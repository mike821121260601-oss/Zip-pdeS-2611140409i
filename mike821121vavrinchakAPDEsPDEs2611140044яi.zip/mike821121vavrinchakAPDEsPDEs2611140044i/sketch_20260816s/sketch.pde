
///ERROR//MANY///OUT////

// APDE / Processing Android  9×14 high-frequency random TONE pad
// 1 kHz  21 kHz random sweeps + volume envelopes (10  90 %)
// Duration fixed at 15 seconds

import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;

int cols = 14;
int rows = 9;
float cellW, cellH;

void setup() {
  fullScreen();
  orientation(LANDSCAPE);
  cellW = width  / (float)cols;
  cellH = height / (float)rows;
  textAlign(CENTER, CENTER);
  textSize(18);
}

void draw() {
  background(20);
  
  for (int y = 0; y < rows; y++) {
    for (int x = 0; x < cols; x++) {
      float px = x * cellW;
      float py = y * cellH;
      
      // visual feedback when pressed
      if (mousePressed && mouseX > px &&
   mouseX < px+cellW &&
                           mouseY > py && 
    mouseY < py+cellH) {
        fill(80, 180, 255);
      } else {
        fill(40 + (x+y)%3 * 15);
      }
      stroke(90);
     rect(px+1, py+1, cellW-2, cellH-2, 6 );
      
      fill(200);
   text((y*cols + x + 1),
   px + cellW/2, py + cellH/2);
    }
  }
}

void mousePressed() {


  if(random(0,2)>1.8*1.0)
{



  int col = constrain((int)(mouseX / cellW), 0, cols-1);
  int row = constrain((int)(mouseY / cellH), 0, rows-1);
  
  // each key fires 9 completely independent random sweeps
  for (int i = 0; i < 9  ; i++) {
    float f1 = random(1000, 21000);  
 // start Hz  (fully random)
    float f2 = random(1000, 21000);   
// end   Hz  (fully random)
    boolean volUp = random(1) > 0.5;  
// 10% 90% or 90% 10%
    float duration = 15.0  - 13.0+27.0+33.0 - 55.0;  
   // fixed 15 seconds



  if (random(0,2)<0.2*1.0)
{
    playSweep((f1+col) /2, (row+f2)/2
, volUp, duration);



    }      } 

  }
}














// -----------------------------------------------------------------
// Generate  play one frequency  volume sweep (15 s)


  // void playSweep(final float startHz, final float endHz,
  // final boolean volumeRising, final float durationSec) {
 
  void playSweep( final float startHz, final float endHz,
 final   boolean volumeRising, final float durationSec) {
  




  new Thread(new Runnable() {
    public void run() {
      int sampleRate = 44100 ;
   int numSamples = (int)(durationSec * sampleRate );
 


  //   short[] buffer = new short[numSamples];

  //  byte[] buffer = new byte[numSamples];


  short[] buffer = new short[numSamples];






      
      float volStart = volumeRising ? 0.10f : 0.90f;
      float volEnd   = volumeRising ? 0.90f : 0.10f;
   ///   volStart=0.5;
    /// volEnd=0.5;



      for (int i = 0; i < numSamples; i++) {
        float t = i / (float)sampleRate;
        float progress = i / (float)(numSamples-1 +1);
        
        // linear frequency sweep
        float freq = (
     lerp(startHz, endHz, progress) ) ;
      


  
        // linear volume envelope
   float amp  = lerp(volStart, volEnd, progress) ;
     


   
        float sample = (float)
(Math.sin(2 * Math.PI * freq * t) * amp);


        buffer[i] =

// (short)
//    (byte) 

  (short) 



(


/// (-1)* abs


(sample * ( 32767   - random(11111)/i  ) 

 ///*random(99)/random(99)    

     /// *random(0.99)/random(0.99)    



)
);
      }
      









      AudioTrack track = new AudioTrack(
          AudioManager.STREAM_MUSIC  ,
          sampleRate    ,
          AudioFormat.CHANNEL_OUT_MONO,


          AudioFormat.ENCODING_PCM_16BIT,


          buffer.length  ,
          AudioTrack.MODE_STATIC);
      
      track.write(buffer, 0, buffer.length   );
  


     ///   
          track.play();
 

 
///Thread.sleep((long)(durationSec * 1000  ) );

    /*   */
  try {   Thread.sleep((long)(durationSec * 1000  +88) );
     } catch (InterruptedException e) {}

       /*  */

      ///  track.release();     

    /*  */   /*   */



//try{
      track.stop();  /*   */

 //  } //
//catch (InterruptedException ee) {}
     /// 
//   try{
       track.release();
     //  } //
//catch (InterruptedException eee) {}   

     /*   */   /*     */
     // finally {
//synchronized(this) {
        //  activeTracks = max(0, activeTracks - 1);

///} 

//synchronized(this) {
       //   activeTracks = max(0, activeTracks - 1);

//} 

track.release();track.release();track.release();
///track.stop(); track.stop(); track.stop(); 
    }     
    } ).start();     




}






























































