


















int typeiooioiooooioooirigibi;
float [] [] m=new float[400][8];

float t=0;

float q=(width/60+height/60) /2;
float oo=width/2;
float o=height/2;
float cc=width/2;
float c=height*0;
float ee=width/2;
float e=height;
void settings() {
size(displayWidth, displayHeight, P2D) ;
} 

void setup() {
//size(displayWidth, displayHeight, P2D) ;
 q=(width/60+height/60) /2;
 oo=width/2;
 o=height/2;
 cc=width/2;
 c=height*0;
 ee=width/2;
 e=height;


println (width) ;
println (height) ;
} 

void draw() {

if(t==0){t=1;
 q=(width/60+height/60)/2;
 oo=width/2;
 o=height/2;
 cc=width/2;
 c=height*0;
 ee=width/2;
 e=height;     




for(int f=0;f<100;f++){
m[f][0]=1;
m[f][1]=random(width);
m[f][2]=random(height);
m[f][3]=random(1);
m[f][4]=random(1);
m[f][5]=random(25);
m[f][6]=random(125,200);
m[f][7]=random(25);  } 


for(int f=100;f<200;f++){
m[f][0]=2;
m[f][1]=random(width);
m[f][2]=random(height);
m[f][3]=random(1);
m[f][4]=random(1);
m[f][5]=random(25);
m[f][6]=random(25);
m[f][7]=random(125,200);  } 


for(int f=200;f<400;f++){
m[f][0]=3;
m[f][1]=random(width);
m[f][2]=random(height);
m[f][3]=random(1);
m[f][4]=random(1);
m[f][5]=random(125,200);
m[f][6]=random(25);
m[f][7]=random(25);  } 











 } 












noStroke() ;
ellipseMode(CENTER) ;
fill(0,0,0);
rect(0,0,width,height) ;



for(int f=0;f<100;f++){
fill( int(round(m[f][5])), 
int(round(m[f][6])), 
int(round(m[f][7]))) ;
ellipse(m[f] [1],m[f][2],q,q);  }



for(int f=100;f<200;f++){
fill( int(round(m[f][5])), 
int(round(m[f][6])), 
int(round(m[f][7]))) ;
ellipse(m[f] [1],m[f][2],q,q);  }


for(int f=200;f<400;f++){
fill( int(round(m[f][5])), 
int(round(m[f][6])), 
int(round(m[f][7]))) ;
ellipse(m[f] [1],m[f][2],q,q);  }







fill(0,0,255);
ellipse(cc, c, q,q);
fill(0,255,0);
ellipse(ee, e, q,q);
fill(255,0,0);
ellipse(oo, o, q,q);
} 




































