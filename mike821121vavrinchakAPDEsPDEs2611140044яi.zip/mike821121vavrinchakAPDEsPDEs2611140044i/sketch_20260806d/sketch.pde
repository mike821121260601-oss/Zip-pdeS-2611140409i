

















/*
If you mean an APDE (Processing for Android) example that opens a file browser so the user can choose a file, you can use an Android file picker with an Intent.
Example (Java/APDE):
*/
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;

Activity activity;

void setup() {
  activity = getActivity();

  Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
  intent.setType("*/*");
  intent.addCategory(Intent.CATEGORY_OPENABLE);

  activity.startActivityForResult(intent, 100);
}

void draw() {
  background(200);
  text("Select a file...", 20, 30);
}


/*
This opens Android's built-in file browser and lets the user select a file.
If you want to:
browse files in a specific folder,
read the selected file,
or create a complete APDE sketch,
tell me which version of APDE and Android you're using, and I can provide a complete working example.

*/








