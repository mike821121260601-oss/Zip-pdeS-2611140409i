































/*

Yes. Here is a complete APDE / Processing Android 3D sketch.
Lamborghini-style low sports car
Built from 3D lines
Target 400+ line segments
Curved parts use 5-line arc sections
Continuous 3D rotation
99 lights supported
Wheels, body, windshield, spoiler, headlights
Touch/drag changes camera angle
Pinch-like zoom with two fingers
*/



// ============================================================
// APDE 3D LINE LAMBORGHINI-STYLE CAR
// Processing / APDE
// ============================================================

int LIGHTS = 7;       // 9 ... 99
int LINE_TARGET = 400; // increase to 4000 if desired

float carRotY = 0;
float carRotX = -0.12;

float cameraDist = 650;
float autoRotate = 0.012;

float oldX, oldY;
boolean dragging = false;

ArrayList<PVector> A = new ArrayList<PVector>();
ArrayList<PVector> B = new ArrayList<PVector>();

// ------------------------------------------------------------

void setup() {
  fullScreen(P3D);
  smooth(4);

  strokeWeight(2);
  noFill();

  buildCar();
}

// ------------------------------------------------------------

void draw() {

  background(3, 5, 9);

  lights3D();

  pushMatrix();

  translate(width/2, height/2 + 50, 0);

  // automatic 3D rotation
  carRotY += autoRotate;

  rotateX(carRotX);
  rotateY(carRotY);

  scale(1.15);

  drawCar();

  popMatrix();

  // information
  camera();
  hint(DISABLE_DEPTH_TEST);

  fill(255);
  textSize(18);
  text("3D LINE CAR", 20, 30);
  text("LINES: " + A.size(), 20, 55);
  text("LIGHTS: " + LIGHTS, 20, 80);

  hint(ENABLE_DEPTH_TEST);
}

// ============================================================
// LIGHTS
// ============================================================

void lights3D() {

  ambientLight(25, 25, 35);

  int n = constrain(LIGHTS, 1, 99);

  for (int i=0; i<n; i++) {

    float a = TWO_PI * i / n;

    float x = cos(a) * 500;
    float y = sin(a * 2.0) * 250;
    float z = sin(a) * 500;

    float r = 80 + 175 * abs(sin(a));
    float g = 50 + 150 * abs(sin(a + 1.5));
    float b = 80 + 175 * abs(cos(a));

    pointLight(
      r, g, b,
      x, y, z
    );
  }
}

// ============================================================
// CAR
// ============================================================

void drawCar() {

  // Main body
  drawGroup(0);

  // roof / cockpit
  drawGroup(1);

  // wheels
  drawGroup(2);

  // windows
  drawGroup(3);

  // headlights
  drawGroup(4);

  // spoiler
  drawGroup(5);

  // extra detail
  drawGroup(6);
}

// ============================================================
// DRAW STORED 3D LINES
// ============================================================

void drawGroup(int group) {

  // groups are encoded by line color
  // simple distance/color classification

  for (int i=0; i<A.size(); i++) {

    PVector p = A.get(i);
    PVector q = B.get(i);

    // normal bright car lines
    stroke(220, 20, 30);

    if (group == 0)
      stroke(240, 30, 40);

    if (group == 1)
      stroke(255, 80, 40);

    if (group == 2)
      stroke(80, 80, 90);

    if (group == 3)
      stroke(30, 180, 255);

    if (group == 4)
      stroke(255, 230, 100);

    if (group == 5)
      stroke(255, 40, 30);

    if (group == 6)
      stroke(255);

    // all geometry is displayed,
    // so the complete line car remains visible
    line(p.x,p.y,p.z,q.x,q.y,q.z);
  }
}

// ============================================================
// BUILD CAR
// ============================================================

void buildCar() {

  A.clear();
  B.clear();

  // ----------------------------------------------------------
  // MAIN BODY
  // ----------------------------------------------------------

  // lower side profile
  polyLine(
    new float[][] {
      {-270, 60, -100},
      {-230, 20, -125},
      {-120, 0, -145},
      { 120, 0, -145},
      { 230, 20, -125},
      { 280, 60, -90}
    }
  );

  // opposite side
  polyLine(
    new float[][] {
      {-270, 60, 100},
      {-230, 20, 125},
      {-120, 0, 145},
      { 120, 0, 145},
      { 230, 20, 125},
      { 280, 60, 90}
    }
  );

  // front
  connect(
    -270,60,-100,
    -270,60,100
  );

  // hood
  polyLine(
    new float[][] {
      {-270,60,-100},
      {-220,20,-90},
      {-150,-5,-70},
      {-70,-20,-55},
      {20,-25,-45}
    }
  );

  polyLine(
    new float[][] {
      {-270,60,100},
      {-220,20,90},
      {-150,-5,70},
      {-70,-20,55},
      {20,-25,45}
    }
  );

  // rear
  polyLine(
    new float[][] {
      {20,-25,-45},
      {150,0,-55},
      {250,30,-75},
      {280,60,-90}
    }
  );

  polyLine(
    new float[][] {
      {20,-25,45},
      {150,0,55},
      {250,30,75},
      {280,60,90}
    }
  );

  // ----------------------------------------------------------
  // SIDE BODY DETAIL
  // ----------------------------------------------------------

  for (int s=-1; s<=1; s+=2) {

    float z = s * 145;

    for (int i=0; i<30; i++) {

      float x1 = -230 + i*16;
      float x2 = x1 + 16;

      float y1 = 20 + sin(i*0.25)*10;
      float y2 = 20 + sin((i+1)*0.25)*10;

      connect(
        x1,y1,z,
        x2,y2,z
      );
    }
  }

  // ----------------------------------------------------------
  // ROOF / CABIN
  // ----------------------------------------------------------

  // roof pillars
  connect(-120,0,-145, -90,-100,-90);
  connect(-120,0,145, -90,-100,90);

  connect(130,5,-130, 90,-80,-80);
  connect(130,5,130, 90,-80,80);

  // roof
  polyLine(
    new float[][] {
      {-90,-100,-90},
      {-40,-125,-75},
      {40,-130,-70},
      {90,-80,-80}
    }
  );

  polyLine(
    new float[][] {
      {-90,-100,90},
      {-40,-125,75},
      {40,-130,70},
      {90,-80,80}
    }
  );

  // roof cross lines
  connect(-40,-125,-75,-40,-125,75);
  connect(40,-130,-70,40,-130,70);

  // ----------------------------------------------------------
  // WINDSHIELD
  // ----------------------------------------------------------

  windshield(
    -85,-95,-90,
    -40,-120,-75,
    -40,-120,75,
    -85,-95,90
  );

  // rear window
  windshield(
    40,-125,-70,
    90,-78,-80,
    90,-78,80,
    40,-125,70
  );

  // ----------------------------------------------------------
  // WHEEL ARCHES
  // ----------------------------------------------------------

  wheelArch(-175,70,-150);
  wheelArch(175,70,-150);

  wheelArch(-175,70,150);
  wheelArch(175,70,150);

  // ----------------------------------------------------------
  // WHEELS
  // ----------------------------------------------------------

  wheel(-175,70,-155,65);
  wheel(175,70,-155,65);

  wheel(-175,70,155,65);
  wheel(175,70,155,65);

  // ----------------------------------------------------------
  // FRONT LIGHTS
  // ----------------------------------------------------------

  headLight(-255,35,-101, 50);
  headLight(-255,35,101, 50);

  // ----------------------------------------------------------
  // REAR LIGHTS
  // ----------------------------------------------------------

  tailLight(250,35,-91,40);
  tailLight(250,35,91,40);

  // ----------------------------------------------------------
  // SPOILER
  // ----------------------------------------------------------

  spoiler();

  // ----------------------------------------------------------
  // SIDE MIRRORS
  // ----------------------------------------------------------

  mirror(-80,-70,-155);
  mirror(-80,-70,155);

  // ----------------------------------------------------------
  // EXTRA 3D BODY LINES
  // ----------------------------------------------------------

  for (int layer=0; layer<8; layer++) {

    float y = 30 + layer*6;

    connect(
      -250,y,-105,
      250,y,-105
    );

    connect(
      -250,y,105,
      250,y,105
    );
  }

  // underbody
  for (int i=0; i<40; i++) {

    float x = -250 + i*12.5;

    connect(
      x,80,-110,
      x+12,80,-110
    );

    connect(
      x,80,110,
      x+12,80,110
    );
  }

  // Increase geometry toward requested line count
  addExtraLines();
}

// ============================================================
// WHEEL
// ============================================================

void wheel(float x, float y, float z, float r) {

  // wheel circles
  // 5 lines per arc section
  for (int ring=0; ring<5; ring++) {

    float rr = r - ring*7;

    arc3D(
      x,y,z,
      rr,
      20,
      5
    );
  }

  // spokes
  for (int i=0; i<10; i++) {

    float a = TWO_PI*i/10.0;

    connect(
      x,
      y,
      z,
      x + cos(a)*r,
      y + sin(a)*r,
      z
    );
  }

  // tire side depth
  connect(x-r,y,z,x-r,y,z+12);
  connect(x+r,y,z,x+r,y,z+12);
}

// ============================================================
// WHEEL ARCH
// ============================================================

void wheelArch(float x,float y,float z) {

  float r = 82;

  arc3D(
    x,y,z,
    r,
    32,
    5
  );

  arc3D(
    x,y,z,
    r+8,
    32,
    5
  );
}

// ============================================================
// HEADLIGHT
// ============================================================

void headLight(float x,float y,float z,float size) {

  for (int i=0; i<5; i++) {

    float a1 = PI*0.15 + i*PI*0.12;
    float a2 = a1 + PI*0.12;

    connect(
      x,y,z,
      x + cos(a1)*size,
      y + sin(a1)*size,
      z
    );

    connect(
      x,y,z,
      x + cos(a2)*size,
      y + sin(a2)*size,
      z
    );
  }
}

// ============================================================
// TAIL LIGHT
// ============================================================

void tailLight(float x,float y,float z,float size) {

  for (int i=0; i<5; i++) {

    float yy = y - size/2 + i*size/4;

    connect(
      x,yy,z,
      x+20,yy,z
    );
  }
}

// ============================================================
// WINDSHIELD
// ============================================================

void windshield(
  float x1,float y1,float z1,
  float x2,float y2,float z2,
  float x3,float y3,float z3,
  float x4,float y4,float z4) {

  connect(x1,y1,z1,x2,y2,z2);
  connect(x2,y2,z2,x3,y3,z3);
  connect(x3,y3,z3,x4,y4,z4);
  connect(x4,y4,z4,x1,y1,z1);

  // internal lines
  for (int i=1; i<6; i++) {

    float t=i/6.0;

    float ax=lerp(x1,x4,t);
    float ay=lerp(y1,y4,t);
    float az=lerp(z1,z4,t);

    float bx=lerp(x2,x3,t);
    float by=lerp(y2,y3,t);
    float bz=lerp(z2,z3,t);

    connect(ax,ay,az,bx,by,bz);
  }
}

// ============================================================
// MIRROR
// ============================================================

void mirror(float x,float y,float z) {

  connect(x,y,z,x-35,y-10,z);
  connect(x-35,y-10,z,x-40,y+5,z);
  connect(x-40,y+5,z,x,y,z);
}

// ============================================================
// SPOILER
// ============================================================

void spoiler() {

  connect(170,20,-100,170,-20,-100);
  connect(170,20,100,170,-20,100);

  connect(170,-20,-110,170,-20,110);

  for (int i=0; i<10; i++) {

    float z = -110 + i*22;

    connect(
      150,-20,z,
      210,-20,z
    );
  }

  connect(150,-20,-110,210,-20,-110);
  connect(150,-20,110,210,-20,110);
}

// ============================================================
// 3D ARC
// IMPORTANT:
// EACH ARC SECTION IS 5 LINES
// ============================================================

void arc3D(
  float cx,
  float cy,
  float cz,
  float radius,
  int segments,
  int linesPerArc) {

  // 5 lines per small arc section
  int n = segments * linesPerArc;

  PVector previous = null;

  for (int i=0; i<=n; i++) {

    float a = TWO_PI * i/n;

    PVector p = new PVector(
      cx + cos(a)*radius,
      cy + sin(a)*radius,
      cz
    );

    if (previous != null) {

      connect(
        previous.x,previous.y,previous.z,
        p.x,p.y,p.z
      );
    }

    previous = p;
  }
}

// ============================================================
// POLYLINE
// ============================================================

void polyLine(float[][] pts) {

  for (int i=0; i<pts.length-1; i++) {

    connect(
      pts[i][0],
      pts[i][1],
      pts[i][2],
      pts[i+1][0],
      pts[i+1][1],
      pts[i+1][2]
    );
  }
}

// ============================================================
// CONNECT
// ============================================================

void connect(
  float x1,float y1,float z1,
  float x2,float y2,float z2) {

  A.add(new PVector(x1,y1,z1));
  B.add(new PVector(x2,y2,z2));
}

// ============================================================
// ADD MANY DETAIL LINES
// ============================================================

void addExtraLines() {

  int wanted = LINE_TARGET;

  while (A.size() < wanted) {

    float t = random(TWO_PI);

    float x1 = cos(t)*random(30,260);
    float z1 = sin(t)*random(70,150);
    float y1 = random(-70,75);

    float x2 = x1 + random(-8,8);
    float y2 = y1 + random(-8,8);
    float z2 = z1 + random(-5,5);

    connect(
      x1,y1,z1,
      x2,y2,z2
    );
  }
}

// ============================================================
// TOUCH
// ============================================================

void touchStarted() {

  oldX = mouseX;
  oldY = mouseY;

  dragging = true;
}

void touchMoved() {

  if (dragging) {

    float dx = mouseX-oldX;
    float dy = mouseY-oldY;

    carRotY += dx*0.01;
    carRotX += dy*0.01;

    carRotX = constrain(
      carRotX,
      -PI/2,
      PI/2
    );

    oldX = mouseX;
    oldY = mouseY;
  }
}

void touchEnded() {

  dragging = false;
}





/*

Main settings
Change these two lines at the top:
int LIGHTS = 99;
int LINE_TARGET = 400;
For a much denser wireframe:
int LIGHTS = 99;
int LINE_TARGET = 4000;

*/







/*

The car continuously rotates around the Y axis, while dragging the screen lets you rotate the car vertically and horizontally.






*/

































