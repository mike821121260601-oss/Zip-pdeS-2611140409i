








// ============================================================
// APDE Chess v0.5.3  -  Simple Board + Engine
// Compatible with APDE 0.5.3
// ============================================================

final int SQ = 80;                    // square size
final int BOARD_SIZE = 8;

int[][] board = new int[8][8];        // 0 = empty
                                      // Positive = White, Negative = Black
                                      // 1=Pawn, 2=Knight, 3=Bishop, 4=Rook, 5=Queen, 6=King

boolean whiteToMove = true;
boolean selected = false;
int selX = -1, selY = -1;

ArrayList<int[]> legalMoves = new ArrayList<int[]>();

boolean engineOn = true;              // engine plays Black
int engineDepth = 3;                  // start with 3 for testing (raise later)

// ------------------------------------------------------------
void setup() {
  size(640, 720);                     // 8*80 = 640
  orientation(PORTRAIT);
  textAlign(CENTER, CENTER);
  textSize(28);
  initBoard();
}

// ------------------------------------------------------------
void draw() {
  background(40);
  drawBoard();
  drawPieces();
  drawSelection();
  drawInfo();
}

// ------------------------------------------------------------
void initBoard() {
  // Clear
  for (int y = 0; y < 8; y++)
    for (int x = 0; x < 8; x++)
      board[y][x] = 0;

  // Black pieces
  board[0][0] = -4; board[0][1] = -2; board[0][2] = -3; board[0][3] = -5;
  board[0][4] = -6; board[0][5] = -3; board[0][6] = -2; board[0][7] = -4;
  for (int x = 0; x < 8; x++) board[1][x] = -1;

  // White pieces
  for (int x = 0; x < 8; x++) board[6][x] = 1;
  board[7][0] = 4; board[7][1] = 2; board[7][2] = 3; board[7][3] = 5;
  board[7][4] = 6; board[7][5] = 3; board[7][6] = 2; board[7][7] = 4;
}

// ------------------------------------------------------------
void drawBoard() {
  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {
      if ((x + y) % 2 == 0) fill(240, 220, 130);   // yellow
      else                  fill(180);             // light grey
      rect(x * SQ, y * SQ, SQ, SQ);
    }
  }
}

// ------------------------------------------------------------
void drawPieces() {
  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {
      int p = board[y][x];
      if (p == 0) continue;

      if (p > 0) fill(255);          // White
      else       fill(30);           // Black

      String s = pieceChar(abs(p));
      text(s, x * SQ + SQ/2, y * SQ + SQ/2);
    }
  }
}

String pieceChar(int p) {
  if (p == 1) return "P";
  if (p == 2) return "N";
  if (p == 3) return "B";
  if (p == 4) return "R";
  if (p == 5) return "Q";
  if (p == 6) return "K";
  return "?";
}

// ------------------------------------------------------------
void drawSelection() {
  if (!selected) return;
  noFill();
  stroke(0, 120, 255);
  strokeWeight(4);
  rect(selX * SQ, selY * SQ, SQ, SQ);
  strokeWeight(1);
  noStroke();

  // legal move markers
  fill(0, 180, 0, 120);
  for (int[] m : legalMoves) {
    ellipse(m[0] * SQ + SQ/2, m[1] * SQ + SQ/2, 30, 30);
  }
}

// ------------------------------------------------------------
void drawInfo() {
  fill(220);
  textSize(22);
  textAlign(LEFT, CENTER);
  String side = whiteToMove ? "White" : "Black";
  text("Turn: " + side + "   Depth: " + engineDepth, 20, 660);
  text("Tap piece → tap square   |  Engine: " + (engineOn ? "ON" : "OFF"), 20, 690);
  textAlign(CENTER, CENTER);
  textSize(28);
}

// ------------------------------------------------------------
void mousePressed() {
  int x = mouseX / SQ;
  int y = mouseY / SQ;
  if (x < 0 || x > 7 || y < 0 || y > 7) return;

  if (!selected) {
    // select own piece
    int p = board[y][x];
    if (p == 0) return;
    if (whiteToMove && p < 0) return;
    if (!whiteToMove && p > 0) return;

    selected = true;
    selX = x;
    selY = y;
    generateLegalMoves(x, y);
  } else {
    // try to move
    boolean found = false;
    for (int[] m : legalMoves) {
      if (m[0] == x && m[1] == y) {
        makeMove(selX, selY, x, y);
        found = true;
        break;
      }
    }
    selected = false;
    legalMoves.clear();

    if (found) {
      whiteToMove = !whiteToMove;
      if (engineOn && !whiteToMove) {
        // engine move after short delay so UI updates
        delay(100);
        engineMove();
      }
    }
  }
}

// ------------------------------------------------------------
void generateLegalMoves(int x, int y) {
  legalMoves.clear();
  int p = board[y][x];
  int color = p > 0 ? 1 : -1;
  int type = abs(p);

  // Pawn
  if (type == 1) {
    int dir = color;                 // White moves up (y decreases)
    int ny = y - dir;
    if (ny >= 0 && ny < 8 && board[ny][x] == 0) {
      legalMoves.add(new int[]{x, ny});
      // double step
      if ((color == 1 && y == 6) || (color == -1 && y == 1)) {
        int ny2 = y - 2 * dir;
        if (board[ny2][x] == 0) legalMoves.add(new int[]{x, ny2});
      }
    }
    // captures
    for (int dx = -1; dx <= 1; dx += 2) {
      int nx = x + dx;
      if (nx >= 0 && nx < 8 && ny >= 0 && ny < 8) {
        if (board[ny][nx] * color < 0) legalMoves.add(new int[]{nx, ny});
      }
    }
  }

  // Knight
  else if (type == 2) {
    int[][] jumps = {{1,2},{1,-2},{-1,2},{-1,-2},{2,1},{2,-1},{-2,1},{-2,-1}};
    for (int[] j : jumps) {
      int nx = x + j[0], ny = y + j[1];
      if (nx >= 0 && nx < 8 && ny >= 0 && ny < 8) {
        if (board[ny][nx] * color <= 0) legalMoves.add(new int[]{nx, ny});
      }
    }
  }

  // Bishop / Rook / Queen / King (simple rays + king)
  else {
    int[][] dirs;
    if (type == 3) dirs = new int[][]{{1,1},{1,-1},{-1,1},{-1,-1}};          // Bishop
    else if (type == 4) dirs = new int[][]{{1,0},{-1,0},{0,1},{0,-1}};        // Rook
    else if (type == 5) dirs = new int[][]{{1,0},{-1,0},{0,1},{0,-1},{1,1},{1,-1},{-1,1},{-1,-1}}; // Queen
    else dirs = new int[][]{{1,0},{-1,0},{0,1},{0,-1},{1,1},{1,-1},{-1,1},{-1,-1}}; // King

    for (int[] d : dirs) {
      for (int dist = 1; dist <= (type == 6 ? 1 : 7); dist++) {
        int nx = x + d[0] * dist;
        int ny = y + d[1] * dist;
        if (nx < 0 || nx > 7 || ny < 0 || ny > 7) break;
        int target = board[ny][nx];
        if (target == 0) {
          legalMoves.add(new int[]{nx, ny});
        } else {
          if (target * color < 0) legalMoves.add(new int[]{nx, ny});
          break;
        }
      }
    }
  }
}

// ------------------------------------------------------------
void makeMove(int x1, int y1, int x2, int y2) {
  board[y2][x2] = board[y1][x1];
  board[y1][x1] = 0;

  // simple promotion
  if (abs(board[y2][x2]) == 1) {
    if (y2 == 0 || y2 == 7) board[y2][x2] = (board[y2][x2] > 0) ? 5 : -5;
  }
}

// ============================================================
//  SIMPLE ENGINE
// ============================================================

void engineMove() {
  int[] best = searchBestMove(engineDepth);
  if (best != null) {
    makeMove(best[0], best[1], best[2], best[3]);
    whiteToMove = true;
  }
}

int[] searchBestMove(int depth) {
  ArrayList<int[]> allMoves = getAllMoves(-1);   // Black moves
  if (allMoves.size() == 0) return null;

  int bestScore = -99999;
  int[] bestMove = allMoves.get(0);

  for (int[] m : allMoves) {
    // make
    int captured = board[m[3]][m[2]];
    board[m[3]][m[2]] = board[m[1]][m[0]];
    board[m[1]][m[0]] = 0;

    int score = -negamax(depth - 1, 1, -99999, 99999);

    // undo
    board[m[1]][m[0]] = board[m[3]][m[2]];
    board[m[3]][m[2]] = captured;

    if (score > bestScore) {
      bestScore = score;
      bestMove = m;
    }
  }
  return bestMove;
}

int negamax(int depth, int color, int alpha, int beta) {
  if (depth == 0) return color * evaluate();

  ArrayList<int[]> moves = getAllMoves(color);
  if (moves.size() == 0) return color * evaluate();   // no check detection yet

  int best = -99999;
  for (int[] m : moves) {
    int captured = board[m[3]][m[2]];
    board[m[3]][m[2]] = board[m[1]][m[0]];
    board[m[1]][m[0]] = 0;

    int score = -negamax(depth - 1, -color, -beta, -alpha);

    board[m[1]][m[0]] = board[m[3]][m[2]];
    board[m[3]][m[2]] = captured;

    if (score > best) best = score;
    if (score > alpha) alpha = score;
    if (alpha >= beta) break;
  }
  return best;
}

ArrayList<int[]> getAllMoves(int color) {
  ArrayList<int[]> list = new ArrayList<int[]>();
  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {
      if (board[y][x] * color > 0) {
        generateLegalMoves(x, y);
        for (int[] m : legalMoves) {
          list.add(new int[]{x, y, m[0], m[1]});
        }
      }
    }
  }
  legalMoves.clear();
  return list;
}

// ------------------------------------------------------------
int evaluate() {
  int score = 0;
  int[] values = {0, 100, 320, 330, 500, 900, 20000};

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {
      int p = board[y][x];
      if (p == 0) continue;
      int v = values[abs(p)];
      if (p > 0) score += v;
      else       score -= v;
    }
  }
  return score;
}

// ------------------------------------------------------------
// Optional: keyboard controls for testing
void keyPressed() {
  if (key == 'e' || key == 'E') engineOn = !engineOn;
  if (key == '+' || key == '=') engineDepth = min(5, engineDepth + 1);
  if (key == '-')              engineDepth = max(1, engineDepth - 1);
  if (key == 'r' || key == 'R') {
    initBoard();
    whiteToMove = true;
    selected = false;
  }
}









/*



// ============================================================
// APDE Chess v0.5.3  -  Simple Board + Engine
// Compatible with APDE 0.5.3
// ============================================================

final int SQ = 80;                    // square size
final int BOARD_SIZE = 8;

int[][] board = new int[8][8];        // 0 = empty
                                      // Positive = White, Negative = Black
                                      // 1=Pawn, 2=Knight, 3=Bishop, 4=Rook, 5=Queen, 6=King

boolean whiteToMove = true;
boolean selected = false;
int selX = -1, selY = -1;

ArrayList<int[]> legalMoves = new ArrayList<int[]>();

boolean engineOn = true;              // engine plays Black
int engineDepth = 3;                  // start with 3 for testing (raise later)

// ------------------------------------------------------------
void setup() {
  size(640, 720);                     // 8*80 = 640
  orientation(PORTRAIT);
  textAlign(CENTER, CENTER);
  textSize(28);
  initBoard();
}

// ------------------------------------------------------------
void draw() {
  background(40);
  drawBoard();
  drawPieces();
  drawSelection();
  drawInfo();
}

// ------------------------------------------------------------
void initBoard() {
  // Clear
  for (int y = 0; y < 8; y++)
    for (int x = 0; x < 8; x++)
      board[y][x] = 0;

  // Black pieces
  board[0][0] = -4; board[0][1] = -2; board[0][2] = -3; board[0][3] = -5;
  board[0][4] = -6; board[0][5] = -3; board[0][6] = -2; board[0][7] = -4;
  for (int x = 0; x < 8; x++) board[1][x] = -1;

  // White pieces
  for (int x = 0; x < 8; x++) board[6][x] = 1;
  board[7][0] = 4; board[7][1] = 2; board[7][2] = 3; board[7][3] = 5;
  board[7][4] = 6; board[7][5] = 3; board[7][6] = 2; board[7][7] = 4;
}

// ------------------------------------------------------------
void drawBoard() {
  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {
      if ((x + y) % 2 == 0) fill(240, 220, 130);   // yellow
      else                  fill(180);             // light grey
      rect(x * SQ, y * SQ, SQ, SQ);
    }
  }
}

// ------------------------------------------------------------
void drawPieces() {
  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {
      int p = board[y][x];
      if (p == 0) continue;

      if (p > 0) fill(255);          // White
      else       fill(30);           // Black

      String s = pieceChar(abs(p));
      text(s, x * SQ + SQ/2, y * SQ + SQ/2);
    }
  }
}

String pieceChar(int p) {
  if (p == 1) return "P";
  if (p == 2) return "N";
  if (p == 3) return "B";
  if (p == 4) return "R";
  if (p == 5) return "Q";
  if (p == 6) return "K";
  return "?";
}

// ------------------------------------------------------------
void drawSelection() {
  if (!selected) return;
  noFill();
  stroke(0, 120, 255);
  strokeWeight(4);
  rect(selX * SQ, selY * SQ, SQ, SQ);
  strokeWeight(1);
  noStroke();

  // legal move markers
  fill(0, 180, 0, 120);
  for (int[] m : legalMoves) {
    ellipse(m[0] * SQ + SQ/2, m[1] * SQ + SQ/2, 30, 30);
  }
}

// ------------------------------------------------------------
void drawInfo() {
  fill(220);
  textSize(22);
  textAlign(LEFT, CENTER);
  String side = whiteToMove ? "White" : "Black";
  text("Turn: " + side + "   Depth: " + engineDepth, 20, 660);
  text("Tap piece → tap square   |  Engine: " + (engineOn ? "ON" : "OFF"), 20, 690);
  textAlign(CENTER, CENTER);
  textSize(28);
}

// ------------------------------------------------------------
void mousePressed() {
  int x = mouseX / SQ;
  int y = mouseY / SQ;
  if (x < 0 || x > 7 || y < 0 || y > 7) return;

  if (!selected) {
    // select own piece
    int p = board[y][x];
    if (p == 0) return;
    if (whiteToMove && p < 0) return;
    if (!whiteToMove && p > 0) return;

    selected = true;
    selX = x;
    selY = y;
    generateLegalMoves(x, y);
  } else {
    // try to move
    boolean found = false;
    for (int[] m : legalMoves) {
      if (m[0] == x && m[1] == y) {
        makeMove(selX, selY, x, y);
        found = true;
        break;
      }
    }
    selected = false;
    legalMoves.clear();

    if (found) {
      whiteToMove = !whiteToMove;
      if (engineOn && !whiteToMove) {
        // engine move after short delay so UI updates
        delay(100);
        engineMove();
      }
    }
  }
}

// ------------------------------------------------------------
void generateLegalMoves(int x, int y) {
  legalMoves.clear();
  int p = board[y][x];
  int color = p > 0 ? 1 : -1;
  int type = abs(p);

  // Pawn
  if (type == 1) {
    int dir = color;                 // White moves up (y decreases)
    int ny = y - dir;
    if (ny >= 0 && ny < 8 && board[ny][x] == 0) {
      legalMoves.add(new int[]{x, ny});
      // double step
      if ((color == 1 && y == 6) || (color == -1 && y == 1)) {
        int ny2 = y - 2 * dir;
        if (board[ny2][x] == 0) legalMoves.add(new int[]{x, ny2});
      }
    }
    // captures
    for (int dx = -1; dx <= 1; dx += 2) {
      int nx = x + dx;
      if (nx >= 0 && nx < 8 && ny >= 0 && ny < 8) {
        if (board[ny][nx] * color < 0) legalMoves.add(new int[]{nx, ny});
      }
    }
  }

  // Knight
  else if (type == 2) {
    int[][] jumps = {{1,2},{1,-2},{-1,2},{-1,-2},{2,1},{2,-1},{-2,1},{-2,-1}};
    for (int[] j : jumps) {
      int nx = x + j[0], ny = y + j[1];
      if (nx >= 0 && nx < 8 && ny >= 0 && ny < 8) {
        if (board[ny][nx] * color <= 0) legalMoves.add(new int[]{nx, ny});
      }
    }
  }

  // Bishop / Rook / Queen / King (simple rays + king)
  else {
    int[][] dirs;
    if (type == 3) dirs = new int[][]{{1,1},{1,-1},{-1,1},{-1,-1}};          // Bishop
    else if (type == 4) dirs = new int[][]{{1,0},{-1,0},{0,1},{0,-1}};        // Rook
    else if (type == 5) dirs = new int[][]{{1,0},{-1,0},{0,1},{0,-1},{1,1},{1,-1},{-1,1},{-1,-1}}; // Queen
    else dirs = new int[][]{{1,0},{-1,0},{0,1},{0,-1},{1,1},{1,-1},{-1,1},{-1,-1}}; // King

    for (int[] d : dirs) {
      for (int dist = 1; dist <= (type == 6 ? 1 : 7); dist++) {
        int nx = x + d[0] * dist;
        int ny = y + d[1] * dist;
        if (nx < 0 || nx > 7 || ny < 0 || ny > 7) break;
        int target = board[ny][nx];
        if (target == 0) {
          legalMoves.add(new int[]{nx, ny});
        } else {
          if (target * color < 0) legalMoves.add(new int[]{nx, ny});
          break;
        }
      }
    }
  }
}

// ------------------------------------------------------------
void makeMove(int x1, int y1, int x2, int y2) {
  board[y2][x2] = board[y1][x1];
  board[y1][x1] = 0;

  // simple promotion
  if (abs(board[y2][x2]) == 1) {
    if (y2 == 0 || y2 == 7) board[y2][x2] = (board[y2][x2] > 0) ? 5 : -5;
  }
}

// ============================================================
//  SIMPLE ENGINE
// ============================================================

void engineMove() {
  int[] best = searchBestMove(engineDepth);
  if (best != null) {
    makeMove(best[0], best[1], best[2], best[3]);
    whiteToMove = true;
  }
}

int[] searchBestMove(int depth) {
  ArrayList<int[]> allMoves = getAllMoves(-1);   // Black moves
  if (allMoves.size() == 0) return null;

  int bestScore = -99999;
  int[] bestMove = allMoves.get(0);

  for (int[] m : allMoves) {
    // make
    int captured = board[m[3]][m[2]];
    board[m[3]][m[2]] = board[m[1]][m[0]];
    board[m[1]][m[0]] = 0;

    int score = -negamax(depth - 1, 1, -99999, 99999);

    // undo
    board[m[1]][m[0]] = board[m[3]][m[2]];
    board[m[3]][m[2]] = captured;

    if (score > bestScore) {
      bestScore = score;
      bestMove = m;
    }
  }
  return bestMove;
}

int negamax(int depth, int color, int alpha, int beta) {
  if (depth == 0) return color * evaluate();

  ArrayList<int[]> moves = getAllMoves(color);
  if (moves.size() == 0) return color * evaluate();   // no check detection yet

  int best = -99999;
  for (int[] m : moves) {
    int captured = board[m[3]][m[2]];
    board[m[3]][m[2]] = board[m[1]][m[0]];
    board[m[1]][m[0]] = 0;

    int score = -negamax(depth - 1, -color, -beta, -alpha);

    board[m[1]][m[0]] = board[m[3]][m[2]];
    board[m[3]][m[2]] = captured;

    if (score > best) best = score;
    if (score > alpha) alpha = score;
    if (alpha >= beta) break;
  }
  return best;
}

ArrayList<int[]> getAllMoves(int color) {
  ArrayList<int[]> list = new ArrayList<int[]>();
  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {
      if (board[y][x] * color > 0) {
        generateLegalMoves(x, y);
        for (int[] m : legalMoves) {
          list.add(new int[]{x, y, m[0], m[1]});
        }
      }
    }
  }
  legalMoves.clear();
  return list;
}

// ------------------------------------------------------------
int evaluate() {
  int score = 0;
  int[] values = {0, 100, 320, 330, 500, 900, 20000};

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {
      int p = board[y][x];
      if (p == 0) continue;
      int v = values[abs(p)];
      if (p > 0) score += v;
      else       score -= v;
    }
  }
  return score;
}

// ------------------------------------------------------------
// Optional: keyboard controls for testing
void keyPressed() {
  if (key == 'e' || key == 'E') engineOn = !engineOn;
  if (key == '+' || key == '=') engineDepth = min(5, engineDepth + 1);
  if (key == '-')              engineDepth = max(1, engineDepth - 1);
  if (key == 'r' || key == 'R') {
    initBoard();
    whiteToMove = true;
    selected = false;
  }
}



// ============================================================
// APDE Chess v0.5.3  -  Simple Board + Engine
// Compatible with APDE 0.5.3
// ============================================================

final int SQ = 80;                    // square size
final int BOARD_SIZE = 8;

int[][] board = new int[8][8];        // 0 = empty
                                      // Positive = White, Negative = Black
                                      // 1=Pawn, 2=Knight, 3=Bishop, 4=Rook, 5=Queen, 6=King

boolean whiteToMove = true;
boolean selected = false;
int selX = -1, selY = -1;

ArrayList<int[]> legalMoves = new ArrayList<int[]>();

boolean engineOn = true;              // engine plays Black
int engineDepth = 3;                  // start with 3 for testing (raise later)

// ------------------------------------------------------------
void setup() {
  size(640, 720);                     // 8*80 = 640
  orientation(PORTRAIT);
  textAlign(CENTER, CENTER);
  textSize(28);
  initBoard();
}

// ------------------------------------------------------------
void draw() {
  background(40);
  drawBoard();
  drawPieces();
  drawSelection();
  drawInfo();
}

// ------------------------------------------------------------
void initBoard() {
  // Clear
  for (int y = 0; y < 8; y++)
    for (int x = 0; x < 8; x++)
      board[y][x] = 0;

  // Black pieces
  board[0][0] = -4; board[0][1] = -2; board[0][2] = -3; board[0][3] = -5;
  board[0][4] = -6; board[0][5] = -3; board[0][6] = -2; board[0][7] = -4;
  for (int x = 0; x < 8; x++) board[1][x] = -1;

  // White pieces
  for (int x = 0; x < 8; x++) board[6][x] = 1;
  board[7][0] = 4; board[7][1] = 2; board[7][2] = 3; board[7][3] = 5;
  board[7][4] = 6; board[7][5] = 3; board[7][6] = 2; board[7][7] = 4;
}

// ------------------------------------------------------------
void drawBoard() {
  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {
      if ((x + y) % 2 == 0) fill(240, 220, 130);   // yellow
      else                  fill(180);             // light grey
      rect(x * SQ, y * SQ, SQ, SQ);
    }
  }
}

// ------------------------------------------------------------
void drawPieces() {
  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {
      int p = board[y][x];
      if (p == 0) continue;

      if (p > 0) fill(255);          // White
      else       fill(30);           // Black

      String s = pieceChar(abs(p));
      text(s, x * SQ + SQ/2, y * SQ + SQ/2);
    }
  }
}

String pieceChar(int p) {
  if (p == 1) return "P";
  if (p == 2) return "N";
  if (p == 3) return "B";
  if (p == 4) return "R";
  if (p == 5) return "Q";
  if (p == 6) return "K";
  return "?";
}

// ------------------------------------------------------------
void drawSelection() {
  if (!selected) return;
  noFill();
  stroke(0, 120, 255);
  strokeWeight(4);
  rect(selX * SQ, selY * SQ, SQ, SQ);
  strokeWeight(1);
  noStroke();

  // legal move markers
  fill(0, 180, 0, 120);
  for (int[] m : legalMoves) {
    ellipse(m[0] * SQ + SQ/2, m[1] * SQ + SQ/2, 30, 30);
  }
}

// ------------------------------------------------------------
void drawInfo() {
  fill(220);
  textSize(22);
  textAlign(LEFT, CENTER);
  String side = whiteToMove ? "White" : "Black";
  text("Turn: " + side + "   Depth: " + engineDepth, 20, 660);
  text("Tap piece → tap square   |  Engine: " + (engineOn ? "ON" : "OFF"), 20, 690);
  textAlign(CENTER, CENTER);
  textSize(28);
}

// ------------------------------------------------------------
void mousePressed() {
  int x = mouseX / SQ;
  int y = mouseY / SQ;
  if (x < 0 || x > 7 || y < 0 || y > 7) return;

  if (!selected) {
    // select own piece
    int p = board[y][x];
    if (p == 0) return;
    if (whiteToMove && p < 0) return;
    if (!whiteToMove && p > 0) return;

    selected = true;
    selX = x;
    selY = y;
    generateLegalMoves(x, y);
  } else {
    // try to move
    boolean found = false;
    for (int[] m : legalMoves) {
      if (m[0] == x && m[1] == y) {
        makeMove(selX, selY, x, y);
        found = true;
        break;
      }
    }
    selected = false;
    legalMoves.clear();

    if (found) {
      whiteToMove = !whiteToMove;
      if (engineOn && !whiteToMove) {
        // engine move after short delay so UI updates
        delay(100);
        engineMove();
      }
    }
  }
}

// ------------------------------------------------------------
void generateLegalMoves(int x, int y) {
  legalMoves.clear();
  int p = board[y][x];
  int color = p > 0 ? 1 : -1;
  int type = abs(p);

  // Pawn
  if (type == 1) {
    int dir = color;                 // White moves up (y decreases)
    int ny = y - dir;
    if (ny >= 0 && ny < 8 && board[ny][x] == 0) {
      legalMoves.add(new int[]{x, ny});
      // double step
      if ((color == 1 && y == 6) || (color == -1 && y == 1)) {
        int ny2 = y - 2 * dir;
        if (board[ny2][x] == 0) legalMoves.add(new int[]{x, ny2});
      }
    }
    // captures
    for (int dx = -1; dx <= 1; dx += 2) {
      int nx = x + dx;
      if (nx >= 0 && nx < 8 && ny >= 0 && ny < 8) {
        if (board[ny][nx] * color < 0) legalMoves.add(new int[]{nx, ny});
      }
    }
  }

  // Knight
  else if (type == 2) {
    int[][] jumps = {{1,2},{1,-2},{-1,2},{-1,-2},{2,1},{2,-1},{-2,1},{-2,-1}};
    for (int[] j : jumps) {
      int nx = x + j[0], ny = y + j[1];
      if (nx >= 0 && nx < 8 && ny >= 0 && ny < 8) {
        if (board[ny][nx] * color <= 0) legalMoves.add(new int[]{nx, ny});
      }
    }
  }

  // Bishop / Rook / Queen / King (simple rays + king)
  else {
    int[][] dirs;
    if (type == 3) dirs = new int[][]{{1,1},{1,-1},{-1,1},{-1,-1}};          // Bishop
    else if (type == 4) dirs = new int[][]{{1,0},{-1,0},{0,1},{0,-1}};        // Rook
    else if (type == 5) dirs = new int[][]{{1,0},{-1,0},{0,1},{0,-1},{1,1},{1,-1},{-1,1},{-1,-1}}; // Queen
    else dirs = new int[][]{{1,0},{-1,0},{0,1},{0,-1},{1,1},{1,-1},{-1,1},{-1,-1}}; // King

    for (int[] d : dirs) {
      for (int dist = 1; dist <= (type == 6 ? 1 : 7); dist++) {
        int nx = x + d[0] * dist;
        int ny = y + d[1] * dist;
        if (nx < 0 || nx > 7 || ny < 0 || ny > 7) break;
        int target = board[ny][nx];
        if (target == 0) {
          legalMoves.add(new int[]{nx, ny});
        } else {
          if (target * color < 0) legalMoves.add(new int[]{nx, ny});
          break;
        }
      }
    }
  }
}

// ------------------------------------------------------------
void makeMove(int x1, int y1, int x2, int y2) {
  board[y2][x2] = board[y1][x1];
  board[y1][x1] = 0;

  // simple promotion
  if (abs(board[y2][x2]) == 1) {
    if (y2 == 0 || y2 == 7) board[y2][x2] = (board[y2][x2] > 0) ? 5 : -5;
  }
}

// ============================================================
//  SIMPLE ENGINE
// ============================================================

void engineMove() {
  int[] best = searchBestMove(engineDepth);
  if (best != null) {
    makeMove(best[0], best[1], best[2], best[3]);
    whiteToMove = true;
  }
}

int[] searchBestMove(int depth) {
  ArrayList<int[]> allMoves = getAllMoves(-1);   // Black moves
  if (allMoves.size() == 0) return null;

  int bestScore = -99999;
  int[] bestMove = allMoves.get(0);

  for (int[] m : allMoves) {
    // make
    int captured = board[m[3]][m[2]];
    board[m[3]][m[2]] = board[m[1]][m[0]];
    board[m[1]][m[0]] = 0;

    int score = -negamax(depth - 1, 1, -99999, 99999);

    // undo
    board[m[1]][m[0]] = board[m[3]][m[2]];
    board[m[3]][m[2]] = captured;

    if (score > bestScore) {
      bestScore = score;
      bestMove = m;
    }
  }
  return bestMove;
}

int negamax(int depth, int color, int alpha, int beta) {
  if (depth == 0) return color * evaluate();

  ArrayList<int[]> moves = getAllMoves(color);
  if (moves.size() == 0) return color * evaluate();   // no check detection yet

  int best = -99999;
  for (int[] m : moves) {
    int captured = board[m[3]][m[2]];
    board[m[3]][m[2]] = board[m[1]][m[0]];
    board[m[1]][m[0]] = 0;

    int score = -negamax(depth - 1, -color, -beta, -alpha);

    board[m[1]][m[0]] = board[m[3]][m[2]];
    board[m[3]][m[2]] = captured;

    if (score > best) best = score;
    if (score > alpha) alpha = score;
    if (alpha >= beta) break;
  }
  return best;
}

ArrayList<int[]> getAllMoves(int color) {
  ArrayList<int[]> list = new ArrayList<int[]>();
  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {
      if (board[y][x] * color > 0) {
        generateLegalMoves(x, y);
        for (int[] m : legalMoves) {
          list.add(new int[]{x, y, m[0], m[1]});
        }
      }
    }
  }
  legalMoves.clear();
  return list;
}

// ------------------------------------------------------------
int evaluate() {
  int score = 0;
  int[] values = {0, 100, 320, 330, 500, 900, 20000};

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {
      int p = board[y][x];
      if (p == 0) continue;
      int v = values[abs(p)];
      if (p > 0) score += v;
      else       score -= v;
    }
  }
  return score;
}

// ------------------------------------------------------------
// Optional: keyboard controls for testing
void keyPressed() {
  if (key == 'e' || key == 'E') engineOn = !engineOn;
  if (key == '+' || key == '=') engineDepth = min(5, engineDepth + 1);
  if (key == '-')              engineDepth = max(1, engineDepth - 1);
  if (key == 'r' || key == 'R') {
    initBoard();
    whiteToMove = true;
    selected = false;
  }
}



// ============================================================
// APDE Chess v0.5.3  -  Simple Board + Engine
// Compatible with APDE 0.5.3
// ============================================================

final int SQ = 80;                    // square size
final int BOARD_SIZE = 8;

int[][] board = new int[8][8];        // 0 = empty
                                      // Positive = White, Negative = Black
                                      // 1=Pawn, 2=Knight, 3=Bishop, 4=Rook, 5=Queen, 6=King

boolean whiteToMove = true;
boolean selected = false;
int selX = -1, selY = -1;

ArrayList<int[]> legalMoves = new ArrayList<int[]>();

boolean engineOn = true;              // engine plays Black
int engineDepth = 3;                  // start with 3 for testing (raise later)

// ------------------------------------------------------------
void setup() {
  size(640, 720);                     // 8*80 = 640
  orientation(PORTRAIT);
  textAlign(CENTER, CENTER);
  textSize(28);
  initBoard();
}

// ------------------------------------------------------------
void draw() {
  background(40);
  drawBoard();
  drawPieces();
  drawSelection();
  drawInfo();
}

// ------------------------------------------------------------
void initBoard() {
  // Clear
  for (int y = 0; y < 8; y++)
    for (int x = 0; x < 8; x++)
      board[y][x] = 0;

  // Black pieces
  board[0][0] = -4; board[0][1] = -2; board[0][2] = -3; board[0][3] = -5;
  board[0][4] = -6; board[0][5] = -3; board[0][6] = -2; board[0][7] = -4;
  for (int x = 0; x < 8; x++) board[1][x] = -1;

  // White pieces
  for (int x = 0; x < 8; x++) board[6][x] = 1;
  board[7][0] = 4; board[7][1] = 2; board[7][2] = 3; board[7][3] = 5;
  board[7][4] = 6; board[7][5] = 3; board[7][6] = 2; board[7][7] = 4;
}

// ------------------------------------------------------------
void drawBoard() {
  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {
      if ((x + y) % 2 == 0) fill(240, 220, 130);   // yellow
      else                  fill(180);             // light grey
      rect(x * SQ, y * SQ, SQ, SQ);
    }
  }
}

// ------------------------------------------------------------
void drawPieces() {
  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {
      int p = board[y][x];
      if (p == 0) continue;

      if (p > 0) fill(255);          // White
      else       fill(30);           // Black

      String s = pieceChar(abs(p));
      text(s, x * SQ + SQ/2, y * SQ + SQ/2);
    }
  }
}

String pieceChar(int p) {
  if (p == 1) return "P";
  if (p == 2) return "N";
  if (p == 3) return "B";
  if (p == 4) return "R";
  if (p == 5) return "Q";
  if (p == 6) return "K";
  return "?";
}

// ------------------------------------------------------------
void drawSelection() {
  if (!selected) return;
  noFill();
  stroke(0, 120, 255);
  strokeWeight(4);
  rect(selX * SQ, selY * SQ, SQ, SQ);
  strokeWeight(1);
  noStroke();

  // legal move markers
  fill(0, 180, 0, 120);
  for (int[] m : legalMoves) {
    ellipse(m[0] * SQ + SQ/2, m[1] * SQ + SQ/2, 30, 30);
  }
}

// ------------------------------------------------------------
void drawInfo() {
  fill(220);
  textSize(22);
  textAlign(LEFT, CENTER);
  String side = whiteToMove ? "White" : "Black";
  text("Turn: " + side + "   Depth: " + engineDepth, 20, 660);
  text("Tap piece → tap square   |  Engine: " + (engineOn ? "ON" : "OFF"), 20, 690);
  textAlign(CENTER, CENTER);
  textSize(28);
}

// ------------------------------------------------------------
void mousePressed() {
  int x = mouseX / SQ;
  int y = mouseY / SQ;
  if (x < 0 || x > 7 || y < 0 || y > 7) return;

  if (!selected) {
    // select own piece
    int p = board[y][x];
    if (p == 0) return;
    if (whiteToMove && p < 0) return;
    if (!whiteToMove && p > 0) return;

    selected = true;
    selX = x;
    selY = y;
    generateLegalMoves(x, y);
  } else {
    // try to move
    boolean found = false;
    for (int[] m : legalMoves) {
      if (m[0] == x && m[1] == y) {
        makeMove(selX, selY, x, y);
        found = true;
        break;
      }
    }
    selected = false;
    legalMoves.clear();

    if (found) {
      whiteToMove = !whiteToMove;
      if (engineOn && !whiteToMove) {
        // engine move after short delay so UI updates
        delay(100);
        engineMove();
      }
    }
  }
}

// ------------------------------------------------------------
void generateLegalMoves(int x, int y) {
  legalMoves.clear();
  int p = board[y][x];
  int color = p > 0 ? 1 : -1;
  int type = abs(p);

  // Pawn
  if (type == 1) {
    int dir = color;                 // White moves up (y decreases)
    int ny = y - dir;
    if (ny >= 0 && ny < 8 && board[ny][x] == 0) {
      legalMoves.add(new int[]{x, ny});
      // double step
      if ((color == 1 && y == 6) || (color == -1 && y == 1)) {
        int ny2 = y - 2 * dir;
        if (board[ny2][x] == 0) legalMoves.add(new int[]{x, ny2});
      }
    }
    // captures
    for (int dx = -1; dx <= 1; dx += 2) {
      int nx = x + dx;
      if (nx >= 0 && nx < 8 && ny >= 0 && ny < 8) {
        if (board[ny][nx] * color < 0) legalMoves.add(new int[]{nx, ny});
      }
    }
  }

  // Knight
  else if (type == 2) {
    int[][] jumps = {{1,2},{1,-2},{-1,2},{-1,-2},{2,1},{2,-1},{-2,1},{-2,-1}};
    for (int[] j : jumps) {
      int nx = x + j[0], ny = y + j[1];
      if (nx >= 0 && nx < 8 && ny >= 0 && ny < 8) {
        if (board[ny][nx] * color <= 0) legalMoves.add(new int[]{nx, ny});
      }
    }
  }

  // Bishop / Rook / Queen / King (simple rays + king)
  else {
    int[][] dirs;
    if (type == 3) dirs = new int[][]{{1,1},{1,-1},{-1,1},{-1,-1}};          // Bishop
    else if (type == 4) dirs = new int[][]{{1,0},{-1,0},{0,1},{0,-1}};        // Rook
    else if (type == 5) dirs = new int[][]{{1,0},{-1,0},{0,1},{0,-1},{1,1},{1,-1},{-1,1},{-1,-1}}; // Queen
    else dirs = new int[][]{{1,0},{-1,0},{0,1},{0,-1},{1,1},{1,-1},{-1,1},{-1,-1}}; // King

    for (int[] d : dirs) {
      for (int dist = 1; dist <= (type == 6 ? 1 : 7); dist++) {
        int nx = x + d[0] * dist;
        int ny = y + d[1] * dist;
        if (nx < 0 || nx > 7 || ny < 0 || ny > 7) break;
        int target = board[ny][nx];
        if (target == 0) {
          legalMoves.add(new int[]{nx, ny});
        } else {
          if (target * color < 0) legalMoves.add(new int[]{nx, ny});
          break;
        }
      }
    }
  }
}

// ------------------------------------------------------------
void makeMove(int x1, int y1, int x2, int y2) {
  board[y2][x2] = board[y1][x1];
  board[y1][x1] = 0;

  // simple promotion
  if (abs(board[y2][x2]) == 1) {
    if (y2 == 0 || y2 == 7) board[y2][x2] = (board[y2][x2] > 0) ? 5 : -5;
  }
}

// ============================================================
//  SIMPLE ENGINE
// ============================================================

void engineMove() {
  int[] best = searchBestMove(engineDepth);
  if (best != null) {
    makeMove(best[0], best[1], best[2], best[3]);
    whiteToMove = true;
  }
}

int[] searchBestMove(int depth) {
  ArrayList<int[]> allMoves = getAllMoves(-1);   // Black moves
  if (allMoves.size() == 0) return null;

  int bestScore = -99999;
  int[] bestMove = allMoves.get(0);

  for (int[] m : allMoves) {
    // make
    int captured = board[m[3]][m[2]];
    board[m[3]][m[2]] = board[m[1]][m[0]];
    board[m[1]][m[0]] = 0;

    int score = -negamax(depth - 1, 1, -99999, 99999);

    // undo
    board[m[1]][m[0]] = board[m[3]][m[2]];
    board[m[3]][m[2]] = captured;

    if (score > bestScore) {
      bestScore = score;
      bestMove = m;
    }
  }
  return bestMove;
}

int negamax(int depth, int color, int alpha, int beta) {
  if (depth == 0) return color * evaluate();

  ArrayList<int[]> moves = getAllMoves(color);
  if (moves.size() == 0) return color * evaluate();   // no check detection yet

  int best = -99999;
  for (int[] m : moves) {
    int captured = board[m[3]][m[2]];
    board[m[3]][m[2]] = board[m[1]][m[0]];
    board[m[1]][m[0]] = 0;

    int score = -negamax(depth - 1, -color, -beta, -alpha);

    board[m[1]][m[0]] = board[m[3]][m[2]];
    board[m[3]][m[2]] = captured;

    if (score > best) best = score;
    if (score > alpha) alpha = score;
    if (alpha >= beta) break;
  }
  return best;
}

ArrayList<int[]> getAllMoves(int color) {
  ArrayList<int[]> list = new ArrayList<int[]>();
  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {
      if (board[y][x] * color > 0) {
        generateLegalMoves(x, y);
        for (int[] m : legalMoves) {
          list.add(new int[]{x, y, m[0], m[1]});
        }
      }
    }
  }
  legalMoves.clear();
  return list;
}

// ------------------------------------------------------------
int evaluate() {
  int score = 0;
  int[] values = {0, 100, 320, 330, 500, 900, 20000};

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {
      int p = board[y][x];
      if (p == 0) continue;
      int v = values[abs(p)];
      if (p > 0) score += v;
      else       score -= v;
    }
  }
  return score;
}

// ------------------------------------------------------------
// Optional: keyboard controls for testing
void keyPressed() {
  if (key == 'e' || key == 'E') engineOn = !engineOn;
  if (key == '+' || key == '=') engineDepth = min(5, engineDepth + 1);
  if (key == '-')              engineDepth = max(1, engineDepth - 1);
  if (key == 'r' || key == 'R') {
    initBoard();
    whiteToMove = true;
    selected = false;
  }
}








*/
















































