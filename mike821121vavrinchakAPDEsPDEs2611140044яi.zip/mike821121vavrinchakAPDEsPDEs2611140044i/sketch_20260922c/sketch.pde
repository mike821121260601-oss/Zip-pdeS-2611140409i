


// ============================================================
// CHESS - APDE 0.5.3
// Android 9
// ONE PDE FILE
// TOUCH ONLY
// ============================================================

String[][] board = new String[8][8];

String turn = "w";

int selectedR = -1;
int selectedC = -1;

int[][] currentMoves = new int[64][2];
int currentMoveCount = 0;

boolean flipped = false;

int enPassant = -1;

boolean promotion = false;
int promotionR = -1;
int promotionC = -1;
String promotionColor = "";

boolean gameOver = false;

ArrayList<String[][]> historyBoard =
  new ArrayList<String[][]>();

ArrayList<String> historyTurn =
  new ArrayList<String>();

ArrayList<Integer> historyEP =
  new ArrayList<Integer>();

ArrayList<String> moveList =
  new ArrayList<String>();

float boardX;
float boardY;
float squareSize;

String message = "";


// ============================================================
// SETUP
// ============================================================

void setup() {

 /// orientation(PORTRAIT);

  size(displayWidth, displayHeight);

  textAlign(CENTER, CENTER);

  squareSize = min(
    width * 0.115,
    height * 0.095
  );

  boardX =
    (width - squareSize * 8) / 2.0;

  boardY = 80;

  startGame();
}


// ============================================================
// DRAW
// ============================================================

void draw() {

  background(35);

  drawTitle();

  drawBoard();

  drawInfo();

  if (promotion) {
    drawPromotion();
  }

  if (gameOver) {
    drawGameOver();
  }
}


// ============================================================
// NEW GAME
// ============================================================

void startGame() {

  board = new String[8][8];

  board[0][0] = "r";
  board[0][1] = "n";
  board[0][2] = "b";
  board[0][3] = "q";
  board[0][4] = "k";
  board[0][5] = "b";
  board[0][6] = "n";
  board[0][7] = "r";

  int c;

  for (c = 0; c < 8; c++) {
    board[1][c] = "p";
  }

  for (int r = 2; r < 6; r++) {

    for (c = 0; c < 8; c++) {
      board[r][c] = null;
    }
  }

  for (c = 0; c < 8; c++) {
    board[6][c] = "P";
  }

  board[7][0] = "R";
  board[7][1] = "N";
  board[7][2] = "B";
  board[7][3] = "Q";
  board[7][4] = "K";
  board[7][5] = "B";
  board[7][6] = "N";
  board[7][7] = "R";

  turn = "w";

  selectedR = -1;
  selectedC = -1;

  currentMoveCount = 0;

  flipped = false;

  enPassant = -1;

  promotion = false;

  gameOver = false;

  historyBoard.clear();
  historyTurn.clear();
  historyEP.clear();

  moveList.clear();

  message = "";
}


// ============================================================
// TITLE
// ============================================================

void drawTitle() {

  fill(255);

  textSize(28);

  text(
    "CHESS",
    width / 2,
    35
  );
}


// ============================================================
// BOARD
// ============================================================

void drawBoard() {

  int r;
  int c;

  for (r = 0; r < 8; r++) {

    for (c = 0; c < 8; c++) {

      int rr;
      int cc;

      if (flipped) {
        rr = 7 - r;
        cc = 7 - c;
      } else {
        rr = r;
        cc = c;
      }

      float x =
        boardX + c * squareSize;

      float y =
        boardY + r * squareSize;

      if ((r + c) % 2 == 0) {
        fill(238);
      } else {
        fill(100);
      }

      noStroke();

      rect(
        x,
        y,
        squareSize,
        squareSize
      );

      // Selected square
      if (rr == selectedR &&
          cc == selectedC) {

        noFill();

        stroke(255, 220, 0);
        strokeWeight(5);

        rect(
          x + 3,
          y + 3,
          squareSize - 6,
          squareSize - 6
        );

        noStroke();
      }

      // Legal move dot
      if (isCurrentMove(rr, cc)) {

        fill(0, 210, 0, 170);

        ellipse(
          x + squareSize / 2,
          y + squareSize / 2,
          squareSize * 0.25,
          squareSize * 0.25
        );
      }

      // Piece
      if (board[rr][cc] != null) {

        drawPiece(
          board[rr][cc],
          x + squareSize / 2,
          y + squareSize / 2
        );
      }
    }
  }

  noFill();

  stroke(0);
  strokeWeight(3);

  rect(
    boardX,
    boardY,
    squareSize * 8,
    squareSize * 8
  );

  noStroke();
}


// ============================================================
// PIECE DRAWING
// ============================================================

void drawPiece(
  String p,
  float x,
  float y) {

  textSize(squareSize * 0.68);

  if (p.equals(p.toUpperCase())) {

    fill(255, 0,0);

    stroke(0);
    strokeWeight(2);

  } else {

    fill(0);

    noStroke();
  }

  text(
    pieceSymbol(p),
    x,
    y
  );

  noStroke();
}


// ============================================================
// PIECE SYMBOL
// ============================================================

String pieceSymbol(String p) {

  if (p.equals("P")) return "♙";
  if (p.equals("R")) return "♖";
  if (p.equals("N")) return "♘";
  if (p.equals("B")) return "♗";
  if (p.equals("Q")) return "♕";
  if (p.equals("K")) return "♔";

  if (p.equals("p")) return "♟";
  if (p.equals("r")) return "♜";
  if (p.equals("n")) return "♞";
  if (p.equals("b")) return "♝";
  if (p.equals("q")) return "♛";
  if (p.equals("k")) return "♚";

  return "";
}


// ============================================================
// TOUCH
// ============================================================

void mousePressed() {

  if (promotion) {

    handlePromotionTouch();

    return;
  }

  if (gameOver) {
    return;
  }

  float buttonsY =
    boardY + squareSize * 8 + 15;

  // Buttons
  if (mouseY >= buttonsY &&
      mouseY <= buttonsY + 55) {

    float w = width / 3.0;

    if (mouseX < w) {

      startGame();

      return;
    }

    if (mouseX < w * 2) {

      undo();

      return;
    }

    flipBoard();

    return;
  }

  // Board
  if (mouseX >= boardX &&
      mouseX < boardX + squareSize * 8 &&
      mouseY >= boardY &&
      mouseY < boardY + squareSize * 8) {

    int c =
      int((mouseX - boardX) / squareSize);

    int r =
      int((mouseY - boardY) / squareSize);

    int rr;
    int cc;

    if (flipped) {

      rr = 7 - r;
      cc = 7 - c;

    } else {

      rr = r;
      cc = c;
    }

    clickSquare(rr, cc);
  }
}


// ============================================================
// SQUARE CLICK
// ============================================================

void clickSquare(int r, int c) {

  if (selectedR != -1) {

    if (isCurrentMove(r, c)) {

      movePiece(
        selectedR,
        selectedC,
        r,
        c
      );

      selectedR = -1;
      selectedC = -1;

      currentMoveCount = 0;

      if (!promotion) {
        checkGameEnd();
      }

      return;
    }

    selectedR = -1;
    selectedC = -1;

    currentMoveCount = 0;

    return;
  }

  String p = board[r][c];

  if (p != null &&
      belongsToTurn(p)) {

    selectedR = r;
    selectedC = c;

    makeLegalMoves(r, c);
  }
}


// ============================================================
// TURN
// ============================================================

boolean belongsToTurn(String p) {

  if (turn.equals("w")) {
    return p.equals(p.toUpperCase());
  }

  return p.equals(p.toLowerCase());
}


// ============================================================
// LEGAL MOVES
// NO switch(String)
// APDE 0.5.3 SAFE
// ============================================================

void makeLegalMoves(int r, int c) {

  currentMoveCount = 0;

  ArrayList<int[]> pseudo =
    generateMoves(r, c);

  for (int i = 0;
       i < pseudo.size();
       i++) {

    int rr = pseudo.get(i)[0];
    int cc = pseudo.get(i)[1];

    String[][] saved =
      copyBoard(board);

    String savedTurn = turn;
    int savedEP = enPassant;

    String p = board[r][c];

    // En passant simulation
    if (p.toLowerCase().equals("p") &&
        enPassant != -1 &&
        cc == enPassant &&
        abs(rr - r) == 1 &&
        board[rr][cc] == null) {

      board[r][cc] = null;
    }

    board[rr][cc] = p;
    board[r][c] = null;

    boolean check =
      isInCheck(savedTurn);

    board = saved;

    turn = savedTurn;
    enPassant = savedEP;

    if (!check) {

      currentMoves[currentMoveCount][0] =
        rr;

      currentMoves[currentMoveCount][1] =
        cc;

      currentMoveCount++;
    }
  }
}


// ============================================================
// GENERATE MOVES
// ============================================================

ArrayList<int[]> generateMoves(
  int r,
  int c) {

  ArrayList<int[]> moves =
    new ArrayList<int[]>();

  String piece = board[r][c];

  if (piece == null) {
    return moves;
  }

  boolean white =
    piece.equals(piece.toUpperCase());

  int dir;

  if (white) {
    dir = -1;
  } else {
    dir = 1;
  }

  String type =
    piece.toLowerCase();


  // ----------------------------------------------------------
  // PAWN
  // ----------------------------------------------------------

  if (type.equals("p")) {

    // Forward one
    if (inside(r + dir, c) &&
        board[r + dir][c] == null) {

      moves.add(new int[] {
        r + dir,
        c
      });
    }

    // Forward two
    if ((white && r == 6) ||
        (!white && r == 1)) {

      if (board[r + dir][c] == null &&
          board[r + dir * 2][c] == null) {

        moves.add(new int[] {
          r + dir * 2,
          c
        });
      }
    }

    // Captures
    int[] dc = {
      -1,
       1
    };

    for (int i = 0; i < 2; i++) {

      int nr = r + dir;
      int nc = c + dc[i];

      if (inside(nr, nc) &&
          board[nr][nc] != null &&
          enemy(piece, board[nr][nc])) {

        moves.add(new int[] {
          nr,
          nc
        });
      }
    }

    // En passant
    if (enPassant != -1 &&
        abs(c - enPassant) == 1 &&
        ((white && r == 3) ||
         (!white && r == 4))) {

      moves.add(new int[] {
        r + dir,
        enPassant
      });
    }
  }


  // ----------------------------------------------------------
  // ROOK
  // ----------------------------------------------------------

  else if (type.equals("r")) {

    lineMoves(
      moves,
      r,
      c,
      new int[][] {
        {1, 0},
        {-1, 0},
        {0, 1},
        {0, -1}
      }
    );
  }


  // ----------------------------------------------------------
  // KNIGHT
  // ----------------------------------------------------------

  else if (type.equals("n")) {

    int[][] knight = {
      {2, 1},
      {2, -1},
      {-2, 1},
      {-2, -1},
      {1, 2},
      {1, -2},
      {-1, 2},
      {-1, -2}
    };

    for (int i = 0;
         i < knight.length;
         i++) {

      addIf(
        moves,
        r + knight[i][0],
        c + knight[i][1],
        piece
      );
    }
  }


  // ----------------------------------------------------------
  // BISHOP
  // ----------------------------------------------------------

  else if (type.equals("b")) {

    lineMoves(
      moves,
      r,
      c,
      new int[][] {
        {1, 1},
        {1, -1},
        {-1, 1},
        {-1, -1}
      }
    );
  }


  // ----------------------------------------------------------
  // QUEEN
  // ----------------------------------------------------------

  else if (type.equals("q")) {

    lineMoves(
      moves,
      r,
      c,
      new int[][] {
        {1, 0},
        {-1, 0},
        {0, 1},
        {0, -1},
        {1, 1},
        {1, -1},
        {-1, 1},
        {-1, -1}
      }
    );
  }


  // ----------------------------------------------------------
  // KING
  // ----------------------------------------------------------

  else if (type.equals("k")) {

    int[][] king = {
      {1, 0},
      {-1, 0},
      {0, 1},
      {0, -1},
      {1, 1},
      {1, -1},
      {-1, 1},
      {-1, -1}
    };

    for (int i = 0;
         i < king.length;
         i++) {

      addIf(
        moves,
        r + king[i][0],
        c + king[i][1],
        piece
      );
    }
  }

  return moves;
}


// ============================================================
// LINE MOVES
// ============================================================

void lineMoves(
  ArrayList<int[]> moves,
  int r,
  int c,
  int[][] dirs) {

  String piece = board[r][c];

  for (int d = 0;
       d < dirs.length;
       d++) {

    int rr =
      r + dirs[d][0];

    int cc =
      c + dirs[d][1];

    while (inside(rr, cc)) {

      if (board[rr][cc] == null) {

        moves.add(new int[] {
          rr,
          cc
        });

      } else {

        if (enemy(
          piece,
          board[rr][cc])) {

          moves.add(new int[] {
            rr,
            cc
          });
        }

        break;
      }

      rr += dirs[d][0];
      cc += dirs[d][1];
    }
  }
}


// ============================================================
// ADD MOVE
// ============================================================

void addIf(
  ArrayList<int[]> moves,
  int r,
  int c,
  String piece) {

  if (!inside(r, c)) {
    return;
  }

  if (board[r][c] == null) {

    moves.add(new int[] {
      r,
      c
    });

  } else if (enemy(
    piece,
    board[r][c])) {

    moves.add(new int[] {
      r,
      c
    });
  }
}


// ============================================================
// ENEMY
// ============================================================

boolean enemy(
  String a,
  String b) {

  boolean aw =
    a.equals(a.toUpperCase());

  boolean bw =
    b.equals(b.toUpperCase());

  return aw != bw;
}


// ============================================================
// INSIDE
// ============================================================

boolean inside(
  int r,
  int c) {

  return r >= 0 &&
         r < 8 &&
         c >= 0 &&
         c < 8;
}


// ============================================================
// MOVE PIECE
// ============================================================

void movePiece(
  int r1,
  int c1,
  int r2,
  int c2) {

  String piece =
    board[r1][c1];

  if (piece == null) {
    return;
  }

  // Save
  historyBoard.add(
    copyBoard(board)
  );

  historyTurn.add(turn);

  historyEP.add(enPassant);


  // En passant capture
  if (piece.toLowerCase().equals("p") &&
      enPassant != -1 &&
      c2 == enPassant &&
      abs(r2 - r1) == 1 &&
      board[r2][c2] == null) {

    board[r1][c2] = null;
  }


  // En passant target
  if (piece.toLowerCase().equals("p") &&
      abs(r2 - r1) == 2) {

    enPassant = c1;

  } else {

    enPassant = -1;
  }


  // Move
  board[r2][c2] = piece;
  board[r1][c1] = null;


  // Promotion
  if (piece.equals("P") &&
      r2 == 0) {

    promotion = true;

    promotionR = r2;
    promotionC = c2;

    promotionColor = "w";

  } else if (
    piece.equals("p") &&
    r2 == 7) {

    promotion = true;

    promotionR = r2;
    promotionC = c2;

    promotionColor = "b";
  }


  // Change turn
  if (turn.equals("w")) {
    turn = "b";
  } else {
    turn = "w";
  }


  logMove(
    piece,
    r1,
    c1,
    r2,
    c2
  );
}


// ============================================================
// PROMOTION
// ============================================================

void drawPromotion() {

  fill(0, 190);

  rect(
    0,
    0,
    width,
    height
  );

  fill(255);

  rect(
    width * 0.08,
    height * 0.35,
    width * 0.84,
    height * 0.30
  );

  fill(0);

  textSize(24);

  text(
    "PROMOTE PAWN",
    width / 2,
    height * 0.40
  );

  textSize(18);

  text(
    "QUEEN   ROOK   BISHOP   KNIGHT",
    width / 2,
    height * 0.46
  );

  float y =
    height * 0.55;

  drawButton(
    width * 0.10,
    y,
    width * 0.38,
    55,
    "QUEEN"
  );

  drawButton(
    width * 0.52,
    y,
    width * 0.38,
    55,
    "ROOK"
  );

  drawButton(
    width * 0.10,
    y + 70,
    width * 0.38,
    55,
    "BISHOP"
  );

  drawButton(
    width * 0.52,
    y + 70,
    width * 0.38,
    55,
    "KNIGHT"
  );
}


// ============================================================
// PROMOTION TOUCH
// ============================================================

void handlePromotionTouch() {

  float y =
    height * 0.55;

  if (mouseY >= y &&
      mouseY < y + 55) {

    if (mouseX < width / 2) {
      promote("Q");
    } else {
      promote("R");
    }

    return;
  }

  if (mouseY >= y + 70 &&
      mouseY < y + 125) {

    if (mouseX < width / 2) {
      promote("B");
    } else {
      promote("N");
    }
  }
}


// ============================================================
// PROMOTE
// ============================================================

void promote(String type) {

  if (!promotion) {
    return;
  }

  if (promotionColor.equals("w")) {

    board[promotionR][promotionC] =
      type;

  } else {

    board[promotionR][promotionC] =
      type.toLowerCase();
  }

  promotion = false;

  promotionR = -1;
  promotionC = -1;
  promotionColor = "";

  checkGameEnd();
}


// ============================================================
// CHECK
// ============================================================

boolean isInCheck(String color) {

  String king;

  if (color.equals("w")) {
    king = "K";
  } else {
    king = "k";
  }

  int kr = -1;
  int kc = -1;

  for (int r = 0; r < 8; r++) {

    for (int c = 0; c < 8; c++) {

      if (board[r][c] != null &&
          board[r][c].equals(king)) {

        kr = r;
        kc = c;
      }
    }
  }

  if (kr == -1) {
    return true;
  }

  for (int r = 0; r < 8; r++) {

    for (int c = 0; c < 8; c++) {

      String p = board[r][c];

      if (p != null &&
          enemyForColor(color, p)) {

        ArrayList<int[]> moves =
          generateMoves(r, c);

        for (int i = 0;
             i < moves.size();
             i++) {

          if (moves.get(i)[0] == kr &&
              moves.get(i)[1] == kc) {

            return true;
          }
        }
      }
    }
  }

  return false;
}


// ============================================================
// ENEMY FOR COLOR
// ============================================================

boolean enemyForColor(
  String color,
  String p) {

  if (color.equals("w")) {

    return p.equals(
      p.toLowerCase()
    );
  }

  return p.equals(
    p.toUpperCase()
  );
}


// ============================================================
// CHECKMATE / STALEMATE
// ============================================================

void checkGameEnd() {

  boolean hasMove = false;

  for (int r = 0; r < 8; r++) {

    for (int c = 0; c < 8; c++) {

      String p = board[r][c];

      if (p != null &&
          belongsToTurn(p)) {

        makeLegalMoves(r, c);

        if (currentMoveCount > 0) {

          hasMove = true;
          break;
        }
      }
    }

    if (hasMove) {
      break;
    }
  }

  currentMoveCount = 0;

  if (!hasMove) {

    if (isInCheck(turn)) {

      if (turn.equals("w")) {

        message =
          "CHECKMATE - BLACK WINS";

      } else {

        message =
          "CHECKMATE - WHITE WINS";
      }

    } else {

      message = "STALEMATE";
    }

    gameOver = true;
  }
}


// ============================================================
// UNDO
// ============================================================

void undo() {

  if (historyBoard.size() <= 0) {
    return;
  }

  int last =
    historyBoard.size() - 1;

  board =
    copyBoard(
      historyBoard.get(last)
    );

  turn =
    historyTurn.get(last);

  enPassant =
    historyEP.get(last);

  historyBoard.remove(last);
  historyTurn.remove(last);
  historyEP.remove(last);

  if (moveList.size() > 0) {

    moveList.remove(
      moveList.size() - 1
    );
  }

  selectedR = -1;
  selectedC = -1;

  currentMoveCount = 0;

  promotion = false;

  gameOver = false;

  message = "";
}


// ============================================================
// FLIP
// ============================================================

void flipBoard() {

  flipped = !flipped;
}


// ============================================================
// MOVE LOG
// ============================================================

void logMove(
  String piece,
  int r1,
  int c1,
  int r2,
  int c2) {

  String columns =
    "abcdefgh";

  String rows =
    "87654321";

  String move =
    piece +
    "" + columns.charAt(c1) +
    "" + rows.charAt(r1) +
    "-" +
    "" + columns.charAt(c2) +
    "" + rows.charAt(r2);

  moveList.add(move);
}


// ============================================================
// INFO
// ============================================================

void drawInfo() {

  float y =
    boardY +
    squareSize * 8 +
    15;

  drawButton(
    0,
    y,
    width / 3.0,
    55,
    "NEW"
  );

  drawButton(
    width / 3.0,
    y,
    width / 3.0,
    55,
    "UNDO"
  );

  drawButton(
    width * 2.0 / 3.0,
    y,
    width / 3.0,
    55,
    "FLIP"
  );

  fill(255);

  textSize(20);

  if (turn.equals("w")) {

    text(
      "WHITE TURN",
      width / 2,
      y + 85
    );

  } else {

    text(
      "BLACK TURN",
      width / 2,
      y + 85
    );
  }

  if (message.length() > 0) {

    fill(255, 220, 0);

    textSize(21);

    text(
      message,
      width / 2,
      y + 120
    );
  }

  drawMoves();
}


// ============================================================
// BUTTON
// ============================================================

void drawButton(
  float x,
  float y,
  float w,
  float h,
  String label) {

  fill(55);

  rect(
    x + 2,
    y + 2,
    w - 4,
    h - 4
  );

  fill(255);

  textSize(16);

  text(
    label,
    x + w / 2,
    y + h / 2
  );
}


// ============================================================
// MOVE LIST
// ============================================================

void drawMoves() {

  float y =
    boardY +
    squareSize * 8 +
    185;

  fill(255);

  textSize(14);

  int maxShow = 7;

  int first =
    max(
      0,
      moveList.size() - maxShow
    );

  for (int i = first;
       i < moveList.size();
       i++) {

    text(
      "" + (i + 1) +
      ". " +
      moveList.get(i),
      width / 2,
      y
    );

    y += 19;
  }
}


// ============================================================
// GAME OVER
// ============================================================

void drawGameOver() {

  fill(0, 160);

  rect(
    0,
    0,
    width,
    height
  );

  fill(255);

  textSize(28);

  text(
    message,
    width / 2,
    height / 2 - 30
  );

  textSize(18);

  text(
    "Press NEW",
    width / 2,
    height / 2 + 20
  );
}


// ============================================================
// CURRENT MOVE
// ============================================================

boolean isCurrentMove(
  int r,
  int c) {

  for (int i = 0;
       i < currentMoveCount;
       i++) {

    if (currentMoves[i][0] == r &&
        currentMoves[i][1] == c) {

      return true;
    }
  }

  return false;
}


// ============================================================
// COPY BOARD
// ============================================================

String[][] copyBoard(
  String[][] src) {

  String[][] dst =
    new String[8][8];

  for (int r = 0; r < 8; r++) {

    for (int c = 0; c < 8; c++) {

      dst[r][c] =
        src[r][c];
    }
  }

  return dst;
}















































