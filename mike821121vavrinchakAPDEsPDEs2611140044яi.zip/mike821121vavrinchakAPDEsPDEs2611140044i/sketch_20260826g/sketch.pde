















//////2D FIGHTING RANDOM ENGEENES2////////


void settings() {
size(displayWidth, displayHeight, P3D) ;   } 
void setup () {
size(displayWidth, displayHeight, P3D) ; 



oo=width/3; cc=width*2/3;
o=(float) (height*0.9) ;
c=(float) (height*0.9) ;
oi=0;ci=0;
 aa=width/3; bb=width*2/3;
a=(float) (height/3*0.9) ;
b=(float) (height/3*0.9) ;
ai=0;bi=0;

 ee=width/3; gg=width*2/3;
e=(float) (height*2/3*0.9) ;
g=(float) (height*2/3*0.9) ;
ei=0;gi=0;


  } 
float [] result;float [] re;


float oo=width/3, cc=width*2/3, 
o=(float) (height*0.9) ,
c=(float) (height*0.9) , 
oi=0,ci=0;

float aa=width/3, bb=width*2/3, 
a=(float) (height/3*0.9) ,
b=(float) (height/3*0.9) , 
ai=0,bi=0;

float ee=width/3, gg=width*2/3, 
e=(float) (height*2/3*0.9) ,
g=(float) (height*2/3*0.9) , 
ei=0,gi=0;


///O-E-C///O-E-C///O-E-C///O-E-C////


void iam() { result[0]=0.0;} 



void u(float uoo, float uo, float uoi) {

rr(uoo-, uo, uoo+22,uo+22,222,22,22);





} 
























void rr(float a, float b,float  c,
float d, float e, float f, float g ) { 
rectMode(CORNERS) ;
fill(e, f, g) ;
rect(a, b, c, d) ;   } ;


void r(float a, float b,float  c,
float d ) { rectMode(CORNERS) ;
rect(a, b, c, d) ;   } ;


void rf(float e, float f, float g ) { 
fill(e, f, g) ;     } ;

void error(             ) {           } 

float w, h;float wh, wh2, wh0005;
void draw() {noStroke() ;
w=width;h=height;
w=displayWidth; h=displayHeight;
point(1,1);fill(211-55,222-55,255-55);
rect(-1,-1,width+1,height+1);
rf(255,122,22);
  
    r(0,h/3-h*0.01,w,h/3+h*0.01);
    r(0,h*2/3-h*0.01,w,h/3*2+0.01*h);
r(0,h-h*0.01,w,h+0.01);





u(oo+33, o, 0);

























}  ////////void draw() {point(0,0);  } //////









































