


// APDE / Processing
// 3D MAN FACE MADE FROM LINES

float rotY = 0;
float rotX = 0;

void setup() {
  fullScreen(P3D);
  orientation(PORTRAIT);
  strokeWeight(2);
}

void draw() {
  background(0);

  translate(width/2, height/2, 0);

  // Slowly rotate the 3D face
  rotateX(rotX);
  rotateY(rotY);
  rotY += 0.008;

  stroke(255);
  noFill();

  // HEAD
  faceOval(0, 0, 0, 230, 300, 60);

  // EARS
  ear(-125, 5, 0);
  ear(125, 5, 0);

  // EYES
  eye(-55, -45, 45);
  eye(55, -45, 45);

  // EYEBROWS
  line3D(-90, -80, 35, -25, -90, 45);
  line3D(25, -90, 45, 90, -80, 35);

  // NOSE
  line3D(0, -55, 55, -12, 15, 75);
  line3D(-12, 15, 75, 0, 38, 65);
  line3D(0, 38, 65, 15, 15, 75);

  // NOSE BOTTOM
  line3D(-25, 35, 55, 0, 45, 65);
  line3D(0, 45, 65, 25, 35, 55);

  // MOUTH
  mouth();

  // CHIN
  line3D(-55, 95, 35, 0, 115, 45);
  line3D(0, 115, 45, 55, 95, 35);

  // CHEEK LINES
  line3D(-105, 10, 20, -80, 55, 35);
  line3D(105, 10, 20, 80, 55, 35);

  // FOREHEAD LINES
  line3D(-80, -125, 10, -25, -145, 30);
  line3D(25, -145, 30, 80, -125, 10);

  // RANDOM 3D FACE DETAIL LINES
  randomFaceLines(180);
}

// ----------------------------

void faceOval(float x, float y, float z,
              float w, float h, float depth) {

  int N = 80;

  for (int i=0; i<N; i++) {

    float a1 = TWO_PI * i / N;
    float a2 = TWO_PI * (i+1) / N;

    float x1 = x + cos(a1) * w/2;
    float y1 = y + sin(a1) * h/2;
    float z1 = z + cos(a1) * depth/2;

    float x2 = x + cos(a2) * w/2;
    float y2 = y + sin(a2) * h/2;
    float z2 = z + cos(a2) * depth/2;

    line3D(x1,y1,z1,x2,y2,z2);
  }
}

// ----------------------------

void eye(float x, float y, float z) {

  int N = 24;

  for (int i=0; i<N; i++) {

    float a1 = TWO_PI*i/N;
    float a2 = TWO_PI*(i+1)/N;

    line3D(
      x + cos(a1)*32,
      y + sin(a1)*14,
      z + cos(a1)*8,

      x + cos(a2)*32,
      y + sin(a2)*14,
      z + cos(a2)*8
    );
  }

  // pupil
  line3D(x-8,y,z+10,x+8,y,z+10);
  line3D(x,y-8,z+10,x,y+8,z+10);
}

// ----------------------------

void ear(float x, float y, float z) {

  line3D(x, y-55, z, x+(x<0?-30:30), y-25, z);
  line3D(x+(x<0?-30:30), y-25, z,
         x+(x<0?-25:25), y+25, z);
  line3D(x+(x<0?-25:25), y+25, z,
         x, y+55, z);
}

// ----------------------------

void mouth() {

  line3D(-55, 65, 45, -25, 60, 60);
  line3D(-25, 60, 60, 0, 65, 65);
  line3D(0, 65, 65, 25, 60, 60);
  line3D(25, 60, 60, 55, 65, 45);

  // lower mouth
  line3D(-45, 70, 42, 0, 82, 55);
  line3D(0, 82, 55, 45, 70, 42);
}

// ----------------------------

void randomFaceLines(int amount) {

  randomSeed(12345);

  for (int i=0; i<amount; i++) {

    float a = random(-PI, PI);
    float b = random(-HALF_PI, HALF_PI);

    float r1 = random(80,145);
    float r2 = r1 + random(5,25);

    float x1 = cos(a)*r1;
    float y1 = sin(b)*r1*1.1;
    float z1 = 40 + random(-25,25);

    float x2 = cos(a)*r2;
    float y2 = sin(b)*r2*1.1;
    float z2 = z1 + random(-15,15);

    // Only keep approximate face area
    if (abs(x1) < 115 && abs(y1) < 150) {
      line3D(x1,y1,z1,x2,y2,z2);
    }
  }
}

// ----------------------------

void line3D(float x1,float y1,float z1,
            float x2,float y2,float z2) {

  line(x1,y1,z1,x2,y2,z2);
}

// TOUCH / DRAG ROTATION
float oldX, oldY;

void touchStarted() {
  oldX = mouseX;
  oldY = mouseY;
}

void touchMoved() {

  rotY += (mouseX-oldX)*0.01;
  rotX += (mouseY-oldY)*0.01;

  oldX = mouseX;
  oldY = mouseY;
}

























