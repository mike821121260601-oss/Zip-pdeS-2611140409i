

// ============================================================
// APDE 3D LINE MOUNTAIN LANDSCAPE
// 30 x 30 MOUNTAINS
// WORLD: -30000 ... +30000
// EACH MOUNTAIN: 10000 3D LINES
// EACH LINE: EXACTLY 10 ROUND POINTS
//
// APDE / PROCESSING
// P3D
// LANDSCAPE
// ============================================================

float WORLD_MIN = -30000 /10/10;
float WORLD_MAX =  30000  /10/10;

int MOUNTAINS_X = 30;
int MOUNTAINS_Z = 30;

int LINES_PER_MOUNTAIN = 10000/100;
int POINTS_PER_LINE = 10;

// Draw only mountains close to camera.
// Increase to 4 or 5 if the phone is fast.
int VISIBLE_RADIUS = 2;

float MOUNTAIN_SIZE = 1900;
float MOUNTAIN_HEIGHT = 2500;

// Camera
float camX = 0;
float camY = -900;
float camZ = 0;

float yaw = 0;
float pitch = -0.12;

float moveSpeed = 18;

// Touch rotation
float lastTouchX;
float lastTouchY;

boolean touching = false;

boolean moveForward = false;
boolean moveBack = false;
boolean moveLeft = false;
boolean moveRight = false;
boolean moveUp = false;
boolean moveDown = false;

boolean autoFly = false;

float autoYawSpeed = 0.0015;
float autoPitchSpeed = 0.0007;

float autoMoveSpeed = 8;

// UI
float buttonSize;

// ============================================================
// SETTINGS
// ============================================================

void settings() {
  size(displayWidth, displayHeight, P3D);
}


// ============================================================
// SETUP
// ============================================================

void setup() {

  ///orientation(LANDSCAPE);

  frameRate(30);

  smooth(2);

  strokeWeight(1);

  buttonSize = min(width, height) * 0.11;

  camX = 0;
  camY = -700;
  camZ = 0;

  yaw = 0;
  pitch = -0.08;

  println("=================================");
  println("3D LINE MOUNTAIN LANDSCAPE");
  println("MOUNTAINS: " + MOUNTAINS_X + " x " + MOUNTAINS_Z);
  println("LINES / MOUNTAIN: " + LINES_PER_MOUNTAIN);
  println("POINTS / LINE: " + POINTS_PER_LINE);
  println("WORLD: " + WORLD_MIN + " ... " + WORLD_MAX);
  println("=================================");
}


// ============================================================
// DRAW
// ============================================================

void draw() {

  background(5, 8, 15);

  updateCamera();

  setupCamera();

  drawLandscape();

  drawHUD();
}


// ============================================================
// CAMERA
// ============================================================

void setupCamera() {

  float lookDistance = 1000;

  float lx = camX + sin(yaw) * cos(pitch) * lookDistance;
  float ly = camY + sin(pitch) * lookDistance;
  float lz = camZ + cos(yaw) * cos(pitch) * lookDistance;

  camera(
    camX, camY, camZ,
    lx, ly, lz,
    0, 1, 0
    );
}


// ============================================================
// CAMERA UPDATE
// ============================================================

void updateCamera() {

  if (autoFly) {

    yaw += autoYawSpeed;
    pitch += sin(frameCount * 0.01) * autoPitchSpeed;

    float dx = sin(yaw);
    float dz = cos(yaw);

    camX += dx * autoMoveSpeed;
    camZ += dz * autoMoveSpeed;

    camY += sin(frameCount * 0.007) * 1.5;
  }

  float dx = sin(yaw);
  float dz = cos(yaw);

  float sideX = cos(yaw);
  float sideZ = -sin(yaw);

  if (moveForward) {
    camX += dx * moveSpeed;
    camZ += dz * moveSpeed;
  }

  if (moveBack) {
    camX -= dx * moveSpeed;
    camZ -= dz * moveSpeed;
  }

  if (moveLeft) {
    camX -= sideX * moveSpeed;
    camZ -= sideZ * moveSpeed;
  }

  if (moveRight) {
    camX += sideX * moveSpeed;
    camZ += sideZ * moveSpeed;
  }

  if (moveUp) {
    camY -= moveSpeed;
  }

  if (moveDown) {
    camY += moveSpeed;
  }

  // Keep camera inside the giant landscape
  camX = constrain(camX, WORLD_MIN, WORLD_MAX);
  camZ = constrain(camZ, WORLD_MIN, WORLD_MAX);

  camY = constrain(camY, -5000, 5000);
}


// ============================================================
// LANDSCAPE
// ============================================================

void drawLandscape() {

  int centerX = worldMountainX(camX);
  int centerZ = worldMountainZ(camZ);

  int minX = max(0, centerX - VISIBLE_RADIUS);
  int maxX = min(MOUNTAINS_X - 1, centerX + VISIBLE_RADIUS);

  int minZ = max(0, centerZ - VISIBLE_RADIUS);
  int maxZ = min(MOUNTAINS_Z - 1, centerZ + VISIBLE_RADIUS);

  for (int mz = minZ; mz <= maxZ; mz++) {

    for (int mx = minX; mx <= maxX; mx++) {

      drawMountain(mx, mz);
    }
  }
}


// ============================================================
// MOUNTAIN
// ============================================================

void drawMountain(int mx, int mz) {

  float baseX = map(
    mx,
    0,
    MOUNTAINS_X - 1,
    WORLD_MIN,
    WORLD_MAX
    );

  float baseZ = map(
    mz,
    0,
    MOUNTAINS_Z - 1,
    WORLD_MIN,
    WORLD_MAX
    );

  // Distance from camera
  float ddx = baseX - camX;
  float ddz = baseZ - camZ;

  float dist = sqrt(ddx * ddx + ddz * ddz);

  if (dist > (VISIBLE_RADIUS + 1) * MOUNTAIN_SIZE * 1.7) {
    return;
  }

  // Every mountain has its own deterministic random seed.
  // Therefore lines do not change every frame.
  long seedValue =
    1234567L +
    (long)mx * 100003L +
    (long)mz * 700001L;

  randomSeed((int)(seedValue & 0x7fffffff));

  // Different line groups make different parts of mountain.
  for (int i = 0; i < LINES_PER_MOUNTAIN; i++) {

    draw3DLine(
      baseX,
      baseZ,
      i
      );
  }
}


// ============================================================
// ONE 3D LINE
//
// EXACTLY 10 POINTS
// ROUND POINTS
// BEGINSHAPE/VERTEX USED
// NOT Processing line()
// ============================================================

void draw3DLine(
  float baseX,
  float baseZ,
  int lineNumber
  ) {

  // Random center of this line
  float angle = random(TWO_PI);

  float radius = pow(random(1), 0.55) *
                 MOUNTAIN_SIZE * 0.50;

  float cx = baseX + cos(angle) * radius;
  float cz = baseZ + sin(angle) * radius;

  // Mountain height depends on distance from mountain center.
  float centerDistance =
    dist(cx, cz, baseX, baseZ);

  float shape =
    max(
      0,
      1.0 - centerDistance / (MOUNTAIN_SIZE * 0.55)
      );

  float lineHeight =
    shape * MOUNTAIN_HEIGHT;

  // Random direction of the line in 3D
  float a = random(TWO_PI);

  float horizontalLength =
    random(80, 600);

  float verticalLength =
    random(-350, 350);

  float dx =
    cos(a) * horizontalLength;

  float dz =
    sin(a) * horizontalLength;

  float dy =
    verticalLength;

  // Randomly rotate line around X/Y/Z
  float rotX = random(-0.5, 0.5);
  float rotY = random(TWO_PI);
  float rotZ = random(-0.5, 0.5);

  // Line visual brightness
  float brightness =
    map(shape, 0, 1, 70, 220);

  stroke(
    brightness,
    brightness,
    brightness * 1.05,
    190
    );

  noFill();

  // ==========================================================
  // EXACTLY 10 POINTS
  // ==========================================================

  beginShape();

  for (int p = 0; p < POINTS_PER_LINE; p++) {

    float t =
      p / float(POINTS_PER_LINE - 1);

    // Rounded/random movement along line
    float wave1 =
      sin(t * PI * 2.0 + lineNumber * 0.13) *
      random(2, 20);

    float wave2 =
      cos(t * PI * 3.0 + lineNumber * 0.07) *
      random(2, 20);

    float x =
      cx +
      dx * (t - 0.5) +
      wave1;

    float y =
      -lineHeight +
      dy * (t - 0.5) +
      wave2;

    float z =
      cz +
      dz * (t - 0.5);

    // ========================================================
    // 3D RANDOM ROTATION
    // ========================================================

    float xx = x - cx;
    float yy = y + lineHeight;
    float zz = z - cz;

    // Rotation Y
    float x1 =
      xx * cos(rotY) -
      zz * sin(rotY);

    float z1 =
      xx * sin(rotY) +
      zz * cos(rotY);

    xx = x1;
    zz = z1;

    // Rotation X
    float y1 =
      yy * cos(rotX) -
      zz * sin(rotX);

    z1 =
      yy * sin(rotX) +
      zz * cos(rotX);

    yy = y1;
    zz = z1;

    // Rotation Z
    x1 =
      xx * cos(rotZ) -
      yy * sin(rotZ);

    y1 =
      xx * sin(rotZ) +
      yy * cos(rotZ);

    xx = x1;
    yy = y1;

    x = cx + xx;
    y = -lineHeight + yy;
    z = cz + zz;

    vertex(x, y, z);
  }

  endShape();
}


// ============================================================
// WORLD MOUNTAIN INDEX
// ============================================================

int worldMountainX(float x) {

  float n =
    map(
      x,
      WORLD_MIN,
      WORLD_MAX,
      0,
      MOUNTAINS_X - 1
      );

  return constrain(
    floor(n),
    0,
    MOUNTAINS_X - 1
    );
}


int worldMountainZ(float z) {

  float n =
    map(
      z,
      WORLD_MIN,
      WORLD_MAX,
      0,
      MOUNTAINS_Z - 1
      );

  return constrain(
    floor(n),
    0,
    MOUNTAINS_Z - 1
    );
}


// ============================================================
// TOUCH
// ============================================================

void touchStarted() {

  touching = true;

  lastTouchX = mouseX;
  lastTouchY = mouseY;

  // Check UI buttons
  if (checkButton(mouseX, mouseY,
                  width * 0.50,
                  height - buttonSize * 0.65,
                  buttonSize)) {

    moveForward = true;
    return;
  }

  if (checkButton(mouseX, mouseY,
                  width * 0.50,
                  height - buttonSize * 1.75,
                  buttonSize)) {

    moveBack = true;
    return;
  }

  if (checkButton(mouseX, mouseY,
                  width * 0.30,
                  height - buttonSize * 0.65,
                  buttonSize)) {

    moveLeft = true;
    return;
  }

  if (checkButton(mouseX, mouseY,
                  width * 0.70,
                  height - buttonSize * 0.65,
                  buttonSize)) {

    moveRight = true;
    return;
  }

  if (checkButton(mouseX, mouseY,
                  width * 0.82,
                  height - buttonSize * 1.75,
                  buttonSize)) {

    moveUp = true;
    return;
  }

  if (checkButton(mouseX, mouseY,
                  width * 0.82,
                  height - buttonSize * 0.65,
                  buttonSize)) {

    moveDown = true;
    return;
  }

  // AUTO button
  if (mouseX > width * 0.88 &&
      mouseY < buttonSize * 1.2) {

    autoFly = !autoFly;
    return;
  }

  // Speed +
  if (mouseX < buttonSize * 1.3 &&
      mouseY < buttonSize * 1.2) {

    moveSpeed *= 1.5;
    moveSpeed = min(moveSpeed, 500);
    return;
  }

  // Speed -
  if (mouseX < buttonSize * 2.6 &&
      mouseY < buttonSize * 1.2) {

    moveSpeed *= 0.67;
    moveSpeed = max(moveSpeed, 1);
    return;
  }
}


// ============================================================
// TOUCH DRAG
//
// Drag anywhere not occupied by movement buttons:
// horizontal = yaw
// vertical = pitch
// ============================================================

void touchMoved() {

  if (!touching) return;

  float dx = mouseX - lastTouchX;
  float dy = mouseY - lastTouchY;

  boolean onMovementButton =
    mouseY > height - buttonSize * 2.4;

  if (!onMovementButton) {

    yaw += dx * 0.008;

    pitch += dy * 0.006;

    pitch = constrain(
      pitch,
      -PI * 0.49,
      PI * 0.49
      );
  }

  lastTouchX = mouseX;
  lastTouchY = mouseY;
}


// ============================================================
// TOUCH END
// ============================================================

void touchEnded() {

  touching = false;

  moveForward = false;
  moveBack = false;
  moveLeft = false;
  moveRight = false;
  moveUp = false;
  moveDown = false;
}


// ============================================================
// BUTTON HIT TEST
// ============================================================

boolean checkButton(
  float x,
  float y,
  float bx,
  float by,
  float sizeB
  ) {

  return
    abs(x - bx) < sizeB * 0.5 &&
    abs(y - by) < sizeB * 0.5;
}


// ============================================================
// HUD
// ============================================================

void drawHUD() {

  hint(DISABLE_DEPTH_TEST);

  camera();

  noStroke();

  // Semi-transparent button backgrounds
  fill(0, 0, 0, 120);

  rectMode(CENTER);

  // LEFT
  rect(
    width * 0.30,
    height - buttonSize * 0.65,
    buttonSize,
    buttonSize
    );

  // RIGHT
  rect(
    width * 0.70,
    height - buttonSize * 0.65,
    buttonSize,
    buttonSize
    );

  // FORWARD
  rect(
    width * 0.50,
    height - buttonSize * 0.65,
    buttonSize,
    buttonSize
    );

  // BACK
  rect(
    width * 0.50,
    height - buttonSize * 1.75,
    buttonSize,
    buttonSize
    );

  // UP
  rect(
    width * 0.82,
    height - buttonSize * 1.75,
    buttonSize,
    buttonSize
    );

  // DOWN
  rect(
    width * 0.82,
    height - buttonSize * 0.65,
    buttonSize,
    buttonSize
    );

  // AUTO
  rect(
    width * 0.93,
    buttonSize * 0.55,
    buttonSize * 1.2,
    buttonSize * 0.7
    );

  // SPEED
  rect(
    buttonSize * 0.65,
    buttonSize * 0.55,
    buttonSize,
    buttonSize * 0.7
    );

  rect(
    buttonSize * 1.8,
    buttonSize * 0.55,
    buttonSize,
    buttonSize * 0.7
    );

  fill(255);

  textAlign(CENTER, CENTER);

  textSize(buttonSize * 0.35);

  text(
    "LEFT",
    width * 0.30,
    height - buttonSize * 0.65
    );

  text(
    "RIGHT",
    width * 0.70,
    height - buttonSize * 0.65
    );

  text(
    "UP",
    width * 0.50,
    height - buttonSize * 0.65
    );

  text(
    "BACK",
    width * 0.50,
    height - buttonSize * 1.75
    );

  text(
    "▲",
    width * 0.82,
    height - buttonSize * 1.75
    );

  text(
    "▼",
    width * 0.82,
    height - buttonSize * 0.65
    );

  text(
    "AUTO",
    width * 0.93,
    buttonSize * 0.55
    );

  text(
    "+",
    buttonSize * 0.65,
    buttonSize * 0.55
    );

  text(
    "-",
    buttonSize * 1.8,
    buttonSize * 0.55
    );

  // Camera information
  textAlign(LEFT, TOP);

  textSize(18);

  text(
    "X " + nf(camX, 0, 0) +
    "  Y " + nf(camY, 0, 0) +
    "  Z " + nf(camZ, 0, 0),
    15,
    15
    );

  text(
    "LINES/MOUNTAIN: " +
    LINES_PER_MOUNTAIN +
    "   POINTS/LINE: " +
    POINTS_PER_LINE,
    15,
    40
    );

  text(
    "SPEED: " + nf(moveSpeed, 0, 1),
    15,
    65
    );

  if (autoFly) {

    text(
      "RANDOM 3D FLIGHT",
      15,
      90
      );
  }

  hint(ENABLE_DEPTH_TEST);
}


// ============================================================
// OPTIONAL KEYBOARD CONTROLS
// Useful when testing with keyboard.
// ============================================================

void keyPressed() {

  if (key == 'w' || key == 'W')
    moveForward = true;

  if (key == 's' || key == 'S')
    moveBack = true;

  if (key == 'a' || key == 'A')
    moveLeft = true;

  if (key == 'd' || key == 'D')
    moveRight = true;

  if (key == 'q' || key == 'Q')
    moveUp = true;

  if (key == 'e' || key == 'E')
    moveDown = true;

  if (key == 'r' || key == 'R')
    autoFly = !autoFly;

  if (key == '+')
    moveSpeed *= 1.5;

  if (key == '-')
    moveSpeed *= 0.67;
}


void keyReleased() {

  if (key == 'w' || key == 'W')
    moveForward = false;

  if (key == 's' || key == 'S')
    moveBack = false;

  if (key == 'a' || key == 'A')
    moveLeft = false;

  if (key == 'd' || key == 'D')
    moveRight = false;

  if (key == 'q' || key == 'Q')
    moveUp = false;

  if (key == 'e' || key == 'E')
    moveDown = false;
}


































