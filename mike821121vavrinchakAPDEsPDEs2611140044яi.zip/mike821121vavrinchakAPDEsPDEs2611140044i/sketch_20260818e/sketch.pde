

import processing.sound.*;
import processing.video.*;

SoundFile punchSound;
SoundFile kickSound;
Movie backgroundVideo;

int player1X = 100;
int player2X = 300;
int health1 = 100;
int health2 = 100;
boolean gameOver = false;

void setup() {
  size(400, 600, P2D);
  
  // Load assets
  punchSound = new SoundFile(this, "punch.mp3");
  kickSound = new SoundFile(this, "kick.mp3");
  backgroundVideo = new Movie(this, "background.mp4");
  backgroundVideo.loop();
  
  // Set initial positions
  player1X = width * 0.25;
  player2X = width * 0.75;
}

void draw() {
  if (gameOver) {
    background(0, 0, 0, 150);
    fill(255, 0, 0);
    textSize(48);
    textAlign(CENTER);
    text("GAME OVER", width/2, height/2);
    textSize(24);
    text("Tap to restart", width/2, height/2 + 50);
    return;
  }

  // Play background video
  backgroundVideo.read();
  image(backgroundVideo, 0, 0);
  
  // Draw health bars
  fill(0, 255, 0);
  rect(20, 40, health1 * 2, 20);
  fill(255, 0, 0);
  rect(200, 40, health2 * 2, 20);
  
  // Draw players
  fill(255, 0, 0);
  rect(player1X, height * 0.6, 80, 80);
  fill(0, 0, 255);
  rect(player2X, height * 0.6, 80, 80);
  
  // Draw ground
  fill(100, 50, 20);
  rect(0, height * 0.75, width, 50);
}

void mousePressed() {
  if (mouseX < player1X + 40 && mouseX > player1X && mouseY > height * 0.6 && mouseY < height * 0.6 + 80) {
    health2 -= 20;
    punchSound.play();
    if (health2 <= 0) gameOver = true;
  }
  else if (mouseX < player2X + 40 && mouseX > player2X && mouseY > height * 0.6 && mouseY < height * 0.6 + 80) {
    health1 -= 20;
    kickSound.play();
    if (health1 <= 0) gameOver = true;
  }
}

void keyPressed() {
  if (key == 'r' && gameOver) {
    health1 = 100;
    health2 = 100;
    gameOver = false;
  }
}










