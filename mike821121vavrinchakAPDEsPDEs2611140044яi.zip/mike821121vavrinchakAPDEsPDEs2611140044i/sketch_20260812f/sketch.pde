





// ============================================================
// APDE 55 x 55 BOARD
// YOUR ORIGINAL DRAWING + TWO ENGINE THINKING
//
// RED ENGINE  : 4 seconds thinking
// BLUE ENGINE : 4 seconds thinking
// FREE TIME   : 14 seconds
// ============================================================

float cc = 200;
float oo = 333;

float c = 200;
float o = 222;


// ============================================================
// ENGINE VARIABLES
// ============================================================

int BOARD = 55;

int engine = 0;
// 0 = RED
// 1 = BLUE

int engineState = 0;
// 0 = THINKING
// 1 = FREE TIME

long engineTimer = 0;

int THINK_TIME = 4000;
int FREE_TIME = 14000;

int redX = 27;
int redY = 27;

int blueX = 27;
int blueY = 27;

int redBestX = 27;
int redBestY = 27;

int blueBestX = 27;
int blueBestY = 27;

int thinkingCounter = 0;


// ============================================================
// SETUP
// ============================================================

void settings() {

  size(
    displayWidth,
    displayHeight,
    P2D
  );
}


void setup() {

  println(displayWidth);
  println(displayHeight);

  noStroke();

  orientation(PORTRAIT);

  t1w1 = 0;

  startEngine();
}


// ============================================================
// YOUR VARIABLE
// ============================================================

int t1w1 = 0;


// ============================================================
// DRAW
// ============================================================

void draw() {

  // ----------------------------------------------------------
  // YOUR ORIGINAL RANDOM BOARD REBUILD
  // ----------------------------------------------------------

  if (
    (int(random(1,11111)) == 9)
    ||
    (t1w1 == 0)
  ) {

    t1w1 = 1;

    fill(0,0,0);

    rect(
      0,
      0,
      displayWidth,
      displayHeight
    );


    float f55x55 =
      random(0,55*55);


    rectMode(CENTER);
    ellipseMode(CENTER);


    int fff = 1;


    // ========================================================
    // 55 x 55 = 3025 CELLS
    // ========================================================

    for (int f = 1; f < 56; f++) {

      for (int ff = 1; ff < 56; ff++) {


        // ----------------------------------------------------
        // BOARD COLOR
        // ----------------------------------------------------

        if (fff == 1) {

          fill(255,255,1);

          fff = 2;

        } else {

          fill(211,211,111);

          fff = 1;
        }


        float px =
          displayWidth / 30.0
          +
          (f * displayWidth / 60.0);

        float py =
          displayHeight / 30.0
          +
          (ff * displayHeight / 60.0);


        float cellW =
          displayWidth / 60.0;

        float cellH =
          displayHeight / 60.0;


        rect(
          px,
          py,
          cellW,
          cellH
        );


        // ----------------------------------------------------
        // RANDOM FIGURE
        // ----------------------------------------------------

        if (
          f55x55 >
          random(0,55*55)
        ) {

          int f1i12 =
            int(random(-2,15));


          // ==================================================
          // RED SQUARE
          // ==================================================

          if (f1i12 == 1) {

            fill(205,1,11);

            rect(
              px,
              py,
              cellW,
              cellH
            );
          }


          // ==================================================
          // BLUE SQUARE
          // ==================================================

          if (f1i12 == 2) {

            fill(11,1,205);

            rect(
              px,
              py,
              cellW,
              cellH
            );
          }


          // ==================================================
          // BLUE + YELLOW CENTER
          // ==================================================

          if (f1i12 == 3) {

            fill(11,1,205);

            rect(
              px,
              py,
              cellW,
              cellH
            );

            fill(251,255,111);

            rect(
              px,
              py,
              displayWidth / 160.0,
              displayHeight / 160.0
            );
          }


          // ==================================================
          // RED + CYAN CENTER
          // ==================================================

          if (f1i12 == 4) {

            fill(205,1,11);

            rect(
              px,
              py,
              cellW,
              cellH
            );

            fill(111,251,255);

            rect(
              px,
              py,
              displayWidth / 160.0,
              displayHeight / 160.0
            );
          }


          // ==================================================
          // BLUE CIRCLE
          // ==================================================

          if (f1i12 == 5) {

            fill(11,1,205);

            ellipse(
              px,
              py,
              cellW,
              cellH
            );
          }


          // ==================================================
          // RED CIRCLE
          // ==================================================

          if (f1i12 == 6) {

            fill(205,1,11);

            ellipse(
              px,
              py,
              cellW,
              cellH
            );
          }


          // ==================================================
          // RED TRIANGLE
          // ==================================================

          if (f1i12 == 7) {

            fill(205,1,11);

            triangle(

              px,
              py - displayHeight / 120.0,

              px - displayWidth / 120.0,
              py + displayHeight / 120.0,

              px + displayWidth / 120.0,
              py + displayHeight / 120.0
            );
          }


          // ==================================================
          // BLUE TRIANGLE
          // ==================================================

          if (f1i12 == 8) {

            fill(11,1,205);

            triangle(

              px,
              py - displayHeight / 120.0,

              px - displayWidth / 120.0,
              py + displayHeight / 120.0,

              px + displayWidth / 120.0,
              py + displayHeight / 120.0
            );
          }


          // ==================================================
          // BLUE CROSS
          // ==================================================

          if (f1i12 == 9) {

            fill(11,1,205);

            rect(
              px,
              py,
              cellW,
              displayHeight / 120.0
            );

            rect(
              px,
              py,
              displayWidth / 120.0,
              cellH
            );
          }


          // ==================================================
          // RED CROSS
          // ==================================================

          if (f1i12 == 10) {

            fill(205,1,11);

            rect(
              px,
              py,
              cellW,
              displayHeight / 120.0
            );

            rect(
              px,
              py,
              displayWidth / 120.0,
              cellH
            );
          }


          // ==================================================
          // RED 4-CORNER FIGURE
          // ==================================================

          if (f1i12 == 11) {

            fill(205,1,11);

            rect(
              px - displayWidth / 240.0,
              py - displayHeight / 240.0,
              displayWidth / 150.0,
              displayHeight / 150.0
            );

            rect(
              px + displayWidth / 240.0,
              py + displayHeight / 240.0,
              displayWidth / 150.0,
              displayHeight / 150.0
            );

            rect(
              px - displayWidth / 240.0,
              py + displayHeight / 240.0,
              displayWidth / 150.0,
              displayHeight / 150.0
            );

            rect(
              px + displayWidth / 240.0,
              py - displayHeight / 240.0,
              displayWidth / 150.0,
              displayHeight / 150.0
            );
          }


          // ==================================================
          // BLUE 4-CORNER FIGURE
          // ==================================================

          if (f1i12 == 12) {

            fill(11,1,205);

            rect(
              px - displayWidth / 240.0,
              py - displayHeight / 240.0,
              displayWidth / 150.0,
              displayHeight / 150.0
            );

            rect(
              px + displayWidth / 240.0,
              py + displayHeight / 240.0,
              displayWidth / 150.0,
              displayHeight / 150.0
            );

            rect(
              px - displayWidth / 240.0,
              py + displayHeight / 240.0,
              displayWidth / 150.0,
              displayHeight / 150.0
            );

            rect(
              px + displayWidth / 240.0,
              py - displayHeight / 240.0,
              displayWidth / 150.0,
              displayHeight / 150.0
            );
          }
        }
      }
    }


    // ========================================================
    // YOUR RED / BLUE RANDOM BALLS
    // ========================================================

    cc = random(0,displayWidth);
    oo = random(0,displayWidth);

    c = random(0,displayHeight);
    o = random(0,displayHeight);


    fill(255,0,0);

    ellipse(
      cc,
      c,
      displayWidth / 55.0
      +
      displayHeight / 55.0,
      displayWidth / 55.0
      +
      displayHeight / 55.0
    );


    fill(0,0,255);

    ellipse(
      oo,
      o,
      displayWidth / 55.0
      +
      displayHeight / 55.0,
      displayWidth / 55.0
      +
      displayHeight / 55.0
    );


    fill(255,111,111);

    ellipse(
      cc,
      c,
      22,
      22
    );


    fill(111,111,255);

    ellipse(
      oo,
      o,
      22,
      22
    );
  }


  // ==========================================================
  // ENGINE
  // ==========================================================

  engineThink();

  engineFreeTime();


  // ==========================================================
  // DRAW ENGINE PIECES OVER YOUR BOARD
  // ==========================================================

  drawEngines();


  // ==========================================================
  // ENGINE STATUS
  // ==========================================================

  drawEngineStatus();
}


// ============================================================
// START ENGINE
// ============================================================

void startEngine() {

  engineState = 0;

  engineTimer = millis();

  thinkingCounter = 0;

  if (engine == 0) {

    redBestX = redX;
    redBestY = redY;

  } else {

    blueBestX = blueX;
    blueBestY = blueY;
  }
}


// ============================================================
// ENGINE THINKING
// ============================================================

void engineThink() {

  if (engineState != 0)
    return;


  long elapsed =
    millis() - engineTimer;


  // ==========================================================
  // 4 SECOND THINKING
  // ==========================================================

  if (elapsed < THINK_TIME) {

    // MANY POSSIBLE MOVES
    for (int q = 0; q < 150; q++) {

      int tx =
        int(random(0,BOARD));

      int ty =
        int(random(0,BOARD));


      if (engine == 0) {

        int dx = tx - redX;
        int dy = ty - redY;

        float d =
          sqrt(dx * dx + dy * dy);


        // RED ENGINE SEARCH
        if (d < 15) {

          redBestX = tx;
          redBestY = ty;
        }

      } else {

        int dx = tx - blueX;
        int dy = ty - blueY;

        float d =
          sqrt(dx * dx + dy * dy);


        // BLUE ENGINE SEARCH
        if (d < 15) {

          blueBestX = tx;
          blueBestY = ty;
        }
      }

      thinkingCounter++;
    }

    return;
  }


  // ==========================================================
  // FINISH ENGINE MOVE
  // ==========================================================

  if (engine == 0) {

    redX = redBestX;
    redY = redBestY;

  } else {

    blueX = blueBestX;
    blueY = blueBestY;
  }


  // CHANGE TO FREE TIME

  engineState = 1;

  engineTimer = millis();


  // RED -> BLUE
  // BLUE -> RED

  engine = 1 - engine;
}


// ============================================================
// FREE TIME
// ============================================================

void engineFreeTime() {

  if (engineState != 1)
    return;


  long elapsed =
    millis() - engineTimer;


  if (elapsed >= FREE_TIME) {

    startEngine();
  }
}


// ============================================================
// DRAW RED + BLUE ENGINE PIECES
// ============================================================

void drawEngines() {

  float cellW =
    displayWidth / 60.0;

  float cellH =
    displayHeight / 60.0;


  // ==========================================================
  // RED ENGINE
  // ==========================================================

  float rx =
    displayWidth / 30.0
    +
    (redX + 1)
    * displayWidth / 60.0;


  float ry =
    displayHeight / 30.0
    +
    (redY + 1)
    * displayHeight / 60.0;


  fill(255,0,0);

  ellipse(
    rx,
    ry,
    cellW * 0.85,
    cellH * 0.85
  );


  fill(255,255,111);

  ellipse(
    rx,
    ry,
    cellW * 0.28,
    cellH * 0.28
  );


  // ==========================================================
  // BLUE ENGINE
  // ==========================================================

  float bx =
    displayWidth / 30.0
    +
    (blueX + 1)
    * displayWidth / 60.0;


  float by =
    displayHeight / 30.0
    +
    (blueY + 1)
    * displayHeight / 60.0;


  fill(0,0,255);

  ellipse(
    bx,
    by,
    cellW * 0.85,
    cellH * 0.85
  );


  fill(111,255,255);

  ellipse(
    bx,
    by,
    cellW * 0.28,
    cellH * 0.28
  );


  // ==========================================================
  // THINKING TARGET
  // ==========================================================

  if (engineState == 0) {

    float tx;
    float ty;


    if (engine == 0) {

      tx =
        displayWidth / 30.0
        +
        (redBestX + 1)
        * displayWidth / 60.0;

      ty =
        displayHeight / 30.0
        +
        (redBestY + 1)
        * displayHeight / 60.0;

    } else {

      tx =
        displayWidth / 30.0
        +
        (blueBestX + 1)
        * displayWidth / 60.0;

      ty =
        displayHeight / 30.0
        +
        (blueBestY + 1)
        * displayHeight / 60.0;
    }


    noFill();

    stroke(255);

    strokeWeight(3);

    ellipse(
      tx,
      ty,
      cellW,
      cellH
    );

    noStroke();
  }
}


// ============================================================
// STATUS TEXT
// ============================================================

void drawEngineStatus() {

  fill(255);

  textAlign(CENTER,CENTER);

  textSize(displayWidth / 25.0);


  long elapsed =
    millis() - engineTimer;


  // ==========================================================
  // THINKING
  // ==========================================================

  if (engineState == 0) {

    float left =
      (THINK_TIME - elapsed)
      / 1000.0;


    if (left < 0)
      left = 0;


    if (engine == 0) {

      text(
        "RED ENGINE THINKING  " +
        nf(left,1,1),
        displayWidth / 2,
        displayHeight * 0.965
      );

    } else {

      text(
        "BLUE ENGINE THINKING  " +
        nf(left,1,1),
        displayWidth / 2,
        displayHeight * 0.965
      );
    }
  }


  // ==========================================================
  // FREE TIME
  // ==========================================================

  else {

    float left =
      (FREE_TIME - elapsed)
      / 1000.0;


    if (left < 0)
      left = 0;


    text(
      "FREE TIME  " +
      nf(left,1,1),
      displayWidth / 2,
      displayHeight * 0.965
    );
  }
}










