




/*
 ============================================================
 CHESS ANALYZER V2
 ONE FILE / APDE 0.5.3
 ============================================================

 FEN
 BEST MOVE
 LOCAL ALPHA-BETA ENGINE
 DEPTH 3
 CHESS BOARD
 MOVE INPUT
 EVALUATION
 TIMER
 DRAW BEST-MOVE ARROW

 One PDE file.
 ============================================================
*/

final int EMPTY = 0;

final int WP = 1;
final int WN = 2;
final int WB = 3;
final int WR = 4;
final int WQ = 5;
final int WK = 6;

final int BP = -1;
final int BN = -2;
final int BB = -3;
final int BR = -4;
final int BQ = -5;
final int BK = -6;

int[][] board = new int[8][8];

boolean whiteToMove = true;

int selectedR = -1;
int selectedC = -1;

int bestFR = -1;
int bestFC = -1;
int bestTR = -1;
int bestTC = -1;

float bestScore = 0;

boolean showArrow = true;

String bestMoveText = "BEST MOVE: ---";

int engineDepth = 3;

long thinkingStart;
boolean thinking = false;

long timerSeconds = 300;
long lastTimer;

int boardX;
int boardY;
int boardSize;
int cell;

PFont font;


/*
 ============================================================
 SETUP
 ============================================================
*/

void setup() {

  fullScreen();

  orientation(LANDSCAPE);

  font = createFont("Sans", 22);

  textFont(font);

  loadFEN(
    "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
  );

  lastTimer = millis();
}


/*
 ============================================================
 DRAW
 ============================================================
*/

void draw() {

  background(0, 0);

  calculateBoard();

  drawBoard();

  drawPieces();

  drawBestArrow();

  drawInterface();

  updateTimer();
}


/*
 ============================================================
 BOARD POSITION
 ============================================================
*/

void calculateBoard() {

  int topSpace = 90;

  boardSize = min(
    width - 20,
    height - topSpace - 20
  );

  boardX = (width - boardSize) / 2;

  boardY = topSpace;

  cell = boardSize / 8;
}


/*
 ============================================================
 BOARD
 ============================================================
*/

void drawBoard() {

  noStroke();

  for (int r = 0; r < 8; r++) {

    for (int c = 0; c < 8; c++) {

      if ((r+c)%2 == 0)
        fill(235);
      else
        fill(90);

      rect(
        boardX+c*cell,
        boardY+r*cell,
        cell,
        cell
      );
    }
  }


  // selected square

  if (selectedR >= 0) {

    fill(255,220,0,120);

    rect(
      boardX+selectedC*cell,
      boardY+selectedR*cell,
      cell,
      cell
    );
  }


  // coordinates

  fill(20);

  textSize(12);

  for (int c = 0; c < 8; c++) {

    String s = ""+(char)('a'+c);

    text(
      s,
      boardX+c*cell+4,
      boardY+boardSize-4
    );
  }

  for (int r = 0; r < 8; r++) {

    String s = ""+(8-r);

    text(
      s,
      boardX+4,
      boardY+r*cell+15
    );
  }
}


/*
 ============================================================
 PIECES
 ============================================================
*/

void drawPieces() {

  textAlign(
    CENTER,
    CENTER
  );

  textSize(cell*0.68);

  for (int r = 0; r < 8; r++) {

    for (int c = 0; c < 8; c++) {

      int p = board[r][c];

      if (p == EMPTY)
        continue;

      String s = pieceSymbol(p);

      if (p > 0)
        fill(255);
      else
        fill(10);

      // shadow
      fill(0,100);

      text(
        s,
        boardX+c*cell+2,
        boardY+r*cell+3
      );

      if (p > 0)
        fill(250);
      else
        fill(15);

      text(
        s,
        boardX+c*cell,
        boardY+r*cell
      );
    }
  }

  textAlign(
    LEFT,
    BASELINE
  );
}


/*
 ============================================================
 PIECE SYMBOL
 ============================================================
*/

String pieceSymbol(int p) {

  switch(abs(p)) {

  case 1:
    return p > 0 ? "♙" : "♟";

  case 2:
    return p > 0 ? "♘" : "♞";

  case 3:
    return p > 0 ? "♗" : "♝";

  case 4:
    return p > 0 ? "♖" : "♜";

  case 5:
    return p > 0 ? "♕" : "♛";

  case 6:
    return p > 0 ? "♔" : "♚";
  }

  return "";
}


/*
 ============================================================
 INTERFACE
 ============================================================
*/

void drawInterface() {

  fill(20,20,20,230);

  rect(
    0,
    0,
    width,
    82
  );

  fill(255);

  textSize(17);

  text(
    bestMoveText,
    15,
    25
  );

  textSize(15);

  text(
    "TURN: " +
    (whiteToMove ? "WHITE" : "BLACK"),
    15,
    50
  );

  text(
    "EVAL: " +
    nf(bestScore/100.0,1,2),
    170,
    50
  );


  // buttons

  button(
    300,
    12,
    410,
    58,
    "BEST MOVE"
  );

  button(
    420,
    12,
    490,
    58,
    "START"
  );

  button(
    500,
    12,
    570,
    58,
    "CLEAR"
  );

  button(
    580,
    12,
    650,
    58,
    "DEPTH"
  );


  textSize(18);

  fill(255);

  text(
    formatTime(timerSeconds),
    width-100,
    30
  );

  textSize(12);

  text(
    "tap piece -> tap destination",
    width-210,
    55
  );
}


void button(
  int x1,
  int y1,
  int x2,
  int y2,
  String s
) {

  fill(50,50,50,240);

  rect(
    x1,
    y1,
    x2-x1,
    y2-y1,
    8
  );

  fill(255);

  textSize(13);

  textAlign(
    CENTER,
    CENTER
  );

  text(
    s,
    (x1+x2)/2,
    (y1+y2)/2
  );

  textAlign(
    LEFT,
    BASELINE
  );
}


/*
 ============================================================
 TOUCH
 ============================================================
*/

void mousePressed() {

  // BEST MOVE

  if (mouseY >= 12 &&
      mouseY <= 58 &&
      mouseX >= 300 &&
      mouseX <= 410) {

    findBestMove();

    return;
  }


  // START

  if (mouseY >= 12 &&
      mouseY <= 58 &&
      mouseX >= 420 &&
      mouseX <= 490) {

    loadFEN(
      "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
    );

    return;
  }


  // CLEAR

  if (mouseY >= 12 &&
      mouseY <= 58 &&
      mouseX >= 500 &&
      mouseX <= 570) {

    for (int r=0;r<8;r++)
      for (int c=0;c<8;c++)
        board[r][c]=EMPTY;

    bestMoveText =
      "BEST MOVE: ---";

    selectedR=-1;
    selectedC=-1;

    return;
  }


  // DEPTH

  if (mouseY >= 12 &&
      mouseY <= 58 &&
      mouseX >= 580 &&
      mouseX <= 650) {

    engineDepth++;

    if (engineDepth > 4)
      engineDepth=2;

    bestMoveText =
      "DEPTH: " + engineDepth;

    return;
  }


  // board

  if (mouseX >= boardX &&
      mouseX < boardX+boardSize &&
      mouseY >= boardY &&
      mouseY < boardY+boardSize) {

    int c =
      (mouseX-boardX)/cell;

    int r =
      (mouseY-boardY)/cell;

    boardTouch(r,c);
  }
}


/*
 ============================================================
 BOARD TOUCH
 ============================================================
*/

void boardTouch(int r,int c) {

  if (selectedR < 0) {

    int p=board[r][c];

    if (p != EMPTY &&
        ((p>0)==whiteToMove)) {

      selectedR=r;
      selectedC=c;
    }

    return;
  }


  // same square

  if (r==selectedR &&
      c==selectedC) {

    selectedR=-1;
    selectedC=-1;

    return;
  }


  int p =
    board[selectedR][selectedC];

  if (p != EMPTY &&
      ((p>0)==whiteToMove)) {

    if (isPseudoLegal(
      selectedR,
      selectedC,
      r,
      c
    )) {

      board[r][c]=p;

      board[selectedR][selectedC]=EMPTY;

      // promotion

      if (p==WP && r==0)
        board[r][c]=WQ;

      if (p==BP && r==7)
        board[r][c]=BQ;

      whiteToMove=!whiteToMove;

      bestMoveText =
        "BEST MOVE: ---";

      bestFR=-1;
      bestFC=-1;

      selectedR=-1;
      selectedC=-1;
    }
  }
}


/*
 ============================================================
 FEN
 ============================================================
*/

void loadFEN(String fen) {

  String[] parts =
    split(fen," ");

  String[] rows =
    split(parts[0],"/");

  for (int r=0;r<8;r++)
    for (int c=0;c<8;c++)
      board[r][c]=EMPTY;


  for (int r=0;r<8;r++) {

    int c=0;

    for (int i=0;
         i<rows[r].length();
         i++) {

      char ch =
        rows[r].charAt(i);

      if (ch>='1' &&
          ch<='8') {

        c += ch-'0';

      } else {

        board[r][c]=fenPiece(ch);

        c++;
      }
    }
  }


  if (parts.length>1)
    whiteToMove =
      parts[1].equals("w");
  else
    whiteToMove=true;


  selectedR=-1;
  selectedC=-1;

  bestFR=-1;
  bestFC=-1;
  bestTR=-1;
  bestTC=-1;

  bestScore=0;

  bestMoveText =
    "BEST MOVE: ---";
}


int fenPiece(char ch) {

  switch(ch) {

  case 'P': return WP;
  case 'N': return WN;
  case 'B': return WB;
  case 'R': return WR;
  case 'Q': return WQ;
  case 'K': return WK;

  case 'p': return BP;
  case 'n': return BN;
  case 'b': return BB;
  case 'r': return BR;
  case 'q': return BQ;
  case 'k': return BK;
  }

  return EMPTY;
}


/*
 ============================================================
 BEST MOVE
 ============================================================
*/

void findBestMove() {

  thinking=true;

  thinkingStart=millis();

  int side =
    whiteToMove ? 1 : -1;

  SearchResult result =
    searchRoot(
      side,
      engineDepth
    );

  bestFR=result.fr;
  bestFC=result.fc;
  bestTR=result.tr;
  bestTC=result.tc;

  bestScore=result.score;

  if (bestFR>=0) {

    bestMoveText =
      "BEST MOVE: " +
      squareName(bestFR,bestFC) +
      "-" +
      squareName(bestTR,bestTC);

  } else {

    bestMoveText =
      "BEST MOVE: NONE";
  }

  thinking=false;
}


/*
 ============================================================
 SEARCH RESULT
 ============================================================
*/

class SearchResult {

  int fr;
  int fc;
  int tr;
  int tc;

  float score;

  SearchResult(
    int a,
    int b,
    int c,
    int d,
    float e
  ) {

    fr=a;
    fc=b;
    tr=c;
    tc=d;
    score=e;
  }
}


/*
 ============================================================
 ROOT SEARCH
 ============================================================
*/

SearchResult searchRoot(
  int side,
  int depth
) {

  float best =
    side==1 ?
    -10000000 :
    10000000;

  SearchResult bestMove =
    new SearchResult(
      -1,-1,-1,-1,best
    );


  for (int fr=0;fr<8;fr++) {

    for (int fc=0;fc<8;fc++) {

      int p=board[fr][fc];

      if (p==EMPTY)
        continue;

      if ((p>0 ? 1:-1)!=side)
        continue;


      for (int tr=0;tr<8;tr++) {

        for (int tc=0;tc<8;tc++) {

          if (!isPseudoLegal(
            fr,fc,tr,tc))
            continue;

          int captured =
            board[tr][tc];

          board[tr][tc]=p;
          board[fr][fc]=EMPTY;


          float score =
            alphaBeta(
              depth-1,
              -10000000,
              10000000,
              -side
            );


          board[fr][fc]=p;
          board[tr][tc]=captured;


          if (side==1) {

            if (score>best) {

              best=score;

              bestMove =
                new SearchResult(
                  fr,fc,tr,tc,score
                );
            }

          } else {

            if (score<best) {

              best=score;

              bestMove =
                new SearchResult(
                  fr,fc,tr,tc,score
                );
            }
          }
        }
      }
    }
  }

  return bestMove;
}


/*
 ============================================================
 ALPHA BETA
 ============================================================
*/

float alphaBeta(
  int depth,
  float alpha,
  float beta,
  int side
) {

  if (depth<=0)
    return evaluate();


  float best =
    side==1 ?
    -10000000 :
    10000000;


  boolean found=false;


  for (int fr=0;fr<8;fr++) {

    for (int fc=0;fc<8;fc++) {

      int p=board[fr][fc];

      if (p==EMPTY)
        continue;

      if ((p>0 ? 1:-1)!=side)
        continue;


      for (int tr=0;tr<8;tr++) {

        for (int tc=0;tc<8;tc++) {

          if (!isPseudoLegal(
            fr,fc,tr,tc))
            continue;

          found=true;

          int captured =
            board[tr][tc];

          board[tr][tc]=p;
          board[fr][fc]=EMPTY;


          float score =
            alphaBeta(
              depth-1,
              alpha,
              beta,
              -side
            );


          board[fr][fc]=p;
          board[tr][tc]=captured;


          if (side==1) {

            if (score>best)
              best=score;

            if (best>alpha)
              alpha=best;

          } else {

            if (score<best)
              best=score;

            if (best<beta)
              beta=best;
          }


          if (beta<=alpha)
            return best;
        }
      }
    }
  }


  if (!found)
    return evaluate();

  return best;
}


/*
 ============================================================
 EVALUATION
 ============================================================
*/

float evaluate() {

  float score=0;


  for (int r=0;r<8;r++) {

    for (int c=0;c<8;c++) {

      int p=board[r][c];

      if (p==EMPTY)
        continue;


      float v =
        pieceValue(abs(p));


      // pawn position

      if (abs(p)==1) {

        if (p>0)
          v += (6-r)*4;
        else
          v += (r-1)*4;
      }


      // center control

      if (r>=2 &&
          r<=5 &&
          c>=2 &&
          c<=5) {

        v += 4;
      }


      if (p>0)
        score+=v;
      else
        score-=v;
    }
  }


  return score;
}


float pieceValue(int p) {

  if (p==1) return 100;
  if (p==2) return 320;
  if (p==3) return 330;
  if (p==4) return 500;
  if (p==5) return 900;
  if (p==6) return 20000;

  return 0;
}


/*
 ============================================================
 MOVE GENERATION
 ============================================================
*/

boolean isPseudoLegal(
  int fr,
  int fc,
  int tr,
  int tc
) {

  if (fr==tr &&
      fc==tc)
    return false;


  int p =
    board[fr][fc];

  if (p==EMPTY)
    return false;


  int target =
    board[tr][tc];


  // cannot capture own piece

  if (target!=EMPTY &&
      ((p>0)==(target>0)))
    return false;


  int dr=tr-fr;
  int dc=tc-fc;


  switch(abs(p)) {

  // PAWN

  case 1:

    int dir =
      p>0 ? -1 : 1;

    int start =
      p>0 ? 6 : 1;


    if (dc==0 &&
        target==EMPTY &&
        dr==dir)
      return true;


    if (dc==0 &&
        target==EMPTY &&
        fr==start &&
        dr==2*dir &&
        board[fr+dir][fc]==EMPTY)
      return true;


    if (abs(dc)==1 &&
        dr==dir &&
        target!=EMPTY)
      return true;

    return false;


  // KNIGHT

  case 2:

    return
      (abs(dr)==2 &&
       abs(dc)==1) ||
      (abs(dr)==1 &&
       abs(dc)==2);


  // BISHOP

  case 3:

    if (abs(dr)!=abs(dc))
      return false;

    return clearPath(
      fr,fc,tr,tc
    );


  // ROOK

  case 4:

    if (dr!=0 && dc!=0)
      return false;

    return clearPath(
      fr,fc,tr,tc
    );


  // QUEEN

  case 5:

    if (!(dr==0 ||
          dc==0 ||
          abs(dr)==abs(dc)))
      return false;

    return clearPath(
      fr,fc,tr,tc
    );


  // KING

  case 6:

    return
      abs(dr)<=1 &&
      abs(dc)<=1;
  }


  return false;
}


/*
 ============================================================
 PATH
 ============================================================
*/

boolean clearPath(
  int fr,
  int fc,
  int tr,
  int tc
) {

  int sr =
    Integer.signum(tr-fr);

  int sc =
    Integer.signum(tc-fc);

  int r=fr+sr;
  int c=fc+sc;


  while (r!=tr ||
         c!=tc) {

    if (board[r][c]!=EMPTY)
      return false;

    r+=sr;
    c+=sc;
  }

  return true;
}


/*
 ============================================================
 BEST ARROW
 ============================================================
*/

void drawBestArrow() {

  if (!showArrow)
    return;

  if (bestFR<0)
    return;


  float x1 =
    boardX+
    bestFC*cell+
    cell/2;

  float y1 =
    boardY+
    bestFR*cell+
    cell/2;


  float x2 =
    boardX+
    bestTC*cell+
    cell/2;

  float y2 =
    boardY+
    bestTR*cell+
    cell/2;


  stroke(
    255,
    30,
    30,
    220
  );

  strokeWeight(
    max(5,cell/14)
  );

  line(
    x1,y1,
    x2,y2
  );


  // arrow head

  float a =
    atan2(
      y2-y1,
      x2-x1
    );


  float len=25;


  line(
    x2,y2,
    x2-len*cos(a-0.5),
    y2-len*sin(a-0.5)
  );

  line(
    x2,y2,
    x2-len*cos(a+0.5),
    y2-len*sin(a+0.5)
  );

  noStroke();
}


/*
 ============================================================
 SQUARE NAME
 ============================================================
*/

String squareName(
  int r,
  int c
) {

  return
    ""+(char)('a'+c)+
    (8-r);
}


/*
 ============================================================
 TIMER
 ============================================================
*/

void updateTimer() {

  long now=millis();

  if (now-lastTimer>=1000) {

    long n=
      (now-lastTimer)/1000;

    timerSeconds-=n;

    if (timerSeconds<0)
      timerSeconds=0;

    lastTimer=now;
  }
}


String formatTime(long s) {

  int m=(int)(s/60);

  int sec=(int)(s%60);

  return
    nf(m,2)+":"+
    nf(sec,2);
}


/*
 ============================================================
 FEN EXAMPLES

 START:
 rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1

 After 1.e4:
 rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq - 0 1

 Example tactical position:
 6k1/5ppp/8/8/8/8/5PPP/6K1 w - - 0 1

 ============================================================
*/




















