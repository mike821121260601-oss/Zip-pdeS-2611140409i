







import processing.sound.*;

// 4 banks × 28 keys
final int BANKS = 4;
final int KEYS_PER_BANK = 28;

// MIDI note base for each bank (you can change these)
int[] bankBaseNote = {36, 48, 60, 72};  // C2, C3, C4, C5

SinOsc[][] osc;          // [bank][key]
boolean[][] keyPressed;  // track which keys are currently held

int currentBank = 0;

// Key layout
float keyW, keyH;
float startY;

// Bank selector buttons
float bankBtnW, bankBtnH;

void setup() {
  fullScreen();



  orientation(LANDSCAPE);



////  orientation(PORTRAIT);
         









  // Maximum volume
  // (Sound library amplitude 1.0 = max)
  
  osc = new SinOsc[BANKS][KEYS_PER_BANK];
  keyPressed = new boolean[BANKS][KEYS_PER_BANK];
  
  for (int b = 0; b < BANKS; b++) {
    for (int k = 0; k < KEYS_PER_BANK; k++) {
      osc[b][k] = new SinOsc(this);
      osc[b][k].amp(0);          // start silent
      keyPressed[b][k] = false;
    }
  }
  
  // Layout calculations
  keyW = width / (float)KEYS_PER_BANK;
  keyH = height * 0.55;
  startY = height * 0.28;
  
  bankBtnW = width / 5.0;
  bankBtnH = height * 0.12;
  
  textAlign(CENTER, CENTER);
  noStroke();
}

void draw() {
  background(20);
  
  // Title
  fill(220);
  textSize(28);
  text("MIDI Keys – Sound Library  |  Volume MAX", width/2, 40);
  
  // Draw bank selector buttons
  for (int b = 0; b < BANKS; b++) {
    float x = (b + 0.5) * (width / 4.0);
    if (b == currentBank) {
      fill(80, 180, 255);
    } else {
      fill(60);
    }
    rect(x - bankBtnW/2, 70, bankBtnW, bankBtnH, 12);
    
    fill(255);
    textSize(22);
    text("SET " + (b+1), x, 70 + bankBtnH/2);
  }
  
  // Draw the 28 rectangular keys of the current bank
  for (int k = 0; k < KEYS_PER_BANK; k++) {
    float x = k * keyW;
    
    // Visual feedback
    if (keyPressed[currentBank][k]) {
      fill(255, 200, 50);          // pressed = bright
    } else {
      // Alternate colors for better visibility
      if (k % 2 == 0) fill(70, 90, 140);
      else            fill(50, 70, 110);
    }
    
    rect(x + 2, startY, keyW - 4, keyH, 6);
    
    // Note number label
    fill(255);
    textSize(16);
    int midiNote = bankBaseNote[currentBank] + k;
    text(midiNote, x + keyW/2, startY + keyH - 25);
  }
  
  // Info
  fill(180);
  textSize(18);
  text("Bank " + (currentBank+1) + "  |  Base MIDI " + bankBaseNote[currentBank] + 
       "  |  28 Keys  |  Multitouch OK", width/2, height - 30);
}

// Multitouch handling
void touchStarted() {
  checkTouches();
}

void touchMoved() {
  checkTouches();
}

void touchEnded() {
  // Release keys that are no longer touched
  for (int k = 0; k < KEYS_PER_BANK; k++) {
    boolean stillTouched = false;
    for (int i = 0; i < touches.length; i++) {
      if (isOverKey(touches[i].x, touches[i].y, k)) {
        stillTouched = true;
        break;
      }
    }
    if (!stillTouched && keyPressed[currentBank][k]) {
      releaseKey(k);
    }
  }
  
  // Also check bank buttons
  for (int i = 0; i < touches.length; i++) {
    checkBankButton(touches[i].x, touches[i].y);
  }
}

void checkTouches() {
  // First release all keys that lost their finger
  for (int k = 0; k < KEYS_PER_BANK; k++) {
    boolean stillTouched = false;
    for (int i = 0; i < touches.length; i++) {
      if (isOverKey(touches[i].x, touches[i].y, k)) {
        stillTouched = true;
        break;
      }
    }
    if (!stillTouched && keyPressed[currentBank][k]) {
      releaseKey(k);
    }
  }
  
  // Then press any newly touched keys
  for (int i = 0; i < touches.length; i++) {
    float tx = touches[i].x;
    float ty = touches[i].y;
    
    // Bank buttons
    checkBankButton(tx, ty);
    
    // Keys
    for (int k = 0; k < KEYS_PER_BANK; k++) {
      if (isOverKey(tx, ty, k) && !keyPressed[currentBank][k]) {
        pressKey(k);
      }
    }
  }
}

boolean isOverKey(float x, float y, int k) {
  float kx = k * keyW;
  return (x > kx && x < kx + keyW && y > startY && y < startY + keyH);
}

void checkBankButton(float x, float y) {
  for (int b = 0; b < BANKS; b++) {
    float bx = (b + 0.5) * (width / 4.0);
    if (x > bx - bankBtnW/2 && x < bx + bankBtnW/2 &&
        y > 70 && y < 70 + bankBtnH) {
      if (currentBank != b) {
        // Release all keys of old bank when switching
        for (int k = 0; k < KEYS_PER_BANK; k++) {
          if (keyPressed[currentBank][k]) {
            releaseKey(k);
          }
        }
        currentBank = b;
      }
    }
  }
}

void pressKey(int k) {
  keyPressed[currentBank][k] = true;
  
  int midiNote = bankBaseNote[currentBank] + k;
  float freq = midiToFreq(midiNote);
  
  osc[currentBank][k].freq(freq);
  osc[currentBank][k].amp(1.0);   // VOLUME MAXIMUM
  osc[currentBank][k].play();
}

void releaseKey(int k) {
  keyPressed[currentBank][k] = false;
  osc[currentBank][k].amp(0);     // silence
  // osc[currentBank][k].stop();  // optional
}

// Convert MIDI note number → frequency
float midiToFreq(int note) {
  return 440.0 * pow(2, (note - 69) / 12.0);
}

// Clean up when sketch stops
void stop() {
  for (int b = 0; b < BANKS; b++) {
    for (int k = 0; k < KEYS_PER_BANK; k++) {
      if (osc[b][k] != null) {
        osc[b][k].stop();
      }
    }
  }
  super.stop();
}








































