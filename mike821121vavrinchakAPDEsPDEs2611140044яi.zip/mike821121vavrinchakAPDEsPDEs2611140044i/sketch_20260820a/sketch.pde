


//////FILE BROWSER/////ok////

import android.content.Intent;
import android.net.Uri;
import android.app.Activity;

Activity act;
Uri selectedFileUri;

void setup() {
  size(displayWidth, displayHeight);
  act = this.getActivity();
  orientation(PORTRAIT);
  
  // Optional: request storage permission if needed (Android 6+)
  // requestPermission("android.permission.READ_EXTERNAL_STORAGE");
}

void draw() {
  background(40);
  fill(255);
  textAlign(CENTER, CENTER);
  textSize(48);
  text("Tap to open File Browser", width/2, height/2);
  
  if (selectedFileUri != null) {
    textSize(28);
    text("Selected:\n" + selectedFileUri.toString(), width/2, height*0.7);
  }
}

void mousePressed() {
  openFileBrowser();
}

void openFileBrowser() {
  Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
  intent.setType("*/*");                    // any file type
  intent.addCategory(Intent.CATEGORY_OPENABLE);
  
  // Optional: allow multiple selection
  // intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
  
  act.startActivityForResult(Intent.createChooser(intent, "Select a file"), 1001);
}

// This is called automatically by the Android activity when the picker returns
@Override
public void onActivityResult(int requestCode, int resultCode, Intent data) {
  super.onActivityResult(requestCode, resultCode, data);
  
  if (requestCode == 1001 && resultCode == Activity.RESULT_OK && data != null) {
    selectedFileUri = data.getData();
    println("Selected URI: " + selectedFileUri);
    
    // Example: get a real path or open an InputStream
    // InputStream is = act.getContentResolver().openInputStream(selectedFileUri);
  }
}


  ////good////



















