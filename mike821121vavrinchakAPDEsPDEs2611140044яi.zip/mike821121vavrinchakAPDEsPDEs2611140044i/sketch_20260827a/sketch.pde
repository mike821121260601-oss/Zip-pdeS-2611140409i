





import android.graphics.Paint;
import android.graphics.Typeface;

Paint androidPaint;

int code = 0;
int maxCode = 0xFFFF;

int cellW = 180;
int cellH = 105;

void setup() {
  fullScreen();
  
  androidPaint = new Paint();
  androidPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
  androidPaint.setTextAlign(Paint.Align.CENTER);
  androidPaint.setTextSize(55);
  
  textAlign(CENTER, CENTER);
  
  // Unicode Basic Multilingual Plane
  maxCode = 0xFFFF;
}

void draw() {
  background(20);
  
  int cols = max(1, width / cellW);
  int rows = max(1, height / cellH);
  int perPage = cols * rows;
  
  int start = (code / perPage) * perPage;
  
  for (int i = 0; i < perPage; i++) {
    int c = start + i;
    
    if (c > maxCode) break;
    
    int col = i % cols;
    int row = i / cols;
    
    float x = col * cellW + cellW / 2;
    float y = row * cellH + cellH / 2;
    
    boolean exists = hasGlyph(c);
    
    // cell
    stroke(70);
    noFill();
    rectMode(CENTER);
    rect(x, y, cellW - 4, cellH - 4);
    
    if (exists) {
      // character
      fill(255);
      textSize(55);
      text(codeToString(c), x, y - 15);
    } else {
      fill(80);
      textSize(25);
      text("NO GLYPH", x, y - 15);
    }
    
    // hexadecimal Unicode number
    fill(180);
    textSize(15);
    text("U+" + hex(c, 4), x, y + 30);
    
    // decimal number
    text(str(c), x, y + 48);
  }
  
  fill(255);
  textSize(18);
  text(
    "START U+" + hex(start, 4) +
    "   END U+" + hex(min(start + perPage - 1, maxCode), 4),
    width / 2,
    height - 20
  );
}

boolean hasGlyph(int c) {
  String s = codeToString(c);
  
  if (s.length() == 0) return false;
  
  return androidPaint.hasGlyph(s);
}

String codeToString(int c) {
  try {
    return new String(Character.toChars(c));
  }
  catch(Exception e) {
    return "";
  }
}

void keyPressed() {
  
  // next page
  if (keyCode == RIGHT) {
    int cols = max(1, width / cellW);
    int rows = max(1, height / cellH);
    int page = cols * rows;
    
    code += page;
    if (code > maxCode) code = maxCode;
  }
  
  // previous page
  if (keyCode == LEFT) {
    int cols = max(1, width / cellW);
    int rows = max(1, height / cellH);
    int page = cols * rows;
    
    code -= page;
    if (code < 0) code = 0;
  }
  
  // first character
  if (key == '0') code = 0;
  
  // chess Unicode block
  if (key == 'c' || key == 'C') {
    code = 0x2654;
  }
}














