



/////GPT//MY ASK//WORK DO OK//
// ARKANOID - APDE / PROCESSING
// Touch the screen to move the paddle
// Android portrait

int cols = 10;
int rows = 12;

float paddleX;
float paddleY;
float paddleW;
float paddleH;

float ballX, ballY;
float ballDX, ballDY;
float ballR;

boolean[][] brick;
int score = 0;
int lives = 3;
int level = 1;

boolean gameOver = false;
boolean win = false;

void settings() {
  size(displayWidth, displayHeight, P2D);
}

void setup() {
  orientation(PORTRAIT);

  paddleW = width * 0.22;
  paddleH = height * 0.025;
  paddleY = height * 0.90;

  ballR = min(width, height) * 0.018;

  brick = new boolean[rows][cols];

  newLevel();
}

void draw() {
  background(0);

  if (gameOver) {
    drawGameOver();
    return;
  }

  if (win) {
    drawWin();
    return;
  }

  updateBall();
  drawBricks();
  drawPaddle();
  drawBall();
  drawInfo();
}

// ------------------------------------------------
// LEVEL
// ------------------------------------------------

void newLevel() {

  for (int y = 0; y < rows; y++) {
    for (int x = 0; x < cols; x++) {

      // more bricks as level increases
      brick[y][x] = true;
    }
  }

  paddleX = width / 2;

  ballX = width / 2;
  ballY = height * 0.70;

  ballDX = random(-3, 3);

  if (abs(ballDX) < 1)
    ballDX = 1.5;

  ballDY = -5 - level * 0.3;
}

// ------------------------------------------------
// BALL
// ------------------------------------------------

void updateBall() {

  ballX += ballDX;
  ballY += ballDY;

  // LEFT
  if (ballX - ballR < 0) {
    ballX = ballR;
    ballDX *= -1;
  }

  // RIGHT
  if (ballX + ballR > width) {
    ballX = width - ballR;
    ballDX *= -1;
  }

  // TOP
  if (ballY - ballR < 0) {
    ballY = ballR;
    ballDY *= -1;
  }

  // PADDLE
  if (
    ballY + ballR >= paddleY &&
    ballY - ballR <= paddleY + paddleH &&
    ballX >= paddleX - paddleW / 2 &&
    ballX <= paddleX + paddleW / 2 &&
    ballDY > 0
    ) {

    ballY = paddleY - ballR;

    ballDY *= -1;

    // change angle depending on paddle hit position
    float hit =
      (ballX - paddleX) / (paddleW / 2);

    ballDX += hit * 2.0;

    // limit horizontal speed
    ballDX = constrain(ballDX, -8, 8);
  }

  // BRICKS
  checkBricks();

  // BALL LOST
  if (ballY - ballR > height) {

    lives--;

    if (lives <= 0) {
      gameOver = true;
    } else {
      resetBall();
    }
  }
}

// ------------------------------------------------
// BRICKS
// ------------------------------------------------

void checkBricks() {

  float margin = width * 0.04;

  float bw =
    (width - margin * 2) / cols;

  float bh =
    height * 0.035;

  float startY =
    height * 0.10;

  for (int y = 0; y < rows; y++) {

    for (int x = 0; x < cols; x++) {

      if (!brick[y][x])
        continue;

      float bx =
        margin + x * bw;

      float by =
        startY + y * bh;

      // collision
      if (
        ballX + ballR > bx &&
        ballX - ballR < bx + bw &&
        ballY + ballR > by &&
        ballY - ballR < by + bh
        ) {

        brick[y][x] = false;

        score += 10 * level;

        // decide bounce direction
        float centerX = bx + bw / 2;
        float centerY = by + bh / 2;

        float dx = ballX - centerX;
        float dy = ballY - centerY;

        if (abs(dx) > abs(dy))
          ballDX *= -1;
        else
          ballDY *= -1;

        // check if all bricks destroyed
        if (allBricksDestroyed()) {

          level++;

          if (level > 10) {
            win = true;
          } else {
            newLevel();
          }
        }

        return;
      }
    }
  }
}

boolean allBricksDestroyed() {

  for (int y = 0; y < rows; y++) {
    for (int x = 0; x < cols; x++) {

      if (brick[y][x])
        return false;
    }
  }

  return true;
}

// ------------------------------------------------
// RESET BALL
// ------------------------------------------------

void resetBall() {

  ballX = width / 2;
  ballY = height * 0.70;

  ballDX = random(-3, 3);

  if (abs(ballDX) < 1)
    ballDX = 2;

  ballDY = -5 - level * 0.3;
}

// ------------------------------------------------
// PADDLE
// ------------------------------------------------

void drawPaddle() {

  rectMode(CENTER);

  fill(255);

  rect(
    paddleX,
    paddleY,
    paddleW,
    paddleH
    );

  rectMode(CORNER);
}

// ------------------------------------------------
// BALL
// ------------------------------------------------

void drawBall() {

  noStroke();

  fill(255, 255, 255);

  ellipse(
    ballX,
    ballY,
    ballR * 2,
    ballR * 2
    );
}

// ------------------------------------------------
// BRICKS
// ------------------------------------------------

void drawBricks() {

  float margin = width * 0.04;

  float bw =
    (width - margin * 2) / cols;

  float bh =
    height * 0.035;

  float startY =
    height * 0.10;

  for (int y = 0; y < rows; y++) {

    for (int x = 0; x < cols; x++) {

      if (!brick[y][x])
        continue;

      float bx =
        margin + x * bw;

      float by =
        startY + y * bh;

      // different colors for different rows
      if (y % 5 == 0)
        fill(255, 60, 60);
      else if (y % 5 == 1)
        fill(255, 160, 40);
      else if (y % 5 == 2)
        fill(255, 255, 40);
      else if (y % 5 == 3)
        fill(60, 220, 100);
      else
        fill(60, 150, 255);

      rect(
        bx + 2,
        by + 2,
        bw - 4,
        bh - 4
        );
    }
  }
}

// ------------------------------------------------
// INFORMATION
// ------------------------------------------------

void drawInfo() {

  fill(255);

  textAlign(LEFT, TOP);
  textSize(width * 0.045);

  text(
    "SCORE: " + score,
    width * 0.03,
    height * 0.015
    );

  text(
    "LIVES: " + lives,
    width * 0.40,
    height * 0.015
    );

  text(
    "LEVEL: " + level,
    width * 0.72,
    height * 0.015
    );
}

// ------------------------------------------------
// TOUCH
// ------------------------------------------------

void touchMoved() {

  paddleX = mouseX;

  paddleX =
    constrain(
      paddleX,
      paddleW / 2,
      width - paddleW / 2
      );
}

void touchStarted() {

  paddleX = mouseX;

  paddleX =
    constrain(
      paddleX,
      paddleW / 2,
      width - paddleW / 2
      );
}

// ------------------------------------------------
// GAME OVER
// ------------------------------------------------

void drawGameOver() {

  fill(255);

  textAlign(CENTER, CENTER);

  textSize(width * 0.10);

  text(
    "GAME OVER",
    width / 2,
    height * 0.40
    );

  textSize(width * 0.055);

  text(
    "SCORE: " + score,
    width / 2,
    height * 0.50
    );

  text(
    "TOUCH TO RESTART",
    width / 2,
    height * 0.60
    );
}

// ------------------------------------------------
// WIN
// ------------------------------------------------

void drawWin() {

  fill(255);

  textAlign(CENTER, CENTER);

  textSize(width * 0.10);

  text(
    "YOU WIN!",
    width / 2,
    height * 0.40
    );

  textSize(width * 0.055);

  text(
    "SCORE: " + score,
    width / 2,
    height * 0.50
    );

  text(
    "TOUCH TO PLAY AGAIN",
    width / 2,
    height * 0.60
    );
}

// ------------------------------------------------
// RESTART
// ------------------------------------------------

void mousePressed() {

  if (gameOver || win) {

    score = 0;
    lives = 3;
    level = 1;

    gameOver = false;
    win = false;

    newLevel();
  }
}








///ok











