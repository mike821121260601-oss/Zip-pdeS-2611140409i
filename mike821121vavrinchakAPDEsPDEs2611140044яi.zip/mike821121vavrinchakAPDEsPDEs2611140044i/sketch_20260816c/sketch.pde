






import android.content.*;
import android.os.*;
import android.telephony.*;
import android.net.*;
import android.net.wifi.*;
import java.text.*;
import java.util.*;

BatteryManager battery;
TelephonyManager telephony;

int batteryPercent = 0;
int signalLevel = 0;

String operatorName = "";
String wifiName = "";

void settings() {
  fullScreen();
}

void setup() {

  orientation(PORTRAIT);

  textFont(createFont("sans", 28+33));

  battery =
    (BatteryManager)getActivity().getSystemService(
    Context.BATTERY_SERVICE);

  telephony =
    (TelephonyManager)getActivity().getSystemService(
    Context.TELEPHONY_SERVICE);

  getBattery();
  getNetwork();
}


void draw() {

  background(20,20,25);

  getBattery();
  getNetwork();

  drawPanel();
}


// =====================================================
// PANEL
// =====================================================

void drawPanel() {

  // TOP SYSTEM BAR
  fill(35,35,42);
  rect(0,0,width,150);

  // CLOCK
  fill(255);
  textSize(48);

  String time =
    new SimpleDateFormat(
    "HH:mm",
    Locale.getDefault()
    ).format(new Date());

  text(time,30,60);


  // DATE
  textSize(20);

  String date =
    new SimpleDateFormat(
    "EEEE  dd MMMM",
    Locale.getDefault()
    ).format(new Date());

  text(date,30,95);


  // BATTERY
  drawBattery(width-115,35);


  // SIGNAL
  drawSignal(width-70,35);


  // OPERATOR
  textSize(16);
  fill(200);

  text(
    operatorName,
    30,
    125
    );


  // WIFI
  text(
    "Wi-Fi: " + wifiName,
    width/2,
    125
    );


  // =================================================
  // QUICK BUTTONS
  // =================================================

  drawButton(
    20,
    180,
    150,
    80,
    "Wi-Fi"
    );

  drawButton(
    190,
    180,
    150,
    80,
    "Bluetooth"
    );

  drawButton(
    360,
    180,
    150,
    80,
    "Rotation"
    );


  // =================================================
  // NOTIFICATIONS
  // =================================================

  fill(255);
  textSize(30);

  text(
    "NOTIFICATIONS",
    25,
    310
    );


  notification(
    25,
    340,
    "APDE",
    "Application started",
    0
    );


  notification(
    25,
    450,
    "SYSTEM",
    "Battery " + batteryPercent + "%",
    1
    );


  notification(
    25,
    560,
    "NETWORK",
    operatorName,
    2
    );


  notification(
    25,
    670,
    "WIFI",
    wifiName,
    3
    );
}


// =====================================================
// BATTERY
// =====================================================

void getBattery() {

  batteryPercent =
    battery.getIntProperty(
    BatteryManager.BATTERY_PROPERTY_CAPACITY
    );
}


void drawBattery(float x, float y) {

  stroke(255);
  strokeWeight(3);
  noFill();

  rect(x,y,55,28);

  rect(x+55,y+8,7,12);

  noStroke();

  float w =
    51.0 * batteryPercent / 100.0;

  fill(80,220,80);

  rect(x+2,y+2,w,24);

  fill(255);

  textSize(15);

  text(
    batteryPercent + "%",
    x,
    y+48
    );
}


// =====================================================
// SIGNAL
// =====================================================

void getNetwork() {

  try {

    operatorName =
      telephony.getNetworkOperatorName();

    if (operatorName == null)
      operatorName = "NO OPERATOR";

  } catch(Exception e) {

    operatorName = "NO SIGNAL";
  }


  try {

    WifiManager wm =
      (WifiManager)getActivity()
      .getApplicationContext()
      .getSystemService(Context.WIFI_SERVICE);

    WifiInfo wi =
      wm.getConnectionInfo();

    wifiName =
      wi.getSSID();

    if (wifiName == null)
      wifiName = "OFF";

  } catch(Exception e) {

    wifiName = "OFF";
  }
}


void drawSignal(float x, float y) {

  noStroke();

  for (int i=0; i<5; i++) {

    float h = 8 + i*7;

    if (i < signalLevel)
      fill(80,220,100);
    else
      fill(70);

    rect(
      x+i*11,
      y+35-h,
      8,
      h
      );
  }

  fill(255);
  textSize(14);

  text(
    "SIGNAL",
    x-5,
    y+55
    );
}


// =====================================================
// BUTTON
// =====================================================

void drawButton(
  float x,
  float y,
  float w,
  float h,
  String s) {

  fill(55,55,65);
  rect(x,y,w,h,15);

  fill(255);
  textSize(20);

  text(
    s,
    x+20,
    y+48
    );
}


// =====================================================
// NOTIFICATION
// =====================================================

void notification(
  float x,
  float y,
  String app,
  String message,
  int icon) {

  fill(45,45,55);
  rect(
    x,
    y,
    width-50,
    95,
    18
    );


  // APP ICON
  fill(
    70 + icon*40,
    100 + icon*20,
    200
    );

  ellipse(
    x+45,
    y+47,
    55,
    55
    );


  // APP NAME
  fill(255);
  textSize(20);

  text(
    app,
    x+85,
    y+35
    );


  // MESSAGE
  fill(200);
  textSize(17);

  text(
    message,
    x+85,
    y+65
    );
}
























