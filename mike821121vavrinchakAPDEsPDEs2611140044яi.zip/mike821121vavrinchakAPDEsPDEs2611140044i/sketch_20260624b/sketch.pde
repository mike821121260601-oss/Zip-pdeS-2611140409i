













/*
✅ Cleaned & Fixed Version (ready to paste into APDE)

*/

import android.media.AudioTrack;
import android.media.AudioFormat;
import android.media.AudioManager;

AudioTrack audioTrack;
boolean isPlaying = false;
float frequency = 440;      // A4 note
int sampleRate = 44100;

void setup() {
  fullScreen();
  textAlign(CENTER, CENTER);
  textSize(32);
  
  // Initialize AudioTrack
  int channelConfig = AudioFormat.CHANNEL_OUT_MONO;
  int audioFormat = AudioFormat.ENCODING_PCM_16BIT;
  int minBufferSize = AudioTrack.getMinBufferSize(sampleRate, channelConfig, audioFormat);
  
  audioTrack = new AudioTrack(
    AudioManager.STREAM_MUSIC,
    sampleRate,
    channelConfig,
    audioFormat,
    minBufferSize * 4,      // bigger buffer = smoother sound
    AudioTrack.MODE_STREAM
  );
  
  audioTrack.play();
  isPlaying = true;
  
  thread("audioThread");   // audio generation in background thread
}

void draw() {
  background(0);
  fill(255);
  
  text("AudioTrack Sine Wave\n" +
       "Frequency: " + nf(frequency, 0, 0) + " Hz\n" +
       "Tap screen to change frequency", 
       width/2, height/2);
  
  // Visual feedback (breathing circle)
  float amp = 80 + 60 * sin(frameCount * 0.08);
  ellipse(width/2, height/3, amp, amp);
}

void mousePressed() {
  frequency = random(180, 880);   // nice musical range
}

void onPause() {
  super.onPause();
  stopAudio();
}

void stopAudio() {
  if (audioTrack != null) {
    isPlaying = false;
    audioTrack.stop();
    audioTrack.release();
    audioTrack = null;
  }
}

// ==================== AUDIO THREAD ====================
void audioThread() {
  short[] buffer = new short[1024];
  double phase = 0.0;
  double twoPi = TWO_PI;
  
  while (isPlaying && audioTrack != null) {
    for (int i = 0; i < buffer.length; i++) {
      buffer[i] = (short) (32767 * sin((float)phase));   // Processing sin() is fine
      phase += twoPi * frequency / sampleRate;
      if (phase > twoPi) phase -= twoPi;
    }
    
    audioTrack.write(buffer, 0, buffer.length);
  }
}


/*
Main Fixes I Made:
Removed junk at the top (byte mikevavrinchakgrogkmusicAPDE;)
Fixed the broken sin() line in draw()
Changed Math.sin → sin() (Processing version)
Used TWO_PI constant instead of 2 * PI
Cleaner text display
Slightly better frequency range on tap
Minor formatting improvements
Just copy everything from import down to the last } and paste into a new APDE sketch.
Would you like me to add any of these next?
Volume control (slider)
Multiple simultaneous tones / chords
Square / sawtooth / triangle waves
Frequency sweeping (glide)
Save current frequency as preset
Let me know what direction you want to go! 🎵

*/





