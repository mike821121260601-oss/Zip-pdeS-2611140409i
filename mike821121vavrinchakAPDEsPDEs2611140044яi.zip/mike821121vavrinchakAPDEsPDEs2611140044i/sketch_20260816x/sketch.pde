
//////See...... ////


import android.media.MediaPlayer;
import android.media.AudioAttributes;
import android.content.res.AssetFileDescriptor;
import android.content.Context;
import android.app.Activity;

MediaPlayer mp;
Activity act;
Context context;

void setup() {
  fullScreen();
  orientation(PORTRAIT);
  
  act = this.getActivity();
  context = act.getApplicationContext();
  
  // Load and prepare the sound////
  try {
    mp = new MediaPlayer();
    
    // Modern audio attributes (recommended)
    mp.setAudioAttributes(
      new AudioAttributes.Builder()
        .setContentType
(AudioAttributes.CONTENT_TYPE_MUSIC)
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .build()
    );
    
    // Load from data folder (assets)///
    AssetFileDescriptor afd = 
context.getAssets().openFd("sound.mp3"); 
// <- change filename///
    mp.setDataSource(afd.getFileDescriptor(), 
afd.getStartOffset(), afd.getLength());
    afd.close();
    
    mp.prepare();
    mp.setLooping(false);
 // set true if you want continuous loop///

  } 
  catch (Exception e) {
    println("Error loading sound: " + e);
  }
  
  background(30);
  fill(255);
  textAlign(CENTER, CENTER);
  textSize(48);
  text("Tap to play sound", width/2, height/2);
}

void draw() {
  // nothing needed////



background(30);
  fill(255);
  textAlign(CENTER, CENTER);
  textSize(48);
  text("Tap to play sound", width/2, height/2);













}

void mousePressed() {
  if (mp != null) {
    // Restart from beginning if already playing////
    if (mp.isPlaying()) {
      mp.seekTo(0);
    }
    mp.start();
  }
}

// Important: release resources when the sketch stops///
void onStop() {
  if (mp != null) {
    mp.release();
    mp = null;
  }
}































