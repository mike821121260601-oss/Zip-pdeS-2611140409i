




/*

APDE / Processing (Android) – 3D Labyrinth with spheres that “walk” on walls
Here’s a complete, ready-to-run APDE sketch.
It creates a simple 3D labyrinth, places several spheres, and makes them slide along the walls (gravity + wall collision). You control one sphere with tilt or touch.
How to use in APDE
Create a new sketch.
Paste the code below into the main tab.
Run on a device (or emulator).
– Tilt the phone or drag on screen to move the player sphere.
– Other spheres wander and stick to walls.
// APDE / Processing – 3D Labyrinth with wall-walking spheres
// Controls: tilt phone or drag finger to move the blue sphere
*/









import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

SensorManager sensorManager;
float ax, ay;          // accelerometer

PVector playerPos;
PVector playerVel;
float playerR = 18;

ArrayList<Sphere> spheres = new ArrayList<Sphere>();
ArrayList<Wall> walls = new ArrayList<Wall>();

float camDist = 420;
float mazeSize = 400;
float wallH = 80;
float wallT = 12;

void setup() {
  fullScreen(P3D);
  orientation(LANDSCAPE);
  
  // accelerometer
  sensorManager = (SensorManager) getActivity().getSystemService(Context.SENSOR_SERVICE);
  Sensor accel = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
  sensorManager.registerListener(new SensorEventListener() {
    public void onSensorChanged(SensorEvent e) {
      ax = e.values[0];
      ay = e.values[1];
    }
    public void onAccuracyChanged(Sensor s, int a) {}
  }, accel, SensorManager.SENSOR_DELAY_GAME);
  
  // player
  playerPos = new PVector(0, 0, 0);
  playerVel = new PVector();
  
  // build simple labyrinth walls
  buildMaze();
  
  // wandering spheres
  for (int i = 0; i < 6; i++) {
    spheres.add(new Sphere(
      random(-mazeSize*0.4, mazeSize*0.4),
      random(-mazeSize*0.4, mazeSize*0.4),
      random(playerR, wallH-playerR)
    ));
  }
}

void draw() {
  background(15, 18, 30);
  lights();
  ambientLight(40, 40, 55);
  directionalLight(180, 180, 200, -0.4, 0.6, -0.5);
  
  // camera follows player
  camera(playerPos.x, playerPos.y - camDist*0.55, playerPos.z + camDist,
         playerPos.x, playerPos.y, playerPos.z,
         0, 1, 0);
  
  // floor
  pushMatrix();
  translate(0, wallH + 2, 0);
  fill(30, 35, 50);
  noStroke();
  box(mazeSize*2.2, 4, mazeSize*2.2);
  popMatrix();
  
  // walls
  for (Wall w : walls) w.display();
  
  // player physics
  updatePlayer();
  
  // other spheres
  for (Sphere s : spheres) {
    s.update();
    s.display();
  }
  
  // player sphere
  pushMatrix();
  translate(playerPos.x, playerPos.y, playerPos.z);
  fill(60, 160, 255);
  noStroke();
  sphere(playerR);
  popMatrix();
  
  // HUD
  camera(); // 2-D overlay
  hint(DISABLE_DEPTH_TEST);
  fill(220);
  textSize(28);
  text("Tilt / Drag to move • Spheres walk on walls", 30, 50);
  hint(ENABLE_DEPTH_TEST);
}

void updatePlayer() {
  // tilt or touch
  float forceX = -ax * 0.45;
  float forceZ =  ay * 0.45;
  
  if (mousePressed) {
    forceX += (mouseX - width/2) * 0.0008;
    forceZ += (mouseY - height/2) * 0.0008;
  }
  
  playerVel.x += forceX;
  playerVel.z += forceZ;
  playerVel.y += 0.35;               // gravity
  
  playerVel.mult(0.92);              // friction
  
  playerPos.add(playerVel);
  
  // floor
  if (playerPos.y > wallH - playerR) {
    playerPos.y = wallH - playerR;
    playerVel.y *= -0.35;
  }
  
  // collide with walls
  for (Wall w : walls) {
    w.collide(playerPos, playerVel, playerR);
  }
  
  // keep inside outer box
  float lim = mazeSize - playerR - 5;
  playerPos.x = constrain(playerPos.x, -lim, lim);
  playerPos.z = constrain(playerPos.z, -lim, lim);
}

void buildMaze() {
  // outer walls
  walls.add(new Wall(-mazeSize, 0, 0, wallT, wallH, mazeSize*2));
  walls.add(new Wall( mazeSize, 0, 0, wallT, wallH, mazeSize*2));
  walls.add(new Wall(0, 0, -mazeSize, mazeSize*2, wallH, wallT));
  walls.add(new Wall(0, 0,  mazeSize, mazeSize*2, wallH, wallT));
  
  // inner corridors (simple labyrinth pattern)
  float s = mazeSize * 0.55;
  walls.add(new Wall(-s*0.5, 0, 0, wallT, wallH, s*1.4));
  walls.add(new Wall( s*0.5, 0, 0, wallT, wallH, s*1.4));
  walls.add(new Wall(0, 0, -s*0.6, s*1.1, wallH, wallT));
  walls.add(new Wall(0, 0,  s*0.6, s*1.1, wallH, wallT));
  walls.add(new Wall(-s*0.25, 0, s*0.3, wallT, wallH, s*0.7));
  walls.add(new Wall( s*0.25, 0, -s*0.3, wallT, wallH, s*0.7));
}

// ---------- Wall class ----------
class Wall {
  float x, y, z, w, h, d;
  
  Wall(float x, float y, float z, float w, float h, float d) {
    this.x = x; this.y = y; this.z = z;
    this.w = w; this.h = h; this.d = d;
  }
  
  void display() {
    pushMatrix();
    translate(x, y + h/2, z);
    fill(70, 85, 110);
    stroke(40, 50, 70);
    strokeWeight(1);
    box(w, h, d);
    popMatrix();
  }
  
  // simple AABB collision that keeps sphere on the surface
  void collide(PVector pos, PVector vel, float r) {
    float hw = w/2 + r;
    float hh = h/2 + r;
    float hd = d/2 + r;
    
    float dx = pos.x - x;
    float dy = pos.y - (y + h/2);
    float dz = pos.z - z;
    
    if (abs(dx) < hw && abs(dy) < hh && abs(dz) < hd) {
      // push out on the axis of least penetration
      float px = hw - abs(dx);
      float py = hh - abs(dy);
      float pz = hd - abs(dz);
      
      if (px < py && px < pz) {
        pos.x += (dx > 0 ? px : -px);
        vel.x *= -0.4;
        // stick a little to the wall
        vel.y *= 0.85;
        vel.z *= 0.85;
      } else if (pz < py) {
        pos.z += (dz > 0 ? pz : -pz);
        vel.z *= -0.4;
        vel.x *= 0.85;
        vel.y *= 0.85;
      } else {
        pos.y += (dy > 0 ? py : -py);
        vel.y *= -0.35;
      }
    }
  }
}

// ---------- Wandering sphere that prefers walls ----------
class Sphere {
  PVector pos, vel;
  float r = 14;
  color col;
  
  Sphere(float x, float y, float z) {
    pos = new PVector(x, y, z);
    vel = PVector.random3D().mult(random(1.5, 3.5));
    col = color(random(120, 255), random(80, 180), random(100, 220));
  }
  
  void update() {
    vel.y += 0.28;                 // gravity
    vel.mult(0.97);
    
    // random walk impulse
    if (random(1) < 0.03) {
      vel.add(PVector.random3D().mult(1.8));
    }
    
    pos.add(vel);
    
    // floor
    if (pos.y > wallH - r) {
      pos.y = wallH - r;
      vel.y *= -0.4;
      // try to crawl along walls
      if (random(1) < 0.4) vel.x += random(-2, 2);
      if (random(1) < 0.4) vel.z += random(-2, 2);
    }
    
    for (Wall w : walls) {
      w.collide(pos, vel, r);
    }
    
    // outer bounds
    float lim = mazeSize - r - 4;
    pos.x = constrain(pos.x, -lim, lim);
    pos.z = constrain(pos.z, -lim, lim);
  }
  
  void display() {
    pushMatrix();
    translate(pos.x, pos.y, pos.z);
    fill(col);
    noStroke();
    sphere(r);
    popMatrix();
  }
}




/*
Notes / possible improvements
The collision is a simple AABB push-out so spheres stay on the surface of walls and can “walk” along them.
You can add more walls in buildMaze() to make a denser labyrinth.
For a pure maze-runner style, replace the free-moving player with grid-based movement.
If you want pure “spheres only walk on walls” (no free falling), increase the wall-stick friction and reduce gravity when a collision is detected.
Just copy-paste into APDE and run.
Enjoy the 3D labyrinth!
*/








