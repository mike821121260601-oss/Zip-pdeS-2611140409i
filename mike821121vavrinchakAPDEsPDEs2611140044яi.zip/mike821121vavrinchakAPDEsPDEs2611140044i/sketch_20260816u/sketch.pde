


// APDE / Processing Android – 9×14 random tone-pad
// Each key has its own exclusive frequency band (1 kHz – 21 kHz divided by 126)
// 15 s sweeps, volume 10↔90 %, safe concurrent limit

import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;

int cols = 14;
int rows = 9;
float cellW, cellH;

final int MAX_CONCURRENT = 12;
int activeTracks = 0;

// Frequency division
final float FREQ_MIN = 1000;
final float FREQ_MAX = 21000;
final float TOTAL_SPAN = FREQ_MAX - FREQ_MIN;          // 20000 Hz
final int   TOTAL_KEYS = cols * rows;                   // 126
final float BAND_WIDTH = TOTAL_SPAN / TOTAL_KEYS;       // ≈ 158.73 Hz

void setup() {
  fullScreen();
  orientation(LANDSCAPE);
  cellW = width  / (float)cols;
  cellH = height / (float)rows;
  textAlign(CENTER, CENTER);
  textSize(16);
}

void draw() {
  background(20);
  
  for (int y = 0; y < rows; y++) {
    for (int x = 0; x < cols; x++) {
      float px = x * cellW;
      float py = y * cellH;
      
      int keyIndex = y * cols + x;                     // 0 … 125
      
      if (mousePressed && mouseX > px && mouseX < px+cellW &&
                           mouseY > py && mouseY < py+cellH) {
        fill(80, 180, 255);
      } else {
        fill(40 + (x+y)%3 * 15);
      }
      stroke(90);
      rect(px+1, py+1, cellW-2, cellH-2, 6);
      
      // show key number + approximate center frequency
      float centerHz = FREQ_MIN + (keyIndex + 0.5) * BAND_WIDTH;
      fill(220);
      text(keyIndex+1 + "\n" + nf(centerHz/1000, 1, 1) + "k", 
           px + cellW/2, py + cellH/2);
    }
  }
  
  fill(255, 200, 50);
  text("Active: " + activeTracks + " / " + MAX_CONCURRENT, width/2, 28);
}

void mousePressed() {
  int col = constrain((int)(mouseX / cellW), 0, cols-1);
  int row = constrain((int)(mouseY / cellH), 0, rows-1);
  int keyIndex = row * cols + col;                    // 0 … 125
  
  // This key’s private frequency band
  float bandStart = FREQ_MIN + keyIndex * BAND_WIDTH;
  float bandEnd   = bandStart + BAND_WIDTH;
  
  // Fire up to 9 random sweeps inside THIS key’s band only
  for (int i = 0; i < 9; i++) {
    
    synchronized(this) {
      if (activeTracks >= MAX_CONCURRENT) continue;
      activeTracks++;
    }
    
    float f1 = random(bandStart, bandEnd);
    float f2 = random(bandStart, bandEnd);
    boolean volUp = random(1) > 0.5;
    
    playSweep(f1, f2, volUp, 15.0);
  }
}

void playSweep(final float startHz, final float endHz,
               final boolean volumeRising, final float durationSec) {
  
  new Thread(new Runnable() {
    public void run() {
      AudioTrack track = null;
      try {
        int sampleRate = 44100;
        int numSamples = (int)(durationSec * sampleRate);
        short[] buffer = new short[numSamples];
        
        float volStart = volumeRising ? 0.10f : 0.90f;
        float volEnd   = volumeRising ? 0.90f : 0.10f;
        
        for (int i = 0; i < numSamples; i++) {
          float t = i / (float)sampleRate;
          float progress = i / (float)(numSamples - 1);
          
          float freq = lerp(startHz, endHz, progress);
          float amp  = lerp(volStart, volEnd, progress);
          
          float sample = (float)(Math.sin(2 * Math.PI * freq * t) * amp);
          buffer[i] = (short)(sample * 32767);
        }
        
        track = new AudioTrack(
            AudioManager.STREAM_MUSIC,
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            buffer.length * 2,
            AudioTrack.MODE_STATIC);
        
        track.write(buffer, 0, buffer.length);
        track.play();
        
        Thread.sleep((long)(durationSec * 1000) + 80);
        
      } catch (Exception e) {
      } finally {
        if (track != null) {
          try { track.stop(); track.release(); } catch (Exception e) {}
        }
        synchronized(this) {
          activeTracks = max(0, activeTracks - 1);
        }
      }
    }
  }).start();
}






























