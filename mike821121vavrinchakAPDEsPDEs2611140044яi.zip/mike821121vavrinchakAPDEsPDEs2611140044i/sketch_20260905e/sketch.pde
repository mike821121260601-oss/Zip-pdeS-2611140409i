






// 3D Череп з точок
// Обертання: тягни пальцем/мишею

ArrayList<PVector> points = new ArrayList<PVector>();
float rotX = 0, rotY = 0;

void setup() {
  fullScreen(P3D);
  background(0);
  noStroke();
  
  // Генеруємо точки на поверхні черепа
  generateSkullPoints();
}

void generateSkullPoints() {
  // Черепна коробка (велика сфера)
  generateSpherePoints(0, 0, 0, 120, 2500);
  
  // Нижня щелепа (менша сфера, зміщена вниз і вперед)
  generateSpherePoints(0, -80, 30, 70, 1200);
  
  // Виличні кістки (дві маленькі сфери)
  generateSpherePoints(-50, -10, 60, 30, 300);
  generateSpherePoints(50, -10, 60, 30, 300);
}

void generateSpherePoints(float cx, float cy, float cz, float r, int count) {
  for (int i = 0; i < count; i++) {
    // Випадкова точка на сфері
    float theta = random(TWO_PI);
    float phi = acos(random(-1, 1));
    float x = cx + r * sin(phi) * cos(theta);
    float y = cy + r * sin(phi) * sin(theta);
    float z = cz + r * cos(phi);
    
    // Перевірка: виключаємо точки всередині очних ямок і носа
    if (isEyeSocket(x, y, z) || isNose(x, y, z)) {
      continue; // пропускаємо цю точку
    }
    points.add(new PVector(x, y, z));
  }
}

boolean isEyeSocket(float x, float y, float z) {
  // Ліва очна ямка
  float d1 = dist(x, y, z, -45, 10, 80);
  // Права очна ямка
  float d2 = dist(x, y, z, 45, 10, 80);
  return (d1 < 30 || d2 < 30);
}

boolean isNose(float x, float y, float z) {
  // Носова порожнина
  float d = dist(x, y, z, 0, -20, 100);
  return (d < 20);
}

void draw() {
  background(0);
  
  // Обертання від миші/пальця
  if (mousePressed) {
    rotY += (mouseX - pmouseX) * 0.01;
    rotX += (mouseY - pmouseY) * 0.01;
  }
  
  translate(width/2, height/2);
  rotateX(rotX);
  rotateY(rotY);
  
  // Малюємо точки
  stroke(200);
  strokeWeight(2);
  beginShape(POINTS);
  for (PVector p : points) {
    vertex(p.x, p.y, p.z);
  }
  endShape();
}