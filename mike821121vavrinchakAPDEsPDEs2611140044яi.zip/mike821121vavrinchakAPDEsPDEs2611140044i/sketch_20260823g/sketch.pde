


/*
  FRUIT-STYLE CHESS
  APDE 0.5.3 / Processing Android

  ONE .PDE FILE
  NO OPENING BOOK
  FRUIT WHITE vs FRUIT BLACK

  NOTE:
  This is a compact Java/Processing chess engine implementation
  designed to run directly inside APDE.
*/

int err=0;



final int EMPTY = 0;

final int WP = 1;
final int WN = 2;
final int WB = 3;
final int WR = 4;
final int WQ = 5;
final int WK = 6;

final int BP = -1;
final int BN = -2;
final int BB = -3;
final int BR = -4;
final int BQ = -5;
final int BK = -6;

int[] board = new int[64];

boolean whiteTurn = true;
boolean running = false;
boolean thinking = false;

int searchDepth = 3;

String lastMove = "";
String statusText = "READY";

ArrayList<String> gameMoves = new ArrayList<String>();

int selectedSquare = -1;

long nodes = 0;

int epSquare = -1;

boolean wCastleK = true;
boolean wCastleQ = true;
boolean bCastleK = true;
boolean bCastleQ = true;

int[] pieceValue = {
  0, 100, 320, 330, 500, 900, 20000
};

// ------------------------------------------------------------
// TRANSPOSITION TABLE
// ------------------------------------------------------------

class HashEntry {
  long key;
  int depth;
  int score;
  String move;
  int flag;

  HashEntry(long k, int d, int s, String m, int f) {
    key = k;
    depth = d;
    score = s;
    move = m;
    flag = f;
  }
}

HashMap<Long, HashEntry> hashTable =
  new HashMap<Long, HashEntry>();

// ------------------------------------------------------------
// MOVE
// ------------------------------------------------------------

class Move {
  int from;
  int to;
  int promotion;
  boolean castle;
  boolean ep;

  Move(int f, int t) {
    from = f;
    to = t;
    promotion = 0;
    castle = false;
    ep = false;
  }

  Move copy() {
    Move m = new Move(from, to);
    m.promotion = promotion;
    m.castle = castle;
    m.ep = ep;
    return m;
  }
}

// ------------------------------------------------------------
// POSITION STATE
// ------------------------------------------------------------

class State {
  int captured;
  int oldEp;
  boolean oldWK;
  boolean oldWQ;
  boolean oldBK;
  boolean oldBQ;
}

State makeMove(Move m) {

  State s = new State();

  s.captured = board[m.to];
  s.oldEp = epSquare;

  s.oldWK = wCastleK;
  s.oldWQ = wCastleQ;
  s.oldBK = bCastleK;
  s.oldBQ = bCastleQ;

  int p = board[m.from];

  // en passant capture
  if (m.ep) {

    if (p == WP) {
      s.captured = board[m.to - 8];
      board[m.to - 8] = EMPTY;
    }

    if (p == BP) {
      s.captured = board[m.to + 8];
      board[m.to + 8] = EMPTY;
    }
  }

  board[m.to] = board[m.from];
  board[m.from] = EMPTY;

  // promotion
  if (m.promotion != 0) {

    if (p > 0)
      board[m.to] = m.promotion;

    else
      board[m.to] = -m.promotion;
  }

  // pawn double move
  epSquare = -1;

  if (p == WP && m.to - m.from == 16)
    epSquare = m.from + 8;

  if (p == BP && m.from - m.to == 16)
    epSquare = m.from - 8;

  // castling
  if (m.castle) {

    if (m.to == 6) {
      board[5] = WR;
      board[7] = EMPTY;
    }

    if (m.to == 2) {
      board[3] = WR;
      board[0] = EMPTY;
    }

    if (m.to == 62) {
      board[61] = BR;
      board[63] = EMPTY;
    }

    if (m.to == 58) {
      board[59] = BR;
      board[56] = EMPTY;
    }
  }

  updateCastling(p, m.from, m.to);

  return s;
}

void undoMove(Move m, State s) {

  int p = board[m.to];

  // undo castle rook
  if (m.castle) {

    if (m.to == 6) {
      board[7] = WR;
      board[5] = EMPTY;
    }

    if (m.to == 2) {
      board[0] = WR;
      board[3] = EMPTY;
    }

    if (m.to == 62) {
      board[63] = BR;
      board[61] = EMPTY;
    }

    if (m.to == 58) {
      board[56] = BR;
      board[59] = EMPTY;
    }
  }

  board[m.from] = p;

  // undo promotion
  if (m.promotion != 0) {

    if (p > 0)
      board[m.from] = WP;
    else
      board[m.from] = BP;
  }

  board[m.to] = s.captured;

  if (m.ep) {

    if (p > 0)
      board[m.to - 8] = BP;

    else
      board[m.to + 8] = WP;
  }

  epSquare = s.oldEp;

  wCastleK = s.oldWK;
  wCastleQ = s.oldWQ;
  bCastleK = s.oldBK;
  bCastleQ = s.oldBQ;
}

void updateCastling(int p, int from, int to) {

  if (p == WK) {
    wCastleK = false;
    wCastleQ = false;
  }

  if (p == BK) {
    bCastleK = false;
    bCastleQ = false;
  }

  if (from == 0 || to == 0)
    wCastleQ = false;

  if (from == 7 || to == 7)
    wCastleK = false;

  if (from == 56 || to == 56)
    bCastleQ = false;

  if (from == 63 || to == 63)
    bCastleK = false;
}

// ------------------------------------------------------------
// START POSITION
// ------------------------------------------------------------

void newGame() {

  String fen =
    "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR";

  loadFEN(fen);

  whiteTurn = true;
  running = false;
  thinking = false;

  gameMoves.clear();

  lastMove = "";
  statusText = "READY";

  selectedSquare = -1;

  hashTable.clear();

  redraw();
}

// ------------------------------------------------------------
// FEN
// ------------------------------------------------------------

void loadFEN(String fen) {

  for (int i = 0; i < 64; i++)
    board[i] = EMPTY;

  String[] a = split(fen, ' ');

  String[] rows = split(a[0], '/');

  for (int r = 0; r < 8; r++) {

    int file = 0;

    for (int i = 0; i < rows[r].length(); i++) {

      char c = rows[r].charAt(i);

      if (c >= '1' && c <= '8') {

        file += c - '0';

      } else {

        board[(7-r)*8 + file] = charPiece(c);

        file++;
      }
    }
  }

  whiteTurn = true;

  if (a.length > 1)
    whiteTurn = a[1].equals("w");

  wCastleK = false;
  wCastleQ = false;
  bCastleK = false;
  bCastleQ = false;

  if (a.length > 2) {

    String cs = a[2];

    wCastleK = cs.indexOf('K') >= 0;
    wCastleQ = cs.indexOf('Q') >= 0;
    bCastleK = cs.indexOf('k') >= 0;
    bCastleQ = cs.indexOf('q') >= 0;
  }

  epSquare = -1;

  if (a.length > 3 && !a[3].equals("-"))
    epSquare = squareFromString(a[3]);
}

int charPiece(char c) {

  if (c == 'P') return WP;
  if (c == 'N') return WN;
  if (c == 'B') return WB;
  if (c == 'R') return WR;
  if (c == 'Q') return WQ;
  if (c == 'K') return WK;

  if (c == 'p') return BP;
  if (c == 'n') return BN;
  if (c == 'b') return BB;
  if (c == 'r') return BR;
  if (c == 'q') return BQ;
  if (c == 'k') return BK;

  return EMPTY;
}

// ------------------------------------------------------------
// MOVE GENERATION
// ------------------------------------------------------------

ArrayList<Move> generateLegalMoves(boolean white) {

  ArrayList<Move> list = generatePseudoMoves(white);

  ArrayList<Move> legal = new ArrayList<Move>();

  for (Move m : list) {

    State s = makeMove(m);

    boolean check = inCheck(white);

    undoMove(m, s);

    if (!check)
      legal.add(m);
  }

  return legal;
}

ArrayList<Move> generatePseudoMoves(boolean white) {

  ArrayList<Move> list = new ArrayList<Move>();

  for (int sq = 0; sq < 64; sq++) {

    int p = board[sq];

    if (p == EMPTY)
      continue;

    if (white && p < 0)
      continue;

    if (!white && p > 0)
      continue;

    int type = abs(p);

    if (type == 1)
      pawnMoves(sq, white, list);

    else if (type == 2)
      knightMoves(sq, white, list);

    else if (type == 3)
      bishopMoves(sq, white, list);

    else if (type == 4)
      rookMoves(sq, white, list);

    else if (type == 5) {
      bishopMoves(sq, white, list);
      rookMoves(sq, white, list);
    }

    else if (type == 6)
      kingMoves(sq, white, list);
  }

  return list;
}

void addMove(ArrayList<Move> list,
             int from,
             int to,
             boolean white) {

  if (to < 0 || to >= 64)
    return;

  int target = board[to];

  if (target != EMPTY) {

    if (white && target > 0)
      return;

    if (!white && target < 0)
      return;

    if (abs(target) == 6)
      return;
  }

  list.add(new Move(from, to));
}

void pawnMoves(int sq,
               boolean white,
               ArrayList<Move> list) {

  int r = sq / 8;
  int f = sq % 8;

  int dir = white ? 8 : -8;

  int one = sq + dir;

  if (one >= 0 && one < 64 && board[one] == EMPTY) {

    if ((white && one / 8 == 7) ||
        (!white && one / 8 == 0)) {

      addPromotionMoves(list, sq, one);

    } else {

      addMove(list, sq, one, white);
    }

    int startRank = white ? 1 : 6;

    int two = sq + dir * 2;

    if (r == startRank &&
        board[two] == EMPTY)
      addMove(list, sq, two, white);
  }

  for (int df = -1; df <= 1; df += 2) {

    int nf = f + df;

    if (nf < 0 || nf > 7)
      continue;

    int to = sq + dir + df;

    if (to < 0 || to >= 64)
      continue;

    if (board[to] != EMPTY) {

      if ((white && board[to] < 0) ||
          (!white && board[to] > 0)) {

        if ((white && to / 8 == 7) ||
            (!white && to / 8 == 0))

          addPromotionMoves(list, sq, to);

        else

          addMove(list, sq, to, white);
      }
    }

    if (to == epSquare) {

      Move m = new Move(sq, to);
      m.ep = true;
      list.add(m);
    }
  }
}

void addPromotionMoves(ArrayList<Move> list,
                       int from,
                       int to) {

  int[] p = {5, 4, 3, 2};

  for (int i = 0; i < p.length; i++) {

    Move m = new Move(from, to);
    m.promotion = p[i];

    list.add(m);
  }
}

void knightMoves(int sq,
                 boolean white,
                 ArrayList<Move> list) {

  int r = sq / 8;
  int f = sq % 8;

  int[] dr = {-2,-2,-1,-1,1,1,2,2};
  int[] df = {-1,1,-2,2,-2,2,-1,1};

  for (int i = 0; i < 8; i++) {

    int nr = r + dr[i];
    int nf = f + df[i];

    if (nr >= 0 && nr < 8 &&
        nf >= 0 && nf < 8)

      addMove(list, sq, nr*8+nf, white);
  }
}

void bishopMoves(int sq,
                 boolean white,
                 ArrayList<Move> list) {

  slide(sq, white, list, 1, 1);
  slide(sq, white, list, 1, -1);
  slide(sq, white, list, -1, 1);
  slide(sq, white, list, -1, -1);
}

void rookMoves(int sq,
               boolean white,
               ArrayList<Move> list) {

  slide(sq, white, list, 1, 0);
  slide(sq, white, list, -1, 0);
  slide(sq, white, list, 0, 1);
  slide(sq, white, list, 0, -1);
}

void slide(int sq,
           boolean white,
           ArrayList<Move> list,
           int dr,
           int df) {

  int r = sq / 8;
  int f = sq % 8;

  int nr = r + dr;
  int nf = f + df;

  while (nr >= 0 && nr < 8 &&
         nf >= 0 && nf < 8) {

    int to = nr*8 + nf;

    if (board[to] == EMPTY) {

      list.add(new Move(sq, to));

    } else {

      if ((white && board[to] < 0) ||
          (!white && board[to] > 0)) {

        if (abs(board[to]) != 6)
          list.add(new Move(sq, to));
      }

      break;
    }

    nr += dr;
    nf += df;
  }
}

void kingMoves(int sq,
               boolean white,
               ArrayList<Move> list) {

  int r = sq / 8;
  int f = sq % 8;

  for (int dr = -1; dr <= 1; dr++) {

    for (int df = -1; df <= 1; df++) {

      if (dr == 0 && df == 0)
        continue;

      int nr = r + dr;
      int nf = f + df;

      if (nr >= 0 && nr < 8 &&
          nf >= 0 && nf < 8)

        addMove(list, sq, nr*8+nf, white);
    }
  }

  // WHITE CASTLING

  if (white && sq == 4) {

    if (wCastleK &&
        board[5] == EMPTY &&
        board[6] == EMPTY &&
        !squareAttacked(4, false) &&
        !squareAttacked(5, false) &&
        !squareAttacked(6, false)) {

      Move m = new Move(4,6);
      m.castle = true;
      list.add(m);
    }

    if (wCastleQ &&
        board[3] == EMPTY &&
        board[2] == EMPTY &&
        board[1] == EMPTY &&
        !squareAttacked(4, false) &&
        !squareAttacked(3, false) &&
        !squareAttacked(2, false)) {

      Move m = new Move(4,2);
      m.castle = true;
      list.add(m);
    }
  }

  // BLACK CASTLING

  if (!white && sq == 60) {

    if (bCastleK &&
        board[61] == EMPTY &&
        board[62] == EMPTY &&
        !squareAttacked(60, true) &&
        !squareAttacked(61, true) &&
        !squareAttacked(62, true)) {

      Move m = new Move(60,62);
      m.castle = true;
      list.add(m);
    }

    if (bCastleQ &&
        board[59] == EMPTY &&
        board[58] == EMPTY &&
        board[57] == EMPTY &&
        !squareAttacked(60, true) &&
        !squareAttacked(59, true) &&
        !squareAttacked(58, true)) {

      Move m = new Move(60,58);
      m.castle = true;
      list.add(m);
    }
  }
}

// ------------------------------------------------------------
// CHECK
// ------------------------------------------------------------

boolean inCheck(boolean white) {

  int king = white ? WK : BK;

  int sq = -1;

  for (int i = 0; i < 64; i++) {

    if (board[i] == king) {
      sq = i;
      break;
    }
  }

  if (sq < 0)
    return true;

  return squareAttacked(sq, !white);
}

boolean squareAttacked(int sq,
                       boolean byWhite) {

  int r = sq / 8;
  int f = sq % 8;

  // pawns

  if (byWhite) {

    if (r > 0) {

      if (f > 0 && board[sq-9] == WP)
        return true;

      if (f < 7 && board[sq-7] == WP)
        return true;
    }

  } else {

    if (r < 7) {

      if (f > 0 && board[sq+7] == BP)
        return true;

      if (f < 7 && board[sq+9] == BP)
        return true;
    }
  }

  // knights

  int[] dr = {-2,-2,-1,-1,1,1,2,2};
  int[] df = {-1,1,-2,2,-2,2,-1,1};

  for (int i = 0; i < 8; i++) {

    int nr = r + dr[i];
    int nf = f + df[i];

    if (nr >= 0 && nr < 8 &&
        nf >= 0 && nf < 8) {

      int p = board[nr*8+nf];

      if (byWhite && p == WN)
        return true;

      if (!byWhite && p == BN)
        return true;
    }
  }

  // king

  for (int rr = -1; rr <= 1; rr++) {

    for (int ff = -1; ff <= 1; ff++) {

      if (rr == 0 && ff == 0)
        continue;

      int nr = r + rr;
      int nf = f + ff;

      if (nr >= 0 && nr < 8 &&
          nf >= 0 && nf < 8) {

        int p = board[nr*8+nf];

        if (byWhite && p == WK)
          return true;

        if (!byWhite && p == BK)
          return true;
      }
    }
  }

  // bishop / queen

  if (rayAttack(sq, byWhite,
                1,1,WB,WQ))
    return true;

  if (rayAttack(sq, byWhite,
                1,-1,WB,WQ))
    return true;

  if (rayAttack(sq, byWhite,
                -1,1,WB,WQ))
    return true;

  if (rayAttack(sq, byWhite,
                -1,-1,WB,WQ))
    return true;

  // rook / queen

  if (rayAttack(sq, byWhite,
                1,0,WR,WQ))
    return true;

  if (rayAttack(sq, byWhite,
                -1,0,WR,WQ))
    return true;

  if (rayAttack(sq, byWhite,
                0,1,WR,WQ))
    return true;

  if (rayAttack(sq, byWhite,
                0,-1,WR,WQ))
    return true;

  return false;
}

boolean rayAttack(int sq,
                  boolean white,
                  int dr,
                  int df,
                  int piece,
                  int queen) {

  int r = sq / 8;
  int f = sq % 8;

  int nr = r + dr;
  int nf = f + df;

  while (nr >= 0 && nr < 8 &&
         nf >= 0 && nf < 8) {

    int p = board[nr*8+nf];

    if (p != EMPTY) {

      if (white) {

        if (p == piece || p == queen)
          return true;

      } else {

        if (p == -piece || p == -queen)
          return true;
      }

      return false;
    }

    nr += dr;
    nf += df;
  }

  return false;
}

// ------------------------------------------------------------
// EVALUATION
// ------------------------------------------------------------

int evaluate() {

  int score = 0;

  for (int sq = 0; sq < 64; sq++) {

    int p = board[sq];

    if (p == EMPTY)
      continue;

    int v = pieceValue[abs(p)];

    int r = sq / 8;
    int f = sq % 8;

    int center =
      14 - abs(3-r)*4 - abs(3-f)*4;

    if (abs(p) == 1)
      v += center * 2;

    if (abs(p) == 2)
      v += center * 3;

    if (abs(p) == 3)
      v += center * 2;

    if (abs(p) == 4)
      v += center;

    if (p > 0)
      score += v;

    else
      score -= v;
  }

  // mobility

  int whiteMob =
    generatePseudoMoves(true).size();

  int blackMob =
    generatePseudoMoves(false).size();

  score += (whiteMob - blackMob) * 2;

  return score;
}

// ------------------------------------------------------------
// SEARCH
// ------------------------------------------------------------

int searchRoot(boolean white,
               int depth) {

  ArrayList<Move> moves =
    generateLegalMoves(white);

  if (moves.size() == 0)
    return 0;

  Move best = moves.get(0);

  int bestScore =
    white ? -100000000 : 100000000;

  int alpha = -100000000;
  int beta = 100000000;

  for (int i = 0; i < moves.size(); i++) {

    Move m = moves.get(i);

    State s = makeMove(m);

    int score;

    if (white)
      score = alphaBeta(depth-1,
                        alpha,
                        beta,
                        false);

    else
      score = alphaBeta(depth-1,
                        alpha,
                        beta,
                        true);

    undoMove(m, s);

    if (white) {

      if (score > bestScore) {

        bestScore = score;
        best = m;
      }

      alpha = max(alpha, score);

    } else {

      if (score < bestScore) {

        bestScore = score;
        best = m;
      }

      beta = min(beta, score);
    }
  }

  lastSearchMove = moveToString(best);

  return bestScore;
}

String lastSearchMove = "";

int alphaBeta(int depth,
              int alpha,
              int beta,
              boolean white) {

  nodes++;

  if (depth <= 0)
    return quiescence(alpha, beta, white);

  ArrayList<Move> moves =
    generateLegalMoves(white);

  if (moves.size() == 0) {

    if (inCheck(white)) {

      if (white)
        return -1000000 - depth;

      else
        return 1000000 + depth;
    }

    return 0;
  }

  orderMoves(moves);

  if (white) {

    int best = -100000000;

    for (int i = 0; i < moves.size(); i++) {

      Move m = moves.get(i);

      State s = makeMove(m);

      int score =
        alphaBeta(depth-1,
                  alpha,
                  beta,
                  false);

      undoMove(m, s);

      best = max(best, score);
      alpha = max(alpha, score);

      if (alpha >= beta)
        break;
    }

    return best;

  } else {

    int best = 100000000;

    for (int i = 0; i < moves.size(); i++) {

      Move m = moves.get(i);

      State s = makeMove(m);

      int score =
        alphaBeta(depth-1,
                  alpha,
                  beta,
                  true);

      undoMove(m, s);

      best = min(best, score);
      beta = min(beta, score);

      if (alpha >= beta)
        break;
    }

    return best;
  }
}

int quiescence(int alpha,
               int beta,
               boolean white) {

  int stand = evaluate();

  if (white) {

    if (stand >= beta)
      return beta;

    if (stand > alpha)
      alpha = stand;

  } else {

    if (stand <= alpha)
      return alpha;

    if (stand < beta)
      beta = stand;
  }

  ArrayList<Move> moves =
    generateLegalMoves(white);

  for (int i = 0; i < moves.size(); i++) {

    Move m = moves.get(i);

    if (board[m.to] == EMPTY &&
        !m.ep)
      continue;

    State s = makeMove(m);

    int score =
      quiescence(alpha, beta, !white);

    undoMove(m, s);

    if (white) {

      if (score >= beta)
        return beta;

      alpha = max(alpha, score);

    } else {

      if (score <= alpha)
        return alpha;

      beta = min(beta, score);
    }
  }

  return white ? alpha : beta;
}

// ------------------------------------------------------------
// MOVE ORDER
// ------------------------------------------------------------

void orderMoves(ArrayList<Move> moves) {

  for (int i = 0; i < moves.size(); i++) {

    int best = i;

    int bestScore =
      moveScore(moves.get(i));

    for (int j = i+1; j < moves.size(); j++) {

      int s =
        moveScore(moves.get(j));

      if (s > bestScore) {

        bestScore = s;
        best = j;
      }
    }

    Move tmp = moves.get(i);

    moves.set(i, moves.get(best));
    moves.set(best, tmp);
  }
}

int moveScore(Move m) {

  int s = 0;

  if (board[m.to] != EMPTY)
    s += 1000 + pieceValue[abs(board[m.to])]
         - pieceValue[abs(board[m.from])]/10;

  if (m.promotion != 0)
    s += pieceValue[m.promotion];

  if (m.castle)
    s += 50;

  return s;
}

// ------------------------------------------------------------
// ENGINE MOVE
// ------------------------------------------------------------

void engineMove() {

  if (!running)
    return;

  thinking = true;

  statusText =
    whiteTurn ?
    "FRUIT WHITE THINKING" :
    "FRUIT BLACK THINKING";

  redraw();

  nodes = 0;
  lastSearchMove = "";

  searchRoot(whiteTurn, searchDepth);

  if (lastSearchMove.equals("")) {

    ArrayList<Move> lm =
      generateLegalMoves(whiteTurn);

    if (lm.size() == 0) {

      running = false;
      thinking = false;

      if (inCheck(whiteTurn))
        statusText = whiteTurn ?
          "BLACK CHECKMATE" :
          "WHITE CHECKMATE";
      else
        statusText = "DRAW";

      redraw();

      return;
    }
  }

  Move chosen =
    findMoveFromString(lastSearchMove);

  if (chosen == null) {

    running = false;
    thinking = false;

    statusText = "MOVE ERROR";

    redraw();

    return;
  }

  State s = makeMove(chosen);

  String text =
    moveToString(chosen);

  gameMoves.add(
    (whiteTurn ? "White " : "Black ") + text
  );

  lastMove = text;

  whiteTurn = !whiteTurn;

  thinking = false;

  statusText =
    "MOVE " + text +
    "  NODES " + nodes;

  redraw();

  delay(80);
}

Move findMoveFromString(String s) {

  ArrayList<Move> moves =
    generateLegalMoves(whiteTurn);

  for (int i = 0; i < moves.size(); i++) {

    if (moveToString(moves.get(i)).equals(s))
      return moves.get(i);
  }

  return null;
}

String moveToString(Move m) {

  String s =
    squareName(m.from) +
    squareName(m.to);

  if (m.promotion != 0) {

    if (m.promotion == 5)
      s += "q";

    else if (m.promotion == 4)
      s += "r";

    else if (m.promotion == 3)
      s += "b";

    else if (m.promotion == 2)
      s += "n";
  }

  return s;
}

String squareName(int sq) {

  int f = sq % 8;
  int r = sq / 8;

  return "" +
    (char)('a' + f) +
    (char)('1' + r);
}

int squareFromString(String s) {

  if (s.length() < 2)
    return -1;

  int f = s.charAt(0) - 'a';
  int r = s.charAt(1) - '1';

  if (f < 0 || f > 7 ||
      r < 0 || r > 7)
    return -1;

  return r*8 + f;
}

// ------------------------------------------------------------
// PROCESSING SETUP
// ------------------------------------------------------------

void setup() {

 /// orientation(PORTRAIT);

  size(displayWidth, displayHeight);

  textAlign(CENTER, CENTER);

  newGame();
}

void draw() {

  background(35);

  drawBoard();
  drawPieces();
  drawInterface();
}

// ------------------------------------------------------------
// BOARD
// ------------------------------------------------------------

void drawBoard() {

  float bs =
    min(width,

//// width
      height*0.9

) / 8.0;

  float ox = 0;
  float oy = 40;

  noStroke();

  for (int r = 0; r < 8; r++) {

    for (int f = 0; f < 8; f++) {

      if ((r+f)%2 == 0)
        fill(220);
      else
        fill(90);

      rect(
        ox + f*bs,
        oy + (7-r)*bs,
        bs,
        bs
      );
    }
  }

  if (selectedSquare >= 0) {

    int f = selectedSquare % 8;
    int r = selectedSquare / 8;

    fill(255,220,0,100);

    rect(
      ox + f*bs,
      oy + (7-r)*bs,
      bs,
      bs
    );
  }
}

// ------------------------------------------------------------
// PIECES
// ------------------------------------------------------------

void drawPieces() {

  float bs =
    min(width, 


///// width

height*0.9



) / 8.0;

  float ox = 0;
  float oy = 40;

  for (int sq = 0; sq < 64; sq++) {

    int p = board[sq];

    if (p == EMPTY)
      continue;

    int f = sq % 8;
    int r = sq / 8;

    float x =
      ox + f*bs + bs/2;

    float y =
      oy + (7-r)*bs + bs/2;

    drawPiece(p, x, y, bs);
  }
}

void drawPiece(int p,
               float x,
               float y,
               float bs) {

  boolean white = p > 0;

  int type = abs(p);

  stroke(white ? 20 : 240);
  strokeWeight(2);

  fill(white ? 245 : 20);

  if (type == 1) {

    ellipse(x,y,bs*.48,bs*.48);
    rectMode(CENTER);
    rect(x,y+bs*.16,bs*.40,bs*.22);
    rectMode(CORNER);
  }

  if (type == 2) {

    triangle(
      x-bs*.22,y+bs*.22,
      x+bs*.22,y+bs*.22,
      x,y-bs*.25
    );

    ellipse(
      x,y+bs*.25,
      bs*.42,bs*.18
    );
  }

  if (type == 3) {

    ellipse(x,y,bs*.55,bs*.55);

    line(
      x-bs*.18,y-bs*.20,
      x+bs*.18,y+bs*.20
    );

    line(
      x+bs*.18,y-bs*.20,
      x-bs*.18,y+bs*.20
    );
  }

  if (type == 4) {

    rectMode(CENTER);

    rect(
      x,y,
      bs*.52,
      bs*.55
    );

    rect(
      x,y-bs*.30,
      bs*.60,
      bs*.14
    );

    rectMode(CORNER);
  }

  if (type == 5) {

    ellipse(x,y,bs*.64,bs*.64);

    ellipse(
      x,
      y-bs*.20,
      bs*.28,
      bs*.28
    );

    line(
      x-bs*.20,y-bs*.20,
      x+bs*.20,y+bs*.20
    );

    line(
      x+bs*.20,y-bs*.20,
      x-bs*.20,y+bs*.20
    );
  }

  if (type == 6) {

    rectMode(CENTER);

    rect(
      x,y,
      bs*.58,
      bs*.58
    );

    line(
      x-bs*.16,y-bs*.20,
      x+bs*.16,y+bs*.20
    );

    line(
      x+bs*.16,y-bs*.20,
      x-bs*.16,y+bs*.20
    );

    rectMode(CORNER);
  }

  noStroke();
}

// ------------------------------------------------------------
// INTERFACE
// ------------------------------------------------------------

void drawInterface() {

  float y = 40 + width + 10
       - 40-width-10

     +min(width, height*0.9)
            ;

 y = 40 + width + 10- 40-width-10
 +min(width, height*0.9)
            ;
 y = 40 + width + 10- 40-width-10
 +min(width, height*0.9)
            ;

  fill(255); textSize(16 +11);

 text(" WHITE vs BLACK",width*0.1,22);

  textSize(14 +13);

  text(   statusText,
    width *0.263040442,   23 );

  text(
    "DEPTH " + searchDepth +
    "   LAST " + lastMove,
    width *0.43633,  21 );


















  // START
  fill(50,170,70);

  rect(10, y+65, width/3-15, 50 );

  fill(255);

  text("START", width/6, y+90);

  // STOP
  fill(180,60,60);

  rect( width/3+5, y+65, width/3-10, 50);

  fill(255);

  text(  "STOP", width/2, y+90 );

  // NEW
  fill(60,100,190);

  rect( width*2/3+5, y+65, width/3-15, 50 );

  fill(255);

  text( "NEW", width*5/6, y+90 );

  fill(255, 0,0,111);

  textSize(12);

  text(
    "Tap a piece and destination for human test",
    width*0.0555, 13 );














  int yy = (int)(height*0.9*0.02) ;

  textSize(11+5);  fill(255,255,122);

  int start = max(0, gameMoves.size()-8);

  for (int i = start; 
   i < gameMoves.size(); i++) {

    text(  gameMoves.get(i),
      width*0.7, 16  +float(yy-yy+yy) 
    );

    yy += 16;
  }
}

// ------------------------------------------------------------
// TOUCH
// ------------------------------------------------------------

void mousePressed() {






///////
  rect(width*0.0, 0.0,width*0.21,height*0.021);



  
float bs =(float)
(min( width, height*0.9)) / 8.0;
float bs1 =(float)
(min( width, height*0.9)) / 8.0;
  float bs2 =(float)
(min( width, height*0.9)) / 8.0;

  // buttons////////3/////////

   float boardY = min(width, height *0.9) ;

  float by = boardY + width -width+ 75-75;
   by=by+bs2-bs2+bs1-bs1;


  if (mouseY >= by*1.0841 &&
      mouseY <= by*1.12 ) {

    if (mouseX < width/3) {

      running = true;
      statusText = "START";
 rect(5,5, width/3,105);

    } else if 
   (  (mouseX < width*2/3) &&
 (mouseX > width*1/3)) 

{
      rect(222,333,355,555);
      running = false;
      statusText = "STOP";

    } else {

       rect(111,333,155,455);


      newGame();
    }

    return;
  }












  // board touch

  if (mouseY >= by*0.05 &&
      mouseY < by) {

//// Activity.setRequestedOrientation. ////

    rect(width*0.4,height*0.4
     ,width*0.45,height*0.45);

    int f =
      constrain((int)(mouseX/bs),0,7);

    int visualRank =
      constrain((int)((mouseY-boardY)/bs),0,7);

    int r = 7-visualRank;

    int sq = r*8+f;

    if (selectedSquare < 0) {

      if (board[sq] != EMPTY &&
          ((whiteTurn && board[sq] > 0) ||
           (!whiteTurn && board[sq] < 0))) {

        selectedSquare = sq;
      }

    } else {

      Move m =
        findMove(selectedSquare, sq);

      if (m != null && !thinking) {

        makeMove(m);

        lastMove =
          moveToString(m);

        gameMoves.add(
          (whiteTurn ? "White " : "Black ") +
          lastMove
        );

        whiteTurn = !whiteTurn;

        selectedSquare = -1;

        redraw();
      }

      else {

        selectedSquare = -1;
      }
    }
  }
}

Move findMove(int from,
              int to) {

  ArrayList<Move> moves =
    generateLegalMoves(whiteTurn);






  //if p////errdeletecode////If p//////

  for (int i = 0; i < moves.size(); i++) {

    Move m = moves.get(i);

    if (m.from == from &&
        m.to == to)

      return m;
  }

  return null;
}

// ------------------------------------------------------------
// CONTINUOUS ENGINE PLAY
// ------------------------------------------------------------

void onLoop() {

  if (running && !thinking) {

    engineMove();


       rect(233,333,344,444);  



  }
}

// APDE / Processing draw loop helper

void drawEngineTick() {

  if (running && !thinking) {

    engineMove();

     rect(333,333,444,444);





  }
}












/*











/*
  FRUIT-STYLE CHESS
  APDE 0.5.3 / Processing Android

  ONE .PDE FILE
  NO OPENING BOOK
  FRUIT WHITE vs FRUIT BLACK

  NOTE:
  This is a compact Java/Processing chess engine implementation
  designed to run directly inside APDE.
*/

final int EMPTY = 0;

final int WP = 1;
final int WN = 2;
final int WB = 3;
final int WR = 4;
final int WQ = 5;
final int WK = 6;

final int BP = -1;
final int BN = -2;
final int BB = -3;
final int BR = -4;
final int BQ = -5;
final int BK = -6;

int[] board = new int[64];

boolean whiteTurn = true;
boolean running = false;
boolean thinking = false;

int searchDepth = 3;

String lastMove = "";
String statusText = "READY";

ArrayList<String> gameMoves = new ArrayList<String>();

int selectedSquare = -1;

long nodes = 0;

int epSquare = -1;

boolean wCastleK = true;
boolean wCastleQ = true;
boolean bCastleK = true;
boolean bCastleQ = true;

int[] pieceValue = {
  0, 100, 320, 330, 500, 900, 20000
};

// ------------------------------------------------------------
// TRANSPOSITION TABLE
// ------------------------------------------------------------

class HashEntry {
  long key;
  int depth;
  int score;
  String move;
  int flag;

  HashEntry(long k, int d, int s, String m, int f) {
    key = k;
    depth = d;
    score = s;
    move = m;
    flag = f;
  }
}

HashMap<Long, HashEntry> hashTable =
  new HashMap<Long, HashEntry>();

// ------------------------------------------------------------
// MOVE
// ------------------------------------------------------------

class Move {
  int from;
  int to;
  int promotion;
  boolean castle;
  boolean ep;

  Move(int f, int t) {
    from = f;
    to = t;
    promotion = 0;
    castle = false;
    ep = false;
  }

  Move copy() {
    Move m = new Move(from, to);
    m.promotion = promotion;
    m.castle = castle;
    m.ep = ep;
    return m;
  }
}

// ------------------------------------------------------------
// POSITION STATE
// ------------------------------------------------------------

class State {
  int captured;
  int oldEp;
  boolean oldWK;
  boolean oldWQ;
  boolean oldBK;
  boolean oldBQ;
}

State makeMove(Move m) {

  State s = new State();

  s.captured = board[m.to];
  s.oldEp = epSquare;

  s.oldWK = wCastleK;
  s.oldWQ = wCastleQ;
  s.oldBK = bCastleK;
  s.oldBQ = bCastleQ;

  int p = board[m.from];

  // en passant capture
  if (m.ep) {

    if (p == WP) {
      s.captured = board[m.to - 8];
      board[m.to - 8] = EMPTY;
    }

    if (p == BP) {
      s.captured = board[m.to + 8];
      board[m.to + 8] = EMPTY;
    }
  }

  board[m.to] = board[m.from];
  board[m.from] = EMPTY;

  // promotion
  if (m.promotion != 0) {

    if (p > 0)
      board[m.to] = m.promotion;

    else
      board[m.to] = -m.promotion;
  }

  // pawn double move
  epSquare = -1;

  if (p == WP && m.to - m.from == 16)
    epSquare = m.from + 8;

  if (p == BP && m.from - m.to == 16)
    epSquare = m.from - 8;

  // castling
  if (m.castle) {

    if (m.to == 6) {
      board[5] = WR;
      board[7] = EMPTY;
    }

    if (m.to == 2) {
      board[3] = WR;
      board[0] = EMPTY;
    }

    if (m.to == 62) {
      board[61] = BR;
      board[63] = EMPTY;
    }

    if (m.to == 58) {
      board[59] = BR;
      board[56] = EMPTY;
    }
  }

  updateCastling(p, m.from, m.to);

  return s;
}

void undoMove(Move m, State s) {

  int p = board[m.to];

  // undo castle rook
  if (m.castle) {

    if (m.to == 6) {
      board[7] = WR;
      board[5] = EMPTY;
    }

    if (m.to == 2) {
      board[0] = WR;
      board[3] = EMPTY;
    }

    if (m.to == 62) {
      board[63] = BR;
      board[61] = EMPTY;
    }

    if (m.to == 58) {
      board[56] = BR;
      board[59] = EMPTY;
    }
  }

  board[m.from] = p;

  // undo promotion
  if (m.promotion != 0) {

    if (p > 0)
      board[m.from] = WP;
    else
      board[m.from] = BP;
  }

  board[m.to] = s.captured;

  if (m.ep) {

    if (p > 0)
      board[m.to - 8] = BP;

    else
      board[m.to + 8] = WP;
  }

  epSquare = s.oldEp;

  wCastleK = s.oldWK;
  wCastleQ = s.oldWQ;
  bCastleK = s.oldBK;
  bCastleQ = s.oldBQ;
}

void updateCastling(int p, int from, int to) {

  if (p == WK) {
    wCastleK = false;
    wCastleQ = false;
  }

  if (p == BK) {
    bCastleK = false;
    bCastleQ = false;
  }

  if (from == 0 || to == 0)
    wCastleQ = false;

  if (from == 7 || to == 7)
    wCastleK = false;

  if (from == 56 || to == 56)
    bCastleQ = false;

  if (from == 63 || to == 63)
    bCastleK = false;
}

// ------------------------------------------------------------
// START POSITION
// ------------------------------------------------------------

void newGame() {

  String fen =
    "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR";

  loadFEN(fen);

  whiteTurn = true;
  running = false;
  thinking = false;

  gameMoves.clear();

  lastMove = "";
  statusText = "READY";

  selectedSquare = -1;

  hashTable.clear();

  redraw();
}

// ------------------------------------------------------------
// FEN
// ------------------------------------------------------------

void loadFEN(String fen) {

  for (int i = 0; i < 64; i++)
    board[i] = EMPTY;

  String[] a = split(fen, ' ');

  String[] rows = split(a[0], '/');

  for (int r = 0; r < 8; r++) {

    int file = 0;

    for (int i = 0; i < rows[r].length(); i++) {

      char c = rows[r].charAt(i);

      if (c >= '1' && c <= '8') {

        file += c - '0';

      } else {

        board[(7-r)*8 + file] = charPiece(c);

        file++;
      }
    }
  }

  whiteTurn = true;

  if (a.length > 1)
    whiteTurn = a[1].equals("w");

  wCastleK = false;
  wCastleQ = false;
  bCastleK = false;
  bCastleQ = false;

  if (a.length > 2) {

    String cs = a[2];

    wCastleK = cs.indexOf('K') >= 0;
    wCastleQ = cs.indexOf('Q') >= 0;
    bCastleK = cs.indexOf('k') >= 0;
    bCastleQ = cs.indexOf('q') >= 0;
  }

  epSquare = -1;

  if (a.length > 3 && !a[3].equals("-"))
    epSquare = squareFromString(a[3]);
}

int charPiece(char c) {

  if (c == 'P') return WP;
  if (c == 'N') return WN;
  if (c == 'B') return WB;
  if (c == 'R') return WR;
  if (c == 'Q') return WQ;
  if (c == 'K') return WK;

  if (c == 'p') return BP;
  if (c == 'n') return BN;
  if (c == 'b') return BB;
  if (c == 'r') return BR;
  if (c == 'q') return BQ;
  if (c == 'k') return BK;

  return EMPTY;
}

// ------------------------------------------------------------
// MOVE GENERATION
// ------------------------------------------------------------

ArrayList<Move> generateLegalMoves(boolean white) {

  ArrayList<Move> list = generatePseudoMoves(white);

  ArrayList<Move> legal = new ArrayList<Move>();

  for (Move m : list) {

    State s = makeMove(m);

    boolean check = inCheck(white);

    undoMove(m, s);

    if (!check)
      legal.add(m);
  }

  return legal;
}

ArrayList<Move> generatePseudoMoves(boolean white) {

  ArrayList<Move> list = new ArrayList<Move>();

  for (int sq = 0; sq < 64; sq++) {

    int p = board[sq];

    if (p == EMPTY)
      continue;

    if (white && p < 0)
      continue;

    if (!white && p > 0)
      continue;

    int type = abs(p);

    if (type == 1)
      pawnMoves(sq, white, list);

    else if (type == 2)
      knightMoves(sq, white, list);

    else if (type == 3)
      bishopMoves(sq, white, list);

    else if (type == 4)
      rookMoves(sq, white, list);

    else if (type == 5) {
      bishopMoves(sq, white, list);
      rookMoves(sq, white, list);
    }

    else if (type == 6)
      kingMoves(sq, white, list);
  }

  return list;
}

void addMove(ArrayList<Move> list,
             int from,
             int to,
             boolean white) {

  if (to < 0 || to >= 64)
    return;

  int target = board[to];

  if (target != EMPTY) {

    if (white && target > 0)
      return;

    if (!white && target < 0)
      return;

    if (abs(target) == 6)
      return;
  }

  list.add(new Move(from, to));
}

void pawnMoves(int sq,
               boolean white,
               ArrayList<Move> list) {

  int r = sq / 8;
  int f = sq % 8;

  int dir = white ? 8 : -8;

  int one = sq + dir;

  if (one >= 0 && one < 64 && board[one] == EMPTY) {

    if ((white && one / 8 == 7) ||
        (!white && one / 8 == 0)) {

      addPromotionMoves(list, sq, one);

    } else {

      addMove(list, sq, one, white);
    }

    int startRank = white ? 1 : 6;

    int two = sq + dir * 2;

    if (r == startRank &&
        board[two] == EMPTY)
      addMove(list, sq, two, white);
  }

  for (int df = -1; df <= 1; df += 2) {

    int nf = f + df;

    if (nf < 0 || nf > 7)
      continue;

    int to = sq + dir + df;

    if (to < 0 || to >= 64)
      continue;

    if (board[to] != EMPTY) {

      if ((white && board[to] < 0) ||
          (!white && board[to] > 0)) {

        if ((white && to / 8 == 7) ||
            (!white && to / 8 == 0))

          addPromotionMoves(list, sq, to);

        else

          addMove(list, sq, to, white);
      }
    }

    if (to == epSquare) {

      Move m = new Move(sq, to);
      m.ep = true;
      list.add(m);
    }
  }
}

void addPromotionMoves(ArrayList<Move> list,
                       int from,
                       int to) {

  int[] p = {5, 4, 3, 2};

  for (int i = 0; i < p.length; i++) {

    Move m = new Move(from, to);
    m.promotion = p[i];

    list.add(m);
  }
}

void knightMoves(int sq,
                 boolean white,
                 ArrayList<Move> list) {

  int r = sq / 8;
  int f = sq % 8;

  int[] dr = {-2,-2,-1,-1,1,1,2,2};
  int[] df = {-1,1,-2,2,-2,2,-1,1};

  for (int i = 0; i < 8; i++) {

    int nr = r + dr[i];
    int nf = f + df[i];

    if (nr >= 0 && nr < 8 &&
        nf >= 0 && nf < 8)

      addMove(list, sq, nr*8+nf, white);
  }
}

void bishopMoves(int sq,
                 boolean white,
                 ArrayList<Move> list) {

  slide(sq, white, list, 1, 1);
  slide(sq, white, list, 1, -1);
  slide(sq, white, list, -1, 1);
  slide(sq, white, list, -1, -1);
}

void rookMoves(int sq,
               boolean white,
               ArrayList<Move> list) {

  slide(sq, white, list, 1, 0);
  slide(sq, white, list, -1, 0);
  slide(sq, white, list, 0, 1);
  slide(sq, white, list, 0, -1);
}

void slide(int sq,
           boolean white,
           ArrayList<Move> list,
           int dr,
           int df) {

  int r = sq / 8;
  int f = sq % 8;

  int nr = r + dr;
  int nf = f + df;

  while (nr >= 0 && nr < 8 &&
         nf >= 0 && nf < 8) {

    int to = nr*8 + nf;

    if (board[to] == EMPTY) {

      list.add(new Move(sq, to));

    } else {

      if ((white && board[to] < 0) ||
          (!white && board[to] > 0)) {

        if (abs(board[to]) != 6)
          list.add(new Move(sq, to));
      }

      break;
    }

    nr += dr;
    nf += df;
  }
}

void kingMoves(int sq,
               boolean white,
               ArrayList<Move> list) {

  int r = sq / 8;
  int f = sq % 8;

  for (int dr = -1; dr <= 1; dr++) {

    for (int df = -1; df <= 1; df++) {

      if (dr == 0 && df == 0)
        continue;

      int nr = r + dr;
      int nf = f + df;

      if (nr >= 0 && nr < 8 &&
          nf >= 0 && nf < 8)

        addMove(list, sq, nr*8+nf, white);
    }
  }

  // WHITE CASTLING

  if (white && sq == 4) {

    if (wCastleK &&
        board[5] == EMPTY &&
        board[6] == EMPTY &&
        !squareAttacked(4, false) &&
        !squareAttacked(5, false) &&
        !squareAttacked(6, false)) {

      Move m = new Move(4,6);
      m.castle = true;
      list.add(m);
    }

    if (wCastleQ &&
        board[3] == EMPTY &&
        board[2] == EMPTY &&
        board[1] == EMPTY &&
        !squareAttacked(4, false) &&
        !squareAttacked(3, false) &&
        !squareAttacked(2, false)) {

      Move m = new Move(4,2);
      m.castle = true;
      list.add(m);
    }
  }

  // BLACK CASTLING

  if (!white && sq == 60) {

    if (bCastleK &&
        board[61] == EMPTY &&
        board[62] == EMPTY &&
        !squareAttacked(60, true) &&
        !squareAttacked(61, true) &&
        !squareAttacked(62, true)) {

      Move m = new Move(60,62);
      m.castle = true;
      list.add(m);
    }

    if (bCastleQ &&
        board[59] == EMPTY &&
        board[58] == EMPTY &&
        board[57] == EMPTY &&
        !squareAttacked(60, true) &&
        !squareAttacked(59, true) &&
        !squareAttacked(58, true)) {

      Move m = new Move(60,58);
      m.castle = true;
      list.add(m);
    }
  }
}

// ------------------------------------------------------------
// CHECK
// ------------------------------------------------------------

boolean inCheck(boolean white) {

  int king = white ? WK : BK;

  int sq = -1;

  for (int i = 0; i < 64; i++) {

    if (board[i] == king) {
      sq = i;
      break;
    }
  }

  if (sq < 0)
    return true;

  return squareAttacked(sq, !white);
}

boolean squareAttacked(int sq,
                       boolean byWhite) {

  int r = sq / 8;
  int f = sq % 8;

  // pawns

  if (byWhite) {

    if (r > 0) {

      if (f > 0 && board[sq-9] == WP)
        return true;

      if (f < 7 && board[sq-7] == WP)
        return true;
    }

  } else {

    if (r < 7) {

      if (f > 0 && board[sq+7] == BP)
        return true;

      if (f < 7 && board[sq+9] == BP)
        return true;
    }
  }

  // knights

  int[] dr = {-2,-2,-1,-1,1,1,2,2};
  int[] df = {-1,1,-2,2,-2,2,-1,1};

  for (int i = 0; i < 8; i++) {

    int nr = r + dr[i];
    int nf = f + df[i];

    if (nr >= 0 && nr < 8 &&
        nf >= 0 && nf < 8) {

      int p = board[nr*8+nf];

      if (byWhite && p == WN)
        return true;

      if (!byWhite && p == BN)
        return true;
    }
  }

  // king

  for (int rr = -1; rr <= 1; rr++) {

    for (int ff = -1; ff <= 1; ff++) {

      if (rr == 0 && ff == 0)
        continue;

      int nr = r + rr;
      int nf = f + ff;

      if (nr >= 0 && nr < 8 &&
          nf >= 0 && nf < 8) {

        int p = board[nr*8+nf];

        if (byWhite && p == WK)
          return true;

        if (!byWhite && p == BK)
          return true;
      }
    }
  }

  // bishop / queen

  if (rayAttack(sq, byWhite,
                1,1,WB,WQ))
    return true;

  if (rayAttack(sq, byWhite,
                1,-1,WB,WQ))
    return true;

  if (rayAttack(sq, byWhite,
                -1,1,WB,WQ))
    return true;

  if (rayAttack(sq, byWhite,
                -1,-1,WB,WQ))
    return true;

  // rook / queen

  if (rayAttack(sq, byWhite,
                1,0,WR,WQ))
    return true;

  if (rayAttack(sq, byWhite,
                -1,0,WR,WQ))
    return true;

  if (rayAttack(sq, byWhite,
                0,1,WR,WQ))
    return true;

  if (rayAttack(sq, byWhite,
                0,-1,WR,WQ))
    return true;

  return false;
}

boolean rayAttack(int sq,
                  boolean white,
                  int dr,
                  int df,
                  int piece,
                  int queen) {

  int r = sq / 8;
  int f = sq % 8;

  int nr = r + dr;
  int nf = f + df;

  while (nr >= 0 && nr < 8 &&
         nf >= 0 && nf < 8) {

    int p = board[nr*8+nf];

    if (p != EMPTY) {

      if (white) {

        if (p == piece || p == queen)
          return true;

      } else {

        if (p == -piece || p == -queen)
          return true;
      }

      return false;
    }

    nr += dr;
    nf += df;
  }

  return false;
}

// ------------------------------------------------------------
// EVALUATION
// ------------------------------------------------------------

int evaluate() {

  int score = 0;

  for (int sq = 0; sq < 64; sq++) {

    int p = board[sq];

    if (p == EMPTY)
      continue;

    int v = pieceValue[abs(p)];

    int r = sq / 8;
    int f = sq % 8;

    int center =
      14 - abs(3-r)*4 - abs(3-f)*4;

    if (abs(p) == 1)
      v += center * 2;

    if (abs(p) == 2)
      v += center * 3;

    if (abs(p) == 3)
      v += center * 2;

    if (abs(p) == 4)
      v += center;

    if (p > 0)
      score += v;

    else
      score -= v;
  }

  // mobility

  int whiteMob =
    generatePseudoMoves(true).size();

  int blackMob =
    generatePseudoMoves(false).size();

  score += (whiteMob - blackMob) * 2;

  return score;
}

// ------------------------------------------------------------
// SEARCH
// ------------------------------------------------------------

int searchRoot(boolean white,
               int depth) {

  ArrayList<Move> moves =
    generateLegalMoves(white);

  if (moves.size() == 0)
    return 0;

  Move best = moves.get(0);

  int bestScore =
    white ? -100000000 : 100000000;

  int alpha = -100000000;
  int beta = 100000000;

  for (int i = 0; i < moves.size(); i++) {

    Move m = moves.get(i);

    State s = makeMove(m);

    int score;

    if (white)
      score = alphaBeta(depth-1,
                        alpha,
                        beta,
                        false);

    else
      score = alphaBeta(depth-1,
                        alpha,
                        beta,
                        true);

    undoMove(m, s);

    if (white) {

      if (score > bestScore) {

        bestScore = score;
        best = m;
      }

      alpha = max(alpha, score);

    } else {

      if (score < bestScore) {

        bestScore = score;
        best = m;
      }

      beta = min(beta, score);
    }
  }

  lastSearchMove = moveToString(best);

  return bestScore;
}

String lastSearchMove = "";

int alphaBeta(int depth,
              int alpha,
              int beta,
              boolean white) {

  nodes++;

  if (depth <= 0)
    return quiescence(alpha, beta, white);

  ArrayList<Move> moves =
    generateLegalMoves(white);

  if (moves.size() == 0) {

    if (inCheck(white)) {

      if (white)
        return -1000000 - depth;

      else
        return 1000000 + depth;
    }

    return 0;
  }

  orderMoves(moves);

  if (white) {

    int best = -100000000;

    for (int i = 0; i < moves.size(); i++) {

      Move m = moves.get(i);

      State s = makeMove(m);

      int score =
        alphaBeta(depth-1,
                  alpha,
                  beta,
                  false);

      undoMove(m, s);

      best = max(best, score);
      alpha = max(alpha, score);

      if (alpha >= beta)
        break;
    }

    return best;

  } else {

    int best = 100000000;

    for (int i = 0; i < moves.size(); i++) {

      Move m = moves.get(i);

      State s = makeMove(m);

      int score =
        alphaBeta(depth-1,
                  alpha,
                  beta,
                  true);

      undoMove(m, s);

      best = min(best, score);
      beta = min(beta, score);

      if (alpha >= beta)
        break;
    }

    return best;
  }
}

int quiescence(int alpha,
               int beta,
               boolean white) {

  int stand = evaluate();

  if (white) {

    if (stand >= beta)
      return beta;

    if (stand > alpha)
      alpha = stand;

  } else {

    if (stand <= alpha)
      return alpha;

    if (stand < beta)
      beta = stand;
  }

  ArrayList<Move> moves =
    generateLegalMoves(white);

  for (int i = 0; i < moves.size(); i++) {

    Move m = moves.get(i);

    if (board[m.to] == EMPTY &&
        !m.ep)
      continue;

    State s = makeMove(m);

    int score =
      quiescence(alpha, beta, !white);

    undoMove(m, s);

    if (white) {

      if (score >= beta)
        return beta;

      alpha = max(alpha, score);

    } else {

      if (score <= alpha)
        return alpha;

      beta = min(beta, score);
    }
  }

  return white ? alpha : beta;
}

// ------------------------------------------------------------
// MOVE ORDER
// ------------------------------------------------------------

void orderMoves(ArrayList<Move> moves) {

  for (int i = 0; i < moves.size(); i++) {

    int best = i;

    int bestScore =
      moveScore(moves.get(i));

    for (int j = i+1; j < moves.size(); j++) {

      int s =
        moveScore(moves.get(j));

      if (s > bestScore) {

        bestScore = s;
        best = j;
      }
    }

    Move tmp = moves.get(i);

    moves.set(i, moves.get(best));
    moves.set(best, tmp);
  }
}

int moveScore(Move m) {

  int s = 0;

  if (board[m.to] != EMPTY)
    s += 1000 + pieceValue[abs(board[m.to])]
         - pieceValue[abs(board[m.from])]/10;

  if (m.promotion != 0)
    s += pieceValue[m.promotion];

  if (m.castle)
    s += 50;

  return s;
}

// ------------------------------------------------------------
// ENGINE MOVE
// ------------------------------------------------------------

void engineMove() {

  if (!running)
    return;

  thinking = true;

  statusText =
    whiteTurn ?
    "FRUIT WHITE THINKING" :
    "FRUIT BLACK THINKING";

  redraw();

  nodes = 0;
  lastSearchMove = "";

  searchRoot(whiteTurn, searchDepth);

  if (lastSearchMove.equals("")) {

    ArrayList<Move> lm =
      generateLegalMoves(whiteTurn);

    if (lm.size() == 0) {

      running = false;
      thinking = false;

      if (inCheck(whiteTurn))
        statusText = whiteTurn ?
          "BLACK CHECKMATE" :
          "WHITE CHECKMATE";
      else
        statusText = "DRAW";

      redraw();

      return;
    }
  }

  Move chosen =
    findMoveFromString(lastSearchMove);

  if (chosen == null) {

    running = false;
    thinking = false;

    statusText = "MOVE ERROR";

    redraw();

    return;
  }

  State s = makeMove(chosen);

  String text =
    moveToString(chosen);

  gameMoves.add(
    (whiteTurn ? "White " : "Black ") + text
  );

  lastMove = text;

  whiteTurn = !whiteTurn;

  thinking = false;

  statusText =
    "MOVE " + text +
    "  NODES " + nodes;

  redraw();

  delay(80);
}

Move findMoveFromString(String s) {

  ArrayList<Move> moves =
    generateLegalMoves(whiteTurn);

  for (int i = 0; i < moves.size(); i++) {

    if (moveToString(moves.get(i)).equals(s))
      return moves.get(i);
  }

  return null;
}

String moveToString(Move m) {

  String s =
    squareName(m.from) +
    squareName(m.to);

  if (m.promotion != 0) {

    if (m.promotion == 5)
      s += "q";

    else if (m.promotion == 4)
      s += "r";

    else if (m.promotion == 3)
      s += "b";

    else if (m.promotion == 2)
      s += "n";
  }

  return s;
}

String squareName(int sq) {

  int f = sq % 8;
  int r = sq / 8;

  return "" +
    (char)('a' + f) +
    (char)('1' + r);
}

int squareFromString(String s) {

  if (s.length() < 2)
    return -1;

  int f = s.charAt(0) - 'a';
  int r = s.charAt(1) - '1';

  if (f < 0 || f > 7 ||
      r < 0 || r > 7)
    return -1;

  return r*8 + f;
}

// ------------------------------------------------------------
// PROCESSING SETUP
// ------------------------------------------------------------

void setup() {

  orientation(PORTRAIT);

  size(displayWidth, displayHeight);

  textAlign(CENTER, CENTER);

  newGame();
}

void draw() {

  background(35);

  drawBoard();
  drawPieces();
  drawInterface();
}

// ------------------------------------------------------------
// BOARD
// ------------------------------------------------------------

void drawBoard() {

  float bs =
    min(width, width) / 8.0;

  float ox = 0;
  float oy = 40;

  noStroke();

  for (int r = 0; r < 8; r++) {

    for (int f = 0; f < 8; f++) {

      if ((r+f)%2 == 0)
        fill(220);
      else
        fill(90);

      rect(
        ox + f*bs,
        oy + (7-r)*bs,
        bs,
        bs
      );
    }
  }

  if (selectedSquare >= 0) {

    int f = selectedSquare % 8;
    int r = selectedSquare / 8;

    fill(255,220,0,100);

    rect(
      ox + f*bs,
      oy + (7-r)*bs,
      bs,
      bs
    );
  }
}

// ------------------------------------------------------------
// PIECES
// ------------------------------------------------------------

void drawPieces() {

  float bs =
    min(width, width) / 8.0;

  float ox = 0;
  float oy = 40;

  for (int sq = 0; sq < 64; sq++) {

    int p = board[sq];

    if (p == EMPTY)
      continue;

    int f = sq % 8;
    int r = sq / 8;

    float x =
      ox + f*bs + bs/2;

    float y =
      oy + (7-r)*bs + bs/2;

    drawPiece(p, x, y, bs);
  }
}

void drawPiece(int p,
               float x,
               float y,
               float bs) {

  boolean white = p > 0;

  int type = abs(p);

  stroke(white ? 20 : 240);
  strokeWeight(2);

  fill(white ? 245 : 20);

  if (type == 1) {

    ellipse(x,y,bs*.48,bs*.48);
    rectMode(CENTER);
    rect(x,y+bs*.16,bs*.40,bs*.22);
    rectMode(CORNER);
  }

  if (type == 2) {

    triangle(
      x-bs*.22,y+bs*.22,
      x+bs*.22,y+bs*.22,
      x,y-bs*.25
    );

    ellipse(
      x,y+bs*.25,
      bs*.42,bs*.18
    );
  }

  if (type == 3) {

    ellipse(x,y,bs*.55,bs*.55);

    line(
      x-bs*.18,y-bs*.20,
      x+bs*.18,y+bs*.20
    );

    line(
      x+bs*.18,y-bs*.20,
      x-bs*.18,y+bs*.20
    );
  }

  if (type == 4) {

    rectMode(CENTER);

    rect(
      x,y,
      bs*.52,
      bs*.55
    );

    rect(
      x,y-bs*.30,
      bs*.60,
      bs*.14
    );

    rectMode(CORNER);
  }

  if (type == 5) {

    ellipse(x,y,bs*.64,bs*.64);

    ellipse(
      x,
      y-bs*.20,
      bs*.28,
      bs*.28
    );

    line(
      x-bs*.20,y-bs*.20,
      x+bs*.20,y+bs*.20
    );

    line(
      x+bs*.20,y-bs*.20,
      x-bs*.20,y+bs*.20
    );
  }

  if (type == 6) {

    rectMode(CENTER);

    rect(
      x,y,
      bs*.58,
      bs*.58
    );

    line(
      x-bs*.16,y-bs*.20,
      x+bs*.16,y+bs*.20
    );

    line(
      x+bs*.16,y-bs*.20,
      x-bs*.16,y+bs*.20
    );

    rectMode(CORNER);
  }

  noStroke();
}

// ------------------------------------------------------------
// INTERFACE
// ------------------------------------------------------------

void drawInterface() {

  float y = 40 + width + 10;

  fill(255);

  textSize(16);

  text(
    "FRUIT 2.1 STYLE  WHITE vs BLACK",
    width/2,
    y
  );

  textSize(14);

  text(
    statusText,
    width/2,
    y+25
  );

  text(
    "DEPTH " + searchDepth +
    "   LAST " + lastMove,
    width/2,
    y+48
  );

  // START
  fill(50,170,70);

  rect(
    10,
    y+65,
    width/3-15,
    50
  );

  fill(255);

  text("START", width/6, y+90);

  // STOP
  fill(180,60,60);

  rect(
    width/3+5,
    y+65,
    width/3-10,
    50
  );

  fill(255);

  text(
    "STOP",
    width/2,
    y+90
  );

  // NEW
  fill(60,100,190);

  rect(
    width*2/3+5,
    y+65,
    width/3-15,
    50
  );

  fill(255);

  text(
    "NEW",
    width*5/6,
    y+90
  );

  fill(255);

  textSize(12);

  text(
    "Tap a piece and destination for human test",
    width/2,
    y+135
  );

  int yy = (int)y+155;

  textSize(11);

  int start =
    max(0, gameMoves.size()-8);

  for (int i = start; i < gameMoves.size(); i++) {

    text(
      gameMoves.get(i),
      width/2,
      yy
    );

    yy += 16;
  }
}

// ------------------------------------------------------------
// TOUCH
// ------------------------------------------------------------

void mousePressed() {

  float boardY = 40;
  float bs = width / 8.0;

  // buttons

  float by =
    boardY + width + 75;

  if (mouseY >= by &&
      mouseY <= by+50) {

    if (mouseX < width/3) {

      running = true;
      statusText = "START";

    } else if (mouseX < width*2/3) {

      running = false;
      statusText = "STOP";

    } else {

      newGame();
    }

    return;
  }

  // board touch

  if (mouseY >= boardY &&
      mouseY < boardY+width) {

    int f =
      constrain((int)(mouseX/bs),0,7);

    int visualRank =
      constrain((int)((mouseY-boardY)/bs),0,7);

    int r = 7-visualRank;

    int sq = r*8+f;

    if (selectedSquare < 0) {

      if (board[sq] != EMPTY &&
          ((whiteTurn && board[sq] > 0) ||
           (!whiteTurn && board[sq] < 0))) {

        selectedSquare = sq;
      }

    } else {

      Move m =
        findMove(selectedSquare, sq);

      if (m != null && !thinking) {

        makeMove(m);

        lastMove =
          moveToString(m);

        gameMoves.add(
          (whiteTurn ? "White " : "Black ") +
          lastMove
        );

        whiteTurn = !whiteTurn;

        selectedSquare = -1;

        redraw();
      }

      else {

        selectedSquare = -1;
      }
    }
  }
}

Move findMove(int from,
              int to) {

  ArrayList<Move> moves =
    generateLegalMoves(whiteTurn);

  for (int i = 0; i < moves.size(); i++) {

    Move m = moves.get(i);

    if (m.from == from &&
        m.to == to)

      return m;
  }

  return null;
}

// ------------------------------------------------------------
// CONTINUOUS ENGINE PLAY
// ------------------------------------------------------------

void onLoop() {

  if (running && !thinking) {

    engineMove();
  }
}

// APDE / Processing draw loop helper

void drawEngineTick() {

  if (running && !thinking) {

    engineMove();
  }
}



*/

/*





/*
  FRUIT-STYLE CHESS
  APDE 0.5.3 / Processing Android

  ONE .PDE FILE
  NO OPENING BOOK
  FRUIT WHITE vs FRUIT BLACK

  NOTE:
  This is a compact Java/Processing chess engine implementation
  designed to run directly inside APDE.
*/

final int EMPTY = 0;

final int WP = 1;
final int WN = 2;
final int WB = 3;
final int WR = 4;
final int WQ = 5;
final int WK = 6;

final int BP = -1;
final int BN = -2;
final int BB = -3;
final int BR = -4;
final int BQ = -5;
final int BK = -6;

int[] board = new int[64];

boolean whiteTurn = true;
boolean running = false;
boolean thinking = false;

int searchDepth = 3;

String lastMove = "";
String statusText = "READY";

ArrayList<String> gameMoves = new ArrayList<String>();

int selectedSquare = -1;

long nodes = 0;

int epSquare = -1;

boolean wCastleK = true;
boolean wCastleQ = true;
boolean bCastleK = true;
boolean bCastleQ = true;

int[] pieceValue = {
  0, 100, 320, 330, 500, 900, 20000
};

// ------------------------------------------------------------
// TRANSPOSITION TABLE
// ------------------------------------------------------------

class HashEntry {
  long key;
  int depth;
  int score;
  String move;
  int flag;

  HashEntry(long k, int d, int s, String m, int f) {
    key = k;
    depth = d;
    score = s;
    move = m;
    flag = f;
  }
}

HashMap<Long, HashEntry> hashTable =
  new HashMap<Long, HashEntry>();

// ------------------------------------------------------------
// MOVE
// ------------------------------------------------------------

class Move {
  int from;
  int to;
  int promotion;
  boolean castle;
  boolean ep;

  Move(int f, int t) {
    from = f;
    to = t;
    promotion = 0;
    castle = false;
    ep = false;
  }

  Move copy() {
    Move m = new Move(from, to);
    m.promotion = promotion;
    m.castle = castle;
    m.ep = ep;
    return m;
  }
}

// ------------------------------------------------------------
// POSITION STATE
// ------------------------------------------------------------

class State {
  int captured;
  int oldEp;
  boolean oldWK;
  boolean oldWQ;
  boolean oldBK;
  boolean oldBQ;
}

State makeMove(Move m) {

  State s = new State();

  s.captured = board[m.to];
  s.oldEp = epSquare;

  s.oldWK = wCastleK;
  s.oldWQ = wCastleQ;
  s.oldBK = bCastleK;
  s.oldBQ = bCastleQ;

  int p = board[m.from];

  // en passant capture
  if (m.ep) {

    if (p == WP) {
      s.captured = board[m.to - 8];
      board[m.to - 8] = EMPTY;
    }

    if (p == BP) {
      s.captured = board[m.to + 8];
      board[m.to + 8] = EMPTY;
    }
  }

  board[m.to] = board[m.from];
  board[m.from] = EMPTY;

  // promotion
  if (m.promotion != 0) {

    if (p > 0)
      board[m.to] = m.promotion;

    else
      board[m.to] = -m.promotion;
  }

  // pawn double move
  epSquare = -1;

  if (p == WP && m.to - m.from == 16)
    epSquare = m.from + 8;

  if (p == BP && m.from - m.to == 16)
    epSquare = m.from - 8;

  // castling
  if (m.castle) {

    if (m.to == 6) {
      board[5] = WR;
      board[7] = EMPTY;
    }

    if (m.to == 2) {
      board[3] = WR;
      board[0] = EMPTY;
    }

    if (m.to == 62) {
      board[61] = BR;
      board[63] = EMPTY;
    }

    if (m.to == 58) {
      board[59] = BR;
      board[56] = EMPTY;
    }
  }

  updateCastling(p, m.from, m.to);

  return s;
}

void undoMove(Move m, State s) {

  int p = board[m.to];

  // undo castle rook
  if (m.castle) {

    if (m.to == 6) {
      board[7] = WR;
      board[5] = EMPTY;
    }

    if (m.to == 2) {
      board[0] = WR;
      board[3] = EMPTY;
    }

    if (m.to == 62) {
      board[63] = BR;
      board[61] = EMPTY;
    }

    if (m.to == 58) {
      board[56] = BR;
      board[59] = EMPTY;
    }
  }

  board[m.from] = p;

  // undo promotion
  if (m.promotion != 0) {

    if (p > 0)
      board[m.from] = WP;
    else
      board[m.from] = BP;
  }

  board[m.to] = s.captured;

  if (m.ep) {

    if (p > 0)
      board[m.to - 8] = BP;

    else
      board[m.to + 8] = WP;
  }

  epSquare = s.oldEp;

  wCastleK = s.oldWK;
  wCastleQ = s.oldWQ;
  bCastleK = s.oldBK;
  bCastleQ = s.oldBQ;
}

void updateCastling(int p, int from, int to) {

  if (p == WK) {
    wCastleK = false;
    wCastleQ = false;
  }

  if (p == BK) {
    bCastleK = false;
    bCastleQ = false;
  }

  if (from == 0 || to == 0)
    wCastleQ = false;

  if (from == 7 || to == 7)
    wCastleK = false;

  if (from == 56 || to == 56)
    bCastleQ = false;

  if (from == 63 || to == 63)
    bCastleK = false;
}

// ------------------------------------------------------------
// START POSITION
// ------------------------------------------------------------

void newGame() {

  String fen =
    "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR";

  loadFEN(fen);

  whiteTurn = true;
  running = false;
  thinking = false;

  gameMoves.clear();

  lastMove = "";
  statusText = "READY";

  selectedSquare = -1;

  hashTable.clear();

  redraw();
}

// ------------------------------------------------------------
// FEN
// ------------------------------------------------------------

void loadFEN(String fen) {

  for (int i = 0; i < 64; i++)
    board[i] = EMPTY;

  String[] a = split(fen, ' ');

  String[] rows = split(a[0], '/');

  for (int r = 0; r < 8; r++) {

    int file = 0;

    for (int i = 0; i < rows[r].length(); i++) {

      char c = rows[r].charAt(i);

      if (c >= '1' && c <= '8') {

        file += c - '0';

      } else {

        board[(7-r)*8 + file] = charPiece(c);

        file++;
      }
    }
  }

  whiteTurn = true;

  if (a.length > 1)
    whiteTurn = a[1].equals("w");

  wCastleK = false;
  wCastleQ = false;
  bCastleK = false;
  bCastleQ = false;

  if (a.length > 2) {

    String cs = a[2];

    wCastleK = cs.indexOf('K') >= 0;
    wCastleQ = cs.indexOf('Q') >= 0;
    bCastleK = cs.indexOf('k') >= 0;
    bCastleQ = cs.indexOf('q') >= 0;
  }

  epSquare = -1;

  if (a.length > 3 && !a[3].equals("-"))
    epSquare = squareFromString(a[3]);
}

int charPiece(char c) {

  if (c == 'P') return WP;
  if (c == 'N') return WN;
  if (c == 'B') return WB;
  if (c == 'R') return WR;
  if (c == 'Q') return WQ;
  if (c == 'K') return WK;

  if (c == 'p') return BP;
  if (c == 'n') return BN;
  if (c == 'b') return BB;
  if (c == 'r') return BR;
  if (c == 'q') return BQ;
  if (c == 'k') return BK;

  return EMPTY;
}

// ------------------------------------------------------------
// MOVE GENERATION
// ------------------------------------------------------------

ArrayList<Move> generateLegalMoves(boolean white) {

  ArrayList<Move> list = generatePseudoMoves(white);

  ArrayList<Move> legal = new ArrayList<Move>();

  for (Move m : list) {

    State s = makeMove(m);

    boolean check = inCheck(white);

    undoMove(m, s);

    if (!check)
      legal.add(m);
  }

  return legal;
}

ArrayList<Move> generatePseudoMoves(boolean white) {

  ArrayList<Move> list = new ArrayList<Move>();

  for (int sq = 0; sq < 64; sq++) {

    int p = board[sq];

    if (p == EMPTY)
      continue;

    if (white && p < 0)
      continue;

    if (!white && p > 0)
      continue;

    int type = abs(p);

    if (type == 1)
      pawnMoves(sq, white, list);

    else if (type == 2)
      knightMoves(sq, white, list);

    else if (type == 3)
      bishopMoves(sq, white, list);

    else if (type == 4)
      rookMoves(sq, white, list);

    else if (type == 5) {
      bishopMoves(sq, white, list);
      rookMoves(sq, white, list);
    }

    else if (type == 6)
      kingMoves(sq, white, list);
  }

  return list;
}

void addMove(ArrayList<Move> list,
             int from,
             int to,
             boolean white) {

  if (to < 0 || to >= 64)
    return;

  int target = board[to];

  if (target != EMPTY) {

    if (white && target > 0)
      return;

    if (!white && target < 0)
      return;

    if (abs(target) == 6)
      return;
  }

  list.add(new Move(from, to));
}

void pawnMoves(int sq,
               boolean white,
               ArrayList<Move> list) {

  int r = sq / 8;
  int f = sq % 8;

  int dir = white ? 8 : -8;

  int one = sq + dir;

  if (one >= 0 && one < 64 && board[one] == EMPTY) {

    if ((white && one / 8 == 7) ||
        (!white && one / 8 == 0)) {

      addPromotionMoves(list, sq, one);

    } else {

      addMove(list, sq, one, white);
    }

    int startRank = white ? 1 : 6;

    int two = sq + dir * 2;

    if (r == startRank &&
        board[two] == EMPTY)
      addMove(list, sq, two, white);
  }

  for (int df = -1; df <= 1; df += 2) {

    int nf = f + df;

    if (nf < 0 || nf > 7)
      continue;

    int to = sq + dir + df;

    if (to < 0 || to >= 64)
      continue;

    if (board[to] != EMPTY) {

      if ((white && board[to] < 0) ||
          (!white && board[to] > 0)) {

        if ((white && to / 8 == 7) ||
            (!white && to / 8 == 0))

          addPromotionMoves(list, sq, to);

        else

          addMove(list, sq, to, white);
      }
    }

    if (to == epSquare) {

      Move m = new Move(sq, to);
      m.ep = true;
      list.add(m);
    }
  }
}

void addPromotionMoves(ArrayList<Move> list,
                       int from,
                       int to) {

  int[] p = {5, 4, 3, 2};

  for (int i = 0; i < p.length; i++) {

    Move m = new Move(from, to);
    m.promotion = p[i];

    list.add(m);
  }
}

void knightMoves(int sq,
                 boolean white,
                 ArrayList<Move> list) {

  int r = sq / 8;
  int f = sq % 8;

  int[] dr = {-2,-2,-1,-1,1,1,2,2};
  int[] df = {-1,1,-2,2,-2,2,-1,1};

  for (int i = 0; i < 8; i++) {

    int nr = r + dr[i];
    int nf = f + df[i];

    if (nr >= 0 && nr < 8 &&
        nf >= 0 && nf < 8)

      addMove(list, sq, nr*8+nf, white);
  }
}

void bishopMoves(int sq,
                 boolean white,
                 ArrayList<Move> list) {

  slide(sq, white, list, 1, 1);
  slide(sq, white, list, 1, -1);
  slide(sq, white, list, -1, 1);
  slide(sq, white, list, -1, -1);
}

void rookMoves(int sq,
               boolean white,
               ArrayList<Move> list) {

  slide(sq, white, list, 1, 0);
  slide(sq, white, list, -1, 0);
  slide(sq, white, list, 0, 1);
  slide(sq, white, list, 0, -1);
}

void slide(int sq,
           boolean white,
           ArrayList<Move> list,
           int dr,
           int df) {

  int r = sq / 8;
  int f = sq % 8;

  int nr = r + dr;
  int nf = f + df;

  while (nr >= 0 && nr < 8 &&
         nf >= 0 && nf < 8) {

    int to = nr*8 + nf;

    if (board[to] == EMPTY) {

      list.add(new Move(sq, to));

    } else {

      if ((white && board[to] < 0) ||
          (!white && board[to] > 0)) {

        if (abs(board[to]) != 6)
          list.add(new Move(sq, to));
      }

      break;
    }

    nr += dr;
    nf += df;
  }
}

void kingMoves(int sq,
               boolean white,
               ArrayList<Move> list) {

  int r = sq / 8;
  int f = sq % 8;

  for (int dr = -1; dr <= 1; dr++) {

    for (int df = -1; df <= 1; df++) {

      if (dr == 0 && df == 0)
        continue;

      int nr = r + dr;
      int nf = f + df;

      if (nr >= 0 && nr < 8 &&
          nf >= 0 && nf < 8)

        addMove(list, sq, nr*8+nf, white);
    }
  }

  // WHITE CASTLING

  if (white && sq == 4) {

    if (wCastleK &&
        board[5] == EMPTY &&
        board[6] == EMPTY &&
        !squareAttacked(4, false) &&
        !squareAttacked(5, false) &&
        !squareAttacked(6, false)) {

      Move m = new Move(4,6);
      m.castle = true;
      list.add(m);
    }

    if (wCastleQ &&
        board[3] == EMPTY &&
        board[2] == EMPTY &&
        board[1] == EMPTY &&
        !squareAttacked(4, false) &&
        !squareAttacked(3, false) &&
        !squareAttacked(2, false)) {

      Move m = new Move(4,2);
      m.castle = true;
      list.add(m);
    }
  }

  // BLACK CASTLING

  if (!white && sq == 60) {

    if (bCastleK &&
        board[61] == EMPTY &&
        board[62] == EMPTY &&
        !squareAttacked(60, true) &&
        !squareAttacked(61, true) &&
        !squareAttacked(62, true)) {

      Move m = new Move(60,62);
      m.castle = true;
      list.add(m);
    }

    if (bCastleQ &&
        board[59] == EMPTY &&
        board[58] == EMPTY &&
        board[57] == EMPTY &&
        !squareAttacked(60, true) &&
        !squareAttacked(59, true) &&
        !squareAttacked(58, true)) {

      Move m = new Move(60,58);
      m.castle = true;
      list.add(m);
    }
  }
}

// ------------------------------------------------------------
// CHECK
// ------------------------------------------------------------

boolean inCheck(boolean white) {

  int king = white ? WK : BK;

  int sq = -1;

  for (int i = 0; i < 64; i++) {

    if (board[i] == king) {
      sq = i;
      break;
    }
  }

  if (sq < 0)
    return true;

  return squareAttacked(sq, !white);
}

boolean squareAttacked(int sq,
                       boolean byWhite) {

  int r = sq / 8;
  int f = sq % 8;

  // pawns

  if (byWhite) {

    if (r > 0) {

      if (f > 0 && board[sq-9] == WP)
        return true;

      if (f < 7 && board[sq-7] == WP)
        return true;
    }

  } else {

    if (r < 7) {

      if (f > 0 && board[sq+7] == BP)
        return true;

      if (f < 7 && board[sq+9] == BP)
        return true;
    }
  }

  // knights

  int[] dr = {-2,-2,-1,-1,1,1,2,2};
  int[] df = {-1,1,-2,2,-2,2,-1,1};

  for (int i = 0; i < 8; i++) {

    int nr = r + dr[i];
    int nf = f + df[i];

    if (nr >= 0 && nr < 8 &&
        nf >= 0 && nf < 8) {

      int p = board[nr*8+nf];

      if (byWhite && p == WN)
        return true;

      if (!byWhite && p == BN)
        return true;
    }
  }

  // king

  for (int rr = -1; rr <= 1; rr++) {

    for (int ff = -1; ff <= 1; ff++) {

      if (rr == 0 && ff == 0)
        continue;

      int nr = r + rr;
      int nf = f + ff;

      if (nr >= 0 && nr < 8 &&
          nf >= 0 && nf < 8) {

        int p = board[nr*8+nf];

        if (byWhite && p == WK)
          return true;

        if (!byWhite && p == BK)
          return true;
      }
    }
  }

  // bishop / queen

  if (rayAttack(sq, byWhite,
                1,1,WB,WQ))
    return true;

  if (rayAttack(sq, byWhite,
                1,-1,WB,WQ))
    return true;

  if (rayAttack(sq, byWhite,
                -1,1,WB,WQ))
    return true;

  if (rayAttack(sq, byWhite,
                -1,-1,WB,WQ))
    return true;

  // rook / queen

  if (rayAttack(sq, byWhite,
                1,0,WR,WQ))
    return true;

  if (rayAttack(sq, byWhite,
                -1,0,WR,WQ))
    return true;

  if (rayAttack(sq, byWhite,
                0,1,WR,WQ))
    return true;

  if (rayAttack(sq, byWhite,
                0,-1,WR,WQ))
    return true;

  return false;
}

boolean rayAttack(int sq,
                  boolean white,
                  int dr,
                  int df,
                  int piece,
                  int queen) {

  int r = sq / 8;
  int f = sq % 8;

  int nr = r + dr;
  int nf = f + df;

  while (nr >= 0 && nr < 8 &&
         nf >= 0 && nf < 8) {

    int p = board[nr*8+nf];

    if (p != EMPTY) {

      if (white) {

        if (p == piece || p == queen)
          return true;

      } else {

        if (p == -piece || p == -queen)
          return true;
      }

      return false;
    }

    nr += dr;
    nf += df;
  }

  return false;
}

// ------------------------------------------------------------
// EVALUATION
// ------------------------------------------------------------

int evaluate() {

  int score = 0;

  for (int sq = 0; sq < 64; sq++) {

    int p = board[sq];

    if (p == EMPTY)
      continue;

    int v = pieceValue[abs(p)];

    int r = sq / 8;
    int f = sq % 8;

    int center =
      14 - abs(3-r)*4 - abs(3-f)*4;

    if (abs(p) == 1)
      v += center * 2;

    if (abs(p) == 2)
      v += center * 3;

    if (abs(p) == 3)
      v += center * 2;

    if (abs(p) == 4)
      v += center;

    if (p > 0)
      score += v;

    else
      score -= v;
  }

  // mobility

  int whiteMob =
    generatePseudoMoves(true).size();

  int blackMob =
    generatePseudoMoves(false).size();

  score += (whiteMob - blackMob) * 2;

  return score;
}

// ------------------------------------------------------------
// SEARCH
// ------------------------------------------------------------

int searchRoot(boolean white,
               int depth) {

  ArrayList<Move> moves =
    generateLegalMoves(white);

  if (moves.size() == 0)
    return 0;

  Move best = moves.get(0);

  int bestScore =
    white ? -100000000 : 100000000;

  int alpha = -100000000;
  int beta = 100000000;

  for (int i = 0; i < moves.size(); i++) {

    Move m = moves.get(i);

    State s = makeMove(m);

    int score;

    if (white)
      score = alphaBeta(depth-1,
                        alpha,
                        beta,
                        false);

    else
      score = alphaBeta(depth-1,
                        alpha,
                        beta,
                        true);

    undoMove(m, s);

    if (white) {

      if (score > bestScore) {

        bestScore = score;
        best = m;
      }

      alpha = max(alpha, score);

    } else {

      if (score < bestScore) {

        bestScore = score;
        best = m;
      }

      beta = min(beta, score);
    }
  }

  lastSearchMove = moveToString(best);

  return bestScore;
}

String lastSearchMove = "";

int alphaBeta(int depth,
              int alpha,
              int beta,
              boolean white) {

  nodes++;

  if (depth <= 0)
    return quiescence(alpha, beta, white);

  ArrayList<Move> moves =
    generateLegalMoves(white);

  if (moves.size() == 0) {

    if (inCheck(white)) {

      if (white)
        return -1000000 - depth;

      else
        return 1000000 + depth;
    }

    return 0;
  }

  orderMoves(moves);

  if (white) {

    int best = -100000000;

    for (int i = 0; i < moves.size(); i++) {

      Move m = moves.get(i);

      State s = makeMove(m);

      int score =
        alphaBeta(depth-1,
                  alpha,
                  beta,
                  false);

      undoMove(m, s);

      best = max(best, score);
      alpha = max(alpha, score);

      if (alpha >= beta)
        break;
    }

    return best;

  } else {

    int best = 100000000;

    for (int i = 0; i < moves.size(); i++) {

      Move m = moves.get(i);

      State s = makeMove(m);

      int score =
        alphaBeta(depth-1,
                  alpha,
                  beta,
                  true);

      undoMove(m, s);

      best = min(best, score);
      beta = min(beta, score);

      if (alpha >= beta)
        break;
    }

    return best;
  }
}

int quiescence(int alpha,
               int beta,
               boolean white) {

  int stand = evaluate();

  if (white) {

    if (stand >= beta)
      return beta;

    if (stand > alpha)
      alpha = stand;

  } else {

    if (stand <= alpha)
      return alpha;

    if (stand < beta)
      beta = stand;
  }

  ArrayList<Move> moves =
    generateLegalMoves(white);

  for (int i = 0; i < moves.size(); i++) {

    Move m = moves.get(i);

    if (board[m.to] == EMPTY &&
        !m.ep)
      continue;

    State s = makeMove(m);

    int score =
      quiescence(alpha, beta, !white);

    undoMove(m, s);

    if (white) {

      if (score >= beta)
        return beta;

      alpha = max(alpha, score);

    } else {

      if (score <= alpha)
        return alpha;

      beta = min(beta, score);
    }
  }

  return white ? alpha : beta;
}

// ------------------------------------------------------------
// MOVE ORDER
// ------------------------------------------------------------

void orderMoves(ArrayList<Move> moves) {

  for (int i = 0; i < moves.size(); i++) {

    int best = i;

    int bestScore =
      moveScore(moves.get(i));

    for (int j = i+1; j < moves.size(); j++) {

      int s =
        moveScore(moves.get(j));

      if (s > bestScore) {

        bestScore = s;
        best = j;
      }
    }

    Move tmp = moves.get(i);

    moves.set(i, moves.get(best));
    moves.set(best, tmp);
  }
}

int moveScore(Move m) {

  int s = 0;

  if (board[m.to] != EMPTY)
    s += 1000 + pieceValue[abs(board[m.to])]
         - pieceValue[abs(board[m.from])]/10;

  if (m.promotion != 0)
    s += pieceValue[m.promotion];

  if (m.castle)
    s += 50;

  return s;
}

// ------------------------------------------------------------
// ENGINE MOVE
// ------------------------------------------------------------

void engineMove() {

  if (!running)
    return;

  thinking = true;

  statusText =
    whiteTurn ?
    "FRUIT WHITE THINKING" :
    "FRUIT BLACK THINKING";

  redraw();

  nodes = 0;
  lastSearchMove = "";

  searchRoot(whiteTurn, searchDepth);

  if (lastSearchMove.equals("")) {

    ArrayList<Move> lm =
      generateLegalMoves(whiteTurn);

    if (lm.size() == 0) {

      running = false;
      thinking = false;

      if (inCheck(whiteTurn))
        statusText = whiteTurn ?
          "BLACK CHECKMATE" :
          "WHITE CHECKMATE";
      else
        statusText = "DRAW";

      redraw();

      return;
    }
  }

  Move chosen =
    findMoveFromString(lastSearchMove);

  if (chosen == null) {

    running = false;
    thinking = false;

    statusText = "MOVE ERROR";

    redraw();

    return;
  }

  State s = makeMove(chosen);

  String text =
    moveToString(chosen);

  gameMoves.add(
    (whiteTurn ? "White " : "Black ") + text
  );

  lastMove = text;

  whiteTurn = !whiteTurn;

  thinking = false;

  statusText =
    "MOVE " + text +
    "  NODES " + nodes;

  redraw();

  delay(80);
}

Move findMoveFromString(String s) {

  ArrayList<Move> moves =
    generateLegalMoves(whiteTurn);

  for (int i = 0; i < moves.size(); i++) {

    if (moveToString(moves.get(i)).equals(s))
      return moves.get(i);
  }

  return null;
}

String moveToString(Move m) {

  String s =
    squareName(m.from) +
    squareName(m.to);

  if (m.promotion != 0) {

    if (m.promotion == 5)
      s += "q";

    else if (m.promotion == 4)
      s += "r";

    else if (m.promotion == 3)
      s += "b";

    else if (m.promotion == 2)
      s += "n";
  }

  return s;
}

String squareName(int sq) {

  int f = sq % 8;
  int r = sq / 8;

  return "" +
    (char)('a' + f) +
    (char)('1' + r);
}

int squareFromString(String s) {

  if (s.length() < 2)
    return -1;

  int f = s.charAt(0) - 'a';
  int r = s.charAt(1) - '1';

  if (f < 0 || f > 7 ||
      r < 0 || r > 7)
    return -1;

  return r*8 + f;
}

// ------------------------------------------------------------
// PROCESSING SETUP
// ------------------------------------------------------------

void setup() {

  orientation(PORTRAIT);

  size(displayWidth, displayHeight);

  textAlign(CENTER, CENTER);

  newGame();
}

void draw() {

  background(35);

  drawBoard();
  drawPieces();
  drawInterface();
}

// ------------------------------------------------------------
// BOARD
// ------------------------------------------------------------

void drawBoard() {

  float bs =
    min(width, width) / 8.0;

  float ox = 0;
  float oy = 40;

  noStroke();

  for (int r = 0; r < 8; r++) {

    for (int f = 0; f < 8; f++) {

      if ((r+f)%2 == 0)
        fill(220);
      else
        fill(90);

      rect(
        ox + f*bs,
        oy + (7-r)*bs,
        bs,
        bs
      );
    }
  }

  if (selectedSquare >= 0) {

    int f = selectedSquare % 8;
    int r = selectedSquare / 8;

    fill(255,220,0,100);

    rect(
      ox + f*bs,
      oy + (7-r)*bs,
      bs,
      bs
    );
  }
}

// ------------------------------------------------------------
// PIECES
// ------------------------------------------------------------

void drawPieces() {

  float bs =
    min(width, width) / 8.0;

  float ox = 0;
  float oy = 40;

  for (int sq = 0; sq < 64; sq++) {

    int p = board[sq];

    if (p == EMPTY)
      continue;

    int f = sq % 8;
    int r = sq / 8;

    float x =
      ox + f*bs + bs/2;

    float y =
      oy + (7-r)*bs + bs/2;

    drawPiece(p, x, y, bs);
  }
}

void drawPiece(int p,
               float x,
               float y,
               float bs) {

  boolean white = p > 0;

  int type = abs(p);

  stroke(white ? 20 : 240);
  strokeWeight(2);

  fill(white ? 245 : 20);

  if (type == 1) {

    ellipse(x,y,bs*.48,bs*.48);
    rectMode(CENTER);
    rect(x,y+bs*.16,bs*.40,bs*.22);
    rectMode(CORNER);
  }

  if (type == 2) {

    triangle(
      x-bs*.22,y+bs*.22,
      x+bs*.22,y+bs*.22,
      x,y-bs*.25
    );

    ellipse(
      x,y+bs*.25,
      bs*.42,bs*.18
    );
  }

  if (type == 3) {

    ellipse(x,y,bs*.55,bs*.55);

    line(
      x-bs*.18,y-bs*.20,
      x+bs*.18,y+bs*.20
    );

    line(
      x+bs*.18,y-bs*.20,
      x-bs*.18,y+bs*.20
    );
  }

  if (type == 4) {

    rectMode(CENTER);

    rect(
      x,y,
      bs*.52,
      bs*.55
    );

    rect(
      x,y-bs*.30,
      bs*.60,
      bs*.14
    );

    rectMode(CORNER);
  }

  if (type == 5) {

    ellipse(x,y,bs*.64,bs*.64);

    ellipse(
      x,
      y-bs*.20,
      bs*.28,
      bs*.28
    );

    line(
      x-bs*.20,y-bs*.20,
      x+bs*.20,y+bs*.20
    );

    line(
      x+bs*.20,y-bs*.20,
      x-bs*.20,y+bs*.20
    );
  }

  if (type == 6) {

    rectMode(CENTER);

    rect(
      x,y,
      bs*.58,
      bs*.58
    );

    line(
      x-bs*.16,y-bs*.20,
      x+bs*.16,y+bs*.20
    );

    line(
      x+bs*.16,y-bs*.20,
      x-bs*.16,y+bs*.20
    );

    rectMode(CORNER);
  }

  noStroke();
}

// ------------------------------------------------------------
// INTERFACE
// ------------------------------------------------------------

void drawInterface() {

  float y = 40 + width + 10;

  fill(255);

  textSize(16);

  text(
    "FRUIT 2.1 STYLE  WHITE vs BLACK",
    width/2,
    y
  );

  textSize(14);

  text(
    statusText,
    width/2,
    y+25
  );

  text(
    "DEPTH " + searchDepth +
    "   LAST " + lastMove,
    width/2,
    y+48
  );

  // START
  fill(50,170,70);

  rect(
    10,
    y+65,
    width/3-15,
    50
  );

  fill(255);

  text("START", width/6, y+90);

  // STOP
  fill(180,60,60);

  rect(
    width/3+5,
    y+65,
    width/3-10,
    50
  );

  fill(255);

  text(
    "STOP",
    width/2,
    y+90
  );

  // NEW
  fill(60,100,190);

  rect(
    width*2/3+5,
    y+65,
    width/3-15,
    50
  );

  fill(255);

  text(
    "NEW",
    width*5/6,
    y+90
  );

  fill(255);

  textSize(12);

  text(
    "Tap a piece and destination for human test",
    width/2,
    y+135
  );

  int yy = (int)y+155;

  textSize(11);

  int start =
    max(0, gameMoves.size()-8);

  for (int i = start; i < gameMoves.size(); i++) {

    text(
      gameMoves.get(i),
      width/2,
      yy
    );

    yy += 16;
  }
}

// ------------------------------------------------------------
// TOUCH
// ------------------------------------------------------------

void mousePressed() {

  float boardY = 40;
  float bs = width / 8.0;

  // buttons

  float by =
    boardY + width + 75;

  if (mouseY >= by &&
      mouseY <= by+50) {

    if (mouseX < width/3) {

      running = true;
      statusText = "START";

    } else if (mouseX < width*2/3) {

      running = false;
      statusText = "STOP";

    } else {

      newGame();
    }

    return;
  }

  // board touch

  if (mouseY >= boardY &&
      mouseY < boardY+width) {

    int f =
      constrain((int)(mouseX/bs),0,7);

    int visualRank =
      constrain((int)((mouseY-boardY)/bs),0,7);

    int r = 7-visualRank;

    int sq = r*8+f;

    if (selectedSquare < 0) {

      if (board[sq] != EMPTY &&
          ((whiteTurn && board[sq] > 0) ||
           (!whiteTurn && board[sq] < 0))) {

        selectedSquare = sq;
      }

    } else {

      Move m =
        findMove(selectedSquare, sq);

      if (m != null && !thinking) {

        makeMove(m);

        lastMove =
          moveToString(m);

        gameMoves.add(
          (whiteTurn ? "White " : "Black ") +
          lastMove
        );

        whiteTurn = !whiteTurn;

        selectedSquare = -1;

        redraw();
      }

      else {

        selectedSquare = -1;
      }
    }
  }
}

Move findMove(int from,
              int to) {

  ArrayList<Move> moves =
    generateLegalMoves(whiteTurn);

  for (int i = 0; i < moves.size(); i++) {

    Move m = moves.get(i);

    if (m.from == from &&
        m.to == to)

      return m;
  }

  return null;
}

// ------------------------------------------------------------
// CONTINUOUS ENGINE PLAY
// ------------------------------------------------------------

void onLoop() {

  if (running && !thinking) {

    engineMove();
  }
}

// APDE / Processing draw loop helper

void drawEngineTick() {

  if (running && !thinking) {

    engineMove();
  }
}



























*/





















































