








APDE (Android Processing Development Environment) code to open a system file browser / file picker
In APDE sketches you can launch the Android system file picker with an Intent. Here is a clean, working example that opens a general file browser and handles the selected file URI.
Basic example (any file type)
import android.content.Intent;
import android.net.Uri;
import android.app.Activity;

Activity act;
Uri selectedFileUri;

void setup() {
  size(displayWidth, displayHeight);
  act = this.getActivity();
  orientation(PORTRAIT);
  
  // Optional: request storage permission if needed (Android 6+)
  // requestPermission("android.permission.READ_EXTERNAL_STORAGE");
}

void draw() {
  background(40);
  fill(255);
  textAlign(CENTER, CENTER);
  textSize(48);
  text("Tap to open File Browser", width/2, height/2);
  
  if (selectedFileUri != null) {
    textSize(28);
    text("Selected:\n" + selectedFileUri.toString(), width/2, height*0.7);
  }
}

void mousePressed() {
  openFileBrowser();
}

void openFileBrowser() {
  Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
  intent.setType("*/*");                    // any file type
  intent.addCategory(Intent.CATEGORY_OPENABLE);
  
  // Optional: allow multiple selection
  // intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
  
  act.startActivityForResult(Intent.createChooser(intent, "Select a file"), 1001);
}

// This is called automatically by the Android activity when the picker returns
@Override
public void onActivityResult(int requestCode, int resultCode, Intent data) {
  super.onActivityResult(requestCode, resultCode, data);
  
  if (requestCode == 1001 && resultCode == Activity.RESULT_OK && data != null) {
    selectedFileUri = data.getData();
    println("Selected URI: " + selectedFileUri);
    
    // Example: get a real path or open an InputStream
    // InputStream is = act.getContentResolver().openInputStream(selectedFileUri);
  }
}
Useful variations
Images only
intent.setType("image/*");
Open a directory (Android 5.0+)
Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
act.startActivityForResult(intent, 1002);
Modern SAF (Storage Access Framework) – preferred on newer Android
Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
intent.addCategory(Intent.CATEGORY_OPENABLE);
intent.setType("*/*");
act.startActivityForResult(intent, 1001);
Alternative: SelectFile library (easier API)
There is a ready-made library called SelectFile made for Processing Android mode / APDE:
Download the ZIP from the SelectFile GitHub releases (or the link in the repo).
In APDE: Tools → Import Library → Manage Libraries → Install Compressed Library and pick the ZIP.
Add the permissions READ_EXTERNAL_STORAGE and WRITE_EXTERNAL_STORAGE (Sketch Permissions).
Then you can simply write:
import select.files.*;

SelectFile select;

void setup() {
  select = new SelectFile(this);
}

void mousePressed() {
  select.selectInput("Select a file", "fileSelected");
}

void fileSelected(File selection) {
  if (selection != null) {
    println("Selected: " + selection.getAbsolutePath());
  }
}
It also supports selectFolder() and selectOutput().
Notes for APDE
You must run the sketch as a full app (not just the previewer) for startActivityForResult / onActivityResult to work reliably.
On Android 10+ (scoped storage) you usually work with the returned Uri + ContentResolver instead of a classic file path.
“Show Sketch Folder” in APDE settings often fails because of how Android file managers handle the internal sketch path — the Intent method above is more reliable.
Copy the first code block into a new APDE sketch and it should open the system file browser on tap.










