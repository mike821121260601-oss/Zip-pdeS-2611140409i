


import processing.sound.*;

// =====================================================
// APDE 28 MIDI KEYS
// 4 SOUND SETS
// PROCESSING SOUND LIBRARY
// =====================================================

SoundFile[] samples;

SinOsc[] osc;

int NUM_KEYS = 28;
int NUM_SETS = 4;

int currentSet = 0;

int[] midi = new int[NUM_KEYS];

boolean[] keyDown = new boolean[NUM_KEYS];

float keyW;
float keyH;

float keysY;

int[] activeSet = new int[NUM_KEYS];

// -----------------------------------------------------
// SETUP
// -----------------------------------------------------

void setup() {

  orientation(PORTRAIT);

  size(displayWidth, displayHeight, P2D);

  background(20);

  keyW = width / 4.0;
  keyH = height * 0.095;

  keysY = height * 0.30;

  // 28 MIDI notes
  // C3 = MIDI 48
  for (int i = 0; i < NUM_KEYS; i++) {
    midi[i] = 48 + i;
    keyDown[i] = false;
  }

  // One oscillator for every key
  osc = new SinOsc[NUM_KEYS];

  for (int i = 0; i < NUM_KEYS; i++) {
    osc[i] = new SinOsc(this);
    osc[i].amp(0);
    osc[i].freq(midiToFreq(midi[i]));
    osc[i].play();



osc[i].play();






  }
}

// -----------------------------------------------------
// MIDI -> FREQUENCY
// -----------------------------------------------------

float midiToFreq(int m) {

  return 440.0 * pow(2.0, (m - 69) / 12.0);
}

// -----------------------------------------------------
// DRAW
// -----------------------------------------------------

void draw() {

  background(15);

  drawSetButtons();

  drawKeys();

  drawInformation();
}

// -----------------------------------------------------
// 4 SOUND SET BUTTONS
// -----------------------------------------------------

void drawSetButtons() {

  float bw = width / 4.0;
  float bh = height * 0.10;

  for (int s = 0; s < NUM_SETS; s++) {

    if (s == currentSet) {
      fill(255, 150, 30);
    } else {
      fill(70);
    }

    rect(
      s * bw,
      0,
      bw - 2,
      bh - 2
    );

    fill(255);

    textAlign(CENTER, CENTER);
    textSize(height * 0.035);

    text(
      "SET " + (s + 1),
      s * bw + bw / 2,
      bh / 2
    );
  }
}

// -----------------------------------------------------
// 28 RECTANGLE MIDI KEYS
// -----------------------------------------------------

void drawKeys() {

  int columns = 4;
  int rows = 7;

  float w = width / 4.0;
  float h = height * 0.075;

  for (int i = 0; i < NUM_KEYS; i++) {

    int col = i % columns;
    int row = i / columns;

    float x = col * w;
    float y = keysY + row * h;

    if (keyDown[i]) {
      fill(255, 120, 20);
    } else {

      // Different appearance for the 4 sets
      if (currentSet == 0) {
        fill(220);
      }

      if (currentSet == 1) {
        fill(100, 180, 255);
      }

      if (currentSet == 2) {
        fill(130, 230, 140);
      }

      if (currentSet == 3) {
        fill(220, 130, 255);
      }
    }

    stroke(30);

    rect(
      x + 2,
      y + 2,
      w - 4,
      h - 4
    );

    fill(0);

    textAlign(CENTER, CENTER);

    textSize(height * 0.022);

    text(
      "" + midi[i],
      x + w / 2,
      y + h / 2
    );
  }
}

// -----------------------------------------------------
// INFORMATION
// -----------------------------------------------------

void drawInformation() {

  fill(255);

  textAlign(CENTER, CENTER);

  textSize(height * 0.025);

  text(
    "MIDI 48 - 75     SOUND SET " + (currentSet + 1),
    width / 2,
    height * 0.92
  );
}

// -----------------------------------------------------
// TOUCH
// -----------------------------------------------------

void mousePressed() {

  checkTouch(mouseX, mouseY);
}

void mouseDragged() {

  checkTouch(mouseX, mouseY);
}

void mouseReleased() {

  releaseAllKeys();
}

// -----------------------------------------------------
// TOUCH PROCESSING
// -----------------------------------------------------

void checkTouch(float tx, float ty) {

  float buttonH = height * 0.10;

  // -----------------------------------------------
  // 4 SET BUTTONS
  // -----------------------------------------------

  if (ty < buttonH) {

    int set = int(tx / (width / 4.0));

    if (set >= 0 && set < 4) {

      currentSet = set;

      changeSoundSet();

    }

    return;
  }

  // -----------------------------------------------
  // 28 KEYS
  // -----------------------------------------------

  int columns = 4;
  int rows = 7;

  float w = width / 4.0;
  float h = height * 0.075;

  for (int i = 0; i < NUM_KEYS; i++) {

    int col = i % columns;
    int row = i / columns;

    float x = col * w;
    float y = keysY + row * h;

    if (
      tx >= x &&
      tx < x + w &&
      ty >= y &&
      ty < y + h
    ) {

      playKey(i);

      break;
    }
  }
}

// -----------------------------------------------------
// PLAY MIDI KEY
// -----------------------------------------------------

void playKey(int k) {

  if (k < 0 || k >= NUM_KEYS)
    return;

  keyDown[k] = true;

  float f = midiToFreq(midi[k]);

  osc[k].freq(f);

  // 4 different sound sets
  if (currentSet == 0) {
    // Sine
    osc[k].amp(0.30);
  }

  if (currentSet == 1) {
    // Brighter
    osc[k].amp(0.45);
  }

  if (currentSet == 2) {
    // Soft
    osc[k].amp(0.20);
  }

  if (currentSet == 3) {
    // Loud
    osc[k].amp(0.60);
  }
}

// -----------------------------------------------------
// CHANGE SOUND SET
// -----------------------------------------------------

void changeSoundSet() {

  for (int i = 0; i < NUM_KEYS; i++) {

    osc[i].amp(0);

    keyDown[i] = false;
  }
}

// -----------------------------------------------------
// RELEASE
// -----------------------------------------------------

void releaseAllKeys() {

  for (int i = 0; i < NUM_KEYS; i++) {

    osc[i].amp(0);

    keyDown[i] = false;
  }
}




























