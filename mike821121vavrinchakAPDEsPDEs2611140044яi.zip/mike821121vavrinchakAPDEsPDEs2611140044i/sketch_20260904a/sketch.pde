// ============================================================
// APDE 0.5.3
// ONE FILE CHESS GAME + SMALL CHESS ENGINE
//
// WHITE = human
// BLACK = computer
//
// ENGINE SEARCH DEPTH = 4
//
// Board:
//   board[y][x]
//
// Pieces:
//   P pawn
//   N knight
//   B bishop
//   R rook
//   Q queen
//   K king
//
// Black pieces are lowercase.
//
// Empty square = '.'
// ============================================================

char[][] board = new char[8][8];

boolean whiteTurn = true;
boolean engineOn = true;
boolean gameOver = false;

int selectedX = -1;
int selectedY = -1;

ArrayList<Move> legalMoves = new ArrayList<Move>();
ArrayList<String> moveList = new ArrayList<String>();

int searchDepth = 4;

int squareSize;
int boardLeft;
int boardTop;

// ------------------------------------------------------------
// PROCESSING
// ------------------------------------------------------------

void setup() {
  size(displayWidth, displayHeight);
  textAlign(CENTER, CENTER);
  initGame();
}

void draw() {
  background(35);

  calculateBoardPosition();
  drawBoard();
  drawPieces();
  drawInfo();

  if (gameOver) {
    fill(255, 220);
    rect(boardLeft, boardTop + squareSize * 8 / 2 - 35,
         squareSize * 8, 70);

    fill(20);
    textSize(28);

    if (isCheckmate(whiteTurn)) {
      if (whiteTurn)
        text("CHECKMATE - BLACK WINS",
             width/2,
             boardTop + squareSize * 4);
      else
        text("CHECKMATE - WHITE WINS",
             width/2,
             boardTop + squareSize * 4);
    } else {
      text("STALEMATE",
           width/2,
           boardTop + squareSize * 4);
    }
  }
}

// ------------------------------------------------------------
// BOARD POSITION
// ------------------------------------------------------------

void calculateBoardPosition() {

  squareSize = min(width / 8, (height - 150) / 8);

  boardLeft = (width - squareSize * 8) / 2;
  boardTop = 30;
}

// ------------------------------------------------------------
// NEW GAME
// ------------------------------------------------------------

void initGame() {

  String[] start = {
    "rnbqkbnr",
    "pppppppp",
    "........",
    "........",
    "........",
    "........",
    "PPPPPPPP",
    "RNBQKBNR"
  };

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {
      board[y][x] = start[y].charAt(x);
    }
  }

  whiteTurn = true;
  gameOver = false;

  selectedX = -1;
  selectedY = -1;

  moveList.clear();

  updateLegalMoves();
}

// ------------------------------------------------------------
// DRAW BOARD
// ------------------------------------------------------------

void drawBoard() {

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {

      if ((x + y) % 2 == 0)
        fill(235, 233-random(100),33);
      else
  fill(100+random(50)-random(50),111,255);

      rect(boardLeft + x * squareSize,
           boardTop + y * squareSize,
           squareSize,
           squareSize);
    }
  }

  // selected square
  if (selectedX >= 0) {

    fill(255, 220, 0, 120);

    rect(boardLeft + selectedX * squareSize,
         boardTop + selectedY * squareSize,
         squareSize,
         squareSize);
  }

  // legal move marks
  for (Move m : legalMoves) {

    if (m.fx == selectedX && m.fy == selectedY) {

      fill(0, 180, 255, 150);

      ellipse(boardLeft + m.tx * squareSize + squareSize/2,
              boardTop + m.ty * squareSize + squareSize/2,
              squareSize * .25,
              squareSize * .25);
    }
  }
}

// ------------------------------------------------------------
// DRAW PIECES
// ------------------------------------------------------------

void drawPieces() {

  textSize(squareSize * .65);

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {

      char p = board[y][x];

      if (p == '.')
        continue;

      if (isWhite(p))
        fill(255);
      else
        fill(20);

      text(pieceUnicode(p),
           boardLeft + x * squareSize + squareSize/2,
           boardTop + y * squareSize + squareSize/2);
    }
  }
}

// ------------------------------------------------------------
// PIECE SYMBOLS
// ------------------------------------------------------------

String pieceUnicode(char p) {

  if (p == 'K') return "♔";
  if (p == 'Q') return "♕";
  if (p == 'R') return "♖";
  if (p == 'B') return "♗";
  if (p == 'N') return "♘";
  if (p == 'P') return "♙";

  if (p == 'k') return "♚";
  if (p == 'q') return "♛";
  if (p == 'r') return "♜";
  if (p == 'b') return "♝";
  if (p == 'n') return "♞";
  if (p == 'p') return "♟";

  return "";
}

// ------------------------------------------------------------
// INFORMATION
// ------------------------------------------------------------

void drawInfo() {

  fill(255);
  textSize(18);

  String side;

  if (whiteTurn)
    side = "WHITE";
  else
    side = "BLACK";

  text("TURN: " + side,
       width/2,
       boardTop + squareSize * 8 + 25);

  text("ENGINE DEPTH: " + searchDepth,
       width/2,
       boardTop + squareSize * 8 + 50);

  text("ENGINE: " + (engineOn ? "ON" : "OFF"),
       width/2,
       boardTop + squareSize * 8 + 75);

  text("R = restart   E = engine",
       width/2,
       boardTop + squareSize * 8 + 105);
}

// ------------------------------------------------------------
// TOUCH
// ------------------------------------------------------------

void mousePressed() {

  if (gameOver)
    return;

  if (!whiteTurn && engineOn)
    return;

  int x = (mouseX - boardLeft) / squareSize;
  int y = (mouseY - boardTop) / squareSize;

  if (x < 0 || x >= 8 ||
      y < 0 || y >= 8)
    return;

  // nothing selected
  if (selectedX == -1) {

    if (board[y][x] != '.' &&
        isWhite(board[y][x]) &&
        whiteTurn) {

      selectedX = x;
      selectedY = y;
    }

    return;
  }

  // select another own piece
  if (board[y][x] != '.' &&
      isWhite(board[y][x])) {

    selectedX = x;
    selectedY = y;
    return;
  }

  // find selected legal move
  Move chosen = null;

  for (Move m : legalMoves) {

    if (m.fx == selectedX &&
        m.fy == selectedY &&
        m.tx == x &&
        m.ty == y) {

      chosen = m;
      break;
    }
  }

  if (chosen != null) {

    makeMove(chosen);

    selectedX = -1;
    selectedY = -1;

    updateLegalMoves();

    if (!gameOver && !whiteTurn && engineOn) {
      engineMove();
    }
  }
}

// ------------------------------------------------------------
// KEYBOARD
// ------------------------------------------------------------

void keyPressed() {

  if (key == 'r' || key == 'R') {
    initGame();
  }

  if (key == 'e' || key == 'E') {
    engineOn = !engineOn;
  }

  if (key == '+' && searchDepth < 6) {
    searchDepth++;
  }

  if (key == '-' && searchDepth > 1) {
    searchDepth--;
  }
}

// ------------------------------------------------------------
// GENERATE LEGAL MOVES
// ------------------------------------------------------------

void updateLegalMoves() {

  legalMoves = generateLegalMoves(whiteTurn);

  if (legalMoves.size() == 0) {

    if (isKingInCheck(whiteTurn)) {
      gameOver = true;
    } else {
      gameOver = true;
    }
  }
}

// ------------------------------------------------------------
// GENERATE ALL LEGAL MOVES
// ------------------------------------------------------------

ArrayList<Move> generateLegalMoves(boolean white) {

  ArrayList<Move> result =
    new ArrayList<Move>();

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {

      char p = board[y][x];

      if (p == '.')
        continue;

      if (isWhite(p) != white)
        continue;

      ArrayList<Move> pseudo =
        generatePseudoMoves(x, y, p);

      for (Move m : pseudo) {

        char[][] save = copyBoard();

        makeMove(m);

        if (!isKingInCheck(white)) {
          result.add(m);
        }

        restoreBoard(save);
      }
    }
  }

  return result;
}

// ------------------------------------------------------------
// PSEUDO MOVES
// ------------------------------------------------------------

ArrayList<Move> generatePseudoMoves(
  int x,
  int y,
  char p) {

  ArrayList<Move> list =
    new ArrayList<Move>();

  boolean white = isWhite(p);

  // ----------------------------------------------------------
  // PAWN
  // ----------------------------------------------------------

  if (Character.toLowerCase(p) == 'p') {

    int dir = white ? -1 : 1;

    int startRow = white ? 6 : 1;

    int ny = y + dir;

    if (inside(x, ny) &&
        board[ny][x] == '.') {

      addMove(list, x, y, x, ny);

      if (y == startRow &&
          board[y + dir*2][x] == '.') {

        addMove(list,
                x, y,
                x, y + dir*2);
      }
    }

    // captures
    for (int dx = -1; dx <= 1; dx += 2) {

      int nx = x + dx;

      if (!inside(nx, ny))
        continue;

      if (board[ny][nx] != '.' &&
          isWhite(board[ny][nx]) != white) {

        addMove(list,
                x, y,
                nx, ny);
      }
    }
  }

  // ----------------------------------------------------------
  // KNIGHT
  // ----------------------------------------------------------

  if (Character.toLowerCase(p) == 'n') {

    int[][] d = {
      {1,2},{2,1},{2,-1},{1,-2},
      {-1,-2},{-2,-1},{-2,1},{-1,2}
    };

    for (int i = 0; i < 8; i++) {

      addIfPossible(list,
                    x, y,
                    x+d[i][0],
                    y+d[i][1],
                    white);
    }
  }

  // ----------------------------------------------------------
  // BISHOP
  // ----------------------------------------------------------

  if (Character.toLowerCase(p) == 'b') {

    slide(list, x, y, white,
          1, 1);
    slide(list, x, y, white,
          1, -1);
    slide(list, x, y, white,
          -1, 1);
    slide(list, x, y, white,
          -1, -1);
  }

  // ----------------------------------------------------------
  // ROOK
  // ----------------------------------------------------------

  if (Character.toLowerCase(p) == 'r') {

    slide(list, x, y, white,
          1, 0);
    slide(list, x, y, white,
          -1, 0);
    slide(list, x, y, white,
          0, 1);
    slide(list, x, y, white,
          0, -1);
  }

  // ----------------------------------------------------------
  // QUEEN
  // ----------------------------------------------------------

  if (Character.toLowerCase(p) == 'q') {

    slide(list, x, y, white,
          1, 0);
    slide(list, x, y, white,
          -1, 0);
    slide(list, x, y, white,
          0, 1);
    slide(list, x, y, white,
          0, -1);

    slide(list, x, y, white,
          1, 1);
    slide(list, x, y, white,
          1, -1);
    slide(list, x, y, white,
          -1, 1);
    slide(list, x, y, white,
          -1, -1);
  }

  // ----------------------------------------------------------
  // KING
  // ----------------------------------------------------------

  if (Character.toLowerCase(p) == 'k') {

    for (int dx = -1; dx <= 1; dx++) {
      for (int dy = -1; dy <= 1; dy++) {

        if (dx == 0 && dy == 0)
          continue;

        addIfPossible(list,
                      x, y,
                      x+dx,
                      y+dy,
                      white);
      }
    }
  }

  return list;
}

// ------------------------------------------------------------
// ADD NORMAL MOVE
// ------------------------------------------------------------

void addMove(ArrayList<Move> list,
             int fx, int fy,
             int tx, int ty) {

  if (!inside(tx, ty))
    return;

  list.add(new Move(fx, fy, tx, ty));
}

// ------------------------------------------------------------
// ADD CAPTURE / NORMAL
// ------------------------------------------------------------

void addIfPossible(ArrayList<Move> list,
                   int fx, int fy,
                   int tx, int ty,
                   boolean white) {

  if (!inside(tx, ty))
    return;

  char target = board[ty][tx];

  if (target == '.' ||
      isWhite(target) != white) {

    list.add(new Move(fx, fy, tx, ty));
  }
}

// ------------------------------------------------------------
// SLIDING PIECES
// ------------------------------------------------------------

void slide(ArrayList<Move> list,
           int x, int y,
           boolean white,
           int dx, int dy) {

  int nx = x + dx;
  int ny = y + dy;

  while (inside(nx, ny)) {

    char target = board[ny][nx];

    if (target == '.') {

      list.add(new Move(x, y, nx, ny));

    } else {

      if (isWhite(target) != white) {

        list.add(new Move(x, y, nx, ny));
      }

      break;
    }

    nx += dx;
    ny += dy;
  }
}

// ------------------------------------------------------------
// MAKE MOVE
// ------------------------------------------------------------

void makeMove(Move m) {

  char p = board[m.fy][m.fx];

  char captured = board[m.ty][m.tx];

  board[m.ty][m.tx] = p;
  board[m.fy][m.fx] = '.';

  // promotion
  if (p == 'P' && m.ty == 0)
    board[m.ty][m.tx] = 'Q';

  if (p == 'p' && m.ty == 7)
    board[m.ty][m.tx] = 'q';

  // move notation
  String s =
    "" + (char)('a' + m.fx) +
    (8 - m.fy) +
    "-" +
    (char)('a' + m.tx) +
    (8 - m.ty);

  moveList.add(s);

  whiteTurn = !whiteTurn;
}

// ------------------------------------------------------------
// UNDO HELPER FOR SEARCH
// ------------------------------------------------------------

char[][] copyBoard() {

  char[][] b = new char[8][8];

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {
      b[y][x] = board[y][x];
    }
  }

  return b;
}

void restoreBoard(char[][] b) {

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {
      board[y][x] = b[y][x];
    }
  }
}

// ------------------------------------------------------------
// ENGINE
// ------------------------------------------------------------

void engineMove() {

  ArrayList<Move> moves =
    generateLegalMoves(false);

  if (moves.size() == 0) {
    gameOver = true;
    return;
  }

  int bestScore = 100000000;
  Move bestMove = moves.get(0);

  for (Move m : moves) {

    char[][] save = copyBoard();

    makeMove(m);

    int score =
      minimax(searchDepth - 1,
              true,
              -100000000,
              100000000);

    restoreBoard(save);

    // BLACK wants smallest score
    if (score < bestScore) {
      bestScore = score;
      bestMove = m;
    }
  }

  makeMove(bestMove);

  updateLegalMoves();
}

// ------------------------------------------------------------
// MINIMAX + ALPHA BETA
// ------------------------------------------------------------

int minimax(int depth,
            boolean white,
            int alpha,
            int beta) {

  if (depth == 0)
    return evaluate();

  ArrayList<Move> moves =
    generateLegalMoves(white);

  if (moves.size() == 0) {

    if (isKingInCheck(white)) {

      if (white)
        return 1000000;

      return -1000000;
    }

    return 0;
  }

  if (white) {

    int best = -100000000;

    for (Move m : moves) {

      char[][] save = copyBoard();

      makeMove(m);

      int score =
        minimax(depth - 1,
                false,
                alpha,
                beta);

      restoreBoard(save);

      best = max(best, score);
      alpha = max(alpha, best);

      if (beta <= alpha)
        break;
    }

    return best;

  } else {

    int best = 100000000;

    for (Move m : moves) {

      char[][] save = copyBoard();

      makeMove(m);

      int score =
        minimax(depth - 1,
                true,
                alpha,
                beta);

      restoreBoard(save);

      best = min(best, score);
      beta = min(beta, best);

      if (beta <= alpha)
        break;
    }

    return best;
  }
}

// ------------------------------------------------------------
// EVALUATION
// ------------------------------------------------------------

int evaluate() {

  int score = 0;

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {

      char p = board[y][x];

      if (p == '.')
        continue;

      int value = pieceValue(p);

      if (isWhite(p))
        score += value;
      else
        score -= value;
    }
  }

  return score;
}

// ------------------------------------------------------------
// PIECE VALUE
// ------------------------------------------------------------

int pieceValue(char p) {

  char q = Character.toLowerCase(p);

  if (q == 'p') return 100;
  if (q == 'n') return 320;
  if (q == 'b') return 330;
  if (q == 'r') return 500;
  if (q == 'q') return 900;
  if (q == 'k') return 20000;

  return 0;
}

// ------------------------------------------------------------
// CHECK KING
// ------------------------------------------------------------

boolean isKingInCheck(boolean white) {

  int kx = -1;
  int ky = -1;

  char king = white ? 'K' : 'k';

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {

      if (board[y][x] == king) {
        kx = x;
        ky = y;
      }
    }
  }

  if (kx == -1)
    return true;

  return squareAttacked(kx, ky, !white);
}

// ------------------------------------------------------------
// ATTACK TEST
// ------------------------------------------------------------

boolean squareAttacked(int x,
                        int y,
                        boolean byWhite) {

  // pawn
  int pawnDir = byWhite ? -1 : 1;

  int py = y - pawnDir;

  if (inside(x-1, py) &&
      board[py][x-1] == (byWhite ? 'P' : 'p'))
    return true;

  if (inside(x+1, py) &&
      board[py][x+1] == (byWhite ? 'P' : 'p'))
    return true;

  // knight
  int[][] nd = {
    {1,2},{2,1},{2,-1},{1,-2},
    {-1,-2},{-2,-1},{-2,1},{-1,2}
  };

  char knight = byWhite ? 'N' : 'n';

  for (int i = 0; i < 8; i++) {

    int nx = x + nd[i][0];
    int ny = y + nd[i][1];

    if (inside(nx, ny) &&
        board[ny][nx] == knight)
      return true;
  }

  // rook / queen
  if (rayAttacked(x,y,byWhite,
                  1,0,'r','q'))
    return true;

  if (rayAttacked(x,y,byWhite,
                  -1,0,'r','q'))
    return true;

  if (rayAttacked(x,y,byWhite,
                  0,1,'r','q'))
    return true;

  if (rayAttacked(x,y,byWhite,
                  0,-1,'r','q'))
    return true;

  // bishop / queen
  if (rayAttacked(x,y,byWhite,
                  1,1,'b','q'))
    return true;

  if (rayAttacked(x,y,byWhite,
                  1,-1,'b','q'))
    return true;

  if (rayAttacked(x,y,byWhite,
                  -1,1,'b','q'))
    return true;

  if (rayAttacked(x,y,byWhite,
                  -1,-1,'b','q'))
    return true;

  // king
  char king = byWhite ? 'K' : 'k';

  for (int dx = -1; dx <= 1; dx++) {
    for (int dy = -1; dy <= 1; dy++) {

      if (dx == 0 && dy == 0)
        continue;

      int nx = x + dx;
      int ny = y + dy;

      if (inside(nx,ny) &&
          board[ny][nx] == king)
        return true;
    }
  }

  return false;
}

// ------------------------------------------------------------
// RAY ATTACK
// ------------------------------------------------------------

boolean rayAttacked(int x,
                    int y,
                    boolean byWhite,
                    int dx,
                    int dy,
                    char piece1,
                    char piece2) {

  int nx = x + dx;
  int ny = y + dy;

  char p1 = byWhite ?
    Character.toUpperCase(piece1) :
    piece1;

  char p2 = byWhite ?
    Character.toUpperCase(piece2) :
    piece2;

  while (inside(nx,ny)) {

    char p = board[ny][nx];

    if (p != '.') {

      if (p == p1 || p == p2)
        return true;

      return false;
    }

    nx += dx;
    ny += dy;
  }

  return false;
}

// ------------------------------------------------------------
// CHECKMATE
// ------------------------------------------------------------

boolean isCheckmate(boolean white) {

  ArrayList<Move> m =
    generateLegalMoves(white);

  return m.size() == 0 &&
         isKingInCheck(white);
}

// ------------------------------------------------------------
// INSIDE BOARD
// ------------------------------------------------------------

boolean inside(int x, int y) {

  return x >= 0 &&
         x < 8 &&
         y >= 0 &&
         y < 8;
}

// ------------------------------------------------------------
// WHITE PIECE
// ------------------------------------------------------------

boolean isWhite(char p) {

  return p >= 'A' &&
         p <= 'Z';
}

// ------------------------------------------------------------
// MOVE CLASS
// ------------------------------------------------------------

class Move {

  int fx;
  int fy;

  int tx;
  int ty;

  Move(int a, int b,
       int c, int d) {

    fx = a;
    fy = b;

    tx = c;
    ty = d;
  }
}
























/*




// ============================================================
// APDE 0.5.3
// ONE FILE CHESS GAME + SMALL CHESS ENGINE
//
// WHITE = human
// BLACK = computer
//
// ENGINE SEARCH DEPTH = 4
//
// Board:
//   board[y][x]
//
// Pieces:
//   P pawn
//   N knight
//   B bishop
//   R rook
//   Q queen
//   K king
//
// Black pieces are lowercase.
//
// Empty square = '.'
// ============================================================

char[][] board = new char[8][8];

boolean whiteTurn = true;
boolean engineOn = true;
boolean gameOver = false;

int selectedX = -1;
int selectedY = -1;

ArrayList<Move> legalMoves = new ArrayList<Move>();
ArrayList<String> moveList = new ArrayList<String>();

int searchDepth = 4;

int squareSize;
int boardLeft;
int boardTop;

// ------------------------------------------------------------
// PROCESSING
// ------------------------------------------------------------

void setup() {
  size(displayWidth, displayHeight);
  textAlign(CENTER, CENTER);
  initGame();
}

void draw() {
  background(35);

  calculateBoardPosition();
  drawBoard();
  drawPieces();
  drawInfo();

  if (gameOver) {
    fill(255, 220);
    rect(boardLeft, boardTop + squareSize * 8 / 2 - 35,
         squareSize * 8, 70);

    fill(20);
    textSize(28);

    if (isCheckmate(whiteTurn)) {
      if (whiteTurn)
        text("CHECKMATE - BLACK WINS",
             width/2,
             boardTop + squareSize * 4);
      else
        text("CHECKMATE - WHITE WINS",
             width/2,
             boardTop + squareSize * 4);
    } else {
      text("STALEMATE",
           width/2,
           boardTop + squareSize * 4);
    }
  }
}

// ------------------------------------------------------------
// BOARD POSITION
// ------------------------------------------------------------

void calculateBoardPosition() {

  squareSize = min(width / 8, (height - 150) / 8);

  boardLeft = (width - squareSize * 8) / 2;
  boardTop = 30;
}

// ------------------------------------------------------------
// NEW GAME
// ------------------------------------------------------------

void initGame() {

  String[] start = {
    "rnbqkbnr",
    "pppppppp",
    "........",
    "........",
    "........",
    "........",
    "PPPPPPPP",
    "RNBQKBNR"
  };

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {
      board[y][x] = start[y].charAt(x);
    }
  }

  whiteTurn = true;
  gameOver = false;

  selectedX = -1;
  selectedY = -1;

  moveList.clear();

  updateLegalMoves();
}

// ------------------------------------------------------------
// DRAW BOARD
// ------------------------------------------------------------

void drawBoard() {

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {

      if ((x + y) % 2 == 0)
        fill(235);
      else
        fill(100);

      rect(boardLeft + x * squareSize,
           boardTop + y * squareSize,
           squareSize,
           squareSize);
    }
  }

  // selected square
  if (selectedX >= 0) {

    fill(255, 220, 0, 120);

    rect(boardLeft + selectedX * squareSize,
         boardTop + selectedY * squareSize,
         squareSize,
         squareSize);
  }

  // legal move marks
  for (Move m : legalMoves) {

    if (m.fx == selectedX && m.fy == selectedY) {

      fill(0, 180, 255, 150);

      ellipse(boardLeft + m.tx * squareSize + squareSize/2,
              boardTop + m.ty * squareSize + squareSize/2,
              squareSize * .25,
              squareSize * .25);
    }
  }
}

// ------------------------------------------------------------
// DRAW PIECES
// ------------------------------------------------------------

void drawPieces() {

  textSize(squareSize * .65);

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {

      char p = board[y][x];

      if (p == '.')
        continue;

      if (isWhite(p))
        fill(255);
      else
        fill(20);

      text(pieceUnicode(p),
           boardLeft + x * squareSize + squareSize/2,
           boardTop + y * squareSize + squareSize/2);
    }
  }
}

// ------------------------------------------------------------
// PIECE SYMBOLS
// ------------------------------------------------------------

String pieceUnicode(char p) {

  if (p == 'K') return "♔";
  if (p == 'Q') return "♕";
  if (p == 'R') return "♖";
  if (p == 'B') return "♗";
  if (p == 'N') return "♘";
  if (p == 'P') return "♙";

  if (p == 'k') return "♚";
  if (p == 'q') return "♛";
  if (p == 'r') return "♜";
  if (p == 'b') return "♝";
  if (p == 'n') return "♞";
  if (p == 'p') return "♟";

  return "";
}

// ------------------------------------------------------------
// INFORMATION
// ------------------------------------------------------------

void drawInfo() {

  fill(255);
  textSize(18);

  String side;

  if (whiteTurn)
    side = "WHITE";
  else
    side = "BLACK";

  text("TURN: " + side,
       width/2,
       boardTop + squareSize * 8 + 25);

  text("ENGINE DEPTH: " + searchDepth,
       width/2,
       boardTop + squareSize * 8 + 50);

  text("ENGINE: " + (engineOn ? "ON" : "OFF"),
       width/2,
       boardTop + squareSize * 8 + 75);

  text("R = restart   E = engine",
       width/2,
       boardTop + squareSize * 8 + 105);
}

// ------------------------------------------------------------
// TOUCH
// ------------------------------------------------------------

void mousePressed() {

  if (gameOver)
    return;

  if (!whiteTurn && engineOn)
    return;

  int x = (mouseX - boardLeft) / squareSize;
  int y = (mouseY - boardTop) / squareSize;

  if (x < 0 || x >= 8 ||
      y < 0 || y >= 8)
    return;

  // nothing selected
  if (selectedX == -1) {

    if (board[y][x] != '.' &&
        isWhite(board[y][x]) &&
        whiteTurn) {

      selectedX = x;
      selectedY = y;
    }

    return;
  }

  // select another own piece
  if (board[y][x] != '.' &&
      isWhite(board[y][x])) {

    selectedX = x;
    selectedY = y;
    return;
  }

  // find selected legal move
  Move chosen = null;

  for (Move m : legalMoves) {

    if (m.fx == selectedX &&
        m.fy == selectedY &&
        m.tx == x &&
        m.ty == y) {

      chosen = m;
      break;
    }
  }

  if (chosen != null) {

    makeMove(chosen);

    selectedX = -1;
    selectedY = -1;

    updateLegalMoves();

    if (!gameOver && !whiteTurn && engineOn) {
      engineMove();
    }
  }
}

// ------------------------------------------------------------
// KEYBOARD
// ------------------------------------------------------------

void keyPressed() {

  if (key == 'r' || key == 'R') {
    initGame();
  }

  if (key == 'e' || key == 'E') {
    engineOn = !engineOn;
  }

  if (key == '+' && searchDepth < 6) {
    searchDepth++;
  }

  if (key == '-' && searchDepth > 1) {
    searchDepth--;
  }
}

// ------------------------------------------------------------
// GENERATE LEGAL MOVES
// ------------------------------------------------------------

void updateLegalMoves() {

  legalMoves = generateLegalMoves(whiteTurn);

  if (legalMoves.size() == 0) {

    if (isKingInCheck(whiteTurn)) {
      gameOver = true;
    } else {
      gameOver = true;
    }
  }
}

// ------------------------------------------------------------
// GENERATE ALL LEGAL MOVES
// ------------------------------------------------------------

ArrayList<Move> generateLegalMoves(boolean white) {

  ArrayList<Move> result =
    new ArrayList<Move>();

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {

      char p = board[y][x];

      if (p == '.')
        continue;

      if (isWhite(p) != white)
        continue;

      ArrayList<Move> pseudo =
        generatePseudoMoves(x, y, p);

      for (Move m : pseudo) {

        char[][] save = copyBoard();

        makeMove(m);

        if (!isKingInCheck(white)) {
          result.add(m);
        }

        restoreBoard(save);
      }
    }
  }

  return result;
}

// ------------------------------------------------------------
// PSEUDO MOVES
// ------------------------------------------------------------

ArrayList<Move> generatePseudoMoves(
  int x,
  int y,
  char p) {

  ArrayList<Move> list =
    new ArrayList<Move>();

  boolean white = isWhite(p);

  // ----------------------------------------------------------
  // PAWN
  // ----------------------------------------------------------

  if (Character.toLowerCase(p) == 'p') {

    int dir = white ? -1 : 1;

    int startRow = white ? 6 : 1;

    int ny = y + dir;

    if (inside(x, ny) &&
        board[ny][x] == '.') {

      addMove(list, x, y, x, ny);

      if (y == startRow &&
          board[y + dir*2][x] == '.') {

        addMove(list,
                x, y,
                x, y + dir*2);
      }
    }

    // captures
    for (int dx = -1; dx <= 1; dx += 2) {

      int nx = x + dx;

      if (!inside(nx, ny))
        continue;

      if (board[ny][nx] != '.' &&
          isWhite(board[ny][nx]) != white) {

        addMove(list,
                x, y,
                nx, ny);
      }
    }
  }

  // ----------------------------------------------------------
  // KNIGHT
  // ----------------------------------------------------------

  if (Character.toLowerCase(p) == 'n') {

    int[][] d = {
      {1,2},{2,1},{2,-1},{1,-2},
      {-1,-2},{-2,-1},{-2,1},{-1,2}
    };

    for (int i = 0; i < 8; i++) {

      addIfPossible(list,
                    x, y,
                    x+d[i][0],
                    y+d[i][1],
                    white);
    }
  }

  // ----------------------------------------------------------
  // BISHOP
  // ----------------------------------------------------------

  if (Character.toLowerCase(p) == 'b') {

    slide(list, x, y, white,
          1, 1);
    slide(list, x, y, white,
          1, -1);
    slide(list, x, y, white,
          -1, 1);
    slide(list, x, y, white,
          -1, -1);
  }

  // ----------------------------------------------------------
  // ROOK
  // ----------------------------------------------------------

  if (Character.toLowerCase(p) == 'r') {

    slide(list, x, y, white,
          1, 0);
    slide(list, x, y, white,
          -1, 0);
    slide(list, x, y, white,
          0, 1);
    slide(list, x, y, white,
          0, -1);
  }

  // ----------------------------------------------------------
  // QUEEN
  // ----------------------------------------------------------

  if (Character.toLowerCase(p) == 'q') {

    slide(list, x, y, white,
          1, 0);
    slide(list, x, y, white,
          -1, 0);
    slide(list, x, y, white,
          0, 1);
    slide(list, x, y, white,
          0, -1);

    slide(list, x, y, white,
          1, 1);
    slide(list, x, y, white,
          1, -1);
    slide(list, x, y, white,
          -1, 1);
    slide(list, x, y, white,
          -1, -1);
  }

  // ----------------------------------------------------------
  // KING
  // ----------------------------------------------------------

  if (Character.toLowerCase(p) == 'k') {

    for (int dx = -1; dx <= 1; dx++) {
      for (int dy = -1; dy <= 1; dy++) {

        if (dx == 0 && dy == 0)
          continue;

        addIfPossible(list,
                      x, y,
                      x+dx,
                      y+dy,
                      white);
      }
    }
  }

  return list;
}

// ------------------------------------------------------------
// ADD NORMAL MOVE
// ------------------------------------------------------------

void addMove(ArrayList<Move> list,
             int fx, int fy,
             int tx, int ty) {

  if (!inside(tx, ty))
    return;

  list.add(new Move(fx, fy, tx, ty));
}

// ------------------------------------------------------------
// ADD CAPTURE / NORMAL
// ------------------------------------------------------------

void addIfPossible(ArrayList<Move> list,
                   int fx, int fy,
                   int tx, int ty,
                   boolean white) {

  if (!inside(tx, ty))
    return;

  char target = board[ty][tx];

  if (target == '.' ||
      isWhite(target) != white) {

    list.add(new Move(fx, fy, tx, ty));
  }
}

// ------------------------------------------------------------
// SLIDING PIECES
// ------------------------------------------------------------

void slide(ArrayList<Move> list,
           int x, int y,
           boolean white,
           int dx, int dy) {

  int nx = x + dx;
  int ny = y + dy;

  while (inside(nx, ny)) {

    char target = board[ny][nx];

    if (target == '.') {

      list.add(new Move(x, y, nx, ny));

    } else {

      if (isWhite(target) != white) {

        list.add(new Move(x, y, nx, ny));
      }

      break;
    }

    nx += dx;
    ny += dy;
  }
}

// ------------------------------------------------------------
// MAKE MOVE
// ------------------------------------------------------------

void makeMove(Move m) {

  char p = board[m.fy][m.fx];

  char captured = board[m.ty][m.tx];

  board[m.ty][m.tx] = p;
  board[m.fy][m.fx] = '.';

  // promotion
  if (p == 'P' && m.ty == 0)
    board[m.ty][m.tx] = 'Q';

  if (p == 'p' && m.ty == 7)
    board[m.ty][m.tx] = 'q';

  // move notation
  String s =
    "" + (char)('a' + m.fx) +
    (8 - m.fy) +
    "-" +
    (char)('a' + m.tx) +
    (8 - m.ty);

  moveList.add(s);

  whiteTurn = !whiteTurn;
}

// ------------------------------------------------------------
// UNDO HELPER FOR SEARCH
// ------------------------------------------------------------

char[][] copyBoard() {

  char[][] b = new char[8][8];

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {
      b[y][x] = board[y][x];
    }
  }

  return b;
}

void restoreBoard(char[][] b) {

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {
      board[y][x] = b[y][x];
    }
  }
}

// ------------------------------------------------------------
// ENGINE
// ------------------------------------------------------------

void engineMove() {

  ArrayList<Move> moves =
    generateLegalMoves(false);

  if (moves.size() == 0) {
    gameOver = true;
    return;
  }

  int bestScore = 100000000;
  Move bestMove = moves.get(0);

  for (Move m : moves) {

    char[][] save = copyBoard();

    makeMove(m);

    int score =
      minimax(searchDepth - 1,
              true,
              -100000000,
              100000000);

    restoreBoard(save);

    // BLACK wants smallest score
    if (score < bestScore) {
      bestScore = score;
      bestMove = m;
    }
  }

  makeMove(bestMove);

  updateLegalMoves();
}

// ------------------------------------------------------------
// MINIMAX + ALPHA BETA
// ------------------------------------------------------------

int minimax(int depth,
            boolean white,
            int alpha,
            int beta) {

  if (depth == 0)
    return evaluate();

  ArrayList<Move> moves =
    generateLegalMoves(white);

  if (moves.size() == 0) {

    if (isKingInCheck(white)) {

      if (white)
        return 1000000;

      return -1000000;
    }

    return 0;
  }

  if (white) {

    int best = -100000000;

    for (Move m : moves) {

      char[][] save = copyBoard();

      makeMove(m);

      int score =
        minimax(depth - 1,
                false,
                alpha,
                beta);

      restoreBoard(save);

      best = max(best, score);
      alpha = max(alpha, best);

      if (beta <= alpha)
        break;
    }

    return best;

  } else {

    int best = 100000000;

    for (Move m : moves) {

      char[][] save = copyBoard();

      makeMove(m);

      int score =
        minimax(depth - 1,
                true,
                alpha,
                beta);

      restoreBoard(save);

      best = min(best, score);
      beta = min(beta, best);

      if (beta <= alpha)
        break;
    }

    return best;
  }
}

// ------------------------------------------------------------
// EVALUATION
// ------------------------------------------------------------

int evaluate() {

  int score = 0;

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {

      char p = board[y][x];

      if (p == '.')
        continue;

      int value = pieceValue(p);

      if (isWhite(p))
        score += value;
      else
        score -= value;
    }
  }

  return score;
}

// ------------------------------------------------------------
// PIECE VALUE
// ------------------------------------------------------------

int pieceValue(char p) {

  char q = Character.toLowerCase(p);

  if (q == 'p') return 100;
  if (q == 'n') return 320;
  if (q == 'b') return 330;
  if (q == 'r') return 500;
  if (q == 'q') return 900;
  if (q == 'k') return 20000;

  return 0;
}

// ------------------------------------------------------------
// CHECK KING
// ------------------------------------------------------------

boolean isKingInCheck(boolean white) {

  int kx = -1;
  int ky = -1;

  char king = white ? 'K' : 'k';

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {

      if (board[y][x] == king) {
        kx = x;
        ky = y;
      }
    }
  }

  if (kx == -1)
    return true;

  return squareAttacked(kx, ky, !white);
}

// ------------------------------------------------------------
// ATTACK TEST
// ------------------------------------------------------------

boolean squareAttacked(int x,
                        int y,
                        boolean byWhite) {

  // pawn
  int pawnDir = byWhite ? -1 : 1;

  int py = y - pawnDir;

  if (inside(x-1, py) &&
      board[py][x-1] == (byWhite ? 'P' : 'p'))
    return true;

  if (inside(x+1, py) &&
      board[py][x+1] == (byWhite ? 'P' : 'p'))
    return true;

  // knight
  int[][] nd = {
    {1,2},{2,1},{2,-1},{1,-2},
    {-1,-2},{-2,-1},{-2,1},{-1,2}
  };

  char knight = byWhite ? 'N' : 'n';

  for (int i = 0; i < 8; i++) {

    int nx = x + nd[i][0];
    int ny = y + nd[i][1];

    if (inside(nx, ny) &&
        board[ny][nx] == knight)
      return true;
  }

  // rook / queen
  if (rayAttacked(x,y,byWhite,
                  1,0,'r','q'))
    return true;

  if (rayAttacked(x,y,byWhite,
                  -1,0,'r','q'))
    return true;

  if (rayAttacked(x,y,byWhite,
                  0,1,'r','q'))
    return true;

  if (rayAttacked(x,y,byWhite,
                  0,-1,'r','q'))
    return true;

  // bishop / queen
  if (rayAttacked(x,y,byWhite,
                  1,1,'b','q'))
    return true;

  if (rayAttacked(x,y,byWhite,
                  1,-1,'b','q'))
    return true;

  if (rayAttacked(x,y,byWhite,
                  -1,1,'b','q'))
    return true;

  if (rayAttacked(x,y,byWhite,
                  -1,-1,'b','q'))
    return true;

  // king
  char king = byWhite ? 'K' : 'k';

  for (int dx = -1; dx <= 1; dx++) {
    for (int dy = -1; dy <= 1; dy++) {

      if (dx == 0 && dy == 0)
        continue;

      int nx = x + dx;
      int ny = y + dy;

      if (inside(nx,ny) &&
          board[ny][nx] == king)
        return true;
    }
  }

  return false;
}

// ------------------------------------------------------------
// RAY ATTACK
// ------------------------------------------------------------

boolean rayAttacked(int x,
                    int y,
                    boolean byWhite,
                    int dx,
                    int dy,
                    char piece1,
                    char piece2) {

  int nx = x + dx;
  int ny = y + dy;

  char p1 = byWhite ?
    Character.toUpperCase(piece1) :
    piece1;

  char p2 = byWhite ?
    Character.toUpperCase(piece2) :
    piece2;

  while (inside(nx,ny)) {

    char p = board[ny][nx];

    if (p != '.') {

      if (p == p1 || p == p2)
        return true;

      return false;
    }

    nx += dx;
    ny += dy;
  }

  return false;
}

// ------------------------------------------------------------
// CHECKMATE
// ------------------------------------------------------------

boolean isCheckmate(boolean white) {

  ArrayList<Move> m =
    generateLegalMoves(white);

  return m.size() == 0 &&
         isKingInCheck(white);
}

// ------------------------------------------------------------
// INSIDE BOARD
// ------------------------------------------------------------

boolean inside(int x, int y) {

  return x >= 0 &&
         x < 8 &&
         y >= 0 &&
         y < 8;
}

// ------------------------------------------------------------
// WHITE PIECE
// ------------------------------------------------------------

boolean isWhite(char p) {

  return p >= 'A' &&
         p <= 'Z';
}

// ------------------------------------------------------------
// MOVE CLASS
// ------------------------------------------------------------

class Move {

  int fx;
  int fy;

  int tx;
  int ty;

  Move(int a, int b,
       int c, int d) {

    fx = a;
    fy = b;

    tx = c;
    ty = d;
  }
}





































// ============================================================
// APDE 0.5.3
// ONE FILE CHESS GAME + SMALL CHESS ENGINE
//
// WHITE = human
// BLACK = computer
//
// ENGINE SEARCH DEPTH = 4
//
// Board:
//   board[y][x]
//
// Pieces:
//   P pawn
//   N knight
//   B bishop
//   R rook
//   Q queen
//   K king
//
// Black pieces are lowercase.
//
// Empty square = '.'
// ============================================================

char[][] board = new char[8][8];

boolean whiteTurn = true;
boolean engineOn = true;
boolean gameOver = false;

int selectedX = -1;
int selectedY = -1;

ArrayList<Move> legalMoves = new ArrayList<Move>();
ArrayList<String> moveList = new ArrayList<String>();

int searchDepth = 4;

int squareSize;
int boardLeft;
int boardTop;

// ------------------------------------------------------------
// PROCESSING
// ------------------------------------------------------------

void setup() {
  size(displayWidth, displayHeight);
  textAlign(CENTER, CENTER);
  initGame();
}

void draw() {
  background(35);

  calculateBoardPosition();
  drawBoard();
  drawPieces();
  drawInfo();

  if (gameOver) {
    fill(255, 220);
    rect(boardLeft, boardTop + squareSize * 8 / 2 - 35,
         squareSize * 8, 70);

    fill(20);
    textSize(28);

    if (isCheckmate(whiteTurn)) {
      if (whiteTurn)
        text("CHECKMATE - BLACK WINS",
             width/2,
             boardTop + squareSize * 4);
      else
        text("CHECKMATE - WHITE WINS",
             width/2,
             boardTop + squareSize * 4);
    } else {
      text("STALEMATE",
           width/2,
           boardTop + squareSize * 4);
    }
  }
}

// ------------------------------------------------------------
// BOARD POSITION
// ------------------------------------------------------------

void calculateBoardPosition() {

  squareSize = min(width / 8, (height - 150) / 8);

  boardLeft = (width - squareSize * 8) / 2;
  boardTop = 30;
}

// ------------------------------------------------------------
// NEW GAME
// ------------------------------------------------------------

void initGame() {

  String[] start = {
    "rnbqkbnr",
    "pppppppp",
    "........",
    "........",
    "........",
    "........",
    "PPPPPPPP",
    "RNBQKBNR"
  };

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {
      board[y][x] = start[y].charAt(x);
    }
  }

  whiteTurn = true;
  gameOver = false;

  selectedX = -1;
  selectedY = -1;

  moveList.clear();

  updateLegalMoves();
}

// ------------------------------------------------------------
// DRAW BOARD
// ------------------------------------------------------------

void drawBoard() {

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {

      if ((x + y) % 2 == 0)
        fill(235);
      else
        fill(100);

      rect(boardLeft + x * squareSize,
           boardTop + y * squareSize,
           squareSize,
           squareSize);
    }
  }

  // selected square
  if (selectedX >= 0) {

    fill(255, 220, 0, 120);

    rect(boardLeft + selectedX * squareSize,
         boardTop + selectedY * squareSize,
         squareSize,
         squareSize);
  }

  // legal move marks
  for (Move m : legalMoves) {

    if (m.fx == selectedX && m.fy == selectedY) {

      fill(0, 180, 255, 150);

      ellipse(boardLeft + m.tx * squareSize + squareSize/2,
              boardTop + m.ty * squareSize + squareSize/2,
              squareSize * .25,
              squareSize * .25);
    }
  }
}

// ------------------------------------------------------------
// DRAW PIECES
// ------------------------------------------------------------

void drawPieces() {

  textSize(squareSize * .65);

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {

      char p = board[y][x];

      if (p == '.')
        continue;

      if (isWhite(p))
        fill(255);
      else
        fill(20);

      text(pieceUnicode(p),
           boardLeft + x * squareSize + squareSize/2,
           boardTop + y * squareSize + squareSize/2);
    }
  }
}

// ------------------------------------------------------------
// PIECE SYMBOLS
// ------------------------------------------------------------

String pieceUnicode(char p) {

  if (p == 'K') return "♔";
  if (p == 'Q') return "♕";
  if (p == 'R') return "♖";
  if (p == 'B') return "♗";
  if (p == 'N') return "♘";
  if (p == 'P') return "♙";

  if (p == 'k') return "♚";
  if (p == 'q') return "♛";
  if (p == 'r') return "♜";
  if (p == 'b') return "♝";
  if (p == 'n') return "♞";
  if (p == 'p') return "♟";

  return "";
}

// ------------------------------------------------------------
// INFORMATION
// ------------------------------------------------------------

void drawInfo() {

  fill(255);
  textSize(18);

  String side;

  if (whiteTurn)
    side = "WHITE";
  else
    side = "BLACK";

  text("TURN: " + side,
       width/2,
       boardTop + squareSize * 8 + 25);

  text("ENGINE DEPTH: " + searchDepth,
       width/2,
       boardTop + squareSize * 8 + 50);

  text("ENGINE: " + (engineOn ? "ON" : "OFF"),
       width/2,
       boardTop + squareSize * 8 + 75);

  text("R = restart   E = engine",
       width/2,
       boardTop + squareSize * 8 + 105);
}

// ------------------------------------------------------------
// TOUCH
// ------------------------------------------------------------

void mousePressed() {

  if (gameOver)
    return;

  if (!whiteTurn && engineOn)
    return;

  int x = (mouseX - boardLeft) / squareSize;
  int y = (mouseY - boardTop) / squareSize;

  if (x < 0 || x >= 8 ||
      y < 0 || y >= 8)
    return;

  // nothing selected
  if (selectedX == -1) {

    if (board[y][x] != '.' &&
        isWhite(board[y][x]) &&
        whiteTurn) {

      selectedX = x;
      selectedY = y;
    }

    return;
  }

  // select another own piece
  if (board[y][x] != '.' &&
      isWhite(board[y][x])) {

    selectedX = x;
    selectedY = y;
    return;
  }

  // find selected legal move
  Move chosen = null;

  for (Move m : legalMoves) {

    if (m.fx == selectedX &&
        m.fy == selectedY &&
        m.tx == x &&
        m.ty == y) {

      chosen = m;
      break;
    }
  }

  if (chosen != null) {

    makeMove(chosen);

    selectedX = -1;
    selectedY = -1;

    updateLegalMoves();

    if (!gameOver && !whiteTurn && engineOn) {
      engineMove();
    }
  }
}

// ------------------------------------------------------------
// KEYBOARD
// ------------------------------------------------------------

void keyPressed() {

  if (key == 'r' || key == 'R') {
    initGame();
  }

  if (key == 'e' || key == 'E') {
    engineOn = !engineOn;
  }

  if (key == '+' && searchDepth < 6) {
    searchDepth++;
  }

  if (key == '-' && searchDepth > 1) {
    searchDepth--;
  }
}

// ------------------------------------------------------------
// GENERATE LEGAL MOVES
// ------------------------------------------------------------

void updateLegalMoves() {

  legalMoves = generateLegalMoves(whiteTurn);

  if (legalMoves.size() == 0) {

    if (isKingInCheck(whiteTurn)) {
      gameOver = true;
    } else {
      gameOver = true;
    }
  }
}

// ------------------------------------------------------------
// GENERATE ALL LEGAL MOVES
// ------------------------------------------------------------

ArrayList<Move> generateLegalMoves(boolean white) {

  ArrayList<Move> result =
    new ArrayList<Move>();

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {

      char p = board[y][x];

      if (p == '.')
        continue;

      if (isWhite(p) != white)
        continue;

      ArrayList<Move> pseudo =
        generatePseudoMoves(x, y, p);

      for (Move m : pseudo) {

        char[][] save = copyBoard();

        makeMove(m);

        if (!isKingInCheck(white)) {
          result.add(m);
        }

        restoreBoard(save);
      }
    }
  }

  return result;
}

// ------------------------------------------------------------
// PSEUDO MOVES
// ------------------------------------------------------------

ArrayList<Move> generatePseudoMoves(
  int x,
  int y,
  char p) {

  ArrayList<Move> list =
    new ArrayList<Move>();

  boolean white = isWhite(p);

  // ----------------------------------------------------------
  // PAWN
  // ----------------------------------------------------------

  if (Character.toLowerCase(p) == 'p') {

    int dir = white ? -1 : 1;

    int startRow = white ? 6 : 1;

    int ny = y + dir;

    if (inside(x, ny) &&
        board[ny][x] == '.') {

      addMove(list, x, y, x, ny);

      if (y == startRow &&
          board[y + dir*2][x] == '.') {

        addMove(list,
                x, y,
                x, y + dir*2);
      }
    }

    // captures
    for (int dx = -1; dx <= 1; dx += 2) {

      int nx = x + dx;

      if (!inside(nx, ny))
        continue;

      if (board[ny][nx] != '.' &&
          isWhite(board[ny][nx]) != white) {

        addMove(list,
                x, y,
                nx, ny);
      }
    }
  }

  // ----------------------------------------------------------
  // KNIGHT
  // ----------------------------------------------------------

  if (Character.toLowerCase(p) == 'n') {

    int[][] d = {
      {1,2},{2,1},{2,-1},{1,-2},
      {-1,-2},{-2,-1},{-2,1},{-1,2}
    };

    for (int i = 0; i < 8; i++) {

      addIfPossible(list,
                    x, y,
                    x+d[i][0],
                    y+d[i][1],
                    white);
    }
  }

  // ----------------------------------------------------------
  // BISHOP
  // ----------------------------------------------------------

  if (Character.toLowerCase(p) == 'b') {

    slide(list, x, y, white,
          1, 1);
    slide(list, x, y, white,
          1, -1);
    slide(list, x, y, white,
          -1, 1);
    slide(list, x, y, white,
          -1, -1);
  }

  // ----------------------------------------------------------
  // ROOK
  // ----------------------------------------------------------

  if (Character.toLowerCase(p) == 'r') {

    slide(list, x, y, white,
          1, 0);
    slide(list, x, y, white,
          -1, 0);
    slide(list, x, y, white,
          0, 1);
    slide(list, x, y, white,
          0, -1);
  }

  // ----------------------------------------------------------
  // QUEEN
  // ----------------------------------------------------------

  if (Character.toLowerCase(p) == 'q') {

    slide(list, x, y, white,
          1, 0);
    slide(list, x, y, white,
          -1, 0);
    slide(list, x, y, white,
          0, 1);
    slide(list, x, y, white,
          0, -1);

    slide(list, x, y, white,
          1, 1);
    slide(list, x, y, white,
          1, -1);
    slide(list, x, y, white,
          -1, 1);
    slide(list, x, y, white,
          -1, -1);
  }

  // ----------------------------------------------------------
  // KING
  // ----------------------------------------------------------

  if (Character.toLowerCase(p) == 'k') {

    for (int dx = -1; dx <= 1; dx++) {
      for (int dy = -1; dy <= 1; dy++) {

        if (dx == 0 && dy == 0)
          continue;

        addIfPossible(list,
                      x, y,
                      x+dx,
                      y+dy,
                      white);
      }
    }
  }

  return list;
}

// ------------------------------------------------------------
// ADD NORMAL MOVE
// ------------------------------------------------------------

void addMove(ArrayList<Move> list,
             int fx, int fy,
             int tx, int ty) {

  if (!inside(tx, ty))
    return;

  list.add(new Move(fx, fy, tx, ty));
}

// ------------------------------------------------------------
// ADD CAPTURE / NORMAL
// ------------------------------------------------------------

void addIfPossible(ArrayList<Move> list,
                   int fx, int fy,
                   int tx, int ty,
                   boolean white) {

  if (!inside(tx, ty))
    return;

  char target = board[ty][tx];

  if (target == '.' ||
      isWhite(target) != white) {

    list.add(new Move(fx, fy, tx, ty));
  }
}

// ------------------------------------------------------------
// SLIDING PIECES
// ------------------------------------------------------------

void slide(ArrayList<Move> list,
           int x, int y,
           boolean white,
           int dx, int dy) {

  int nx = x + dx;
  int ny = y + dy;

  while (inside(nx, ny)) {

    char target = board[ny][nx];

    if (target == '.') {

      list.add(new Move(x, y, nx, ny));

    } else {

      if (isWhite(target) != white) {

        list.add(new Move(x, y, nx, ny));
      }

      break;
    }

    nx += dx;
    ny += dy;
  }
}

// ------------------------------------------------------------
// MAKE MOVE
// ------------------------------------------------------------

void makeMove(Move m) {

  char p = board[m.fy][m.fx];

  char captured = board[m.ty][m.tx];

  board[m.ty][m.tx] = p;
  board[m.fy][m.fx] = '.';

  // promotion
  if (p == 'P' && m.ty == 0)
    board[m.ty][m.tx] = 'Q';

  if (p == 'p' && m.ty == 7)
    board[m.ty][m.tx] = 'q';

  // move notation
  String s =
    "" + (char)('a' + m.fx) +
    (8 - m.fy) +
    "-" +
    (char)('a' + m.tx) +
    (8 - m.ty);

  moveList.add(s);

  whiteTurn = !whiteTurn;
}

// ------------------------------------------------------------
// UNDO HELPER FOR SEARCH
// ------------------------------------------------------------

char[][] copyBoard() {

  char[][] b = new char[8][8];

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {
      b[y][x] = board[y][x];
    }
  }

  return b;
}

void restoreBoard(char[][] b) {

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {
      board[y][x] = b[y][x];
    }
  }
}

// ------------------------------------------------------------
// ENGINE
// ------------------------------------------------------------

void engineMove() {

  ArrayList<Move> moves =
    generateLegalMoves(false);

  if (moves.size() == 0) {
    gameOver = true;
    return;
  }

  int bestScore = 100000000;
  Move bestMove = moves.get(0);

  for (Move m : moves) {

    char[][] save = copyBoard();

    makeMove(m);

    int score =
      minimax(searchDepth - 1,
              true,
              -100000000,
              100000000);

    restoreBoard(save);

    // BLACK wants smallest score
    if (score < bestScore) {
      bestScore = score;
      bestMove = m;
    }
  }

  makeMove(bestMove);

  updateLegalMoves();
}

// ------------------------------------------------------------
// MINIMAX + ALPHA BETA
// ------------------------------------------------------------

int minimax(int depth,
            boolean white,
            int alpha,
            int beta) {

  if (depth == 0)
    return evaluate();

  ArrayList<Move> moves =
    generateLegalMoves(white);

  if (moves.size() == 0) {

    if (isKingInCheck(white)) {

      if (white)
        return 1000000;

      return -1000000;
    }

    return 0;
  }

  if (white) {

    int best = -100000000;

    for (Move m : moves) {

      char[][] save = copyBoard();

      makeMove(m);

      int score =
        minimax(depth - 1,
                false,
                alpha,
                beta);

      restoreBoard(save);

      best = max(best, score);
      alpha = max(alpha, best);

      if (beta <= alpha)
        break;
    }

    return best;

  } else {

    int best = 100000000;

    for (Move m : moves) {

      char[][] save = copyBoard();

      makeMove(m);

      int score =
        minimax(depth - 1,
                true,
                alpha,
                beta);

      restoreBoard(save);

      best = min(best, score);
      beta = min(beta, best);

      if (beta <= alpha)
        break;
    }

    return best;
  }
}

// ------------------------------------------------------------
// EVALUATION
// ------------------------------------------------------------

int evaluate() {

  int score = 0;

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {

      char p = board[y][x];

      if (p == '.')
        continue;

      int value = pieceValue(p);

      if (isWhite(p))
        score += value;
      else
        score -= value;
    }
  }

  return score;
}

// ------------------------------------------------------------
// PIECE VALUE
// ------------------------------------------------------------

int pieceValue(char p) {

  char q = Character.toLowerCase(p);

  if (q == 'p') return 100;
  if (q == 'n') return 320;
  if (q == 'b') return 330;
  if (q == 'r') return 500;
  if (q == 'q') return 900;
  if (q == 'k') return 20000;

  return 0;
}

// ------------------------------------------------------------
// CHECK KING
// ------------------------------------------------------------

boolean isKingInCheck(boolean white) {

  int kx = -1;
  int ky = -1;

  char king = white ? 'K' : 'k';

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {

      if (board[y][x] == king) {
        kx = x;
        ky = y;
      }
    }
  }

  if (kx == -1)
    return true;

  return squareAttacked(kx, ky, !white);
}

// ------------------------------------------------------------
// ATTACK TEST
// ------------------------------------------------------------

boolean squareAttacked(int x,
                        int y,
                        boolean byWhite) {

  // pawn
  int pawnDir = byWhite ? -1 : 1;

  int py = y - pawnDir;

  if (inside(x-1, py) &&
      board[py][x-1] == (byWhite ? 'P' : 'p'))
    return true;

  if (inside(x+1, py) &&
      board[py][x+1] == (byWhite ? 'P' : 'p'))
    return true;

  // knight
  int[][] nd = {
    {1,2},{2,1},{2,-1},{1,-2},
    {-1,-2},{-2,-1},{-2,1},{-1,2}
  };

  char knight = byWhite ? 'N' : 'n';

  for (int i = 0; i < 8; i++) {

    int nx = x + nd[i][0];
    int ny = y + nd[i][1];

    if (inside(nx, ny) &&
        board[ny][nx] == knight)
      return true;
  }

  // rook / queen
  if (rayAttacked(x,y,byWhite,
                  1,0,'r','q'))
    return true;

  if (rayAttacked(x,y,byWhite,
                  -1,0,'r','q'))
    return true;

  if (rayAttacked(x,y,byWhite,
                  0,1,'r','q'))
    return true;

  if (rayAttacked(x,y,byWhite,
                  0,-1,'r','q'))
    return true;

  // bishop / queen
  if (rayAttacked(x,y,byWhite,
                  1,1,'b','q'))
    return true;

  if (rayAttacked(x,y,byWhite,
                  1,-1,'b','q'))
    return true;

  if (rayAttacked(x,y,byWhite,
                  -1,1,'b','q'))
    return true;

  if (rayAttacked(x,y,byWhite,
                  -1,-1,'b','q'))
    return true;

  // king
  char king = byWhite ? 'K' : 'k';

  for (int dx = -1; dx <= 1; dx++) {
    for (int dy = -1; dy <= 1; dy++) {

      if (dx == 0 && dy == 0)
        continue;

      int nx = x + dx;
      int ny = y + dy;

      if (inside(nx,ny) &&
          board[ny][nx] == king)
        return true;
    }
  }

  return false;
}

// ------------------------------------------------------------
// RAY ATTACK
// ------------------------------------------------------------

boolean rayAttacked(int x,
                    int y,
                    boolean byWhite,
                    int dx,
                    int dy,
                    char piece1,
                    char piece2) {

  int nx = x + dx;
  int ny = y + dy;

  char p1 = byWhite ?
    Character.toUpperCase(piece1) :
    piece1;

  char p2 = byWhite ?
    Character.toUpperCase(piece2) :
    piece2;

  while (inside(nx,ny)) {

    char p = board[ny][nx];

    if (p != '.') {

      if (p == p1 || p == p2)
        return true;

      return false;
    }

    nx += dx;
    ny += dy;
  }

  return false;
}

// ------------------------------------------------------------
// CHECKMATE
// ------------------------------------------------------------

boolean isCheckmate(boolean white) {

  ArrayList<Move> m =
    generateLegalMoves(white);

  return m.size() == 0 &&
         isKingInCheck(white);
}

// ------------------------------------------------------------
// INSIDE BOARD
// ------------------------------------------------------------

boolean inside(int x, int y) {

  return x >= 0 &&
         x < 8 &&
         y >= 0 &&
         y < 8;
}

// ------------------------------------------------------------
// WHITE PIECE
// ------------------------------------------------------------

boolean isWhite(char p) {

  return p >= 'A' &&
         p <= 'Z';
}

// ------------------------------------------------------------
// MOVE CLASS
// ------------------------------------------------------------

class Move {

  int fx;
  int fy;

  int tx;
  int ty;

  Move(int a, int b,
       int c, int d) {

    fx = a;
    fy = b;

    tx = c;
    ty = d;
  }
}
























// ============================================================
// APDE 0.5.3
// ONE FILE CHESS GAME + SMALL CHESS ENGINE
//
// WHITE = human
// BLACK = computer
//
// ENGINE SEARCH DEPTH = 4
//
// Board:
//   board[y][x]
//
// Pieces:
//   P pawn
//   N knight
//   B bishop
//   R rook
//   Q queen
//   K king
//
// Black pieces are lowercase.
//
// Empty square = '.'
// ============================================================

char[][] board = new char[8][8];

boolean whiteTurn = true;
boolean engineOn = true;
boolean gameOver = false;

int selectedX = -1;
int selectedY = -1;

ArrayList<Move> legalMoves = new ArrayList<Move>();
ArrayList<String> moveList = new ArrayList<String>();

int searchDepth = 4;

int squareSize;
int boardLeft;
int boardTop;

// ------------------------------------------------------------
// PROCESSING
// ------------------------------------------------------------

void setup() {
  size(displayWidth, displayHeight);
  textAlign(CENTER, CENTER);
  initGame();
}

void draw() {
  background(35);

  calculateBoardPosition();
  drawBoard();
  drawPieces();
  drawInfo();

  if (gameOver) {
    fill(255, 220);
    rect(boardLeft, boardTop + squareSize * 8 / 2 - 35,
         squareSize * 8, 70);

    fill(20);
    textSize(28);

    if (isCheckmate(whiteTurn)) {
      if (whiteTurn)
        text("CHECKMATE - BLACK WINS",
             width/2,
             boardTop + squareSize * 4);
      else
        text("CHECKMATE - WHITE WINS",
             width/2,
             boardTop + squareSize * 4);
    } else {
      text("STALEMATE",
           width/2,
           boardTop + squareSize * 4);
    }
  }
}

// ------------------------------------------------------------
// BOARD POSITION
// ------------------------------------------------------------

void calculateBoardPosition() {

  squareSize = min(width / 8, (height - 150) / 8);

  boardLeft = (width - squareSize * 8) / 2;
  boardTop = 30;
}

// ------------------------------------------------------------
// NEW GAME
// ------------------------------------------------------------

void initGame() {

  String[] start = {
    "rnbqkbnr",
    "pppppppp",
    "........",
    "........",
    "........",
    "........",
    "PPPPPPPP",
    "RNBQKBNR"
  };

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {
      board[y][x] = start[y].charAt(x);
    }
  }

  whiteTurn = true;
  gameOver = false;

  selectedX = -1;
  selectedY = -1;

  moveList.clear();

  updateLegalMoves();
}

// ------------------------------------------------------------
// DRAW BOARD
// ------------------------------------------------------------

void drawBoard() {

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {

      if ((x + y) % 2 == 0)
        fill(235);
      else
        fill(100);

      rect(boardLeft + x * squareSize,
           boardTop + y * squareSize,
           squareSize,
           squareSize);
    }
  }

  // selected square
  if (selectedX >= 0) {

    fill(255, 220, 0, 120);

    rect(boardLeft + selectedX * squareSize,
         boardTop + selectedY * squareSize,
         squareSize,
         squareSize);
  }

  // legal move marks
  for (Move m : legalMoves) {

    if (m.fx == selectedX && m.fy == selectedY) {

      fill(0, 180, 255, 150);

      ellipse(boardLeft + m.tx * squareSize + squareSize/2,
              boardTop + m.ty * squareSize + squareSize/2,
              squareSize * .25,
              squareSize * .25);
    }
  }
}

// ------------------------------------------------------------
// DRAW PIECES
// ------------------------------------------------------------

void drawPieces() {

  textSize(squareSize * .65);

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {

      char p = board[y][x];

      if (p == '.')
        continue;

      if (isWhite(p))
        fill(255);
      else
        fill(20);

      text(pieceUnicode(p),
           boardLeft + x * squareSize + squareSize/2,
           boardTop + y * squareSize + squareSize/2);
    }
  }
}

// ------------------------------------------------------------
// PIECE SYMBOLS
// ------------------------------------------------------------

String pieceUnicode(char p) {

  if (p == 'K') return "♔";
  if (p == 'Q') return "♕";
  if (p == 'R') return "♖";
  if (p == 'B') return "♗";
  if (p == 'N') return "♘";
  if (p == 'P') return "♙";

  if (p == 'k') return "♚";
  if (p == 'q') return "♛";
  if (p == 'r') return "♜";
  if (p == 'b') return "♝";
  if (p == 'n') return "♞";
  if (p == 'p') return "♟";

  return "";
}

// ------------------------------------------------------------
// INFORMATION
// ------------------------------------------------------------

void drawInfo() {

  fill(255);
  textSize(18);

  String side;

  if (whiteTurn)
    side = "WHITE";
  else
    side = "BLACK";

  text("TURN: " + side,
       width/2,
       boardTop + squareSize * 8 + 25);

  text("ENGINE DEPTH: " + searchDepth,
       width/2,
       boardTop + squareSize * 8 + 50);

  text("ENGINE: " + (engineOn ? "ON" : "OFF"),
       width/2,
       boardTop + squareSize * 8 + 75);

  text("R = restart   E = engine",
       width/2,
       boardTop + squareSize * 8 + 105);
}

// ------------------------------------------------------------
// TOUCH
// ------------------------------------------------------------

void mousePressed() {

  if (gameOver)
    return;

  if (!whiteTurn && engineOn)
    return;

  int x = (mouseX - boardLeft) / squareSize;
  int y = (mouseY - boardTop) / squareSize;

  if (x < 0 || x >= 8 ||
      y < 0 || y >= 8)
    return;

  // nothing selected
  if (selectedX == -1) {

    if (board[y][x] != '.' &&
        isWhite(board[y][x]) &&
        whiteTurn) {

      selectedX = x;
      selectedY = y;
    }

    return;
  }

  // select another own piece
  if (board[y][x] != '.' &&
      isWhite(board[y][x])) {

    selectedX = x;
    selectedY = y;
    return;
  }

  // find selected legal move
  Move chosen = null;

  for (Move m : legalMoves) {

    if (m.fx == selectedX &&
        m.fy == selectedY &&
        m.tx == x &&
        m.ty == y) {

      chosen = m;
      break;
    }
  }

  if (chosen != null) {

    makeMove(chosen);

    selectedX = -1;
    selectedY = -1;

    updateLegalMoves();

    if (!gameOver && !whiteTurn && engineOn) {
      engineMove();
    }
  }
}

// ------------------------------------------------------------
// KEYBOARD
// ------------------------------------------------------------

void keyPressed() {

  if (key == 'r' || key == 'R') {
    initGame();
  }

  if (key == 'e' || key == 'E') {
    engineOn = !engineOn;
  }

  if (key == '+' && searchDepth < 6) {
    searchDepth++;
  }

  if (key == '-' && searchDepth > 1) {
    searchDepth--;
  }
}

// ------------------------------------------------------------
// GENERATE LEGAL MOVES
// ------------------------------------------------------------

void updateLegalMoves() {

  legalMoves = generateLegalMoves(whiteTurn);

  if (legalMoves.size() == 0) {

    if (isKingInCheck(whiteTurn)) {
      gameOver = true;
    } else {
      gameOver = true;
    }
  }
}

// ------------------------------------------------------------
// GENERATE ALL LEGAL MOVES
// ------------------------------------------------------------

ArrayList<Move> generateLegalMoves(boolean white) {

  ArrayList<Move> result =
    new ArrayList<Move>();

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {

      char p = board[y][x];

      if (p == '.')
        continue;

      if (isWhite(p) != white)
        continue;

      ArrayList<Move> pseudo =
        generatePseudoMoves(x, y, p);

      for (Move m : pseudo) {

        char[][] save = copyBoard();

        makeMove(m);

        if (!isKingInCheck(white)) {
          result.add(m);
        }

        restoreBoard(save);
      }
    }
  }

  return result;
}

// ------------------------------------------------------------
// PSEUDO MOVES
// ------------------------------------------------------------

ArrayList<Move> generatePseudoMoves(
  int x,
  int y,
  char p) {

  ArrayList<Move> list =
    new ArrayList<Move>();

  boolean white = isWhite(p);

  // ----------------------------------------------------------
  // PAWN
  // ----------------------------------------------------------

  if (Character.toLowerCase(p) == 'p') {

    int dir = white ? -1 : 1;

    int startRow = white ? 6 : 1;

    int ny = y + dir;

    if (inside(x, ny) &&
        board[ny][x] == '.') {

      addMove(list, x, y, x, ny);

      if (y == startRow &&
          board[y + dir*2][x] == '.') {

        addMove(list,
                x, y,
                x, y + dir*2);
      }
    }

    // captures
    for (int dx = -1; dx <= 1; dx += 2) {

      int nx = x + dx;

      if (!inside(nx, ny))
        continue;

      if (board[ny][nx] != '.' &&
          isWhite(board[ny][nx]) != white) {

        addMove(list,
                x, y,
                nx, ny);
      }
    }
  }

  // ----------------------------------------------------------
  // KNIGHT
  // ----------------------------------------------------------

  if (Character.toLowerCase(p) == 'n') {

    int[][] d = {
      {1,2},{2,1},{2,-1},{1,-2},
      {-1,-2},{-2,-1},{-2,1},{-1,2}
    };

    for (int i = 0; i < 8; i++) {

      addIfPossible(list,
                    x, y,
                    x+d[i][0],
                    y+d[i][1],
                    white);
    }
  }

  // ----------------------------------------------------------
  // BISHOP
  // ----------------------------------------------------------

  if (Character.toLowerCase(p) == 'b') {

    slide(list, x, y, white,
          1, 1);
    slide(list, x, y, white,
          1, -1);
    slide(list, x, y, white,
          -1, 1);
    slide(list, x, y, white,
          -1, -1);
  }

  // ----------------------------------------------------------
  // ROOK
  // ----------------------------------------------------------

  if (Character.toLowerCase(p) == 'r') {

    slide(list, x, y, white,
          1, 0);
    slide(list, x, y, white,
          -1, 0);
    slide(list, x, y, white,
          0, 1);
    slide(list, x, y, white,
          0, -1);
  }

  // ----------------------------------------------------------
  // QUEEN
  // ----------------------------------------------------------

  if (Character.toLowerCase(p) == 'q') {

    slide(list, x, y, white,
          1, 0);
    slide(list, x, y, white,
          -1, 0);
    slide(list, x, y, white,
          0, 1);
    slide(list, x, y, white,
          0, -1);

    slide(list, x, y, white,
          1, 1);
    slide(list, x, y, white,
          1, -1);
    slide(list, x, y, white,
          -1, 1);
    slide(list, x, y, white,
          -1, -1);
  }

  // ----------------------------------------------------------
  // KING
  // ----------------------------------------------------------

  if (Character.toLowerCase(p) == 'k') {

    for (int dx = -1; dx <= 1; dx++) {
      for (int dy = -1; dy <= 1; dy++) {

        if (dx == 0 && dy == 0)
          continue;

        addIfPossible(list,
                      x, y,
                      x+dx,
                      y+dy,
                      white);
      }
    }
  }

  return list;
}

// ------------------------------------------------------------
// ADD NORMAL MOVE
// ------------------------------------------------------------

void addMove(ArrayList<Move> list,
             int fx, int fy,
             int tx, int ty) {

  if (!inside(tx, ty))
    return;

  list.add(new Move(fx, fy, tx, ty));
}

// ------------------------------------------------------------
// ADD CAPTURE / NORMAL
// ------------------------------------------------------------

void addIfPossible(ArrayList<Move> list,
                   int fx, int fy,
                   int tx, int ty,
                   boolean white) {

  if (!inside(tx, ty))
    return;

  char target = board[ty][tx];

  if (target == '.' ||
      isWhite(target) != white) {

    list.add(new Move(fx, fy, tx, ty));
  }
}

// ------------------------------------------------------------
// SLIDING PIECES
// ------------------------------------------------------------

void slide(ArrayList<Move> list,
           int x, int y,
           boolean white,
           int dx, int dy) {

  int nx = x + dx;
  int ny = y + dy;

  while (inside(nx, ny)) {

    char target = board[ny][nx];

    if (target == '.') {

      list.add(new Move(x, y, nx, ny));

    } else {

      if (isWhite(target) != white) {

        list.add(new Move(x, y, nx, ny));
      }

      break;
    }

    nx += dx;
    ny += dy;
  }
}

// ------------------------------------------------------------
// MAKE MOVE
// ------------------------------------------------------------

void makeMove(Move m) {

  char p = board[m.fy][m.fx];

  char captured = board[m.ty][m.tx];

  board[m.ty][m.tx] = p;
  board[m.fy][m.fx] = '.';

  // promotion
  if (p == 'P' && m.ty == 0)
    board[m.ty][m.tx] = 'Q';

  if (p == 'p' && m.ty == 7)
    board[m.ty][m.tx] = 'q';

  // move notation
  String s =
    "" + (char)('a' + m.fx) +
    (8 - m.fy) +
    "-" +
    (char)('a' + m.tx) +
    (8 - m.ty);

  moveList.add(s);

  whiteTurn = !whiteTurn;
}

// ------------------------------------------------------------
// UNDO HELPER FOR SEARCH
// ------------------------------------------------------------

char[][] copyBoard() {

  char[][] b = new char[8][8];

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {
      b[y][x] = board[y][x];
    }
  }

  return b;
}

void restoreBoard(char[][] b) {

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {
      board[y][x] = b[y][x];
    }
  }
}

// ------------------------------------------------------------
// ENGINE
// ------------------------------------------------------------

void engineMove() {

  ArrayList<Move> moves =
    generateLegalMoves(false);

  if (moves.size() == 0) {
    gameOver = true;
    return;
  }

  int bestScore = 100000000;
  Move bestMove = moves.get(0);

  for (Move m : moves) {

    char[][] save = copyBoard();

    makeMove(m);

    int score =
      minimax(searchDepth - 1,
              true,
              -100000000,
              100000000);

    restoreBoard(save);

    // BLACK wants smallest score
    if (score < bestScore) {
      bestScore = score;
      bestMove = m;
    }
  }

  makeMove(bestMove);

  updateLegalMoves();
}

// ------------------------------------------------------------
// MINIMAX + ALPHA BETA
// ------------------------------------------------------------

int minimax(int depth,
            boolean white,
            int alpha,
            int beta) {

  if (depth == 0)
    return evaluate();

  ArrayList<Move> moves =
    generateLegalMoves(white);

  if (moves.size() == 0) {

    if (isKingInCheck(white)) {

      if (white)
        return 1000000;

      return -1000000;
    }

    return 0;
  }

  if (white) {

    int best = -100000000;

    for (Move m : moves) {

      char[][] save = copyBoard();

      makeMove(m);

      int score =
        minimax(depth - 1,
                false,
                alpha,
                beta);

      restoreBoard(save);

      best = max(best, score);
      alpha = max(alpha, best);

      if (beta <= alpha)
        break;
    }

    return best;

  } else {

    int best = 100000000;

    for (Move m : moves) {

      char[][] save = copyBoard();

      makeMove(m);

      int score =
        minimax(depth - 1,
                true,
                alpha,
                beta);

      restoreBoard(save);

      best = min(best, score);
      beta = min(beta, best);

      if (beta <= alpha)
        break;
    }

    return best;
  }
}

// ------------------------------------------------------------
// EVALUATION
// ------------------------------------------------------------

int evaluate() {

  int score = 0;

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {

      char p = board[y][x];

      if (p == '.')
        continue;

      int value = pieceValue(p);

      if (isWhite(p))
        score += value;
      else
        score -= value;
    }
  }

  return score;
}

// ------------------------------------------------------------
// PIECE VALUE
// ------------------------------------------------------------

int pieceValue(char p) {

  char q = Character.toLowerCase(p);

  if (q == 'p') return 100;
  if (q == 'n') return 320;
  if (q == 'b') return 330;
  if (q == 'r') return 500;
  if (q == 'q') return 900;
  if (q == 'k') return 20000;

  return 0;
}

// ------------------------------------------------------------
// CHECK KING
// ------------------------------------------------------------

boolean isKingInCheck(boolean white) {

  int kx = -1;
  int ky = -1;

  char king = white ? 'K' : 'k';

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {

      if (board[y][x] == king) {
        kx = x;
        ky = y;
      }
    }
  }

  if (kx == -1)
    return true;

  return squareAttacked(kx, ky, !white);
}

// ------------------------------------------------------------
// ATTACK TEST
// ------------------------------------------------------------

boolean squareAttacked(int x,
                        int y,
                        boolean byWhite) {

  // pawn
  int pawnDir = byWhite ? -1 : 1;

  int py = y - pawnDir;

  if (inside(x-1, py) &&
      board[py][x-1] == (byWhite ? 'P' : 'p'))
    return true;

  if (inside(x+1, py) &&
      board[py][x+1] == (byWhite ? 'P' : 'p'))
    return true;

  // knight
  int[][] nd = {
    {1,2},{2,1},{2,-1},{1,-2},
    {-1,-2},{-2,-1},{-2,1},{-1,2}
  };

  char knight = byWhite ? 'N' : 'n';

  for (int i = 0; i < 8; i++) {

    int nx = x + nd[i][0];
    int ny = y + nd[i][1];

    if (inside(nx, ny) &&
        board[ny][nx] == knight)
      return true;
  }

  // rook / queen
  if (rayAttacked(x,y,byWhite,
                  1,0,'r','q'))
    return true;

  if (rayAttacked(x,y,byWhite,
                  -1,0,'r','q'))
    return true;

  if (rayAttacked(x,y,byWhite,
                  0,1,'r','q'))
    return true;

  if (rayAttacked(x,y,byWhite,
                  0,-1,'r','q'))
    return true;

  // bishop / queen
  if (rayAttacked(x,y,byWhite,
                  1,1,'b','q'))
    return true;

  if (rayAttacked(x,y,byWhite,
                  1,-1,'b','q'))
    return true;

  if (rayAttacked(x,y,byWhite,
                  -1,1,'b','q'))
    return true;

  if (rayAttacked(x,y,byWhite,
                  -1,-1,'b','q'))
    return true;

  // king
  char king = byWhite ? 'K' : 'k';

  for (int dx = -1; dx <= 1; dx++) {
    for (int dy = -1; dy <= 1; dy++) {

      if (dx == 0 && dy == 0)
        continue;

      int nx = x + dx;
      int ny = y + dy;

      if (inside(nx,ny) &&
          board[ny][nx] == king)
        return true;
    }
  }

  return false;
}

// ------------------------------------------------------------
// RAY ATTACK
// ------------------------------------------------------------

boolean rayAttacked(int x,
                    int y,
                    boolean byWhite,
                    int dx,
                    int dy,
                    char piece1,
                    char piece2) {

  int nx = x + dx;
  int ny = y + dy;

  char p1 = byWhite ?
    Character.toUpperCase(piece1) :
    piece1;

  char p2 = byWhite ?
    Character.toUpperCase(piece2) :
    piece2;

  while (inside(nx,ny)) {

    char p = board[ny][nx];

    if (p != '.') {

      if (p == p1 || p == p2)
        return true;

      return false;
    }

    nx += dx;
    ny += dy;
  }

  return false;
}

// ------------------------------------------------------------
// CHECKMATE
// ------------------------------------------------------------

boolean isCheckmate(boolean white) {

  ArrayList<Move> m =
    generateLegalMoves(white);

  return m.size() == 0 &&
         isKingInCheck(white);
}

// ------------------------------------------------------------
// INSIDE BOARD
// ------------------------------------------------------------

boolean inside(int x, int y) {

  return x >= 0 &&
         x < 8 &&
         y >= 0 &&
         y < 8;
}

// ------------------------------------------------------------
// WHITE PIECE
// ------------------------------------------------------------

boolean isWhite(char p) {

  return p >= 'A' &&
         p <= 'Z';
}

// ------------------------------------------------------------
// MOVE CLASS
// ------------------------------------------------------------

class Move {

  int fx;
  int fy;

  int tx;
  int ty;

  Move(int a, int b,
       int c, int d) {

    fx = a;
    fy = b;

    tx = c;
    ty = d;
  }
}






*/

































