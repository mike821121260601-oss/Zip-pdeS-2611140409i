











/*

SYSTEM ALERT WINDOW
SYSTEM ALERT WINDOW
SYSTEM ALERT WINDOW
SYSTEM ALERT WINDOW


  CHESS TRANSPARENT OVERLAY
  APDE 0.5.3 / Android

  Функції:
  - прозорий шар поверх іншої програми
  - малювання пальцем
  - CLEAR
  - ERASE
  - HIDE / SHOW
  - кольори
  - таймер
  - +1 / -1 / +5 / -5 секунд
  - BACK TO CHESS

  ВАЖЛИВО:
  У APDE:
  Sketch -> Sketch Permissions
  додай:

  android.permission.SYSTEM_ALERT_WINDOW

  Потім Android:
  Settings -> Apps -> Special access ->
  Display over other apps -> дозволити цій програмі.
*/

import android.app.Activity;
import android.content.Intent;
import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.view.*;
import android.widget.Toast;

Activity act;
WindowManager wm;

OverlayView overlay;

boolean overlayOK = false;

void setup() {
  fullScreen();
  orientation(LANDSCAPE);

  act = this.getActivity();

  // Повністю прозоре вікно основної Activity
  act.getWindow().setBackgroundDrawable(
    new ColorDrawable(Color.TRANSPARENT)
  );

  act.getWindow().setFormat(
    android.graphics.PixelFormat.TRANSLUCENT
  );

  createOverlay();
}

void draw() {
  // Все малювання робить OverlayView.
  background(0, 0);
}

void createOverlay() {

  if (Build.VERSION.SDK_INT >= 23) {
    if (!Settings.canDrawOverlays(act)) {
      Toast.makeText(
        act,
        "Дозволь Display over other apps",
        Toast.LENGTH_LONG
      ).show();

      try {
        Intent i = new Intent(
          Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
          Uri.parse("package:" + act.getPackageName())
        );
        act.startActivity(i);
      }
      catch(Exception e) {
        Intent i = new Intent(
          Settings.ACTION_MANAGE_OVERLAY_PERMISSION
        );
        act.startActivity(i);
      }

      return;
    }
  }

  overlayOK = true;

  wm = (WindowManager)act.getSystemService(
    Context.WINDOW_SERVICE
  );

  overlay = new OverlayView(act);

  WindowManager.LayoutParams p =
    new WindowManager.LayoutParams();

  p.width  = WindowManager.LayoutParams.MATCH_PARENT;
  p.height = WindowManager.LayoutParams.MATCH_PARENT;

  if (Build.VERSION.SDK_INT >= 26) {
    p.type =
      WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
  }
  else {
    p.type =
      WindowManager.LayoutParams.TYPE_PHONE;
  }

  p.flags =
      WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
    | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
    | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
    | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;

  p.format = android.graphics.PixelFormat.TRANSLUCENT;

  p.gravity =
      Gravity.TOP | Gravity.LEFT;

  try {
    wm.addView(overlay, p);
  }
  catch(Exception e) {
    Toast.makeText(
      act,
      "Overlay error: " + e,
      Toast.LENGTH_LONG
    ).show();
  }
}


// ----------------------------------------------------
// OVERLAY VIEW
// ----------------------------------------------------

class OverlayView extends View {

  Paint paint;
  Paint buttonPaint;
  Paint textPaint;

  ArrayList<Line> lines =
    new ArrayList<Line>();

  boolean drawing = false;
  boolean erasing = false;

  boolean panel = true;

  float oldX;
  float oldY;

  int currentColor = Color.RED;

  float strokeWidth = 7;

  long timerSeconds = 300;

  long lastTimerTime;

  RectF clearRect =
    new RectF();

  OverlayView(Context c) {
    super(c);

    setLayerType(
      View.LAYER_TYPE_SOFTWARE,
      null
    );

    paint = new Paint();
    paint.setAntiAlias(true);
    paint.setStrokeCap(Paint.Cap.ROUND);
    paint.setStrokeJoin(Paint.Join.ROUND);

    buttonPaint = new Paint();
    buttonPaint.setAntiAlias(true);

    textPaint = new Paint();
    textPaint.setAntiAlias(true);
    textPaint.setTypeface(
      Typeface.create(
        Typeface.DEFAULT,
        Typeface.BOLD
      )
    );

    lastTimerTime =
      System.currentTimeMillis();
  }


  protected void onDraw(Canvas c) {

    super.onDraw(c);

    // ПРОЗОРИЙ ФОН
    c.drawColor(Color.TRANSPARENT,
      PorterDuff.Mode.CLEAR);

    if (!panel) {
      drawLines(c);
      return;
    }

    drawLines(c);
    drawPanel(c);

    updateTimer();
  }


  // --------------------------------------------------
  // LINES
  // --------------------------------------------------

  void drawLines(Canvas c) {

    for (int i = 0;
         i < lines.size();
         i++) {

      Line l = lines.get(i);

      paint.setStyle(Paint.Style.STROKE);
      paint.setStrokeWidth(l.w);
      paint.setColor(l.color);

      c.drawLine(
        l.x1, l.y1,
        l.x2, l.y2,
        paint
      );
    }
  }


  // --------------------------------------------------
  // PANEL
  // --------------------------------------------------

  void drawPanel(Canvas c) {

    int w = getWidth();
    int h = getHeight();

    // верхня прозора панель
    buttonPaint.setColor(
      Color.argb(170, 20, 20, 20)
    );

    c.drawRoundRect(
      new RectF(
        8, 8,
        w - 8, 105
      ),
      15, 15,
      buttonPaint
    );

    // кнопки
    button(
      c, 15, 18,
      95, 55,
      "CLEAR"
    );

    button(
      c, 105, 18,
      185, 55,
      "ERASE"
    );

    button(
      c, 195, 18,
      275, 55,
      "RED"
    );

    button(
      c, 285, 18,
      365, 55,
      "GREEN"
    );

    button(
      c, 375, 18,
      455, 55,
      "BLUE"
    );

    button(
      c, 465, 18,
      545, 55,
      "HIDE"
    );

    button(
      c, 555, 18,
      635, 55,
      "BACK"
    );

    // таймер
    String t =
      formatTime(timerSeconds);

    textPaint.setTextSize(25);
    textPaint.setColor(Color.WHITE);

    c.drawText(
      t,
      650,
      48,
      textPaint
    );

    button(
      c, 720, 18,
      775, 55,
      "-5"
    );

    button(
      c, 780, 18,
      835, 55,
      "-1"
    );

    button(
      c, 840, 18,
      895, 55,
      "+1"
    );

    button(
      c, 900, 18,
      955, 55,
      "+5"
    );

    textPaint.setTextSize(15);
    textPaint.setColor(Color.WHITE);

    c.drawText(
      "DRAW OVER CHESS",
      20,
      90,
      textPaint
    );
  }


  void button(
    Canvas c,
    float x1,
    float y1,
    float x2,
    float y2,
    String s
  ) {

    buttonPaint.setColor(
      Color.argb(220, 55, 55, 55)
    );

    c.drawRoundRect(
      new RectF(
        x1, y1,
        x2, y2
      ),
      8, 8,
      buttonPaint
    );

    textPaint.setTextSize(14);
    textPaint.setColor(Color.WHITE);
    textPaint.setTextAlign(Paint.Align.CENTER);

    c.drawText(
      s,
      (x1+x2)/2,
      y1+25,
      textPaint
    );

    textPaint.setTextAlign(Paint.Align.LEFT);
  }


  // --------------------------------------------------
  // TOUCH
  // --------------------------------------------------

  public boolean onTouchEvent(
    android.view.MotionEvent e
  ) {

    float x = e.getX();
    float y = e.getY();

    if (e.getAction() ==
        MotionEvent.ACTION_DOWN) {

      // кнопки
      if (panel && y < 70) {

        if (x >= 15 && x < 95) {
          lines.clear();
          invalidate();
          return true;
        }

        if (x >= 105 && x < 185) {
          erasing = true;
          return true;
        }

        if (x >= 195 && x < 275) {
          currentColor = Color.RED;
          erasing = false;
          return true;
        }

        if (x >= 285 && x < 365) {
          currentColor = Color.GREEN;
          erasing = false;
          return true;
        }

        if (x >= 375 && x < 455) {
          currentColor = Color.BLUE;
          erasing = false;
          return true;
        }

        if (x >= 465 && x < 545) {
          panel = false;
          invalidate();
          return true;
        }

        if (x >= 555 && x < 635) {
          backToChess();
          return true;
        }

        if (x >= 720 && x < 775) {
          timerSeconds -= 5;
          if (timerSeconds < 0)
            timerSeconds = 0;
          invalidate();
          return true;
        }

        if (x >= 780 && x < 835) {
          timerSeconds -= 1;
          if (timerSeconds < 0)
            timerSeconds = 0;
          invalidate();
          return true;
        }

        if (x >= 840 && x < 895) {
          timerSeconds++;
          invalidate();
          return true;
        }

        if (x >= 900 && x < 955) {
          timerSeconds += 5;
          invalidate();
          return true;
        }
      }

      // малювання
      oldX = x;
      oldY = y;

      drawing = true;

      return true;
    }


    if (e.getAction() ==
        MotionEvent.ACTION_MOVE) {

      if (!drawing)
        return true;

      if (erasing) {

        eraseNear(x, y);

      } else {

        lines.add(
          new Line(
            oldX,
            oldY,
            x,
            y,
            currentColor,
            strokeWidth
          )
        );
      }

      oldX = x;
      oldY = y;

      invalidate();

      return true;
    }


    if (e.getAction() ==
        MotionEvent.ACTION_UP) {

      drawing = false;

      return true;
    }

    return true;
  }


  // --------------------------------------------------
  // ERASE
  // --------------------------------------------------

  void eraseNear(float x, float y) {

    for (int i = lines.size()-1;
         i >= 0;
         i--) {

      Line l = lines.get(i);

      float dx = l.x2-l.x1;
      float dy = l.y2-l.y1;

      float len =
        sqrt(dx*dx + dy*dy);

      if (len < 1)
        continue;

      float t =
        ((x-l.x1)*dx +
         (y-l.y1)*dy) /
        (len*len);

      t = constrain(t,0,1);

      float px =
        l.x1 + t*dx;

      float py =
        l.y1 + t*dy;

      float d =
        dist(x,y,px,py);

      if (d < 35) {
        lines.remove(i);
      }
    }
  }


  // --------------------------------------------------
  // TIMER
  // --------------------------------------------------

  void updateTimer() {

    long now =
      System.currentTimeMillis();

    if (now-lastTimerTime >= 1000) {

      long n =
        (now-lastTimerTime)/1000;

      timerSeconds -= n;

      if (timerSeconds < 0)
        timerSeconds = 0;

      lastTimerTime = now;

      invalidate();
    }
  }


  String formatTime(long s) {

    long m = s / 60;
    long sec = s % 60;

    String a = "" + m;
    String b = "" + sec;

    if (sec < 10)
      b = "0" + sec;

    return a + ":" + b;
  }


  // --------------------------------------------------
  // SHOW PANEL
  // --------------------------------------------------

  void showPanel() {
    panel = true;
    invalidate();
  }


  // --------------------------------------------------
  // BACK TO CHESS
  // --------------------------------------------------

  void backToChess() {

    /*
      ВСТАВ СЮДИ package name твоєї шахової програми.

      Наприклад:
      com.example.chess
    */

    String chessPackage =
      "com.example.chess";

    try {

      Intent i =
        act.getPackageManager()
        .getLaunchIntentForPackage(
          chessPackage
        );

      if (i != null) {

        i.addFlags(
          Intent.FLAG_ACTIVITY_NEW_TASK
        );

        act.startActivity(i);

      } else {

        Toast.makeText(
          act,
          "Chess app package not found",
          Toast.LENGTH_SHORT
        ).show();
      }

    }
    catch(Exception ex) {

      Toast.makeText(
        act,
        "Cannot open chess",
        Toast.LENGTH_SHORT
      ).show();
    }
  }
}


// ----------------------------------------------------
// LINE
// ----------------------------------------------------

class Line {

  float x1;
  float y1;
  float x2;
  float y2;

  int color;
  float w;

  Line(
    float a,
    float b,
    float c,
    float d,
    int col,
    float width
  ) {

    x1 = a;
    y1 = b;
    x2 = c;
    y2 = d;

    color = col;
    w = width;
  }
}


// ----------------------------------------------------
// ANDROID ACTIVITY
// ----------------------------------------------------

@Override
public void onResume() {

  super.onResume();

  if (overlay == null) {

    if (Build.VERSION.SDK_INT < 23 ||
        Settings.canDrawOverlays(act)) {

      createOverlay();
    }
  }
}


@Override
public void onPause() {

  super.onPause();

  // overlay НЕ прибираємо.
  // Він може залишатися поверх іншої програми.
}


@Override
public void onDestroy() {

  try {

    if (wm != null &&
        overlay != null) {

      wm.removeView(overlay);
      overlay = null;
    }

  }
  catch(Exception e) {
  }

  super.onDestroy();
}















