
// Налаштування сітки гри
int cols = 10;
int rows = 20;
int blockSize;
int[][] grid = new int[rows][cols];

// Налаштування таймінгу
int lastTime = 0;
int dropInterval = 800; // Швидкість за замовчуванням (у мс)

// Поточна фігура
int[][] currentPiece;
int pieceX, pieceY;
int currentType;

// Рахунок та стан гри
int score = 0;
boolean gameOver = false;

// Визначення 7 фігур
int[][][] shapes = {
  {{0,0,0,0}, {1,1,1,1}, {0,0,0,0}, {0,0,0,0}}, // I
  {{0,0,0,0}, {1,1,1,0}, {0,1,0,0}, {0,0,0,0}}, // T
  {{0,0,0,0}, {1,1,1,0}, {1,0,0,0}, {0,0,0,0}}, // L
  {{0,0,0,0}, {1,1,1,0}, {0,0,1,0}, {0,0,0,0}}, // J
  {{0,0,0,0}, {0,1,1,0}, {0,1,1,0}, {0,0,0,0}}, // O
  {{0,0,0,0}, {0,1,1,0}, {1,1,0,0}, {0,0,0,0}}, // S
  {{0,0,0,0}, {1,1,0,0}, {0,1,1,0}, {0,0,0,0}}  // Z
};

color[] colors = {
  #00FFFF, #800080, #FFA500, #0000FF, #FFFF00, #00FF00, #FF0000
};

void setup() {
  // Автоматично адаптуємо розмір під екран Android
  fullScreen();
  orientation(PORTRAIT);
  
  // Вираховуємо розмір блоку під ширину екрана
  blockSize = width / cols;
  
  spawnPiece();
}

void draw() {
  background(30);
  
  // Обробка переміщення фігури по горизонталі за рухом пальця/миші (mouseX)
  if (!gameOver) {
    int targetX = int(mouseX / blockSize) - 1;
    targetX = constrain(targetX, 0, cols - 4);
    
    // Плавне зміщення фігури до координати X миші
    if (targetX > pieceX && canMove(pieceX + 1, pieceY, currentPiece)) {
      pieceX++;
    } else if (targetX < pieceX && canMove(pieceX - 1, pieceY, currentPiece)) {
      pieceX--;
    }

    // Автоматичне падіння вниз
    if (millis() - lastTime > dropInterval) {
      if (canMove(pieceX, pieceY + 1, currentPiece)) {
        pieceY++;
      } else {
        lockPiece();
        clearLines();
        spawnPiece();
      }
      lastTime = millis();
    }
  }

  drawGrid();
  drawPiece();
  drawUI();
}

// Рендеринг зафіксованої сітки
void drawGrid() {
  for (int r = 0; r < rows; r++) {
    for (int c = 0; c < cols; c++) {
      if (grid[r][c] > 0) {
        fill(colors[grid[r][c] - 1]);
        stroke(0);
        rect(c * blockSize, r * blockSize, blockSize, blockSize);
      } else {
        stroke(45);
        noFill();
        rect(c * blockSize, r * blockSize, blockSize, blockSize);
      }
    }
  }
}

// Малювання фігури
void drawPiece() {
  fill(colors[currentType]);
  stroke(0);
  for (int r = 0; r < 4; r++) {
    for (int c = 0; c < 4; c++) {
      if (currentPiece[r][c] == 1) {
        int x = (pieceX + c) * blockSize;
        int y = (pieceY + r) * blockSize;
        if (y >= 0) {
          rect(x, y, blockSize, blockSize);
        }
      }
    }
  }
}

// Рахунок та керування (інфозона внизу)
void drawUI() {
  int uiY = rows * blockSize;
  fill(20);
  rect(0, uiY, width, height - uiY);
  
  fill(255);
  textSize(width * 0.05); // Адаптивний шрифт
  textAlign(CENTER, CENTER);
  text("Score: " + score, width / 2, uiY + (height - uiY) / 2);
  
  if (gameOver) {
    fill(255, 50, 50);
    textSize(width * 0.1);
    text("GAME OVER\nTap to Restart", width / 2, height / 2);
  }
}

// Логіка кліків на Android (mouseReleased / Touch)
void mouseReleased() {
  if (gameOver) {
    resetGame();
    return;
  }
  
  // Якщо клікнули у ВЕРХНІЙ половині екрана — ПОВОРОТ фігури
  if (mouseY < (rows * blockSize) / 2) {
    int[][] rotated = rotatePiece(currentPiece);
    if (canMove(pieceX, pieceY, rotated)) {
      currentPiece = rotated;
    }
  } 
  // Якщо клікнули у НИЖНІЙ половині поля — падіння в самий низ (DROP)
  else if (mouseY < rows * blockSize) {
    while (canMove(pieceX, pieceY + 1, currentPiece)) {
      pieceY++;
    }
    lockPiece();
    clearLines();
    spawnPiece();
  }
}

void spawnPiece() {
  currentType = int(random(7));
  currentPiece = new int[4][4];
  for (int r = 0; r < 4; r++) {
    for (int c = 0; c < 4; c++) {
      currentPiece[r][c] = shapes[currentType][r][c];
    }
  }
  pieceX = cols / 2 - 2;
  pieceY = -1;

  if (!canMove(pieceX, pieceY, currentPiece)) {
    gameOver = true;
  }
}

boolean canMove(int nextX, int nextY, int[][] piece) {
  for (int r = 0; r < 4; r++) {
    for (int c = 0; c < 4; c++) {
      if (piece[r][c] == 1) {
        int gx = nextX + c;
        int gy = nextY + r;
        
        if (gx < 0 || gx >= cols || gy >= rows) return false;
        if (gy >= 0 && grid[gy][gx] > 0) return false;
      }
    }
  }
  return true;
}

void lockPiece() {
  for (int r = 0; r < 4; r++) {
    for (int c = 0; c < 4; c++) {
      if (currentPiece[r][c] == 1) {
        int gy = pieceY + r;
        int gx = pieceX + c;
        if (gy >= 0) {
          grid[gy][gx] = currentType + 1;
        }
      }
    }
  }
}

void clearLines() {
  for (int r = rows - 1; r >= 0; r--) {
    boolean full = true;
    for (int c = 0; c < cols; c++) {
      if (grid[r][c] == 0) {
        full = false;
        break;
      }
    }
    if (full) {
      score += 100;
      for (int moveR = r; moveR > 0; moveR--) {
        grid[moveR] = grid[moveR - 1].clone();
      }
      grid[0] = new int[cols];
      r++;
    }
  }
}

int[][] rotatePiece(int[][] piece) {
  int[][] rotated = new int[4][4];
  for (int r = 0; r < 4; r++) {
    for (int c = 0; c < 4; c++) {
      rotated[c][3 - r] = piece[r][c];
    }
  }
  return rotated;
}

void resetGame() {
  grid = new int[rows][cols];
  score = 0;
  gameOver = false;
  spawnPiece();
}


/*






// Налаштування сітки гри
int cols = 10;
int rows = 20;
int blockSize;
int[][] grid = new int[rows][cols];

// Налаштування таймінгу
int lastTime = 0;
int dropInterval = 800; // Швидкість за замовчуванням (�� мс)

// Поточна фігура
int[][] currentPiece;
int pieceX, pieceY;
int currentType;

// Рахунок та стан гри
int score = 0;
boolean gameOver = false;

// Визначення 7 фігур
int[][][] shapes = {
  {{0,0,0,0}, {1,1,1,1}, {0,0,0,0}, {0,0,0,0}}, // I
  {{0,0,0,0}, {1,1,1,0}, {0,1,0,0}, {0,0,0,0}}, // T
  {{0,0,0,0}, {1,1,1,0}, {1,0,0,0}, {0,0,0,0}}, // L
  {{0,0,0,0}, {1,1,1,0}, {0,0,1,0}, {0,0,0,0}}, // J
  {{0,0,0,0}, {0,1,1,0}, {0,1,1,0}, {0,0,0,0}}, // O
  {{0,0,0,0}, {0,1,1,0}, {1,1,0,0}, {0,0,0,0}}, // S
  {{0,0,0,0}, {1,1,0,0}, {0,1,1,0}, {0,0,0,0}}  // Z
};

color[] colors = {
  #00FFFF, #800080, #FFA500, #0000FF, #FFFF00, #00FF00, #FF0000
};

void setup() {
  // Автоматично адаптуємо розмір під екран Android
  fullScreen();
  orientation(PORTRAIT);
  
  // Вираховуємо розмір блоку під ширину екрана
  blockSize = width / cols;
  
  spawnPiece();
}

void draw() {
  background(30);
  
  // О��робка переміщення фігури по горизонталі за рухом пальця/миші (mouseX)
  if (!gameOver) {
    int targetX = int(mouseX / blockSize) - 1;
    targetX = constrain(targetX, 0, cols - 4);
    
    // Плавне зміщення фігури до координати X миші
    if (targetX > pieceX && canMove(pieceX + 1, pieceY, currentPiece)) {
      pieceX++;
    } else if (targetX < pieceX && canMove(pieceX - 1, pieceY, currentPiece)) {
      pieceX--;
    }

    // Автоматичне падіння вниз
    if (millis() - lastTime > dropInterval) {
      if (canMove(pieceX, pieceY + 1, currentPiece)) {
        pieceY++;
      } else {
        lockPiece();
        clearLines();
        spawnPiece();
      }
      lastTime = millis();
    }
  }

  drawGrid();
  drawPiece();
  drawUI();
}

// Рендеринг зафіксованої сітки
void drawGrid() {
  for (int r = 0; r < rows; r++) {
    for (int c = 0; c < cols; c++) {
      if (grid[r][c] > 0) {
        fill(colors[grid[r][c] - 1]);
        stroke(0);
        rect(c * blockSize, r * blockSize, blockSize, blockSize);
      } else {
        stroke(45);
        noFill();
        rect(c * blockSize, r * blockSize, blockSize, blockSize);
      }
    }
  }
}

// Малювання фігури
void drawPiece() {
  fill(colors[currentType]);
  stroke(0);
  for (int r = 0; r < 4; r++) {
    for (int c = 0; c < 4; c++) {
      if (currentPiece[r][c] == 1) {
        int x = (pieceX + c) * blockSize;
        int y = (pieceY + r) * blockSize;
        if (y >= 0) {
          rect(x, y, blockSize, blockSize);
        }
      }
    }
  }
}

// Рахунок та керування (інфозона внизу)
void drawUI() {
  int uiY = rows * blockSize;
  fill(20);
  rect(0, uiY, width, height - uiY);
  
  fill(255);
  textSize(width * 0.05); // Адаптивний шрифт
  textAlign(CENTER, CENTER);
  text("Score: " + score, width / 2, uiY + (height - uiY) / 2);
  
  if (gameOver) {
    fill(255, 50, 50);
    textSize(width * 0.1);
    text("GAME OVER\nTap to Restart", width / 2, height / 2);
  }
}

// Логіка кліків на Android (mouseReleased / Touch)
void mouseReleased() {
  if (gameOver) {
    resetGame();
    return;
  }
  
  // Якщо клікнули у ВЕРХНІЙ половині екрана — ПОВОРОТ фігури
  if (mouseY < (rows * blockSize) / 2) {
    int[][] rotated = rotatePiece(currentPiece);
    if (canMove(pieceX, pieceY, rotated)) {
      currentPiece = rotated;
    }
  } 
  // Якщо клікнули у НИЖНІЙ половині поля — падіння в самий низ (DROP)
  else if (mouseY < rows * blockSize) {
    while (canMove(pieceX, pieceY + 1, currentPiece)) {
      pieceY++;
    }
    lockPiece();
    clearLines();
    spawnPiece();
  }
}

void spawnPiece() {
  currentType = int(random(7));
  currentPiece = new int[4][4];
  for (int r = 0; r < 4; r++) {
    for (int c = 0; c < 4; c++) {
      currentPiece[r][c] = shapes[currentType][r][c];
    }
  }
  pieceX = cols / 2 - 2;
  pieceY = -1;

  if (!canMove(pieceX, pieceY, currentPiece)) {
    gameOver = true;
  }
}

boolean canMove(int nextX, int nextY, int[][] piece) {
  for (int r = 0; r < 4; r++) {
    for (int c = 0; c < 4; c++) {
      if (piece[r][c] == 1) {
        int gx = nextX + c;
        int gy = nextY + r;
        
        if (gx < 0 || gx >= cols || gy >= rows) return false;
        if (gy >= 0 && grid[gy][gx] > 0) return false;
      }
    }
  }
  return true;
}

void lockPiece() {
  for (int r = 0; r < 4; r++) {
    for (int c = 0; c < 4; c++) {
      if (currentPiece[r][c] == 1) {
        int gy = pieceY + r;
        int gx = pieceX + c;
        if (gy >= 0) {
          grid[gy][gx] = currentType + 1;
        }
      }
    }
  }
}

void clearLines() {
  for (int r = rows - 1; r >= 0; r--) {
    boolean full = true;
    for (int c = 0; c < cols; c++) {
      if (grid[r][c] == 0) {
        full = false;
        break;
      }
    }
    if (full) {
      score += 100;
      for (int moveR = r; moveR > 0; moveR--) {
        grid[moveR] = grid[moveR - 1].clone();
      }
      grid[0] = new int[cols];
      r++;
    }
  }
}

int[][] rotatePiece(int[][] piece) {
  int[][] rotated = new int[4][4];
  for (int r = 0; r < 4; r++) {
    for (int c = 0; c < 4; c++) {
      rotated[c][3 - r] = piece[r][c];
    }
  }
  return rotated;
}

void resetGame() {
  grid = new int[rows][cols];
  score = 0;
  gameOver = false;
  spawnPiece();
}






// Налаштування сітки гри
int cols = 10;
int rows = 20;
int blockSize;
int[][] grid = new int[rows][cols];

// Налаштування таймінгу
int lastTime = 0;
int dropInterval = 800; // Швидкість за замовчуванням (у мс)

// Поточна фігура
int[][] currentPiece;
int pieceX, pieceY;
int currentType;

// Рахунок та стан гри
int score = 0;
boolean gameOver = false;

// Визначення 7 фігур
int[][][] shapes = {
  {{0,0,0,0}, {1,1,1,1}, {0,0,0,0}, {0,0,0,0}}, // I
  {{0,0,0,0}, {1,1,1,0}, {0,1,0,0}, {0,0,0,0}}, // T
  {{0,0,0,0}, {1,1,1,0}, {1,0,0,0}, {0,0,0,0}}, // L
  {{0,0,0,0}, {1,1,1,0}, {0,0,1,0}, {0,0,0,0}}, // J
  {{0,0,0,0}, {0,1,1,0}, {0,1,1,0}, {0,0,0,0}}, // O
  {{0,0,0,0}, {0,1,1,0}, {1,1,0,0}, {0,0,0,0}}, // S
  {{0,0,0,0}, {1,1,0,0}, {0,1,1,0}, {0,0,0,0}}  // Z
};

color[] colors = {
  #00FFFF, #800080, #FFA500, #0000FF, #FFFF00, #00FF00, #FF0000
};

void setup() {
  // Автоматично адаптуємо розмір під екран Android
  fullScreen();
  orientation(PORTRAIT);
  
  // Вираховуємо розмір блоку під ширину екрана
  blockSize = width / cols;
  
  spawnPiece();
}

void draw() {
  background(30);
  
  // Обробка переміщення фігури по горизонталі за рухом пальця/миші (mouseX)
  if (!gameOver) {
    int targetX = int(mouseX / blockSize) - 1;
    targetX = constrain(targetX, 0, cols - 4);
    
    // Плавне зміщення фігури до координати X миші
    if (targetX > pieceX && canMove(pieceX + 1, pieceY, currentPiece)) {
      pieceX++;
    } else if (targetX < pieceX && canMove(pieceX - 1, pieceY, currentPiece)) {
      pieceX--;
    }

    // Автоматичне падіння вниз
    if (millis() - lastTime > dropInterval) {
      if (canMove(pieceX, pieceY + 1, currentPiece)) {
        pieceY++;
      } else {
        lockPiece();
        clearLines();
        spawnPiece();
      }
      lastTime = millis();
    }
  }

  drawGrid();
  drawPiece();
  drawUI();
}

// Рендеринг зафіксованої сітки
void drawGrid() {
  for (int r = 0; r < rows; r++) {
    for (int c = 0; c < cols; c++) {
      if (grid[r][c] > 0) {
        fill(colors[grid[r][c] - 1]);
        stroke(0);
        rect(c * blockSize, r * blockSize, blockSize, blockSize);
      } else {
        stroke(45);
        noFill();
        rect(c * blockSize, r * blockSize, blockSize, blockSize);
      }
    }
  }
}

// Малювання фігури
void drawPiece() {
  fill(colors[currentType]);
  stroke(0);
  for (int r = 0; r < 4; r++) {
    for (int c = 0; c < 4; c++) {
      if (currentPiece[r][c] == 1) {
        int x = (pieceX + c) * blockSize;
        int y = (pieceY + r) * blockSize;
        if (y >= 0) {
          rect(x, y, blockSize, blockSize);
        }
      }
    }
  }
}

// Рахунок та керування (інфозона внизу)
void drawUI() {
  int uiY = rows * blockSize;
  fill(20);
  rect(0, uiY, width, height - uiY);
  
  fill(255);
  textSize(width * 0.05); // Адаптивний шрифт
  textAlign(CENTER, CENTER);
  text("Score: " + score, width / 2, uiY + (height - uiY) / 2);
  
  if (gameOver) {
    fill(255, 50, 50);
    textSize(width * 0.1);
    text("GAME OVER\nTap to Restart", width / 2, height / 2);
  }
}

// Логіка кліків на Android (mouseReleased / Touch)
void mouseReleased() {
  if (gameOver) {
    resetGame();
    return;
  }
  
  // Якщо клік��ули у ВЕРХНІЙ половині екрана — ПОВОРОТ фігури
  if (mouseY < (rows * blockSize) / 2) {
    int[][] rotated = rotatePiece(currentPiece);
    if (canMove(pieceX, pieceY, rotated)) {
      currentPiece = rotated;
    }
  } 
  // Якщо клікнули у НИЖНІЙ половині поля — падіння в самий низ (DROP)
  else if (mouseY < rows * blockSize) {
    while (canMove(pieceX, pieceY + 1, currentPiece)) {
      pieceY++;
    }
    lockPiece();
    clearLines();
    spawnPiece();
  }
}

void spawnPiece() {
  currentType = int(random(7));
  currentPiece = new int[4][4];
  for (int r = 0; r < 4; r++) {
    for (int c = 0; c < 4; c++) {
      currentPiece[r][c] = shapes[currentType][r][c];
    }
  }
  pieceX = cols / 2 - 2;
  pieceY = -1;

  if (!canMove(pieceX, pieceY, currentPiece)) {
    gameOver = true;
  }
}

boolean canMove(int nextX, int nextY, int[][] piece) {
  for (int r = 0; r < 4; r++) {
    for (int c = 0; c < 4; c++) {
      if (piece[r][c] == 1) {
        int gx = nextX + c;
        int gy = nextY + r;
        
        if (gx < 0 || gx >= cols || gy >= rows) return false;
        if (gy >= 0 && grid[gy][gx] > 0) return false;
      }
    }
  }
  return true;
}

void lockPiece() {
  for (int r = 0; r < 4; r++) {
    for (int c = 0; c < 4; c++) {
      if (currentPiece[r][c] == 1) {
        int gy = pieceY + r;
        int gx = pieceX + c;
        if (gy >= 0) {
          grid[gy][gx] = currentType + 1;
        }
      }
    }
  }
}

void clearLines() {
  for (int r = rows - 1; r >= 0; r--) {
    boolean full = true;
    for (int c = 0; c < cols; c++) {
      if (grid[r][c] == 0) {
        full = false;
        break;
      }
    }
    if (full) {
      score += 100;
      for (int moveR = r; moveR > 0; moveR--) {
        grid[moveR] = grid[moveR - 1].clone();
      }
      grid[0] = new int[cols];
      r++;
    }
  }
}

int[][] rotatePiece(int[][] piece) {
  int[][] rotated = new int[4][4];
  for (int r = 0; r < 4; r++) {
    for (int c = 0; c < 4; c++) {
      rotated[c][3 - r] = piece[r][c];
    }
  }
  return rotated;
}

void resetGame() {
  grid = new int[rows][cols];
  score = 0;
  gameOver = false;
  spawnPiece();
}







// Налаштування сітки гри
int cols = 10;
int rows = 20;
int blockSize;
int[][] grid = new int[rows][cols];

// Налаштування таймінгу
int lastTime = 0;
int dropInterval = 800; // Швидкість за замовчуванням (у мс)

// Поточна фігура
int[][] currentPiece;
int pieceX, pieceY;
int currentType;

// Рахунок та стан гри
int score = 0;
boolean gameOver = false;

// Визначення 7 фігур
int[][][] shapes = {
  {{0,0,0,0}, {1,1,1,1}, {0,0,0,0}, {0,0,0,0}}, // I
  {{0,0,0,0}, {1,1,1,0}, {0,1,0,0}, {0,0,0,0}}, // T
  {{0,0,0,0}, {1,1,1,0}, {1,0,0,0}, {0,0,0,0}}, // L
  {{0,0,0,0}, {1,1,1,0}, {0,0,1,0}, {0,0,0,0}}, // J
  {{0,0,0,0}, {0,1,1,0}, {0,1,1,0}, {0,0,0,0}}, // O
  {{0,0,0,0}, {0,1,1,0}, {1,1,0,0}, {0,0,0,0}}, // S
  {{0,0,0,0}, {1,1,0,0}, {0,1,1,0}, {0,0,0,0}}  // Z
};

color[] colors = {
  #00FFFF, #800080, #FFA500, #0000FF, #FFFF00, #00FF00, #FF0000
};

void setup() {
  // Автоматично адаптуємо розмір під екран Android
  fullScreen();
  orientation(PORTRAIT);
  
  // Вираховуємо розмір блоку під ширину екрана
  blockSize = width / cols;
  
  spawnPiece();
}

void draw() {
  background(30);
  
  // Обробка переміщення фігури по горизонталі за рухом пальця/миші (mouseX)
  if (!gameOver) {
    int targetX = int(mouseX / blockSize) - 1;
    targetX = constrain(targetX, 0, cols - 4);
    
    // Плавне зміщення фігури до координати X миші
    if (targetX > pieceX && canMove(pieceX + 1, pieceY, currentPiece)) {
      pieceX++;
    } else if (targetX < pieceX && canMove(pieceX - 1, pieceY, currentPiece)) {
      pieceX--;
    }

    // Автоматичне п��діння вниз
    if (millis() - lastTime > dropInterval) {
      if (canMove(pieceX, pieceY + 1, currentPiece)) {
        pieceY++;
      } else {
        lockPiece();
        clearLines();
        spawnPiece();
      }
      lastTime = millis();
    }
  }

  drawGrid();
  drawPiece();
  drawUI();
}

// Рендеринг зафіксованої сітки
void drawGrid() {
  for (int r = 0; r < rows; r++) {
    for (int c = 0; c < cols; c++) {
      if (grid[r][c] > 0) {
        fill(colors[grid[r][c] - 1]);
        stroke(0);
        rect(c * blockSize, r * blockSize, blockSize, blockSize);
      } else {
        stroke(45);
        noFill();
        rect(c * blockSize, r * blockSize, blockSize, blockSize);
      }
    }
  }
}

// Малювання фігури
void drawPiece() {
  fill(colors[currentType]);
  stroke(0);
  for (int r = 0; r < 4; r++) {
    for (int c = 0; c < 4; c++) {
      if (currentPiece[r][c] == 1) {
        int x = (pieceX + c) * blockSize;
        int y = (pieceY + r) * blockSize;
        if (y >= 0) {
          rect(x, y, blockSize, blockSize);
        }
      }
    }
  }
}

// Рахунок та керування (інфозона внизу)
void drawUI() {
  int uiY = rows * blockSize;
  fill(20);
  rect(0, uiY, width, height - uiY);
  
  fill(255);
  textSize(width * 0.05); // Адаптивний шрифт
  textAlign(CENTER, CENTER);
  text("Score: " + score, width / 2, uiY + (height - uiY) / 2);
  
  if (gameOver) {
    fill(255, 50, 50);
    textSize(width * 0.1);
    text("GAME OVER\nTap to Restart", width / 2, height / 2);
  }
}

// Логіка кліків на Android (mouseReleased / Touch)
void mouseReleased() {
  if (gameOver) {
    resetGame();
    return;
  }
  
  // Якщо клікнули у ВЕРХНІЙ половині екрана — ПОВОРОТ фігури
  if (mouseY < (rows * blockSize) / 2) {
    int[][] rotated = rotatePiece(currentPiece);
    if (canMove(pieceX, pieceY, rotated)) {
      currentPiece = rotated;
    }
  } 
  // Якщо клікнули у НИЖНІЙ половині поля — падіння в самий низ (DROP)
  else if (mouseY < rows * blockSize) {
    while (canMove(pieceX, pieceY + 1, currentPiece)) {
      pieceY++;
    }
    lockPiece();
    clearLines();
    spawnPiece();
  }
}

void spawnPiece() {
  currentType = int(random(7));
  currentPiece = new int[4][4];
  for (int r = 0; r < 4; r++) {
    for (int c = 0; c < 4; c++) {
      currentPiece[r][c] = shapes[currentType][r][c];
    }
  }
  pieceX = cols / 2 - 2;
  pieceY = -1;

  if (!canMove(pieceX, pieceY, currentPiece)) {
    gameOver = true;
  }
}

boolean canMove(int nextX, int nextY, int[][] piece) {
  for (int r = 0; r < 4; r++) {
    for (int c = 0; c < 4; c++) {
      if (piece[r][c] == 1) {
        int gx = nextX + c;
        int gy = nextY + r;
        
        if (gx < 0 || gx >= cols || gy >= rows) return false;
        if (gy >= 0 && grid[gy][gx] > 0) return false;
      }
    }
  }
  return true;
}

void lockPiece() {
  for (int r = 0; r < 4; r++) {
    for (int c = 0; c < 4; c++) {
      if (currentPiece[r][c] == 1) {
        int gy = pieceY + r;
        int gx = pieceX + c;
        if (gy >= 0) {
          grid[gy][gx] = currentType + 1;
        }
      }
    }
  }
}

void clearLines() {
  for (int r = rows - 1; r >= 0; r--) {
    boolean full = true;
    for (int c = 0; c < cols; c++) {
      if (grid[r][c] == 0) {
        full = false;
        break;
      }
    }
    if (full) {
      score += 100;
      for (int moveR = r; moveR > 0; moveR--) {
        grid[moveR] = grid[moveR - 1].clone();
      }
      grid[0] = new int[cols];
      r++;
    }
  }
}

int[][] rotatePiece(int[][] piece) {
  int[][] rotated = new int[4][4];
  for (int r = 0; r < 4; r++) {
    for (int c = 0; c < 4; c++) {
      rotated[c][3 - r] = piece[r][c];
    }
  }
  return rotated;
}

void resetGame() {
  grid = new int[rows][cols];
  score = 0;
  gameOver = false;
  spawnPiece();
}





*/





























































