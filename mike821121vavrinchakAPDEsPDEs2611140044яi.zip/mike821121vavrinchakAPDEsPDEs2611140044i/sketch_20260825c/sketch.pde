


// ============================================================
// FRUIT ENGINE
// ============================================================

// POSITION
int[] board = new int[64];

boolean sideWhite = true;

long nodes;
int engineDepth = 3;

// SEARCH
int search(int depth, int alpha, int beta) {

  nodes++;

  if (depth == 0)
    return evaluate();

  ArrayList<Move> moves =
    generateLegalMoves(sideWhite);

  if (moves.size() == 0)
    return evaluate();

  int best;

  if (sideWhite)
    best = -1000000;
  else
    best = 1000000;

  for (int i = 0; i < moves.size(); i++) {

    Move m = moves.get(i);

    State s = makeMove(m);

    sideWhite = !sideWhite;

    int score =
      search(depth-1, alpha, beta);

    sideWhite = !sideWhite;

    undoMove(m, s);

    if (sideWhite) {

      if (score > best)
        best = score;

      if (score > alpha)
        alpha = score;

    } else {

      if (score < best)
        best = score;

      if (score < beta)
        beta = score;
    }

    if (alpha >= beta)
      break;
  }

  return best;
}


// ============================================================
// ENGINE THINK
// ============================================================

Move engineThink() {

  nodes = 0;

  ArrayList<Move> moves =
    generateLegalMoves(sideWhite);

  Move bestMove = null;

  int bestScore;

  if (sideWhite)
    bestScore = -1000000;
  else
    bestScore = 1000000;

  for (int i = 0; i < moves.size(); i++) {

    Move m = moves.get(i);

    State s = makeMove(m);

    sideWhite = !sideWhite;

    int score =
      search(
        engineDepth-1,
        -1000000,
        1000000
      );

    sideWhite = !sideWhite;

    undoMove(m, s);

    if (sideWhite) {

      if (score > bestScore) {
        bestScore = score;
        bestMove = m;
      }

    } else {

      if (score < bestScore) {
        bestScore = score;
        bestMove = m;
      }
    }
  }

  println(
    "ENGINE THINK: " +
    nodes +
    " nodes  score=" +
    bestScore
  );

  return bestMove;
}








/*
// ============================================================
// FRUIT ENGINE
// ============================================================

// POSITION
int[] board = new int[64];

boolean sideWhite = true;

long nodes;
int engineDepth = 3;

// SEARCH
int search(int depth, int alpha, int beta) {

  nodes++;

  if (depth == 0)
    return evaluate();

  ArrayList<Move> moves =
    generateLegalMoves(sideWhite);

  if (moves.size() == 0)
    return evaluate();

  int best;

  if (sideWhite)
    best = -1000000;
  else
    best = 1000000;

  for (int i = 0; i < moves.size(); i++) {

    Move m = moves.get(i);

    State s = makeMove(m);

    sideWhite = !sideWhite;

    int score =
      search(depth-1, alpha, beta);

    sideWhite = !sideWhite;

    undoMove(m, s);

    if (sideWhite) {

      if (score > best)
        best = score;

      if (score > alpha)
        alpha = score;

    } else {

      if (score < best)
        best = score;

      if (score < beta)
        beta = score;
    }

    if (alpha >= beta)
      break;
  }

  return best;
}


// ============================================================
// ENGINE THINK
// ============================================================

Move engineThink() {

  nodes = 0;

  ArrayList<Move> moves =
    generateLegalMoves(sideWhite);

  Move bestMove = null;

  int bestScore;

  if (sideWhite)
    bestScore = -1000000;
  else
    bestScore = 1000000;

  for (int i = 0; i < moves.size(); i++) {

    Move m = moves.get(i);

    State s = makeMove(m);

    sideWhite = !sideWhite;

    int score =
      search(
        engineDepth-1,
        -1000000,
        1000000
      );

    sideWhite = !sideWhite;

    undoMove(m, s);

    if (sideWhite) {

      if (score > bestScore) {
        bestScore = score;
        bestMove = m;
      }

    } else {

      if (score < bestScore) {
        bestScore = score;
        bestMove = m;
      }
    }
  }

  println(
    "ENGINE THINK: " +
    nodes +
    " nodes  score=" +
    bestScore
  );

  return bestMove;
}

*/

/*

// ============================================================
// FRUIT ENGINE
// ============================================================

// POSITION
int[] board = new int[64];

boolean sideWhite = true;

long nodes;
int engineDepth = 3;

// SEARCH
int search(int depth, int alpha, int beta) {

  nodes++;

  if (depth == 0)
    return evaluate();

  ArrayList<Move> moves =
    generateLegalMoves(sideWhite);

  if (moves.size() == 0)
    return evaluate();

  int best;

  if (sideWhite)
    best = -1000000;
  else
    best = 1000000;

  for (int i = 0; i < moves.size(); i++) {

    Move m = moves.get(i);

    State s = makeMove(m);

    sideWhite = !sideWhite;

    int score =
      search(depth-1, alpha, beta);

    sideWhite = !sideWhite;

    undoMove(m, s);

    if (sideWhite) {

      if (score > best)
        best = score;

      if (score > alpha)
        alpha = score;

    } else {

      if (score < best)
        best = score;

      if (score < beta)
        beta = score;
    }

    if (alpha >= beta)
      break;
  }

  return best;
}


// ============================================================
// ENGINE THINK
// ============================================================

Move engineThink() {

  nodes = 0;

  ArrayList<Move> moves =
    generateLegalMoves(sideWhite);

  Move bestMove = null;

  int bestScore;

  if (sideWhite)
    bestScore = -1000000;
  else
    bestScore = 1000000;

  for (int i = 0; i < moves.size(); i++) {

    Move m = moves.get(i);

    State s = makeMove(m);

    sideWhite = !sideWhite;

    int score =
      search(
        engineDepth-1,
        -1000000,
        1000000
      );

    sideWhite = !sideWhite;

    undoMove(m, s);

    if (sideWhite) {

      if (score > bestScore) {
        bestScore = score;
        bestMove = m;
      }

    } else {

      if (score < bestScore) {
        bestScore = score;
        bestMove = m;
      }
    }
  }

  println(
    "ENGINE THINK: " +
    nodes +
    " nodes  score=" +
    bestScore
  );

  return bestMove;
}



*/



























