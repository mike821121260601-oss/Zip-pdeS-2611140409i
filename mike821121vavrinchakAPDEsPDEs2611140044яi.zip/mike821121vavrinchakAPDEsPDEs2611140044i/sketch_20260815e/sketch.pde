


// ============================================================
// APDE 3D RALLY
// Player + 2 AI thinking cars
// Landscape / road trace / trees / chase camera
// ============================================================

final int ROAD_POINTS = 180;
final int TREES = 260;

float[] rx = new float[ROAD_POINTS];
float[] rz = new float[ROAD_POINTS];

float playerX = 0;
float playerZ = 0;
float playerSpeed = 0;

float[] aiX = new float[2];
float[] aiZ = new float[2];
float[] aiSpeed = new float[2];
int[] aiRoad = new int[2];

float playerAngle = 0;

boolean left = false;
boolean right = false;
boolean gas = false;
boolean brake = false;

float cameraX;
float cameraY;
float cameraZ;

float roadWidth = 700;

float worldScale = 1.0;

void settings() {
  size(displayWidth, displayHeight, P3D);
}

void setup() {

 /// orientation(LANDSCAPE);

  frameRate(60);

  // ----------------------------------------------------------
  // CREATE RALLY ROAD TRACE
  // ----------------------------------------------------------

  for (int i = 0; i < ROAD_POINTS; i++) {

    float t = i * 0.075;

    rx[i] =
      sin(t * 0.65) * 1700 +
      sin(t * 1.7) * 600 +
      sin(t * 3.1) * 250;

    rz[i] = i * 850;
  }

  // ----------------------------------------------------------
  // AI CARS
  // ----------------------------------------------------------

  aiRoad[0] = 8;
  aiRoad[1] = 15;

  aiX[0] = rx[aiRoad[0]] - 180;
  aiZ[0] = rz[aiRoad[0]];

  aiX[1] = rx[aiRoad[1]] + 180;
  aiZ[1] = rz[aiRoad[1]];

  aiSpeed[0] = 8;
  aiSpeed[1] = 7;

  playerX = rx[2];
  playerZ = rz[2];

  noStroke();
}


// ============================================================
// DRAW
// ============================================================

void draw() {

  background(120, 190, 235);

  lights();

  updatePlayer();
  updateAI();

  cameraFollow();

  drawWorld();
}


// ============================================================
// PLAYER ENGINE
// ============================================================

void updatePlayer() {

  if (gas) {
    playerSpeed += 0.35;
  }

  if (brake) {
    playerSpeed -= 0.55;
  }

  playerSpeed *= 0.985;

  if (playerSpeed < 0) playerSpeed = 0;
  if (playerSpeed > 35) playerSpeed = 35;

  float steeringPower = 0.035 + playerSpeed * 0.001;

  if (left) {
    playerAngle -= steeringPower;
  }

  if (right) {
    playerAngle += steeringPower;
  }

  playerX += sin(playerAngle) * playerSpeed;
  playerZ += cos(playerAngle) * playerSpeed;

  // keep player near road
  float roadX = nearestRoadX(playerZ);

  playerX = lerp(playerX, roadX, 0.008);
}


// ============================================================
// AI THINKING ENGINE
// ============================================================

void updateAI() {

  for (int n = 0; n < 2; n++) {

    // Find road waypoint ahead
    int target = aiRoad[n] + 4;

    if (target >= ROAD_POINTS - 1) {
      target = ROAD_POINTS - 2;
    }

    float targetX = rx[target];
    float targetZ = rz[target];

    float dx = targetX - aiX[n];
    float dz = targetZ - aiZ[n];

    float distance = sqrt(dx * dx + dz * dz);

    // --------------------------------------------------------
    // THINKING:
    // if far from target -> turn toward road
    // if road is straight -> accelerate
    // if curve is strong -> slow down
    // --------------------------------------------------------

    float roadCurve = abs(
      rx[min(target + 2, ROAD_POINTS - 1)] -
      rx[target]
    );

    if (roadCurve > 500) {
      aiSpeed[n] -= 0.15;
    } else {
      aiSpeed[n] += 0.12;
    }

    aiSpeed[n] = constrain(aiSpeed[n], 5, 25);

    // movement direction
    float dir = atan2(dx, dz);

    // smooth steering
    float wantedX = targetX;

    aiX[n] = lerp(aiX[n], wantedX, 0.015);

    aiZ[n] += aiSpeed[n];

    // waypoint reached
    if (aiZ[n] > rz[target]) {
      aiRoad[n]++;

      if (aiRoad[n] >= ROAD_POINTS - 5) {
        aiRoad[n] = 5;
        aiX[n] = rx[5];
        aiZ[n] = rz[5];
      }
    }

    // --------------------------------------------------------
    // AVOID PLAYER / OTHER AI
    // --------------------------------------------------------

    if (dist(aiX[n], aiZ[n], playerX, playerZ) < 300) {

      if (aiX[n] < playerX)
        aiX[n] -= 1.5;
      else
        aiX[n] += 1.5;

      aiSpeed[n] *= 0.995;
    }

    int other = 1 - n;

    if (dist(aiX[n], aiZ[n], aiX[other], aiZ[other]) < 250) {

      if (aiX[n] < aiX[other])
        aiX[n] -= 1.0;
      else
        aiX[n] += 1.0;
    }
  }
}


// ============================================================
// CAMERA BEHIND PLAYER
// ============================================================

void cameraFollow() {

  float backDistance = 1100;
  float side = 0;

  cameraX =
    playerX -
    sin(playerAngle) * backDistance;

  cameraZ =
    playerZ -
    cos(playerAngle) * backDistance;

  cameraY = 520;

  float lookX =
    playerX +
    sin(playerAngle) * 1000;

  float lookZ =
    playerZ +
    cos(playerAngle) * 1000;

  camera(
    cameraX,
    cameraY,
    cameraZ,

    lookX,
    150,
    lookZ,

    0,
    -1,
    0
  );
}


// ============================================================
// WORLD
// ============================================================

void drawWorld() {

  // huge ground
  pushMatrix();

  translate(0, 5000, playerZ + 3000);

  rotateX(HALF_PI);

  fill(55, 125, 45);

  rectMode(CENTER);
  rect(0, 0, 15000, 20000);

  popMatrix();


  // ----------------------------------------------------------
  // ROAD
  // ----------------------------------------------------------

  drawRoad();


  // ----------------------------------------------------------
  // TREES
  // ----------------------------------------------------------

  drawTrees();


  // ----------------------------------------------------------
  // CARS
  // ----------------------------------------------------------

  drawPlayerCar();

  drawAICar(aiX[0], aiZ[0], 0);
  drawAICar(aiX[1], aiZ[1], 1);
}


// ============================================================
// ROAD
// ============================================================

void drawRoad() {

  for (int i = 0; i < ROAD_POINTS - 1; i++) {

    float x1 = rx[i];
    float z1 = rz[i];

    float x2 = rx[i + 1];
    float z2 = rz[i + 1];

    float dx = x2 - x1;
    float dz = z2 - z1;

    float len = sqrt(dx * dx + dz * dz);

    float angle = atan2(dx, dz);

    pushMatrix();

    translate((x1 + x2) / 2,
              470,
              (z1 + z2) / 2);

    rotateY(angle);

    fill(65, 65, 65);

    box(roadWidth, 35, len + 20);

    // road center line
    fill(230, 230, 180);

    for (int j = -2; j < 3; j++) {

      pushMatrix();

      translate(0, -22, j * 150);

      box(20, 5, 90);

      popMatrix();
    }

    popMatrix();
  }
}


// ============================================================
// TREES
// ============================================================

void drawTrees() {

  int start = max(0, nearestRoadIndex(playerZ) - 15);
  int end = min(ROAD_POINTS - 1,
                nearestRoadIndex(playerZ) + 55);

  for (int i = start; i < end; i++) {

    float sideDistance = 1000;

    float x = rx[i];

    float z = rz[i];

    // left tree
    drawTree(
      x - roadWidth / 2 - sideDistance,
      z
    );

    // right tree
    drawTree(
      x + roadWidth / 2 + sideDistance,
      z
    );
  }
}


// ============================================================
// TREE
// ============================================================

void drawTree(float x, float z) {

  pushMatrix();

  translate(x, 0, z);

  // trunk
  pushMatrix();

  translate(0, 280, 0);

  fill(105, 65, 30);

  box(90, 560, 90);

  popMatrix();


  // lower crown
  pushMatrix();

  translate(0, 0, 0);

  fill(25, 110, 35);

  sphere(330);

  popMatrix();


  // upper crown
  pushMatrix();

  translate(0, -300, 0);

  fill(35, 140, 45);

  sphere(250);

  popMatrix();

  popMatrix();
}


// ============================================================
// PLAYER CAR
// ============================================================

void drawPlayerCar() {

  pushMatrix();

  translate(playerX, 400, playerZ);

  rotateY(playerAngle);

  // body
  fill(220, 20, 20);

  box(330, 120, 600);


  // cabin
  pushMatrix();

  translate(0, -100, -30);

  fill(50, 80, 100);

  box(240, 120, 300);

  popMatrix();


  // front
  pushMatrix();

  translate(0, 0, 330);

  fill(180, 0, 0);

  box(300, 100, 80);

  popMatrix();


  // wheels
  drawWheel(-180, 80, -200);
  drawWheel(180, 80, -200);
  drawWheel(-180, 80, 200);
  drawWheel(180, 80, 200);

  popMatrix();
}


// ============================================================
// AI CAR
// ============================================================

void drawAICar(float x, float z, int n) {

  pushMatrix();

  translate(x, 400, z);

  // AI cars point approximately forward
  rotateY(0);

  if (n == 0)
    fill(30, 60, 220);
  else
    fill(245, 190, 20);

  box(330, 120, 600);


  // cabin
  pushMatrix();

  translate(0, -100, -30);

  fill(60, 80, 100);

  box(240, 120, 300);

  popMatrix();


  drawWheel(-180, 80, -200);
  drawWheel(180, 80, -200);
  drawWheel(-180, 80, 200);
  drawWheel(180, 80, 200);

  popMatrix();
}


// ============================================================
// WHEEL
// ============================================================

void drawWheel(float x, float y, float z) {

  pushMatrix();

  translate(x, y, z);

  rotateZ(HALF_PI);

  fill(20);

  cylinder(75, 70);

  popMatrix();
}


// ============================================================
// CYLINDER
// ============================================================

void cylinder(float r, float h) {

  int sides = 16;

  beginShape(QUAD_STRIP);

  for (int i = 0; i <= sides; i++) {

    float a = TWO_PI * i / sides;

    vertex(
      cos(a) * r,
      -h / 2,
      sin(a) * r
    );

    vertex(
      cos(a) * r,
      h / 2,
      sin(a) * r
    );
  }

  endShape();

  // top
  beginShape(TRIANGLE_FAN);

  vertex(0, -h / 2, 0);

  for (int i = 0; i <= sides; i++) {

    float a = TWO_PI * i / sides;

    vertex(
      cos(a) * r,
      -h / 2,
      sin(a) * r
    );
  }

  endShape();


  // bottom
  beginShape(TRIANGLE_FAN);

  vertex(0, h / 2, 0);

  for (int i = 0; i <= sides; i++) {

    float a = TWO_PI * i / sides;

    vertex(
      cos(a) * r,
      h / 2,
      sin(a) * r
    );
  }

  endShape();
}


// ============================================================
// ROAD SEARCH
// ============================================================

int nearestRoadIndex(float z) {

  int best = 0;

  float bestDistance = abs(rz[0] - z);

  for (int i = 1; i < ROAD_POINTS; i++) {

    float d = abs(rz[i] - z);

    if (d < bestDistance) {

      bestDistance = d;
      best = i;
    }
  }

  return best;
}


float nearestRoadX(float z) {

  int i = nearestRoadIndex(z);

  return rx[i];
}


// ============================================================
// TOUCH / KEYBOARD
// ============================================================

void keyPressed() {

  if (keyCode == LEFT)
    left = true;

  if (keyCode == RIGHT)
    right = true;

  if (keyCode == UP)
    gas = true;

  if (keyCode == DOWN)
    brake = true;
}


void keyReleased() {

  if (keyCode == LEFT)
    left = false;

  if (keyCode == RIGHT)
    right = false;

  if (keyCode == UP)
    gas = false;

  if (keyCode == DOWN)
    brake = false;
}


// ============================================================
// SIMPLE TOUCH CONTROLS
// ============================================================

void mousePressed() {

  if (mouseX < width * 0.30) {
    left = true;
  }

  else if (mouseX > width * 0.70) {
    right = true;
  }

  else {
    gas = true;
  }
}


void mouseReleased() {

  left = false;
  right = false;
  gas = false;
}


// ============================================================
// LIGHTS
// ============================================================

void lights() {

  ambientLight(90, 90, 90);

  directionalLight(
    255, 255, 255,
    -0.4, -1, -0.3
  );

  pointLight(
    255, 255, 255,
    playerX,
    100,
    playerZ + 500
  );
}

































