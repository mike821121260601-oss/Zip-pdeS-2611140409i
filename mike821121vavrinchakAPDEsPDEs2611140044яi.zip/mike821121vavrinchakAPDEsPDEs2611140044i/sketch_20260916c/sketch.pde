
import java.util.*;

char[] b = new char[64];
boolean whiteTurn = true;
boolean humanWhite = true;

int selected = -1;
ArrayList<Move> legal = new ArrayList<Move>();
ArrayList<Move> allLegal = new ArrayList<Move>();

boolean wk = true, wq = true, bk = true, bq = true;
int ep = -1;
int halfmove = 0, fullmove = 1;

String status = "White to move";
String lastMove = "";
String fenText = "";
String analysisText = "Tap ANALYZE";
String promotion = "q";

boolean gameOver = false;
boolean thinking = false;
boolean showFEN = false;

int boardX, boardY, boardSize, sq;
int uiTop;

int nodes = 0;
int maxDepth = 3;
int searchTimeLimit = 1800;
int searchStart;

class Move {
  int from, to;
  char promo;
  boolean epMove, castle;

  Move(int f, int t) {
    from = f;
    to = t;
    promo = 0;
    epMove = false;
    castle = false;
  }

  Move copy() {
    Move m = new Move(from, to);
    m.promo = promo;
    m.epMove = epMove;
    m.castle = castle;
    return m;
  }

  String text() {
    return squareName(from) + squareName(to) +
      (promo == 0 ? "" : ("" + promo));
  }
}

void settings() {
  fullScreen(P2D);
}

void setup() {
  orientation(PORTRAIT);
  textAlign(CENTER, CENTER);
  textSize(24);
  layoutBoard();
  newGame();
}

void layoutBoard() {
  boardSize = min(width - 20, (int)(height * 0.62));
  boardSize = min(boardSize, width - 20);
  sq = boardSize / 8;
  boardSize = sq * 8;
  boardX = (width - boardSize) / 2;
  boardY = max(30, (int)(height * 0.12));
  uiTop = boardY + boardSize + 12;
}

void newGame() {
  String start =
    "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";
  loadFEN(start);
  selected = -1;
  legal.clear();
  lastMove = "";
  gameOver = false;
  status = "White to move";
  analysisText = "Tap ANALYZE";
}

void draw() {
  background(24, 29, 37);
  drawHeader();
  drawBoard();
  drawControls();
  drawStatus();
}

void drawHeader() {
  fill(245);
  textSize(25);
  text("CHESS", width/2, 30);
  textSize(13);
  fill(180, 195, 210);
  text("APDE 0.5.3  |  Touch chess", width/2, 55);
}

void drawBoard() {
  for (int r=0; r<8; r++) {
    for (int c=0; c<8; c++) {
      int s = r*8+c;
      int x = boardX+c*sq;
      int y = boardY+r*sq;

      if ((r+c)%2==0) fill(235, 218, 185);
      else fill(112, 145, 112);
      rect(x,y,sq,sq);

      if (selected==s) {
        noFill();
        stroke(255, 210, 40);
        strokeWeight(4);
        rect(x+2,y+2,sq-4,sq-4);
        noStroke();
      }

      if (selected>=0 && isLegalDestination(s)) {
        if (b[s]==0) fill(30, 40, 30, 110);
        else fill(220, 50, 40, 150);
        ellipse(x+sq/2,y+sq/2,sq*0.30,sq*0.30);
      }

      if (b[s]!=0) drawPiece(b[s],x,y);
    }
  }

  fill(230);
  textSize(11);
  for (int i=0;i<8;i++) {
    text("" + (char)('8'-i), boardX-10, boardY+i*sq+sq/2);
    text("" + (char)('a'+i), boardX+i*sq+sq/2, boardY+boardSize+9);
  }
}

void drawPiece(char p, int x, int y) {
  boolean white = Character.isUpperCase(p);
  String name = (""+Character.toUpperCase(p));
  fill(white ? color(255,255,245) : color(25,30,35));
  stroke(white ? color(30) : color(230));
  strokeWeight(1.2);
  ellipse(x+sq/2,y+sq/2,sq*0.78,sq*0.78);
  noStroke();
  fill(white ? color(25,35,30) : color(250,245,225));
  textSize(sq*0.49);
  text(name,x+sq/2,y+sq/2+1);
}

void drawControls() {
  int y = uiTop + 10;
  int h = max(42, min(54, height/16));
  int gap = 7;
  int w = (width-30-gap*2)/3;

  button(10,y,w,h,"NEW");
  button(20+w,y,w,h,"UNDO");
  button(30+2*w,y,w,h,"ANALYZE");

  y += h+gap;
  button(10,y,w,h,"FEN");
  button(20+w,y,w,h,"PROMOTE");
  button(30+2*w,y,w,h,"DEPTH "+maxDepth);

  y += h+gap;
  button(10,y,width-20,h,"FLIP / SIDE");
}

void button(int x,int y,int w,int h,String label) {
  fill(54,66,82);
  stroke(115,135,155);
  strokeWeight(1);
  rect(x,y,w,h,8);
  noStroke();
  fill(245);
  textSize(15);
  text(label,x+w/2,y+h/2);
}

void drawStatus() {
  int y = uiTop + 10 + 3*(max(42,min(54,height/16))+7)+10;
  fill(245);
  textSize(16);
  text(status,width/2,y);
  y += 24;

  fill(190,205,220);
  textSize(12);
  text(lastMove,width/2,y);
  y += 20;
  text(analysisText,width/2,y);

  if (showFEN) {
    y += 28;
    fill(255,220,130);
    textSize(11);
    text(fenText,width/2,y,width-20,80);
  }
}

boolean isLegalDestination(int s) {
  for (Move m:legal) if (m.to==s) return true;
  return false;
}

void mousePressed() {
  if (thinking) return;

  int y = uiTop + 10;
  int h = max(42,min(54,height/16));
  int gap = 7;
  int w = (width-30-gap*2)/3;

  if (mouseY>=y && mouseY<y+h) {
    if (mouseX<10+w) { newGame(); return; }
    if (mouseX<20+2*w) { undoMove(); return; }
    if (mouseX<width-10) { analyzePosition(); return; }
  }

  y += h+gap;
  if (mouseY>=y && mouseY<y+h) {
    if (mouseX<10+w) {
      showFEN = !showFEN;
      fenText = makeFEN();
      return;
    }
    if (mouseX<20+2*w) {
      cyclePromotion();
      return;
    }
    if (mouseX<width-10) {
      maxDepth++;
      if (maxDepth>5) maxDepth=1;
      return;
    }
  }

  y += h+gap;
  if (mouseY>=y && mouseY<y+h) {
    humanWhite = !humanWhite;
    status = humanWhite ? "You play White" : "You play Black";
    return;
  }

  if (mouseX<boardX || mouseX>=boardX+boardSize ||
      mouseY<boardY || mouseY>=boardY+boardSize) return;

  int c=(mouseX-boardX)/sq;
  int r=(mouseY-boardY)/sq;
  int s=r*8+c;

  if (selected>=0) {
    Move chosen=null;
    for (Move m:legal) {
      if (m.to==s) { chosen=m; break; }
    }
    if (chosen!=null) {
      makeMove(chosen);
      selected=-1;
      legal.clear();
      if (!gameOver && whiteTurn!=humanWhite) computerMove();
      return;
    }
  }

  if (b[s]!=0 && isWhite(b[s])==whiteTurn &&
      whiteTurn==humanWhite && !gameOver) {
    selected=s;
    legal=legalMovesFrom(s);
  } else {
    selected=-1;
    legal.clear();
  }
}

void cyclePromotion() {
  if (promotion=='q') promotion='r';
  else if (promotion=='r') promotion='b';
  else if (promotion=='b') promotion='n';
  else promotion='q';
  status="Promotion: "+promotion;
}

boolean isWhite(char p) {
  return p>='A' && p<='Z';
}

boolean isBlack(char p) {
  return p>='a' && p<='z';
}

boolean sameSide(char a,char b0) {
  if (a==0 || b0==0) return false;
  return isWhite(a)==isWhite(b0);
}

int fileOf(int s) { return s%8; }
int rankOf(int s) { return s/8; }

String squareName(int s) {
  return ""+(char)('a'+fileOf(s))+(char)('8'-rankOf(s));
}

int squareFromName(String s) {
  if (s.length()<2) return -1;
  int f=s.charAt(0)-'a';
  int r='8'-s.charAt(1);
  if (f<0||f>7||r<0||r>7) return -1;
  return r*8+f;
}

void addMove(ArrayList<Move> list,int from,int to) {
  if (to<0||to>=64) return;
  if (sameSide(b[from],b[to])) return;
  Move m=new Move(from,to);
  if (Character.toLowerCase(b[from])=='p' &&
      (rankOf(to)==0||rankOf(to)==7)) m.promo=promotion;
  list.add(m);
}

ArrayList<Move> pseudoMovesFrom(int s) {
  ArrayList<Move> out=new ArrayList<Move>();
  char p=b[s];
  if (p==0) return out;

  boolean w=isWhite(p);
  char t=Character.toLowerCase(p);
  int r=rankOf(s), c=fileOf(s);

  if (t=='p') {
    int d=w?-1:1;
    int nr=r+d;
    if (nr>=0&&nr<8) {
      int one=nr*8+c;
      if (b[one]==0) {
        addMove(out,s,one);
        int start=w?6:1;
        int nr2=r+2*d;
        if (r==start && b[nr2*8+c]==0)
          addMove(out,s,nr2*8+c);
      }
      for (int dc=-1;dc<=1;dc+=2) {
        int nc=c+dc;
        if (nc<0||nc>7) continue;
        int to=nr*8+nc;
        if (b[to]!=0 && !sameSide(p,b[to])) addMove(out,s,to);
        if (to==ep) {
          Move m=new Move(s,to);
          m.epMove=true;
          out.add(m);
        }
      }
    }
    return out;
  }

  if (t=='n') {
    int[] dr={-2,-2,-1,-1,1,1,2,2};
    int[] dc={-1,1,-2,2,-2,2,-1,1};
    for (int i=0;i<8;i++) {
      int rr=r+dr[i],cc=c+dc[i];
      if (rr>=0&&rr<8&&cc>=0&&cc<8)
        addMove(out,s,rr*8+cc);
    }
    return out;
  }

  if (t=='k') {
    for (int dr=-1;dr<=1;dr++)
      for (int dc=-1;dc<=1;dc++) {
        if (dr==0&&dc==0) continue;
        int rr=r+dr,cc=c+dc;
        if (rr>=0&&rr<8&&cc>=0&&cc<8)
          addMove(out,s,rr*8+cc);
      }

    if (w && s==60 && !inCheck(true)) {
      if (wk && b[61]==0 && b[62]==0 &&
          b[63]=='R' && !attacked(61,false) && !attacked(62,false)) {
        Move m=new Move(60,62); m.castle=true; out.add(m);
      }
      if (wq && b[59]==0 && b[58]==0 && b[57]==0 &&
          b[56]=='R' && !attacked(59,false) && !attacked(58,false)) {
        Move m=new Move(60,58); m.castle=true; out.add(m);
      }
    }
    if (!w && s==4 && !inCheck(false)) {
      if (bk && b[5]==0 && b[6]==0 &&
          b[7]=='r' && !attacked(5,true) && !attacked(6,true)) {
        Move m=new Move(4,6); m.castle=true; out.add(m);
      }
      if (bq && b[3]==0 && b[2]==0 && b[1]==0 &&
          b[0]=='r' && !attacked(3,true) && !attacked(2,true)) {
        Move m=new Move(4,2); m.castle=true; out.add(m);
      }
    }
    return out;
  }

  boolean bishop=(t=='b'||t=='q');
  boolean rook=(t=='r'||t=='q');

  if (bishop||rook) {
    int[][] dirs={{-1,-1},{-1,1},{1,-1},{1,1},
                  {-1,0},{1,0},{0,-1},{0,1}};
    for (int i=0;i<8;i++) {
      if (i<4&&!bishop) continue;
      if (i>=4&&!rook) continue;
      int rr=r+dirs[i][0],cc=c+dirs[i][1];
      while (rr>=0&&rr<8&&cc>=0&&cc<8) {
        int to=rr*8+cc;
        if (sameSide(p,b[to])) break;
        addMove(out,s,to);
        if (b[to]!=0) break;
        rr+=dirs[i][0]; cc+=dirs[i][1];
      }
    }
  }
  return out;
}

boolean attacked(int sqr,boolean byWhite) {
  int r=rankOf(sqr),c=fileOf(sqr);

  int pawnDir=byWhite?1:-1;
  int pawnRow=r+pawnDir;
  if (pawnRow>=0&&pawnRow<8) {
    for (int dc=-1;dc<=1;dc+=2) {
      int cc=c+dc;
      if (cc>=0&&cc<8) {
        char p=b[pawnRow*8+cc];
        if (p==(byWhite?'P':'p')) return true;
      }
    }
  }

  int[] knr={-2,-2,-1,-1,1,1,2,2};
  int[] knc={-1,1,-2,2,-2,2,-1,1};
  for (int i=0;i<8;i++) {
    int rr=r+knr[i],cc=c+knc[i];
    if (rr>=0&&rr<8&&cc>=0&&cc<8 &&
        b[rr*8+cc]==(byWhite?'N':'n')) return true;
  }

  for (int dr=-1;dr<=1;dr++)
    for (int dc=-1;dc<=1;dc++) {
      if (dr==0&&dc==0) continue;
      int rr=r+dr,cc=c+dc;
      if (rr>=0&&rr<8&&cc>=0&&cc<8 &&
          b[rr*8+cc]==(byWhite?'K':'k')) return true;
    }

  int[][] dirs={{-1,-1},{-1,1},{1,-1},{1,1},
                {-1,0},{1,0},{0,-1},{0,1}};
  for (int i=0;i<8;i++) {
    int rr=r+dirs[i][0],cc=c+dirs[i][1],dist=1;
    while (rr>=0&&rr<8&&cc>=0&&cc<8) {
      char p=b[rr*8+cc];
      if (p!=0) {
        if (isWhite(p)==byWhite) {
          char t=Character.toLowerCase(p);
          if (t=='q'||(i<4&&t=='b')||
              (i>=4&&t=='r')||(dist==1&&t=='k'))
            return true;
        }
        break;
      }
      rr+=dirs[i][0];cc+=dirs[i][1];dist++;
    }
  }
  return false;
}

int kingSquare(boolean white) {
  char k=white?'K':'k';
  for (int i=0;i<64;i++) if (b[i]==k) return i;
  return -1;
}

boolean inCheck(boolean white) {
  int k=kingSquare(white);
  if (k<0) return true;
  return attacked(k,!white);
}

ArrayList<Move> legalMovesFrom(int s) {
  ArrayList<Move> result=new ArrayList<Move>();
  ArrayList<Move> ps=pseudoMovesFrom(s);
  for (Move m:ps) {
    Snapshot snap=new Snapshot();
    applyRaw(m);
    boolean safe=!inCheck(isWhite(b[m.to]));
    snap.restore();
    if (safe) result.add(m);
  }
  return result;
}

ArrayList<Move> legalMoves(boolean white) {
  ArrayList<Move> result=new ArrayList<Move>();
  for (int s=0;s<64;s++) {
    if (b[s]!=0 && isWhite(b[s])==white)
      result.addAll(legalMovesFrom(s));
  }
  return result;
}

class Snapshot {
  char[] old=b.clone();
  boolean owk=wk,owq=wq,obk=bk,obq=bq;
  int oep=ep,oh=halfmove,of=fullmove;
  boolean ot=whiteTurn;

  void restore() {
    for (int i=0;i<64;i++) b[i]=old[i];
    wk=owk;wq=owq;bk=obk;bq=obq;
    ep=oep;halfmove=oh;fullmove=of;whiteTurn=ot;
  }
}

void applyRaw(Move m) {
  char p=b[m.from];
  char captured=b[m.to];
  b[m.to]=p;
  b[m.from]=0;

  if (m.epMove) {
    int cap=m.to+(isWhite(p)?8:-8);
    b[cap]=0;
  }

  if (m.castle) {
    if (m.to==62) { b[61]=b[63];b[63]=0; }
    if (m.to==58) { b[59]=b[56];b[56]=0; }
    if (m.to==6) { b[5]=b[7];b[7]=0; }
    if (m.to==2) { b[3]=b[0];b[0]=0; }
  }

  if (m.promo!=0) {
    char q=m.promo;
    b[m.to]=isWhite(p)?Character.toUpperCase(q):q;
  }

  if (p=='K') { wk=false;wq=false; }
  if (p=='k') { bk=false;bq=false; }
  if (m.from==63||m.to==63) wk=false;
  if (m.from==56||m.to==56) wq=false;
  if (m.from==7||m.to==7) bk=false;
  if (m.from==0||m.to==0) bq=false;

  ep=-1;
  if (Character.toLowerCase(p)=='p' &&
      abs(rankOf(m.to)-rankOf(m.from))==2)
    ep=(m.to+m.from)/2;

  if (Character.toLowerCase(p)=='p'||captured!=0||m.epMove)
    halfmove=0;
  else halfmove++;

  if (!whiteTurn) fullmove++;
  whiteTurn=!whiteTurn;
}

void makeMove(Move m) {
  String mover=whiteTurn?"White":"Black";
  String notation=m.text();
  applyRaw(m);
  lastMove=mover+": "+notation;
  selected=-1;
  legal.clear();
  updateGameStatus();
}

void updateGameStatus() {
  ArrayList<Move> moves=legalMoves(whiteTurn);
  if (moves.size()==0) {
    gameOver=true;
    if (inCheck(whiteTurn))
      status="CHECKMATE — "+(whiteTurn?"Black":"White")+" wins";
    else status="STALEMATE — draw";
  } else if (halfmove>=100) {
    gameOver=true;
    status="Draw: 50-move rule";
  } else {
    status=whiteTurn?"White to move":"Black to move";
    if (inCheck(whiteTurn)) status+=" — CHECK";
  }
  fenText=makeFEN();
}

void computerMove() {
  if (gameOver||whiteTurn==humanWhite) return;
  thinking=true;
  status="Computer thinking...";
  draw();
  searchStart=millis();
  nodes=0;

  Move best=null;
  int bestScore=whiteTurn?-999999:999999;
  ArrayList<Move> moves=legalMoves(whiteTurn);
  orderMoves(moves);

  for (Move m:moves) {
    Snapshot snap=new Snapshot();
    applyRaw(m);
    int score=search(maxDepth-1,-1000000,1000000);
    snap.restore();

    if (whiteTurn && score>bestScore) {
      bestScore=score;best=m;
    }
    if (!whiteTurn && score<bestScore) {
      bestScore=score;best=m;
    }
    if (millis()-searchStart>searchTimeLimit) break;
  }

  if (best==null && moves.size()>0) best=moves.get(0);
  thinking=false;
  if (best!=null) makeMove(best);
}

int search(int depth,int alpha,int beta) {
  nodes++;
  if (depth<=0) return quiescence(alpha,beta,0);

  ArrayList<Move> moves=legalMoves(whiteTurn);
  if (moves.size()==0) {
    if (inCheck(whiteTurn))
      return whiteTurn?-90000+depth:90000-depth;
    return 0;
  }

  orderMoves(moves);
  boolean maximizing=whiteTurn;
  int best=maximizing?-999999:999999;

  for (Move m:moves) {
    Snapshot snap=new Snapshot();
    applyRaw(m);
    int score=search(depth-1,alpha,beta);
    snap.restore();

    if (maximizing) {
      best=max(best,score);
      alpha=max(alpha,best);
    } else {
      best=min(best,score);
      beta=min(beta,best);
    }
    if (beta<=alpha) break;
    if (millis()-searchStart>searchTimeLimit && depth>1) break;
  }
  return best;
}

int quiescence(int alpha,int beta,int qdepth) {
  int stand=evaluate();
  if (qdepth>=3) return stand;

  if (whiteTurn) {
    if (stand>=beta) return beta;
    alpha=max(alpha,stand);
  } else {
    if (stand<=alpha) return alpha;
    beta=min(beta,stand);
  }

  ArrayList<Move> moves=legalMoves(whiteTurn);
  ArrayList<Move> caps=new ArrayList<Move>();
  for (Move m:moves) {
    if (b[m.to]!=0||m.epMove) caps.add(m);
  }
  orderMoves(caps);

  for (Move m:caps) {
    Snapshot snap=new Snapshot();
    applyRaw(m);
    int score=quiescence(alpha,beta,qdepth+1);
    snap.restore();

    if (whiteTurn) {
      if (score>=beta) return beta;
      alpha=max(alpha,score);
    } else {
      if (score<=alpha) return alpha;
      beta=min(beta,score);
    }
  }
  return whiteTurn?alpha:beta;
}

void orderMoves(ArrayList<Move> moves) {
  Collections.sort(moves,new Comparator<Move>() {
    public int compare(Move a,Move c) {
      int va=moveOrder(a),vc=moveOrder(c);
      return vc-va;
    }
  });
}

int moveOrder(Move m) {
  int score=0;
  if (b[m.to]!=0) score+=10*pieceValue(b[m.to])-pieceValue(b[m.from]);
  if (m.epMove) score+=100;
  if (m.promo!=0) score+=800;
  return score;
}

int pieceValue(char p) {
  switch(Character.toLowerCase(p)) {
  case 'p':return 100;
  case 'n':return 320;
  case 'b':return 330;
  case 'r':return 500;
  case 'q':return 900;
  case 'k':return 20000;
  }
  return 0;
}

int evaluate() {
  int score=0;
  for (int s=0;s<64;s++) {
    char p=b[s];
    if (p==0) continue;
    int v=pieceValue(p);
    int r=rankOf(s),c=fileOf(s);
    int center=7-(abs(3-r)+abs(3-c));
    v+=center*3;

    if (Character.toLowerCase(p)=='p') {
      v+=(isWhite(p)?(6-r):(r-1))*8;
    }
    score+=isWhite(p)?v:-v;
  }
  return score;
}

void analyzePosition() {
  nodes=0;
  searchStart=millis();
  ArrayList<Move> moves=legalMoves(whiteTurn);
  if (moves.size()==0) {
    analysisText="No legal moves";
    return;
  }
  orderMoves(moves);
  Move best=moves.get(0);
  int bestScore=whiteTurn?-999999:999999;

  for (Move m:moves) {
    Snapshot snap=new Snapshot();
    applyRaw(m);
    int score=search(maxDepth-1,-1000000,1000000);
    snap.restore();

    if (whiteTurn&&score>bestScore) {
      bestScore=score;best=m;
    }
    if (!whiteTurn&&score<bestScore) {
      bestScore=score;best=m;
    }
    if (millis()-searchStart>searchTimeLimit) break;
  }

  analysisText="Best: "+best.text()+"  Eval: "+
    nf(bestScore/100.0,1,2)+"  Depth "+maxDepth;
}

void undoMove() {
  status="Undo is not available in this compact build";
}

String makeFEN() {
  String out="";
  for (int r=0;r<8;r++) {
    int empty=0;
    for (int c=0;c<8;c++) {
      char p=b[r*8+c];
      if (p==0) empty++;
      else {
        if (empty>0) { out+=empty;empty=0; }
        out+=p;
      }
    }
    if (empty>0) out+=empty;
    if (r<7) out+="/";
  }

  out+=" "+(whiteTurn?"w":"b")+" ";
  String cr="";
  if (wk) cr+="K";
  if (wq) cr+="Q";
  if (bk) cr+="k";
  if (bq) cr+="q";
  out+=(cr.length()==0?"-":cr);
  out+=" "+(ep<0?"-":squareName(ep));
  out+=" "+halfmove+" "+fullmove;
  return out;
}

boolean loadFEN(String fen) {
  try {
    String[] parts=splitTokens(fen," ");
    if (parts.length<4) return false;
    String[] rows=split(parts[0],'/');
    if (rows.length!=8) return false;

    for (int i=0;i<64;i++) b[i]=0;
    for (int r=0;r<8;r++) {
      int c=0;
      for (int j=0;j<rows[r].length();j++) {
        char ch=rows[r].charAt(j);
        if (ch>='1'&&ch<='8') c+=ch-'0';
        else {
          if (c>=8) return false;
          b[r*8+c]=ch;
          c++;
        }
      }
      if (c!=8) return false;
    }

    whiteTurn=parts[1].equals("w");
    wk=parts[2].contains("K");
    wq=parts[2].contains("Q");
    bk=parts[2].contains("k");
    bq=parts[2].contains("q");
    ep=parts[3].equals("-")?-1:squareFromName(parts[3]);
    halfmove=parts.length>4?Integer.parseInt(parts[4]):0;
    fullmove=parts.length>5?Integer.parseInt(parts[5]):1;

    gameOver=false;
    selected=-1;
    legal.clear();
    fenText=makeFEN();
    return true;
  } catch(Exception e) {
    return false;
  }
}













