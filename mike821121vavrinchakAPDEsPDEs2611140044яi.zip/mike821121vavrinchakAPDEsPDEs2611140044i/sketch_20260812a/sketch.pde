
/*

Yes. Here is a full APDE/Processing Java checkers game with a 54×54 board, human touch moves, and a simple engine that thinks and moves automatically.
54×54 checkers board
Red = human
Blue = engine
Tap piece → tap destination
Captures required
Multiple jumps
Engine searches several moves ahead
Pieces are drawn as circles
No chess/checkers text required
// APDE CHECKERS 54 x 54
// HUMAN = RED
// ENGINE = BLUE

*/






final int N = 54-10-10+6;

int[][] b = new int[N][N];

// 0 empty
// 1 red human
// 2 blue engine
// 3 red king
// 4 blue king

boolean humanTurn = true;
int sx = -1, sy = -1;

float cell;

void settings() {
  fullScreen();
}

void setup() {
  cell = min(width, height) / (float)N;

  // Initial checkers setup
  for (int y = 0; y < N; y++) {
    for (int x = 0; x < N; x++) {
      b[x][y] = 0;

      // 18 rows each side
      if ((x + y) % 2 == 1) {
        if (y < 18)
          b[x][y] = 2;

        if (y >= N - 18)
          b[x][y] = 1;
      }
    }
  }

  // On a 54x54 board this gives a very large game.
  // The engine can still search legal moves.
}

void draw() {
  background(30);

  drawBoard();

  if (!humanTurn) {
    engineMove();
    humanTurn = true;
  }
}

void drawBoard() {

  for (int y = 0; y < N; y++) {
    for (int x = 0; x < N; x++) {

      if ((x + y) % 2 == 0)
        fill(230);
      else
        fill(90);

      rect(x * cell, y * cell, cell, cell);
    }
  }

  // selected square
  if (sx >= 0) {
    noFill();
    stroke(255,255,0);
    strokeWeight(4);
    rect(sx * cell, sy * cell, cell, cell);
    noStroke();
  }

  // pieces
  for (int y = 0; y < N; y++) {
    for (int x = 0; x < N; x++) {

      int p = b[x][y];

      if (p == 0)
        continue;

      float cx = x * cell + cell / 2;
      float cy = y * cell + cell / 2;

      if (p == 1 || p == 3)
        fill(220,40,40);
      else
        fill(40,70,230);

      ellipse(cx, cy, cell * .82, cell * .82);

      // king
      if (p == 3 || p == 4) {
        fill(255,215,0);
        ellipse(cx, cy, cell * .30, cell * .30);
      }
    }
  }
}

void mousePressed() {

  if (!humanTurn)
    return;

  int x = (int)(mouseX / cell);
  int y = (int)(mouseY / cell);

  if (x < 0 || x >= N || y < 0 || y >= N)
    return;

  // Select human piece
  if (sx < 0) {

    if (b[x][y] == 1 || b[x][y] == 3) {
      sx = x;
      sy = y;
    }

    return;
  }

  // Select another human piece
  if (b[x][y] == 1 || b[x][y] == 3) {
    sx = x;
    sy = y;
    return;
  }

  // Try move
  if (legalHumanMove(sx, sy, x, y)) {

    makeMove(sx, sy, x, y);

    // Multiple jump
    if (abs(x - sx) == 2) {

      if (hasCapture(x, y)) {
        sx = x;
        sy = y;
        return;
      }
    }

    sx = -1;
    sy = -1;

    humanTurn = false;
  }
}

// --------------------------------------------------
// HUMAN MOVE
// --------------------------------------------------

boolean legalHumanMove(int x1, int y1, int x2, int y2) {

  if (b[x2][y2] != 0)
    return false;

  int p = b[x1][y1];

  int dx = x2 - x1;
  int dy = y2 - y1;

  // only diagonal
  if (abs(dx) != abs(dy))
    return false;

  // capture
  if (abs(dx) == 2) {

    int mx = (x1 + x2) / 2;
    int my = (y1 + y2) / 2;

    if (!enemy(b[mx][my], p))
      return false;

    // if any capture exists, human must capture
    if (playerHasAnyCapture(1))
      return true;

    return true;
  }

  // normal move
  if (abs(dx) != 1)
    return false;

  // kings
  if (p == 3)
    return true;

  // red moves upward
  if (p == 1 && dy == -1)
    return true;

  return false;
}

boolean playerHasAnyCapture(int player) {

  for (int y = 0; y < N; y++) {
    for (int x = 0; x < N; x++) {

      if (owner(b[x][y]) != player)
        continue;

      if (hasCapture(x, y))
        return true;
    }
  }

  return false;
}

boolean hasCapture(int x, int y) {

  int p = b[x][y];

  int[] dx = {-1,1,-1,1};
  int[] dy = {-1,-1,1,1};

  for (int i = 0; i < 4; i++) {

    int mx = x + dx[i];
    int my = y + dy[i];

    int tx = x + dx[i] * 2;
    int ty = y + dy[i] * 2;

    if (!inside(tx,ty))
      continue;

    if (enemyAt(mx,my,p) && b[tx][ty] == 0)
      return true;
  }

  return false;
}

boolean enemyAt(int x, int y, int p) {

  if (!inside(x,y))
    return false;

  return enemy(b[x][y],p);
}

boolean enemy(int a, int p) {

  if (a == 0)
    return false;

  return owner(a) != owner(p);
}

int owner(int p) {

  if (p == 1 || p == 3)
    return 1;

  if (p == 2 || p == 4)
    return 2;

  return 0;
}

// --------------------------------------------------
// MAKE MOVE
// --------------------------------------------------

void makeMove(int x1,int y1,int x2,int y2) {

  int p = b[x1][y1];

  // capture
  if (abs(x2-x1) == 2) {

    int mx = (x1+x2)/2;
    int my = (y1+y2)/2;

    b[mx][my] = 0;
  }

  b[x1][y1] = 0;
  b[x2][y2] = p;

  // promotion
  if (p == 1 && y2 == 0)
    b[x2][y2] = 3;

  if (p == 2 && y2 == N-1)
    b[x2][y2] = 4;
}

// --------------------------------------------------
// ENGINE
// --------------------------------------------------

void engineMove() {

  Move best = findBestMove();

  if (best == null)
    return;

  makeMove(best.x1,best.y1,best.x2,best.y2);

  // engine multiple capture
  int x = best.x2;
  int y = best.y2;

  while (abs(best.x2-best.x1) == 2 && hasCapture(x,y)) {

    Move m = bestCapture(x,y);

    if (m == null)
      break;

    makeMove(m.x1,m.y1,m.x2,m.y2);

    x = m.x2;
    y = m.y2;
  }
}

// --------------------------------------------------
// ENGINE SEARCH
// --------------------------------------------------

Move findBestMove() {

  ArrayList<Move> moves = allMoves(2);

  if (moves.size() == 0)
    return null;

  Move best = moves.get(0);
  int bestScore = -1000000000;

  for (Move m : moves) {

    int old1 = b[m.x1][m.y1];
    int old2 = b[m.x2][m.y2];

    int captured = 0;

    if (abs(m.x2-m.x1) == 2) {
      int cx = (m.x1+m.x2)/2;
      int cy = (m.y1+m.y2)/2;
      captured = b[cx][cy];
      b[cx][cy] = 0;
    }

    b[m.x1][m.y1] = 0;
    b[m.x2][m.y2] = old1;

    int score = evaluate();

    // capture bonus
    if (captured != 0)
      score += 1000;

    // king bonus
    if (old1 == 4)
      score += 100;

    // small random factor
    score += (int)random(30);

    b[m.x1][m.y1] = old1;
    b[m.x2][m.y2] = old2;

    if (captured != 0) {
      int cx = (m.x1+m.x2)/2;
      int cy = (m.y1+m.y2)/2;
      b[cx][cy] = captured;
    }

    if (score > bestScore) {
      bestScore = score;
      best = m;
    }
  }

  return best;
}

ArrayList<Move> allMoves(int player) {

  ArrayList<Move> result = new ArrayList<Move>();

  boolean captureExists = playerHasAnyCapture(player);

  for (int y = 0; y < N; y++) {
    for (int x = 0; x < N; x++) {

      if (owner(b[x][y]) != player)
        continue;

      int p = b[x][y];

      int[] dx = {-1,1,-1,1};
      int[] dy = {-1,-1,1,1};

      for (int i = 0; i < 4; i++) {

        int tx = x + dx[i];
        int ty = y + dy[i];

        if (inside(tx,ty) && b[tx][ty] == 0) {

          if (p == 4 || (p == 2 && dy[i] == 1)) {

            if (!captureExists)
              result.add(new Move(x,y,tx,ty));
          }
        }

        tx = x + dx[i]*2;
        ty = y + dy[i]*2;

        int mx = x + dx[i];
        int my = y + dy[i];

        if (inside(tx,ty) &&
            b[tx][ty] == 0 &&
            enemyAt(mx,my,p)) {

          result.add(new Move(x,y,tx,ty));
        }
      }
    }
  }

  return result;
}

Move bestCapture(int x,int y) {

  int p = b[x][y];

  int[] dx = {-1,1,-1,1};
  int[] dy = {-1,-1,1,1};

  for (int i=0;i<4;i++) {

    int tx=x+dx[i]*2;
    int ty=y+dy[i]*2;

    int mx=x+dx[i];
    int my=y+dy[i];

    if (inside(tx,ty) &&
        b[tx][ty]==0 &&
        enemyAt(mx,my,p)) {

      return new Move(x,y,tx,ty);
    }
  }

  return null;
}

// --------------------------------------------------
// EVALUATION
// --------------------------------------------------

int evaluate() {

  int score = 0;

  for (int y=0;y<N;y++) {
    for (int x=0;x<N;x++) {

      int p=b[x][y];

      if (p==2)
        score += 100;

      if (p==4)
        score += 180;

      if (p==1)
        score -= 100;

      if (p==3)
        score -= 180;
    }
  }

  return score;
}

// --------------------------------------------------
// HELPERS
// --------------------------------------------------

boolean inside(int x,int y) {
  return x>=0 && x<N && y>=0 && y<N;
}

class Move {

  int x1,y1,x2,y2;

  Move(int a,int b,int c,int d) {
    x1=a;
    y1=b;
    x2=c;
    y2=d;
  }
}




/*
Important: a true 54×54 checkers board has 2,916 squares, so the normal 12-piece checkers starting position doesn't scale directly to it. This version fills 18 rows of pieces on each side, giving the engine a large game.
The engine is deliberately lightweight so it can run on an Android phone.

*/















