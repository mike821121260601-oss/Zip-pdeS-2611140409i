
















































int [] [] [] m=new int[55][55][5];
int t=0;


























void setup () {
//fullScreen(P2D) ;
size(displayWidth, displayHeight, P2D) ;
orientation(PORTRAIT) ;  } 

void draw() {noStroke() ;
rectMode(CENTER) ;
ellipseMode(CENTER) ;


if(t==0){t=1;
for(int f=0;f<55;f++){
for(int ff=0;ff<55;ff++){
m[f] [ff] [0]=int(random(1,999)) ;
m[f] [ff] [1]=int(random(0,255));
m[f] [ff] [2]=int(random(0,255));
m[f] [ff] [3]=int(random(0,255));

} }    //}











for(int f=0;f<55;f++){
for(int ff=0;ff<55;ff++){

fill(m[f] [ff] [1] 
,m[f] [ff] [2]  ,
m[f] [ff] [3]  );
rect(
displayWidth /55*(1.5+f) 
,displayHeight /55*(0.7+ff)
 ,displayWidth /55,displayHeight /55);

fill(int(m[f] [ff] [0]/5)  
,int(m[f] [ff] [0]/5)  ,
int(m[f] [ff] [0]/5)  );
rect(
displayWidth /55*(1.5+f) 
,displayHeight /55*(0.7+ff)
 ,displayWidth /75,displayHeight /75);

} } 
























for(int f=0;f<55;f++){
for(int ff=0;ff<55;ff++){
fill(m[f] [ff] [1] 
,m[f] [ff] [2]  ,
m[f] [ff] [3]  );

rect(
displayWidth /55*(1.5+f) 
+random(0,displayWidth /155)
-random(0,displayWidth /155)

,displayHeight /2+
displayHeight /55/2*(0.7+ff)
-m[f] [ff] [0] /2/9
 ,displayWidth /155,
m[f] [ff] [0]/9 );






rect(
displayWidth /55*(1.5+f) 
+random(0,displayWidth /155)
-random(0,displayWidth /155)
-displayWidth /155

,displayHeight /2+
displayHeight /55/2*(0.7+ff)
-m[f] [ff] [0] /2/9
 ,displayWidth /155,
m[f] [ff] [0]/9 *0.95 );

rect(
displayWidth /55*(1.5+f) 
+random(0,displayWidth /155)
-random(0,displayWidth /155)
+displayWidth /155

,displayHeight /2+
displayHeight /55/2*(0.7+ff)
-m[f] [ff] [0] /2/9
 ,displayWidth /155,
m[f] [ff] [0]/9 *0.95 );














if((f<54)&&(ff<54)){
stroke(1,1,1);strokeWeight(11);
line(displayWidth /55*(1.5+f), 
displayHeight /2+
displayHeight /55/2*(0.7+ff)
-m[f] [ff] [0] /2/9, 

displayWidth /55*(1.5+f+1), 

displayHeight /2+
displayHeight /55/2*(0.7+ff)
-m[f+1] [ff] [0] /2/9) ;   
noStroke() ;   } 













 } }
} 














//t=0;
if( int(round(random(0,11111)))==9 ) {t=0;}

} 



































