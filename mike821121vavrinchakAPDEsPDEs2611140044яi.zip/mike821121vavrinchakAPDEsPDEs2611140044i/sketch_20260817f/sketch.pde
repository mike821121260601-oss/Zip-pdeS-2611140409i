





#!/usr/bin/env python3
"""
APDE FULL CODE
MORTAL COMBAT 3D ENGINE DEMO
Hands (punch) • Foots (kick) • Jumps • Run • GO!

Controls (Player 1 - Red, Left):
  A / D     : Run left / right
  W         : Jump
  J         : Punch (Hands)
  K         : Kick (Foots)
  S         : Block

Player 2 - Blue, Right:
  ← / →     : Run
  ↑         : Jump
  U or Numpad1 : Punch
  I or Numpad2 : Kick
  ↓         : Block

ESC = Quit | R = Restart after KO
"""

import pygame
import sys
import math
import random

# ================== INIT ==================
pygame.init()
WIDTH, HEIGHT = 1000, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("APDE MORTAL COMBAT 3D ENGINE - JUMPS + HANDS + FOOTS")
clock = pygame.time.Clock()
FPS = 60

# Colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (220, 50, 50)
BLUE = (50, 100, 220)
GREEN = (50, 200, 80)
YELLOW = (255, 220, 50)
GRAY = (80, 80, 80)
DARK_GRAY = (40, 40, 40)
ORANGE = (255, 140, 0)
PURPLE = (180, 50, 200)
SKY = (30, 30, 60)
GROUND = (60, 40, 20)

# Fonts
try:
    font_big = pygame.font.SysFont("Arial", 48, bold=True)
    font_med = pygame.font.SysFont("Arial", 28)
    font_small = pygame.font.SysFont("Arial", 20)
except:
    font_big = pygame.font.Font(None, 48)
    font_med = pygame.font.Font(None, 28)
    font_small = pygame.font.Font(None, 20)

# ================== PHYSICS ==================
GRAVITY = 0.85
JUMP_FORCE = -16.5
MOVE_SPEED = 6.5
RUN_MULT = 1.35
GROUND_Y = HEIGHT - 80
FRICTION = 0.75

# ================== FIGHTER ==================
class Fighter:
    def __init__(self, x, y, color, facing=1, is_player2=False):
        self.x = float(x)
        self.y = float(y)
        self.vx = 0.0
        self.vy = 0.0
        self.width = 50
        self.height = 110
        self.color = color
        self.facing = facing
        self.is_player2 = is_player2
        self.health = 100
        self.max_health = 100
        self.on_ground = True
        self.jumping = False
        self.blocking = False
        self.attacking = False
        self.attack_type = None
        self.attack_timer = 0
        self.attack_cooldown = 0
        self.hitstun = 0
        self.invuln = 0
        self.combo = 0
        self.score = 0
        self.alive = True
        self.name = "PLAYER 2" if is_player2 else "PLAYER 1"
        self.anim_frame = 0
        self.state = "idle"

    def get_rect(self):
        return pygame.Rect(self.x - self.width//2, self.y - self.height, self.width, self.height)

    def get_hitbox(self):
        return self.get_rect()

    def get_attack_box(self):
        if not self.attacking or self.attack_timer <= 0:
            return None
        if self.attack_type == "punch":
            aw, ah = 45, 30
            ax = self.x + (self.facing * (self.width//2 + 10))
            ay = self.y - self.height + 25
            return pygame.Rect(ax - aw//2, ay, aw, ah)
        elif self.attack_type == "kick":
            aw, ah = 55, 35
            ax = self.x + (self.facing * (self.width//2 + 15))
            ay = self.y - 45
            return pygame.Rect(ax - aw//2, ay, aw, ah)
        return None

    def update(self, keys, opponent):
        if not self.alive:
            self.state = "ko"
            self.vy += GRAVITY
            self.y += self.vy
            if self.y > GROUND_Y + 50:
                self.y = GROUND_Y + 50
                self.vy = 0
            return

        if self.attack_cooldown > 0:
            self.attack_cooldown -= 1
        if self.hitstun > 0:
            self.hitstun -= 1
            self.state = "hit"
            self.vx *= 0.9
            self.vy += GRAVITY
            self.x += self.vx
            self.y += self.vy
            self._ground_check()
            return
        if self.invuln > 0:
            self.invuln -= 1

        if self.is_player2:
            left = keys[pygame.K_LEFT]
            right = keys[pygame.K_RIGHT]
            jump = keys[pygame.K_UP]
            punch = keys[pygame.K_u] or keys[pygame.K_KP1]
            kick = keys[pygame.K_i] or keys[pygame.K_KP2]
            block = keys[pygame.K_DOWN]
        else:
            left = keys[pygame.K_a]
            right = keys[pygame.K_d]
            jump = keys[pygame.K_w]
            punch = keys[pygame.K_j]
            kick = keys[pygame.K_k]
            block = keys[pygame.K_s]

        self.blocking = block and self.on_ground and not self.attacking
        if self.blocking:
            self.state = "block"
            self.vx *= 0.5
        else:
            speed = MOVE_SPEED
            if left or right:
                speed = MOVE_SPEED * RUN_MULT
            if left:
                self.vx = -speed
                self.facing = -1
                if self.on_ground:
                    self.state = "run"
            elif right:
                self.vx = speed
                self.facing = 1
                if self.on_ground:
                    self.state = "run"
            else:
                self.vx *= FRICTION
                if abs(self.vx) < 0.3:
                    self.vx = 0
                if self.on_ground and not self.attacking:
                    self.state = "idle"

        if jump and self.on_ground and not self.blocking and self.attack_cooldown <= 0:
            self.vy = JUMP_FORCE
            self.on_ground = False
            self.jumping = True
            self.state = "jump"

        if not self.attacking and self.attack_cooldown <= 0 and not self.blocking:
            if punch:
                self.attacking = True
                self.attack_type = "punch"
                self.attack_timer = 14
                self.attack_cooldown = 22
                self.state = "punch"
                self.vx *= 0.3
            elif kick:
                self.attacking = True
                self.attack_type = "kick"
                self.attack_timer = 16
                self.attack_cooldown = 28
                self.state = "kick"
                self.vx *= 0.2

        if self.attacking:
            self.attack_timer -= 1
            if self.attack_timer <= 0:
                self.attacking = False
                self.attack_type = None

        self.vy += GRAVITY
        self.x += self.vx
        self.y += self.vy
        self.x = max(40, min(WIDTH - 40, self.x))
        self._ground_check()

        if opponent and abs(self.x - opponent.x) > 20:
            self.facing = 1 if self.x < opponent.x else -1

        self.anim_frame += 1

    def _ground_check(self):
        if self.y >= GROUND_Y:
            self.y = GROUND_Y
            self.vy = 0
            self.on_ground = True
            self.jumping = False
        else:
            self.on_ground = False

    def take_damage(self, amount, attacker, is_blocked=False):
        if self.invuln > 0 or not self.alive:
            return False
        if self.blocking and is_blocked:
            amount = int(amount * 0.25)
            self.vx = attacker.facing * 4
        else:
            self.health -= amount
            self.hitstun = 12
            self.invuln = 18
            self.vx = attacker.facing * 8
            self.vy = -4
            self.combo = 0
            if self.health <= 0:
                self.health = 0
                self.alive = False
                self.state = "ko"
                attacker.score += 1
                return True
        return False

    def draw(self, surface):
        rect = self.get_rect()
        col = self.color
        if self.invuln > 0 and (self.invuln // 2) % 2 == 0:
            col = WHITE

        # Torso
        torso = pygame.Rect(rect.x + 8, rect.y + 20, rect.w - 16, 50)
        pygame.draw.rect(surface, col, torso)

        # Head
        pygame.draw.circle(surface, col, (int(self.x), int(rect.y + 15)), 18)
        eye_off = 6 * self.facing
        pygame.draw.circle(surface, WHITE, (int(self.x + eye_off), int(rect.y + 12)), 4)
        pygame.draw.circle(surface, BLACK, (int(self.x + eye_off + 2*self.facing), int(rect.y + 12)), 2)

        # Arms / Hands
        arm_y = rect.y + 35
        if self.attacking and self.attack_type == "punch":
            arm_end_x = self.x + self.facing * 55
            pygame.draw.line(surface, col, (self.x, arm_y), (arm_end_x, arm_y - 5), 10)
            pygame.draw.circle(surface, YELLOW, (int(arm_end_x), int(arm_y - 5)), 12)
        else:
            pygame.draw.line(surface, col, (self.x - 15, arm_y), (self.x - 25, arm_y + 25), 8)
            pygame.draw.line(surface, col, (self.x + 15, arm_y), (self.x + 25, arm_y + 25), 8)

        # Legs / Foots
        leg_y = rect.y + 70
        if self.attacking and self.attack_type == "kick":
            leg_end_x = self.x + self.facing * 65
            pygame.draw.line(surface, col, (self.x, leg_y), (leg_end_x, leg_y + 10), 12)
            pygame.draw.circle(surface, ORANGE, (int(leg_end_x), int(leg_y + 10)), 14)
        else:
            offset = 0
            if self.state == "run":
                offset = 8 * math.sin(self.anim_frame * 0.4)
            pygame.draw.line(surface, col, (self.x - 10, leg_y), (self.x - 15 - offset, rect.bottom), 10)
            pygame.draw.line(surface, col, (self.x + 10, leg_y), (self.x + 15 + offset, rect.bottom), 10)

        if self.blocking:
            pygame.draw.rect(surface, YELLOW, (rect.x - 5, rect.y - 5, rect.w + 10, rect.h + 10), 3)

        abox = self.get_attack_box()
        if abox:
            pygame.draw.rect(surface, (255, 255, 0), abox, 2)

        name_s = font_small.render(self.name, True, WHITE)
        surface.blit(name_s, (self.x - name_s.get_width()//2, rect.y - 45))

# ================== HELPERS ==================
def draw_health_bar(surface, x, y, w, h, current, maximum, color):
    pygame.draw.rect(surface, DARK_GRAY, (x, y, w, h))
    fill = int(w * (current / maximum))
    pygame.draw.rect(surface, color, (x, y, fill, h))
    pygame.draw.rect(surface, WHITE, (x, y, w, h), 2)

def draw_stage(surface):
    surface.fill(SKY)
    pygame.draw.rect(surface, GROUND, (0, GROUND_Y, WIDTH, HEIGHT - GROUND_Y))
    pygame.draw.line(surface, (100, 70, 40), (0, GROUND_Y), (WIDTH, GROUND_Y), 4)
    for i in range(5):
        px = 100 + i * 200
        pygame.draw.rect(surface, (50, 50, 70), (px, GROUND_Y - 180, 40, 180))
        pygame.draw.rect(surface, (70, 70, 90), (px + 5, GROUND_Y - 170, 30, 20))

# ================== MAIN ==================
def main():
    p1 = Fighter(250, GROUND_Y, RED, facing=1, is_player2=False)
    p2 = Fighter(750, GROUND_Y, BLUE, facing=-1, is_player2=True)

    game_over = False
    winner = None
    start_timer = 180
    round_text = "READY..."

    running = True
    while running:
        clock.tick(FPS)
        keys = pygame.key.get_pressed()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                if event.key == pygame.K_r and game_over:
                    p1 = Fighter(250, GROUND_Y, RED, facing=1, is_player2=False)
                    p2 = Fighter(750, GROUND_Y, BLUE, facing=-1, is_player2=True)
                    game_over = False
                    winner = None
                    start_timer = 180
                    round_text = "READY..."

        if start_timer > 0:
            start_timer -= 1
            if start_timer > 120:
                round_text = "READY..."
            elif start_timer > 60:
                round_text = "FIGHT!"
            else:
                round_text = "GO!"
            p1.update(keys, p2)
            p2.update(keys, p1)
        else:
            if not game_over:
                p1.update(keys, p2)
                p2.update(keys, p1)

                # Hit detection
                abox1 = p1.get_attack_box()
                if abox1 and p2.alive and p1.attack_timer > 4:
                    if abox1.colliderect(p2.get_hitbox()):
                        dmg = 8 if p1.attack_type == "punch" else 12
                        ko = p2.take_damage(dmg, p1, is_blocked=p2.blocking)
                        if ko:
                            game_over = True
                            winner = "PLAYER 1"
                        p1.attack_timer = 0

                abox2 = p2.get_attack_box()
                if abox2 and p1.alive and p2.attack_timer > 4:
                    if abox2.colliderect(p1.get_hitbox()):
                        dmg = 8 if p2.attack_type == "punch" else 12
                        ko = p1.take_damage(dmg, p2, is_blocked=p1.blocking)
                        if ko:
                            game_over = True
                            winner = "PLAYER 2"
                        p2.attack_timer = 0

        # Draw
        draw_stage(screen)
        draw_health_bar(screen, 50, 30, 350, 28, p1.health, p1.max_health, RED)
        draw_health_bar(screen, WIDTH - 400, 30, 350, 28, p2.health, p2.max_health, BLUE)

        n1 = font_small.render("P1 - HANDS(J) FOOTS(K) JUMP(W) RUN(A/D)", True, WHITE)
        n2 = font_small.render("P2 - HANDS(U) FOOTS(I) JUMP(UP) RUN(ARROWS)", True, WHITE)
        screen.blit(n1, (50, 62))
        screen.blit(n2, (WIDTH - 400, 62))

        p1.draw(screen)
        p2.draw(screen)

        if start_timer > 0:
            txt = font_big.render(round_text, True, YELLOW)
            screen.blit(txt, (WIDTH//2 - txt.get_width()//2, HEIGHT//2 - 80))
        elif game_over:
            txt = font_big.render(f"{winner} WINS!", True, GREEN)
            screen.blit(txt, (WIDTH//2 - txt.get_width()//2, HEIGHT//2 - 80))
            sub = font_med.render("Press R to Restart  |  ESC to Quit", True, WHITE)
            screen.blit(sub, (WIDTH//2 - sub.get_width()//2, HEIGHT//2 - 20))
        else:
            tip = font_small.render("JUMP + KICK for air attacks  |  Block reduces damage", True, (180, 180, 180))
            screen.blit(tip, (WIDTH//2 - tip.get_width()//2, 100))

        sc = font_med.render(f"{p1.score}  -  {p2.score}", True, WHITE)
        screen.blit(sc, (WIDTH//2 - sc.get_width()//2, 25))

        pygame.display.flip()

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
















