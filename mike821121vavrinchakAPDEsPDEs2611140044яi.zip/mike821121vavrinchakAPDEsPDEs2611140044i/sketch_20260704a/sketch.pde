













int score = 0;
float ballX, ballY;
float ballSpeed = 5;
float radius = 40;
int lives = 3;
String gameState = "START"; 

void setup() {
  fullScreen();
  orientation(PORTRAIT);
  resetBall();
}

void draw() {
  background(20, 20, 30);
  
  if (gameState.equals("START")) {
    textAlign(CENTER);
    textSize(60);
    fill(255);
    text("TAP TO START", width/2, height/2);
  } else if (gameState.equals("PLAYING")) {
    updateGame();
  } else if (gameState.equals("GAMEOVER")) {
    textAlign(CENTER);
    textSize(60);
    fill(255, 0, 0);
    text("GAME OVER", width/2, height/2 - 50);
    textSize(40);
    text("Score: " + score, width/2, height/2 + 50);
    textSize(30);
    fill(200);
    text("Tap to Restart", width/2, height/2 + 150);
  }
}

void updateGame() {
  // Draw falling object
  fill(255, 100, 100);
  noStroke();
  ellipse(ballX, ballY, radius*2, radius*2);
  
  // Move the ball
  ballY += ballSpeed;
  
  // Check if ball hits the bottom
  if (ballY > height - radius) {
    lives--;
    if (lives <= 0) {
      gameState = "GAMEOVER";
    } else {
      resetBall();
    }
  }
  
  // HUD (Score and Lives)
  textSize(40);
  fill(255);
  textAlign(LEFT);
  text("Score: " + score, 40, 60);
  text("Lives: " + lives, 40, 110);
}

void resetBall() {
  ballX = random(radius, width - radius);
  ballY = 0;
  ballSpeed += 0.5; // Increase difficulty slightly
}

void mousePressed() {
  if (gameState.equals("START")) {
    gameState = "PLAYING";
  } else if (gameState.equals("GAMEOVER")) {
    score = 0;
    lives = 3;
    ballSpeed = 5;
    gameState = "PLAYING";
    resetBall();
  } else if (gameState.equals("PLAYING")) {
    // Check if touch hits the falling ball
    if (dist(mouseX, mouseY, ballX, ballY) < radius + 50) {
      score += 10;
      resetBall();
    }
  }
}













