














































float oo=222;float o=222;
float cc=277;float c=277;
float ee=111;float e=111;
float ooo=2;
float ccc=2;
float oooo=2;
float cccc=2;
float eeee=-2;
float eee=-2;
float t=0;float tt=0;float ttt=22;
int errorint=0;



void settings() {

} 



void setup() {

size(displayWidth, displayHeight, P2D) ; 

orientation(PORTRAIT) ;


  } 

void draw() {
if(9==9+0-0+errorint){




 noStroke() ;fill(0,0,0);
rect(0,0,displayWidth, displayHeight) ;





if(    ( abs(oo-cc) <
(displayWidth /60+displayHeight /60) ) 
&&
(abs(o-c) <
(displayWidth /60+displayHeight /60) ) ) 
{tt=tt+0.001;}

if(    ( abs(oo-ee) <
(displayWidth /60+displayHeight /60) ) 
&&
(abs(o-e) <
(displayWidth /60+displayHeight /60) ) ) 
{tt=tt-0.0011;}

if(    ( abs(ee-cc) <
(displayWidth /60+displayHeight /60) ) 
&&
(abs(e-c) <
(displayWidth /60+displayHeight /60) ) ) 
{tt=tt-0.0000111;}





oo=oo+(mouseX-displayWidth/2)/1 /
(displayWidth/1.1) ;
o=o+(mouseY-displayHeight/2)/1 /
(displayHeight/1.1) ;


oooo=oooo+(mouseX-displayWidth/2)/8 /
(displayWidth/1.1) ;
ooo=ooo+(mouseY-displayHeight/2)/8 /
(displayHeight/1.1) ;



eeee=eeee+random(0,1)-random(0,1);
eee=eee+random(0,1)-random(0,1);
cccc=cccc+random(0,1)-random(0,1);
ccc=ccc+random(0,1)-random(0,1);




float dw=float(displayWidth) ;
float dh=float(displayHeight) ;
if(oooo>(dw/60+dh/60) ) 
{oooo=oooo+0;oooo=(dw/160+dh/160); }
if(cccc>displayWidth/60+displayHeight/60)
{cccc=displayWidth/160+displayHeight/160;};
if(eeee>displayWidth/60+displayHeight/60)
{eeee=displayWidth/160+displayHeight/160;};
if(oooo<-displayWidth/60-displayHeight/60)
{oooo=-displayWidth/160-displayHeight/160;};
if(cccc<-displayWidth/60-displayHeight/60)
{cccc=-displayWidth/160-displayHeight/160;};
if(eeee<-displayWidth/60-displayHeight/60)
{eeee=-displayWidth/160-displayHeight/160;};

if(ooo>displayWidth/60+displayHeight/60)
{ooo=displayWidth/160+displayHeight/160;};
if(ccc>displayWidth/60+displayHeight/60)
{ccc=displayWidth/160+displayHeight/160;};
if(eee>displayWidth/60+displayHeight/60)
{eee=displayWidth/160+displayHeight/160;};
if(ooo<-displayWidth/60-displayHeight/60)
{ooo=-displayWidth/160-displayHeight/160;};
if(ccc<-displayWidth/60-displayHeight/60)
{ccc=-displayWidth/160-displayHeight/160;};
if(eee<-displayWidth/60-displayHeight/60)
{eee=-displayWidth/160-displayHeight/160;};









oo=oo+oooo;
o=o+ooo;
ee=ee+eeee;
e=e+eee;
cc=cc+cccc;
c=c+ccc;

if(oo<0){oo=0;oooo=-oooo;}
if(ee<0){ee=0;eeee=-eeee;}
if(cc<0){cc=0;cccc=-cccc;}

if(o<0){o=0;ooo=-ooo;}
if(e<0){e=0;eee=-eee;}
if(c<0){c=0;ccc=-ccc;}

if(oo>displayWidth ){
oo=displayWidth ;oooo=-oooo;}
if(ee>displayWidth ){
ee=displayWidth ;eeee=-eeee;}
if(cc>displayWidth ){
cc=displayWidth ;cccc=-cccc;}

if(o>displayHeight ){
o=displayHeight ;ooo=-ooo;}
if(e>displayHeight ){
e=displayHeight ;eee=-eee;}
if(c>displayHeight ){
c=displayHeight ;ccc=-ccc;}

































strokeWeight(3);
stroke(int(random(255)),int(random(255)),
int(random(255))); 
line(displayWidth /2,displayHeight /2,
mouseX,mouseY);noStroke() ;

fill(0,0,255);ellipse(cc,c,
displayWidth /60+displayHeight /60,
displayWidth /60+displayHeight /60) ;
fill(255,255,0);ellipse(ee,e,
displayWidth /60+displayHeight /60,
displayWidth /60+displayHeight /60) ;
fill(255,0,0);ellipse(oo,o,
displayWidth /60+displayHeight /60,
displayWidth /60+displayHeight /60) ;

ttt=ttt+4.1;if(ttt>displayHeight) {
ttt=22;}
fill(int(random(111,255)),
int(random(111,255)),
int(random(111,255))); textSize(33);
text(tt,displayWidth *0.4,ttt);


} 
}



























