
/*
APDE / Processing (Java) version of the Checkers sketch.
This is a complete, self-contained Processing sketch ready for APDE (Android Processing Development Environment). It runs on Android with touch input and also works in the desktop Processing IDE.
Features
8×8 American/English Checkers rules
Touch / mouse to select and move pieces (human = Black)
Simple minimax AI (White) with alpha-beta
Mandatory captures + multi-jumps
Kings
Clean board + piece rendering
// Checkers.pde  –  APDE / Processing sketch
// Human (Black) vs AI (White)

*/





final int BOARD_SIZE = 8;
final int EMPTY = 0;
final int BLACK_MAN = 1;
final int BLACK_KING = 2;
final int WHITE_MAN = -1;
final int WHITE_KING = -2;

int[][] board;
int cellSize;
int turn = 1;               // 1 = Black (human), -1 = White (AI)
boolean gameOver = false;
String statusMsg = "Your turn (Black)";
ArrayList<PVector> selectedPath = new ArrayList<PVector>();
ArrayList<ArrayList<PVector>> legalMoves = new ArrayList<ArrayList<PVector>>();
int aiDepth = 3;            // Increase carefully on mobile

void setup() {
  size(720, 820);           // APDE will scale; works on most phones
  orientation(PORTRAIT);
  cellSize = width / BOARD_SIZE;
  board = createInitialBoard();
  textAlign(CENTER, CENTER);
  textSize(22);
}

void draw() {
  background(40);
  drawBoard();
  drawPieces();
  drawStatus();
  
  if (!gameOver && turn == -1) {
    // AI turn
    statusMsg = "Engine thinking...";
    ArrayList<PVector> best = findBestMove(aiDepth);
    if (best != null) {
      applyMove(best);
      turn = 1;
      statusMsg = "Your turn (Black)";
      generateLegalMoves();
      if (legalMoves.isEmpty()) {
        gameOver = true;
        statusMsg = "You have no moves. White wins!";
      }
    } else {
      gameOver = true;
      statusMsg = "White has no moves. You win!";
    }
  }
}

void mousePressed() {
  if (gameOver || turn != 1) return;
  
  int c = mouseX / cellSize;
  int r = mouseY / cellSize;
  if (r < 0 || r >= BOARD_SIZE || c < 0 || c >= BOARD_SIZE) return;
  
  PVector clicked = new PVector(r, c);
  
  // First click or continuing a multi-jump selection
  if (selectedPath.isEmpty()) {
    // Start new selection if it is one of our pieces
    if (pieceColor(board[r][c]) == 1) {
      selectedPath.add(clicked);
      generateLegalMovesFrom(selectedPath);
    }
  } else {
    // Check if this click continues a legal path
    ArrayList<PVector> candidate = new ArrayList<PVector>(selectedPath);
    candidate.add(clicked);
    
    boolean isLegal = false;
    for (ArrayList<PVector> m : legalMoves) {
      if (pathsEqual(m, candidate)) {
        // Complete move
        applyMove(m);
        selectedPath.clear();
        turn = -1;
        statusMsg = "Engine thinking...";
        isLegal = true;
        break;
      }
    }
    
    if (!isLegal) {
      // Try to extend current path (for multi-jump preview) or restart
      boolean canExtend = false;
      for (ArrayList<PVector> m : legalMoves) {
        if (m.size() > selectedPath.size() && pathStartsWith(m, selectedPath) && 
            m.get(selectedPath.size()).equals(clicked)) {
          selectedPath.add(clicked);
          canExtend = true;
          break;
        }
      }
      if (!canExtend) {
        selectedPath.clear();
        if (pieceColor(board[r][c]) == 1) {
          selectedPath.add(clicked);
          generateLegalMovesFrom(selectedPath);
        }
      }
    }
  }
}

// -------------------- Board & Rules --------------------

int[][] createInitialBoard() {
  int[][] b = new int[BOARD_SIZE][BOARD_SIZE];
  for (int r = 0; r < 3; r++) {
    for (int c = 0; c < BOARD_SIZE; c++) {
      if ((r + c) % 2 == 1) b[r][c] = WHITE_MAN;
    }
  }
  for (int r = 5; r < 8; r++) {
    for (int c = 0; c < BOARD_SIZE; c++) {
      if ((r + c) % 2 == 1) b[r][c] = BLACK_MAN;
    }
  }
  return b;
}

int pieceColor(int p) {
  if (p > 0) return 1;
  if (p < 0) return -1;
  return 0;
}

boolean isKing(int p) {
  return abs(p) == 2;
}

PVector[] getDirections(int p) {
  if (isKing(p)) {
    return new PVector[]{ new PVector(-1,-1), new PVector(-1,1), new PVector(1,-1), new PVector(1,1) };
  }
  if (p > 0) { // Black
    return new PVector[]{ new PVector(-1,-1), new PVector(-1,1) };
  }
  return new PVector[]{ new PVector(1,-1), new PVector(1,1) };
}

void generateLegalMoves() {
  legalMoves.clear();
  ArrayList<ArrayList<PVector>> captures = new ArrayList<ArrayList<PVector>>();
  ArrayList<ArrayList<PVector>> quiet = new ArrayList<ArrayList<PVector>>();
  
  for (int r = 0; r < BOARD_SIZE; r++) {
    for (int c = 0; c < BOARD_SIZE; c++) {
      if (pieceColor(board[r][c]) != turn) continue;
      
      // Quiet moves
      for (PVector d : getDirections(board[r][c])) {
        int nr = r + (int)d.x;
        int nc = c + (int)d.y;
        if (inBounds(nr, nc) && board[nr][nc] == EMPTY && isDark(nr, nc)) {
          ArrayList<PVector> m = new ArrayList<PVector>();
          m.add(new PVector(r, c));
          m.add(new PVector(nr, nc));
          quiet.add(m);
        }
      }
      
      // Captures
      findJumps(r, c, new ArrayList<PVector>(), new HashSet<String>(), captures);
    }
  }
  
  if (!captures.isEmpty()) {
    legalMoves.addAll(captures);
  } else {
    legalMoves.addAll(quiet);
  }
}

void generateLegalMovesFrom(ArrayList<PVector> startPath) {
  legalMoves.clear();
  if (startPath.isEmpty()) return;
  
  int sr = (int)startPath.get(0).x;
  int sc = (int)startPath.get(0).y;
  int p = board[sr][sc];
  
  ArrayList<ArrayList<PVector>> captures = new ArrayList<ArrayList<PVector>>();
  findJumps(sr, sc, new ArrayList<PVector>(), new HashSet<String>(), captures);
  
  for (ArrayList<PVector> m : captures) {
    if (pathStartsWith(m, startPath)) {
      legalMoves.add(m);
    }
  }
  
  // Also allow simple moves if no captures from this piece
  if (legalMoves.isEmpty()) {
    for (PVector d : getDirections(p)) {
      int nr = sr + (int)d.x;
      int nc = sc + (int)d.y;
      if (inBounds(nr, nc) && board[nr][nc] == EMPTY && isDark(nr, nc)) {
        ArrayList<PVector> m = new ArrayList<PVector>();
        m.add(new PVector(sr, sc));
        m.add(new PVector(nr, nc));
        legalMoves.add(m);
      }
    }
  }
}

void findJumps(int r, int c, ArrayList<PVector> path, HashSet<String> visited, ArrayList<ArrayList<PVector>> results) {
  if (path.isEmpty()) {
    path.add(new PVector(r, c));
  }
  
  boolean found = false;
  int p = board[(int)path.get(0).x][(int)path.get(0).y]; // original piece type
  
  for (PVector d : getDirections(p)) {
    int jr = r + (int)d.x;
    int jc = c + (int)d.y;
    int lr = r + 2*(int)d.x;
    int lc = c + 2*(int)d.y;
    
    String key = jr + "," + jc;
    if (inBounds(jr, jc) && inBounds(lr, lc) &&
        pieceColor(board[jr][jc]) == -turn &&
        board[lr][lc] == EMPTY && isDark(lr, lc) &&
        !visited.contains(key)) {
      
      visited.add(key);
      ArrayList<PVector> newPath = new ArrayList<PVector>(path);
      newPath.add(new PVector(lr, lc));
      findJumps(lr, lc, newPath, visited, results);
      visited.remove(key);
      found = true;
    }
  }
  
  if (!found && path.size() > 1) {
    results.add(new ArrayList<PVector>(path));
  }
}

void applyMove(ArrayList<PVector> move) {
  int sr = (int)move.get(0).x;
  int sc = (int)move.get(0).y;
  int p = board[sr][sc];
  board[sr][sc] = EMPTY;
  
  for (int i = 1; i < move.size(); i++) {
    int r = (int)move.get(i).x;
    int c = (int)move.get(i).y;
    
    // Remove jumped piece
    if (abs(r - (int)move.get(i-1).x) == 2) {
      int jr = (r + (int)move.get(i-1).x) / 2;
      int jc = (c + (int)move.get(i-1).y) / 2;
      board[jr][jc] = EMPTY;
    }
    board[r][c] = p;
  }
  
  // Promotion
  int er = (int)move.get(move.size()-1).x;
  int ec = (int)move.get(move.size()-1).y;
  if (p == BLACK_MAN && er == 0) board[er][ec] = BLACK_KING;
  if (p == WHITE_MAN && er == 7) board[er][ec] = WHITE_KING;
}

// -------------------- AI --------------------

ArrayList<PVector> findBestMove(int depth) {
  int bestScore = Integer.MAX_VALUE; // White minimizes
  ArrayList<PVector> bestMove = null;
  
  generateLegalMoves(); // for current turn (White)
  for (ArrayList<PVector> m : legalMoves) {
    int[][] copy = copyBoard(board);
    applyMove(m);
    int score = minimax(depth - 1, Integer.MIN_VALUE, Integer.MAX_VALUE, true);
    board = copy;
    
    if (score < bestScore) {
      bestScore = score;
      bestMove = m;
    }
  }
  return bestMove;
}

int minimax(int depth, int alpha, int beta, boolean maximizing) {
  int color = maximizing ? 1 : -1;
  turn = color; // temporary for generateLegalMoves
  generateLegalMoves();
  ArrayList<ArrayList<PVector>> moves = new ArrayList<ArrayList<PVector>>(legalMoves);
  turn = -color; // restore
  
  if (depth == 0 || moves.isEmpty()) {
    return evaluate();
  }
  
  if (maximizing) {
    int maxEval = Integer.MIN_VALUE;
    for (ArrayList<PVector> m : moves) {
      int[][] copy = copyBoard(board);
      applyMove(m);
      int eval = minimax(depth - 1, alpha, beta, false);
      board = copy;
      maxEval = max(maxEval, eval);
      alpha = max(alpha, eval);
      if (beta <= alpha) break;
    }
    return maxEval;
  } else {
    int minEval = Integer.MAX_VALUE;
    for (ArrayList<PVector> m : moves) {
      int[][] copy = copyBoard(board);
      applyMove(m);
      int eval = minimax(depth - 1, alpha, beta, true);
      board = copy;
      minEval = min(minEval, eval);
      beta = min(beta, eval);
      if (beta <= alpha) break;
    }
    return minEval;
  }
}

int evaluate() {
  int score = 0;
  for (int r = 0; r < BOARD_SIZE; r++) {
    for (int c = 0; c < BOARD_SIZE; c++) {
      int p = board[r][c];
      if (p == BLACK_MAN) score += 100 + (7 - r);
      else if (p == BLACK_KING) score += 200;
      else if (p == WHITE_MAN) score -= 100 + r;
      else if (p == WHITE_KING) score -= 200;
    }
  }
  return score;
}

// -------------------- Helpers & Drawing --------------------

boolean inBounds(int r, int c) {
  return r >= 0 && r < BOARD_SIZE && c >= 0 && c < BOARD_SIZE;
}

boolean isDark(int r, int c) {
  return (r + c) % 2 == 1;
}

int[][] copyBoard(int[][] src) {
  int[][] dst = new int[BOARD_SIZE][BOARD_SIZE];
  for (int i = 0; i < BOARD_SIZE; i++) {
    arrayCopy(src[i], dst[i]);
  }
  return dst;
}

boolean pathsEqual(ArrayList<PVector> a, ArrayList<PVector> b) {
  if (a.size() != b.size()) return false;
  for (int i = 0; i < a.size(); i++) {
    if (!a.get(i).equals(b.get(i))) return false;
  }
  return true;
}

boolean pathStartsWith(ArrayList<PVector> full, ArrayList<PVector> prefix) {
  if (prefix.size() > full.size()) return false;
  for (int i = 0; i < prefix.size(); i++) {
    if (!full.get(i).equals(prefix.get(i))) return false;
  }
  return true;
}

void drawBoard() {
  for (int r = 0; r < BOARD_SIZE; r++) {
    for (int c = 0; c < BOARD_SIZE; c++) {
      if (isDark(r, c)) fill(139, 90, 43);
      else fill(245, 222, 179);
      rect(c * cellSize, r * cellSize, cellSize, cellSize);
      
      // Highlight selected
      if (!selectedPath.isEmpty()) {
        for (PVector p : selectedPath) {
          if ((int)p.x == r && (int)p.y == c) {
            fill(255, 255, 0, 120);
            rect(c * cellSize, r * cellSize, cellSize, cellSize);
          }
        }
      }
    }
  }
}

void drawPieces() {
  for (int r = 0; r < BOARD_SIZE; r++) {
    for (int c = 0; c < BOARD_SIZE; c++) {
      int p = board[r][c];
      if (p == 0) continue;
      
      float cx = c * cellSize + cellSize/2.0;
      float cy = r * cellSize + cellSize/2.0;
      float rad = cellSize * 0.38;
      
      if (p > 0) fill(30);          // Black
      else fill(240, 240, 240);     // White
      
      stroke(20);
      strokeWeight(2);
      ellipse(cx, cy, rad*2, rad*2);
      
      if (isKing(p)) {
        fill(p > 0 ? 200 : 50);
        noStroke();
        ellipse(cx, cy, rad*0.9, rad*0.9);
      }
    }
  }
  noStroke();
}

void drawStatus() {
  fill(30);
  rect(0, BOARD_SIZE * cellSize, width, height - BOARD_SIZE * cellSize);
  fill(255);
  text(statusMsg, width/2, BOARD_SIZE * cellSize + 40);
  text("Tap a black piece, then a destination", width/2, BOARD_SIZE * cellSize + 75);
}

/*
How to use in APDE
Open APDE.
Create a new sketch.
Paste the entire code above.
Run on your device (or use the desktop Processing IDE for testing).
Notes
Touch a black piece, then the destination square (or intermediate squares for multi-jumps).
AI depth is set to 3 for reasonable mobile performance. Raise to 4 only if your device is fast.
The code prioritizes captures (mandatory) and supports multi-jumps.
Promotion happens automatically when a man reaches the opposite back rank.
If you need adjustments (different board size, International draughts rules, stronger AI, undo button, sound, etc.), just say what you want changed.


+*/
































