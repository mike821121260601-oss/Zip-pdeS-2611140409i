
// APDE Chess – Human vs Engine
// + Castling + Promotion
// Depth rises in endgame, shows PV + arrows

int SQ = 0;
int BOARD_X, BOARD_Y;
int[] board = new int[64];          // 0=empty, 1-6 white, 7-12 black
int side = 0;                       // 0=white (human), 1=black (engine)
boolean thinking = false;
String pvLine = "";
String info = "Your move (White)";
int bestFrom = -1, bestTo = -1;
int[] pvFrom = new int[32];
int[] pvTo   = new int[32];
int pvLen = 0;

// Castling rights: bit 0=White-K, 1=White-Q, 2=Black-K, 3=Black-Q
int castle = 0b1111;

int nodes;
long startTime;

// Piece values
int[] val = {0, 100, 320, 330, 500, 900, 20000};

// Directions
int[] knightD = {-17, -15, -10, -6, 6, 10, 15, 17};
int[] kingD   = {-9, -8, -7, -1, 1, 7, 8, 9};
int[] bishopD = {-9, -7, 7, 9};
int[] rookD   = {-8, -1, 1, 8};

void setup() {
  size(displayWidth, displayHeight);
  orientation(PORTRAIT);
  textAlign(CENTER, CENTER);
  textSize(18);
  
  SQ = min(width, height - 180) / 8;
  BOARD_X = (width - SQ * 8) / 2;
  BOARD_Y = 40;
  
  startPos();
}

void startPos() {
  int[] start = {
    10, 8, 9, 11, 12, 9, 8, 10,
     7, 7, 7,  7,  7, 7, 7,  7,
     0, 0, 0,  0,  0, 0, 0,  0,
     0, 0, 0,  0,  0, 0, 0,  0,
     0, 0, 0,  0,  0, 0, 0,  0,
     0, 0, 0,  0,  0, 0, 0,  0,
     1, 1, 1,  1,  1, 1, 1,  1,
     4, 2, 3,  5,  6, 3, 2,  4
  };
  for (int i = 0; i < 64; i++) board[i] = start[i];
  side = 0;
  castle = 0b1111;          // KQkq
  thinking = false;
  info = "Your move (White)";
  pvLine = "";
  bestFrom = bestTo = -1;
  pvLen = 0;
  selected = -1;
}

void draw() {
  background(30, 30, 40);
  drawBoard();
  drawPieces();
  drawArrows();
  drawInfo();
  
  // highlight selected square
  if (selected >= 0) {
    int f = selected % 8, r = selected / 8;
    noFill();
    stroke(255, 255, 0);
    strokeWeight(4);
    rect(BOARD_X + f * SQ, BOARD_Y + r * SQ, SQ, SQ);
  }
}

void drawBoard() {
  for (int r = 0; r < 8; r++) {
    for (int f = 0; f < 8; f++) {
      boolean light = (r + f) % 2 == 0;
      fill(light ? color(240, 217, 181) : color(181, 136, 99));
      noStroke();
      rect(BOARD_X + f * SQ, BOARD_Y + r * SQ, SQ, SQ);
    }
  }
  fill(200);
  textSize(14);
  for (int i = 0; i < 8; i++) {
    text("abcdefgh".charAt(i), BOARD_X + i * SQ + SQ / 2, BOARD_Y + 8 * SQ + 14);
    text(8 - i, BOARD_X - 14, BOARD_Y + i * SQ + SQ / 2);
  }
}

void drawPieces() {
  textSize(SQ * 0.72);
  for (int i = 0; i < 64; i++) {
    if (board[i] == 0) continue;
    int f = i % 8, r = i / 8;
    float x = BOARD_X + f * SQ + SQ / 2;
    float y = BOARD_Y + r * SQ + SQ / 2 + 2;
    
    String s = "";
    switch (board[i]) {
      case 1:  s = "♙"; break; case 2: 
 s = "♘"; break; case 3:  s = "♗"; break;
      case 4:  s = "♖"; break; case 5:
  s = "♕"; break; case 6:  s = "♔"; break;
      case 7:  s = "♟"; break; case 8:
  s = "♞"; break; case 9:  s = "♝"; break;
      case 10: s = "♜"; break; case 11:
 s = "♛"; break; case 12: s = "♚"; break;
    }
    fill(board[i] <= 6 ? 255 : 20);
    text(s, x, y);
  }
}

void drawArrows() {
  if (bestFrom < 0) return;
  strokeWeight(5);
  stroke(0, 180, 255, 220);
  drawArrow(bestFrom, bestTo);
  
  strokeWeight(3);
  stroke(0, 255, 120, 170);
  for (int i = 0; i < min(pvLen, 3); i++) {
    drawArrow(pvFrom[i], pvTo[i]);
  }
}

void drawArrow(int from, int to) {
  int ff = from % 8, fr = from / 8;
  int tf = to % 8,   tr = to / 8;
  float x1 = BOARD_X + ff * SQ + SQ / 2;
  float y1 = BOARD_Y + fr * SQ + SQ / 2;
  float x2 = BOARD_X + tf * SQ + SQ / 2;
  float y2 = BOARD_Y + tr * SQ + SQ / 2;
  
  line(x1, y1, x2, y2);
  float a = atan2(y2 - y1, x2 - x1);
  line(x2, y2, x2 - 14 * cos(a - 0.45), y2 - 14 * sin(a - 0.45));
  line(x2, y2, x2 - 14 * cos(a + 0.45), y2 - 14 * sin(a + 0.45));
}

void drawInfo() {
  fill(35, 35, 50);
  noStroke();
  rect(0, BOARD_Y + 8 * SQ + 28, width, height - (BOARD_Y + 8 * SQ + 28));
  
  fill(255);
  textSize(17);
  textAlign(LEFT, TOP);
  text(info, 16, BOARD_Y + 8 * SQ + 42);
  
  textSize(14);
  fill(160, 255, 170);
  text("PV: " + pvLine, 16, BOARD_Y + 8 * SQ + 72);
  
  fill(180);
  text("Castling & Promotion enabled  |  Depth rises when few pieces left", 16, BOARD_Y + 8 * SQ + 100);
  textAlign(CENTER, CENTER);
}

// ---------- Human move ----------
int selected = -1;

void mousePressed() {
  if (thinking || side != 0) return;
  
  int f = (mouseX - BOARD_X) / SQ;
  int r = (mouseY - BOARD_Y) / SQ;
  if (f < 0 || f > 7 || r < 0 || r > 7) return;
  int sq = r * 8 + f;
  
  if (selected == -1) {
    if (board[sq] >= 1 && board[sq] <= 6) selected = sq;
  } else {
    if (sq == selected) {
      selected = -1;
      return;
    }
    if (isLegal(selected, sq, 0)) {
      makeMove(selected, sq, 0);
      selected = -1;
      side = 1;
      info = "Engine thinking...";
      thinking = true;
    } else {
      if (board[sq] >= 1 && board[sq] <= 6) selected = sq;
      else selected = -1;
    }
  }
}

void mouseReleased() {
  if (thinking && side == 1) {
    int pieces = countPieces();
    int maxDepth = (pieces <= 6) ? 13 : (pieces <= 10) ? 10 : 6;
    
    int[] move = search(maxDepth);
    if (move[0] >= 0) {
      makeMove(move[0], move[1], 1);
      bestFrom = move[0];
      bestTo   = move[1];
    }
    side = 0;
    thinking = false;
    info = "Your move (White)  – depth " + maxDepth;
  }
}

// ---------- Make move (handles castling + promotion) ----------
void makeMove(int from, int to, int s) {
  int piece = board[from];
  
  // Castling
  if (piece == 6 || piece == 12) {          // king
    if (abs((to % 8) - (from % 8)) == 2) {
      // kingside
      if (to % 8 == 6) {
        board[from + 1] = board[from + 3];  // rook moves
        board[from + 3] = 0;
      }
      // queenside
      else if (to % 8 == 2) {
        board[from - 1] = board[from - 4];
        board[from - 4] = 0;
      }
    }
    // remove castling rights for this side
    if (s == 0) castle &= \~0b0011;
    else        castle &= \~0b1100;
  }
  
  // Rook moved → lose rights
  if (piece == 4) { // white rook
    if (from == 63) castle &= \~0b0001;
    if (from == 56) castle &= \~0b0010;
  }
  if (piece == 10) { // black rook
    if (from == 7)  castle &= \~0b0100;
    if (from == 0)  castle &= \~0b1000;
  }
  
  // Capture rook on corner also removes rights
  if (to == 63) castle &= \~0b0001;
  if (to == 56) castle &= \~0b0010;
  if (to == 7)  castle &= \~0b0100;
  if (to == 0)  castle &= \~0b1000;
  
  // Normal move
  board[to] = board[from];
  board[from] = 0;
  
  // Promotion (always to queen)
  if (piece == 1 && to / 8 == 0) board[to] = 5;   // white pawn → queen
  if (piece == 7 && to / 8 == 7) board[to] = 11;  // black pawn → queen
}

// ---------- Engine ----------
int[] search(int depth) {
  nodes = 0;
  int bestScore = -999999;
  int bf = -1, bt = -1;
  pvLen = 0;
  
  ArrayList<int[]> moves = genMoves(1);
  for (int[] m : moves) {
    // save state
    int[] savedBoard = board.clone();
    int savedCastle = castle;
    
    makeMove(m[0], m[1], 1);
    int score = -alphaBeta(depth - 1, -999999, 999999, 0);
    
    // restore
    board = savedBoard;
    castle = savedCastle;
    
    if (score > bestScore) {
      bestScore = score;
      bf = m[0];
      bt = m[1];
    }
  }
  
  pvLine = sqName(bf) + sqName(bt) + "  (" + bestScore + ")";
  pvFrom[0] = bf;
  pvTo[0] = bt;
  pvLen = 1;
  
  return new int[]{bf, bt};
}

int alphaBeta(int depth, int alpha, int beta, int s) {
  nodes++;
  if (depth <= 0) return evaluate(s);
  
  ArrayList<int[]> moves = genMoves(s);
  if (moves.isEmpty()) return evaluate(s);
  
  for (int[] m : moves) {
    int[] savedBoard = board.clone();
    int savedCastle = castle;
    
    makeMove(m[0], m[1], s);
    int score = -alphaBeta(depth - 1, -beta, -alpha, 1 - s);
    
    board = savedBoard;
    castle = savedCastle;
    
    if (score >= beta) return beta;
    if (score > alpha) alpha = score;
  }
  return alpha;
}

int evaluate(int s) {
  int score = 0;
  for (int i = 0; i < 64; i++) {
    int p = board[i];
    if (p == 0) continue;
    int v = val[p > 6 ? p - 6 : p];
    if (p <= 6) score += v;
    else score -= v;
  }
  return (s == 0) ? score : -score;
}

int countPieces() {
  int c = 0;
  for (int i = 0; i < 64; i++) if (board[i] != 0) c++;
  return c;
}

// ---------- Move generation (with castling) ----------
ArrayList<int[]> genMoves(int s) {
  ArrayList<int[]> list = new ArrayList<int[]>();
  int minP = (s == 0) ? 1 : 7;
  int maxP = (s == 0) ? 6 : 12;
  
  for (int from = 0; from < 64; from++) {
    int p = board[from];
    if (p < minP || p > maxP) continue;
    int type = (p > 6) ? p - 6 : p;
    
    // PAWN
    if (type == 1) {
      int dir = (s == 0) ? -8 : 8;
      int to = from + dir;
      if (to >= 0 && to < 64 && board[to] == 0) {
        list.add(new int[]{from, to});
        // double push
        if ((s == 0 && from / 8 == 6) || (s == 1 && from / 8 == 1)) {
          int to2 = from + dir * 2;
          if (board[to2] == 0) list.add(new int[]{from, to2});
        }
      }
      // captures
      for (int d : new int[]{dir - 1, dir + 1}) {
        to = from + d;
        if (to < 0 || to > 63) continue;
        if (abs((to % 8) - (from % 8)) != 1) continue;
        int t = board[to];
        if (t != 0 && ((s == 0 && t > 6) || (s == 1 && t <= 6))) {
          list.add(new int[]{from, to});
        }
      }
    }
    // KNIGHT
    else if (type == 2) {
      for (int d : knightD) {
        int to = from + d;
        if (to < 0 || to > 63) continue;
        if (abs((to % 8) - (from % 8)) > 2) continue;
        int t = board[to];
        if (t == 0 || ((s == 0 && t > 6) || (s == 1 && t <= 6))) {
          list.add(new int[]{from, to});
        }
      }
    }
    // KING + CASTLING
    else if (type == 6) {
      for (int d : kingD) {
        int to = from + d;
        if (to < 0 || to > 63) continue;
        if (abs((to % 8) - (from % 8)) > 1) continue;
        int t = board[to];
        if (t == 0 || ((s == 0 && t > 6) || (s == 1 && t <= 6))) {
          list.add(new int[]{from, to});
        }
      }
      // Castling
      if (s == 0 && from == 60) { // white king e1
        // kingside
        if ((castle & 1) != 0 && board[61] == 0 && board[62] == 0 && board[63] == 4) {
          list.add(new int[]{60, 62});
        }
        // queenside
        if ((castle & 2) != 0 && board[59] == 0 && board[58] == 0 && board[57] == 0 && board[56] == 4) {
          list.add(new int[]{60, 58});
        }
      }
      if (s == 1 && from == 4) { // black king e8
        if ((castle & 4) != 0 && board[5] == 0 && board[6] == 0 && board[7] == 10) {
          list.add(new int[]{4, 6});
        }
        if ((castle & 8) != 0 && board[3] == 0 && board[2] == 0 && board[1] == 0 && board[0] == 10) {
          list.add(new int[]{4, 2});
        }
      }
    }
    // SLIDING (bishop / rook / queen)
    else {
      int[] dirs = (type == 3) ? bishopD : (type == 4) ? rookD : 
                   new int[]{-9, -8, -7, -1, 1, 7, 8, 9};
      for (int d : dirs) {
        int to = from;
        while (true) {
          int prevFile = to % 8;
          to += d;
          if (to < 0 || to > 63) break;
          int file = to % 8;
          if (abs(file - prevFile) > 1 && (abs(d) == 1 || abs(d) == 7 || abs(d) == 9)) break;
          
          int t = board[to];
          if (t == 0) {
            list.add(new int[]{from, to});
          } else {
            if ((s == 0 && t > 6) || (s == 1 && t <= 6)) list.add(new int[]{from, to});
            break;
          }
        }
      }
    }
  }
  return list;
}

boolean isLegal(int from, int to, int s) {
  ArrayList<int[]> moves = genMoves(s);
  for (int[] m : moves) {
    if (m[0] == from && m[1] == to) return true;
  }
  return false;
}

String sqName(int sq) {
  if (sq < 0) return "??";
  return "" + "abcdefgh".charAt(sq % 8) + (8 - sq / 8);
}

























