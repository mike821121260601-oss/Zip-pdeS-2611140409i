


//CCCCHHHHEEEESSSSSSSS//


/*

Yes. In APDE/Processing, you can define each chess piece from 3 rectangles, using your rr() idea. Here is a complete board with red and blue pieces, with no chess text.
// APDE / Processing
// Chess board + red/blue chess pieces
// Every piece is built from 3 rectangles

*/




void setup() {
  fullScreen();
  noStroke();
  rectMode(CENTER);
}

void draw() {
  background(30);

  float s = min(width, height) / 8.0;

  // Chess board
  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {
      if ((x + y) % 2 == 0)
        fill(235, 210, 170);
      else
        fill(90, 55, 35);

      rect(
        x*s + s/2,
        y*s + s/2,
        s,
        s
      );
    }
  }

  // BLUE pieces
  for (int x = 0; x < 8; x++)
    pawn(x*s+s/2, s*1.5, s, color(30,80,255));

  rook (s*.5, s*.5, s, color(30,80,255));
  knight(s*1.5, s*.5, s, color(30,80,255));
  bishop(s*2.5, s*.5, s, color(30,80,255));
  queen (s*3.5, s*.5, s, color(30,80,255));
  king  (s*4.5, s*.5, s, color(30,80,255));
  bishop(s*5.5, s*.5, s, color(30,80,255));
  knight(s*6.5, s*.5, s, color(30,80,255));
  rook  (s*7.5, s*.5, s, color(30,80,255));

  // RED pieces
  for (int x = 0; x < 8; x++)
    pawn(x*s+s/2, s*6.5, s, color(255,40,40));

  rook (s*.5, s*7.5, s, color(255,40,40));
  knight(s*1.5, s*7.5, s, color(255,40,40));
  bishop(s*2.5, s*7.5, s, color(255,40,40));
  queen (s*3.5, s*7.5, s, color(255,40,40));
  king  (s*4.5, s*7.5, s, color(255,40,40));
  bishop(s*5.5, s*7.5, s, color(255,40,40));
  knight(s*6.5, s*7.5, s, color(255,40,40));
  rook  (s*7.5, s*7.5, s, color(255,40,40));
}


// --------------------------------------------------
// YOUR 3-RECTANGLE IDEA
// --------------------------------------------------

void rr(float cx, float cy,
        float x1, float y1,
        float x2, float y2,
        float x3, float y3,
        float x4, float y4,
        color c) {

  fill(c);

  // rectangle 1
  rect(cx + x1, cy + y1,
       abs(x2-x1), abs(y2-y1));

  // rectangle 2
  rect(cx + x3, cy + y3,
       abs(x4-x3), abs(y4-y3));

  // rectangle 3
  rect(cx, cy + (y1+y4)/2,
       abs(x4-x1), abs(y4-y1)/3);
}


// --------------------------------------------------
// PAWN
// --------------------------------------------------

void pawn(float x, float y, float s, color c) {

  rr(x, y,
     -s*.25, s*.05,
      s*.25, s*.22,
     -s*.18,-s*.20,
      s*.18,-s*.02,
      c);

  fill(c);
  ellipse(x, y-s*.25, s*.30, s*.30);
}


// --------------------------------------------------
// ROOK
// --------------------------------------------------

void rook(float x, float y, float s, color c) {

  rr(x, y,
     -s*.30, s*.20,
      s*.30, s*.35,
     -s*.22,-s*.05,
      s*.22, s*.25,
      c);

  fill(c);

  // top
  rect(x, y-s*.25, s*.42, s*.22);

  // battlements
  rect(x-s*.18, y-s*.38, s*.12, s*.20);
  rect(x,       y-s*.38, s*.12, s*.20);
  rect(x+s*.18, y-s*.38, s*.12, s*.20);
}


// --------------------------------------------------
// KNIGHT
// --------------------------------------------------

void knight(float x, float y, float s, color c) {

  rr(x, y,
     -s*.28, s*.28,
      s*.28, s*.38,
     -s*.20,-s*.10,
      s*.18, s*.30,
      c);

  fill(c);

  // head/body made with rectangles
  rect(x, y-s*.22, s*.32, s*.35);
  rect(x+s*.10, y-s*.38, s*.20, s*.25);

  // nose
  rect(x+s*.23, y-s*.38, s*.20, s*.12);
}


// --------------------------------------------------
// BISHOP
// --------------------------------------------------

void bishop(float x, float y, float s, color c) {

  rr(x, y,
     -s*.28, s*.22,
      s*.28, s*.36,
     -s*.18,-s*.05,
      s*.18, s*.25,
      c);

  fill(c);

  // head
  ellipse(x, y-s*.27, s*.34, s*.40);

  // diagonal cut
  stroke(255);
  strokeWeight(max(2, s*.035));
  line(
    x-s*.10, y-s*.38,
    x+s*.10, y-s*.16
  );
  noStroke();
}


// --------------------------------------------------
// QUEEN
// --------------------------------------------------

void queen(float x, float y, float s, color c) {

  rr(x, y,
     -s*.30, s*.20,
      s*.30, s*.38,
     -s*.22,-s*.08,
      s*.22, s*.25,
      c);

  fill(c);

  // crown
  rect(x, y-s*.28, s*.38, s*.22);

  ellipse(x-s*.17, y-s*.42, s*.18, s*.18);
  ellipse(x,       y-s*.47, s*.18, s*.18);
  ellipse(x+s*.17, y-s*.42, s*.18, s*.18);
}


// --------------------------------------------------
// KING
// --------------------------------------------------

void king(float x, float y, float s, color c) {

  rr(x, y,
     -s*.30, s*.20,
      s*.30, s*.38,
     -s*.22,-s*.08,
      s*.22, s*.25,
      c);

  fill(c);

  // king head
  rect(x, y-s*.30, s*.35, s*.30);

  // cross
  rect(x, y-s*.50, s*.12, s*.30);
  rect(x, y-s*.50, s*.30, s*.10);
}
/*



















This uses the same basic idea as your rr(...): three rectangular components form the body, then small extra rectangles/circles give each piece its shape. No chess letters or text are drawn.


*/









































