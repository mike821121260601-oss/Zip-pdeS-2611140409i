
// APDE GAME - TANKS 2D BATTLE
// Simple top-down tank battle for Processing / APDE

Tank player;
ArrayList<Tank> enemies;
ArrayList<Bullet> bullets;
ArrayList<Explosion> explosions;

int score = 0;
boolean gameOver = false;
boolean gameStarted = false;

// Touch controls
PVector joyCenter;
float joyRadius = 90;
PVector joyPos;
boolean joyActive = false;
boolean firePressed = false;
float fireBtnX, fireBtnY, fireBtnR = 70;

void setup() {
  fullScreen();



  orientation(LANDSCAPE);

          orientation(PORTRAIT);    















  
  player = new Tank(width/2, height/2, color(50, 200, 50), true);
  enemies = new ArrayList<Tank>();
  bullets = new ArrayList<Bullet>();
  explosions = new ArrayList<Explosion>();
  
  // Spawn some enemies
  for (int i = 0; i < 5; i++) {
    spawnEnemy();
  }
  
  joyCenter = new PVector(150, height - 150);
  joyPos = joyCenter.copy();
  fireBtnX = width - 130;
  fireBtnY = height - 150;
  
  textAlign(CENTER, CENTER);
}

void draw() {


firePressed = true;
    player.shoot();







  background(30, 40, 30);
  
  // Grid background
  stroke(40, 55, 40);
  strokeWeight(1);
  for (int x = 0; x < width; x += 40) line(x, 0, x, height);
  for (int y = 0; y < height; y += 40) line(0, y, width, y);
  
  if (!gameStarted) {
    fill(255);
    textSize(48);
    text("TANKS 2D BATTLE", width/2, height/2 - 80);
    textSize(28);
    text("Tap screen or press any key to start", width/2, height/2);
    textSize(22);
    text("WASD / Arrows + Space  |  Touch stick + Fire button", width/2, height/2 + 50);
    return;
  }
  
  if (gameOver) {
    fill(255, 80, 80);
    textSize(56);
    text("GAME OVER", width/2, height/2 - 40);
    textSize(32);
    fill(255);
    text("Score: " + score, width/2, height/2 + 20);
    textSize(24);
    text("Tap to restart", width/2, height/2 + 70);
    return;
  }
  
  // Update & draw player
  player.update();
  player.display();
  
  // Enemies
  for (int i = enemies.size()-1; i >= 0; i--) {
    Tank e = enemies.get(i);
    e.updateAI(player);
    e.display();
    
    if (e.health <= 0) {
      explosions.add(new Explosion(e.pos.x, e.pos.y));
      enemies.remove(i);
      score += 100;
      spawnEnemy();
    }
  }
  
  // Bullets
  for (int i = bullets.size()-1; i >= 0; i--) {
    Bullet b = bullets.get(i);
    b.update();
    b.display();
    
    // Hit player
    if (!b.fromPlayer && dist(b.pos.x, b.pos.y, player.pos.x, player.pos.y) < 28) {
      player.health -= 15;
      bullets.remove(i);
      continue;
    }
    
    // Hit enemies
    if (b.fromPlayer) {
      for (int j = enemies.size()-1; j >= 0; j--) {
        Tank e = enemies.get(j);
        if (dist(b.pos.x, b.pos.y, e.pos.x, e.pos.y) < 28) {
          e.health -= 25;
          bullets.remove(i);
          break;
        }
      }
    }
    
    if (b.pos.x < 0 || b.pos.x > width || b.pos.y < 0 || b.pos.y > height) {
      bullets.remove(i);
    }
  }
  
  // Explosions
  for (int i = explosions.size()-1; i >= 0; i--) {
    Explosion ex = explosions.get(i);
    ex.update();
    ex.display();
    if (ex.life <= 0) explosions.remove(i);
  }
  
  // UI
  fill(255);
  textSize(28);
  text("Score: " + score, width/2, 40);
  
  // Player health bar
  fill(0, 150);
  rect(20, 20, 200, 24);
  fill(50, 220, 50);
  rect(20, 20, map(player.health, 0, 100, 0, 200), 24);
  fill(255);
  textSize(18);
  text("HP", 120, 32);
  
  if (player.health <= 0) {
    gameOver = true;
    explosions.add(new Explosion(player.pos.x, player.pos.y));
  }
  
  // Draw virtual controls
  drawJoystick();
  drawFireButton();
}

void spawnEnemy() {
  float x, y;
  do {
    x = random(80, width-80);
    y = random(80, height-80);
  } while (dist(x, y, player.pos.x, player.pos.y) < 250);
  
  enemies.add(new Tank(x, y, color(220, 60, 60), false));
}

void drawJoystick() {
  // Base
  noFill();
  stroke(255, 80);
  strokeWeight(4);
  ellipse(joyCenter.x, joyCenter.y, joyRadius*2, joyRadius*2);
  
  // Stick
  fill(255, 120);
  noStroke();
  ellipse(joyPos.x, joyPos.y, 55, 55);
}

void drawFireButton() {
  if (firePressed) fill(255, 100, 100, 180);
  else fill(255, 60, 60, 140);
  noStroke();
  ellipse(fireBtnX, fireBtnY, fireBtnR*2, fireBtnR*2);
  fill(255);
  textSize(22);
  text("FIRE", fireBtnX, fireBtnY);
}

// ===== INPUT =====
void keyPressed() {
  if (!gameStarted) { gameStarted = true; return; }
  if (gameOver) { restartGame(); return; }
  
  if (key == ' ' || key == 'z' || key == 'Z') {
    player.shoot();
  }
  player.handleKey(key, true);
}

void keyReleased() {
  player.handleKey(key, false);
}

void mousePressed() {
  if (!gameStarted) { gameStarted = true; return; }
  if (gameOver) { restartGame(); return; }
  
  // Joystick
  if (dist(mouseX, mouseY, joyCenter.x, joyCenter.y) < joyRadius + 30) {
    joyActive = true;
    joyPos.set(mouseX, mouseY);
  }
  
  // Fire button
  if (dist(mouseX, mouseY, fireBtnX, fireBtnY) < fireBtnR + 10) {
    firePressed = true;
    player.shoot();
  }
}

void mouseDragged() {
  if (joyActive) {
    PVector dir = new PVector(mouseX - joyCenter.x, mouseY - joyCenter.y);
    if (dir.mag() > joyRadius) dir.setMag(joyRadius);
    joyPos = PVector.add(joyCenter, dir);
    
    // Move player
    player.vel.set(dir.x * 0.08, dir.y * 0.08);
    if (dir.mag() > 10) {
      player.angle = atan2(dir.y, dir.x);
    }
  }
}

void mouseReleased() {
  joyActive = false;
  joyPos = joyCenter.copy();
  player.vel.set(0, 0);
  firePressed = false;
}

void restartGame() {
  player = new Tank(width/2, height/2, color(50, 200, 50), true);
  enemies.clear();
  bullets.clear();
  explosions.clear();
  score = 0;
  gameOver = false;
  for (int i = 0; i < 5; i++) spawnEnemy();
}

// ===== CLASSES =====
class Tank {
  PVector pos, vel;
  float angle = 0;
  color col;
  boolean isPlayer;
  float health = 100;
  int shootCooldown = 0;
  boolean up, down, left, right;
  
  Tank(float x, float y, color c, boolean p) {
    pos = new PVector(x, y);
    vel = new PVector(0, 0);
    col = c;
    isPlayer = p;
  }
  
  void update() {
    if (isPlayer) {
      // Keyboard movement
      if (up)    vel.y = -3.5;
      if (down)  vel.y =  3.5;
      if (left)  vel.x = -3.5;
      if (right) vel.x =  3.5;
      
      if (!up && !down) vel.y *= 0.8;
      if (!left && !right) vel.x *= 0.8;
      
      if (vel.mag() > 0.5) {
        angle = atan2(vel.y, vel.x);
      }
    }
    
    pos.add(vel);
    pos.x = constrain(pos.x, 30, width-30);
    pos.y = constrain(pos.y, 30, height-30);
    
    if (shootCooldown > 0) shootCooldown--;
  }
  
  void updateAI(Tank target) {
    // Simple chase + shoot AI
    PVector dir = PVector.sub(target.pos, pos);
    float d = dir.mag();
    
    if (d > 180) {
      dir.setMag(1.8);
      vel = dir;
    } else {
      vel.mult(0.9);
    }
    
    angle = atan2(dir.y, dir.x);
    
    if (d < 350 && shootCooldown <= 0 && random(1) < 0.03) {
      shoot();
    }
    
    update();
  }
  
  void shoot() {
    if (shootCooldown > 0) return;
    float bx = pos.x + cos(angle) * 35;
    float by = pos.y + sin(angle) * 35;
    bullets.add(new Bullet(bx, by, angle, isPlayer));
    shootCooldown = isPlayer ? 18 : 45;
  }
  
  void display() {
    pushMatrix();
    translate(pos.x, pos.y);
    rotate(angle);
    
    // Body
    fill(col);
    stroke(0);
    strokeWeight(2);
    rectMode(CENTER);
    rect(0, 0, 48, 32, 4);
    
    // Tracks
    fill(40);
    rect(-18, -18, 12, 36, 2);
    rect(-18,  18, 12, 36, 2);
    
    // Turret
    fill(red(col)*0.8, green(col)*0.8, blue(col)*0.8);
    ellipse(0, 0, 26, 26);
    
    // Barrel
    strokeWeight(6);
    stroke(30);
    line(0, 0, 32, 0);
    
    popMatrix();
    
    // Health bar above tank
    if (!isPlayer || health < 100) {
      fill(0, 150);
      rect(pos.x-25, pos.y-40, 50, 8);
      fill(isPlayer ? color(50,220,50) : color(220,60,60));
      rect(pos.x-25, pos.y-40, map(health, 0, 100, 0, 50), 8);
    }
  }
  
  void handleKey(char k, boolean pressed) {
    if (k == 'w' || k == 'W' || k == CODED && keyCode == UP)    up = pressed;
    if (k == 's' || k == 'S' || k == CODED && keyCode == DOWN)  down = pressed;
    if (k == 'a' || k == 'A' || k == CODED && keyCode == LEFT)  left = pressed;
    if (k == 'd' || k == 'D' || k == CODED && keyCode == RIGHT) right = pressed;
  }
}

class Bullet {
  PVector pos, vel;
  boolean fromPlayer;
  
  Bullet(float x, float y, float a, boolean fp) {
    pos = new PVector(x, y);
    vel = PVector.fromAngle(a).mult(9);
    fromPlayer = fp;
  }
  
  void update() {
    pos.add(vel);
  }
  
  void display() {
    fill(fromPlayer ? color(255, 255, 100) : color(255, 120, 50));
    noStroke();
    ellipse(pos.x, pos.y, 10, 10);
  }
}

class Explosion {
  float x, y;
  float life = 20;
  float maxLife = 20;
  
  Explosion(float x, float y) {
    this.x = x;
    this.y = y;
  }
  
  void update() {
    life--;
  }
  
  void display() {
    float s = map(life, 0, maxLife, 60, 10);
    fill(255, 150, 50, map(life, 0, maxLife, 0, 255));
    noStroke();
    ellipse(x, y, s, s);
    fill(255, 80, 0, map(life, 0, maxLife, 0, 200));
    ellipse(x, y, s*0.6, s*0.6);
  }
}
































