











import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.content.SharedPreferences;

Activity activity;
SharedPreferences prefs;

void setup() {
  fullScreen();

  activity = this.getActivity();

  prefs = activity.getSharedPreferences(
    "SCREEN_SETTINGS", Activity.MODE_PRIVATE
  );

  // RESTORE LAST CHOICE
  int saved = prefs.getInt(
    "orientation",
    ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
  );

  activity.setRequestedOrientation(saved);

  textAlign(CENTER, CENTER);
  textSize(30);
}

void draw() {
  background(25);

  fill(60);
  rect(10, 10, width-20, height-20, 20);

  drawKey(20, 30, width-40, height/4-40, "PORTRAIT");
  drawKey(20, height/4+20, width-40, height/4-40, "BACK PORTRAIT");
  drawKey(20, height/2+10, width-40, height/4-40, "LANDSCAPE");
  drawKey(20, height*3/4, width-40, height/4-40, "BACK LANDSCAPE");
}

void drawKey(float x, float y, float w, float h, String s) {
  fill(80);
  rect(x, y, w, h, 20);

  fill(255);
  text(s, x+w/2, y+h/2);
}

void mousePressed() {

  int orientation = -1;

  if (mouseY > 30 &&
      mouseY < height/4-10) {

    orientation =
      ActivityInfo.SCREEN_ORIENTATION_PORTRAIT;
  }

  else if (mouseY > height/4+20 &&
           mouseY < height/2-20) {

    orientation =
      ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT;
  }

  else if (mouseY > height/2+10 &&
           mouseY < height*3/4-20) {

    orientation =
      ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE;
  }

  else if (mouseY > height*3/4 &&
           mouseY < height) {

    orientation =
      ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE;
  }

  if (orientation != -1) {

    // SAVE CHOICE
    prefs.edit()
      .putInt("orientation", orientation)
      .apply();

    // APPLY CHOICE
    activity.setRequestedOrientation(orientation);
  }
}










