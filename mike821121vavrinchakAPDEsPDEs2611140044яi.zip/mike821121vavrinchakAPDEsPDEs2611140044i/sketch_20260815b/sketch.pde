


// APDE GO GAME
// BOARD 25 x 25
// RED = HUMAN
// BLUE = COMPUTER
// Tap intersection to play

final int N = 25;

int[][] board = new int[N][N];
// 0 empty, 1 human, 2 computer

float bx, by, cell;
boolean gameOver = false;
boolean humanTurn = true;

///void setup() {
 // fullScreen(P2D);
 /// orientation(PORTRAIT);

 // surface.setTitle("GO 25 x 25");

 /// bx = width * 0.05;
  /// by = width * 0.12;
  /// cell = (width * 0.90) / (N - 1);

///  noStroke();
 /// textAlign(CENTER, CENTER);
///}// APDE GO GAME
// BOARD 25 x 25
// RED = HUMAN
// BLUE = COMPUTER
// Tap intersection to play

/// final int N = 25;

/// int[][] board = new int[N][N];
// 0 empty, 1 human, 2 computer

/// float bx, by, cell;
/// boolean gameOver = false;
/// boolean humanTurn = true;

void setup() {
  fullScreen(P2D);
  orientation(PORTRAIT);

  ///surface.setTitle("GO 25 x 25");

  bx = width * 0.05;
  by = width * 0.12;
  cell = (width * 0.90) / (N - 1);

  noStroke();
  textAlign(CENTER, CENTER);
}

void draw() {
  background(210, 170, 90);

  drawBoard();
  drawStones();

  fill(0);
  textSize(width * 0.045);

  if (gameOver) {
    text("GAME OVER", width/2, width * 0.045);
  } else if (humanTurn) {
    text("YOUR MOVE", width/2, width * 0.045);
  } else {
    text("COMPUTER THINKING", width/2, width * 0.045);
  }
}

// ---------------- BOARD ----------------

void drawBoard() {
  stroke(0);
  strokeWeight(1);

  for (int i = 0; i < N; i++) {
    float p = bx + i * cell;

    line(p, by, p, by + (N-1)*cell);
    line(bx, p - bx + by, bx + (N-1)*cell, p - bx + by);
  }

  // Star points
  noStroke();
  fill(0);

  int[] stars = {3, 6, 12, 18, 21};

  for (int a = 0; a < stars.length; a++) {
    for (int b = 0; b < stars.length; b++) {

      int x = stars[a];
      int y = stars[b];

      if ((x == 3 || x == 21) &&
          (y == 3 || y == 21)) {

        ellipse(
          bx + x * cell,
          by + y * cell,
          cell * 0.16,
          cell * 0.16
        );
      }

      if (x == 12 && y == 12) {
        ellipse(
          bx + x * cell,
          by + y * cell,
          cell * 0.16,
          cell * 0.16
        );
      }
    }
  }
}

// ---------------- STONES ----------------

void drawStones() {

  float r = cell * 0.44;

  for (int y = 0; y < N; y++) {
    for (int x = 0; x < N; x++) {

      if (board[x][y] == 0) continue;

      float px = bx + x * cell;
      float py = by + y * cell;

      if (board[x][y] == 1) {
        fill(210, 30, 30);
      } else {
        fill(30, 60, 220);
      }

      ellipse(px, py, r*2, r*2);

      // small highlight
      fill(255, 120);
      ellipse(
        px - r*0.25,
        py - r*0.25,
        r*0.25,
        r*0.25
      );
    }
  }
}

// ---------------- TOUCH ----------------

void mousePressed() {

  if (gameOver) {
    return;
  }

  if (!humanTurn) {
    return;
  }

  int gx = round((mouseX - bx) / cell);
  int gy = round((mouseY - by) / cell);

  if (gx < 0 || gx >= N ||
      gy < 0 || gy >= N) {
    return;
  }

  float px = bx + gx * cell;
  float py = by + gy * cell;

  // Only accept touch close to intersection
  if (dist(mouseX, mouseY, px, py) > cell * 0.55) {
    return;
  }

  if (board[gx][gy] != 0) {
    return;
  }

  // Human move
  if (makeMove(gx, gy, 1)) {

    humanTurn = false;

    delay(150);

    computerMove();

    humanTurn = true;
  }
}

// ---------------- MOVE ----------------

boolean makeMove(int x, int y, int player) {

  if (board[x][y] != 0)
    return false;

  board[x][y] = player;

  // Remove opponent groups without liberties
  int opponent;

  if (player == 1)
    opponent = 2;
  else
    opponent = 1;

  for (int yy = 0; yy < N; yy++) {
    for (int xx = 0; xx < N; xx++) {

      if (board[xx][yy] == opponent) {

        if (!hasLiberty(xx, yy)) {
          removeGroup(xx, yy);
        }
      }
    }
  }

  // Suicide check
  if (!hasLiberty(x, y)) {
    board[x][y] = 0;
    return false;
  }

  return true;
}

// ---------------- LIBERTIES ----------------

boolean hasLiberty(int sx, int sy) {

  int player = board[sx][sy];

  if (player == 0)
    return true;

  boolean[][] used = new boolean[N][N];

  int[] qx = new int[N*N];
  int[] qy = new int[N*N];

  int head = 0;
  int tail = 0;

  qx[tail] = sx;
  qy[tail] = sy;
  tail++;

  used[sx][sy] = true;

  while (head < tail) {

    int x = qx[head];
    int y = qy[head];
    head++;

    int[][] dirs = {
      {1,0},
      {-1,0},
      {0,1},
      {0,-1}
    };

    for (int d = 0; d < 4; d++) {

      int nx = x + dirs[d][0];
      int ny = y + dirs[d][1];

      if (nx < 0 || nx >= N ||
          ny < 0 || ny >= N)
        continue;

      if (board[nx][ny] == 0)
        return true;

      if (board[nx][ny] == player &&
          !used[nx][ny]) {

        used[nx][ny] = true;

        qx[tail] = nx;
        qy[tail] = ny;
        tail++;
      }
    }
  }

  return false;
}

// ---------------- REMOVE GROUP ----------------

void removeGroup(int sx, int sy) {

  int player = board[sx][sy];

  if (player == 0)
    return;

  boolean[][] used = new boolean[N][N];

  int[] qx = new int[N*N];
  int[] qy = new int[N*N];

  int head = 0;
  int tail = 0;

  qx[tail] = sx;
  qy[tail] = sy;
  tail++;

  used[sx][sy] = true;

  while (head < tail) {

    int x = qx[head];
    int y = qy[head];
    head++;

    board[x][y] = 0;

    int[][] dirs = {
      {1,0},
      {-1,0},
      {0,1},
      {0,-1}
    };

    for (int d = 0; d < 4; d++) {

      int nx = x + dirs[d][0];
      int ny = y + dirs[d][1];

      if (nx < 0 || nx >= N ||
          ny < 0 || ny >= N)
        continue;

      if (board[nx][ny] == player &&
          !used[nx][ny]) {

        used[nx][ny] = true;

        qx[tail] = nx;
        qy[tail] = ny;
        tail++;
      }
    }
  }
}

// ---------------- COMPUTER ENGINE ----------------

void computerMove() {

  int bestX = -1;
  int bestY = -1;

  float bestScore = -999999;

  for (int y = 0; y < N; y++) {
    for (int x = 0; x < N; x++) {

      if (board[x][y] != 0)
        continue;

      float score = evaluateMove(x, y);

      // Small randomness
      score += random(-2, 2);

      if (score > bestScore) {
        bestScore = score;
        bestX = x;
        bestY = y;
      }
    }
  }

  if (bestX >= 0) {
    makeMove(bestX, bestY, 2);
  }
}

// ---------------- ENGINE EVALUATION ----------------

float evaluateMove(int x, int y) {

  float score = 0;

  // Prefer center
  float center = dist(
    x, y,
    N/2, N/2
  );

  score += (N - center) * 0.4;

  // Prefer neighbors
  int[][] dirs = {
    {1,0},
    {-1,0},
    {0,1},
    {0,-1}
  };

  for (int d = 0; d < 4; d++) {

    int nx = x + dirs[d][0];
    int ny = y + dirs[d][1];

    if (nx < 0 || nx >= N ||
        ny < 0 || ny >= N)
      continue;

    if (board[nx][ny] == 2)
      score += 5;

    if (board[nx][ny] == 1)
      score += 7;
  }

  // Try captures
  board[x][y] = 2;

  for (int yy = 0; yy < N; yy++) {
    for (int xx = 0; xx < N; xx++) {

      if (board[xx][yy] == 1 &&
          !hasLiberty(xx, yy)) {

        score += 100;
      }
    }
  }

  board[x][y] = 0;

  return score;
}
















/*


void draw() {
  background(210, 170, 90);

  drawBoard();
  drawStones();

  fill(0);
  textSize(width * 0.045);

  if (gameOver) {
    text("GAME OVER", width/2, width * 0.045);
  } else if (humanTurn) {
    text("YOUR MOVE", width/2, width * 0.045);
  } else {
    text("COMPUTER THINKING", width/2, width * 0.045);
  }
}

// ---------------- BOARD ----------------

void drawBoard() {
  stroke(0);
  strokeWeight(1);

  for (int i = 0; i < N; i++) {
    float p = bx + i * cell;

    line(p, by, p, by + (N-1)*cell);
    line(bx, p - bx + by, bx + (N-1)*cell, p - bx + by);
  }

  // Star points
  noStroke();
  fill(0);

  int[] stars = {3, 6, 12, 18, 21};

  for (int a = 0; a < stars.length; a++) {
    for (int b = 0; b < stars.length; b++) {

      int x = stars[a];
      int y = stars[b];

      if ((x == 3 || x == 21) &&
          (y == 3 || y == 21)) {

        ellipse(
          bx + x * cell,
          by + y * cell,
          cell * 0.16,
          cell * 0.16
        );
      }

      if (x == 12 && y == 12) {
        ellipse(
          bx + x * cell,
          by + y * cell,
          cell * 0.16,
          cell * 0.16
        );
      }
    }
  }
}

// ---------------- STONES ----------------

void drawStones() {

  float r = cell * 0.44;

  for (int y = 0; y < N; y++) {
    for (int x = 0; x < N; x++) {

      if (board[x][y] == 0) continue;

      float px = bx + x * cell;
      float py = by + y * cell;

      if (board[x][y] == 1) {
        fill(210, 30, 30);
      } else {
        fill(30, 60, 220);
      }

      ellipse(px, py, r*2, r*2);

      // small highlight
      fill(255, 120);
      ellipse(
        px - r*0.25,
        py - r*0.25,
        r*0.25,
        r*0.25
      );
    }
  }
}

// ---------------- TOUCH ----------------

void mousePressed() {

  if (gameOver) {
    return;
  }

  if (!humanTurn) {
    return;
  }

  int gx = round((mouseX - bx) / cell);
  int gy = round((mouseY - by) / cell);

  if (gx < 0 || gx >= N ||
      gy < 0 || gy >= N) {
    return;
  }

  float px = bx + gx * cell;
  float py = by + gy * cell;

  // Only accept touch close to intersection
  if (dist(mouseX, mouseY, px, py) > cell * 0.55) {
    return;
  }

  if (board[gx][gy] != 0) {
    return;
  }

  // Human move
  if (makeMove(gx, gy, 1)) {

    humanTurn = false;

    delay(150);

    computerMove();

    humanTurn = true;
  }
}

// ---------------- MOVE ----------------

boolean makeMove(int x, int y, int player) {

  if (board[x][y] != 0)
    return false;

  board[x][y] = player;

  // Remove opponent groups without liberties
  int opponent;

  if (player == 1)
    opponent = 2;
  else
    opponent = 1;

  for (int yy = 0; yy < N; yy++) {
    for (int xx = 0; xx < N; xx++) {

      if (board[xx][yy] == opponent) {

        if (!hasLiberty(xx, yy)) {
          removeGroup(xx, yy);
        }
      }
    }
  }

  // Suicide check
  if (!hasLiberty(x, y)) {
    board[x][y] = 0;
    return false;
  }

  return true;
}

// ---------------- LIBERTIES ----------------

boolean hasLiberty(int sx, int sy) {

  int player = board[sx][sy];

  if (player == 0)
    return true;

  boolean[][] used = new boolean[N][N];

  int[] qx = new int[N*N];
  int[] qy = new int[N*N];

  int head = 0;
  int tail = 0;

  qx[tail] = sx;
  qy[tail] = sy;
  tail++;

  used[sx][sy] = true;

  while (head < tail) {

    int x = qx[head];
    int y = qy[head];
    head++;

    int[][] dirs = {
      {1,0},
      {-1,0},
      {0,1},
      {0,-1}
    };

    for (int d = 0; d < 4; d++) {

      int nx = x + dirs[d][0];
      int ny = y + dirs[d][1];

      if (nx < 0 || nx >= N ||
          ny < 0 || ny >= N)
        continue;

      if (board[nx][ny] == 0)
        return true;

      if (board[nx][ny] == player &&
          !used[nx][ny]) {

        used[nx][ny] = true;

        qx[tail] = nx;
        qy[tail] = ny;
        tail++;
      }
    }
  }

  return false;
}

// ---------------- REMOVE GROUP ----------------

void removeGroup(int sx, int sy) {

  int player = board[sx][sy];

  if (player == 0)
    return;

  boolean[][] used = new boolean[N][N];

  int[] qx = new int[N*N];
  int[] qy = new int[N*N];

  int head = 0;
  int tail = 0;

  qx[tail] = sx;
  qy[tail] = sy;
  tail++;

  used[sx][sy] = true;

  while (head < tail) {

    int x = qx[head];
    int y = qy[head];
    head++;

    board[x][y] = 0;

    int[][] dirs = {
      {1,0},
      {-1,0},
      {0,1},
      {0,-1}
    };

    for (int d = 0; d < 4; d++) {

      int nx = x + dirs[d][0];
      int ny = y + dirs[d][1];

      if (nx < 0 || nx >= N ||
          ny < 0 || ny >= N)
        continue;

      if (board[nx][ny] == player &&
          !used[nx][ny]) {

        used[nx][ny] = true;

        qx[tail] = nx;
        qy[tail] = ny;
        tail++;
      }
    }
  }
}

// ---------------- COMPUTER ENGINE ----------------

void computerMove() {

  int bestX = -1;
  int bestY = -1;

  float bestScore = -999999;

  for (int y = 0; y < N; y++) {
    for (int x = 0; x < N; x++) {

      if (board[x][y] != 0)
        continue;

      float score = evaluateMove(x, y);

      // Small randomness
      score += random(-2, 2);

      if (score > bestScore) {
        bestScore = score;
        bestX = x;
        bestY = y;
      }
    }
  }

  if (bestX >= 0) {
    makeMove(bestX, bestY, 2);
  }
}

// ---------------- ENGINE EVALUATION ----------------

float evaluateMove(int x, int y) {

  float score = 0;

  // Prefer center
  float center = dist(
    x, y,
    N/2, N/2
  );

  score += (N - center) * 0.4;

  // Prefer neighbors
  int[][] dirs = {
    {1,0},
    {-1,0},
    {0,1},
    {0,-1}
  };

  for (int d = 0; d < 4; d++) {

    int nx = x + dirs[d][0];
    int ny = y + dirs[d][1];

    if (nx < 0 || nx >= N ||
        ny < 0 || ny >= N)
      continue;

    if (board[nx][ny] == 2)
      score += 5;

    if (board[nx][ny] == 1)
      score += 7;
  }

  // Try captures
  board[x][y] = 2;

  for (int yy = 0; yy < N; yy++) {
    for (int xx = 0; xx < N; xx++) {

      if (board[xx][yy] == 1 &&
          !hasLiberty(xx, yy)) {

        score += 100;
      }
    }
  }

  board[x][y] = 0;

  return score;
}


*/























