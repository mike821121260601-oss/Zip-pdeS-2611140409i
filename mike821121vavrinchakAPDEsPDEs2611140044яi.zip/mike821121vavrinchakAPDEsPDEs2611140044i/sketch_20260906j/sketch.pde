

// DroidFish companion – transparent line board
// APDE ready – does not touch any chess position

void setup() {
  fullScreen();                 // fills the phone screen
  orientation(PORTRAIT);
  // completely transparent background
  background(0, 0);
}

void draw() {
  // keep background fully transparent every frame
  background(0, 0);

  // soft chess-wood color (you can change these RGB values)
  stroke(160, 120, 70);
  strokeWeight(2.5);
  noFill();

  int margin = 40;
  int boardSize = min(width, height) - margin * 2;
  int cell = boardSize / 8;
  int startX = (width - boardSize) / 2;
  int startY = (height - boardSize) / 2;

  // draw the 8×8 grid lines only
  for (int i = 0; i <= 8; i++) {
    // vertical
    line(startX + i * cell, startY, 
         startX + i * cell, startY + boardSize);
    // horizontal
    line(startX, startY + i * cell, 
         startX + boardSize, startY + i * cell);
  }

  // thicker outer frame (DroidFish-like)
  stroke(110, 80, 40);
  strokeWeight(5);
  rect(startX, startY, boardSize, boardSize);
}




