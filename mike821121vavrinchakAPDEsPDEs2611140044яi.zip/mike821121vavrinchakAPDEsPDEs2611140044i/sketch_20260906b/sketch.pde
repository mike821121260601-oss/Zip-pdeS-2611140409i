




// ============================================================
// CHESS.pde
// APDE 0.5.3 / Processing
// ONE FILE
//
// Human = WHITE
// Computer = BLACK
// Search = Alpha-Beta
// Maximum depth = 8 ply
//
// Controls:
// TAP piece -> select
// TAP destination -> move
// NEW GAME -> restart
// ENGINE -> computer move
// DEPTH +/- -> search depth
// ============================================================

final int EMPTY = 0;

final int WHITE = 1;
final int BLACK = -1;

final int PAWN   = 1;
final int KNIGHT = 2;
final int BISHOP = 3;
final int ROOK   = 4;
final int QUEEN  = 5;
final int KING   = 6;

final int INF  = 100000000;
final int MATE = 1000000;

char[] pieces = {
  ' ', 'P', 'N', 'B', 'R', 'Q', 'K',
  'p', 'n', 'b', 'r', 'q', 'k'
};

Board board;

int selected = -1;
ArrayList<Move> selectedMoves;

boolean thinking = false;
boolean gameOver = false;

int searchDepth = 8;

long nodes = 0;
long startThink = 0;
long thinkTime = 9000;

String info = "";
String lastMoveText = "";

float bx, by, sq;

PFont font;

// ------------------------------------------------------------
// MOVE
// ------------------------------------------------------------

class Move {
  int from;
  int to;
  char promotion;

  boolean castle;
  boolean enPassant;

  int captured;

  Move(int f, int t) {
    from = f;
    to = t;
    promotion = 0;
    castle = false;
    enPassant = false;
    captured = 0;
  }

  Move copy() {
    Move m = new Move(from, to);
    m.promotion = promotion;
    m.castle = castle;
    m.enPassant = enPassant;
    m.captured = captured;
    return m;
  }
}

// ------------------------------------------------------------
// BOARD
// ------------------------------------------------------------

class Board {

  char[] b = new char[64];

  boolean wCastleK = true;
  boolean wCastleQ = true;
  boolean bCastleK = true;
  boolean bCastleQ = true;

  int ep = -1;

  boolean whiteTurn = true;

  int halfmove = 0;
  int fullmove = 1;

  Board() {
    reset();
  }

  Board(Board other) {

    for (int i = 0; i < 64; i++)
      b[i] = other.b[i];

    wCastleK = other.wCastleK;
    wCastleQ = other.wCastleQ;
    bCastleK = other.bCastleK;
    bCastleQ = other.bCastleQ;

    ep = other.ep;
    whiteTurn = other.whiteTurn;

    halfmove = other.halfmove;
    fullmove = other.fullmove;
  }

  void reset() {

    for (int i = 0; i < 64; i++)
      b[i] = '.';

    // black
    b[0]='r';
    b[1]='n';
    b[2]='b';
    b[3]='q';
    b[4]='k';
    b[5]='b';
    b[6]='n';
    b[7]='r';

    for (int i=8; i<16; i++)
      b[i]='p';

    // white
    b[56]='R';
    b[57]='N';
    b[58]='B';
    b[59]='Q';
    b[60]='K';
    b[61]='B';
    b[62]='N';
    b[63]='R';

    for (int i=48; i<56; i++)
      b[i]='P';

    wCastleK=true;
    wCastleQ=true;
    bCastleK=true;
    bCastleQ=true;

    ep=-1;
    whiteTurn=true;
    halfmove=0;
    fullmove=1;
  }
}

// ------------------------------------------------------------
// SETUP
// ------------------------------------------------------------

void setup() {

  size(displayWidth, displayHeight);

  font = createFont("SansSerif", 30);
  textFont(font);

  board = new Board();
  selectedMoves = new ArrayList<Move>();

  info = "WHITE TO MOVE";
}

// ------------------------------------------------------------
// DRAW
// ------------------------------------------------------------

void draw() {

  background(25,25,25);

  sq = min(width * 0.94, height * 0.76) / 8.0;

  bx = (width - sq * 8) / 2.0;
  by = 30;

  drawBoard();
  drawPieces();
  drawMoves();
  drawInfo();

  if (thinking) {
    fill(255);
    textAlign(CENTER,CENTER);
    textSize(22);
    text("ENGINE THINKING...", width/2, by+sq*8+75);
  }
}

// ------------------------------------------------------------
// BOARD
// ------------------------------------------------------------

void drawBoard() {

  noStroke();

  for (int r=0; r<8; r++) {

    for (int c=0; c<8; c++) {

      int x = c;
      int y = r;

      if ((r+c)%2==0)
        fill(235,220,180);
      else
        fill(105,135,80);

      rect(bx+c*sq, by+r*sq, sq, sq);
    }
  }

  // coordinates
  fill(30);
  textSize(max(10,sq*0.16));

  for (int i=0;i<8;i++) {

    textAlign(LEFT,BOTTOM);
    text(""+(8-i),
         bx+3,
         by+i*sq+sq-3);

    textAlign(RIGHT,TOP);
    text(""+char('a'+i),
         bx+(i+1)*sq-3,
         by+8*sq-3);
  }

  // selected square
  if (selected>=0) {

    int r=selected/8;
    int c=selected%8;

    noFill();
    stroke(255,215,0);
    strokeWeight(5);

    rect(bx+c*sq+2,
         by+r*sq+2,
         sq-4,
         sq-4);

    noStroke();
  }
}

// ------------------------------------------------------------
// PIECES
// ------------------------------------------------------------

void drawPieces() {

  textAlign(CENTER,CENTER);

  textSize(sq*0.68);

  for (int i=0;i<64;i++) {

    char p=board.b[i];

    if (p=='.')
      continue;

    int r=i/8;
    int c=i%8;

    String s="";

    switch(p) {

    case 'K': s="♔"; break;
    case 'Q': s="♕"; break;
    case 'R': s="♖"; break;
    case 'B': s="♗"; break;
    case 'N': s="♘"; break;
    case 'P': s="♙"; break;

    case 'k': s="♚"; break;
    case 'q': s="♛"; break;
    case 'r': s="♜"; break;
    case 'b': s="♝"; break;
    case 'n': s="♞"; break;
    case 'p': s="♟"; break;
    }

    // outline/shadow
    if (Character.isUpperCase(p))
      fill(250);
    else
      fill(20);

    text(s,
         bx+c*sq+sq/2,
         by+r*sq+sq/2+2);
  }
}

// ------------------------------------------------------------
// LEGAL MOVE MARKERS
// ------------------------------------------------------------

void drawMoves() {

  if (selectedMoves==null)
    return;

  noStroke();

  for (Move m : selectedMoves) {

    int r=m.to/8;
    int c=m.to%8;

    if (board.b[m.to]!='.') {

      noFill();
      stroke(230,50,50);
      strokeWeight(4);

      ellipse(
        bx+c*sq+sq/2,
        by+r*sq+sq/2,
        sq*0.75,
        sq*0.75
        );

      noStroke();

    } else {

      fill(40,40,40,130);

      ellipse(
        bx+c*sq+sq/2,
        by+r*sq+sq/2,
        sq*0.22,
        sq*0.22
        );
    }
  }
}

// ------------------------------------------------------------
// INFORMATION
// ------------------------------------------------------------

void drawInfo() {

  fill(255);
  textAlign(CENTER,CENTER);

  textSize(20);

  String turn =
    board.whiteTurn ? "WHITE" : "BLACK";

  if (!gameOver)
    info = turn + " TO MOVE";

  text(info,width/2,by+sq*8+30);

  textSize(15);

  text(
    "DEPTH " + searchDepth +
    "   NODES " + nodes +
    "   " + lastMoveText,
    width/2,
    by+sq*8+55
    );

  // buttons
  drawButton(
    width*0.05,
    height-55,
    width*0.25,
    42,
    "NEW GAME"
    );

  drawButton(
    width*0.375,
    height-55,
    width*0.25,
    42,
    "ENGINE"
    );

  drawButton(
    width*0.70,
    height-55,
    width*0.12,
    42,
    "-"
    );

  drawButton(
    width*0.84,
    height-55,
    width*0.12,
    42,
    "+"
    );
}

void drawButton(
  float x,
  float y,
  float w,
  float h,
  String s) {

  fill(55,55,55);
  stroke(150);
  strokeWeight(1);

  rect(x,y,w,h,6);

  fill(255);
  textAlign(CENTER,CENTER);
  textSize(15);

  text(s,x+w/2,y+h/2);
}

// ------------------------------------------------------------
// TOUCH
// ------------------------------------------------------------

void mousePressed() {

  if (thinking || gameOver)
    return;

  // new game
  if (mouseY>height-80 &&
      mouseX<width*0.30) {

    board.reset();
    selected=-1;
    selectedMoves.clear();
    gameOver=false;
    info="WHITE TO MOVE";
    lastMoveText="";
    return;
  }

  // engine button
  if (mouseY>height-80 &&
      mouseX>=width*0.35 &&
      mouseX<width*0.65) {

    if (!board.whiteTurn)
      startEngine();

    return;
  }

  // depth -
  if (mouseY>height-80 &&
      mouseX>=width*0.68 &&
      mouseX<width*0.83) {

    searchDepth=max(1,searchDepth-1);
    return;
  }

  // depth +
  if (mouseY>height-80 &&
      mouseX>=width*0.83) {

    searchDepth=min(8,searchDepth+1);
    return;
  }

  if (!board.whiteTurn)
    return;

  if (mouseX<bx ||
      mouseX>bx+sq*8 ||
      mouseY<by ||
      mouseY>by+sq*8)
    return;

  int c=int((mouseX-bx)/sq);
  int r=int((mouseY-by)/sq);

  int pos=r*8+c;

  // choose destination
  if (selected>=0) {

    Move chosen=null;

    for (Move m : selectedMoves) {

      if (m.to==pos) {
        chosen=m;
        break;
      }
    }

    if (chosen!=null) {

      makeMove(board,chosen);

      selected=-1;
      selectedMoves.clear();

      lastMoveText=moveName(chosen);

      checkGame();

      if (!gameOver && !board.whiteTurn)
        startEngine();

      return;
    }
  }

  // select white piece
  char p=board.b[pos];

  if (p!='.' && Character.isUpperCase(p)) {

    selected=pos;

    selectedMoves=legalMovesFor(board,pos);

  } else {

    selected=-1;
    selectedMoves.clear();
  }
}

// ------------------------------------------------------------
// ENGINE
// ------------------------------------------------------------

void startEngine() {

  if (thinking || gameOver)
    return;

  thinking=true;
  nodes=0;
  startThink=millis();

  // Processing draw must return.
  // Engine is executed in a short asynchronous-like sequence.
  // APDE will call draw repeatedly.
}

void engineStep() {

  if (!thinking)
    return;

  thinking=false;

  Move best=searchRoot(
    board,
    searchDepth
    );

  if (best!=null) {

    makeMove(board,best);

    lastMoveText=moveName(best);

    checkGame();
  }
}

// Use mouse release as a convenient APDE event.
// If engine was started, execute it on next frame.
void mouseReleased() {

  if (thinking) {

    // Do not run immediately while touch handling is active.
    delay(20);
    engineStep();
  }
}

// ------------------------------------------------------------
// ROOT SEARCH
// ------------------------------------------------------------

Move searchRoot(Board b, int depth) {

  ArrayList<Move> moves=legalMoves(b);

  if (moves.size()==0)
    return null;

  orderMoves(b,moves);

  Move best=moves.get(0);

  int bestScore= -INF;

  int alpha=-INF;
  int beta=INF;

  for (Move m : moves) {

    Board n=new Board(b);

    makeMove(n,m);

    int score=alphaBeta(
      n,
      depth-1,
      alpha,
      beta
      );

    if (score>bestScore) {

      bestScore=score;
      best=m;
    }

    if (score>alpha)
      alpha=score;

    if (millis()-startThink>thinkTime)
      break;
  }

  return best;
}

// ------------------------------------------------------------
// ALPHA BETA
// ------------------------------------------------------------

int alphaBeta(
  Board b,
  int depth,
  int alpha,
  int beta) {

  nodes++;

  if (millis()-startThink>thinkTime)
    return evaluate(b);

  ArrayList<Move> moves=legalMoves(b);

  if (moves.size()==0) {

    if (inCheck(b,b.whiteTurn))
      return b.whiteTurn ?
        -MATE-depth :
         MATE+depth;

    return 0;
  }

  if (depth<=0)
    return evaluate(b);

  orderMoves(b,moves);

  boolean maximizing=b.whiteTurn;

  if (maximizing) {

    int best=-INF;

    for (Move m:moves) {

      Board n=new Board(b);

      makeMove(n,m);

      int score=alphaBeta(
        n,
        depth-1,
        alpha,
        beta
        );

      best=max(best,score);
      alpha=max(alpha,score);

      if (beta<=alpha)
        break;
    }

    return best;

  } else {

    int best=INF;

    for (Move m:moves) {

      Board n=new Board(b);

      makeMove(n,m);

      int score=alphaBeta(
        n,
        depth-1,
        alpha,
        beta
        );

      best=min(best,score);
      beta=min(beta,score);

      if (beta<=alpha)
        break;
    }

    return best;
  }
}

// ------------------------------------------------------------
// EVALUATION
// ------------------------------------------------------------

int evaluate(Board b) {

  int score=0;

  for (int i=0;i<64;i++) {

    char p=b.b[i];

    if (p=='.')
      continue;

    int v=pieceValue(p);

    // material
    if (Character.isUpperCase(p))
      score+=v;
    else
      score-=v;

    // small positional bonus
    int r=i/8;
    int c=i%8;

    if (p=='P')
      score+=pawnBonus(r,c,true);

    if (p=='p')
      score-=pawnBonus(r,c,false);

    if (p=='N' || p=='B')
      score+=centerBonus(r,c);

    if (p=='n' || p=='b')
      score-=centerBonus(r,c);
  }

  // side to move has a tiny initiative bonus
  if (b.whiteTurn)
    score+=5;
  else
    score-=5;

  return score;
}

int pieceValue(char p) {

  switch(Character.toUpperCase(p)) {

  case 'P': return 100;
  case 'N': return 320;
  case 'B': return 330;
  case 'R': return 500;
  case 'Q': return 900;
  case 'K': return 20000;
  }

  return 0;
}

int centerBonus(int r,int c) {

  int d=abs(3-r)+abs(3-c);

  return max(0,12-d*3);
}

int pawnBonus(
  int r,
  int c,
  boolean white) {

  if (white)
    return (6-r)*4;
  else
    return (r-1)*4;
}

// ------------------------------------------------------------
// MOVE GENERATION
// ------------------------------------------------------------

ArrayList<Move> legalMoves(Board b) {

  ArrayList<Move> all=new ArrayList<Move>();

  for (int i=0;i<64;i++) {

    char p=b.b[i];

    if (p=='.')
      continue;

    boolean white=
      Character.isUpperCase(p);

    if (white!=b.whiteTurn)
      continue;

    ArrayList<Move> pm=
      pseudoMoves(b,i);

    for (Move m:pm) {

      Board n=new Board(b);

      makeMove(n,m);

      if (!inCheck(n,white))
        all.add(m);
    }
  }

  return all;
}

ArrayList<Move> legalMovesFor(
  Board b,
  int from) {

  ArrayList<Move> result=
    new ArrayList<Move>();

  char p=b.b[from];

  if (p=='.')
    return result;

  boolean white=
    Character.isUpperCase(p);

  if (white!=b.whiteTurn)
    return result;

  ArrayList<Move> pm=
    pseudoMoves(b,from);

  for (Move m:pm) {

    Board n=new Board(b);

    makeMove(n,m);

    if (!inCheck(n,white))
      result.add(m);
  }

  return result;
}

// ------------------------------------------------------------
// PSEUDO MOVES
// ------------------------------------------------------------

ArrayList<Move> pseudoMoves(
  Board b,
  int from) {

  ArrayList<Move> list=
    new ArrayList<Move>();

  char p=b.b[from];

  if (p=='.')
    return list;

  boolean white=
    Character.isUpperCase(p);

  int r=from/8;
  int c=from%8;

  char u=Character.toUpperCase(p);

  // PAWN
  if (u=='P') {

    int dir=white ? -1 : 1;
    int start=white ? 6 : 1;
    int promo=white ? 0 : 7;

    int nr=r+dir;

    if (inside(nr,c)) {

      int to=nr*8+c;

      if (b.b[to]=='.') {

        addPawnMove(list,from,to,white,promo);

        if (r==start) {

          int nr2=r+dir*2;
          int to2=nr2*8+c;

          if (b.b[to2]=='.') {

            Move m=new Move(from,to2);
            list.add(m);
          }
        }
      }

      // captures
      for (int dc=-1;dc<=1;dc+=2) {

        int nc=c+dc;

        if (!inside(nr,nc))
          continue;

        int cap=nr*8+nc;

        if (b.b[cap]!='.' &&
            Character.isUpperCase(b.b[cap])!=white) {

          addPawnMove(
            list,
            from,
            cap,
            white,
            promo
            );
        }

        // en passant
        if (cap==b.ep) {

          Move m=new Move(from,cap);
          m.enPassant=true;
          list.add(m);
        }
      }
    }
  }

  // KNIGHT
  else if (u=='N') {

    int[][] d={
      {2,1},{2,-1},
      {-2,1},{-2,-1},
      {1,2},{1,-2},
      {-1,2},{-1,-2}
    };

    for (int k=0;k<8;k++) {

      int nr=r+d[k][0];
      int nc=c+d[k][1];

      if (!inside(nr,nc))
        continue;

      int to=nr*8+nc;

      if (friendly(b.b[to],white))
        continue;

      list.add(new Move(from,to));
    }
  }

  // BISHOP
  else if (u=='B') {

    addSlides(
      b,list,from,r,c,white,
      new int[][] {
        {1,1},{1,-1},
        {-1,1},{-1,-1}
      }
      );
  }

  // ROOK
  else if (u=='R') {

    addSlides(
      b,list,from,r,c,white,
      new int[][] {
        {1,0},{-1,0},
        {0,1},{0,-1}
      }
      );
  }

  // QUEEN
  else if (u=='Q') {

    addSlides(
      b,list,from,r,c,white,
      new int[][] {
        {1,1},{1,-1},
        {-1,1},{-1,-1},
        {1,0},{-1,0},
        {0,1},{0,-1}
      }
      );
  }

  // KING
  else if (u=='K') {

    for (int dr=-1;dr<=1;dr++) {
      for (int dc=-1;dc<=1;dc++) {

        if (dr==0 && dc==0)
          continue;

        int nr=r+dr;
        int nc=c+dc;

        if (!inside(nr,nc))
          continue;

        int to=nr*8+nc;

        if (!friendly(b.b[to],white))
          list.add(new Move(from,to));
      }
    }

    // castling
    addCastling(b,list,white);
  }

  return list;
}

// ------------------------------------------------------------
// SLIDING PIECES
// ------------------------------------------------------------

void addSlides(
  Board b,
  ArrayList<Move> list,
  int from,
  int r,
  int c,
  boolean white,
  int[][] dirs) {

  for (int d=0;d<dirs.length;d++) {

    int dr=dirs[d][0];
    int dc=dirs[d][1];

    int nr=r+dr;
    int nc=c+dc;

    while (inside(nr,nc)) {

      int to=nr*8+nc;

      if (b.b[to]=='.') {

        list.add(new Move(from,to));

      } else {

        if (!friendly(b.b[to],white))
          list.add(new Move(from,to));

        break;
      }

      nr+=dr;
      nc+=dc;
    }
  }
}

// ------------------------------------------------------------
// PAWN PROMOTION
// ------------------------------------------------------------

void addPawnMove(
  ArrayList<Move> list,
  int from,
  int to,
  boolean white,
  int promoRank) {

  int r=to/8;

  if (r==promoRank) {

    char[] ps=white ?
      new char[]{'Q','R','B','N'} :
      new char[]{'q','r','b','n'};

    for (int i=0;i<4;i++) {

      Move m=new Move(from,to);
      m.promotion=ps[i];

      list.add(m);
    }

  } else {

    list.add(new Move(from,to));
  }
}

// ------------------------------------------------------------
// CASTLING
// ------------------------------------------------------------

void addCastling(
  Board b,
  ArrayList<Move> list,
  boolean white) {

  if (white) {

    // king side
    if (b.wCastleK &&
        b.b[60]=='K' &&
        b.b[61]=='.' &&
        b.b[62]=='.' &&
        b.b[63]=='R') {

      if (!inCheck(b,true) &&
          !attacked(b,61,false) &&
          !attacked(b,62,false)) {

        Move m=new Move(60,62);
        m.castle=true;
        list.add(m);
      }
    }

    // queen side
    if (b.wCastleQ &&
        b.b[60]=='K' &&
        b.b[59]=='.' &&
        b.b[58]=='.' &&
        b.b[57]=='.' &&
        b.b[56]=='R') {

      if (!inCheck(b,true) &&
          !attacked(b,59,false) &&
          !attacked(b,58,false)) {

        Move m=new Move(60,58);
        m.castle=true;
        list.add(m);
      }
    }

  } else {

    // black king side
    if (b.bCastleK &&
        b.b[4]=='k' &&
        b.b[5]=='.' &&
        b.b[6]=='.' &&
        b.b[7]=='r') {

      if (!inCheck(b,false) &&
          !attacked(b,5,true) &&
          !attacked(b,6,true)) {

        Move m=new Move(4,6);
        m.castle=true;
        list.add(m);
      }
    }

    // black queen side
    if (b.bCastleQ &&
        b.b[4]=='k' &&
        b.b[3]=='.' &&
        b.b[2]=='.' &&
        b.b[1]=='.' &&
        b.b[0]=='r') {

      if (!inCheck(b,false) &&
          !attacked(b,3,true) &&
          !attacked(b,2,true)) {

        Move m=new Move(4,2);
        m.castle=true;
        list.add(m);
      }
    }
  }
}

// ------------------------------------------------------------
// MAKE MOVE
// ------------------------------------------------------------

void makeMove(
  Board b,
  Move m) {

  char p=b.b[m.from];
  char target=b.b[m.to];

  boolean white=
    Character.isUpperCase(p);

  // halfmove
  if (Character.toUpperCase(p)=='P' ||
      target!='.' ||
      m.enPassant)
    b.halfmove=0;
  else
    b.halfmove++;

  // en passant target
  b.ep=-1;

  // pawn double move
  if (Character.toUpperCase(p)=='P') {

    if (abs(m.to-m.from)==16)
      b.ep=(m.to+m.from)/2;
  }

  // en passant capture
  if (m.enPassant) {

    if (white)
      b.b[m.to+8]='.';
    else
      b.b[m.to-8]='.';
  }

  // update castling rights because king moves
  if (p=='K') {

    b.wCastleK=false;
    b.wCastleQ=false;
  }

  if (p=='k') {

    b.bCastleK=false;
    b.bCastleQ=false;
  }

  // rook moves
  if (m.from==63) b.wCastleK=false;
  if (m.from==56) b.wCastleQ=false;
  if (m.from==7)  b.bCastleK=false;
  if (m.from==0)  b.bCastleQ=false;

  // rook captured
  if (m.to==63 && target=='R')
    b.wCastleK=false;

  if (m.to==56 && target=='R')
    b.wCastleQ=false;

  if (m.to==7 && target=='r')
    b.bCastleK=false;

  if (m.to==0 && target=='r')
    b.bCastleQ=false;

  // move
  b.b[m.to]=p;
  b.b[m.from]='.';

  // promotion
  if (m.promotion!=0)
    b.b[m.to]=m.promotion;

  // castling rook
  if (m.castle) {

    if (m.to==62) {

      b.b[61]='R';
      b.b[63]='.';

    } else if (m.to==58) {

      b.b[59]='R';
      b.b[56]='.';

    } else if (m.to==6) {

      b.b[5]='r';
      b.b[7]='.';

    } else if (m.to==2) {

      b.b[3]='r';
      b.b[0]='.';
    }
  }

  if (!white)
    b.fullmove++;

  b.whiteTurn=!b.whiteTurn;
}

// ------------------------------------------------------------
// CHECK
// ------------------------------------------------------------

boolean inCheck(
  Board b,
  boolean white) {

  int king=-1;

  char k=white ? 'K' : 'k';

  for (int i=0;i<64;i++) {

    if (b.b[i]==k) {
      king=i;
      break;
    }
  }

  if (king<0)
    return true;

  return attacked(
    b,
    king,
    !white
    );
}

// ------------------------------------------------------------
// ATTACK DETECTION
// ------------------------------------------------------------

boolean attacked(
  Board b,
  int square,
  boolean byWhite) {

  int r=square/8;
  int c=square%8;

  // pawn
  int pawnDir=byWhite ? 1 : -1;

  int pr=r+pawnDir;

  if (inside(pr,c-1)) {

    char p=b.b[pr*8+c-1];

    if (p==(byWhite?'P':'p'))
      return true;
  }

  if (inside(pr,c+1)) {

    char p=b.b[pr*8+c+1];

    if (p==(byWhite?'P':'p'))
      return true;
  }

  // knight
  int[][] nd={
    {2,1},{2,-1},
    {-2,1},{-2,-1},
    {1,2},{1,-2},
    {-1,2},{-1,-2}
  };

  for (int i=0;i<8;i++) {

    int nr=r+nd[i][0];
    int nc=c+nd[i][1];

    if (!inside(nr,nc))
      continue;

    char p=b.b[nr*8+nc];

    if (p==(byWhite?'N':'n'))
      return true;
  }

  // rook / queen
  int[][] rd={
    {1,0},{-1,0},
    {0,1},{0,-1}
  };

  for (int i=0;i<4;i++) {

    int nr=r+rd[i][0];
    int nc=c+rd[i][1];

    while (inside(nr,nc)) {

      char p=b.b[nr*8+nc];

      if (p!='.') {

        if (p==(byWhite?'R':'r') ||
            p==(byWhite?'Q':'q'))
          return true;

        break;
      }

      nr+=rd[i][0];
      nc+=rd[i][1];
    }
  }

  // bishop / queen
  int[][] bd={
    {1,1},{1,-1},
    {-1,1},{-1,-1}
  };

  for (int i=0;i<4;i++) {

    int nr=r+bd[i][0];
    int nc=c+bd[i][1];

    while (inside(nr,nc)) {

      char p=b.b[nr*8+nc];

      if (p!='.') {

        if (p==(byWhite?'B':'b') ||
            p==(byWhite?'Q':'q'))
          return true;

        break;
      }

      nr+=bd[i][0];
      nc+=bd[i][1];
    }
  }

  // king
  for (int dr=-1;dr<=1;dr++) {
    for (int dc=-1;dc<=1;dc++) {

      if (dr==0 && dc==0)
        continue;

      int nr=r+dr;
      int nc=c+dc;

      if (!inside(nr,nc))
        continue;

      if (b.b[nr*8+nc]==
          (byWhite?'K':'k'))
        return true;
    }
  }

  return false;
}

// ------------------------------------------------------------
// MOVE ORDERING
// ------------------------------------------------------------

void orderMoves(
  Board b,
  ArrayList<Move> moves) {

  // simple insertion sort:
  // captures / promotions / castles first

  for (int i=1;i<moves.size();i++) {

    Move key=moves.get(i);

    int kv=moveScore(b,key);

    int j=i-1;

    while (j>=0 &&
           moveScore(b,moves.get(j))<kv) {

      moves.set(j+1,moves.get(j));
      j--;
    }

    moves.set(j+1,key);
  }
}

int moveScore(
  Board b,
  Move m) {

  int s=0;

  char p=b.b[m.from];
  char c=b.b[m.to];

  if (c!='.')
    s+=10000+pieceValue(c)-pieceValue(p)/10;

  if (m.enPassant)
    s+=9500;

  if (m.promotion!=0)
    s+=8000+pieceValue(m.promotion);

  if (m.castle)
    s+=100;

  // center
  int r=m.to/8;
  int col=m.to%8;

  if (r>=2 && r<=5 &&
      col>=2 && col<=5)
    s+=20;

  return s;
}

// ------------------------------------------------------------
// UTILITIES
// ------------------------------------------------------------

boolean inside(int r,int c) {

  return r>=0 && r<8 &&
         c>=0 && c<8;
}

boolean friendly(
  char p,
  boolean white) {

  if (p=='.')
    return false;

  return Character.isUpperCase(p)==white;
}

// ------------------------------------------------------------
// GAME STATE
// ------------------------------------------------------------

void checkGame() {

  ArrayList<Move> moves=
    legalMoves(board);

  if (moves.size()==0) {

    gameOver=true;

    if (inCheck(board,board.whiteTurn)) {

      if (board.whiteTurn)
        info="CHECKMATE - BLACK WINS";
      else
        info="CHECKMATE - WHITE WINS";

    } else {

      info="STALEMATE";
    }

    return;
  }

  // fifty move rule
  if (board.halfmove>=100) {

    gameOver=true;
    info="DRAW - 50 MOVE RULE";
    return;
  }

  // check indication
  if (inCheck(board,board.whiteTurn))
    info=
      (board.whiteTurn ? "WHITE" : "BLACK")
      + " IN CHECK";
  else
    info=
      (board.whiteTurn ? "WHITE" : "BLACK")
      + " TO MOVE";
}

// ------------------------------------------------------------
// MOVE TEXT
// ------------------------------------------------------------

String moveName(Move m) {

  String s=
    squareName(m.from)+
    "-" +
    squareName(m.to);

  if (m.promotion!=0)
    s+="="+
      Character.toUpperCase(m.promotion);

  if (m.castle) {

    if (m.to==62 || m.to==6)
      s="O-O";
    else
      s="O-O-O";
  }

  return s;
}

String squareName(int p) {

  int r=p/8;
  int c=p%8;

  return ""+
    char('a'+c)+
    (8-r);
}

// ------------------------------------------------------------
// OPTIONAL FEN PRINT
// ------------------------------------------------------------

String getFEN() {

  String f="";

  for (int r=0;r<8;r++) {

    int empty=0;

    for (int c=0;c<8;c++) {

      char p=board.b[r*8+c];

      if (p=='.') {

        empty++;

      } else {

        if (empty>0) {
          f+=empty;
          empty=0;
        }

        f+=p;
      }
    }

    if (empty>0)
      f+=empty;

    if (r<7)
      f+="/";
  }

  f+=" ";
  f+=board.whiteTurn ? "w " : "b ";

  String castle="";

  if (board.wCastleK) castle+="K";
  if (board.wCastleQ) castle+="Q";
  if (board.bCastleK) castle+="k";
  if (board.bCastleQ) castle+="q";

  if (castle.length()==0)
    castle="-";

  f+=castle+" ";

  if (board.ep<0)
    f+="-";
  else
    f+=squareName(board.ep);

  f+=" "+board.halfmove;
  f+=" "+board.fullmove;

  return f;
}







/*


// ============================================================
// CHESS.pde
// APDE 0.5.3 / Processing
// ONE FILE
//
// Human = WHITE
// Computer = BLACK
// Search = Alpha-Beta
// Maximum depth = 8 ply
//
// Controls:
// TAP piece -> select
// TAP destination -> move
// NEW GAME -> restart
// ENGINE -> computer move
// DEPTH +/- -> search depth
// ============================================================

final int EMPTY = 0;

final int WHITE = 1;
final int BLACK = -1;

final int PAWN   = 1;
final int KNIGHT = 2;
final int BISHOP = 3;
final int ROOK   = 4;
final int QUEEN  = 5;
final int KING   = 6;

final int INF  = 100000000;
final int MATE = 1000000;

char[] pieces = {
  ' ', 'P', 'N', 'B', 'R', 'Q', 'K',
  'p', 'n', 'b', 'r', 'q', 'k'
};

Board board;

int selected = -1;
ArrayList<Move> selectedMoves;

boolean thinking = false;
boolean gameOver = false;

int searchDepth = 8;

long nodes = 0;
long startThink = 0;
long thinkTime = 9000;

String info = "";
String lastMoveText = "";

float bx, by, sq;

PFont font;

// ------------------------------------------------------------
// MOVE
// ------------------------------------------------------------

class Move {
  int from;
  int to;
  char promotion;

  boolean castle;
  boolean enPassant;

  int captured;

  Move(int f, int t) {
    from = f;
    to = t;
    promotion = 0;
    castle = false;
    enPassant = false;
    captured = 0;
  }

  Move copy() {
    Move m = new Move(from, to);
    m.promotion = promotion;
    m.castle = castle;
    m.enPassant = enPassant;
    m.captured = captured;
    return m;
  }
}

// ------------------------------------------------------------
// BOARD
// ------------------------------------------------------------

class Board {

  char[] b = new char[64];

  boolean wCastleK = true;
  boolean wCastleQ = true;
  boolean bCastleK = true;
  boolean bCastleQ = true;

  int ep = -1;

  boolean whiteTurn = true;

  int halfmove = 0;
  int fullmove = 1;

  Board() {
    reset();
  }

  Board(Board other) {

    for (int i = 0; i < 64; i++)
      b[i] = other.b[i];

    wCastleK = other.wCastleK;
    wCastleQ = other.wCastleQ;
    bCastleK = other.bCastleK;
    bCastleQ = other.bCastleQ;

    ep = other.ep;
    whiteTurn = other.whiteTurn;

    halfmove = other.halfmove;
    fullmove = other.fullmove;
  }

  void reset() {

    for (int i = 0; i < 64; i++)
      b[i] = '.';

    // black
    b[0]='r';
    b[1]='n';
    b[2]='b';
    b[3]='q';
    b[4]='k';
    b[5]='b';
    b[6]='n';
    b[7]='r';

    for (int i=8; i<16; i++)
      b[i]='p';

    // white
    b[56]='R';
    b[57]='N';
    b[58]='B';
    b[59]='Q';
    b[60]='K';
    b[61]='B';
    b[62]='N';
    b[63]='R';

    for (int i=48; i<56; i++)
      b[i]='P';

    wCastleK=true;
    wCastleQ=true;
    bCastleK=true;
    bCastleQ=true;

    ep=-1;
    whiteTurn=true;
    halfmove=0;
    fullmove=1;
  }
}

// ------------------------------------------------------------
// SETUP
// ------------------------------------------------------------

void setup() {

  size(displayWidth, displayHeight);

  font = createFont("SansSerif", 30);
  textFont(font);

  board = new Board();
  selectedMoves = new ArrayList<Move>();

  info = "WHITE TO MOVE";
}

// ------------------------------------------------------------
// DRAW
// ------------------------------------------------------------

void draw() {

  background(25,25,25);

  sq = min(width * 0.94, height * 0.76) / 8.0;

  bx = (width - sq * 8) / 2.0;
  by = 30;

  drawBoard();
  drawPieces();
  drawMoves();
  drawInfo();

  if (thinking) {
    fill(255);
    textAlign(CENTER,CENTER);
    textSize(22);
    text("ENGINE THINKING...", width/2, by+sq*8+75);
  }
}

// ------------------------------------------------------------
// BOARD
// ------------------------------------------------------------

void drawBoard() {

  noStroke();

  for (int r=0; r<8; r++) {

    for (int c=0; c<8; c++) {

      int x = c;
      int y = r;

      if ((r+c)%2==0)
        fill(235,220,180);
      else
        fill(105,135,80);

      rect(bx+c*sq, by+r*sq, sq, sq);
    }
  }

  // coordinates
  fill(30);
  textSize(max(10,sq*0.16));

  for (int i=0;i<8;i++) {

    textAlign(LEFT,BOTTOM);
    text(""+(8-i),
         bx+3,
         by+i*sq+sq-3);

    textAlign(RIGHT,TOP);
    text(""+char('a'+i),
         bx+(i+1)*sq-3,
         by+8*sq-3);
  }

  // selected square
  if (selected>=0) {

    int r=selected/8;
    int c=selected%8;

    noFill();
    stroke(255,215,0);
    strokeWeight(5);

    rect(bx+c*sq+2,
         by+r*sq+2,
         sq-4,
         sq-4);

    noStroke();
  }
}

// ------------------------------------------------------------
// PIECES
// ------------------------------------------------------------

void drawPieces() {

  textAlign(CENTER,CENTER);

  textSize(sq*0.68);

  for (int i=0;i<64;i++) {

    char p=board.b[i];

    if (p=='.')
      continue;

    int r=i/8;
    int c=i%8;

    String s="";

    switch(p) {

    case 'K': s="♔"; break;
    case 'Q': s="♕"; break;
    case 'R': s="♖"; break;
    case 'B': s="♗"; break;
    case 'N': s="♘"; break;
    case 'P': s="♙"; break;

    case 'k': s="♚"; break;
    case 'q': s="♛"; break;
    case 'r': s="♜"; break;
    case 'b': s="♝"; break;
    case 'n': s="♞"; break;
    case 'p': s="♟"; break;
    }

    // outline/shadow
    if (Character.isUpperCase(p))
      fill(250);
    else
      fill(20);

    text(s,
         bx+c*sq+sq/2,
         by+r*sq+sq/2+2);
  }
}

// ------------------------------------------------------------
// LEGAL MOVE MARKERS
// ------------------------------------------------------------

void drawMoves() {

  if (selectedMoves==null)
    return;

  noStroke();

  for (Move m : selectedMoves) {

    int r=m.to/8;
    int c=m.to%8;

    if (board.b[m.to]!='.') {

      noFill();
      stroke(230,50,50);
      strokeWeight(4);

      ellipse(
        bx+c*sq+sq/2,
        by+r*sq+sq/2,
        sq*0.75,
        sq*0.75
        );

      noStroke();

    } else {

      fill(40,40,40,130);

      ellipse(
        bx+c*sq+sq/2,
        by+r*sq+sq/2,
        sq*0.22,
        sq*0.22
        );
    }
  }
}

// ------------------------------------------------------------
// INFORMATION
// ------------------------------------------------------------

void drawInfo() {

  fill(255);
  textAlign(CENTER,CENTER);

  textSize(20);

  String turn =
    board.whiteTurn ? "WHITE" : "BLACK";

  if (!gameOver)
    info = turn + " TO MOVE";

  text(info,width/2,by+sq*8+30);

  textSize(15);

  text(
    "DEPTH " + searchDepth +
    "   NODES " + nodes +
    "   " + lastMoveText,
    width/2,
    by+sq*8+55
    );

  // buttons
  drawButton(
    width*0.05,
    height-55,
    width*0.25,
    42,
    "NEW GAME"
    );

  drawButton(
    width*0.375,
    height-55,
    width*0.25,
    42,
    "ENGINE"
    );

  drawButton(
    width*0.70,
    height-55,
    width*0.12,
    42,
    "-"
    );

  drawButton(
    width*0.84,
    height-55,
    width*0.12,
    42,
    "+"
    );
}

void drawButton(
  float x,
  float y,
  float w,
  float h,
  String s) {

  fill(55,55,55);
  stroke(150);
  strokeWeight(1);

  rect(x,y,w,h,6);

  fill(255);
  textAlign(CENTER,CENTER);
  textSize(15);

  text(s,x+w/2,y+h/2);
}

// ------------------------------------------------------------
// TOUCH
// ------------------------------------------------------------

void mousePressed() {

  if (thinking || gameOver)
    return;

  // new game
  if (mouseY>height-80 &&
      mouseX<width*0.30) {

    board.reset();
    selected=-1;
    selectedMoves.clear();
    gameOver=false;
    info="WHITE TO MOVE";
    lastMoveText="";
    return;
  }

  // engine button
  if (mouseY>height-80 &&
      mouseX>=width*0.35 &&
      mouseX<width*0.65) {

    if (!board.whiteTurn)
      startEngine();

    return;
  }

  // depth -
  if (mouseY>height-80 &&
      mouseX>=width*0.68 &&
      mouseX<width*0.83) {

    searchDepth=max(1,searchDepth-1);
    return;
  }

  // depth +
  if (mouseY>height-80 &&
      mouseX>=width*0.83) {

    searchDepth=min(8,searchDepth+1);
    return;
  }

  if (!board.whiteTurn)
    return;

  if (mouseX<bx ||
      mouseX>bx+sq*8 ||
      mouseY<by ||
      mouseY>by+sq*8)
    return;

  int c=int((mouseX-bx)/sq);
  int r=int((mouseY-by)/sq);

  int pos=r*8+c;

  // choose destination
  if (selected>=0) {

    Move chosen=null;

    for (Move m : selectedMoves) {

      if (m.to==pos) {
        chosen=m;
        break;
      }
    }

    if (chosen!=null) {

      makeMove(board,chosen);

      selected=-1;
      selectedMoves.clear();

      lastMoveText=moveName(chosen);

      checkGame();

      if (!gameOver && !board.whiteTurn)
        startEngine();

      return;
    }
  }

  // select white piece
  char p=board.b[pos];

  if (p!='.' && Character.isUpperCase(p)) {

    selected=pos;

    selectedMoves=legalMovesFor(board,pos);

  } else {

    selected=-1;
    selectedMoves.clear();
  }
}

// ------------------------------------------------------------
// ENGINE
// ------------------------------------------------------------

void startEngine() {

  if (thinking || gameOver)
    return;

  thinking=true;
  nodes=0;
  startThink=millis();

  // Processing draw must return.
  // Engine is executed in a short asynchronous-like sequence.
  // APDE will call draw repeatedly.
}

void engineStep() {

  if (!thinking)
    return;

  thinking=false;

  Move best=searchRoot(
    board,
    searchDepth
    );

  if (best!=null) {

    makeMove(board,best);

    lastMoveText=moveName(best);

    checkGame();
  }
}

// Use mouse release as a convenient APDE event.
// If engine was started, execute it on next frame.
void mouseReleased() {

  if (thinking) {

    // Do not run immediately while touch handling is active.
    delay(20);
    engineStep();
  }
}

// ------------------------------------------------------------
// ROOT SEARCH
// ------------------------------------------------------------

Move searchRoot(Board b, int depth) {

  ArrayList<Move> moves=legalMoves(b);

  if (moves.size()==0)
    return null;

  orderMoves(b,moves);

  Move best=moves.get(0);

  int bestScore= -INF;

  int alpha=-INF;
  int beta=INF;

  for (Move m : moves) {

    Board n=new Board(b);

    makeMove(n,m);

    int score=alphaBeta(
      n,
      depth-1,
      alpha,
      beta
      );

    if (score>bestScore) {

      bestScore=score;
      best=m;
    }

    if (score>alpha)
      alpha=score;

    if (millis()-startThink>thinkTime)
      break;
  }

  return best;
}

// ------------------------------------------------------------
// ALPHA BETA
// ------------------------------------------------------------

int alphaBeta(
  Board b,
  int depth,
  int alpha,
  int beta) {

  nodes++;

  if (millis()-startThink>thinkTime)
    return evaluate(b);

  ArrayList<Move> moves=legalMoves(b);

  if (moves.size()==0) {

    if (inCheck(b,b.whiteTurn))
      return b.whiteTurn ?
        -MATE-depth :
         MATE+depth;

    return 0;
  }

  if (depth<=0)
    return evaluate(b);

  orderMoves(b,moves);

  boolean maximizing=b.whiteTurn;

  if (maximizing) {

    int best=-INF;

    for (Move m:moves) {

      Board n=new Board(b);

      makeMove(n,m);

      int score=alphaBeta(
        n,
        depth-1,
        alpha,
        beta
        );

      best=max(best,score);
      alpha=max(alpha,score);

      if (beta<=alpha)
        break;
    }

    return best;

  } else {

    int best=INF;

    for (Move m:moves) {

      Board n=new Board(b);

      makeMove(n,m);

      int score=alphaBeta(
        n,
        depth-1,
        alpha,
        beta
        );

      best=min(best,score);
      beta=min(beta,score);

      if (beta<=alpha)
        break;
    }

    return best;
  }
}

// ------------------------------------------------------------
// EVALUATION
// ------------------------------------------------------------

int evaluate(Board b) {

  int score=0;

  for (int i=0;i<64;i++) {

    char p=b.b[i];

    if (p=='.')
      continue;

    int v=pieceValue(p);

    // material
    if (Character.isUpperCase(p))
      score+=v;
    else
      score-=v;

    // small positional bonus
    int r=i/8;
    int c=i%8;

    if (p=='P')
      score+=pawnBonus(r,c,true);

    if (p=='p')
      score-=pawnBonus(r,c,false);

    if (p=='N' || p=='B')
      score+=centerBonus(r,c);

    if (p=='n' || p=='b')
      score-=centerBonus(r,c);
  }

  // side to move has a tiny initiative bonus
  if (b.whiteTurn)
    score+=5;
  else
    score-=5;

  return score;
}

int pieceValue(char p) {

  switch(Character.toUpperCase(p)) {

  case 'P': return 100;
  case 'N': return 320;
  case 'B': return 330;
  case 'R': return 500;
  case 'Q': return 900;
  case 'K': return 20000;
  }

  return 0;
}

int centerBonus(int r,int c) {

  int d=abs(3-r)+abs(3-c);

  return max(0,12-d*3);
}

int pawnBonus(
  int r,
  int c,
  boolean white) {

  if (white)
    return (6-r)*4;
  else
    return (r-1)*4;
}

// ------------------------------------------------------------
// MOVE GENERATION
// ------------------------------------------------------------

ArrayList<Move> legalMoves(Board b) {

  ArrayList<Move> all=new ArrayList<Move>();

  for (int i=0;i<64;i++) {

    char p=b.b[i];

    if (p=='.')
      continue;

    boolean white=
      Character.isUpperCase(p);

    if (white!=b.whiteTurn)
      continue;

    ArrayList<Move> pm=
      pseudoMoves(b,i);

    for (Move m:pm) {

      Board n=new Board(b);

      makeMove(n,m);

      if (!inCheck(n,white))
        all.add(m);
    }
  }

  return all;
}

ArrayList<Move> legalMovesFor(
  Board b,
  int from) {

  ArrayList<Move> result=
    new ArrayList<Move>();

  char p=b.b[from];

  if (p=='.')
    return result;

  boolean white=
    Character.isUpperCase(p);

  if (white!=b.whiteTurn)
    return result;

  ArrayList<Move> pm=
    pseudoMoves(b,from);

  for (Move m:pm) {

    Board n=new Board(b);

    makeMove(n,m);

    if (!inCheck(n,white))
      result.add(m);
  }

  return result;
}

// ------------------------------------------------------------
// PSEUDO MOVES
// ------------------------------------------------------------

ArrayList<Move> pseudoMoves(
  Board b,
  int from) {

  ArrayList<Move> list=
    new ArrayList<Move>();

  char p=b.b[from];

  if (p=='.')
    return list;

  boolean white=
    Character.isUpperCase(p);

  int r=from/8;
  int c=from%8;

  char u=Character.toUpperCase(p);

  // PAWN
  if (u=='P') {

    int dir=white ? -1 : 1;
    int start=white ? 6 : 1;
    int promo=white ? 0 : 7;

    int nr=r+dir;

    if (inside(nr,c)) {

      int to=nr*8+c;

      if (b.b[to]=='.') {

        addPawnMove(list,from,to,white,promo);

        if (r==start) {

          int nr2=r+dir*2;
          int to2=nr2*8+c;

          if (b.b[to2]=='.') {

            Move m=new Move(from,to2);
            list.add(m);
          }
        }
      }

      // captures
      for (int dc=-1;dc<=1;dc+=2) {

        int nc=c+dc;

        if (!inside(nr,nc))
          continue;

        int cap=nr*8+nc;

        if (b.b[cap]!='.' &&
            Character.isUpperCase(b.b[cap])!=white) {

          addPawnMove(
            list,
            from,
            cap,
            white,
            promo
            );
        }

        // en passant
        if (cap==b.ep) {

          Move m=new Move(from,cap);
          m.enPassant=true;
          list.add(m);
        }
      }
    }
  }

  // KNIGHT
  else if (u=='N') {

    int[][] d={
      {2,1},{2,-1},
      {-2,1},{-2,-1},
      {1,2},{1,-2},
      {-1,2},{-1,-2}
    };

    for (int k=0;k<8;k++) {

      int nr=r+d[k][0];
      int nc=c+d[k][1];

      if (!inside(nr,nc))
        continue;

      int to=nr*8+nc;

      if (friendly(b.b[to],white))
        continue;

      list.add(new Move(from,to));
    }
  }

  // BISHOP
  else if (u=='B') {

    addSlides(
      b,list,from,r,c,white,
      new int[][] {
        {1,1},{1,-1},
        {-1,1},{-1,-1}
      }
      );
  }

  // ROOK
  else if (u=='R') {

    addSlides(
      b,list,from,r,c,white,
      new int[][] {
        {1,0},{-1,0},
        {0,1},{0,-1}
      }
      );
  }

  // QUEEN
  else if (u=='Q') {

    addSlides(
      b,list,from,r,c,white,
      new int[][] {
        {1,1},{1,-1},
        {-1,1},{-1,-1},
        {1,0},{-1,0},
        {0,1},{0,-1}
      }
      );
  }

  // KING
  else if (u=='K') {

    for (int dr=-1;dr<=1;dr++) {
      for (int dc=-1;dc<=1;dc++) {

        if (dr==0 && dc==0)
          continue;

        int nr=r+dr;
        int nc=c+dc;

        if (!inside(nr,nc))
          continue;

        int to=nr*8+nc;

        if (!friendly(b.b[to],white))
          list.add(new Move(from,to));
      }
    }

    // castling
    addCastling(b,list,white);
  }

  return list;
}

// ------------------------------------------------------------
// SLIDING PIECES
// ------------------------------------------------------------

void addSlides(
  Board b,
  ArrayList<Move> list,
  int from,
  int r,
  int c,
  boolean white,
  int[][] dirs) {

  for (int d=0;d<dirs.length;d++) {

    int dr=dirs[d][0];
    int dc=dirs[d][1];

    int nr=r+dr;
    int nc=c+dc;

    while (inside(nr,nc)) {

      int to=nr*8+nc;

      if (b.b[to]=='.') {

        list.add(new Move(from,to));

      } else {

        if (!friendly(b.b[to],white))
          list.add(new Move(from,to));

        break;
      }

      nr+=dr;
      nc+=dc;
    }
  }
}

// ------------------------------------------------------------
// PAWN PROMOTION
// ------------------------------------------------------------

void addPawnMove(
  ArrayList<Move> list,
  int from,
  int to,
  boolean white,
  int promoRank) {

  int r=to/8;

  if (r==promoRank) {

    char[] ps=white ?
      new char[]{'Q','R','B','N'} :
      new char[]{'q','r','b','n'};

    for (int i=0;i<4;i++) {

      Move m=new Move(from,to);
      m.promotion=ps[i];

      list.add(m);
    }

  } else {

    list.add(new Move(from,to));
  }
}

// ------------------------------------------------------------
// CASTLING
// ------------------------------------------------------------

void addCastling(
  Board b,
  ArrayList<Move> list,
  boolean white) {

  if (white) {

    // king side
    if (b.wCastleK &&
        b.b[60]=='K' &&
        b.b[61]=='.' &&
        b.b[62]=='.' &&
        b.b[63]=='R') {

      if (!inCheck(b,true) &&
          !attacked(b,61,false) &&
          !attacked(b,62,false)) {

        Move m=new Move(60,62);
        m.castle=true;
        list.add(m);
      }
    }

    // queen side
    if (b.wCastleQ &&
        b.b[60]=='K' &&
        b.b[59]=='.' &&
        b.b[58]=='.' &&
        b.b[57]=='.' &&
        b.b[56]=='R') {

      if (!inCheck(b,true) &&
          !attacked(b,59,false) &&
          !attacked(b,58,false)) {

        Move m=new Move(60,58);
        m.castle=true;
        list.add(m);
      }
    }

  } else {

    // black king side
    if (b.bCastleK &&
        b.b[4]=='k' &&
        b.b[5]=='.' &&
        b.b[6]=='.' &&
        b.b[7]=='r') {

      if (!inCheck(b,false) &&
          !attacked(b,5,true) &&
          !attacked(b,6,true)) {

        Move m=new Move(4,6);
        m.castle=true;
        list.add(m);
      }
    }

    // black queen side
    if (b.bCastleQ &&
        b.b[4]=='k' &&
        b.b[3]=='.' &&
        b.b[2]=='.' &&
        b.b[1]=='.' &&
        b.b[0]=='r') {

      if (!inCheck(b,false) &&
          !attacked(b,3,true) &&
          !attacked(b,2,true)) {

        Move m=new Move(4,2);
        m.castle=true;
        list.add(m);
      }
    }
  }
}

// ------------------------------------------------------------
// MAKE MOVE
// ------------------------------------------------------------

void makeMove(
  Board b,
  Move m) {

  char p=b.b[m.from];
  char target=b.b[m.to];

  boolean white=
    Character.isUpperCase(p);

  // halfmove
  if (Character.toUpperCase(p)=='P' ||
      target!='.' ||
      m.enPassant)
    b.halfmove=0;
  else
    b.halfmove++;

  // en passant target
  b.ep=-1;

  // pawn double move
  if (Character.toUpperCase(p)=='P') {

    if (abs(m.to-m.from)==16)
      b.ep=(m.to+m.from)/2;
  }

  // en passant capture
  if (m.enPassant) {

    if (white)
      b.b[m.to+8]='.';
    else
      b.b[m.to-8]='.';
  }

  // update castling rights because king moves
  if (p=='K') {

    b.wCastleK=false;
    b.wCastleQ=false;
  }

  if (p=='k') {

    b.bCastleK=false;
    b.bCastleQ=false;
  }

  // rook moves
  if (m.from==63) b.wCastleK=false;
  if (m.from==56) b.wCastleQ=false;
  if (m.from==7)  b.bCastleK=false;
  if (m.from==0)  b.bCastleQ=false;

  // rook captured
  if (m.to==63 && target=='R')
    b.wCastleK=false;

  if (m.to==56 && target=='R')
    b.wCastleQ=false;

  if (m.to==7 && target=='r')
    b.bCastleK=false;

  if (m.to==0 && target=='r')
    b.bCastleQ=false;

  // move
  b.b[m.to]=p;
  b.b[m.from]='.';

  // promotion
  if (m.promotion!=0)
    b.b[m.to]=m.promotion;

  // castling rook
  if (m.castle) {

    if (m.to==62) {

      b.b[61]='R';
      b.b[63]='.';

    } else if (m.to==58) {

      b.b[59]='R';
      b.b[56]='.';

    } else if (m.to==6) {

      b.b[5]='r';
      b.b[7]='.';

    } else if (m.to==2) {

      b.b[3]='r';
      b.b[0]='.';
    }
  }

  if (!white)
    b.fullmove++;

  b.whiteTurn=!b.whiteTurn;
}

// ------------------------------------------------------------
// CHECK
// ------------------------------------------------------------

boolean inCheck(
  Board b,
  boolean white) {

  int king=-1;

  char k=white ? 'K' : 'k';

  for (int i=0;i<64;i++) {

    if (b.b[i]==k) {
      king=i;
      break;
    }
  }

  if (king<0)
    return true;

  return attacked(
    b,
    king,
    !white
    );
}

// ------------------------------------------------------------
// ATTACK DETECTION
// ------------------------------------------------------------

boolean attacked(
  Board b,
  int square,
  boolean byWhite) {

  int r=square/8;
  int c=square%8;

  // pawn
  int pawnDir=byWhite ? 1 : -1;

  int pr=r+pawnDir;

  if (inside(pr,c-1)) {

    char p=b.b[pr*8+c-1];

    if (p==(byWhite?'P':'p'))
      return true;
  }

  if (inside(pr,c+1)) {

    char p=b.b[pr*8+c+1];

    if (p==(byWhite?'P':'p'))
      return true;
  }

  // knight
  int[][] nd={
    {2,1},{2,-1},
    {-2,1},{-2,-1},
    {1,2},{1,-2},
    {-1,2},{-1,-2}
  };

  for (int i=0;i<8;i++) {

    int nr=r+nd[i][0];
    int nc=c+nd[i][1];

    if (!inside(nr,nc))
      continue;

    char p=b.b[nr*8+nc];

    if (p==(byWhite?'N':'n'))
      return true;
  }

  // rook / queen
  int[][] rd={
    {1,0},{-1,0},
    {0,1},{0,-1}
  };

  for (int i=0;i<4;i++) {

    int nr=r+rd[i][0];
    int nc=c+rd[i][1];

    while (inside(nr,nc)) {

      char p=b.b[nr*8+nc];

      if (p!='.') {

        if (p==(byWhite?'R':'r') ||
            p==(byWhite?'Q':'q'))
          return true;

        break;
      }

      nr+=rd[i][0];
      nc+=rd[i][1];
    }
  }

  // bishop / queen
  int[][] bd={
    {1,1},{1,-1},
    {-1,1},{-1,-1}
  };

  for (int i=0;i<4;i++) {

    int nr=r+bd[i][0];
    int nc=c+bd[i][1];

    while (inside(nr,nc)) {

      char p=b.b[nr*8+nc];

      if (p!='.') {

        if (p==(byWhite?'B':'b') ||
            p==(byWhite?'Q':'q'))
          return true;

        break;
      }

      nr+=bd[i][0];
      nc+=bd[i][1];
    }
  }

  // king
  for (int dr=-1;dr<=1;dr++) {
    for (int dc=-1;dc<=1;dc++) {

      if (dr==0 && dc==0)
        continue;

      int nr=r+dr;
      int nc=c+dc;

      if (!inside(nr,nc))
        continue;

      if (b.b[nr*8+nc]==
          (byWhite?'K':'k'))
        return true;
    }
  }

  return false;
}

// ------------------------------------------------------------
// MOVE ORDERING
// ------------------------------------------------------------

void orderMoves(
  Board b,
  ArrayList<Move> moves) {

  // simple insertion sort:
  // captures / promotions / castles first

  for (int i=1;i<moves.size();i++) {

    Move key=moves.get(i);

    int kv=moveScore(b,key);

    int j=i-1;

    while (j>=0 &&
           moveScore(b,moves.get(j))<kv) {

      moves.set(j+1,moves.get(j));
      j--;
    }

    moves.set(j+1,key);
  }
}

int moveScore(
  Board b,
  Move m) {

  int s=0;

  char p=b.b[m.from];
  char c=b.b[m.to];

  if (c!='.')
    s+=10000+pieceValue(c)-pieceValue(p)/10;

  if (m.enPassant)
    s+=9500;

  if (m.promotion!=0)
    s+=8000+pieceValue(m.promotion);

  if (m.castle)
    s+=100;

  // center
  int r=m.to/8;
  int col=m.to%8;

  if (r>=2 && r<=5 &&
      col>=2 && col<=5)
    s+=20;

  return s;
}

// ------------------------------------------------------------
// UTILITIES
// ------------------------------------------------------------

boolean inside(int r,int c) {

  return r>=0 && r<8 &&
         c>=0 && c<8;
}

boolean friendly(
  char p,
  boolean white) {

  if (p=='.')
    return false;

  return Character.isUpperCase(p)==white;
}

// ------------------------------------------------------------
// GAME STATE
// ------------------------------------------------------------

void checkGame() {

  ArrayList<Move> moves=
    legalMoves(board);

  if (moves.size()==0) {

    gameOver=true;

    if (inCheck(board,board.whiteTurn)) {

      if (board.whiteTurn)
        info="CHECKMATE - BLACK WINS";
      else
        info="CHECKMATE - WHITE WINS";

    } else {

      info="STALEMATE";
    }

    return;
  }

  // fifty move rule
  if (board.halfmove>=100) {

    gameOver=true;
    info="DRAW - 50 MOVE RULE";
    return;
  }

  // check indication
  if (inCheck(board,board.whiteTurn))
    info=
      (board.whiteTurn ? "WHITE" : "BLACK")
      + " IN CHECK";
  else
    info=
      (board.whiteTurn ? "WHITE" : "BLACK")
      + " TO MOVE";
}

// ------------------------------------------------------------
// MOVE TEXT
// ------------------------------------------------------------

String moveName(Move m) {

  String s=
    squareName(m.from)+
    "-" +
    squareName(m.to);

  if (m.promotion!=0)
    s+="="+
      Character.toUpperCase(m.promotion);

  if (m.castle) {

    if (m.to==62 || m.to==6)
      s="O-O";
    else
      s="O-O-O";
  }

  return s;
}

String squareName(int p) {

  int r=p/8;
  int c=p%8;

  return ""+
    char('a'+c)+
    (8-r);
}

// ------------------------------------------------------------
// OPTIONAL FEN PRINT
// ------------------------------------------------------------

String getFEN() {

  String f="";

  for (int r=0;r<8;r++) {

    int empty=0;

    for (int c=0;c<8;c++) {

      char p=board.b[r*8+c];

      if (p=='.') {

        empty++;

      } else {

        if (empty>0) {
          f+=empty;
          empty=0;
        }

        f+=p;
      }
    }

    if (empty>0)
      f+=empty;

    if (r<7)
      f+="/";
  }

  f+=" ";
  f+=board.whiteTurn ? "w " : "b ";

  String castle="";

  if (board.wCastleK) castle+="K";
  if (board.wCastleQ) castle+="Q";
  if (board.bCastleK) castle+="k";
  if (board.bCastleQ) castle+="q";

  if (castle.length()==0)
    castle="-";

  f+=castle+" ";

  if (board.ep<0)
    f+="-";
  else
    f+=squareName(board.ep);

  f+=" "+board.halfmove;
  f+=" "+board.fullmove;

  return f;
}


// ============================================================
// CHESS.pde
// APDE 0.5.3 / Processing
// ONE FILE
//
// Human = WHITE
// Computer = BLACK
// Search = Alpha-Beta
// Maximum depth = 8 ply
//
// Controls:
// TAP piece -> select
// TAP destination -> move
// NEW GAME -> restart
// ENGINE -> computer move
// DEPTH +/- -> search depth
// ============================================================

final int EMPTY = 0;

final int WHITE = 1;
final int BLACK = -1;

final int PAWN   = 1;
final int KNIGHT = 2;
final int BISHOP = 3;
final int ROOK   = 4;
final int QUEEN  = 5;
final int KING   = 6;

final int INF  = 100000000;
final int MATE = 1000000;

char[] pieces = {
  ' ', 'P', 'N', 'B', 'R', 'Q', 'K',
  'p', 'n', 'b', 'r', 'q', 'k'
};

Board board;

int selected = -1;
ArrayList<Move> selectedMoves;

boolean thinking = false;
boolean gameOver = false;

int searchDepth = 8;

long nodes = 0;
long startThink = 0;
long thinkTime = 9000;

String info = "";
String lastMoveText = "";

float bx, by, sq;

PFont font;

// ------------------------------------------------------------
// MOVE
// ------------------------------------------------------------

class Move {
  int from;
  int to;
  char promotion;

  boolean castle;
  boolean enPassant;

  int captured;

  Move(int f, int t) {
    from = f;
    to = t;
    promotion = 0;
    castle = false;
    enPassant = false;
    captured = 0;
  }

  Move copy() {
    Move m = new Move(from, to);
    m.promotion = promotion;
    m.castle = castle;
    m.enPassant = enPassant;
    m.captured = captured;
    return m;
  }
}

// ------------------------------------------------------------
// BOARD
// ------------------------------------------------------------

class Board {

  char[] b = new char[64];

  boolean wCastleK = true;
  boolean wCastleQ = true;
  boolean bCastleK = true;
  boolean bCastleQ = true;

  int ep = -1;

  boolean whiteTurn = true;

  int halfmove = 0;
  int fullmove = 1;

  Board() {
    reset();
  }

  Board(Board other) {

    for (int i = 0; i < 64; i++)
      b[i] = other.b[i];

    wCastleK = other.wCastleK;
    wCastleQ = other.wCastleQ;
    bCastleK = other.bCastleK;
    bCastleQ = other.bCastleQ;

    ep = other.ep;
    whiteTurn = other.whiteTurn;

    halfmove = other.halfmove;
    fullmove = other.fullmove;
  }

  void reset() {

    for (int i = 0; i < 64; i++)
      b[i] = '.';

    // black
    b[0]='r';
    b[1]='n';
    b[2]='b';
    b[3]='q';
    b[4]='k';
    b[5]='b';
    b[6]='n';
    b[7]='r';

    for (int i=8; i<16; i++)
      b[i]='p';

    // white
    b[56]='R';
    b[57]='N';
    b[58]='B';
    b[59]='Q';
    b[60]='K';
    b[61]='B';
    b[62]='N';
    b[63]='R';

    for (int i=48; i<56; i++)
      b[i]='P';

    wCastleK=true;
    wCastleQ=true;
    bCastleK=true;
    bCastleQ=true;

    ep=-1;
    whiteTurn=true;
    halfmove=0;
    fullmove=1;
  }
}

// ------------------------------------------------------------
// SETUP
// ------------------------------------------------------------

void setup() {

  size(displayWidth, displayHeight);

  font = createFont("SansSerif", 30);
  textFont(font);

  board = new Board();
  selectedMoves = new ArrayList<Move>();

  info = "WHITE TO MOVE";
}

// ------------------------------------------------------------
// DRAW
// ------------------------------------------------------------

void draw() {

  background(25,25,25);

  sq = min(width * 0.94, height * 0.76) / 8.0;

  bx = (width - sq * 8) / 2.0;
  by = 30;

  drawBoard();
  drawPieces();
  drawMoves();
  drawInfo();

  if (thinking) {
    fill(255);
    textAlign(CENTER,CENTER);
    textSize(22);
    text("ENGINE THINKING...", width/2, by+sq*8+75);
  }
}

// ------------------------------------------------------------
// BOARD
// ------------------------------------------------------------

void drawBoard() {

  noStroke();

  for (int r=0; r<8; r++) {

    for (int c=0; c<8; c++) {

      int x = c;
      int y = r;

      if ((r+c)%2==0)
        fill(235,220,180);
      else
        fill(105,135,80);

      rect(bx+c*sq, by+r*sq, sq, sq);
    }
  }

  // coordinates
  fill(30);
  textSize(max(10,sq*0.16));

  for (int i=0;i<8;i++) {

    textAlign(LEFT,BOTTOM);
    text(""+(8-i),
         bx+3,
         by+i*sq+sq-3);

    textAlign(RIGHT,TOP);
    text(""+char('a'+i),
         bx+(i+1)*sq-3,
         by+8*sq-3);
  }

  // selected square
  if (selected>=0) {

    int r=selected/8;
    int c=selected%8;

    noFill();
    stroke(255,215,0);
    strokeWeight(5);

    rect(bx+c*sq+2,
         by+r*sq+2,
         sq-4,
         sq-4);

    noStroke();
  }
}

// ------------------------------------------------------------
// PIECES
// ------------------------------------------------------------

void drawPieces() {

  textAlign(CENTER,CENTER);

  textSize(sq*0.68);

  for (int i=0;i<64;i++) {

    char p=board.b[i];

    if (p=='.')
      continue;

    int r=i/8;
    int c=i%8;

    String s="";

    switch(p) {

    case 'K': s="♔"; break;
    case 'Q': s="♕"; break;
    case 'R': s="♖"; break;
    case 'B': s="♗"; break;
    case 'N': s="♘"; break;
    case 'P': s="♙"; break;

    case 'k': s="♚"; break;
    case 'q': s="♛"; break;
    case 'r': s="♜"; break;
    case 'b': s="♝"; break;
    case 'n': s="♞"; break;
    case 'p': s="♟"; break;
    }

    // outline/shadow
    if (Character.isUpperCase(p))
      fill(250);
    else
      fill(20);

    text(s,
         bx+c*sq+sq/2,
         by+r*sq+sq/2+2);
  }
}

// ------------------------------------------------------------
// LEGAL MOVE MARKERS
// ------------------------------------------------------------

void drawMoves() {

  if (selectedMoves==null)
    return;

  noStroke();

  for (Move m : selectedMoves) {

    int r=m.to/8;
    int c=m.to%8;

    if (board.b[m.to]!='.') {

      noFill();
      stroke(230,50,50);
      strokeWeight(4);

      ellipse(
        bx+c*sq+sq/2,
        by+r*sq+sq/2,
        sq*0.75,
        sq*0.75
        );

      noStroke();

    } else {

      fill(40,40,40,130);

      ellipse(
        bx+c*sq+sq/2,
        by+r*sq+sq/2,
        sq*0.22,
        sq*0.22
        );
    }
  }
}

// ------------------------------------------------------------
// INFORMATION
// ------------------------------------------------------------

void drawInfo() {

  fill(255);
  textAlign(CENTER,CENTER);

  textSize(20);

  String turn =
    board.whiteTurn ? "WHITE" : "BLACK";

  if (!gameOver)
    info = turn + " TO MOVE";

  text(info,width/2,by+sq*8+30);

  textSize(15);

  text(
    "DEPTH " + searchDepth +
    "   NODES " + nodes +
    "   " + lastMoveText,
    width/2,
    by+sq*8+55
    );

  // buttons
  drawButton(
    width*0.05,
    height-55,
    width*0.25,
    42,
    "NEW GAME"
    );

  drawButton(
    width*0.375,
    height-55,
    width*0.25,
    42,
    "ENGINE"
    );

  drawButton(
    width*0.70,
    height-55,
    width*0.12,
    42,
    "-"
    );

  drawButton(
    width*0.84,
    height-55,
    width*0.12,
    42,
    "+"
    );
}

void drawButton(
  float x,
  float y,
  float w,
  float h,
  String s) {

  fill(55,55,55);
  stroke(150);
  strokeWeight(1);

  rect(x,y,w,h,6);

  fill(255);
  textAlign(CENTER,CENTER);
  textSize(15);

  text(s,x+w/2,y+h/2);
}

// ------------------------------------------------------------
// TOUCH
// ------------------------------------------------------------

void mousePressed() {

  if (thinking || gameOver)
    return;

  // new game
  if (mouseY>height-80 &&
      mouseX<width*0.30) {

    board.reset();
    selected=-1;
    selectedMoves.clear();
    gameOver=false;
    info="WHITE TO MOVE";
    lastMoveText="";
    return;
  }

  // engine button
  if (mouseY>height-80 &&
      mouseX>=width*0.35 &&
      mouseX<width*0.65) {

    if (!board.whiteTurn)
      startEngine();

    return;
  }

  // depth -
  if (mouseY>height-80 &&
      mouseX>=width*0.68 &&
      mouseX<width*0.83) {

    searchDepth=max(1,searchDepth-1);
    return;
  }

  // depth +
  if (mouseY>height-80 &&
      mouseX>=width*0.83) {

    searchDepth=min(8,searchDepth+1);
    return;
  }

  if (!board.whiteTurn)
    return;

  if (mouseX<bx ||
      mouseX>bx+sq*8 ||
      mouseY<by ||
      mouseY>by+sq*8)
    return;

  int c=int((mouseX-bx)/sq);
  int r=int((mouseY-by)/sq);

  int pos=r*8+c;

  // choose destination
  if (selected>=0) {

    Move chosen=null;

    for (Move m : selectedMoves) {

      if (m.to==pos) {
        chosen=m;
        break;
      }
    }

    if (chosen!=null) {

      makeMove(board,chosen);

      selected=-1;
      selectedMoves.clear();

      lastMoveText=moveName(chosen);

      checkGame();

      if (!gameOver && !board.whiteTurn)
        startEngine();

      return;
    }
  }

  // select white piece
  char p=board.b[pos];

  if (p!='.' && Character.isUpperCase(p)) {

    selected=pos;

    selectedMoves=legalMovesFor(board,pos);

  } else {

    selected=-1;
    selectedMoves.clear();
  }
}

// ------------------------------------------------------------
// ENGINE
// ------------------------------------------------------------

void startEngine() {

  if (thinking || gameOver)
    return;

  thinking=true;
  nodes=0;
  startThink=millis();

  // Processing draw must return.
  // Engine is executed in a short asynchronous-like sequence.
  // APDE will call draw repeatedly.
}

void engineStep() {

  if (!thinking)
    return;

  thinking=false;

  Move best=searchRoot(
    board,
    searchDepth
    );

  if (best!=null) {

    makeMove(board,best);

    lastMoveText=moveName(best);

    checkGame();
  }
}

// Use mouse release as a convenient APDE event.
// If engine was started, execute it on next frame.
void mouseReleased() {

  if (thinking) {

    // Do not run immediately while touch handling is active.
    delay(20);
    engineStep();
  }
}

// ------------------------------------------------------------
// ROOT SEARCH
// ------------------------------------------------------------

Move searchRoot(Board b, int depth) {

  ArrayList<Move> moves=legalMoves(b);

  if (moves.size()==0)
    return null;

  orderMoves(b,moves);

  Move best=moves.get(0);

  int bestScore= -INF;

  int alpha=-INF;
  int beta=INF;

  for (Move m : moves) {

    Board n=new Board(b);

    makeMove(n,m);

    int score=alphaBeta(
      n,
      depth-1,
      alpha,
      beta
      );

    if (score>bestScore) {

      bestScore=score;
      best=m;
    }

    if (score>alpha)
      alpha=score;

    if (millis()-startThink>thinkTime)
      break;
  }

  return best;
}

// ------------------------------------------------------------
// ALPHA BETA
// ------------------------------------------------------------

int alphaBeta(
  Board b,
  int depth,
  int alpha,
  int beta) {

  nodes++;

  if (millis()-startThink>thinkTime)
    return evaluate(b);

  ArrayList<Move> moves=legalMoves(b);

  if (moves.size()==0) {

    if (inCheck(b,b.whiteTurn))
      return b.whiteTurn ?
        -MATE-depth :
         MATE+depth;

    return 0;
  }

  if (depth<=0)
    return evaluate(b);

  orderMoves(b,moves);

  boolean maximizing=b.whiteTurn;

  if (maximizing) {

    int best=-INF;

    for (Move m:moves) {

      Board n=new Board(b);

      makeMove(n,m);

      int score=alphaBeta(
        n,
        depth-1,
        alpha,
        beta
        );

      best=max(best,score);
      alpha=max(alpha,score);

      if (beta<=alpha)
        break;
    }

    return best;

  } else {

    int best=INF;

    for (Move m:moves) {

      Board n=new Board(b);

      makeMove(n,m);

      int score=alphaBeta(
        n,
        depth-1,
        alpha,
        beta
        );

      best=min(best,score);
      beta=min(beta,score);

      if (beta<=alpha)
        break;
    }

    return best;
  }
}

// ------------------------------------------------------------
// EVALUATION
// ------------------------------------------------------------

int evaluate(Board b) {

  int score=0;

  for (int i=0;i<64;i++) {

    char p=b.b[i];

    if (p=='.')
      continue;

    int v=pieceValue(p);

    // material
    if (Character.isUpperCase(p))
      score+=v;
    else
      score-=v;

    // small positional bonus
    int r=i/8;
    int c=i%8;

    if (p=='P')
      score+=pawnBonus(r,c,true);

    if (p=='p')
      score-=pawnBonus(r,c,false);

    if (p=='N' || p=='B')
      score+=centerBonus(r,c);

    if (p=='n' || p=='b')
      score-=centerBonus(r,c);
  }

  // side to move has a tiny initiative bonus
  if (b.whiteTurn)
    score+=5;
  else
    score-=5;

  return score;
}

int pieceValue(char p) {

  switch(Character.toUpperCase(p)) {

  case 'P': return 100;
  case 'N': return 320;
  case 'B': return 330;
  case 'R': return 500;
  case 'Q': return 900;
  case 'K': return 20000;
  }

  return 0;
}

int centerBonus(int r,int c) {

  int d=abs(3-r)+abs(3-c);

  return max(0,12-d*3);
}

int pawnBonus(
  int r,
  int c,
  boolean white) {

  if (white)
    return (6-r)*4;
  else
    return (r-1)*4;
}

// ------------------------------------------------------------
// MOVE GENERATION
// ------------------------------------------------------------

ArrayList<Move> legalMoves(Board b) {

  ArrayList<Move> all=new ArrayList<Move>();

  for (int i=0;i<64;i++) {

    char p=b.b[i];

    if (p=='.')
      continue;

    boolean white=
      Character.isUpperCase(p);

    if (white!=b.whiteTurn)
      continue;

    ArrayList<Move> pm=
      pseudoMoves(b,i);

    for (Move m:pm) {

      Board n=new Board(b);

      makeMove(n,m);

      if (!inCheck(n,white))
        all.add(m);
    }
  }

  return all;
}

ArrayList<Move> legalMovesFor(
  Board b,
  int from) {

  ArrayList<Move> result=
    new ArrayList<Move>();

  char p=b.b[from];

  if (p=='.')
    return result;

  boolean white=
    Character.isUpperCase(p);

  if (white!=b.whiteTurn)
    return result;

  ArrayList<Move> pm=
    pseudoMoves(b,from);

  for (Move m:pm) {

    Board n=new Board(b);

    makeMove(n,m);

    if (!inCheck(n,white))
      result.add(m);
  }

  return result;
}

// ------------------------------------------------------------
// PSEUDO MOVES
// ------------------------------------------------------------

ArrayList<Move> pseudoMoves(
  Board b,
  int from) {

  ArrayList<Move> list=
    new ArrayList<Move>();

  char p=b.b[from];

  if (p=='.')
    return list;

  boolean white=
    Character.isUpperCase(p);

  int r=from/8;
  int c=from%8;

  char u=Character.toUpperCase(p);

  // PAWN
  if (u=='P') {

    int dir=white ? -1 : 1;
    int start=white ? 6 : 1;
    int promo=white ? 0 : 7;

    int nr=r+dir;

    if (inside(nr,c)) {

      int to=nr*8+c;

      if (b.b[to]=='.') {

        addPawnMove(list,from,to,white,promo);

        if (r==start) {

          int nr2=r+dir*2;
          int to2=nr2*8+c;

          if (b.b[to2]=='.') {

            Move m=new Move(from,to2);
            list.add(m);
          }
        }
      }

      // captures
      for (int dc=-1;dc<=1;dc+=2) {

        int nc=c+dc;

        if (!inside(nr,nc))
          continue;

        int cap=nr*8+nc;

        if (b.b[cap]!='.' &&
            Character.isUpperCase(b.b[cap])!=white) {

          addPawnMove(
            list,
            from,
            cap,
            white,
            promo
            );
        }

        // en passant
        if (cap==b.ep) {

          Move m=new Move(from,cap);
          m.enPassant=true;
          list.add(m);
        }
      }
    }
  }

  // KNIGHT
  else if (u=='N') {

    int[][] d={
      {2,1},{2,-1},
      {-2,1},{-2,-1},
      {1,2},{1,-2},
      {-1,2},{-1,-2}
    };

    for (int k=0;k<8;k++) {

      int nr=r+d[k][0];
      int nc=c+d[k][1];

      if (!inside(nr,nc))
        continue;

      int to=nr*8+nc;

      if (friendly(b.b[to],white))
        continue;

      list.add(new Move(from,to));
    }
  }

  // BISHOP
  else if (u=='B') {

    addSlides(
      b,list,from,r,c,white,
      new int[][] {
        {1,1},{1,-1},
        {-1,1},{-1,-1}
      }
      );
  }

  // ROOK
  else if (u=='R') {

    addSlides(
      b,list,from,r,c,white,
      new int[][] {
        {1,0},{-1,0},
        {0,1},{0,-1}
      }
      );
  }

  // QUEEN
  else if (u=='Q') {

    addSlides(
      b,list,from,r,c,white,
      new int[][] {
        {1,1},{1,-1},
        {-1,1},{-1,-1},
        {1,0},{-1,0},
        {0,1},{0,-1}
      }
      );
  }

  // KING
  else if (u=='K') {

    for (int dr=-1;dr<=1;dr++) {
      for (int dc=-1;dc<=1;dc++) {

        if (dr==0 && dc==0)
          continue;

        int nr=r+dr;
        int nc=c+dc;

        if (!inside(nr,nc))
          continue;

        int to=nr*8+nc;

        if (!friendly(b.b[to],white))
          list.add(new Move(from,to));
      }
    }

    // castling
    addCastling(b,list,white);
  }

  return list;
}

// ------------------------------------------------------------
// SLIDING PIECES
// ------------------------------------------------------------

void addSlides(
  Board b,
  ArrayList<Move> list,
  int from,
  int r,
  int c,
  boolean white,
  int[][] dirs) {

  for (int d=0;d<dirs.length;d++) {

    int dr=dirs[d][0];
    int dc=dirs[d][1];

    int nr=r+dr;
    int nc=c+dc;

    while (inside(nr,nc)) {

      int to=nr*8+nc;

      if (b.b[to]=='.') {

        list.add(new Move(from,to));

      } else {

        if (!friendly(b.b[to],white))
          list.add(new Move(from,to));

        break;
      }

      nr+=dr;
      nc+=dc;
    }
  }
}

// ------------------------------------------------------------
// PAWN PROMOTION
// ------------------------------------------------------------

void addPawnMove(
  ArrayList<Move> list,
  int from,
  int to,
  boolean white,
  int promoRank) {

  int r=to/8;

  if (r==promoRank) {

    char[] ps=white ?
      new char[]{'Q','R','B','N'} :
      new char[]{'q','r','b','n'};

    for (int i=0;i<4;i++) {

      Move m=new Move(from,to);
      m.promotion=ps[i];

      list.add(m);
    }

  } else {

    list.add(new Move(from,to));
  }
}

// ------------------------------------------------------------
// CASTLING
// ------------------------------------------------------------

void addCastling(
  Board b,
  ArrayList<Move> list,
  boolean white) {

  if (white) {

    // king side
    if (b.wCastleK &&
        b.b[60]=='K' &&
        b.b[61]=='.' &&
        b.b[62]=='.' &&
        b.b[63]=='R') {

      if (!inCheck(b,true) &&
          !attacked(b,61,false) &&
          !attacked(b,62,false)) {

        Move m=new Move(60,62);
        m.castle=true;
        list.add(m);
      }
    }

    // queen side
    if (b.wCastleQ &&
        b.b[60]=='K' &&
        b.b[59]=='.' &&
        b.b[58]=='.' &&
        b.b[57]=='.' &&
        b.b[56]=='R') {

      if (!inCheck(b,true) &&
          !attacked(b,59,false) &&
          !attacked(b,58,false)) {

        Move m=new Move(60,58);
        m.castle=true;
        list.add(m);
      }
    }

  } else {

    // black king side
    if (b.bCastleK &&
        b.b[4]=='k' &&
        b.b[5]=='.' &&
        b.b[6]=='.' &&
        b.b[7]=='r') {

      if (!inCheck(b,false) &&
          !attacked(b,5,true) &&
          !attacked(b,6,true)) {

        Move m=new Move(4,6);
        m.castle=true;
        list.add(m);
      }
    }

    // black queen side
    if (b.bCastleQ &&
        b.b[4]=='k' &&
        b.b[3]=='.' &&
        b.b[2]=='.' &&
        b.b[1]=='.' &&
        b.b[0]=='r') {

      if (!inCheck(b,false) &&
          !attacked(b,3,true) &&
          !attacked(b,2,true)) {

        Move m=new Move(4,2);
        m.castle=true;
        list.add(m);
      }
    }
  }
}

// ------------------------------------------------------------
// MAKE MOVE
// ------------------------------------------------------------

void makeMove(
  Board b,
  Move m) {

  char p=b.b[m.from];
  char target=b.b[m.to];

  boolean white=
    Character.isUpperCase(p);

  // halfmove
  if (Character.toUpperCase(p)=='P' ||
      target!='.' ||
      m.enPassant)
    b.halfmove=0;
  else
    b.halfmove++;

  // en passant target
  b.ep=-1;

  // pawn double move
  if (Character.toUpperCase(p)=='P') {

    if (abs(m.to-m.from)==16)
      b.ep=(m.to+m.from)/2;
  }

  // en passant capture
  if (m.enPassant) {

    if (white)
      b.b[m.to+8]='.';
    else
      b.b[m.to-8]='.';
  }

  // update castling rights because king moves
  if (p=='K') {

    b.wCastleK=false;
    b.wCastleQ=false;
  }

  if (p=='k') {

    b.bCastleK=false;
    b.bCastleQ=false;
  }

  // rook moves
  if (m.from==63) b.wCastleK=false;
  if (m.from==56) b.wCastleQ=false;
  if (m.from==7)  b.bCastleK=false;
  if (m.from==0)  b.bCastleQ=false;

  // rook captured
  if (m.to==63 && target=='R')
    b.wCastleK=false;

  if (m.to==56 && target=='R')
    b.wCastleQ=false;

  if (m.to==7 && target=='r')
    b.bCastleK=false;

  if (m.to==0 && target=='r')
    b.bCastleQ=false;

  // move
  b.b[m.to]=p;
  b.b[m.from]='.';

  // promotion
  if (m.promotion!=0)
    b.b[m.to]=m.promotion;

  // castling rook
  if (m.castle) {

    if (m.to==62) {

      b.b[61]='R';
      b.b[63]='.';

    } else if (m.to==58) {

      b.b[59]='R';
      b.b[56]='.';

    } else if (m.to==6) {

      b.b[5]='r';
      b.b[7]='.';

    } else if (m.to==2) {

      b.b[3]='r';
      b.b[0]='.';
    }
  }

  if (!white)
    b.fullmove++;

  b.whiteTurn=!b.whiteTurn;
}

// ------------------------------------------------------------
// CHECK
// ------------------------------------------------------------

boolean inCheck(
  Board b,
  boolean white) {

  int king=-1;

  char k=white ? 'K' : 'k';

  for (int i=0;i<64;i++) {

    if (b.b[i]==k) {
      king=i;
      break;
    }
  }

  if (king<0)
    return true;

  return attacked(
    b,
    king,
    !white
    );
}

// ------------------------------------------------------------
// ATTACK DETECTION
// ------------------------------------------------------------

boolean attacked(
  Board b,
  int square,
  boolean byWhite) {

  int r=square/8;
  int c=square%8;

  // pawn
  int pawnDir=byWhite ? 1 : -1;

  int pr=r+pawnDir;

  if (inside(pr,c-1)) {

    char p=b.b[pr*8+c-1];

    if (p==(byWhite?'P':'p'))
      return true;
  }

  if (inside(pr,c+1)) {

    char p=b.b[pr*8+c+1];

    if (p==(byWhite?'P':'p'))
      return true;
  }

  // knight
  int[][] nd={
    {2,1},{2,-1},
    {-2,1},{-2,-1},
    {1,2},{1,-2},
    {-1,2},{-1,-2}
  };

  for (int i=0;i<8;i++) {

    int nr=r+nd[i][0];
    int nc=c+nd[i][1];

    if (!inside(nr,nc))
      continue;

    char p=b.b[nr*8+nc];

    if (p==(byWhite?'N':'n'))
      return true;
  }

  // rook / queen
  int[][] rd={
    {1,0},{-1,0},
    {0,1},{0,-1}
  };

  for (int i=0;i<4;i++) {

    int nr=r+rd[i][0];
    int nc=c+rd[i][1];

    while (inside(nr,nc)) {

      char p=b.b[nr*8+nc];

      if (p!='.') {

        if (p==(byWhite?'R':'r') ||
            p==(byWhite?'Q':'q'))
          return true;

        break;
      }

      nr+=rd[i][0];
      nc+=rd[i][1];
    }
  }

  // bishop / queen
  int[][] bd={
    {1,1},{1,-1},
    {-1,1},{-1,-1}
  };

  for (int i=0;i<4;i++) {

    int nr=r+bd[i][0];
    int nc=c+bd[i][1];

    while (inside(nr,nc)) {

      char p=b.b[nr*8+nc];

      if (p!='.') {

        if (p==(byWhite?'B':'b') ||
            p==(byWhite?'Q':'q'))
          return true;

        break;
      }

      nr+=bd[i][0];
      nc+=bd[i][1];
    }
  }

  // king
  for (int dr=-1;dr<=1;dr++) {
    for (int dc=-1;dc<=1;dc++) {

      if (dr==0 && dc==0)
        continue;

      int nr=r+dr;
      int nc=c+dc;

      if (!inside(nr,nc))
        continue;

      if (b.b[nr*8+nc]==
          (byWhite?'K':'k'))
        return true;
    }
  }

  return false;
}

// ------------------------------------------------------------
// MOVE ORDERING
// ------------------------------------------------------------

void orderMoves(
  Board b,
  ArrayList<Move> moves) {

  // simple insertion sort:
  // captures / promotions / castles first

  for (int i=1;i<moves.size();i++) {

    Move key=moves.get(i);

    int kv=moveScore(b,key);

    int j=i-1;

    while (j>=0 &&
           moveScore(b,moves.get(j))<kv) {

      moves.set(j+1,moves.get(j));
      j--;
    }

    moves.set(j+1,key);
  }
}

int moveScore(
  Board b,
  Move m) {

  int s=0;

  char p=b.b[m.from];
  char c=b.b[m.to];

  if (c!='.')
    s+=10000+pieceValue(c)-pieceValue(p)/10;

  if (m.enPassant)
    s+=9500;

  if (m.promotion!=0)
    s+=8000+pieceValue(m.promotion);

  if (m.castle)
    s+=100;

  // center
  int r=m.to/8;
  int col=m.to%8;

  if (r>=2 && r<=5 &&
      col>=2 && col<=5)
    s+=20;

  return s;
}

// ------------------------------------------------------------
// UTILITIES
// ------------------------------------------------------------

boolean inside(int r,int c) {

  return r>=0 && r<8 &&
         c>=0 && c<8;
}

boolean friendly(
  char p,
  boolean white) {

  if (p=='.')
    return false;

  return Character.isUpperCase(p)==white;
}

// ------------------------------------------------------------
// GAME STATE
// ------------------------------------------------------------

void checkGame() {

  ArrayList<Move> moves=
    legalMoves(board);

  if (moves.size()==0) {

    gameOver=true;

    if (inCheck(board,board.whiteTurn)) {

      if (board.whiteTurn)
        info="CHECKMATE - BLACK WINS";
      else
        info="CHECKMATE - WHITE WINS";

    } else {

      info="STALEMATE";
    }

    return;
  }

  // fifty move rule
  if (board.halfmove>=100) {

    gameOver=true;
    info="DRAW - 50 MOVE RULE";
    return;
  }

  // check indication
  if (inCheck(board,board.whiteTurn))
    info=
      (board.whiteTurn ? "WHITE" : "BLACK")
      + " IN CHECK";
  else
    info=
      (board.whiteTurn ? "WHITE" : "BLACK")
      + " TO MOVE";
}

// ------------------------------------------------------------
// MOVE TEXT
// ------------------------------------------------------------

String moveName(Move m) {

  String s=
    squareName(m.from)+
    "-" +
    squareName(m.to);

  if (m.promotion!=0)
    s+="="+
      Character.toUpperCase(m.promotion);

  if (m.castle) {

    if (m.to==62 || m.to==6)
      s="O-O";
    else
      s="O-O-O";
  }

  return s;
}

String squareName(int p) {

  int r=p/8;
  int c=p%8;

  return ""+
    char('a'+c)+
    (8-r);
}

// ------------------------------------------------------------
// OPTIONAL FEN PRINT
// ------------------------------------------------------------

String getFEN() {

  String f="";

  for (int r=0;r<8;r++) {

    int empty=0;

    for (int c=0;c<8;c++) {

      char p=board.b[r*8+c];

      if (p=='.') {

        empty++;

      } else {

        if (empty>0) {
          f+=empty;
          empty=0;
        }

        f+=p;
      }
    }

    if (empty>0)
      f+=empty;

    if (r<7)
      f+="/";
  }

  f+=" ";
  f+=board.whiteTurn ? "w " : "b ";

  String castle="";

  if (board.wCastleK) castle+="K";
  if (board.wCastleQ) castle+="Q";
  if (board.bCastleK) castle+="k";
  if (board.bCastleQ) castle+="q";

  if (castle.length()==0)
    castle="-";

  f+=castle+" ";

  if (board.ep<0)
    f+="-";
  else
    f+=squareName(board.ep);

  f+=" "+board.halfmove;
  f+=" "+board.fullmove;

  return f;
}











*/




































