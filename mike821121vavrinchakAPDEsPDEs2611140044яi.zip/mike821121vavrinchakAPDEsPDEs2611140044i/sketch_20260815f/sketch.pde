

// MARIO-STYLE PLATFORM GAME FOR APDE
// Processing Java / APDE
// Landscape screen

float px, py;
float vx = 0;
float vy = 0;

float playerW = 42;
float playerH = 58;

boolean left = false;
boolean right = false;
boolean jump = false;

boolean onGround = false;

float cameraX = 0;

int coins = 0;
int lives = 3;

final float GRAVITY = 0.65;
final float MOVE = 0.55;
final float MAX_SPEED = 7;
final float JUMP_POWER = -13;

int WORLD_W = 12000;

// Platforms
float[] platformX = {
  0, 500, 850, 1200, 1600, 2050, 2450,
  2900, 3350, 3800, 4300, 4750, 5200,
  5700, 6200, 6700, 7200, 7700, 8300,
  8900, 9500, 10100, 10800, 11400
};

float[] platformY = {
  650, 550, 600, 500, 620, 530, 450,
  600, 500, 420, 580, 480, 400,
  550, 450, 350, 520, 430, 330,
  550, 450, 380, 500
};

float[] platformW = {
  500, 300, 350, 350, 400, 300, 300,
  350, 300, 350, 400, 300, 350,
  400, 300, 350, 400, 300, 350,
  400, 300, 350, 500
};

// Coins
float[] coinX = new float[100];
float[] coinY = new float[100];
boolean[] coinTaken = new boolean[100];

// Enemies
float[] enemyX = new float[30];
float[] enemyY = new float[30];
float[] enemyV = new float[30];
boolean[] enemyAlive = new boolean[30];

 //  
 void settings() { fullScreen(P2D);   }

void setup() {


//fullScreen(P2D);

//size(700,400,P2D);


 /// orientation(LANDSCAPE);




  px = 100;
  py = 500;

  // Coins
  for (int i = 0; i < coinX.length - 1; i++) {
    coinX[i] = 300 + i * 115;
    coinY[i] = 350 + random(-80, 80);
    coinTaken[i] = false;
  }

  // Enemies
  for (int i = 0; i < enemyX.length - 1; i++) {
    enemyX[i] = 700 + i * 380;
    enemyY[i] = 480;
    enemyV[i] = random(1.0, 2.2);
    enemyAlive[i] = true;
  }
}







void draw() {

  // SKY
  background(80, 180, 255);

  // Camera follows player
  cameraX = px - width * 0.35;

  if (cameraX < 0) cameraX = 0;
  if (cameraX > WORLD_W - width)
    cameraX = WORLD_W - width;

  pushMatrix();
  translate(-cameraX, 0);




/*   */

 // errdrawWorld/////lenghth-1/////


////       
 drawWorld();






  drawCoins();
  drawEnemies();
  drawPlayer();

/*    */







  popMatrix();

  drawHUD();

  updateGame();
}
























void drawWorld() {

////erris////




  // Clouds
  noStroke();
  fill(255);

  for (int i = 0; i < 30    ; i++) {
    float cx = i * 500 + 100;
    ellipse(cx, 100 + (i % 3) * 40, 100, 50);
    ellipse(cx + 50, 90 + (i % 3) * 40, 120, 60);
    ellipse(cx + 100, 105 + (i % 3) * 40, 90, 45);
  }

  // Ground
  fill(90, 190, 70);
  rect(0, 700, WORLD_W, 100);

  fill(130, 80, 40);
  rect(0, 740, WORLD_W, 100);

  // Platforms
  for (int i = 0; i < platformX.length -1; i++) {

    fill(70, 190, 70);
    rect(platformX[i], platformY[i],
         platformW[i], 25);

    fill(150, 90, 45);
    rect(platformX[i],
         platformY[i] + 25,
         platformW[i], 35);
  }

  // Trees
  for (int i = 0; i < (WORLD_W - 1)/ 350; i++) {

    float tx = i * 350 + 100;

    fill(100, 60, 30);
    rect(tx, 550, 35, 150);

    fill(30, 150, 50);
    ellipse(tx + 15, 520, 120, 120);
    ellipse(tx - 25, 550, 100, 100);
    ellipse(tx + 55, 550, 100, 100);
  }
}




























void drawPlayer() {

  pushMatrix();
  translate(px, py);

  // Body
  fill(0, 80, 220);
  rect(5, 20, 32, 35);

  // Head
  fill(255, 190, 130);
  ellipse(21, 15, 34, 34);

  // Hat
  fill(220, 20, 20);
  rect(3, 0, 36, 12);
  ellipse(21, 5, 40, 15);

  // Shirt
  fill(220, 20, 20);
  rect(8, 25, 26, 20);

  // Legs
  fill(100, 50, 30);
  rect(5, 50, 13, 10);
  rect(24, 50, 13, 10);

  // Eyes
  fill(0);
  ellipse(27, 14, 4, 5);

  popMatrix();
}

void drawCoins() {

  for (int i = 0; i < coinX.length - 1; i++) {

    if (!coinTaken[i]) {

      fill(255, 220, 0);
      ellipse(coinX[i], coinY[i], 25, 25);

      fill(255, 245, 100);
      ellipse(coinX[i] - 4,
              coinY[i] - 4,
              8, 8);
    }
  }
}

void drawEnemies() {

  for (int i = 0; i < enemyX.length - 1; i++) {

    if (!enemyAlive[i]) continue;

    fill(120, 70, 30);
    ellipse(enemyX[i], enemyY[i], 45, 35);

    fill(255);
    ellipse(enemyX[i] - 10,
            enemyY[i] - 5,
            10, 12);

    ellipse(enemyX[i] + 10,
            enemyY[i] - 5,
            10, 12);

    fill(0);
    ellipse(enemyX[i] - 10,
            enemyY[i] - 5,
            4, 5);

    ellipse(enemyX[i] + 10,
            enemyY[i] - 5,
            4, 5);
  }
}

void updateGame() {

  // Horizontal movement
  if (left) vx -= MOVE;
  if (right) vx += MOVE;

  if (!left && !right) {
    vx *= 0.82;
  }

  vx = constrain(vx, -MAX_SPEED, MAX_SPEED);

  px += vx;

  // Gravity
  vy += GRAVITY;
  py += vy;

  onGround = false;

  // Ground
  if (py + playerH >= 700) {
    py = 700 - playerH;
    vy = 0;
    onGround = true;
  }

  // Platforms
  for (int i = 0; i < platformX.length - 1; i++) {

    if (px + playerW > platformX[i] &&
        px < platformX[i] + platformW[i] &&
        py + playerH <= platformY[i] + 15 &&
        py + playerH + vy >= platformY[i]) {

      py = platformY[i] - playerH;
      vy = 0;
      onGround = true;
    }
  }

  // Jump
  if (jump && onGround) {
    vy = JUMP_POWER;
    onGround = false;
  }

  jump = false;

  // World boundaries
  if (px < 0) px = 0;

  if (px > WORLD_W - playerW)
    px = WORLD_W - playerW;

  // Coins
  for (int i = 0; i < coinX.length - 1; i++) {

    if (!coinTaken[i] &&
        dist(px + playerW/2,
             py + playerH/2,
             coinX[i],
             coinY[i]) < 40) {

      coinTaken[i] = true;
      coins++;
    }
  }

  // Enemies
  for (int i = 0; i < enemyX.length - 1; i++) {

    if (!enemyAlive[i]) continue;

    enemyX[i] += enemyV[i];

    // Turn around
    if (enemyX[i] < 0 ||
        enemyX[i] > WORLD_W) {

      enemyV[i] *= -1;
    }

    // Player collision
    if (abs(px - enemyX[i]) < 40 &&
        abs((py + playerH) -
            enemyY[i]) < 40) {

      // Jump on enemy
      if (vy > 0 &&
          py + playerH < enemyY[i] + 15) {

        enemyAlive[i] = false;
        vy = -9;
        coins += 5;

      } else {

        loseLife();
      }
    }
  }

  // Fall into hole
  if (py > height + 200) {
    loseLife();
  }
}

void loseLife() {

  lives--;

  px = max(100, px - 300);
  py = 300;
  vx = 0;
  vy = 0;

  if (lives <= 0) {

    lives = 3;
    coins = 0;

    px = 100;

    for (int i = 0; i < coinTaken.length - 1; i++)
      coinTaken[i] = false;

    for (int i = 0; i < enemyAlive.length - 1; i++)
      enemyAlive[i] = true;
  }
}

void drawHUD() {

  fill(0, 150);
  rect(0, 0, width, 70);

  fill(255);
  textSize(28);

  text("COINS: " + coins, 25, 42);
  text("LIVES: " + lives, 200, 42);

  text("<-  - >   MOVE     JUMP", width - 330, 42);
}

// TOUCH CONTROLS
void touchStarted() {

  if (mouseY > height * 0.55) {

    if (mouseX < width * 0.30)
      left = true;

    else if (mouseX < width * 0.60)
      right = true;

    else
      jump = true;
  }
}

void touchMoved() {

  if (mouseY > height * 0.55) {

    if (mouseX < width * 0.30) {
      left = true;
      right = false;
    }

    else if (mouseX < width * 0.60) {
      right = true;
      left = false;
    }
  }
}

void touchEnded() {
  left = false;
  right = false;
}

// KEYBOARD
void keyPressed() {

  if (keyCode == LEFT)
    left = true;

  if (keyCode == RIGHT)
    right = true;

  if (keyCode == UP ||
      key == ' ')

    jump = true;
}

void keyReleased() {

  if (keyCode == LEFT)
    left = false;

  if (keyCode == RIGHT)
    right = false;
}
















































