

// Кількість елементів
int numSquares = 111;
int numTriangles = 111;
int numDigits = 15; // Кількість цифр на екрані

Circle player;
ArrayList<Shape> shapes = new ArrayList<Shape>();
ArrayList<Digit> digits = new ArrayList<Digit>();
GradientPoint[] gradients = new GradientPoint[5];

void setup() {
  size(1000, 700);
  frameRate(60);
  colorMode(HSB, 360, 100, 100);
  
  // Ініціалізація круга (гравця)
  player = new Circle(width/2, height/2);
  
  // Створення 111 квадратів та 111 трикутників
  for (int i = 0; i < numSquares; i++) shapes.add(new Shape(0)); // 0 - квадрат
  for (int i = 0; i < numTriangles; i++) shapes.add(new Shape(1)); // 1 - трикутник
  
  // Створення цифр
  for (int i = 0; i < numDigits; i++) digits.add(new Digit());
  
  // Тіні/точки для рухомого темного градієнту
  for (int i = 0; i < gradients.length; i++) gradients[i] = new GradientPoint();
}

void draw() {
  // 1. Малювання рухомого темного градієнту (75%-95% темноти -> яскравість 5-25)
  loadPixels();
  for (int y = 0; y < height; y++) {
    for (int x = 0; x < width; x++) {
      float totalBright = 0;
      for (GradientPoint g : gradients) {
        float d = dist(x, y, g.x, g.y);
        totalBright += map(d, 0, width, 25, 5); // чим ближче, тим світліше (у межах темного)
      }
      float b = constrain(totalBright / gradients.length, 5, 25);
      pixels[x + y * width] = color(220, 40, b); // Темно-синій відтінок градієнту
    }
  }
  updatePixels();
  
  // Оновлення точок градієнту
  for (GradientPoint g : gradients) g.update();

  // 2. Оновлення та малювання цифр
  for (Digit d : digits) {
    d.update();
    d.display();
  }

  // 3. Оновлення та малювання фігур (квадрати і трикутники)
  for (int i = 0; i < shapes.size(); i++) {
    Shape s1 = shapes.get(i);
    s1.update();
    
    // Відбивання від стін
    s1.checkEdges();
    
    // Відбивання між фігурами (фізично правильне векторне відбивання)
    for (int j = i + 1; j < shapes.size(); j++) {
      Shape s2 = shapes.get(j);
      float minDist = (s1.size + s2.size) / 2;
      if (dist(s1.x, s1.y, s2.x, s2.y) < minDist) {
        s1.bounce(s2);
      }
    }
    
    // Відбивання з кругом гравця
    float dToPlayer = dist(s1.x, s1.y, player.x, player.y);
    if (dToPlayer < (s1.size/2 + player.r)) {
      s1.bounceWithCircle(player);
    }
    
    s1.display();
  }

  // 4. Оновлення та малювання круга (гравця)
  player.update();
  player.checkEdges();
  player.checkDigitCollision(digits);
  player.display();
}

// КЛАС КРУГА (ГРАВЦЯ)
class Circle {
  float x, y, r, angle, speed;
  int score;
  color col, textColor;
  int lastColTime, lastTextColTime, cooldownTime;
  boolean canScore = true;

  Circle(float x, float y) {
    this.x = x;
    this.y = y;
    this.r = 20;
    this.angle = random(TWO_PI);
    this.speed = 0.5; // Рух пів пікселя за цикл
    this.score = 0;
    updateColor();
    updateTextColor();
    lastColTime = millis();
    lastTextColTime = millis();
  }

  void update() {
    // Зміна кута за мишкою (середнє між старим кутом і кутом до мишки)
    float angleToMouse = atan2(mouseY - y, mouseX - x);
    
    // Правильне усереднення кутів без стрибків через PI/-PI
    angle = angle + atan2(sin(angleToMouse - angle), cos(angleToMouse - angle)) * 0.5;

    x += cos(angle) * speed;
    y += sin(angle) * speed;

    // Таймер зміни кольору круга (кожні 5 секунд, не світлий, не темний)
    if (millis() - lastColTime > 5000) {
      updateColor();
      lastColTime = millis();
    }
    // Таймер зміни кольору цифри круга (кожні 2 секунди)
    if (millis() - lastTextColTime > 2000) {
      updateTextColor();
      lastTextColTime = millis();
    }
    // Таймер кулдауну додавання цифр (3 секунди)
    if (!canScore && millis() - cooldownTime > 3000) {
      canScore = true;
    }
  }

  void updateColor() {
    col = color(random(360), random(50, 70), random(40, 60)); // Середні тони
  }

  void updateTextColor() {
    textColor = color(random(360), random(70, 100), random(70, 100));
  }

  void checkEdges() {
    if (x - r < 0) { x = r; angle = PI - angle; }
    if (x + r > width) { x = width - r; angle = PI - angle; }
    if (y - r < 0) { y = r; angle = -angle; }
    if (y + r > height) { y = height - r; angle = -angle; }
  }

  void checkDigitCollision(ArrayList<Digit> digitsList) {
    if (!canScore) return;
    for (Digit d : digitsList) {
      if (dist(x, y, d.x, d.y) < r + 10) {
        score += d.value;
        canScore = false;
        cooldownTime = millis();
        d.randomizePosition(); // Переносимо цифру в інше місце
        break;
      }
    }
  }

  void display() {
    fill(col);
    noStroke();
    ellipse(x, y, r * 2, r * 2);
    
    // Відображення числа на крузі
    fill(textColor);
    textAlign(CENTER, CENTER);
    textSize(16);
    text(score, x, y);
    
    // Індикатор кулдауну (маленька цятка, якщо не може додавати)
    if (!canScore) {
      fill(0, 100, 100);
      ellipse(x, y - r - 5, 5, 5);
    }
  }
}

// КЛАС КВАДРАТІВ ТА ТРИКУТНИКІВ
class Shape {
  float x, y, vx, vy, angle, rotSpeed, size;
  int type; // 0 - квадрат, 1 - трикутник
  color col;
  int lastColorTime;
  int changeInterval;

  Shape(int type) {
    this.type = type;
    this.x = random(50, width - 50);
    this.y = random(50, height - 50);
    this.size = 18;
    this.angle = random(TWO_PI);
    this.rotSpeed = random(-0.015, 0.015); // Менше градуса (~0.017 радіан)
    
    // Швидкість: 1/11 пікселя + рандомний зсув (макс від 3/11 до 6/11)
    float baseSpeed = 1.0 / 11.0;
    float maxSpeed = random(3.0 / 11.0, 6.0 / 11.0);
    float angleMove = random(TWO_PI);
    float speed = constrain(baseSpeed + random(-0.05, 0.15), baseSpeed, maxSpeed);
    this.vx = cos(angleMove) * speed;
    this.vy = sin(angleMove) * speed;
    
    this.changeInterval = (type == 0) ? 9000 : 15000; // 9с для квадратів, 15с для трикутників
    updateColor();
    lastColorTime = millis();
  }

  void update() {
    x += vx;
    y += vy;
    angle += rotSpeed;

    if (millis() - lastColorTime > changeInterval) {
      updateColor();
      lastColorTime = millis();
    }
  }

  void updateColor() {
    col = color(random(360), random(10, 40), random(80, 100)); // Лише світлі тони
  }

  void checkEdges() {
    if (x - size/2 < 0) { x = size/2; vx *= -1; }
    if (x + size/2 > width) { x = width - size/2; vx *= -1; }
    if (y - size/2 < 0) { y = size/2; vy *= -1; }
    if (y + size/2 > height) { y = height - size/2; vy *= -1; }
  }

  // Фізично правильне відбивання (Векторне відбивання пружних тіл)
  void bounce(Shape other) {
    float dx = other.x - this.x;
    float dy = other.y - this.y;
    float distance = sqrt(dx*dx + dy*dy);
    if (distance == 0) return;
    
    // Нормаль і тангенс
    float nx = dx / distance;
    float ny = dy / distance;
    
    // Розділення швидкостей на нормальні та тангенціальні
    float kx = this.vx - other.vx;
    float ky = this.vy - other.vy;
    float p = nx * kx + ny * ky;
    
    if (p > 0) { // Рухаються назустріч
      this.vx -= p * nx;
      this.vy -= p * ny;
      other.vx += p * nx;
      other.vy += p * ny;
    }
  }

  void bounceWithCircle(Circle c) {
    float dx = c.x - this.x;
    float dy = c.y - this.y;
    float distance = sqrt(dx*dx + dy*dy);
    if (distance == 0) return;
    
    float nx = dx / distance;
    float ny = dy / distance;
    
    // Відбиваємо фігуру від круга, як від статичної стіни (бо швидкість круга задається мишкою)
    float dot = this.vx * nx + this.vy * ny;
    this.vx -= 2 * dot * nx;
    this.vy -= 2 * dot * ny;
  }

  void display() {
    fill(col);
    noStroke();
    pushMatrix();
    translate(x, y);
    rotate(angle);
    if (type == 0) {
      rectMode(CENTER);
      rect(0, 0, size, size);
    } else {
      triangle(0, -size/2, -size/2, size/2, size/2, size/2);
    }
    popMatrix();
  }
}

// КЛАС ЦИФР НА ЕКРАНІ
class Digit {
  float x, y, vx, vy;
  int value;
  color col;
  int lastColorTime;

  Digit() {
    randomizePosition();
    this.value = int(random(1, 10));
    updateColor();
    lastColorTime = millis();
  }

  void randomizePosition() {
    this.x = random(30, width - 30);
    this.y = random(30, height - 30);
    this.vx = random(-0.2, 0.2);
    this.vy = random(-0.2, 0.2);
  }

  void update() {
    x += vx;
    y += vy;
    
    if (x < 0 || x > width) vx *= -1;
    if (y < 0 || y > height) vy *= -1;

    // Зміна кольору кожну 1 секунду
    if (millis() - lastColorTime > 1000) {
      updateColor();
      lastColorTime = millis();
    }
  }

  void updateColor() {
    col = color(random(360), random(70, 100), random(60, 100));
  }

  void display() {
    fill(col);
    textAlign(CENTER, CENTER);
    textSize(18);
    text(value, x, y);
  }
}

// КЛАС ТОЧОК РУХОМОГО ГРАДІЄНТУ
class GradientPoint {
  float x, y, vx, vy;
  GradientPoint() {
    x = random(width);
    y = random(height);
    vx = random(-1, 1);
    vy = random(-1, 1);
  }
  void update() {
    x += vx; y += vy;
    if (x < 0 || x > width) vx *= -1;
    if (y < 0 || y > height) vy *= -1;
  }
}



