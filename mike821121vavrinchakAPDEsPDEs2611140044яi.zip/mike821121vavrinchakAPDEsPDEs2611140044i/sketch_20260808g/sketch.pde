






//T E T R I S. SEEK FUTURE. GPT. ASKED//













/*


// ============================================================ // APDE TETRIS 55 x 55 // Processing / APDE Java mode // ============================================================ final int BW = 55; final int BH = 55; int[][] board = new int[BH][BW]; int cell; int boardX, boardY; int score = 0; int lines = 0; int pieceX, pieceY; int pieceType; int rotation = 0; int fallDelay = 350; long lastFall = 0; boolean gameOver = false; // ------------------------------------------------------------ // MANY FIGURES // Each figure is an array of x,y pairs. // ------------------------------------------------------------ int[][][] shapes = { // 0 POINT {{0,0}}, // 1 LINE 2 {{0,0},{1,0}}, // 2 LINE 3 {{0,0},{1,0},{2,0}}, // 3 LINE 4 {{0,0},{1,0},{2,0},{3,0}}, // 4 LINE 5 {{0,0},{1,0},{2,0},{3,0},{4,0}}, // 5 LINE 6 {{0,0},{1,0},{2,0},{3,0},{4,0},{5,0}}, // 6 ANGLE 2 {{0,0},{0,1},{1,1}}, // 7 ANGLE 3 {{0,0},{0,1},{0,2},{1,2}}, // 8 L {{0,0},{0,1},{0,2},{1,2}}, // 9 REVERSE L {{1,0},{1,1},{1,2},{0,2}}, // 10 T {{0,0},{1,0},{2,0},{1,1}}, // 11 T DOWN {{1,0},{0,1},{1,1},{2,1}}, // 12 S {{1,0},{2,0},{0,1},{1,1}}, // 13 Z {{0,0},{1,0},{1,1},{2,1}}, // 14 SQUARE {{0,0},{1,0},{0,1},{1,1}}, // 15 PLUS {{1,0},{0,1},{1,1},{2,1},{1,2}}, // 16 SMALL CROSS {{0,1},{1,0},{1,1},{2,1},{1,2}}, // 17 CORNER {{0,0},{1,0},{0,1}}, // 18 BIG CORNER {{0,0},{0,1},{0,2},{1,0},{2,0}}, // 19 U {{0,0},{2,0},{0,1},{1,1},{2,1}}, // 20 P {{0,0},{1,0},{0,1},{1,1},{0,2}}, // 21 BIG T {{0,0},{1,0},{2,0},{1,1},{1,2}}, // 22 PLUS WITHOUT CENTER TOP {{0,0},{1,0},{2,0},{1,1},{0,2},{1,2},{2,2}}, // 23 H {{0,0},{0,1},{1,0},{1,1},{2,0},{2,1}}, // 24 ZIGZAG 5 {{0,0},{1,0},{1,1},{2,1},{2,2}}, // 25 STAIR {{0,0},{0,1},{1,1},{1,2},{2,2}}, // 26 3 + PERPENDICULAR {{0,0},{1,0},{2,0},{1,1}}, // 27 5 ARM {{0,0},{1,0},{2,0},{3,0},{2,1}}, // 28 W {{0,0},{1,0},{1,1},{2,1},{2,2}}, // 29 V {{0,0},{0,1},{0,2},{1,2},{2,2}} }; // ------------------------------------------------------------ // COLORS // ------------------------------------------------------------ color[] colors = { color(255,255,255), color(255,60,60), color(60,150,255), color(70,255,100), color(255,220,40), color(255,100,240), color(50,255,255), color(255,150,40), color(180,80,255) }; // ============================================================ // SETUP // ============================================================ void setup() { fullScreen(); orientation(PORTRAIT); cell = min(width * 7 / 10 / BW, height * 70 / 100 / BH); boardX = (width - cell * BW) / 2; boardY = height * 5 / 100; resetGame(); textAlign(CENTER,CENTER); } // ============================================================ // RESET // ============================================================ void resetGame() { for(int y=0;y<BH;y++) { for(int x=0;x<BW;x++) { board[y][x] = 0; } } score = 0; lines = 0; gameOver = false; newPiece(); } // ============================================================ // NEW PIECE // ============================================================ void newPiece() { pieceType = int(random(shapes.length)); rotation = 0; pieceX = BW/2; pieceY = 0; if(!canPlace(pieceX,pieceY,rotation)) { gameOver = true; } } // ============================================================ // DRAW // ============================================================ void draw() { background(10,10,18); drawBoard(); if(!gameOver) { drawPiece(); if(millis() - lastFall > fallDelay) { if(canPlace(pieceX,pieceY+1,rotation)) { pieceY++; } else { lockPiece(); clearLines(); newPiece(); } lastFall = millis(); } } else { drawPiece(); fill(255,50,50); textSize(width/12); text("GAME OVER",width/2,height*44/100); fill(255); textSize(width/22); text("TOUCH SCREEN",width/2,height*50/100); text("TO RESTART",width/2,height*55/100); } drawControls(); fill(255); textSize(width/25); text("SCORE: "+score,width/2,height*78/100); text("LINES: "+lines,width/2,height*82/100); } // ============================================================ // BOARD // ============================================================ void drawBoard() { stroke(35,35,45); strokeWeight(1); for(int y=0;y<BH;y++) { for(int x=0;x<BW;x++) { int px = boardX + x*cell; int py = boardY + y*cell; if(board[y][x] != 0) { fill(colors[board[y][x] % colors.length]); } else { fill(15,15,24); } rect(px,py,cell,cell); } } noFill(); stroke(100); rect(boardX,boardY,cell*BW,cell*BH); } // ============================================================ // DRAW CURRENT PIECE // ============================================================ void drawPiece() { int[][] s = getRotatedShape(pieceType,rotation); fill(colors[(pieceType+1)%colors.length]); stroke(255); for(int i=0;i<s.length;i++) { int x = pieceX + s[i][0]; int y = pieceY + s[i][1]; if(x>=0 && x<BW && y>=0 && y<BH) { rect( boardX+x*cell, boardY+y*cell, cell, cell ); } } } // ============================================================ // ROTATION // ============================================================ int[][] getRotatedShape(int type,int r) { int[][] original = shapes[type]; int[][] result = new int[original.length][2]; for(int i=0;i<original.length;i++) { int x = original[i][0]; int y = original[i][1]; int rx=x; int ry=y; for(int k=0;k<r;k++) { int temp=rx; rx=-ry; ry=temp; } result[i][0]=rx; result[i][1]=ry; } // normalize negative coordinates int minX=999; int minY=999; for(int i=0;i<result.length;i++) { minX=min(minX,result[i][0]); minY=min(minY,result[i][1]); } for(int i=0;i<result.length;i++) { result[i][0]-=minX; result[i][1]-=minY; } return result; } // ============================================================ // CAN PLACE // ============================================================ boolean canPlace(int px,int py,int r) { int[][] s=getRotatedShape(pieceType,r); for(int i=0;i<s.length;i++) { int x=px+s[i][0]; int y=py+s[i][1]; if(x<0 || x>=BW) return false; if(y>=BH) return false; if(y>=0 && board[y][x]!=0) return false; } return true; } // ============================================================ // LOCK PIECE // ============================================================ void lockPiece() { int[][] s=getRotatedShape(pieceType,rotation); for(int i=0;i<s.length;i++) { int x=pieceX+s[i][0]; int y=pieceY+s[i][1]; if(x>=0 && x<BW && y>=0 && y<BH) { board[y][x]=(pieceType+1)%colors.length; if(board[y][x]==0) board[y][x]=1; } } } // ============================================================ // CLEAR LINES // ============================================================ void clearLines() { // Repeat because a large piece can create several rows. boolean again=true; while(again) { again=false; for(int y=BH-1;y>=0;y--) { if(isFullLine(y) || isAlternatingLine(y)) { removeLine(y); score += BW; lines++; again=true; // Stay at same y because rows moved down. y++; } } } } // ============================================================ // FULL LINE // Requirement: horizontal line 9 or MORE // ============================================================ boolean isFullLine(int y) { int count=0; for(int x=0;x<BW;x++) { if(board[y][x]!=0) count++; } return count>=9; } // ============================================================ // 101010101... PATTERN // 8 or MORE alternating occupied/empty cells. // ============================================================ boolean isAlternatingLine(int y) { int best=0; int current=0; int previous=-1; for(int x=0;x<BW;x++) { int v=(board[y][x]!=0)?1:0; if(previous==-1) { current=1; } else if(v!=previous) { current++; } else { current=1; } previous=v; best=max(best,current); } return best>=8; } // ============================================================ // REMOVE ONE ROW // ============================================================ void removeLine(int row) { for(int y=row;y>0;y--) { for(int x=0;x<BW;x++) { board[y][x]=board[y-1][x]; } } for(int x=0;x<BW;x++) { board[0][x]=0; } } // ============================================================ // CONTROLS // ============================================================ void drawControls() { int cy=height*90/100; int buttonW=width/5; int buttonH=height/13; int leftX=width/20; int downX=width*29/100; int rightX=width*53/100; int rotX=width*77/100; drawButton(leftX,cy,buttonW,buttonH,"LEFT"); drawButton(downX,cy,buttonW,buttonH,"DOWN"); drawButton(rightX,cy,buttonW,buttonH,"RIGHT"); drawButton(rotX,cy,buttonW,buttonH,"ROTATE"); } // ============================================================ void drawButton(int x,int y,int w,int h,String txt) { fill(35,45,65); stroke(130,160,200); rect(x,y,w,h,12); fill(255); textSize(width/32); text(txt,x+w/2,y+h/2); } // ============================================================ // TOUCH // ============================================================ void mousePressed() { if(gameOver) { resetGame(); return; } int cy=height*90/100; int buttonW=width/5; int buttonH=height/13; int leftX=width/20; int downX=width*29/100; int rightX=width*53/100; int rotX=width*77/100; if(mouseY>cy && mouseY<cy+buttonH) { if(mouseX>=leftX && mouseX<leftX+buttonW) { moveLeft(); } else if(mouseX>=downX && mouseX<downX+buttonW) { moveDown(); } else if(mouseX>=rightX && mouseX<rightX+buttonW) { moveRight(); } else if(mouseX>=rotX && mouseX<rotX+buttonW) { rotatePiece(); } } } // ============================================================ // KEYBOARD // ============================================================ void keyPressed() { if(gameOver) { resetGame(); return; } if(keyCode==LEFT) { moveLeft(); } else if(keyCode==RIGHT) { moveRight(); } else if(keyCode==DOWN) { moveDown(); } else if(key==' ' || key=='r' || key=='R') { rotatePiece(); } } // ============================================================ // LEFT // ============================================================ void moveLeft() { if(canPlace(pieceX-1,pieceY,rotation)) pieceX--; } // ============================================================ // RIGHT // ============================================================ void moveRight() { if(canPlace(pieceX+1,pieceY,rotation)) pieceX++; } // ============================================================ // DOWN // ============================================================ void moveDown() { if(canPlace(pieceX,pieceY+1,rotation)) { pieceY++; score++; } else { lockPiece(); clearLines(); newPiece(); } lastFall=millis(); } // ============================================================ // ROTATE // ============================================================ void rotatePiece() { int nr=(rotation+1)%4; // Normal rotation if(canPlace(pieceX,pieceY,nr)) { rotation=nr; return; } // Small wall-kick left if(canPlace(pieceX-1,pieceY,nr)) { pieceX--; rotation=nr; return; } // Small wall-kick right if(canPlace(pieceX+1,pieceY,nr)) { pieceX++; rotation=nr; return; } // Small vertical correction if(canPlace(pieceX,pieceY-1,nr)) { pieceY--; rotation=nr; } }


*/

















// ============================================================
// APDE TETRIS 55 x 55
// Processing / APDE Java mode
// ============================================================

final int BW = 55;
final int BH = 55;

int[][] board = new int[BH][BW];

int cell;
int boardX, boardY;

int score = 0;
int lines = 0;

int pieceX, pieceY;
int pieceType;
int rotation = 0;

int fallDelay = 350;
long lastFall = 0;

boolean gameOver = false;

// ------------------------------------------------------------
// MANY FIGURES
// Each figure is an array of x,y pairs.
// ------------------------------------------------------------

int[][][] shapes = {

  // 0 POINT
  {{0,0}},

  // 1 LINE 2
  {{0,0},{1,0}},

  // 2 LINE 3
  {{0,0},{1,0},{2,0}},

  // 3 LINE 4
  {{0,0},{1,0},{2,0},{3,0}},

  // 4 LINE 5
  {{0,0},{1,0},{2,0},{3,0},{4,0}},

  // 5 LINE 6
  {{0,0},{1,0},{2,0},{3,0},{4,0},{5,0}},

  // 6 ANGLE 2
  {{0,0},{0,1},{1,1}},

  // 7 ANGLE 3
  {{0,0},{0,1},{0,2},{1,2}},

  // 8 L
  {{0,0},{0,1},{0,2},{1,2}},

  // 9 REVERSE L
  {{1,0},{1,1},{1,2},{0,2}},

  // 10 T
  {{0,0},{1,0},{2,0},{1,1}},

  // 11 T DOWN
  {{1,0},{0,1},{1,1},{2,1}},

  // 12 S
  {{1,0},{2,0},{0,1},{1,1}},

  // 13 Z
  {{0,0},{1,0},{1,1},{2,1}},

  // 14 SQUARE
  {{0,0},{1,0},{0,1},{1,1}},

  // 15 PLUS
  {{1,0},{0,1},{1,1},{2,1},{1,2}},

  // 16 SMALL CROSS
  {{0,1},{1,0},{1,1},{2,1},{1,2}},

  // 17 CORNER
  {{0,0},{1,0},{0,1}},

  // 18 BIG CORNER
  {{0,0},{0,1},{0,2},{1,0},{2,0}},

  // 19 U
  {{0,0},{2,0},{0,1},{1,1},{2,1}},

  // 20 P
  {{0,0},{1,0},{0,1},{1,1},{0,2}},

  // 21 BIG T
  {{0,0},{1,0},{2,0},{1,1},{1,2}},

  // 22 PLUS WITHOUT CENTER TOP
  {{0,0},{1,0},{2,0},{1,1},{0,2},{1,2},{2,2}},

  // 23 H
  {{0,0},{0,1},{1,0},{1,1},{2,0},{2,1}},

  // 24 ZIGZAG 5
  {{0,0},{1,0},{1,1},{2,1},{2,2}},

  // 25 STAIR
  {{0,0},{0,1},{1,1},{1,2},{2,2}},

  // 26 3 + PERPENDICULAR
  {{0,0},{1,0},{2,0},{1,1}},

  // 27 5 ARM
  {{0,0},{1,0},{2,0},{3,0},{2,1}},

  // 28 W
  {{0,0},{1,0},{1,1},{2,1},{2,2}},

  // 29 V
  {{0,0},{0,1},{0,2},{1,2},{2,2}}
};

// ------------------------------------------------------------
// COLORS
// ------------------------------------------------------------

color[] colors = {
  color(255,255,255),
  color(255,60,60),
  color(60,150,255),
  color(70,255,100),
  color(255,220,40),
  color(255,100,240),
  color(50,255,255),
  color(255,150,40),
  color(180,80,255)
};

// ============================================================
// SETUP
// ============================================================

void setup() {

  fullScreen();

  orientation(PORTRAIT);

  cell = min(width * 7 / 10 / BW,
             height * 70 / 100 / BH);

  boardX = (width - cell * BW) / 2;
  boardY = height * 5 / 100;

  resetGame();

  textAlign(CENTER,CENTER);
}

// ============================================================
// RESET
// ============================================================

void resetGame() {

  for(int y=0;y<BH;y++) {
    for(int x=0;x<BW;x++) {
      board[y][x] = 0;
    }
  }

  score = 0;
  lines = 0;
  gameOver = false;

  newPiece();
}

// ============================================================
// NEW PIECE
// ============================================================

void newPiece() {

  pieceType = int(random(shapes.length));

  rotation = 0;

  pieceX = BW/2;
  pieceY = 0;

  if(!canPlace(pieceX,pieceY,rotation)) {
    gameOver = true;
  }
}

// ============================================================
// DRAW
// ============================================================

void draw() {

  background(10,10,18);

  drawBoard();

  if(!gameOver) {

    drawPiece();

    if(millis() - lastFall > fallDelay) {

      if(canPlace(pieceX,pieceY+1,rotation)) {

        pieceY++;

      } else {

        lockPiece();

        clearLines();

        newPiece();
      }

      lastFall = millis();
    }

  } else {

    drawPiece();

    fill(255,50,50);
    textSize(width/12);
    text("GAME OVER",width/2,height*44/100);

    fill(255);
    textSize(width/22);
    text("TOUCH SCREEN",width/2,height*50/100);

    text("TO RESTART",width/2,height*55/100);
  }

  drawControls();

  fill(255);
  textSize(width/25);
  text("SCORE: "+score,width/2,height*78/100);

  text("LINES: "+lines,width/2,height*82/100);
}

// ============================================================
// BOARD
// ============================================================

void drawBoard() {

  stroke(35,35,45);
  strokeWeight(1);

  for(int y=0;y<BH;y++) {

    for(int x=0;x<BW;x++) {

      int px = boardX + x*cell;
      int py = boardY + y*cell;

      if(board[y][x] != 0) {

        fill(colors[board[y][x] % colors.length]);

      } else {

        fill(15,15,24);
      }

      rect(px,py,cell,cell);
    }
  }

  noFill();
  stroke(100);
  rect(boardX,boardY,cell*BW,cell*BH);
}

// ============================================================
// DRAW CURRENT PIECE
// ============================================================

void drawPiece() {

  int[][] s = getRotatedShape(pieceType,rotation);

  fill(colors[(pieceType+1)%colors.length]);
  stroke(255);

  for(int i=0;i<s.length;i++) {

    int x = pieceX + s[i][0];
    int y = pieceY + s[i][1];

    if(x>=0 && x<BW && y>=0 && y<BH) {

      rect(
        boardX+x*cell,
        boardY+y*cell,
        cell,
        cell
      );
    }
  }
}

// ============================================================
// ROTATION
// ============================================================

int[][] getRotatedShape(int type,int r) {

  int[][] original = shapes[type];

  int[][] result = new int[original.length][2];

  for(int i=0;i<original.length;i++) {

    int x = original[i][0];
    int y = original[i][1];

    int rx=x;
    int ry=y;

    for(int k=0;k<r;k++) {

      int temp=rx;

      rx=-ry;
      ry=temp;
    }

    result[i][0]=rx;
    result[i][1]=ry;
  }

  // normalize negative coordinates
  int minX=999;
  int minY=999;

  for(int i=0;i<result.length;i++) {

    minX=min(minX,result[i][0]);
    minY=min(minY,result[i][1]);
  }

  for(int i=0;i<result.length;i++) {

    result[i][0]-=minX;
    result[i][1]-=minY;
  }

  return result;
}

// ============================================================
// CAN PLACE
// ============================================================

boolean canPlace(int px,int py,int r) {

  int[][] s=getRotatedShape(pieceType,r);

  for(int i=0;i<s.length;i++) {

    int x=px+s[i][0];
    int y=py+s[i][1];

    if(x<0 || x>=BW) return false;

    if(y>=BH) return false;

    if(y>=0 && board[y][x]!=0) return false;
  }

  return true;
}

// ============================================================
// LOCK PIECE
// ============================================================

void lockPiece() {

  int[][] s=getRotatedShape(pieceType,rotation);

  for(int i=0;i<s.length;i++) {

    int x=pieceX+s[i][0];
    int y=pieceY+s[i][1];

    if(x>=0 && x<BW &&
       y>=0 && y<BH) {

      board[y][x]=(pieceType+1)%colors.length;

      if(board[y][x]==0)
        board[y][x]=1;
    }
  }
}

// ============================================================
// CLEAR LINES
// ============================================================

void clearLines() {

  // Repeat because a large piece can create several rows.
  boolean again=true;

  while(again) {

    again=false;

    for(int y=BH-1;y>=0;y--) {

      if(isFullLine(y) || isAlternatingLine(y)) {

        removeLine(y);

        score += BW;
        lines++;

        again=true;

        // Stay at same y because rows moved down.
        y++;
      }
    }
  }
}

// ============================================================
// FULL LINE
// Requirement: horizontal line 9 or MORE
// ============================================================

boolean isFullLine(int y) {

  int count=0;

  for(int x=0;x<BW;x++) {

    if(board[y][x]!=0)
      count++;
  }

  return count>=9;
}

// ============================================================
// 101010101... PATTERN
// 8 or MORE alternating occupied/empty cells.
// ============================================================

boolean isAlternatingLine(int y) {

  int best=0;
  int current=0;

  int previous=-1;

  for(int x=0;x<BW;x++) {

    int v=(board[y][x]!=0)?1:0;

    if(previous==-1) {

      current=1;

    } else if(v!=previous) {

      current++;

    } else {

      current=1;
    }

    previous=v;

    best=max(best,current);
  }

  return best>=8;
}

// ============================================================
// REMOVE ONE ROW
// ============================================================

void removeLine(int row) {

  for(int y=row;y>0;y--) {

    for(int x=0;x<BW;x++) {

      board[y][x]=board[y-1][x];
    }
  }

  for(int x=0;x<BW;x++) {

    board[0][x]=0;
  }
}

// ============================================================
// CONTROLS
// ============================================================

void drawControls() {

  int cy=height*90/100;

  int buttonW=width/5;
  int buttonH=height/13;

  int leftX=width/20;
  int downX=width*29/100;
  int rightX=width*53/100;
  int rotX=width*77/100;

  drawButton(leftX,cy,buttonW,buttonH,"LEFT");
  drawButton(downX,cy,buttonW,buttonH,"DOWN");
  drawButton(rightX,cy,buttonW,buttonH,"RIGHT");
  drawButton(rotX,cy,buttonW,buttonH,"ROTATE");
}

// ============================================================

void drawButton(int x,int y,int w,int h,String txt) {

  fill(35,45,65);
  stroke(130,160,200);

  rect(x,y,w,h,12);

  fill(255);
  textSize(width/32);

  text(txt,x+w/2,y+h/2);
}

// ============================================================
// TOUCH
// ============================================================

void mousePressed() {

  if(gameOver) {

    resetGame();
    return;
  }

  int cy=height*90/100;

  int buttonW=width/5;
  int buttonH=height/13;

  int leftX=width/20;
  int downX=width*29/100;
  int rightX=width*53/100;
  int rotX=width*77/100;

  if(mouseY>cy && mouseY<cy+buttonH) {

    if(mouseX>=leftX &&
       mouseX<leftX+buttonW) {

      moveLeft();
    }

    else if(mouseX>=downX &&
            mouseX<downX+buttonW) {

      moveDown();
    }

    else if(mouseX>=rightX &&
            mouseX<rightX+buttonW) {

      moveRight();
    }

    else if(mouseX>=rotX &&
            mouseX<rotX+buttonW) {

      rotatePiece();
    }
  }
}

// ============================================================
// KEYBOARD
// ============================================================

void keyPressed() {

  if(gameOver) {

    resetGame();
    return;
  }

  if(keyCode==LEFT) {

    moveLeft();

  } else if(keyCode==RIGHT) {

    moveRight();

  } else if(keyCode==DOWN) {

    moveDown();

  } else if(key==' ' ||
           key=='r' ||
           key=='R') {

    rotatePiece();
  }
}

// ============================================================
// LEFT
// ============================================================

void moveLeft() {

  if(canPlace(pieceX-1,pieceY,rotation))
    pieceX--;
}

// ============================================================
// RIGHT
// ============================================================

void moveRight() {

  if(canPlace(pieceX+1,pieceY,rotation))
    pieceX++;
}

// ============================================================
// DOWN
// ============================================================

void moveDown() {

  if(canPlace(pieceX,pieceY+1,rotation)) {

    pieceY++;
    score++;

  } else {

    lockPiece();

    clearLines();

    newPiece();
  }

  lastFall=millis();
}

// ============================================================
// ROTATE
// ============================================================

void rotatePiece() {

  int nr=(rotation+1)%4;

  // Normal rotation
  if(canPlace(pieceX,pieceY,nr)) {

    rotation=nr;
    return;
  }

  // Small wall-kick left
  if(canPlace(pieceX-1,pieceY,nr)) {

    pieceX--;
    rotation=nr;
    return;
  }

  // Small wall-kick right
  if(canPlace(pieceX+1,pieceY,nr)) {

    pieceX++;
    rotation=nr;
    return;
  }

  // Small vertical correction
  if(canPlace(pieceX,pieceY-1,nr)) {

    pieceY--;
    rotation=nr;
  }
}
































