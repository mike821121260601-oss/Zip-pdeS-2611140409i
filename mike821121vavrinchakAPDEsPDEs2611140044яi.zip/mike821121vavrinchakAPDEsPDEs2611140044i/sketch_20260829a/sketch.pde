





// ============================================================
// CUSTOM CHESS ENGINE - APDE 0.5.3
// Single PDE file
//
// Pieces:
// T = Rook
// O = Knight
// X = Bishop
// W = King
// U = Queen
// V = Pawn
//
// RED = uppercase
// BLUE = lowercase
//
// Engine:
// - Legal moves
// - Capture search
// - Alpha-beta
// - Depth 8
// - Best move
// - Move memory
// - Search marks
// ============================================================

final int EMPTY = 0;

final int PAWN   = 1;
final int ROOK   = 2;
final int KNIGHT = 3;
final int BISHOP = 4;
final int KING   = 5;
final int QUEEN  = 6;

final int RED  = 1;
final int BLUE = -1;

int[][] board = new int[8][8];

int turn = RED;

int selectedX = -1;
int selectedY = -1;

ArrayList<Move> legalMoves = new ArrayList<Move>();

String bestMoveText = "";
int bestScore = 0;

boolean engineRed = true;
boolean engineBlue = true;

boolean thinking = false;
boolean gameOver = false;

int searchDepth = 8;

long nodes = 0;
long maxNodes = 180000;

ArrayList<Memory> memory = new ArrayList<Memory>();

// ------------------------------------------------------------
// SETUP
// ------------------------------------------------------------

void setup() {
  fullScreen();
  orientation(PORTRAIT);

  textAlign(CENTER, CENTER);
  rectMode(CORNER);

  newGame();
}

// ------------------------------------------------------------
// NEW GAME
// ------------------------------------------------------------

void newGame() {

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {
      board[y][x] = EMPTY;
    }
  }

  // RED
  board[0][0] = ROOK;
  board[0][1] = KNIGHT;
  board[0][2] = BISHOP;
  board[0][3] = KING;
  board[0][4] = QUEEN;
  board[0][5] = BISHOP;
  board[0][6] = KNIGHT;
  board[0][7] = ROOK;

  for (int x = 0; x < 8; x++)
    board[1][x] = PAWN;

  // BLUE
  board[7][0] = -ROOK;
  board[7][1] = -KNIGHT;
  board[7][2] = -BISHOP;
  board[7][3] = -KING;
  board[7][4] = -QUEEN;
  board[7][5] = -BISHOP;
  board[7][6] = -KNIGHT;
  board[7][7] = -ROOK;

  for (int x = 0; x < 8; x++)
    board[6][x] = -PAWN;

  turn = RED;

  selectedX = -1;
  selectedY = -1;

  bestMoveText = "";
  bestScore = 0;

  legalMoves.clear();

  memory.clear();

  gameOver = false;
  thinking = false;

  generateLegalMoves(turn);
}

// ------------------------------------------------------------
// DRAW
// ------------------------------------------------------------

void draw() {

  background(40);

  float boardSize = min(width - 20, height - 180);
  float sx = (width - boardSize) / 2.0;
  float sy = 45;

  float sq = boardSize / 8.0;

  // BOARD
  for (int y = 0; y < 8; y++) {

    for (int x = 0; x < 8; x++) {

      if ((x + y) % 2 == 0)
        fill(245, 220, 80);
      else
        fill(210, 210, 210);

      rect(sx + x * sq,
           sy + y * sq,
           sq,
           sq);

      // selected square
      if (x == selectedX && y == selectedY) {
        noFill();
        stroke(255, 0, 0);
        strokeWeight(5);
        rect(sx + x * sq + 3,
             sy + y * sq + 3,
             sq - 6,
             sq - 6);
        noStroke();
      }
    }
  }

  // LEGAL MOVE MARKS
  fill(0, 180, 0, 150);

  for (int i = 0; i < legalMoves.size(); i++) {

    Move m = legalMoves.get(i);

    if (m.fx == selectedX && m.fy == selectedY) {

      ellipse(
        sx + m.tx * sq + sq / 2,
        sy + m.ty * sq + sq / 2,
        sq * 0.25,
        sq * 0.25
      );
    }
  }

  // PIECES
  textSize(sq * 0.62);

  for (int y = 0; y < 8; y++) {

    for (int x = 0; x < 8; x++) {

      int p = board[y][x];

      if (p == EMPTY)
        continue;

      if (p > 0)
        fill(220, 30, 30);
      else
        fill(30, 70, 230);

      text(
        pieceChar(abs(p)),
        sx + x * sq + sq / 2,
        sy + y * sq + sq / 2
      );
    }
  }

  // BEST MOVE
  if (bestMoveText.length() > 0) {

    stroke(0, 255, 0);
    strokeWeight(4);
    noFill();

    // text only; board remains clean
    noStroke();

    fill(255);
    textSize(18);

    text(
      "BEST: " + bestMoveText +
      "  SCORE " + bestScore +
      "  DEPTH " + searchDepth,
      width / 2,
      height - 95
    );
  }

  // STATUS
  fill(255);
  textSize(20);

  String side;

  if (turn == RED)
    side = "RED";
  else
    side = "BLUE";

  text(
    thinking ? "ENGINE THINKING..." :
    gameOver ? "GAME END" :
    side + " TO MOVE",
    width / 2,
    20
  );

  // BUTTONS
  drawButton(
    10,
    height - 65,
    width / 2 - 15,
    50,
    "NEW GAME"
  );

  drawButton(
    width / 2 + 5,
    height - 65,
    width / 2 - 15,
    50,
    "ENGINE MOVE"
  );

  // engine info
  fill(220);
  textSize(13);

  text(
    "Nodes: " + nodes +
    "   Memory: " + memory.size(),
    width / 2,
    height - 120
  );
}

// ------------------------------------------------------------
// BUTTON
// ------------------------------------------------------------

void drawButton(float x, float y, float w, float h, String s) {

  fill(70);
  rect(x, y, w, h);

  fill(255);
  textSize(16);

  text(
    s,
    x + w / 2,
    y + h / 2
  );
}

// ------------------------------------------------------------
// TOUCH
// ------------------------------------------------------------

void mousePressed() {

  if (mouseY > height - 70) {

    if (mouseX < width / 2) {
      newGame();
      return;
    }

    if (mouseX >= width / 2) {
      if (!thinking && !gameOver)
        engineMove();
      return;
    }
  }

  float boardSize = min(width - 20, height - 180);
  float sx = (width - boardSize) / 2.0;
  float sy = 45;
  float sq = boardSize / 8.0;

  if (mouseX < sx ||
      mouseX >= sx + boardSize ||
      mouseY < sy ||
      mouseY >= sy + boardSize)
    return;

  int x = int((mouseX - sx) / sq);
  int y = int((mouseY - sy) / sq);

  if (x < 0 || x > 7 || y < 0 || y > 7)
    return;

  humanSquare(x, y);
}

// ------------------------------------------------------------
// HUMAN MOVE
// ------------------------------------------------------------

void humanSquare(int x, int y) {

  if (thinking || gameOver)
    return;

  int p = board[y][x];

  if (selectedX < 0) {

    if (p != EMPTY &&
        sideOf(p) == turn) {

      selectedX = x;
      selectedY = y;

    }

    return;
  }

  // select another own piece
  if (p != EMPTY &&
      sideOf(p) == turn) {

    selectedX = x;
    selectedY = y;

    return;
  }

  // find legal selected -> destination
  for (int i = 0; i < legalMoves.size(); i++) {

    Move m = legalMoves.get(i);

    if (m.fx == selectedX &&
        m.fy == selectedY &&
        m.tx == x &&
        m.ty == y) {

      makeMove(m);

      selectedX = -1;
      selectedY = -1;

      turn = -turn;

      generateLegalMoves(turn);

      checkGameEnd();

      return;
    }
  }
}

// ------------------------------------------------------------
// ENGINE MOVE
// ------------------------------------------------------------

void engineMove() {

  if (thinking || gameOver)
    return;

  thinking = true;

  nodes = 0;

  generateLegalMoves(turn);

  if (legalMoves.size() == 0) {
    thinking = false;
    gameOver = true;
    return;
  }

  Move best = searchRoot(turn);

  if (best != null) {

    bestMoveText = moveText(best);

    makeMove(best);

    turn = -turn;

    generateLegalMoves(turn);

    checkGameEnd();
  }

  thinking = false;
}

// ------------------------------------------------------------
// ROOT SEARCH
// ------------------------------------------------------------

Move searchRoot(int side) {

  ArrayList<Move> moves = copyMoves(legalMoves);

  // captures first
  sortCaptures(moves);

  int bestValue = -100000000;
  Move best = null;

  for (int i = 0; i < moves.size(); i++) {

    Move m = moves.get(i);

    int captured = board[m.ty][m.tx];

    makeMove(m);

    int value =
      -alphaBeta(
        -side,
        searchDepth - 1,
        -100000000,
        100000000
      );

    undoMove(m, captured);

    if (value > bestValue) {

      bestValue = value;
      best = m;
    }

    // memory
    saveMemory(
      boardKey(),
      m,
      value
    );
  }

  bestScore = bestValue;

  return best;
}

// ------------------------------------------------------------
// ALPHA BETA
// ------------------------------------------------------------

int alphaBeta(
  int side,
  int depth,
  int alpha,
  int beta) {

  nodes++;

  if (nodes > maxNodes)
    return evaluate();

  if (depth <= 0)
    return evaluateFor(side);

  generateLegalMoves(side);

  if (legalMoves.size() == 0) {

    if (kingExists(side))
      return -900000 + (searchDepth - depth);

    return 0;
  }

  // check memory
  int mem = getMemoryScore(boardKey());

  if (mem != 999999 &&
      depth <= 2)
    return mem;

  ArrayList<Move> moves = copyMoves(legalMoves);

  sortCaptures(moves);

  int best = -100000000;

  for (int i = 0; i < moves.size(); i++) {

    Move m = moves.get(i);

    int captured = board[m.ty][m.tx];

    makeMove(m);

    int value =
      -alphaBeta(
        -side,
        depth - 1,
        -beta,
        -alpha
      );

    undoMove(m, captured);

    if (value > best)
      best = value;

    if (value > alpha)
      alpha = value;

    if (alpha >= beta)
      break;
  }

  return best;
}

// ------------------------------------------------------------
// LEGAL MOVES
// ------------------------------------------------------------

void generateLegalMoves(int side) {

  legalMoves.clear();

  for (int y = 0; y < 8; y++) {

    for (int x = 0; x < 8; x++) {

      int p = board[y][x];

      if (p == EMPTY)
        continue;

      if (sideOf(p) != side)
        continue;

      generatePieceMoves(
        x,
        y,
        p,
        side
      );
    }
  }

  // remove moves that leave own king attacked
  for (int i = legalMoves.size() - 1; i >= 0; i--) {

    Move m = legalMoves.get(i);

    int captured = board[m.ty][m.tx];

    makeMove(m);

    boolean bad = isKingAttacked(side);

    undoMove(m, captured);

    if (bad)
      legalMoves.remove(i);
  }
}

// ------------------------------------------------------------
// PIECE MOVES
// ------------------------------------------------------------

void generatePieceMoves(
  int x,
  int y,
  int p,
  int side) {

  int type = abs(p);

  if (type == PAWN) {

    int d = side == RED ? 1 : -1;

    int ny = y + d;

    if (inside(x, ny) &&
        board[ny][x] == EMPTY) {

      legalMoves.add(
        new Move(x, y, x, ny)
      );

      int start = side == RED ? 1 : 6;

      if (y == start &&
          board[y + d * 2][x] == EMPTY) {

        legalMoves.add(
          new Move(
            x,
            y,
            x,
            y + d * 2
          )
        );
      }
    }

    // captures
    for (int dx = -1; dx <= 1; dx += 2) {

      int nx = x + dx;

      if (inside(nx, ny) &&
          board[ny][nx] != EMPTY &&
          sideOf(board[ny][nx]) != side) {

        legalMoves.add(
          new Move(
            x,
            y,
            nx,
            ny
          )
        );
      }
    }

    return;
  }

  if (type == KNIGHT) {

    int[][] n = {
      {1,2},{2,1},
      {-1,2},{-2,1},
      {1,-2},{2,-1},
      {-1,-2},{-2,-1}
    };

    for (int i = 0; i < 8; i++) {

      addIfLegal(
        x,
        y,
        x + n[i][0],
        y + n[i][1],
        side
      );
    }

    return;
  }

  if (type == KING) {

    for (int dx = -1; dx <= 1; dx++) {
      for (int dy = -1; dy <= 1; dy++) {

        if (dx == 0 && dy == 0)
          continue;

        addIfLegal(
          x,
          y,
          x + dx,
          y + dy,
          side
        );
      }
    }

    return;
  }

  if (type == ROOK ||
      type == QUEEN) {

    slide(
      x,y,
      side,
      1,0
    );

    slide(
      x,y,
      side,
      -1,0
    );

    slide(
      x,y,
      side,
      0,1
    );

    slide(
      x,y,
      side,
      0,-1
    );
  }

  if (type == BISHOP ||
      type == QUEEN) {

    slide(
      x,y,
      side,
      1,1
    );

    slide(
      x,y,
      side,
      1,-1
    );

    slide(
      x,y,
      side,
      -1,1
    );

    slide(
      x,y,
      side,
      -1,-1
    );
  }
}

// ------------------------------------------------------------
// SLIDING PIECES
// ------------------------------------------------------------

void slide(
  int x,
  int y,
  int side,
  int dx,
  int dy) {

  int nx = x + dx;
  int ny = y + dy;

  while (inside(nx, ny)) {

    if (board[ny][nx] == EMPTY) {

      legalMoves.add(
        new Move(
          x,y,nx,ny
        )
      );

    } else {

      if (sideOf(board[ny][nx]) != side) {

        legalMoves.add(
          new Move(
            x,y,nx,ny
          )
        );
      }

      break;
    }

    nx += dx;
    ny += dy;
  }
}

// ------------------------------------------------------------
// ADD MOVE
// ------------------------------------------------------------

void addIfLegal(
  int fx,
  int fy,
  int tx,
  int ty,
  int side) {

  if (!inside(tx,ty))
    return;

  if (board[ty][tx] == EMPTY ||
      sideOf(board[ty][tx]) != side) {

    legalMoves.add(
      new Move(
        fx,fy,tx,ty
      )
    );
  }
}

// ------------------------------------------------------------
// MAKE MOVE
// ------------------------------------------------------------

void makeMove(Move m) {

  board[m.ty][m.tx] =
    board[m.fy][m.fx];

  board[m.fy][m.fx] =
    EMPTY;

  // pawn promotion
  if (abs(board[m.ty][m.tx]) == PAWN) {

    if (m.ty == 7 || m.ty == 0) {

      board[m.ty][m.tx] =
        sideOf(board[m.ty][m.tx]) * QUEEN;
    }
  }
}

// ------------------------------------------------------------
// UNDO
// ------------------------------------------------------------

void undoMove(
  Move m,
  int captured) {

  board[m.fy][m.fx] =
    board[m.ty][m.tx];

  board[m.ty][m.tx] =
    captured;
}

// ------------------------------------------------------------
// KING ATTACK
// ------------------------------------------------------------

boolean isKingAttacked(int side) {

  int kx = -1;
  int ky = -1;

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {

      if (board[y][x] ==
          side * KING) {

        kx = x;
        ky = y;
      }
    }
  }

  if (kx < 0)
    return true;

  int enemy = -side;

  // pawn attack
  int pd = enemy == RED ? 1 : -1;

  for (int dx = -1; dx <= 1; dx += 2) {

    int x = kx + dx;
    int y = ky + pd;

    if (inside(x,y) &&
        board[y][x] ==
        enemy * PAWN)
      return true;
  }

  // knight
  int[][] n = {
    {1,2},{2,1},
    {-1,2},{-2,1},
    {1,-2},{2,-1},
    {-1,-2},{-2,-1}
  };

  for (int i = 0; i < 8; i++) {

    int x = kx + n[i][0];
    int y = ky + n[i][1];

    if (inside(x,y) &&
        board[y][x] ==
        enemy * KNIGHT)
      return true;
  }

  // king
  for (int dx = -1; dx <= 1; dx++) {
    for (int dy = -1; dy <= 1; dy++) {

      if (dx == 0 && dy == 0)
        continue;

      int x = kx + dx;
      int y = ky + dy;

      if (inside(x,y) &&
          board[y][x] ==
          enemy * KING)
        return true;
    }
  }

  // rook / queen
  if (rayAttack(
    kx,ky,enemy,
    1,0,ROOK))
    return true;

  if (rayAttack(
    kx,ky,enemy,
    -1,0,ROOK))
    return true;

  if (rayAttack(
    kx,ky,enemy,
    0,1,ROOK))
    return true;

  if (rayAttack(
    kx,ky,enemy,
    0,-1,ROOK))
    return true;

  // bishop / queen
  if (rayAttack(
    kx,ky,enemy,
    1,1,BISHOP))
    return true;

  if (rayAttack(
    kx,ky,enemy,
    1,-1,BISHOP))
    return true;

  if (rayAttack(
    kx,ky,enemy,
    -1,1,BISHOP))
    return true;

  if (rayAttack(
    kx,ky,enemy,
    -1,-1,BISHOP))
    return true;

  return false;
}

// ------------------------------------------------------------
// RAY ATTACK
// ------------------------------------------------------------

boolean rayAttack(
  int x,
  int y,
  int enemy,
  int dx,
  int dy,
  int wanted) {

  x += dx;
  y += dy;

  while (inside(x,y)) {

    int p = board[y][x];

    if (p != EMPTY) {

      if (p == enemy * wanted ||
          p == enemy * QUEEN)
        return true;

      return false;
    }

    x += dx;
    y += dy;
  }

  return false;
}

// ------------------------------------------------------------
// EVALUATION
// ------------------------------------------------------------

int evaluate() {

  int score = 0;

  for (int y = 0; y < 8; y++) {

    for (int x = 0; x < 8; x++) {

      int p = board[y][x];

      if (p == EMPTY)
        continue;

      int value = pieceValue(abs(p));

      if (p > 0)
        score += value;
      else
        score -= value;

      // central squares
      if (x >= 2 && x <= 5 &&
          y >= 2 && y <= 5) {

        if (p > 0)
          score += 3;
        else
          score -= 3;
      }
    }
  }

  return score;
}

// score from side perspective
int evaluateFor(int side) {

  return side == RED ?
    evaluate() :
    -evaluate();
}

// ------------------------------------------------------------
// PIECE VALUES
// ------------------------------------------------------------

int pieceValue(int p) {

  if (p == PAWN) return 100;
  if (p == KNIGHT) return 320;
  if (p == BISHOP) return 330;
  if (p == ROOK) return 500;
  if (p == QUEEN) return 900;
  if (p == KING) return 20000;

  return 0;
}

// ------------------------------------------------------------
// CAPTURE SORT
// ------------------------------------------------------------

void sortCaptures(ArrayList<Move> list) {

  for (int i = 0; i < list.size(); i++) {

    int best = i;

    for (int j = i + 1; j < list.size(); j++) {

      int a =
        abs(board[list.get(j).ty][list.get(j).tx]);

      int b =
        abs(board[list.get(best).ty][list.get(best).tx]);

      if (a > b)
        best = j;
    }

    Move temp = list.get(i);

    list.set(
      i,
      list.get(best)
    );

    list.set(
      best,
      temp
    );
  }
}

// ------------------------------------------------------------
// MEMORY
// ------------------------------------------------------------

void saveMemory(
  long key,
  Move m,
  int score) {

  if (memory.size() >= 5000)
    memory.remove(0);

  memory.add(
    new Memory(
      key,
      m,
      score
    )
  );
}

int getMemoryScore(long key) {

  for (int i = memory.size() - 1; i >= 0; i--) {

    if (memory.get(i).key == key)
      return memory.get(i).score;
  }

  return 999999;
}

// ------------------------------------------------------------
// BOARD KEY
// ------------------------------------------------------------

long boardKey() {

  long k = 7;

  for (int y = 0; y < 8; y++) {

    for (int x = 0; x < 8; x++) {

      k = k * 31 + board[y][x];
    }
  }

  k = k * 2 + (turn == RED ? 1 : 0);

  return k;
}

// ------------------------------------------------------------
// COPY MOVES
// ------------------------------------------------------------

ArrayList<Move> copyMoves(
  ArrayList<Move> source) {

  ArrayList<Move> r =
    new ArrayList<Move>();

  for (int i = 0; i < source.size(); i++) {

    Move m = source.get(i);

    r.add(
      new Move(
        m.fx,
        m.fy,
        m.tx,
        m.ty
      )
    );
  }

  return r;
}

// ------------------------------------------------------------
// GAME END
// ------------------------------------------------------------

void checkGameEnd() {

  generateLegalMoves(turn);

  if (legalMoves.size() == 0) {

    gameOver = true;

    if (kingExists(turn)) {

      if (isKingAttacked(turn))
        bestMoveText =
          "CHECKMATE";
      else
        bestMoveText =
          "STALEMATE";
    }
  }
}

// ------------------------------------------------------------
// KING EXISTS
// ------------------------------------------------------------

boolean kingExists(int side) {

  for (int y = 0; y < 8; y++) {

    for (int x = 0; x < 8; x++) {

      if (board[y][x] ==
          side * KING)
        return true;
    }
  }

  return false;
}

// ------------------------------------------------------------
// HELPERS
// ------------------------------------------------------------

boolean inside(int x, int y) {

  return x >= 0 &&
         x < 8 &&
         y >= 0 &&
         y < 8;
}

int sideOf(int p) {

  if (p > 0)
    return RED;

  if (p < 0)
    return BLUE;

  return 0;
}

String pieceChar(int p) {

  if (p == PAWN)   return "V";
  if (p == ROOK)   return "T";
  if (p == KNIGHT) return "O";
  if (p == BISHOP) return "X";
  if (p == KING)   return "W";
  if (p == QUEEN)  return "U";

  return "";
}

String moveText(Move m) {

  return squareName(m.fx,m.fy) +
         "-" +
         squareName(m.tx,m.ty);
}

String squareName(int x, int y) {

  char f = char('A' + x);

  int rank = y + 1;

  return "" + f + rank;
}

// ------------------------------------------------------------
// MOVE CLASS
// ------------------------------------------------------------

class Move {

  int fx;
  int fy;

  int tx;
  int ty;

  Move(
    int a,
    int b,
    int c,
    int d) {

    fx = a;
    fy = b;
    tx = c;
    ty = d;
  }
}

// ------------------------------------------------------------
// MEMORY CLASS
// ------------------------------------------------------------

class Memory {

  long key;

  Move move;

  int score;

  Memory(
    long k,
    Move m,
    int s) {

    key = k;

    move =
      new Move(
        m.fx,
        m.fy,
        m.tx,
        m.ty
      );

    score = s;
  }
}















/*











// ============================================================
// CUSTOM CHESS ENGINE - APDE 0.5.3
// Single PDE file
//
// Pieces:
// T = Rook
// O = Knight
// X = Bishop
// W = King
// U = Queen
// V = Pawn
//
// RED = uppercase
// BLUE = lowercase
//
// Engine:
// - Legal moves
// - Capture search
// - Alpha-beta
// - Depth 8
// - Best move
// - Move memory
// - Search marks
// ============================================================

final int EMPTY = 0;

final int PAWN   = 1;
final int ROOK   = 2;
final int KNIGHT = 3;
final int BISHOP = 4;
final int KING   = 5;
final int QUEEN  = 6;

final int RED  = 1;
final int BLUE = -1;

int[][] board = new int[8][8];

int turn = RED;

int selectedX = -1;
int selectedY = -1;

ArrayList<Move> legalMoves = new ArrayList<Move>();

String bestMoveText = "";
int bestScore = 0;

boolean engineRed = true;
boolean engineBlue = true;

boolean thinking = false;
boolean gameOver = false;

int searchDepth = 8;

long nodes = 0;
long maxNodes = 180000;

ArrayList<Memory> memory = new ArrayList<Memory>();

// ------------------------------------------------------------
// SETUP
// ------------------------------------------------------------

void setup() {
  fullScreen();
  orientation(PORTRAIT);

  textAlign(CENTER, CENTER);
  rectMode(CORNER);

  newGame();
}

// ------------------------------------------------------------
// NEW GAME
// ------------------------------------------------------------

void newGame() {

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {
      board[y][x] = EMPTY;
    }
  }

  // RED
  board[0][0] = ROOK;
  board[0][1] = KNIGHT;
  board[0][2] = BISHOP;
  board[0][3] = KING;
  board[0][4] = QUEEN;
  board[0][5] = BISHOP;
  board[0][6] = KNIGHT;
  board[0][7] = ROOK;

  for (int x = 0; x < 8; x++)
    board[1][x] = PAWN;

  // BLUE
  board[7][0] = -ROOK;
  board[7][1] = -KNIGHT;
  board[7][2] = -BISHOP;
  board[7][3] = -KING;
  board[7][4] = -QUEEN;
  board[7][5] = -BISHOP;
  board[7][6] = -KNIGHT;
  board[7][7] = -ROOK;

  for (int x = 0; x < 8; x++)
    board[6][x] = -PAWN;

  turn = RED;

  selectedX = -1;
  selectedY = -1;

  bestMoveText = "";
  bestScore = 0;

  legalMoves.clear();

  memory.clear();

  gameOver = false;
  thinking = false;

  generateLegalMoves(turn);
}

// ------------------------------------------------------------
// DRAW
// ------------------------------------------------------------

void draw() {

  background(40);

  float boardSize = min(width - 20, height - 180);
  float sx = (width - boardSize) / 2.0;
  float sy = 45;

  float sq = boardSize / 8.0;

  // BOARD
  for (int y = 0; y < 8; y++) {

    for (int x = 0; x < 8; x++) {

      if ((x + y) % 2 == 0)
        fill(245, 220, 80);
      else
        fill(210, 210, 210);

      rect(sx + x * sq,
           sy + y * sq,
           sq,
           sq);

      // selected square
      if (x == selectedX && y == selectedY) {
        noFill();
        stroke(255, 0, 0);
        strokeWeight(5);
        rect(sx + x * sq + 3,
             sy + y * sq + 3,
             sq - 6,
             sq - 6);
        noStroke();
      }
    }
  }

  // LEGAL MOVE MARKS
  fill(0, 180, 0, 150);

  for (int i = 0; i < legalMoves.size(); i++) {

    Move m = legalMoves.get(i);

    if (m.fx == selectedX && m.fy == selectedY) {

      ellipse(
        sx + m.tx * sq + sq / 2,
        sy + m.ty * sq + sq / 2,
        sq * 0.25,
        sq * 0.25
      );
    }
  }

  // PIECES
  textSize(sq * 0.62);

  for (int y = 0; y < 8; y++) {

    for (int x = 0; x < 8; x++) {

      int p = board[y][x];

      if (p == EMPTY)
        continue;

      if (p > 0)
        fill(220, 30, 30);
      else
        fill(30, 70, 230);

      text(
        pieceChar(abs(p)),
        sx + x * sq + sq / 2,
        sy + y * sq + sq / 2
      );
    }
  }

  // BEST MOVE
  if (bestMoveText.length() > 0) {

    stroke(0, 255, 0);
    strokeWeight(4);
    noFill();

    // text only; board remains clean
    noStroke();

    fill(255);
    textSize(18);

    text(
      "BEST: " + bestMoveText +
      "  SCORE " + bestScore +
      "  DEPTH " + searchDepth,
      width / 2,
      height - 95
    );
  }

  // STATUS
  fill(255);
  textSize(20);

  String side;

  if (turn == RED)
    side = "RED";
  else
    side = "BLUE";

  text(
    thinking ? "ENGINE THINKING..." :
    gameOver ? "GAME END" :
    side + " TO MOVE",
    width / 2,
    20
  );

  // BUTTONS
  drawButton(
    10,
    height - 65,
    width / 2 - 15,
    50,
    "NEW GAME"
  );

  drawButton(
    width / 2 + 5,
    height - 65,
    width / 2 - 15,
    50,
    "ENGINE MOVE"
  );

  // engine info
  fill(220);
  textSize(13);

  text(
    "Nodes: " + nodes +
    "   Memory: " + memory.size(),
    width / 2,
    height - 120
  );
}

// ------------------------------------------------------------
// BUTTON
// ------------------------------------------------------------

void drawButton(float x, float y, float w, float h, String s) {

  fill(70);
  rect(x, y, w, h);

  fill(255);
  textSize(16);

  text(
    s,
    x + w / 2,
    y + h / 2
  );
}

// ------------------------------------------------------------
// TOUCH
// ------------------------------------------------------------

void mousePressed() {

  if (mouseY > height - 70) {

    if (mouseX < width / 2) {
      newGame();
      return;
    }

    if (mouseX >= width / 2) {
      if (!thinking && !gameOver)
        engineMove();
      return;
    }
  }

  float boardSize = min(width - 20, height - 180);
  float sx = (width - boardSize) / 2.0;
  float sy = 45;
  float sq = boardSize / 8.0;

  if (mouseX < sx ||
      mouseX >= sx + boardSize ||
      mouseY < sy ||
      mouseY >= sy + boardSize)
    return;

  int x = int((mouseX - sx) / sq);
  int y = int((mouseY - sy) / sq);

  if (x < 0 || x > 7 || y < 0 || y > 7)
    return;

  humanSquare(x, y);
}

// ------------------------------------------------------------
// HUMAN MOVE
// ------------------------------------------------------------

void humanSquare(int x, int y) {

  if (thinking || gameOver)
    return;

  int p = board[y][x];

  if (selectedX < 0) {

    if (p != EMPTY &&
        sideOf(p) == turn) {

      selectedX = x;
      selectedY = y;

    }

    return;
  }

  // select another own piece
  if (p != EMPTY &&
      sideOf(p) == turn) {

    selectedX = x;
    selectedY = y;

    return;
  }

  // find legal selected -> destination
  for (int i = 0; i < legalMoves.size(); i++) {

    Move m = legalMoves.get(i);

    if (m.fx == selectedX &&
        m.fy == selectedY &&
        m.tx == x &&
        m.ty == y) {

      makeMove(m);

      selectedX = -1;
      selectedY = -1;

      turn = -turn;

      generateLegalMoves(turn);

      checkGameEnd();

      return;
    }
  }
}

// ------------------------------------------------------------
// ENGINE MOVE
// ------------------------------------------------------------

void engineMove() {

  if (thinking || gameOver)
    return;

  thinking = true;

  nodes = 0;

  generateLegalMoves(turn);

  if (legalMoves.size() == 0) {
    thinking = false;
    gameOver = true;
    return;
  }

  Move best = searchRoot(turn);

  if (best != null) {

    bestMoveText = moveText(best);

    makeMove(best);

    turn = -turn;

    generateLegalMoves(turn);

    checkGameEnd();
  }

  thinking = false;
}

// ------------------------------------------------------------
// ROOT SEARCH
// ------------------------------------------------------------

Move searchRoot(int side) {

  ArrayList<Move> moves = copyMoves(legalMoves);

  // captures first
  sortCaptures(moves);

  int bestValue = -100000000;
  Move best = null;

  for (int i = 0; i < moves.size(); i++) {

    Move m = moves.get(i);

    int captured = board[m.ty][m.tx];

    makeMove(m);

    int value =
      -alphaBeta(
        -side,
        searchDepth - 1,
        -100000000,
        100000000
      );

    undoMove(m, captured);

    if (value > bestValue) {

      bestValue = value;
      best = m;
    }

    // memory
    saveMemory(
      boardKey(),
      m,
      value
    );
  }

  bestScore = bestValue;

  return best;
}

// ------------------------------------------------------------
// ALPHA BETA
// ------------------------------------------------------------

int alphaBeta(
  int side,
  int depth,
  int alpha,
  int beta) {

  nodes++;

  if (nodes > maxNodes)
    return evaluate();

  if (depth <= 0)
    return evaluateFor(side);

  generateLegalMoves(side);

  if (legalMoves.size() == 0) {

    if (kingExists(side))
      return -900000 + (searchDepth - depth);

    return 0;
  }

  // check memory
  int mem = getMemoryScore(boardKey());

  if (mem != 999999 &&
      depth <= 2)
    return mem;

  ArrayList<Move> moves = copyMoves(legalMoves);

  sortCaptures(moves);

  int best = -100000000;

  for (int i = 0; i < moves.size(); i++) {

    Move m = moves.get(i);

    int captured = board[m.ty][m.tx];

    makeMove(m);

    int value =
      -alphaBeta(
        -side,
        depth - 1,
        -beta,
        -alpha
      );

    undoMove(m, captured);

    if (value > best)
      best = value;

    if (value > alpha)
      alpha = value;

    if (alpha >= beta)
      break;
  }

  return best;
}

// ------------------------------------------------------------
// LEGAL MOVES
// ------------------------------------------------------------

void generateLegalMoves(int side) {

  legalMoves.clear();

  for (int y = 0; y < 8; y++) {

    for (int x = 0; x < 8; x++) {

      int p = board[y][x];

      if (p == EMPTY)
        continue;

      if (sideOf(p) != side)
        continue;

      generatePieceMoves(
        x,
        y,
        p,
        side
      );
    }
  }

  // remove moves that leave own king attacked
  for (int i = legalMoves.size() - 1; i >= 0; i--) {

    Move m = legalMoves.get(i);

    int captured = board[m.ty][m.tx];

    makeMove(m);

    boolean bad = isKingAttacked(side);

    undoMove(m, captured);

    if (bad)
      legalMoves.remove(i);
  }
}

// ------------------------------------------------------------
// PIECE MOVES
// ------------------------------------------------------------

void generatePieceMoves(
  int x,
  int y,
  int p,
  int side) {

  int type = abs(p);

  if (type == PAWN) {

    int d = side == RED ? 1 : -1;

    int ny = y + d;

    if (inside(x, ny) &&
        board[ny][x] == EMPTY) {

      legalMoves.add(
        new Move(x, y, x, ny)
      );

      int start = side == RED ? 1 : 6;

      if (y == start &&
          board[y + d * 2][x] == EMPTY) {

        legalMoves.add(
          new Move(
            x,
            y,
            x,
            y + d * 2
          )
        );
      }
    }

    // captures
    for (int dx = -1; dx <= 1; dx += 2) {

      int nx = x + dx;

      if (inside(nx, ny) &&
          board[ny][nx] != EMPTY &&
          sideOf(board[ny][nx]) != side) {

        legalMoves.add(
          new Move(
            x,
            y,
            nx,
            ny
          )
        );
      }
    }

    return;
  }

  if (type == KNIGHT) {

    int[][] n = {
      {1,2},{2,1},
      {-1,2},{-2,1},
      {1,-2},{2,-1},
      {-1,-2},{-2,-1}
    };

    for (int i = 0; i < 8; i++) {

      addIfLegal(
        x,
        y,
        x + n[i][0],
        y + n[i][1],
        side
      );
    }

    return;
  }

  if (type == KING) {

    for (int dx = -1; dx <= 1; dx++) {
      for (int dy = -1; dy <= 1; dy++) {

        if (dx == 0 && dy == 0)
          continue;

        addIfLegal(
          x,
          y,
          x + dx,
          y + dy,
          side
        );
      }
    }

    return;
  }

  if (type == ROOK ||
      type == QUEEN) {

    slide(
      x,y,
      side,
      1,0
    );

    slide(
      x,y,
      side,
      -1,0
    );

    slide(
      x,y,
      side,
      0,1
    );

    slide(
      x,y,
      side,
      0,-1
    );
  }

  if (type == BISHOP ||
      type == QUEEN) {

    slide(
      x,y,
      side,
      1,1
    );

    slide(
      x,y,
      side,
      1,-1
    );

    slide(
      x,y,
      side,
      -1,1
    );

    slide(
      x,y,
      side,
      -1,-1
    );
  }
}

// ------------------------------------------------------------
// SLIDING PIECES
// ------------------------------------------------------------

void slide(
  int x,
  int y,
  int side,
  int dx,
  int dy) {

  int nx = x + dx;
  int ny = y + dy;

  while (inside(nx, ny)) {

    if (board[ny][nx] == EMPTY) {

      legalMoves.add(
        new Move(
          x,y,nx,ny
        )
      );

    } else {

      if (sideOf(board[ny][nx]) != side) {

        legalMoves.add(
          new Move(
            x,y,nx,ny
          )
        );
      }

      break;
    }

    nx += dx;
    ny += dy;
  }
}

// ------------------------------------------------------------
// ADD MOVE
// ------------------------------------------------------------

void addIfLegal(
  int fx,
  int fy,
  int tx,
  int ty,
  int side) {

  if (!inside(tx,ty))
    return;

  if (board[ty][tx] == EMPTY ||
      sideOf(board[ty][tx]) != side) {

    legalMoves.add(
      new Move(
        fx,fy,tx,ty
      )
    );
  }
}

// ------------------------------------------------------------
// MAKE MOVE
// ------------------------------------------------------------

void makeMove(Move m) {

  board[m.ty][m.tx] =
    board[m.fy][m.fx];

  board[m.fy][m.fx] =
    EMPTY;

  // pawn promotion
  if (abs(board[m.ty][m.tx]) == PAWN) {

    if (m.ty == 7 || m.ty == 0) {

      board[m.ty][m.tx] =
        sideOf(board[m.ty][m.tx]) * QUEEN;
    }
  }
}

// ------------------------------------------------------------
// UNDO
// ------------------------------------------------------------

void undoMove(
  Move m,
  int captured) {

  board[m.fy][m.fx] =
    board[m.ty][m.tx];

  board[m.ty][m.tx] =
    captured;
}

// ------------------------------------------------------------
// KING ATTACK
// ------------------------------------------------------------

boolean isKingAttacked(int side) {

  int kx = -1;
  int ky = -1;

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {

      if (board[y][x] ==
          side * KING) {

        kx = x;
        ky = y;
      }
    }
  }

  if (kx < 0)
    return true;

  int enemy = -side;

  // pawn attack
  int pd = enemy == RED ? 1 : -1;

  for (int dx = -1; dx <= 1; dx += 2) {

    int x = kx + dx;
    int y = ky + pd;

    if (inside(x,y) &&
        board[y][x] ==
        enemy * PAWN)
      return true;
  }

  // knight
  int[][] n = {
    {1,2},{2,1},
    {-1,2},{-2,1},
    {1,-2},{2,-1},
    {-1,-2},{-2,-1}
  };

  for (int i = 0; i < 8; i++) {

    int x = kx + n[i][0];
    int y = ky + n[i][1];

    if (inside(x,y) &&
        board[y][x] ==
        enemy * KNIGHT)
      return true;
  }

  // king
  for (int dx = -1; dx <= 1; dx++) {
    for (int dy = -1; dy <= 1; dy++) {

      if (dx == 0 && dy == 0)
        continue;

      int x = kx + dx;
      int y = ky + dy;

      if (inside(x,y) &&
          board[y][x] ==
          enemy * KING)
        return true;
    }
  }

  // rook / queen
  if (rayAttack(
    kx,ky,enemy,
    1,0,ROOK))
    return true;

  if (rayAttack(
    kx,ky,enemy,
    -1,0,ROOK))
    return true;

  if (rayAttack(
    kx,ky,enemy,
    0,1,ROOK))
    return true;

  if (rayAttack(
    kx,ky,enemy,
    0,-1,ROOK))
    return true;

  // bishop / queen
  if (rayAttack(
    kx,ky,enemy,
    1,1,BISHOP))
    return true;

  if (rayAttack(
    kx,ky,enemy,
    1,-1,BISHOP))
    return true;

  if (rayAttack(
    kx,ky,enemy,
    -1,1,BISHOP))
    return true;

  if (rayAttack(
    kx,ky,enemy,
    -1,-1,BISHOP))
    return true;

  return false;
}

// ------------------------------------------------------------
// RAY ATTACK
// ------------------------------------------------------------

boolean rayAttack(
  int x,
  int y,
  int enemy,
  int dx,
  int dy,
  int wanted) {

  x += dx;
  y += dy;

  while (inside(x,y)) {

    int p = board[y][x];

    if (p != EMPTY) {

      if (p == enemy * wanted ||
          p == enemy * QUEEN)
        return true;

      return false;
    }

    x += dx;
    y += dy;
  }

  return false;
}

// ------------------------------------------------------------
// EVALUATION
// ------------------------------------------------------------

int evaluate() {

  int score = 0;

  for (int y = 0; y < 8; y++) {

    for (int x = 0; x < 8; x++) {

      int p = board[y][x];

      if (p == EMPTY)
        continue;

      int value = pieceValue(abs(p));

      if (p > 0)
        score += value;
      else
        score -= value;

      // central squares
      if (x >= 2 && x <= 5 &&
          y >= 2 && y <= 5) {

        if (p > 0)
          score += 3;
        else
          score -= 3;
      }
    }
  }

  return score;
}

// score from side perspective
int evaluateFor(int side) {

  return side == RED ?
    evaluate() :
    -evaluate();
}

// ------------------------------------------------------------
// PIECE VALUES
// ------------------------------------------------------------

int pieceValue(int p) {

  if (p == PAWN) return 100;
  if (p == KNIGHT) return 320;
  if (p == BISHOP) return 330;
  if (p == ROOK) return 500;
  if (p == QUEEN) return 900;
  if (p == KING) return 20000;

  return 0;
}

// ------------------------------------------------------------
// CAPTURE SORT
// ------------------------------------------------------------

void sortCaptures(ArrayList<Move> list) {

  for (int i = 0; i < list.size(); i++) {

    int best = i;

    for (int j = i + 1; j < list.size(); j++) {

      int a =
        abs(board[list.get(j).ty][list.get(j).tx]);

      int b =
        abs(board[list.get(best).ty][list.get(best).tx]);

      if (a > b)
        best = j;
    }

    Move temp = list.get(i);

    list.set(
      i,
      list.get(best)
    );

    list.set(
      best,
      temp
    );
  }
}

// ------------------------------------------------------------
// MEMORY
// ------------------------------------------------------------

void saveMemory(
  long key,
  Move m,
  int score) {

  if (memory.size() >= 5000)
    memory.remove(0);

  memory.add(
    new Memory(
      key,
      m,
      score
    )
  );
}

int getMemoryScore(long key) {

  for (int i = memory.size() - 1; i >= 0; i--) {

    if (memory.get(i).key == key)
      return memory.get(i).score;
  }

  return 999999;
}

// ------------------------------------------------------------
// BOARD KEY
// ------------------------------------------------------------

long boardKey() {

  long k = 7;

  for (int y = 0; y < 8; y++) {

    for (int x = 0; x < 8; x++) {

      k = k * 31 + board[y][x];
    }
  }

  k = k * 2 + (turn == RED ? 1 : 0);

  return k;
}

// ------------------------------------------------------------
// COPY MOVES
// ------------------------------------------------------------

ArrayList<Move> copyMoves(
  ArrayList<Move> source) {

  ArrayList<Move> r =
    new ArrayList<Move>();

  for (int i = 0; i < source.size(); i++) {

    Move m = source.get(i);

    r.add(
      new Move(
        m.fx,
        m.fy,
        m.tx,
        m.ty
      )
    );
  }

  return r;
}

// ------------------------------------------------------------
// GAME END
// ------------------------------------------------------------

void checkGameEnd() {

  generateLegalMoves(turn);

  if (legalMoves.size() == 0) {

    gameOver = true;

    if (kingExists(turn)) {

      if (isKingAttacked(turn))
        bestMoveText =
          "CHECKMATE";
      else
        bestMoveText =
          "STALEMATE";
    }
  }
}

// ------------------------------------------------------------
// KING EXISTS
// ------------------------------------------------------------

boolean kingExists(int side) {

  for (int y = 0; y < 8; y++) {

    for (int x = 0; x < 8; x++) {

      if (board[y][x] ==
          side * KING)
        return true;
    }
  }

  return false;
}

// ------------------------------------------------------------
// HELPERS
// ------------------------------------------------------------

boolean inside(int x, int y) {

  return x >= 0 &&
         x < 8 &&
         y >= 0 &&
         y < 8;
}

int sideOf(int p) {

  if (p > 0)
    return RED;

  if (p < 0)
    return BLUE;

  return 0;
}

String pieceChar(int p) {

  if (p == PAWN)   return "V";
  if (p == ROOK)   return "T";
  if (p == KNIGHT) return "O";
  if (p == BISHOP) return "X";
  if (p == KING)   return "W";
  if (p == QUEEN)  return "U";

  return "";
}

String moveText(Move m) {

  return squareName(m.fx,m.fy) +
         "-" +
         squareName(m.tx,m.ty);
}

String squareName(int x, int y) {

  char f = char('A' + x);

  int rank = y + 1;

  return "" + f + rank;
}

// ------------------------------------------------------------
// MOVE CLASS
// ------------------------------------------------------------

class Move {

  int fx;
  int fy;

  int tx;
  int ty;

  Move(
    int a,
    int b,
    int c,
    int d) {

    fx = a;
    fy = b;
    tx = c;
    ty = d;
  }
}

// ------------------------------------------------------------
// MEMORY CLASS
// ------------------------------------------------------------

class Memory {

  long key;

  Move move;

  int score;

  Memory(
    long k,
    Move m,
    int s) {

    key = k;

    move =
      new Move(
        m.fx,
        m.fy,
        m.tx,
        m.ty
      );

    score = s;
  }
}




// ============================================================
// CUSTOM CHESS ENGINE - APDE 0.5.3
// Single PDE file
//
// Pieces:
// T = Rook
// O = Knight
// X = Bishop
// W = King
// U = Queen
// V = Pawn
//
// RED = uppercase
// BLUE = lowercase
//
// Engine:
// - Legal moves
// - Capture search
// - Alpha-beta
// - Depth 8
// - Best move
// - Move memory
// - Search marks
// ============================================================

final int EMPTY = 0;

final int PAWN   = 1;
final int ROOK   = 2;
final int KNIGHT = 3;
final int BISHOP = 4;
final int KING   = 5;
final int QUEEN  = 6;

final int RED  = 1;
final int BLUE = -1;

int[][] board = new int[8][8];

int turn = RED;

int selectedX = -1;
int selectedY = -1;

ArrayList<Move> legalMoves = new ArrayList<Move>();

String bestMoveText = "";
int bestScore = 0;

boolean engineRed = true;
boolean engineBlue = true;

boolean thinking = false;
boolean gameOver = false;

int searchDepth = 8;

long nodes = 0;
long maxNodes = 180000;

ArrayList<Memory> memory = new ArrayList<Memory>();

// ------------------------------------------------------------
// SETUP
// ------------------------------------------------------------

void setup() {
  fullScreen();
  orientation(PORTRAIT);

  textAlign(CENTER, CENTER);
  rectMode(CORNER);

  newGame();
}

// ------------------------------------------------------------
// NEW GAME
// ------------------------------------------------------------

void newGame() {

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {
      board[y][x] = EMPTY;
    }
  }

  // RED
  board[0][0] = ROOK;
  board[0][1] = KNIGHT;
  board[0][2] = BISHOP;
  board[0][3] = KING;
  board[0][4] = QUEEN;
  board[0][5] = BISHOP;
  board[0][6] = KNIGHT;
  board[0][7] = ROOK;

  for (int x = 0; x < 8; x++)
    board[1][x] = PAWN;

  // BLUE
  board[7][0] = -ROOK;
  board[7][1] = -KNIGHT;
  board[7][2] = -BISHOP;
  board[7][3] = -KING;
  board[7][4] = -QUEEN;
  board[7][5] = -BISHOP;
  board[7][6] = -KNIGHT;
  board[7][7] = -ROOK;

  for (int x = 0; x < 8; x++)
    board[6][x] = -PAWN;

  turn = RED;

  selectedX = -1;
  selectedY = -1;

  bestMoveText = "";
  bestScore = 0;

  legalMoves.clear();

  memory.clear();

  gameOver = false;
  thinking = false;

  generateLegalMoves(turn);
}

// ------------------------------------------------------------
// DRAW
// ------------------------------------------------------------

void draw() {

  background(40);

  float boardSize = min(width - 20, height - 180);
  float sx = (width - boardSize) / 2.0;
  float sy = 45;

  float sq = boardSize / 8.0;

  // BOARD
  for (int y = 0; y < 8; y++) {

    for (int x = 0; x < 8; x++) {

      if ((x + y) % 2 == 0)
        fill(245, 220, 80);
      else
        fill(210, 210, 210);

      rect(sx + x * sq,
           sy + y * sq,
           sq,
           sq);

      // selected square
      if (x == selectedX && y == selectedY) {
        noFill();
        stroke(255, 0, 0);
        strokeWeight(5);
        rect(sx + x * sq + 3,
             sy + y * sq + 3,
             sq - 6,
             sq - 6);
        noStroke();
      }
    }
  }

  // LEGAL MOVE MARKS
  fill(0, 180, 0, 150);

  for (int i = 0; i < legalMoves.size(); i++) {

    Move m = legalMoves.get(i);

    if (m.fx == selectedX && m.fy == selectedY) {

      ellipse(
        sx + m.tx * sq + sq / 2,
        sy + m.ty * sq + sq / 2,
        sq * 0.25,
        sq * 0.25
      );
    }
  }

  // PIECES
  textSize(sq * 0.62);

  for (int y = 0; y < 8; y++) {

    for (int x = 0; x < 8; x++) {

      int p = board[y][x];

      if (p == EMPTY)
        continue;

      if (p > 0)
        fill(220, 30, 30);
      else
        fill(30, 70, 230);

      text(
        pieceChar(abs(p)),
        sx + x * sq + sq / 2,
        sy + y * sq + sq / 2
      );
    }
  }

  // BEST MOVE
  if (bestMoveText.length() > 0) {

    stroke(0, 255, 0);
    strokeWeight(4);
    noFill();

    // text only; board remains clean
    noStroke();

    fill(255);
    textSize(18);

    text(
      "BEST: " + bestMoveText +
      "  SCORE " + bestScore +
      "  DEPTH " + searchDepth,
      width / 2,
      height - 95
    );
  }

  // STATUS
  fill(255);
  textSize(20);

  String side;

  if (turn == RED)
    side = "RED";
  else
    side = "BLUE";

  text(
    thinking ? "ENGINE THINKING..." :
    gameOver ? "GAME END" :
    side + " TO MOVE",
    width / 2,
    20
  );

  // BUTTONS
  drawButton(
    10,
    height - 65,
    width / 2 - 15,
    50,
    "NEW GAME"
  );

  drawButton(
    width / 2 + 5,
    height - 65,
    width / 2 - 15,
    50,
    "ENGINE MOVE"
  );

  // engine info
  fill(220);
  textSize(13);

  text(
    "Nodes: " + nodes +
    "   Memory: " + memory.size(),
    width / 2,
    height - 120
  );
}

// ------------------------------------------------------------
// BUTTON
// ------------------------------------------------------------

void drawButton(float x, float y, float w, float h, String s) {

  fill(70);
  rect(x, y, w, h);

  fill(255);
  textSize(16);

  text(
    s,
    x + w / 2,
    y + h / 2
  );
}

// ------------------------------------------------------------
// TOUCH
// ------------------------------------------------------------

void mousePressed() {

  if (mouseY > height - 70) {

    if (mouseX < width / 2) {
      newGame();
      return;
    }

    if (mouseX >= width / 2) {
      if (!thinking && !gameOver)
        engineMove();
      return;
    }
  }

  float boardSize = min(width - 20, height - 180);
  float sx = (width - boardSize) / 2.0;
  float sy = 45;
  float sq = boardSize / 8.0;

  if (mouseX < sx ||
      mouseX >= sx + boardSize ||
      mouseY < sy ||
      mouseY >= sy + boardSize)
    return;

  int x = int((mouseX - sx) / sq);
  int y = int((mouseY - sy) / sq);

  if (x < 0 || x > 7 || y < 0 || y > 7)
    return;

  humanSquare(x, y);
}

// ------------------------------------------------------------
// HUMAN MOVE
// ------------------------------------------------------------

void humanSquare(int x, int y) {

  if (thinking || gameOver)
    return;

  int p = board[y][x];

  if (selectedX < 0) {

    if (p != EMPTY &&
        sideOf(p) == turn) {

      selectedX = x;
      selectedY = y;

    }

    return;
  }

  // select another own piece
  if (p != EMPTY &&
      sideOf(p) == turn) {

    selectedX = x;
    selectedY = y;

    return;
  }

  // find legal selected -> destination
  for (int i = 0; i < legalMoves.size(); i++) {

    Move m = legalMoves.get(i);

    if (m.fx == selectedX &&
        m.fy == selectedY &&
        m.tx == x &&
        m.ty == y) {

      makeMove(m);

      selectedX = -1;
      selectedY = -1;

      turn = -turn;

      generateLegalMoves(turn);

      checkGameEnd();

      return;
    }
  }
}

// ------------------------------------------------------------
// ENGINE MOVE
// ------------------------------------------------------------

void engineMove() {

  if (thinking || gameOver)
    return;

  thinking = true;

  nodes = 0;

  generateLegalMoves(turn);

  if (legalMoves.size() == 0) {
    thinking = false;
    gameOver = true;
    return;
  }

  Move best = searchRoot(turn);

  if (best != null) {

    bestMoveText = moveText(best);

    makeMove(best);

    turn = -turn;

    generateLegalMoves(turn);

    checkGameEnd();
  }

  thinking = false;
}

// ------------------------------------------------------------
// ROOT SEARCH
// ------------------------------------------------------------

Move searchRoot(int side) {

  ArrayList<Move> moves = copyMoves(legalMoves);

  // captures first
  sortCaptures(moves);

  int bestValue = -100000000;
  Move best = null;

  for (int i = 0; i < moves.size(); i++) {

    Move m = moves.get(i);

    int captured = board[m.ty][m.tx];

    makeMove(m);

    int value =
      -alphaBeta(
        -side,
        searchDepth - 1,
        -100000000,
        100000000
      );

    undoMove(m, captured);

    if (value > bestValue) {

      bestValue = value;
      best = m;
    }

    // memory
    saveMemory(
      boardKey(),
      m,
      value
    );
  }

  bestScore = bestValue;

  return best;
}

// ------------------------------------------------------------
// ALPHA BETA
// ------------------------------------------------------------

int alphaBeta(
  int side,
  int depth,
  int alpha,
  int beta) {

  nodes++;

  if (nodes > maxNodes)
    return evaluate();

  if (depth <= 0)
    return evaluateFor(side);

  generateLegalMoves(side);

  if (legalMoves.size() == 0) {

    if (kingExists(side))
      return -900000 + (searchDepth - depth);

    return 0;
  }

  // check memory
  int mem = getMemoryScore(boardKey());

  if (mem != 999999 &&
      depth <= 2)
    return mem;

  ArrayList<Move> moves = copyMoves(legalMoves);

  sortCaptures(moves);

  int best = -100000000;

  for (int i = 0; i < moves.size(); i++) {

    Move m = moves.get(i);

    int captured = board[m.ty][m.tx];

    makeMove(m);

    int value =
      -alphaBeta(
        -side,
        depth - 1,
        -beta,
        -alpha
      );

    undoMove(m, captured);

    if (value > best)
      best = value;

    if (value > alpha)
      alpha = value;

    if (alpha >= beta)
      break;
  }

  return best;
}

// ------------------------------------------------------------
// LEGAL MOVES
// ------------------------------------------------------------

void generateLegalMoves(int side) {

  legalMoves.clear();

  for (int y = 0; y < 8; y++) {

    for (int x = 0; x < 8; x++) {

      int p = board[y][x];

      if (p == EMPTY)
        continue;

      if (sideOf(p) != side)
        continue;

      generatePieceMoves(
        x,
        y,
        p,
        side
      );
    }
  }

  // remove moves that leave own king attacked
  for (int i = legalMoves.size() - 1; i >= 0; i--) {

    Move m = legalMoves.get(i);

    int captured = board[m.ty][m.tx];

    makeMove(m);

    boolean bad = isKingAttacked(side);

    undoMove(m, captured);

    if (bad)
      legalMoves.remove(i);
  }
}

// ------------------------------------------------------------
// PIECE MOVES
// ------------------------------------------------------------

void generatePieceMoves(
  int x,
  int y,
  int p,
  int side) {

  int type = abs(p);

  if (type == PAWN) {

    int d = side == RED ? 1 : -1;

    int ny = y + d;

    if (inside(x, ny) &&
        board[ny][x] == EMPTY) {

      legalMoves.add(
        new Move(x, y, x, ny)
      );

      int start = side == RED ? 1 : 6;

      if (y == start &&
          board[y + d * 2][x] == EMPTY) {

        legalMoves.add(
          new Move(
            x,
            y,
            x,
            y + d * 2
          )
        );
      }
    }

    // captures
    for (int dx = -1; dx <= 1; dx += 2) {

      int nx = x + dx;

      if (inside(nx, ny) &&
          board[ny][nx] != EMPTY &&
          sideOf(board[ny][nx]) != side) {

        legalMoves.add(
          new Move(
            x,
            y,
            nx,
            ny
          )
        );
      }
    }

    return;
  }

  if (type == KNIGHT) {

    int[][] n = {
      {1,2},{2,1},
      {-1,2},{-2,1},
      {1,-2},{2,-1},
      {-1,-2},{-2,-1}
    };

    for (int i = 0; i < 8; i++) {

      addIfLegal(
        x,
        y,
        x + n[i][0],
        y + n[i][1],
        side
      );
    }

    return;
  }

  if (type == KING) {

    for (int dx = -1; dx <= 1; dx++) {
      for (int dy = -1; dy <= 1; dy++) {

        if (dx == 0 && dy == 0)
          continue;

        addIfLegal(
          x,
          y,
          x + dx,
          y + dy,
          side
        );
      }
    }

    return;
  }

  if (type == ROOK ||
      type == QUEEN) {

    slide(
      x,y,
      side,
      1,0
    );

    slide(
      x,y,
      side,
      -1,0
    );

    slide(
      x,y,
      side,
      0,1
    );

    slide(
      x,y,
      side,
      0,-1
    );
  }

  if (type == BISHOP ||
      type == QUEEN) {

    slide(
      x,y,
      side,
      1,1
    );

    slide(
      x,y,
      side,
      1,-1
    );

    slide(
      x,y,
      side,
      -1,1
    );

    slide(
      x,y,
      side,
      -1,-1
    );
  }
}

// ------------------------------------------------------------
// SLIDING PIECES
// ------------------------------------------------------------

void slide(
  int x,
  int y,
  int side,
  int dx,
  int dy) {

  int nx = x + dx;
  int ny = y + dy;

  while (inside(nx, ny)) {

    if (board[ny][nx] == EMPTY) {

      legalMoves.add(
        new Move(
          x,y,nx,ny
        )
      );

    } else {

      if (sideOf(board[ny][nx]) != side) {

        legalMoves.add(
          new Move(
            x,y,nx,ny
          )
        );
      }

      break;
    }

    nx += dx;
    ny += dy;
  }
}

// ------------------------------------------------------------
// ADD MOVE
// ------------------------------------------------------------

void addIfLegal(
  int fx,
  int fy,
  int tx,
  int ty,
  int side) {

  if (!inside(tx,ty))
    return;

  if (board[ty][tx] == EMPTY ||
      sideOf(board[ty][tx]) != side) {

    legalMoves.add(
      new Move(
        fx,fy,tx,ty
      )
    );
  }
}

// ------------------------------------------------------------
// MAKE MOVE
// ------------------------------------------------------------

void makeMove(Move m) {

  board[m.ty][m.tx] =
    board[m.fy][m.fx];

  board[m.fy][m.fx] =
    EMPTY;

  // pawn promotion
  if (abs(board[m.ty][m.tx]) == PAWN) {

    if (m.ty == 7 || m.ty == 0) {

      board[m.ty][m.tx] =
        sideOf(board[m.ty][m.tx]) * QUEEN;
    }
  }
}

// ------------------------------------------------------------
// UNDO
// ------------------------------------------------------------

void undoMove(
  Move m,
  int captured) {

  board[m.fy][m.fx] =
    board[m.ty][m.tx];

  board[m.ty][m.tx] =
    captured;
}

// ------------------------------------------------------------
// KING ATTACK
// ------------------------------------------------------------

boolean isKingAttacked(int side) {

  int kx = -1;
  int ky = -1;

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {

      if (board[y][x] ==
          side * KING) {

        kx = x;
        ky = y;
      }
    }
  }

  if (kx < 0)
    return true;

  int enemy = -side;

  // pawn attack
  int pd = enemy == RED ? 1 : -1;

  for (int dx = -1; dx <= 1; dx += 2) {

    int x = kx + dx;
    int y = ky + pd;

    if (inside(x,y) &&
        board[y][x] ==
        enemy * PAWN)
      return true;
  }

  // knight
  int[][] n = {
    {1,2},{2,1},
    {-1,2},{-2,1},
    {1,-2},{2,-1},
    {-1,-2},{-2,-1}
  };

  for (int i = 0; i < 8; i++) {

    int x = kx + n[i][0];
    int y = ky + n[i][1];

    if (inside(x,y) &&
        board[y][x] ==
        enemy * KNIGHT)
      return true;
  }

  // king
  for (int dx = -1; dx <= 1; dx++) {
    for (int dy = -1; dy <= 1; dy++) {

      if (dx == 0 && dy == 0)
        continue;

      int x = kx + dx;
      int y = ky + dy;

      if (inside(x,y) &&
          board[y][x] ==
          enemy * KING)
        return true;
    }
  }

  // rook / queen
  if (rayAttack(
    kx,ky,enemy,
    1,0,ROOK))
    return true;

  if (rayAttack(
    kx,ky,enemy,
    -1,0,ROOK))
    return true;

  if (rayAttack(
    kx,ky,enemy,
    0,1,ROOK))
    return true;

  if (rayAttack(
    kx,ky,enemy,
    0,-1,ROOK))
    return true;

  // bishop / queen
  if (rayAttack(
    kx,ky,enemy,
    1,1,BISHOP))
    return true;

  if (rayAttack(
    kx,ky,enemy,
    1,-1,BISHOP))
    return true;

  if (rayAttack(
    kx,ky,enemy,
    -1,1,BISHOP))
    return true;

  if (rayAttack(
    kx,ky,enemy,
    -1,-1,BISHOP))
    return true;

  return false;
}

// ------------------------------------------------------------
// RAY ATTACK
// ------------------------------------------------------------

boolean rayAttack(
  int x,
  int y,
  int enemy,
  int dx,
  int dy,
  int wanted) {

  x += dx;
  y += dy;

  while (inside(x,y)) {

    int p = board[y][x];

    if (p != EMPTY) {

      if (p == enemy * wanted ||
          p == enemy * QUEEN)
        return true;

      return false;
    }

    x += dx;
    y += dy;
  }

  return false;
}

// ------------------------------------------------------------
// EVALUATION
// ------------------------------------------------------------

int evaluate() {

  int score = 0;

  for (int y = 0; y < 8; y++) {

    for (int x = 0; x < 8; x++) {

      int p = board[y][x];

      if (p == EMPTY)
        continue;

      int value = pieceValue(abs(p));

      if (p > 0)
        score += value;
      else
        score -= value;

      // central squares
      if (x >= 2 && x <= 5 &&
          y >= 2 && y <= 5) {

        if (p > 0)
          score += 3;
        else
          score -= 3;
      }
    }
  }

  return score;
}

// score from side perspective
int evaluateFor(int side) {

  return side == RED ?
    evaluate() :
    -evaluate();
}

// ------------------------------------------------------------
// PIECE VALUES
// ------------------------------------------------------------

int pieceValue(int p) {

  if (p == PAWN) return 100;
  if (p == KNIGHT) return 320;
  if (p == BISHOP) return 330;
  if (p == ROOK) return 500;
  if (p == QUEEN) return 900;
  if (p == KING) return 20000;

  return 0;
}

// ------------------------------------------------------------
// CAPTURE SORT
// ------------------------------------------------------------

void sortCaptures(ArrayList<Move> list) {

  for (int i = 0; i < list.size(); i++) {

    int best = i;

    for (int j = i + 1; j < list.size(); j++) {

      int a =
        abs(board[list.get(j).ty][list.get(j).tx]);

      int b =
        abs(board[list.get(best).ty][list.get(best).tx]);

      if (a > b)
        best = j;
    }

    Move temp = list.get(i);

    list.set(
      i,
      list.get(best)
    );

    list.set(
      best,
      temp
    );
  }
}

// ------------------------------------------------------------
// MEMORY
// ------------------------------------------------------------

void saveMemory(
  long key,
  Move m,
  int score) {

  if (memory.size() >= 5000)
    memory.remove(0);

  memory.add(
    new Memory(
      key,
      m,
      score
    )
  );
}

int getMemoryScore(long key) {

  for (int i = memory.size() - 1; i >= 0; i--) {

    if (memory.get(i).key == key)
      return memory.get(i).score;
  }

  return 999999;
}

// ------------------------------------------------------------
// BOARD KEY
// ------------------------------------------------------------

long boardKey() {

  long k = 7;

  for (int y = 0; y < 8; y++) {

    for (int x = 0; x < 8; x++) {

      k = k * 31 + board[y][x];
    }
  }

  k = k * 2 + (turn == RED ? 1 : 0);

  return k;
}

// ------------------------------------------------------------
// COPY MOVES
// ------------------------------------------------------------

ArrayList<Move> copyMoves(
  ArrayList<Move> source) {

  ArrayList<Move> r =
    new ArrayList<Move>();

  for (int i = 0; i < source.size(); i++) {

    Move m = source.get(i);

    r.add(
      new Move(
        m.fx,
        m.fy,
        m.tx,
        m.ty
      )
    );
  }

  return r;
}

// ------------------------------------------------------------
// GAME END
// ------------------------------------------------------------

void checkGameEnd() {

  generateLegalMoves(turn);

  if (legalMoves.size() == 0) {

    gameOver = true;

    if (kingExists(turn)) {

      if (isKingAttacked(turn))
        bestMoveText =
          "CHECKMATE";
      else
        bestMoveText =
          "STALEMATE";
    }
  }
}

// ------------------------------------------------------------
// KING EXISTS
// ------------------------------------------------------------

boolean kingExists(int side) {

  for (int y = 0; y < 8; y++) {

    for (int x = 0; x < 8; x++) {

      if (board[y][x] ==
          side * KING)
        return true;
    }
  }

  return false;
}

// ------------------------------------------------------------
// HELPERS
// ------------------------------------------------------------

boolean inside(int x, int y) {

  return x >= 0 &&
         x < 8 &&
         y >= 0 &&
         y < 8;
}

int sideOf(int p) {

  if (p > 0)
    return RED;

  if (p < 0)
    return BLUE;

  return 0;
}

String pieceChar(int p) {

  if (p == PAWN)   return "V";
  if (p == ROOK)   return "T";
  if (p == KNIGHT) return "O";
  if (p == BISHOP) return "X";
  if (p == KING)   return "W";
  if (p == QUEEN)  return "U";

  return "";
}

String moveText(Move m) {

  return squareName(m.fx,m.fy) +
         "-" +
         squareName(m.tx,m.ty);
}

String squareName(int x, int y) {

  char f = char('A' + x);

  int rank = y + 1;

  return "" + f + rank;
}

// ------------------------------------------------------------
// MOVE CLASS
// ------------------------------------------------------------

class Move {

  int fx;
  int fy;

  int tx;
  int ty;

  Move(
    int a,
    int b,
    int c,
    int d) {

    fx = a;
    fy = b;
    tx = c;
    ty = d;
  }
}

// ------------------------------------------------------------
// MEMORY CLASS
// ------------------------------------------------------------

class Memory {

  long key;

  Move move;

  int score;

  Memory(
    long k,
    Move m,
    int s) {

    key = k;

    move =
      new Move(
        m.fx,
        m.fy,
        m.tx,
        m.ty
      );

    score = s;
  }
}











// ============================================================
// CUSTOM CHESS ENGINE - APDE 0.5.3
// Single PDE file
//
// Pieces:
// T = Rook
// O = Knight
// X = Bishop
// W = King
// U = Queen
// V = Pawn
//
// RED = uppercase
// BLUE = lowercase
//
// Engine:
// - Legal moves
// - Capture search
// - Alpha-beta
// - Depth 8
// - Best move
// - Move memory
// - Search marks
// ============================================================

final int EMPTY = 0;

final int PAWN   = 1;
final int ROOK   = 2;
final int KNIGHT = 3;
final int BISHOP = 4;
final int KING   = 5;
final int QUEEN  = 6;

final int RED  = 1;
final int BLUE = -1;

int[][] board = new int[8][8];

int turn = RED;

int selectedX = -1;
int selectedY = -1;

ArrayList<Move> legalMoves = new ArrayList<Move>();

String bestMoveText = "";
int bestScore = 0;

boolean engineRed = true;
boolean engineBlue = true;

boolean thinking = false;
boolean gameOver = false;

int searchDepth = 8;

long nodes = 0;
long maxNodes = 180000;

ArrayList<Memory> memory = new ArrayList<Memory>();

// ------------------------------------------------------------
// SETUP
// ------------------------------------------------------------

void setup() {
  fullScreen();
  orientation(PORTRAIT);

  textAlign(CENTER, CENTER);
  rectMode(CORNER);

  newGame();
}

// ------------------------------------------------------------
// NEW GAME
// ------------------------------------------------------------

void newGame() {

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {
      board[y][x] = EMPTY;
    }
  }

  // RED
  board[0][0] = ROOK;
  board[0][1] = KNIGHT;
  board[0][2] = BISHOP;
  board[0][3] = KING;
  board[0][4] = QUEEN;
  board[0][5] = BISHOP;
  board[0][6] = KNIGHT;
  board[0][7] = ROOK;

  for (int x = 0; x < 8; x++)
    board[1][x] = PAWN;

  // BLUE
  board[7][0] = -ROOK;
  board[7][1] = -KNIGHT;
  board[7][2] = -BISHOP;
  board[7][3] = -KING;
  board[7][4] = -QUEEN;
  board[7][5] = -BISHOP;
  board[7][6] = -KNIGHT;
  board[7][7] = -ROOK;

  for (int x = 0; x < 8; x++)
    board[6][x] = -PAWN;

  turn = RED;

  selectedX = -1;
  selectedY = -1;

  bestMoveText = "";
  bestScore = 0;

  legalMoves.clear();

  memory.clear();

  gameOver = false;
  thinking = false;

  generateLegalMoves(turn);
}

// ------------------------------------------------------------
// DRAW
// ------------------------------------------------------------

void draw() {

  background(40);

  float boardSize = min(width - 20, height - 180);
  float sx = (width - boardSize) / 2.0;
  float sy = 45;

  float sq = boardSize / 8.0;

  // BOARD
  for (int y = 0; y < 8; y++) {

    for (int x = 0; x < 8; x++) {

      if ((x + y) % 2 == 0)
        fill(245, 220, 80);
      else
        fill(210, 210, 210);

      rect(sx + x * sq,
           sy + y * sq,
           sq,
           sq);

      // selected square
      if (x == selectedX && y == selectedY) {
        noFill();
        stroke(255, 0, 0);
        strokeWeight(5);
        rect(sx + x * sq + 3,
             sy + y * sq + 3,
             sq - 6,
             sq - 6);
        noStroke();
      }
    }
  }

  // LEGAL MOVE MARKS
  fill(0, 180, 0, 150);

  for (int i = 0; i < legalMoves.size(); i++) {

    Move m = legalMoves.get(i);

    if (m.fx == selectedX && m.fy == selectedY) {

      ellipse(
        sx + m.tx * sq + sq / 2,
        sy + m.ty * sq + sq / 2,
        sq * 0.25,
        sq * 0.25
      );
    }
  }

  // PIECES
  textSize(sq * 0.62);

  for (int y = 0; y < 8; y++) {

    for (int x = 0; x < 8; x++) {

      int p = board[y][x];

      if (p == EMPTY)
        continue;

      if (p > 0)
        fill(220, 30, 30);
      else
        fill(30, 70, 230);

      text(
        pieceChar(abs(p)),
        sx + x * sq + sq / 2,
        sy + y * sq + sq / 2
      );
    }
  }

  // BEST MOVE
  if (bestMoveText.length() > 0) {

    stroke(0, 255, 0);
    strokeWeight(4);
    noFill();

    // text only; board remains clean
    noStroke();

    fill(255);
    textSize(18);

    text(
      "BEST: " + bestMoveText +
      "  SCORE " + bestScore +
      "  DEPTH " + searchDepth,
      width / 2,
      height - 95
    );
  }

  // STATUS
  fill(255);
  textSize(20);

  String side;

  if (turn == RED)
    side = "RED";
  else
    side = "BLUE";

  text(
    thinking ? "ENGINE THINKING..." :
    gameOver ? "GAME END" :
    side + " TO MOVE",
    width / 2,
    20
  );

  // BUTTONS
  drawButton(
    10,
    height - 65,
    width / 2 - 15,
    50,
    "NEW GAME"
  );

  drawButton(
    width / 2 + 5,
    height - 65,
    width / 2 - 15,
    50,
    "ENGINE MOVE"
  );

  // engine info
  fill(220);
  textSize(13);

  text(
    "Nodes: " + nodes +
    "   Memory: " + memory.size(),
    width / 2,
    height - 120
  );
}

// ------------------------------------------------------------
// BUTTON
// ------------------------------------------------------------

void drawButton(float x, float y, float w, float h, String s) {

  fill(70);
  rect(x, y, w, h);

  fill(255);
  textSize(16);

  text(
    s,
    x + w / 2,
    y + h / 2
  );
}

// ------------------------------------------------------------
// TOUCH
// ------------------------------------------------------------

void mousePressed() {

  if (mouseY > height - 70) {

    if (mouseX < width / 2) {
      newGame();
      return;
    }

    if (mouseX >= width / 2) {
      if (!thinking && !gameOver)
        engineMove();
      return;
    }
  }

  float boardSize = min(width - 20, height - 180);
  float sx = (width - boardSize) / 2.0;
  float sy = 45;
  float sq = boardSize / 8.0;

  if (mouseX < sx ||
      mouseX >= sx + boardSize ||
      mouseY < sy ||
      mouseY >= sy + boardSize)
    return;

  int x = int((mouseX - sx) / sq);
  int y = int((mouseY - sy) / sq);

  if (x < 0 || x > 7 || y < 0 || y > 7)
    return;

  humanSquare(x, y);
}

// ------------------------------------------------------------
// HUMAN MOVE
// ------------------------------------------------------------

void humanSquare(int x, int y) {

  if (thinking || gameOver)
    return;

  int p = board[y][x];

  if (selectedX < 0) {

    if (p != EMPTY &&
        sideOf(p) == turn) {

      selectedX = x;
      selectedY = y;

    }

    return;
  }

  // select another own piece
  if (p != EMPTY &&
      sideOf(p) == turn) {

    selectedX = x;
    selectedY = y;

    return;
  }

  // find legal selected -> destination
  for (int i = 0; i < legalMoves.size(); i++) {

    Move m = legalMoves.get(i);

    if (m.fx == selectedX &&
        m.fy == selectedY &&
        m.tx == x &&
        m.ty == y) {

      makeMove(m);

      selectedX = -1;
      selectedY = -1;

      turn = -turn;

      generateLegalMoves(turn);

      checkGameEnd();

      return;
    }
  }
}

// ------------------------------------------------------------
// ENGINE MOVE
// ------------------------------------------------------------

void engineMove() {

  if (thinking || gameOver)
    return;

  thinking = true;

  nodes = 0;

  generateLegalMoves(turn);

  if (legalMoves.size() == 0) {
    thinking = false;
    gameOver = true;
    return;
  }

  Move best = searchRoot(turn);

  if (best != null) {

    bestMoveText = moveText(best);

    makeMove(best);

    turn = -turn;

    generateLegalMoves(turn);

    checkGameEnd();
  }

  thinking = false;
}

// ------------------------------------------------------------
// ROOT SEARCH
// ------------------------------------------------------------

Move searchRoot(int side) {

  ArrayList<Move> moves = copyMoves(legalMoves);

  // captures first
  sortCaptures(moves);

  int bestValue = -100000000;
  Move best = null;

  for (int i = 0; i < moves.size(); i++) {

    Move m = moves.get(i);

    int captured = board[m.ty][m.tx];

    makeMove(m);

    int value =
      -alphaBeta(
        -side,
        searchDepth - 1,
        -100000000,
        100000000
      );

    undoMove(m, captured);

    if (value > bestValue) {

      bestValue = value;
      best = m;
    }

    // memory
    saveMemory(
      boardKey(),
      m,
      value
    );
  }

  bestScore = bestValue;

  return best;
}

// ------------------------------------------------------------
// ALPHA BETA
// ------------------------------------------------------------

int alphaBeta(
  int side,
  int depth,
  int alpha,
  int beta) {

  nodes++;

  if (nodes > maxNodes)
    return evaluate();

  if (depth <= 0)
    return evaluateFor(side);

  generateLegalMoves(side);

  if (legalMoves.size() == 0) {

    if (kingExists(side))
      return -900000 + (searchDepth - depth);

    return 0;
  }

  // check memory
  int mem = getMemoryScore(boardKey());

  if (mem != 999999 &&
      depth <= 2)
    return mem;

  ArrayList<Move> moves = copyMoves(legalMoves);

  sortCaptures(moves);

  int best = -100000000;

  for (int i = 0; i < moves.size(); i++) {

    Move m = moves.get(i);

    int captured = board[m.ty][m.tx];

    makeMove(m);

    int value =
      -alphaBeta(
        -side,
        depth - 1,
        -beta,
        -alpha
      );

    undoMove(m, captured);

    if (value > best)
      best = value;

    if (value > alpha)
      alpha = value;

    if (alpha >= beta)
      break;
  }

  return best;
}

// ------------------------------------------------------------
// LEGAL MOVES
// ------------------------------------------------------------

void generateLegalMoves(int side) {

  legalMoves.clear();

  for (int y = 0; y < 8; y++) {

    for (int x = 0; x < 8; x++) {

      int p = board[y][x];

      if (p == EMPTY)
        continue;

      if (sideOf(p) != side)
        continue;

      generatePieceMoves(
        x,
        y,
        p,
        side
      );
    }
  }

  // remove moves that leave own king attacked
  for (int i = legalMoves.size() - 1; i >= 0; i--) {

    Move m = legalMoves.get(i);

    int captured = board[m.ty][m.tx];

    makeMove(m);

    boolean bad = isKingAttacked(side);

    undoMove(m, captured);

    if (bad)
      legalMoves.remove(i);
  }
}

// ------------------------------------------------------------
// PIECE MOVES
// ------------------------------------------------------------

void generatePieceMoves(
  int x,
  int y,
  int p,
  int side) {

  int type = abs(p);

  if (type == PAWN) {

    int d = side == RED ? 1 : -1;

    int ny = y + d;

    if (inside(x, ny) &&
        board[ny][x] == EMPTY) {

      legalMoves.add(
        new Move(x, y, x, ny)
      );

      int start = side == RED ? 1 : 6;

      if (y == start &&
          board[y + d * 2][x] == EMPTY) {

        legalMoves.add(
          new Move(
            x,
            y,
            x,
            y + d * 2
          )
        );
      }
    }

    // captures
    for (int dx = -1; dx <= 1; dx += 2) {

      int nx = x + dx;

      if (inside(nx, ny) &&
          board[ny][nx] != EMPTY &&
          sideOf(board[ny][nx]) != side) {

        legalMoves.add(
          new Move(
            x,
            y,
            nx,
            ny
          )
        );
      }
    }

    return;
  }

  if (type == KNIGHT) {

    int[][] n = {
      {1,2},{2,1},
      {-1,2},{-2,1},
      {1,-2},{2,-1},
      {-1,-2},{-2,-1}
    };

    for (int i = 0; i < 8; i++) {

      addIfLegal(
        x,
        y,
        x + n[i][0],
        y + n[i][1],
        side
      );
    }

    return;
  }

  if (type == KING) {

    for (int dx = -1; dx <= 1; dx++) {
      for (int dy = -1; dy <= 1; dy++) {

        if (dx == 0 && dy == 0)
          continue;

        addIfLegal(
          x,
          y,
          x + dx,
          y + dy,
          side
        );
      }
    }

    return;
  }

  if (type == ROOK ||
      type == QUEEN) {

    slide(
      x,y,
      side,
      1,0
    );

    slide(
      x,y,
      side,
      -1,0
    );

    slide(
      x,y,
      side,
      0,1
    );

    slide(
      x,y,
      side,
      0,-1
    );
  }

  if (type == BISHOP ||
      type == QUEEN) {

    slide(
      x,y,
      side,
      1,1
    );

    slide(
      x,y,
      side,
      1,-1
    );

    slide(
      x,y,
      side,
      -1,1
    );

    slide(
      x,y,
      side,
      -1,-1
    );
  }
}

// ------------------------------------------------------------
// SLIDING PIECES
// ------------------------------------------------------------

void slide(
  int x,
  int y,
  int side,
  int dx,
  int dy) {

  int nx = x + dx;
  int ny = y + dy;

  while (inside(nx, ny)) {

    if (board[ny][nx] == EMPTY) {

      legalMoves.add(
        new Move(
          x,y,nx,ny
        )
      );

    } else {

      if (sideOf(board[ny][nx]) != side) {

        legalMoves.add(
          new Move(
            x,y,nx,ny
          )
        );
      }

      break;
    }

    nx += dx;
    ny += dy;
  }
}

// ------------------------------------------------------------
// ADD MOVE
// ------------------------------------------------------------

void addIfLegal(
  int fx,
  int fy,
  int tx,
  int ty,
  int side) {

  if (!inside(tx,ty))
    return;

  if (board[ty][tx] == EMPTY ||
      sideOf(board[ty][tx]) != side) {

    legalMoves.add(
      new Move(
        fx,fy,tx,ty
      )
    );
  }
}

// ------------------------------------------------------------
// MAKE MOVE
// ------------------------------------------------------------

void makeMove(Move m) {

  board[m.ty][m.tx] =
    board[m.fy][m.fx];

  board[m.fy][m.fx] =
    EMPTY;

  // pawn promotion
  if (abs(board[m.ty][m.tx]) == PAWN) {

    if (m.ty == 7 || m.ty == 0) {

      board[m.ty][m.tx] =
        sideOf(board[m.ty][m.tx]) * QUEEN;
    }
  }
}

// ------------------------------------------------------------
// UNDO
// ------------------------------------------------------------

void undoMove(
  Move m,
  int captured) {

  board[m.fy][m.fx] =
    board[m.ty][m.tx];

  board[m.ty][m.tx] =
    captured;
}

// ------------------------------------------------------------
// KING ATTACK
// ------------------------------------------------------------

boolean isKingAttacked(int side) {

  int kx = -1;
  int ky = -1;

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {

      if (board[y][x] ==
          side * KING) {

        kx = x;
        ky = y;
      }
    }
  }

  if (kx < 0)
    return true;

  int enemy = -side;

  // pawn attack
  int pd = enemy == RED ? 1 : -1;

  for (int dx = -1; dx <= 1; dx += 2) {

    int x = kx + dx;
    int y = ky + pd;

    if (inside(x,y) &&
        board[y][x] ==
        enemy * PAWN)
      return true;
  }

  // knight
  int[][] n = {
    {1,2},{2,1},
    {-1,2},{-2,1},
    {1,-2},{2,-1},
    {-1,-2},{-2,-1}
  };

  for (int i = 0; i < 8; i++) {

    int x = kx + n[i][0];
    int y = ky + n[i][1];

    if (inside(x,y) &&
        board[y][x] ==
        enemy * KNIGHT)
      return true;
  }

  // king
  for (int dx = -1; dx <= 1; dx++) {
    for (int dy = -1; dy <= 1; dy++) {

      if (dx == 0 && dy == 0)
        continue;

      int x = kx + dx;
      int y = ky + dy;

      if (inside(x,y) &&
          board[y][x] ==
          enemy * KING)
        return true;
    }
  }

  // rook / queen
  if (rayAttack(
    kx,ky,enemy,
    1,0,ROOK))
    return true;

  if (rayAttack(
    kx,ky,enemy,
    -1,0,ROOK))
    return true;

  if (rayAttack(
    kx,ky,enemy,
    0,1,ROOK))
    return true;

  if (rayAttack(
    kx,ky,enemy,
    0,-1,ROOK))
    return true;

  // bishop / queen
  if (rayAttack(
    kx,ky,enemy,
    1,1,BISHOP))
    return true;

  if (rayAttack(
    kx,ky,enemy,
    1,-1,BISHOP))
    return true;

  if (rayAttack(
    kx,ky,enemy,
    -1,1,BISHOP))
    return true;

  if (rayAttack(
    kx,ky,enemy,
    -1,-1,BISHOP))
    return true;

  return false;
}

// ------------------------------------------------------------
// RAY ATTACK
// ------------------------------------------------------------

boolean rayAttack(
  int x,
  int y,
  int enemy,
  int dx,
  int dy,
  int wanted) {

  x += dx;
  y += dy;

  while (inside(x,y)) {

    int p = board[y][x];

    if (p != EMPTY) {

      if (p == enemy * wanted ||
          p == enemy * QUEEN)
        return true;

      return false;
    }

    x += dx;
    y += dy;
  }

  return false;
}

// ------------------------------------------------------------
// EVALUATION
// ------------------------------------------------------------

int evaluate() {

  int score = 0;

  for (int y = 0; y < 8; y++) {

    for (int x = 0; x < 8; x++) {

      int p = board[y][x];

      if (p == EMPTY)
        continue;

      int value = pieceValue(abs(p));

      if (p > 0)
        score += value;
      else
        score -= value;

      // central squares
      if (x >= 2 && x <= 5 &&
          y >= 2 && y <= 5) {

        if (p > 0)
          score += 3;
        else
          score -= 3;
      }
    }
  }

  return score;
}

// score from side perspective
int evaluateFor(int side) {

  return side == RED ?
    evaluate() :
    -evaluate();
}

// ------------------------------------------------------------
// PIECE VALUES
// ------------------------------------------------------------

int pieceValue(int p) {

  if (p == PAWN) return 100;
  if (p == KNIGHT) return 320;
  if (p == BISHOP) return 330;
  if (p == ROOK) return 500;
  if (p == QUEEN) return 900;
  if (p == KING) return 20000;

  return 0;
}

// ------------------------------------------------------------
// CAPTURE SORT
// ------------------------------------------------------------

void sortCaptures(ArrayList<Move> list) {

  for (int i = 0; i < list.size(); i++) {

    int best = i;

    for (int j = i + 1; j < list.size(); j++) {

      int a =
        abs(board[list.get(j).ty][list.get(j).tx]);

      int b =
        abs(board[list.get(best).ty][list.get(best).tx]);

      if (a > b)
        best = j;
    }

    Move temp = list.get(i);

    list.set(
      i,
      list.get(best)
    );

    list.set(
      best,
      temp
    );
  }
}

// ------------------------------------------------------------
// MEMORY
// ------------------------------------------------------------

void saveMemory(
  long key,
  Move m,
  int score) {

  if (memory.size() >= 5000)
    memory.remove(0);

  memory.add(
    new Memory(
      key,
      m,
      score
    )
  );
}

int getMemoryScore(long key) {

  for (int i = memory.size() - 1; i >= 0; i--) {

    if (memory.get(i).key == key)
      return memory.get(i).score;
  }

  return 999999;
}

// ------------------------------------------------------------
// BOARD KEY
// ------------------------------------------------------------

long boardKey() {

  long k = 7;

  for (int y = 0; y < 8; y++) {

    for (int x = 0; x < 8; x++) {

      k = k * 31 + board[y][x];
    }
  }

  k = k * 2 + (turn == RED ? 1 : 0);

  return k;
}

// ------------------------------------------------------------
// COPY MOVES
// ------------------------------------------------------------

ArrayList<Move> copyMoves(
  ArrayList<Move> source) {

  ArrayList<Move> r =
    new ArrayList<Move>();

  for (int i = 0; i < source.size(); i++) {

    Move m = source.get(i);

    r.add(
      new Move(
        m.fx,
        m.fy,
        m.tx,
        m.ty
      )
    );
  }

  return r;
}

// ------------------------------------------------------------
// GAME END
// ------------------------------------------------------------

void checkGameEnd() {

  generateLegalMoves(turn);

  if (legalMoves.size() == 0) {

    gameOver = true;

    if (kingExists(turn)) {

      if (isKingAttacked(turn))
        bestMoveText =
          "CHECKMATE";
      else
        bestMoveText =
          "STALEMATE";
    }
  }
}

// ------------------------------------------------------------
// KING EXISTS
// ------------------------------------------------------------

boolean kingExists(int side) {

  for (int y = 0; y < 8; y++) {

    for (int x = 0; x < 8; x++) {

      if (board[y][x] ==
          side * KING)
        return true;
    }
  }

  return false;
}

// ------------------------------------------------------------
// HELPERS
// ------------------------------------------------------------

boolean inside(int x, int y) {

  return x >= 0 &&
         x < 8 &&
         y >= 0 &&
         y < 8;
}

int sideOf(int p) {

  if (p > 0)
    return RED;

  if (p < 0)
    return BLUE;

  return 0;
}

String pieceChar(int p) {

  if (p == PAWN)   return "V";
  if (p == ROOK)   return "T";
  if (p == KNIGHT) return "O";
  if (p == BISHOP) return "X";
  if (p == KING)   return "W";
  if (p == QUEEN)  return "U";

  return "";
}

String moveText(Move m) {

  return squareName(m.fx,m.fy) +
         "-" +
         squareName(m.tx,m.ty);
}

String squareName(int x, int y) {

  char f = char('A' + x);

  int rank = y + 1;

  return "" + f + rank;
}

// ------------------------------------------------------------
// MOVE CLASS
// ------------------------------------------------------------

class Move {

  int fx;
  int fy;

  int tx;
  int ty;

  Move(
    int a,
    int b,
    int c,
    int d) {

    fx = a;
    fy = b;
    tx = c;
    ty = d;
  }
}

// ------------------------------------------------------------
// MEMORY CLASS
// ------------------------------------------------------------

class Memory {

  long key;

  Move move;

  int score;

  Memory(
    long k,
    Move m,
    int s) {

    key = k;

    move =
      new Move(
        m.fx,
        m.fy,
        m.tx,
        m.ty
      );

    score = s;
  }
}































































*/














































