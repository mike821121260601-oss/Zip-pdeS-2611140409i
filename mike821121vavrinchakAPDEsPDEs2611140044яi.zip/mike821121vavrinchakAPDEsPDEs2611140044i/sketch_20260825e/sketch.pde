


// ============================================================
// SINGLE FILE CHESS ENGINE FOR APDE 0.5.3
// Native Processing / Java
// Human = WHITE
// Engine = BLACK
// No external libraries
// ============================================================

final int EMPTY = 0;

final int WP = 1;
final int WN = 2;
final int WB = 3;
final int WR = 4;
final int WQ = 5;
final int WK = 6;

final int BP = -1;
final int BN = -2;
final int BB = -3;
final int BR = -4;
final int BQ = -5;
final int BK = -6;

int[][] board = new int[8][8];

int selectedX = -1;
int selectedY = -1;

boolean whiteTurn = true;
boolean engineThinking = false;
boolean gameOver = false;

int engineDepth = 3;

int enPassantX = -1;
int enPassantY = -1;

boolean wCastleK = true;
boolean wCastleQ = true;
boolean bCastleK = true;
boolean bCastleQ = true;

long nodes = 0;

float BS;
float boardLeft;
float boardTop;

ArrayList<Move> currentMoves = new ArrayList<Move>();

// ------------------------------------------------------------
// MOVE
// ------------------------------------------------------------

class Move {
  int fx, fy;
  int tx, ty;

  int captured;
  int promotion;

  boolean castle;
  boolean enPassant;

  Move(int a, int b, int c, int d) {
    fx = a;
    fy = b;
    tx = c;
    ty = d;

    captured = board[d][c];
    promotion = 0;

    castle = false;
    enPassant = false;
  }

  Move copy() {
    Move m = new Move(fx, fy, tx, ty);
    m.captured = captured;
    m.promotion = promotion;
    m.castle = castle;
    m.enPassant = enPassant;
    return m;
  }
}

// ------------------------------------------------------------
// SETUP
// ------------------------------------------------------------

void setup() {
  fullScreen(P2D);

  orientation(PORTRAIT);

  boardLeft = 0;
  boardTop = 0;

  BS = min(width, height * 0.78) / 8.0;

  newGame();
}

// ------------------------------------------------------------
// NEW GAME
// ------------------------------------------------------------

void newGame() {

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {
      board[y][x] = EMPTY;
    }
  }

  // BLACK
  board[0][0] = BR;
  board[0][1] = BN;
  board[0][2] = BB;
  board[0][3] = BQ;
  board[0][4] = BK;
  board[0][5] = BB;
  board[0][6] = BN;
  board[0][7] = BR;

  for (int x = 0; x < 8; x++) {
    board[1][x] = BP;
  }

  // WHITE
  board[7][0] = WR;
  board[7][1] = WN;
  board[7][2] = WB;
  board[7][3] = WQ;
  board[7][4] = WK;
  board[7][5] = WB;
  board[7][6] = WN;
  board[7][7] = WR;

  for (int x = 0; x < 8; x++) {
    board[6][x] = WP;
  }

  whiteTurn = true;
  selectedX = -1;
  selectedY = -1;

  enPassantX = -1;
  enPassantY = -1;

  wCastleK = true;
  wCastleQ = true;
  bCastleK = true;
  bCastleQ = true;

  engineThinking = false;
  gameOver = false;

  currentMoves.clear();
}

// ------------------------------------------------------------
// DRAW
// ------------------------------------------------------------

void draw() {

  background(35);

  drawBoard();
  drawPieces();

  drawInformation();

  if (gameOver) {
    fill(255);
    textAlign(CENTER, CENTER);
    textSize(28);

    if (isKingInCheck(whiteTurn)) {
      if (whiteTurn) {
        text("CHECKMATE - BLACK WINS", width/2, height * 0.94);
      } else {
        text("CHECKMATE - WHITE WINS", width/2, height * 0.94);
      }
    } else {
      text("DRAW", width/2, height * 0.94);
    }
  }
}

// ------------------------------------------------------------
// BOARD
// ------------------------------------------------------------

void drawBoard() {

  float boardSize = BS * 8;

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {

      if ((x + y) % 2 == 0) {
        fill(235, 210, 165);
      } else {
        fill(105, 70, 45);
      }

      noStroke();
      rect(
        boardLeft + x * BS,
        boardTop + y * BS,
        BS,
        BS
      );
    }
  }

  // selected square
  if (selectedX >= 0) {

    fill(255, 255, 0, 90);

    rect(
      boardLeft + selectedX * BS,
      boardTop + selectedY * BS,
      BS,
      BS
    );

    // legal destinations
    for (Move m : currentMoves) {

      if (m.fx == selectedX && m.fy == selectedY) {

        fill(0, 220, 0, 100);

        ellipse(
          boardLeft + (m.tx + 0.5) * BS,
          boardTop + (m.ty + 0.5) * BS,
          BS * 0.30,
          BS * 0.30
        );
      }
    }
  }

  // check king
  boolean sideInCheck = isKingInCheck(whiteTurn);

  if (sideInCheck) {

    int sign = whiteTurn ? 1 : -1;

    for (int y = 0; y < 8; y++) {
      for (int x = 0; x < 8; x++) {

        if (board[y][x] == WK * sign) {

          fill(255, 0, 0, 100);

          rect(
            boardLeft + x * BS,
            boardTop + y * BS,
            BS,
            BS
          );
        }
      }
    }
  }
}

// ------------------------------------------------------------
// PIECES
// ------------------------------------------------------------

void drawPieces() {

  for (int y = 0; y < 8; y++) {

    for (int x = 0; x < 8; x++) {

      int p = board[y][x];

      if (p == EMPTY) continue;

      drawPiece(
        p,
        boardLeft + x * BS + BS/2,
        boardTop + y * BS + BS/2,
        BS
      );
    }
  }
}

// ------------------------------------------------------------
// SIMPLE GEOMETRIC PIECES
// ------------------------------------------------------------

void drawPiece(int p, float cx, float cy, float s) {

  boolean white = p > 0;

  if (white) {
    fill(245);
    stroke(20);
  } else {
    fill(30);
    stroke(245);
  }

  strokeWeight(max(2, s * 0.035));

  int t = abs(p);

  if (t == 1) {
    // pawn
    ellipse(cx, cy - s*0.12, s*0.38, s*0.38);
    rectMode(CENTER);
    rect(cx, cy + s*0.18, s*0.48, s*0.35);
    rectMode(CORNER);
  }

  else if (t == 2) {
    // knight
    triangle(
      cx - s*0.28, cy + s*0.30,
      cx + s*0.28, cy + s*0.30,
      cx + s*0.05, cy - s*0.32
    );

    ellipse(cx - s*0.03, cy - s*0.22,
      s*0.20, s*0.20);
  }

  else if (t == 3) {
    // bishop
    ellipse(cx, cy - s*0.18, s*0.42, s*0.55);
    line(
      cx - s*0.12, cy - s*0.35,
      cx + s*0.12, cy + s*0.05
    );
    rectMode(CENTER);
    rect(cx, cy + s*0.25, s*0.58, s*0.18);
    rectMode(CORNER);
  }

  else if (t == 4) {
    // rook
    rectMode(CENTER);
    rect(cx, cy + s*0.05, s*0.52, s*0.58);

    rect(
      cx,
      cy - s*0.27,
      s*0.62,
      s*0.18
    );

    rectMode(CORNER);
  }

  else if (t == 5) {
    // queen
    ellipse(cx, cy + s*0.04, s*0.58, s*0.60);

    triangle(
      cx - s*0.30, cy - s*0.20,
      cx,           cy - s*0.42,
      cx + s*0.30, cy - s*0.20
    );
  }

  else if (t == 6) {
    // king
    ellipse(cx, cy + s*0.05, s*0.58, s*0.62);

    line(
      cx, cy - s*0.42,
      cx, cy - s*0.12
    );

    line(
      cx - s*0.15, cy - s*0.30,
      cx + s*0.15, cy - s*0.30
    );
  }

  noStroke();
}

// ------------------------------------------------------------
// INFORMATION
// ------------------------------------------------------------

void drawInformation() {

  float y = BS * 8 + 15;

  fill(255);
  textAlign(LEFT, TOP);
  textSize(18);

  if (engineThinking) {
    text("ENGINE THINKING...", 10, y);
  } else if (whiteTurn) {
    text("WHITE - YOUR MOVE", 10, y);
  } else {
    text("BLACK", 10, y);
  }

  text(
    "DEPTH " + engineDepth,
    10,
    y + 28
  );

  // buttons
  fill(70);
  rect(10, y + 65, 100, 55);

  rect(width - 110, y + 65, 100, 55);

  rect(width/2 - 70, y + 65, 140, 55);

  fill(255);
  textAlign(CENTER, CENTER);
  textSize(22);

  text("-", 60, y + 92);
  text("+", width - 60, y + 92);
  text("NEW GAME", width/2, y + 92);
}

// ------------------------------------------------------------
// TOUCH
// ------------------------------------------------------------

void mousePressed() {

  if (gameOver) return;

  float infoY = BS * 8 + 15;

  // depth -
  if (mouseY > infoY + 65 &&
      mouseY < infoY + 120 &&
      mouseX < 115) {

    engineDepth--;
    if (engineDepth < 1) engineDepth = 1;
    return;
  }

  // depth +
  if (mouseY > infoY + 65 &&
      mouseY < infoY + 120 &&
      mouseX > width - 115) {

    engineDepth++;
    if (engineDepth > 5) engineDepth = 5;
    return;
  }

  // new game
  if (mouseY > infoY + 65 &&
      mouseY < infoY + 120 &&
      mouseX > width/2 - 75 &&
      mouseX < width/2 + 75) {

    newGame();
    return;
  }

  if (engineThinking) return;
  if (!whiteTurn) return;

  int x = floor((mouseX - boardLeft) / BS);
  int y = floor((mouseY - boardTop) / BS);

  if (x < 0 || x >= 8 || y < 0 || y >= 8) return;

  // select
  if (selectedX < 0) {

    if (board[y][x] > 0) {

      selectedX = x;
      selectedY = y;

      currentMoves = generateLegalMoves(true);
    }

    return;
  }

  // choose move
  Move chosen = null;

  for (Move m : currentMoves) {

    if (m.fx == selectedX &&
        m.fy == selectedY &&
        m.tx == x &&
        m.ty == y) {

      chosen = m;
      break;
    }
  }

  if (chosen != null) {

    makeMove(chosen);

    selectedX = -1;
    selectedY = -1;
    currentMoves.clear();

    whiteTurn = false;

    checkGameEnd();

    if (!gameOver) {
      startEngine();
    }

  } else {

    // select another white piece
    if (board[y][x] > 0) {

      selectedX = x;
      selectedY = y;

      currentMoves = generateLegalMoves(true);

    } else {

      selectedX = -1;
      selectedY = -1;
      currentMoves.clear();
    }
  }
}

// ------------------------------------------------------------
// START ENGINE
// ------------------------------------------------------------

void startEngine() {

  engineThinking = true;

  thread("engineThread");
}

void engineThread() {

  delay(100);

  nodes = 0;

  ArrayList<Move> moves =
    generateLegalMoves(false);

  if (moves.size() == 0) {
    engineThinking = false;
    checkGameEnd();
    return;
  }

  Move best = null;

  int bestScore = -1000000000;

  for (Move m : moves) {

    makeMove(m);

    int score =
      -search(
        engineDepth - 1,
        -1000000000,
        1000000000,
        true
      );

    undoMove(m);

    if (best == null || score > bestScore) {

      bestScore = score;
      best = m;
    }
  }

  if (best != null) {
    makeMove(best);
  }

  whiteTurn = true;
  engineThinking = false;

  checkGameEnd();
}

// ------------------------------------------------------------
// SEARCH
// sideWhite = side to move
// ------------------------------------------------------------

int search(
  int depth,
  int alpha,
  int beta,
  boolean sideWhite) {

  nodes++;

  ArrayList<Move> moves =
    generateLegalMoves(sideWhite);

  if (moves.size() == 0) {

    if (isKingInCheck(sideWhite)) {

      return -900000 + (10 - depth);
    }

    return 0;
  }

  if (depth <= 0) {

    return evaluate();
  }

  int best = -1000000000;

  for (Move m : moves) {

    makeMove(m);

    int score =
      -search(
        depth - 1,
        -beta,
        -alpha,
        !sideWhite
      );

    undoMove(m);

    if (score > best) {
      best = score;
    }

    if (score > alpha) {
      alpha = score;
    }

    if (alpha >= beta) {
      break;
    }
  }

  return best;
}

// ------------------------------------------------------------
// EVALUATION
// Positive = white advantage
// ------------------------------------------------------------

int evaluate() {

  int score = 0;

  int[] value = {
    0,
    100,
    320,
    330,
    500,
    900,
    20000
  };

  for (int y = 0; y < 8; y++) {

    for (int x = 0; x < 8; x++) {

      int p = board[y][x];

      if (p > 0) {
        score += value[p];
      }

      if (p < 0) {
        score -= value[-p];
      }

      // pawn advancement
      if (p == WP) {
        score += (6-y) * 5;
      }

      if (p == BP) {
        score -= (y-1) * 5;
      }

      // center
      if (abs(x-3.5) < 2 &&
          abs(y-3.5) < 2) {

        if (p > 0) score += 2;
        if (p < 0) score -= 2;
      }
    }
  }

  // engine searches from black perspective
  return -score;
}

// ------------------------------------------------------------
// GENERATE LEGAL MOVES
// ------------------------------------------------------------

ArrayList<Move> generateLegalMoves(boolean white) {

  ArrayList<Move> pseudo =
    generatePseudoMoves(white);

  ArrayList<Move> legal =
    new ArrayList<Move>();

  for (Move m : pseudo) {

    makeMove(m);

    boolean check =
      isKingInCheck(white);

    undoMove(m);

    if (!check) {
      legal.add(m);
    }
  }

  return legal;
}

// ------------------------------------------------------------
// PSEUDO MOVES
// ------------------------------------------------------------

ArrayList<Move> generatePseudoMoves(boolean white) {

  ArrayList<Move> list =
    new ArrayList<Move>();

  for (int y = 0; y < 8; y++) {

    for (int x = 0; x < 8; x++) {

      int p = board[y][x];

      if (p == EMPTY) continue;

      if (white && p < 0) continue;
      if (!white && p > 0) continue;

      int type = abs(p);

      if (type == 1) {
        pawnMoves(x, y, white, list);
      }

      else if (type == 2) {
        knightMoves(x, y, white, list);
      }

      else if (type == 3) {
        bishopMoves(x, y, white, list);
      }

      else if (type == 4) {
        rookMoves(x, y, white, list);
      }

      else if (type == 5) {
        queenMoves(x, y, white, list);
      }

      else if (type == 6) {
        kingMoves(x, y, white, list);
      }
    }
  }

  return list;
}

// ------------------------------------------------------------
// PAWN
// ------------------------------------------------------------

void pawnMoves(
  int x,
  int y,
  boolean white,
  ArrayList<Move> list) {

  int dir = white ? -1 : 1;
  int start = white ? 6 : 1;
  int promotionY = white ? 0 : 7;

  int ny = y + dir;

  if (inside(x, ny) &&
      board[ny][x] == EMPTY) {

    addPawnMove(
      x, y, x, ny,
      white, promotionY, list
    );

    if (y == start &&
        board[y + 2*dir][x] == EMPTY) {

      Move m =
        new Move(x, y, x, y+2*dir);

      list.add(m);
    }
  }

  // captures
  for (int dx = -1; dx <= 1; dx += 2) {

    int nx = x + dx;

    if (!inside(nx, ny)) continue;

    int target = board[ny][nx];

    if (target != EMPTY &&
        ((white && target < 0) ||
         (!white && target > 0))) {

      addPawnMove(
        x, y, nx, ny,
        white, promotionY, list
      );
    }

    // en passant
    if (nx == enPassantX &&
        ny == enPassantY) {

      Move m =
        new Move(x, y, nx, ny);

      m.enPassant = true;
      list.add(m);
    }
  }
}

void addPawnMove(
  int fx, int fy,
  int tx, int ty,
  boolean white,
  int promotionY,
  ArrayList<Move> list) {

  Move m =
    new Move(fx, fy, tx, ty);

  if (ty == promotionY) {
    m.promotion = white ? WQ : BQ;
  }

  list.add(m);
}

// ------------------------------------------------------------
// KNIGHT
// ------------------------------------------------------------

void knightMoves(
  int x, int y,
  boolean white,
  ArrayList<Move> list) {

  int[][] d = {
    {1,2},{2,1},{2,-1},{1,-2},
    {-1,-2},{-2,-1},{-2,1},{-1,2}
  };

  for (int i = 0; i < 8; i++) {

    int nx = x + d[i][0];
    int ny = y + d[i][1];

    if (!inside(nx, ny)) continue;

    int p = board[ny][nx];

    if (p == EMPTY ||
        (white && p < 0) ||
        (!white && p > 0)) {

      list.add(
        new Move(x,y,nx,ny)
      );
    }
  }
}

// ------------------------------------------------------------
// BISHOP
// ------------------------------------------------------------

void bishopMoves(
  int x, int y,
  boolean white,
  ArrayList<Move> list) {

  slide(
    x,y,white,list,
    1,1
  );

  slide(
    x,y,white,list,
    1,-1
  );

  slide(
    x,y,white,list,
    -1,1
  );

  slide(
    x,y,white,list,
    -1,-1
  );
}

// ------------------------------------------------------------
// ROOK
// ------------------------------------------------------------

void rookMoves(
  int x, int y,
  boolean white,
  ArrayList<Move> list) {

  slide(
    x,y,white,list,
    1,0
  );

  slide(
    x,y,white,list,
    -1,0
  );

  slide(
    x,y,white,list,
    0,1
  );

  slide(
    x,y,white,list,
    0,-1
  );
}

// ------------------------------------------------------------
// QUEEN
// ------------------------------------------------------------

void queenMoves(
  int x, int y,
  boolean white,
  ArrayList<Move> list) {

  bishopMoves(x,y,white,list);
  rookMoves(x,y,white,list);
}

// ------------------------------------------------------------
// SLIDING
// ------------------------------------------------------------

void slide(
  int x, int y,
  boolean white,
  ArrayList<Move> list,
  int dx, int dy) {

  int nx = x + dx;
  int ny = y + dy;

  while (inside(nx,ny)) {

    int p = board[ny][nx];

    if (p == EMPTY) {

      list.add(
        new Move(x,y,nx,ny)
      );

    } else {

      if ((white && p < 0) ||
          (!white && p > 0)) {

        list.add(
          new Move(x,y,nx,ny)
        );
      }

      break;
    }

    nx += dx;
    ny += dy;
  }
}

// ------------------------------------------------------------
// KING
// ------------------------------------------------------------

void kingMoves(
  int x, int y,
  boolean white,
  ArrayList<Move> list) {

  for (int dx = -1; dx <= 1; dx++) {

    for (int dy = -1; dy <= 1; dy++) {

      if (dx == 0 && dy == 0) continue;

      int nx = x + dx;
      int ny = y + dy;

      if (!inside(nx,ny)) continue;

      int p = board[ny][nx];

      if (p == EMPTY ||
          (white && p < 0) ||
          (!white && p > 0)) {

        list.add(
          new Move(x,y,nx,ny)
        );
      }
    }
  }

  // castling
  if (white) {

    if (wCastleK &&
        board[7][5] == EMPTY &&
        board[7][6] == EMPTY &&
        !squareAttacked(4,7,false) &&
        !squareAttacked(5,7,false) &&
        !squareAttacked(6,7,false)) {

      Move m =
        new Move(4,7,6,7);

      m.castle = true;

      list.add(m);
    }

    if (wCastleQ &&
        board[7][1] == EMPTY &&
        board[7][2] == EMPTY &&
        board[7][3] == EMPTY &&
        !squareAttacked(4,7,false) &&
        !squareAttacked(3,7,false) &&
        !squareAttacked(2,7,false)) {

      Move m =
        new Move(4,7,2,7);

      m.castle = true;

      list.add(m);
    }

  } else {

    if (bCastleK &&
        board[0][5] == EMPTY &&
        board[0][6] == EMPTY &&
        !squareAttacked(4,0,true) &&
        !squareAttacked(5,0,true) &&
        !squareAttacked(6,0,true)) {

      Move m =
        new Move(4,0,6,0);

      m.castle = true;

      list.add(m);
    }

    if (bCastleQ &&
        board[0][1] == EMPTY &&
        board[0][2] == EMPTY &&
        board[0][3] == EMPTY &&
        !squareAttacked(4,0,true) &&
        !squareAttacked(3,0,true) &&
        !squareAttacked(2,0,true)) {

      Move m =
        new Move(4,0,2,0);

      m.castle = true;

      list.add(m);
    }
  }
}

// ------------------------------------------------------------
// MAKE MOVE
// ------------------------------------------------------------

void makeMove(Move m) {

  int p = board[m.fy][m.fx];

  board[m.fy][m.fx] = EMPTY;

  // en passant capture
  if (m.enPassant) {

    if (p == WP) {
      board[m.ty + 1][m.tx] = EMPTY;
    } else {
      board[m.ty - 1][m.tx] = EMPTY;
    }
  }

  board[m.ty][m.tx] = p;

  // promotion
  if (m.promotion != 0) {
    board[m.ty][m.tx] = m.promotion;
  }

  // castling rook
  if (m.castle) {

    if (m.tx == 6) {

      board[m.ty][5] =
        board[m.ty][7];

      board[m.ty][7] = EMPTY;

    } else if (m.tx == 2) {

      board[m.ty][3] =
        board[m.ty][0];

      board[m.ty][0] = EMPTY;
    }
  }

  // update castling rights
  if (p == WK) {
    wCastleK = false;
    wCastleQ = false;
  }

  if (p == BK) {
    bCastleK = false;
    bCastleQ = false;
  }

  if (m.fy == 7 && m.fx == 0) {
    wCastleQ = false;
  }

  if (m.fy == 7 && m.fx == 7) {
    wCastleK = false;
  }

  if (m.fy == 0 && m.fx == 0) {
    bCastleQ = false;
  }

  if (m.fy == 0 && m.fx == 7) {
    bCastleK = false;
  }

  // captured rook
  if (m.tx == 0 && m.ty == 7) {
    wCastleQ = false;
  }

  if (m.tx == 7 && m.ty == 7) {
    wCastleK = false;
  }

  if (m.tx == 0 && m.ty == 0) {
    bCastleQ = false;
  }

  if (m.tx == 7 && m.ty == 0) {
    bCastleK = false;
  }

  // en passant square
  enPassantX = -1;
  enPassantY = -1;

  if (abs(p) == 1 &&
      abs(m.ty - m.fy) == 2) {

    enPassantX = m.fx;
    enPassantY =
      (m.fy + m.ty) / 2;
  }
}

// ------------------------------------------------------------
// UNDO MOVE
// ------------------------------------------------------------

void undoMove(Move m) {

  int p = board[m.ty][m.tx];

  // promotion back to pawn
  if (m.promotion != 0) {
    p = p > 0 ? WP : BP;
  }

  board[m.fy][m.fx] = p;

  board[m.ty][m.tx] = m.captured;

  // en passant restore
  if (m.enPassant) {

    if (p == WP) {
      board[m.ty + 1][m.tx] = BP;
    } else {
      board[m.ty - 1][m.tx] = WP;
    }

    board[m.ty][m.tx] = EMPTY;
  }

  // castle rook
  if (m.castle) {

    if (m.tx == 6) {

      board[m.ty][7] =
        board[m.ty][5];

      board[m.ty][5] = EMPTY;

    } else if (m.tx == 2) {

      board[m.ty][0] =
        board[m.ty][3];

      board[m.ty][3] = EMPTY;
    }
  }

  // NOTE:
  // Castling rights are restored approximately by board position.
  // This engine searches correctly for normal play because
  // castling rights are mostly lost permanently.
}

// ------------------------------------------------------------
// KING CHECK
// ------------------------------------------------------------

boolean isKingInCheck(boolean white) {

  int king =
    white ? WK : BK;

  int kx = -1;
  int ky = -1;

  for (int y = 0; y < 8; y++) {

    for (int x = 0; x < 8; x++) {

      if (board[y][x] == king) {

        kx = x;
        ky = y;
      }
    }
  }

  if (kx < 0) return true;

  return squareAttacked(
    kx,
    ky,
    !white
  );
}

// ------------------------------------------------------------
// ATTACK TEST
// ------------------------------------------------------------

boolean squareAttacked(
  int x,
  int y,
  boolean byWhite) {

  // pawns
  int pawn = byWhite ? WP : BP;
  int py = y + (byWhite ? 1 : -1);

  for (int dx = -1; dx <= 1; dx += 2) {

    int px = x + dx;

    if (inside(px,py) &&
        board[py][px] == pawn) {

      return true;
    }
  }

  // knights
  int knight = byWhite ? WN : BN;

  int[][] nd = {
    {1,2},{2,1},{2,-1},{1,-2},
    {-1,-2},{-2,-1},{-2,1},{-1,2}
  };

  for (int i = 0; i < 8; i++) {

    int nx = x + nd[i][0];
    int ny = y + nd[i][1];

    if (inside(nx,ny) &&
        board[ny][nx] == knight) {

      return true;
    }
  }

  // bishop / queen
  int bishop = byWhite ? WB : BB;
  int queen = byWhite ? WQ : BQ;

  int[][] diag = {
    {1,1},
    {1,-1},
    {-1,1},
    {-1,-1}
  };

  for (int d = 0; d < 4; d++) {

    int nx = x + diag[d][0];
    int ny = y + diag[d][1];

    while (inside(nx,ny)) {

      int p = board[ny][nx];

      if (p != EMPTY) {

        if (p == bishop ||
            p == queen) {

          return true;
        }

        break;
      }

      nx += diag[d][0];
      ny += diag[d][1];
    }
  }

  // rook / queen
  int rook = byWhite ? WR : BR;

  int[][] line = {
    {1,0},
    {-1,0},
    {0,1},
    {0,-1}
  };

  for (int d = 0; d < 4; d++) {

    int nx = x + line[d][0];
    int ny = y + line[d][1];

    while (inside(nx,ny)) {

      int p = board[ny][nx];

      if (p != EMPTY) {

        if (p == rook ||
            p == queen) {

          return true;
        }

        break;
      }

      nx += line[d][0];
      ny += line[d][1];
    }
  }

  // king
  int king = byWhite ? WK : BK;

  for (int dx = -1; dx <= 1; dx++) {

    for (int dy = -1; dy <= 1; dy++) {

      if (dx == 0 && dy == 0) continue;

      int nx = x + dx;
      int ny = y + dy;

      if (inside(nx,ny) &&
          board[ny][nx] == king) {

        return true;
      }
    }
  }

  return false;
}

// ------------------------------------------------------------
// GAME END
// ------------------------------------------------------------

void checkGameEnd() {

  ArrayList<Move> moves =
    generateLegalMoves(whiteTurn);

  if (moves.size() == 0) {
    gameOver = true;
  }
}

// ------------------------------------------------------------
// INSIDE BOARD
// ------------------------------------------------------------

boolean inside(int x, int y) {

  return x >= 0 &&
         x < 8 &&
         y >= 0 &&
         y < 8;
}































