

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.MediaRecorder;
import android.media.projection.MediaProjectionManager;
import android.media.projection.MediaProjection;
import android.os.Environment;
import android.os.Handler;
import android.view.Surface;
import android.widget.Toast;

import java.io.File;

Activity activity;

MediaProjectionManager projectionManager;
MediaProjection mediaProjection;
MediaRecorder recorder;

int REQUEST_SCREEN_CAPTURE = 5001;

Handler handler = new Handler();

long WAIT_TIME = 60L * 1000L;       // 1 minute
long RECORD_TIME = 175L * 1000L;   // 2 minutes 55 seconds

boolean recording = false;

void setup() {
  fullScreen();

  activity = this.getActivity();

  background(0);
  fill(255);
  textAlign(CENTER, CENTER);
  textSize(28);
  text("SCREEN RECORDER", width/2, height/2 - 60);
  text("Recording starts after 1 minute", width/2, height/2);

  projectionManager =
    (MediaProjectionManager) activity.getSystemService(
    Context.MEDIA_PROJECTION_SERVICE);

  // Ask Android for screen recording permission.
  Intent captureIntent = projectionManager.createScreenCaptureIntent();

  activity.startActivityForResult(
    captureIntent,
    REQUEST_SCREEN_CAPTURE
  );
}


void draw() {
  // Nothing needed here.
}


// --------------------------------------------------
// ANDROID SCREEN CAPTURE PERMISSION RESULT
// --------------------------------------------------

@Override
public void onActivityResult(
  int requestCode,
  int resultCode,
  Intent data) {

  super.onActivityResult(requestCode, resultCode, data);

  if (requestCode == REQUEST_SCREEN_CAPTURE) {

    if (resultCode == Activity.RESULT_OK) {

      mediaProjection =
        projectionManager.getMediaProjection(
        resultCode,
        data
        );

      Toast.makeText(
        activity,
        "Permission OK\nRecording starts in 1 minute",
        Toast.LENGTH_LONG
        ).show();

      // WAIT 1 MINUTE
      handler.postDelayed(
        new Runnable() {
          public void run() {
            startRecording();
          }
        },
        WAIT_TIME
        );

    } else {

      Toast.makeText(
        activity,
        "Screen recording permission denied",
        Toast.LENGTH_LONG
        ).show();
    }
  }
}


// --------------------------------------------------
// START RECORDING
// --------------------------------------------------

void startRecording() {

  if (recording) return;

  try {

    int w = displayWidth;
    int h = displayHeight;

    // Make dimensions even for H.264.
    w = w / 2 * 2;
    h = h / 2 * 2;

    recorder = new MediaRecorder();

    recorder.setVideoSource(
      MediaRecorder.VideoSource.SURFACE
      );

    recorder.setOutputFormat(
      MediaRecorder.OutputFormat.MPEG_4
      );

    recorder.setVideoEncoder(
      MediaRecorder.VideoEncoder.H264
      );

    recorder.setVideoEncodingBitRate(
      6 * 1000 * 1000
      );

    recorder.setVideoFrameRate(30);

    recorder.setVideoSize(w, h);

    // --------------------------------------------
    // FILE
    // --------------------------------------------

    File movies =
      activity.getExternalFilesDir(
      Environment.DIRECTORY_MOVIES
      );

    if (!movies.exists()) {
      movies.mkdirs();
    }

    String filename =
      "SCREEN_RECORDING_" +
      System.currentTimeMillis() +
      ".mp4";

    File output =
      new File(movies, filename);

    recorder.setOutputFile(
      output.getAbsolutePath()
      );

    recorder.prepare();

    Surface surface =
      recorder.getSurface();

    // --------------------------------------------
    // MEDIA PROJECTION
    // --------------------------------------------

    mediaProjection.createVirtualDisplay(
      "APDE_SCREEN_RECORDER",
      w+w-w,
      h+h-h,



   //   getResources().getDisplayMetrics().densityDpi,
    //    null, 
 //   getResources().getDisplayMetrics().densityDpi,
      30 +30-55,


      0,
      surface,
      null,
      null
  





    );

    recorder.start();

    recording = true;

    Toast.makeText(
      activity,
      "RECORDING STARTED\n2 minutes 55 seconds",
      Toast.LENGTH_LONG
      ).show();

    // --------------------------------------------
    // STOP AFTER 2:55
    // --------------------------------------------

    handler.postDelayed(
      new Runnable() {
        public void run() {
          stopRecording();
        }
      },
      RECORD_TIME
      );

  }

  catch (Exception e) {

    recording = false;

    Toast.makeText(
      activity,
      "Recording error: " + e.toString(),
      Toast.LENGTH_LONG
      ).show();
  }
}


// --------------------------------------------------
// STOP RECORDING
// --------------------------------------------------

void stopRecording() {

  if (!recording) return;

  recording = false;

  try {

    if (recorder != null) {

      recorder.stop();
      recorder.reset();
      recorder.release();
      recorder = null;
    }

    if (mediaProjection != null) {

      mediaProjection.stop();
      mediaProjection = null;
    }

    Toast.makeText(
      activity,
      "RECORDING FINISHED\nMP4 saved",
      Toast.LENGTH_LONG
      ).show();

  }

  catch (Exception e) {

    Toast.makeText(
      activity,
      "Stop error: " + e.toString(),
      Toast.LENGTH_LONG
      ).show();
  }
}


























