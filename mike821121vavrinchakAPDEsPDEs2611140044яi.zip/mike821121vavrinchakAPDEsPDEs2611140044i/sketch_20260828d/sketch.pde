


/*
Here is a **Processing / PDE translation** of your idea, turned into a simple chess-board prototype with:

- 8×8 board
- legal move list
- autoplay best move
- move memory for 8 moves
- capture tracking
- side switching
- no knight moves
- no castling
- no diagonal moves for rook-like “castle” movement

```java

*/
// Processing (PDE) chess prototype
// Simplified engine based on your idea

String[][] board = new String[8][8];
boolean whiteTurn = true;

int selectedRow = -1;
int selectedCol = -1;

ArrayList<Move> legalMoves = new ArrayList<Move>();
ArrayList<Move> moveMemory = new ArrayList<Move>();  // last 8 moves
Move lastMove = null;

PFont font;

void setup() {
  size(900, 900);
  font = createFont("Arial", 24);
  textFont(font);
  initBoard();
}

void draw() {
  background(245);

  drawBoard();
  drawInfoPanel();
}

void mousePressed() {
  int cellSize = 80;
  int offsetX = 40;
  int offsetY = 40;

  int col = (mouseX - offsetX) / cellSize;
  int row = (mouseY - offsetY) / cellSize;

  if (row < 0 || row > 7 || col < 0 || col > 7) return;

  if (selectedRow == -1) {
    if (isMyPiece(board[row][col])) {
      selectedRow = row;
      selectedCol = col;
      legalMoves = getLegalMovesForPiece(row, col);
    }
  } else {
    Move chosen = findMove(row, col);
    if (chosen != null) {
      doMove(chosen);
    }
    selectedRow = -1;
    selectedCol = -1;
    legalMoves.clear();
  }
}

void keyPressed() {
  if (key == 'a' || key == 'A') {
    autoplayBestMove();
  }
  if (key == 'r' || key == 'R') {
    initBoard();
    whiteTurn = true;
    selectedRow = -1;
    selectedCol = -1;
    legalMoves.clear();
    moveMemory.clear();
    lastMove = null;
  }
}

void initBoard() {
  for (int r = 0; r < 8; r++) {
    for (int c = 0; c < 8; c++) {
      board[r][c] = "";
    }
  }

  // Black side
  board[0][0] = "r";
  board[0][2] = "b";
  board[0][3] = "q";
  board[0][4] = "k";
  board[0][5] = "b";
  board[0][7] = "r";
  for (int c = 0; c < 8; c++) board[1][c] = "p";

  // White side
  for (int c = 0; c < 8; c++) board[6][c] = "P";
  board[7][0] = "R";
  board[7][2] = "B";
  board[7][3] = "Q";
  board[7][4] = "K";
  board[7][5] = "B";
  board[7][7] = "R";
}

void drawBoard() {
  int cellSize = 80;
  int offsetX = 40;
  int offsetY = 40;

  for (int r = 0; r < 8; r++) {
    for (int c = 0; c < 8; c++) {
      boolean light = ((r + c) % 2 == 0);

      if (light) fill(240, 220, 190);
      else fill(120, 90, 60);

      stroke(40);
      rect(offsetX + c * cellSize, offsetY + r * cellSize, cellSize, cellSize);

      // selected square
      if (r == selectedRow && c == selectedCol) {
        fill(255, 120, 0, 120);
        noStroke();
        rect(offsetX + c * cellSize, offsetY + r * cellSize, cellSize, cellSize);
      }

      // legal move mark
      for (Move m : legalMoves) {
        if (m.toRow == r && m.toCol == c) {
          if (m.capturedPiece.equals("")) {
            fill(0, 150, 150, 160);
            ellipse(offsetX + c * cellSize + cellSize/2, offsetY + r * cellSize + cellSize/2, 18, 18);
          } else {
            noFill();
            stroke(180, 0, 0);
            strokeWeight(3);
            ellipse(offsetX + c * cellSize + cellSize/2, offsetY + r * cellSize + cellSize/2, 36, 36);
            strokeWeight(1);
          }
        }
      }

      // last move mark
      if (lastMove != null) {
        if (lastMove.fromRow == r && lastMove.fromCol == c) {
          fill(255, 100, 0, 70);
          noStroke();
          rect(offsetX + c * cellSize, offsetY + r * cellSize, cellSize, cellSize);
        }
        if (lastMove.toRow == r && lastMove.toCol == c) {
          fill(0, 180, 0, 70);
          noStroke();
          rect(offsetX + c * cellSize, offsetY + r * cellSize, cellSize, cellSize);
        }
      }

      // piece text
      if (!board[r][c].equals("")) {
        fill(isWhitePiece(board[r][c]) ? 255 : 20);
        textAlign(CENTER, CENTER);
        textSize(34);
        text(pieceSymbol(board[r][c]), offsetX + c * cellSize + cellSize/2, offsetY + r * cellSize + cellSize/2);
      }
    }
  }

  // file labels
  fill(0);
  textSize(18);
  for (int c = 0; c < 8; c++) {
    text("" + (char)('a' + c), offsetX + c * cellSize + cellSize/2, 700);
  }

  // rank labels
  for (int r = 0; r < 8; r++) {
    text("" + (8 - r), 20, offsetY + r * cellSize + cellSize/2);
  }
}

void drawInfoPanel() {
  fill(20);
  textAlign(LEFT, TOP);
  textSize(18);

  String sideText = whiteTurn ? "White" : "Black";
  text("Turn: " + sideText, 700, 60);
  text("A = autoplay best move", 700, 90);
  text("R = reset", 700, 120);

  text("Last 8 moves:", 700, 170);

  int y = 200;
  for (int i = 0; i < moveMemory.size(); i++) {
    Move m = moveMemory.get(i);
    text((i + 1) + ". " + m.piece + " " + squareName(m.fromRow, m.fromCol) + " -> " + squareName(m.toRow, m.toCol) +
      " take:" + (m.capturedPiece.equals("") ? "no" : m.capturedPiece), 700, y);
    y += 28;
  }

  if (lastMove != null) {
    text("Best/Last move:", 700, 470);
    text(lastMove.piece + " " + squareName(lastMove.fromRow, lastMove.fromCol) + " -> " +
      squareName(lastMove.toRow, lastMove.toCol), 700, 500);
  }
}

// ===== Move logic =====

boolean isWhitePiece(String p) {
  if (p.equals("")) return false;
  return p.equals(p.toUpperCase());
}

boolean isMyPiece(String p) {
  if (p.equals("")) return false;
  if (whiteTurn) return isWhitePiece(p);
  return !isWhitePiece(p);
}

String pieceSymbol(String p) {
  if (p.equals("K")) return "♔";
  if (p.equals("Q")) return "♕";
  if (p.equals("R")) return "♖";
  if (p.equals("B")) return "♗";
  if (p.equals("P")) return "♙";
  if (p.equals("k")) return "♚";
  if (p.equals("q")) return "♛";
  if (p.equals("r")) return "♜";
  if (p.equals("b")) return "♝";
  if (p.equals("p")) return "♟";
  return p;
}

ArrayList<Move> getLegalMovesForPiece(int row, int col) {
  ArrayList<Move> moves = new ArrayList<Move>();
  String p = board[row][col];
  if (p.equals("")) return moves;

  if (p.equals("R") || p.equals("r")) {
    addRookMoves(moves, row, col, p);
  } else if (p.equals("Q") || p.equals("q")) {
    addRookMoves(moves, row, col, p);   // no diagonal in your idea
  } else if (p.equals("B") || p.equals("b")) {
    // placeholder only, no diagonal moves in this version
  } else if (p.equals("K") || p.equals("k")) {
    addKingMoves(moves, row, col, p);
  } else if (p.equals("P")) {
    addPawnMoves(moves, row, col, -1, true);
  } else if (p.equals("p")) {
    addPawnMoves(moves, row, col, 1, false);
  }

  return moves;
}

void addRookMoves(ArrayList<Move> moves, int row, int col, String p) {
  int[] dr = {-1, 1, 0, 0};
  int[] dc = {0, 0, -1, 1};

  for (int dir = 0; dir < 4; dir++) {
    int r = row + dr[dir];
    int c = col + dc[dir];

    while (r >= 0 && r < 8 && c >= 0 && c < 8) {
      if (board[r][c].equals("")) {
        moves.add(new Move(p, row, col, r, c, ""));
      } else {
        if (isEnemyPiece(board[r][c], p)) {
          moves.add(new Move(p, row, col, r, c, board[r][c]));
        }
        break;
      }
      r += dr[dir];
      c += dc[dir];
    }
  }
}

void addKingMoves(ArrayList<Move> moves, int row, int col, String p) {
  for (int dr = -1; dr <= 1; dr++) {
    for (int dc = -1; dc <= 1; dc++) {
      if (dr == 0 && dc == 0) continue;
      int r = row + dr;
      int c = col + dc;
      if (r >= 0 && r < 8 && c >= 0 && c < 8) {
        if (board[r][c].equals("") || isEnemyPiece(board[r][c], p)) {
          moves.add(new Move(p, row, col, r, c, board[r][c]));
        }
      }
    }
  }
}

void addPawnMoves(ArrayList<Move> moves, int row, int col, int dir, boolean whitePawn) {
  int one = row + dir;
  if (one >= 0 && one < 8) {
    if (board[one][col].equals("")) {
      moves.add(new Move(board[row][col], row, col, one, col, ""));

      int startRow = whitePawn ? 6 : 1;
      int two = row + dir * 2;
      if (row == startRow && two >= 0 && two < 8 && board[two][col].equals("")) {
        moves.add(new Move(board[row][col], row, col, two, col, ""));
      }
    }

    // capture diagonally allowed for pawns
    if (col - 1 >= 0 && !board[one][col - 1].equals("") && isEnemyPiece(board[one][col - 1], board[row][col])) {
      moves.add(new Move(board[row][col], row, col, one, col - 1, board[one][col - 1]));
    }
    if (col + 1 < 8 && !board[one][col + 1].equals("") && isEnemyPiece(board[one][col + 1], board[row][col])) {
      moves.add(new Move(board[row][col], row, col, one, col + 1, board[one][col + 1]));
    }
  }
}

boolean isEnemyPiece(String target, String mine) {
  if (target.equals("")) return false;
  return isWhitePiece(target) != isWhitePiece(mine);
}

Move findMove(int row, int col) {
  for (Move m : legalMoves) {
    if (m.toRow == row && m.toCol == col) return m;
  }
  return null;
}

void doMove(Move m) {
  board[m.toRow][m.toCol] = board[m.fromRow][m.fromCol];
  board[m.fromRow][m.fromCol] = "";

  if (board[m.toRow][m.toCol].equals("P") && m.toRow == 0) board[m.toRow][m.toCol] = "Q";
  if (board[m.toRow][m.toCol].equals("p") && m.toRow == 7) board[m.toRow][m.toCol] = "q";

  lastMove = m;

  moveMemory.add(0, m);
  while (moveMemory.size() > 8) moveMemory.remove(moveMemory.size() - 1);

  whiteTurn = !whiteTurn;
}

void autoplayBestMove() {
  ArrayList<Move> all = getAllLegalMoves();
  if (all.size() == 0) return;

  Move best = null;
  int bestScore = whiteTurn ? -999999 : 999999;

  for (Move m : all) {
    int score = evaluateAfterMove(m);
    if (whiteTurn) {
      if (score > bestScore) {
        bestScore = score;
        best = m;
      }
    } else {
      if (score < bestScore) {
        bestScore = score;
        best = m;
      }
    }
  }

  if (best != null) {
    doMove(best);
  }
}

ArrayList<Move> getAllLegalMoves() {
  ArrayList<Move> all = new ArrayList<Move>();
  for (int r = 0; r < 8; r++) {
    for (int c = 0; c < 8; c++) {
      if (isMyPiece(board[r][c])) {
        all.addAll(getLegalMovesForPiece(r, c));
      }
    }
  }
  return all;
}

int evaluateAfterMove(Move m) {
  String[][] copy = copyBoard();
  copy[m.toRow][m.toCol] = copy[m.fromRow][m.fromCol];
  copy[m.fromRow][m.fromCol] = "";

  int score = 0;
  for (int r = 0; r < 8; r++) {
    for (int c = 0; c < 8; c++) {
      String p = copy[r][c];
      if (p.equals("")) continue;
      int val = pieceValue(p);
      if (isWhitePiece(p)) score += val;
      else score -= val;
    }
  }
  return score;
}

String[][] copyBoard() {
  String[][] copy = new String[8][8];
  for (int r = 0; r < 8; r++) {
    for (int c = 0; c < 8; c++) {
      copy[r][c] = board[r][c];
    }
  }
  return copy;
}

int pieceValue(String p) {
  p = p.toLowerCase();
  if (p.equals("k")) return 10000;
  if (p.equals("q")) return 900;
  if (p.equals("r")) return 500;
  if (p.equals("b")) return 330;
  if (p.equals("p")) return 100;
  return 0;
}

String squareName(int row, int col) {
  return "" + (char)('a' + col) + (8 - row);
}

// ===== Move class =====
class Move {
  String piece;
  int fromRow, fromCol, toRow, toCol;
  String capturedPiece;

  Move(String piece, int fromRow, int fromCol, int toRow, int toCol, String capturedPiece) {
    this.piece = piece;
    this.fromRow = fromRow;
    this.fromCol = fromCol;
    this.toRow = toRow;
    this.toCol = toCol;
    this.capturedPiece = capturedPiece;
  }
}



/*



```

## Notes
This translation keeps your idea but makes it clearer and valid in **PDE**:

- **board code**
- **legal moves list**
- **8-move memory**
- **take marks**
- **best move autoplay**
- **switch white/black after move**
- **no knight**
- **no castling**
- **rook-style movement for R and Q only**

If you want, I can now make a **version 2** with:

- **true 8-depth search**
- **mate-in-3 check**
- **better “++==” best-move marking**
- **separate first side / second side score comparison**
- **full move tree memory**





*/






























