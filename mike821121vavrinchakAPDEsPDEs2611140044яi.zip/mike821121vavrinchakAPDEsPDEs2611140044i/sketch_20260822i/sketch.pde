


// Version 1 – Classic 8-ball style (touch drag to shoot)
int BALL_COUNT = 16;
float BALL_R = 13;
float TABLE_MARGIN = 50;
float POCKET_R = 24;

Ball[] balls = new Ball[BALL_COUNT];
PVector[] pockets = new PVector[6];
boolean aiming = false;
PVector aimStart, aimEnd;
boolean moving = false;

void setup() {
  size(displayWidth, displayHeight);




 //////// orientation(LANDSCAPE);





  frameRate(60);
  float w = width, h = height;
  pockets[0] = new PVector(TABLE_MARGIN, TABLE_MARGIN);
  pockets[1] = new PVector(w/2, TABLE_MARGIN);
  pockets[2] = new PVector(w-TABLE_MARGIN, TABLE_MARGIN);
  pockets[3] = new PVector(TABLE_MARGIN, h-TABLE_MARGIN);
  pockets[4] = new PVector(w/2, h-TABLE_MARGIN);
  pockets[5] = new PVector(w-TABLE_MARGIN, h-TABLE_MARGIN);
  reset();
}

void reset() {
  balls[0] = new Ball(width*0.22, height/2, color(255), true);
  float sx = width*0.68, sy = height/2, d = BALL_R*2.08;
  int id = 1;
  for (int r=0; r<5; r++) {
    for (int c=0; c<=r; c++) {
      if (id >= BALL_COUNT) break;
      float x = sx + r*d*0.866;
      float y = sy - r*d/2 + c*d;
      balls[id++] = new Ball(x, y, color(random(60,255), random(30,180), random(30,160)), false);
    }
  }
  moving = false;
}

void draw() {
  background(15, 50, 25);
  fill(25, 120, 45); noStroke();
  rect(TABLE_MARGIN, TABLE_MARGIN, width-2*TABLE_MARGIN, height-2*TABLE_MARGIN, 10);
  stroke(90, 45, 15); strokeWeight(10); noFill();
  rect(TABLE_MARGIN, TABLE_MARGIN, width-2*TABLE_MARGIN, height-2*TABLE_MARGIN, 10);
  
  fill(0); noStroke();
  for (PVector p : pockets) ellipse(p.x, p.y, POCKET_R*2, POCKET_R*2);
  
  moving = false;
  for (Ball b : balls) if (b != null && !b.dead) { b.move(); if (b.v.mag()>0.2) moving=true; }
  
  for (int i=0; i<BALL_COUNT; i++) {
    if (balls[i]==null || balls[i].dead) continue;
    for (int j=i+1; j<BALL_COUNT; j++) {
      if (balls[j]==null || balls[j].dead) continue;
      balls[i].hit(balls[j]);
    }
  }
  
  for (Ball b : balls) if (b != null && !b.dead) b.show();
  
  if (aiming && !moving) {
    stroke(255, 220); strokeWeight(3);
    line(aimStart.x, aimStart.y, aimEnd.x, aimEnd.y);
    float pwr = constrain(PVector.dist(aimStart, aimEnd)/10, 0, 20);
    fill(255, 160, 0); noStroke();
    rect(30, 25, pwr*12, 14, 4);
  }
  
  fill(255); textSize(20);
  text(moving ? "Balls moving..." : "Drag from white ball to shoot", 30, height-25);
}

void mousePressed() {
  if (moving) return;
  Ball c = balls[0];
  if (c!=null && !c.dead && dist(mouseX,mouseY,c.p.x,c.p.y) < BALL_R*3.5) {
    aiming = true;
    aimStart = c.p.copy();
    aimEnd = new PVector(mouseX, mouseY);
  }
}
void mouseDragged() { if (aiming) aimEnd.set(mouseX, mouseY); }
void mouseReleased() {
  if (aiming && !moving) {
    Ball c = balls[0];
    if (c!=null && !c.dead) {
      PVector d = PVector.sub(aimStart, aimEnd);
      float pwr = constrain(d.mag()/11, 0, 17);
      d.normalize().mult(pwr);
      c.v.add(d);
    }
  }
  aiming = false;
}
void keyPressed() { if (key=='r'||key=='R') reset(); }

class Ball {
  PVector p, v;
  color col;
  boolean cue, dead;
  Ball(float x, float y, color c, boolean isCue) {
    p = new PVector(x,y); v = new PVector(); col=c; cue=isCue; dead=false;
  }
  void move() {
    if (dead) return;
    p.add(v); v.mult(0.987);
    float L=TABLE_MARGIN+BALL_R, R=width-TABLE_MARGIN-BALL_R;
    float T=TABLE_MARGIN+BALL_R, B=height-TABLE_MARGIN-BALL_R;
    if (p.x<L){p.x=L;v.x*=-0.92;} if (p.x>R){p.x=R;v.x*=-0.92;}
    if (p.y<T){p.y=T;v.y*=-0.92;} if (p.y>B){p.y=B;v.y*=-0.92;}
    for (PVector pk : pockets)
      if (dist(p.x,p.y,pk.x,pk.y) < POCKET_R-3) { dead=true; v.set(0,0); }
  }
  void hit(Ball o) {
    float d = dist(p.x,p.y,o.p.x,o.p.y);
    if (d < BALL_R*2 && d>0.01) {
      PVector n = PVector.sub(o.p, p).normalize();
      float ov = BALL_R*2 - d;
      p.sub(PVector.mult(n, ov*0.5)); o.p.add(PVector.mult(n, ov*0.5));
      float imp = v.dot(n) - o.v.dot(n);
      v.sub(PVector.mult(n, imp)); o.v.add(PVector.mult(n, imp));
      v.mult(0.97); o.v.mult(0.97);
    }
  }
  void show() {
    noStroke(); fill(col); ellipse(p.x,p.y,BALL_R*2,BALL_R*2);
    if (cue) { fill(0); ellipse(p.x,p.y,5,5); }
  }
}


























