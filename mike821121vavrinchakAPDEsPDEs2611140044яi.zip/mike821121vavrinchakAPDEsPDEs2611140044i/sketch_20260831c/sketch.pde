







// ============================================================
// CircleGoalGame.pde
// APDE / Processing (0.5.3+) sketch
//
// Billiard-style checkers/football hybrid on a 5x5-marked field.
// 4 white "neutral" balls (one of them is THE ball), 26 red,
// 26 blue. Players/engines shoot their own-colour balls by
// dragging (slingshot style) to push the white game-ball into
// the opponent's goal mouth.
//
// NOTE ON THE SPEC FORMULA:
// The requested ball radius = (width+height) * (1/26) is too
// large to fit 56 non-overlapping circles on one field, so it
// is scaled down further below (ballRadius) while keeping the
// same proportion. Change BALL_RADIUS_DIVISOR to taste.
//
// Touch-only: no keyboard needed. Menu is tap buttons; shooting
// is drag-and-release on your own colour's balls.
// ============================================================

int TYPE_WHITE = 0;
int TYPE_RED   = 1;
int TYPE_BLUE  = 2;

int MODE_MAN_MAN        = 1;
int MODE_ENGINE_ENGINE  = 2;
int MODE_MAN_ENGINE     = 3;

int gameMode = 0;
boolean started = false;

float fx0, fy0, fx1, fy1;    
  // field rect: 10%-90% of width/height///
float ballRadius;
float goalDepth, goalHalf, goalCenterY;

float BALL_RADIUS_DIVISOR = 26.0 * 8.0; 
// see note above/////

ArrayList<Ball> balls;
Ball gameBall;

int currentTurn = 1; // starts on RED

Ball selectedBall = null;
PVector dragStart, dragCurrent;
boolean dragging = false;

int scoreRed = 0;
int scoreBlue = 0;

float FRICTION = 0.9;
float STOP_THRESHOLD = 0.03;
float WHITE_ZERO_THRESHOLD = 0.01;
float MAX_SPEED = 18;
float MAX_DRAG = 160;

int aiCooldown = 0;

// ---------- Ball ----------

class Ball {
  PVector pos, vel;
  float r;
  int type;
  boolean isGame;
  Ball(float x, float y, float r_, int t) {
    pos = new PVector(x, y);
    vel = new PVector(0, 0);
    r = r_;
    type = t;
    isGame = false;
  }
}

// ---------- Setup ----------

void setup() {
  fullScreen();
  frameRate(60);
  computeField();
  textAlign(CENTER, CENTER);
}

void computeField() {
  fx0 = width * 0.10;
  fx1 = width * 0.90;
  fy0 = height * 0.10;
  fy1 = height * 0.90;

  ballRadius = (width + height) / BALL_RADIUS_DIVISOR;

  goalDepth   = (fx1 - fx0) * 0.15;        
 // 15% perpendicular////
  goalHalf    = (fy1 - fy0) * 0.25;       
  // 50% of side length -> half = 25%//////
  goalCenterY = (fy0 + fy1) / 2.0;
}

void resetRound() {
  balls = new ArrayList<Ball>();
  placeBalls(4, TYPE_WHITE);
  placeBalls(26, TYPE_RED);
  placeBalls(26, TYPE_BLUE);

  gameBall = null;
  for (Ball b : balls) {
    if (b.type == TYPE_WHITE) { 
  gameBall = b; b.isGame = true; break; }
  }

  currentTurn = TYPE_RED;
  selectedBall = null;
  dragging = false;
}

void placeBalls(int n, int type) {
  int placed = 0;
  int attempts = 0;
  while (placed < n && attempts < 20000) {
    attempts++;
    float x = random(fx0 + ballRadius, fx1 - ballRadius);
    float y = random(fy0 + ballRadius, fy1 - ballRadius);
    if (overlapsAny(x, y, ballRadius)) continue;
    if (insideGoal(x, y)) continue;
    balls.add(new Ball(x, y, ballRadius, type));
    placed++;
  }
}

boolean overlapsAny(float x, float y, float r) {
  for (Ball b : balls) {
    if (dist(x, y, b.pos.x, b.pos.y) < r + b.r + 2) 
return true;
  }
  return false;
}

boolean insideGoal(float x, float y) {
  boolean inLeft  = x < fx0 + goalDepth && 
y > goalCenterY - goalHalf && y < goalCenterY + goalHalf;
  boolean inRight = x > fx1 - goalDepth &&
 y > goalCenterY - goalHalf && y < goalCenterY + goalHalf;
  return inLeft || inRight;
}

// ---------- Main loop ----------
// "think" fast: run physics 30 times with no drawing, then draw once/////

void draw() {
  if (!started) { drawMenu(); return; }

  for (int i = 0; i < 30; i++) {
    updatePhysics();
  }
  renderScene();
  maybeTakeAiTurn();
}

// ---------- Touch menu (no keyboard) ----------/////

float btnW, btnH, btnX, btn1Y, btn2Y, btn3Y;

void layoutMenuButtons() {
  btnW = width * 0.7;
  btnH = height * 0.09;
  btnX = (width - btnW) / 2.0;
  btn1Y = height * 0.40;
  btn2Y = height * 0.52;
  btn3Y = height * 0.64;
}

void drawMenu() {
  layoutMenuButtons();
  background(0);
  fill(255);
  textSize(28);
  text("CIRCLE GOAL", width/2, height*0.25);

  drawMenuButton(btn1Y, "MAN vs MAN");
  drawMenuButton(btn2Y, "ENGINE vs ENGINE");
  drawMenuButton(btn3Y, "MAN vs ENGINE");
}

void drawMenuButton(float y, String label) {
  noStroke();
  fill(40);
  rect(btnX, y, btnW, btnH, 20);
  stroke(255);
  strokeWeight(2);
  noFill();
  rect(btnX, y, btnW, btnH, 20);
  noStroke();
  fill(255);
  textSize(18);
  text(label, btnX + btnW/2.0, y + btnH/2.0);
}

boolean touchInButton(float y) {
  return mouseX > btnX && 
mouseX < btnX + btnW && mouseY > y && mouseY < y + btnH;
}

// ---------- Physics ----------////

void updatePhysics() {
  for (Ball b : balls) {
    b.pos.add(b.vel);
    b.vel.mult(FRICTION);
// billiard wall bounce, ball always stays inside the rect
    if (b.pos.x - b.r < fx0) 
{ b.pos.x = fx0 + b.r; b.vel.x *= -1; }
    if (b.pos.x + b.r > fx1) 
{ b.pos.x = fx1 - b.r; b.vel.x *= -1; }
    if (b.pos.y - b.r < fy0)
 { b.pos.y = fy0 + b.r; b.vel.y *= -1; }
    if (b.pos.y + b.r > fy1) 
{ b.pos.y = fy1 - b.r; b.vel.y *= -1; }

if 
(b.type == TYPE_WHITE && b.vel.mag() 
      < WHITE_ZERO_THRESHOLD) {
      b.vel.set(0, 0);
    }
  }

  for (int i = 0; i < balls.size(); i++) {
    for (int j = i + 1; j < balls.size(); j++) {
      resolveCollision(balls.get(i), balls.get(j));
    }
  }

  checkGoal();
}

void resolveCollision(Ball a, Ball b) {
  float dx = b.pos.x - a.pos.x;
  float dy = b.pos.y - a.pos.y;
  float d = sqrt(dx*dx + dy*dy);
  float minD = a.r + b.r;
  if (d < 0.0001) { d = 0.0001; dx = 0.0001; dy = 0; }
  if (d < minD) {
    float nx = dx / d;
    float ny = dy / d;
    float overlap = (minD - d) / 2.0;
    a.pos.x -= nx * overlap;  a.pos.y -= ny * overlap;
    b.pos.x += nx * overlap;  b.pos.y += ny * overlap;

    float dvx = b.vel.x - a.vel.x;
    float dvy = b.vel.y - a.vel.y;
    float dot = dvx*nx + dvy*ny;
    if (dot < 0) {
      a.vel.x += dot*nx; a.vel.y += dot*ny;
      b.vel.x -= dot*nx; b.vel.y -= dot*ny;
    }
  }
}

void checkGoal() {
  if (gameBall == null) return;
  Ball g = gameBall;
  boolean inLeftGoal  = 
g.pos.x - g.r < fx0 + goalDepth &&
 g.pos.y > goalCenterY - goalHalf && 
g.pos.y < goalCenterY + goalHalf;
boolean 
inRightGoal = g.pos.x + g.r > fx1 - goalDepth && 
g.pos.y > goalCenterY - goalHalf &&
 g.pos.y < goalCenterY + goalHalf;

  if (inLeftGoal)  { scoreBlue++; resetRound(); }
  else if (inRightGoal) { scoreRed++; resetRound(); }
}

// ---------- Input / shooting ----------

boolean humanControls(int team) {
  if (gameMode == MODE_MAN_MAN) return true;
  if (gameMode == MODE_MAN_ENGINE)
 return team == TYPE_RED; 
// human = red////
  return false;
 // engine vs engine///////
}

boolean allBallsStopped() {
  for (Ball b : balls) {
    if (b.vel.mag() > STOP_THRESHOLD) return false;
  }
  return true;
}

void mousePressed() {
  if (!started) {
    if (touchInButton(btn1Y))
    { gameMode = MODE_MAN_MAN;    
  started = true; resetRound(); }
    else if (touchInButton(btn2Y))
   { gameMode = MODE_ENGINE_ENGINE; 
   started = true; resetRound(); }
    else if (touchInButton(btn3Y))
    { gameMode = MODE_MAN_ENGINE;    
   started = true; resetRound(); }
    return;
  }
  if (!humanControls(currentTurn) ||
    !allBallsStopped()) return;
  for (Ball b : balls) {
    if (b.type == currentTurn && 
dist(mouseX, mouseY, b.pos.x, b.pos.y) < b.r) {
      selectedBall = b;
      dragStart = new PVector(mouseX, mouseY);
      dragCurrent = new PVector(mouseX, mouseY);
      dragging = true;
      break;
    }
  }
}

void mouseDragged() {
  if (dragging) dragCurrent.set(mouseX, mouseY);
}

void mouseReleased() {
  if (!dragging || selectedBall == null) return;
  shoot(selectedBall, dragStart, dragCurrent);
  dragging = false;
  selectedBall = null;
  currentTurn = 
(currentTurn == TYPE_RED) ? TYPE_BLUE : TYPE_RED;
}

void shoot(Ball b, PVector touch, PVector release) {
// pull-back-and-release, like a billiards cue / slingshot///
  PVector dir = PVector.sub(b.pos, release);
  float dragDist = dir.mag();
  if (dragDist < 1) return;
  dir.normalize();

// touching dead centre of the circle -> full precision -> up to 100%///
  // touching near the edge -> lower ceiling on strength///
float touchOffset = 
dist(touch.x, touch.y, b.pos.x, b.pos.y);
  float centerPrecision = 
    1.0 - constrain(touchOffset / b.r, 0, 1);

  float rawStrength = 
  constrain(dragDist / MAX_DRAG, 0, 1);
  float finalStrength =
   constrain(rawStrength * 
 (0.5 + 0.5*centerPrecision) * random(0.9, 1.0),
   0.01, 1.0);

  b.vel = PVector.mult(dir, finalStrength * MAX_SPEED);
}

// ---------- Simple AI ("engine") ----------///

void maybeTakeAiTurn() {
  if (!allBallsStopped()) { aiCooldown = 20; return; }
  if (humanControls(currentTurn)) return;
  if (aiCooldown > 0) { aiCooldown--; return; }

  aiTakeShot(currentTurn);
  currentTurn =
  (currentTurn == TYPE_RED) ? TYPE_BLUE : TYPE_RED;
  aiCooldown = 20;
}

void aiTakeShot(int team) {
  if (gameBall == null) return;

// pick the own-team ball closest to the game ball///
  Ball best = null;
  float bestD = Float.MAX_VALUE;
  for (Ball b : balls) {
    if (b.type != team) continue;
    float d = dist(b.pos.x, b.pos.y, 
    gameBall.pos.x, gameBall.pos.y);
    if (d < bestD) { bestD = d; best = b; }
  }
  if (best == null) return;

  float targetX = (team == TYPE_RED)
    ? fx1 - goalDepth*0.5 : fx0 + goalDepth*0.5;
  float targetY = goalCenterY;

  // proper "ghost ball" billiard aim: to send the game ball toward the
  // goal, aim best's centre at the point on the game ball's far side,
  // offset by the sum of the two radii along the goal direction///
  PVector goalDir = new 
  PVector(targetX - gameBall.pos.x, targetY 
       - gameBall.pos.y);
  if (goalDir.mag() < 0.0001) goalDir.set(1, 0);
  goalDir.normalize();
  PVector ghost = PVector.sub
 (gameBall.pos, PVector.mult(goalDir, best.r 
     + gameBall.r));

  PVector aim = PVector.sub(ghost, best.pos);
  if (aim.mag() < 0.0001) aim.set(1, 0);
  aim.normalize();

  // tiny random angle jitter: roughly 0..0.1% of a full turn, +/-////
 float angleJitter = radians(random(-0.1, 0.1) * 3.6);
  aim.rotate(angleJitter);

  // strength tier: maximum / 3-4 / 2-3 / middle / 1-3, minus 0..1% random////
  float[] tiers = {1.0, 0.75, 0.667, 0.5, 0.333};
  float tier = tiers[int(random(tiers.length))];
  float strength = constrain(tier 
    * (1.0 - random(0, 0.01)), 0.01, 1.0);

  best.vel = PVector.mult(aim, strength * MAX_SPEED);
}

// ---------- Rendering ----------///

void renderScene() {
  background(0);

  stroke(255);
  strokeWeight(2);
  noFill();
  rect(fx0, fy0, fx1 - fx0, fy1 - fy0, 55);

  stroke(255, 40);
  strokeWeight(1);
  for (int i = 1; i < 5; i++) {
    float gx = fx0 + (fx1 - fx0) * i / 5.0;
    line(gx, fy0, gx, fy1);
    float gy = fy0 + (fy1 - fy0) * i / 5.0;
    line(fx0, gy, fx1, gy);
  }

  noStroke();
  fill(255, 0, 0, 60);
  rect(fx0, goalCenterY - goalHalf,
    goalDepth, goalHalf * 2);
  fill(0, 100, 255, 60);
  rect(fx1 - goalDepth, 
   goalCenterY - goalHalf, goalDepth, goalHalf * 2);

  for (Ball b : balls) drawBall(b);

  if (dragging && selectedBall != null) {
    stroke(255, 220);
    strokeWeight(2);
    line(dragCurrent.x, dragCurrent.y, 
   selectedBall.pos.x, selectedBall.pos.y);
  }

  drawScore();
}

void drawBall(Ball b) {
  noStroke();
  if (b.type == TYPE_WHITE) fill(255);
  else if (b.type == TYPE_RED) fill(220, 40, 40);
  else fill(40, 110, 220);
  ellipse(b.pos.x, b.pos.y, b.r * 2, b.r * 2);

  if (b.isGame) {
    noFill();
    stroke(255, 200, 0);
    strokeWeight(2);
  ellipse(b.pos.x, b.pos.y, b.r * 2 + 6, b.r * 2 + 6);
  }

  // small decorative centre mark, ~0.05%-0.1% of (width+height)///
  noStroke();
  fill(0, 0, 0, 100);
  float markR = (width + height) * 0.0007;
  ellipse(b.pos.x, b.pos.y, markR, markR);
}

void drawScore() {
  fill(255, 128, 0, int(255 * 40 / 100.0));
  textSize(28);
  text("+" + scoreRed + "  RED  -  BLUE  " 
   + scoreBlue + "+", width/3, height/2);

  fill(255);
  textSize(14);
  String turnLabel = (currentTurn == TYPE_RED) ? "RED" : "BLUE";
  text("Turn: " + turnLabel, width/2, fy1 + 25);
}











/*



// ============================================================
// CircleGoalGame.pde
// APDE / Processing (0.5.3+) sketch
//
// Billiard-style checkers/football hybrid on a 5x5-marked field.
// 4 white "neutral" balls (one of them is THE ball), 26 red,
// 26 blue. Players/engines shoot their own-colour balls by
// dragging (slingshot style) to push the white game-ball into
// the opponent's goal mouth.
//
// NOTE ON THE SPEC FORMULA:
// The requested ball radius = (width+height) * (1/26) is too
// large to fit 56 non-overlapping circles on one field, so it
// is scaled down further below (ballRadius) while keeping the
// same proportion. Change BALL_RADIUS_DIVISOR to taste.
//
// Touch-only: no keyboard needed. Menu is tap buttons; shooting
// is drag-and-release on your own colour's balls.
// ============================================================

int TYPE_WHITE = 0;
int TYPE_RED   = 1;
int TYPE_BLUE  = 2;

int MODE_MAN_MAN        = 1;
int MODE_ENGINE_ENGINE  = 2;
int MODE_MAN_ENGINE     = 3;

int gameMode = 0;
boolean started = false;

float fx0, fy0, fx1, fy1;      // field rect: 10%-90% of width/height
float ballRadius;
float goalDepth, goalHalf, goalCenterY;

float BALL_RADIUS_DIVISOR = 26.0 * 8.0; // see note above

ArrayList<Ball> balls;
Ball gameBall;

int currentTurn = 1; // starts on RED

Ball selectedBall = null;
PVector dragStart, dragCurrent;
boolean dragging = false;

int scoreRed = 0;
int scoreBlue = 0;

float FRICTION = 0.9;
float STOP_THRESHOLD = 0.03;
float WHITE_ZERO_THRESHOLD = 0.01;
float MAX_SPEED = 18;
float MAX_DRAG = 160;

int aiCooldown = 0;

// ---------- Ball ----------

class Ball {
  PVector pos, vel;
  float r;
  int type;
  boolean isGame;
  Ball(float x, float y, float r_, int t) {
    pos = new PVector(x, y);
    vel = new PVector(0, 0);
    r = r_;
    type = t;
    isGame = false;
  }
}

// ---------- Setup ----------

void setup() {
  fullScreen();
  frameRate(60);
  computeField();
  textAlign(CENTER, CENTER);
}

void computeField() {
  fx0 = width * 0.10;
  fx1 = width * 0.90;
  fy0 = height * 0.10;
  fy1 = height * 0.90;

  ballRadius = (width + height) / BALL_RADIUS_DIVISOR;

  goalDepth   = (fx1 - fx0) * 0.15;         // 15% perpendicular
  goalHalf    = (fy1 - fy0) * 0.25;         // 50% of side length -> half = 25%
  goalCenterY = (fy0 + fy1) / 2.0;
}

void resetRound() {
  balls = new ArrayList<Ball>();
  placeBalls(4, TYPE_WHITE);
  placeBalls(26, TYPE_RED);
  placeBalls(26, TYPE_BLUE);

  gameBall = null;
  for (Ball b : balls) {
    if (b.type == TYPE_WHITE) { gameBall = b; b.isGame = true; break; }
  }

  currentTurn = TYPE_RED;
  selectedBall = null;
  dragging = false;
}

void placeBalls(int n, int type) {
  int placed = 0;
  int attempts = 0;
  while (placed < n && attempts < 20000) {
    attempts++;
    float x = random(fx0 + ballRadius, fx1 - ballRadius);
    float y = random(fy0 + ballRadius, fy1 - ballRadius);
    if (overlapsAny(x, y, ballRadius)) continue;
    if (insideGoal(x, y)) continue;
    balls.add(new Ball(x, y, ballRadius, type));
    placed++;
  }
}

boolean overlapsAny(float x, float y, float r) {
  for (Ball b : balls) {
    if (dist(x, y, b.pos.x, b.pos.y) < r + b.r + 2) return true;
  }
  return false;
}

boolean insideGoal(float x, float y) {
  boolean inLeft  = x < fx0 + goalDepth && y > goalCenterY - goalHalf && y < goalCenterY + goalHalf;
  boolean inRight = x > fx1 - goalDepth && y > goalCenterY - goalHalf && y < goalCenterY + goalHalf;
  return inLeft || inRight;
}

// ---------- Main loop ----------
// "think" fast: run physics 30 times with no drawing, then draw once

void draw() {
  if (!started) { drawMenu(); return; }

  for (int i = 0; i < 30; i++) {
    updatePhysics();
  }
  renderScene();
  maybeTakeAiTurn();
}

// ---------- Touch menu (no keyboard) ----------

float btnW, btnH, btnX, btn1Y, btn2Y, btn3Y;

void layoutMenuButtons() {
  btnW = width * 0.7;
  btnH = height * 0.09;
  btnX = (width - btnW) / 2.0;
  btn1Y = height * 0.40;
  btn2Y = height * 0.52;
  btn3Y = height * 0.64;
}

void drawMenu() {
  layoutMenuButtons();
  background(0);
  fill(255);
  textSize(28);
  text("CIRCLE GOAL", width/2, height*0.25);

  drawMenuButton(btn1Y, "MAN vs MAN");
  drawMenuButton(btn2Y, "ENGINE vs ENGINE");
  drawMenuButton(btn3Y, "MAN vs ENGINE");
}

void drawMenuButton(float y, String label) {
  noStroke();
  fill(40);
  rect(btnX, y, btnW, btnH, 20);
  stroke(255);
  strokeWeight(2);
  noFill();
  rect(btnX, y, btnW, btnH, 20);
  noStroke();
  fill(255);
  textSize(18);
  text(label, btnX + btnW/2.0, y + btnH/2.0);
}

boolean touchInButton(float y) {
  return mouseX > btnX && mouseX < btnX + btnW && mouseY > y && mouseY < y + btnH;
}

// ---------- Physics ----------

void updatePhysics() {
  for (Ball b : balls) {
    b.pos.add(b.vel);
    b.vel.mult(FRICTION);

    // billiard wall bounce, ball always stays inside the rect
    if (b.pos.x - b.r < fx0) { b.pos.x = fx0 + b.r; b.vel.x *= -1; }
    if (b.pos.x + b.r > fx1) { b.pos.x = fx1 - b.r; b.vel.x *= -1; }
    if (b.pos.y - b.r < fy0) { b.pos.y = fy0 + b.r; b.vel.y *= -1; }
    if (b.pos.y + b.r > fy1) { b.pos.y = fy1 - b.r; b.vel.y *= -1; }

    if (b.type == TYPE_WHITE && b.vel.mag() < WHITE_ZERO_THRESHOLD) {
      b.vel.set(0, 0);
    }
  }

  for (int i = 0; i < balls.size(); i++) {
    for (int j = i + 1; j < balls.size(); j++) {
      resolveCollision(balls.get(i), balls.get(j));
    }
  }

  checkGoal();
}

void resolveCollision(Ball a, Ball b) {
  float dx = b.pos.x - a.pos.x;
  float dy = b.pos.y - a.pos.y;
  float d = sqrt(dx*dx + dy*dy);
  float minD = a.r + b.r;
  if (d < 0.0001) { d = 0.0001; dx = 0.0001; dy = 0; }
  if (d < minD) {
    float nx = dx / d;
    float ny = dy / d;
    float overlap = (minD - d) / 2.0;
    a.pos.x -= nx * overlap;  a.pos.y -= ny * overlap;
    b.pos.x += nx * overlap;  b.pos.y += ny * overlap;

    float dvx = b.vel.x - a.vel.x;
    float dvy = b.vel.y - a.vel.y;
    float dot = dvx*nx + dvy*ny;
    if (dot < 0) {
      a.vel.x += dot*nx; a.vel.y += dot*ny;
      b.vel.x -= dot*nx; b.vel.y -= dot*ny;
    }
  }
}

void checkGoal() {
  if (gameBall == null) return;
  Ball g = gameBall;
  boolean inLeftGoal  = g.pos.x - g.r < fx0 + goalDepth && g.pos.y > goalCenterY - goalHalf && g.pos.y < goalCenterY + goalHalf;
  boolean inRightGoal = g.pos.x + g.r > fx1 - goalDepth && g.pos.y > goalCenterY - goalHalf && g.pos.y < goalCenterY + goalHalf;

  if (inLeftGoal)  { scoreBlue++; resetRound(); }
  else if (inRightGoal) { scoreRed++; resetRound(); }
}

// ---------- Input / shooting ----------

boolean humanControls(int team) {
  if (gameMode == MODE_MAN_MAN) return true;
  if (gameMode == MODE_MAN_ENGINE) return team == TYPE_RED; // human = red
  return false; // engine vs engine
}

boolean allBallsStopped() {
  for (Ball b : balls) {
    if (b.vel.mag() > STOP_THRESHOLD) return false;
  }
  return true;
}

void mousePressed() {
  if (!started) {
    if (touchInButton(btn1Y)) { gameMode = MODE_MAN_MAN;      started = true; resetRound(); }
    else if (touchInButton(btn2Y)) { gameMode = MODE_ENGINE_ENGINE; started = true; resetRound(); }
    else if (touchInButton(btn3Y)) { gameMode = MODE_MAN_ENGINE;    started = true; resetRound(); }
    return;
  }
  if (!humanControls(currentTurn) || !allBallsStopped()) return;
  for (Ball b : balls) {
    if (b.type == currentTurn && dist(mouseX, mouseY, b.pos.x, b.pos.y) < b.r) {
      selectedBall = b;
      dragStart = new PVector(mouseX, mouseY);
      dragCurrent = new PVector(mouseX, mouseY);
      dragging = true;
      break;
    }
  }
}

void mouseDragged() {
  if (dragging) dragCurrent.set(mouseX, mouseY);
}

void mouseReleased() {
  if (!dragging || selectedBall == null) return;
  shoot(selectedBall, dragStart, dragCurrent);
  dragging = false;
  selectedBall = null;
  currentTurn = (currentTurn == TYPE_RED) ? TYPE_BLUE : TYPE_RED;
}

void shoot(Ball b, PVector touch, PVector release) {
  // pull-back-and-release, like a billiards cue / slingshot
  PVector dir = PVector.sub(b.pos, release);
  float dragDist = dir.mag();
  if (dragDist < 1) return;
  dir.normalize();

  // touching dead centre of the circle -> full precision -> up to 100%
  // touching near the edge -> lower ceiling on strength
  float touchOffset = dist(touch.x, touch.y, b.pos.x, b.pos.y);
  float centerPrecision = 1.0 - constrain(touchOffset / b.r, 0, 1);

  float rawStrength = constrain(dragDist / MAX_DRAG, 0, 1);
  float finalStrength = constrain(rawStrength * (0.5 + 0.5*centerPrecision) * random(0.9, 1.0), 0.01, 1.0);

  b.vel = PVector.mult(dir, finalStrength * MAX_SPEED);
}

// ---------- Simple AI ("engine") ----------

void maybeTakeAiTurn() {
  if (!allBallsStopped()) { aiCooldown = 20; return; }
  if (humanControls(currentTurn)) return;
  if (aiCooldown > 0) { aiCooldown--; return; }

  aiTakeShot(currentTurn);
  currentTurn = (currentTurn == TYPE_RED) ? TYPE_BLUE : TYPE_RED;
  aiCooldown = 20;
}

void aiTakeShot(int team) {
  if (gameBall == null) return;

  // pick the own-team ball closest to the game ball
  Ball best = null;
  float bestD = Float.MAX_VALUE;
  for (Ball b : balls) {
    if (b.type != team) continue;
    float d = dist(b.pos.x, b.pos.y, gameBall.pos.x, gameBall.pos.y);
    if (d < bestD) { bestD = d; best = b; }
  }
  if (best == null) return;

  float targetX = (team == TYPE_RED) ? fx1 - goalDepth*0.5 : fx0 + goalDepth*0.5;
  float targetY = goalCenterY;

  // proper "ghost ball" billiard aim: to send the game ball toward the
  // goal, aim best's centre at the point on the game ball's far side,
  // offset by the sum of the two radii along the goal direction
  PVector goalDir = new PVector(targetX - gameBall.pos.x, targetY - gameBall.pos.y);
  if (goalDir.mag() < 0.0001) goalDir.set(1, 0);
  goalDir.normalize();
  PVector ghost = PVector.sub(gameBall.pos, PVector.mult(goalDir, best.r + gameBall.r));

  PVector aim = PVector.sub(ghost, best.pos);
  if (aim.mag() < 0.0001) aim.set(1, 0);
  aim.normalize();

  // tiny random angle jitter: roughly 0..0.1% of a full turn, +/-
  float angleJitter = radians(random(-0.1, 0.1) * 3.6);
  aim.rotate(angleJitter);

  // strength tier: maximum / 3-4 / 2-3 / middle / 1-3, minus 0..1% random
  float[] tiers = {1.0, 0.75, 0.667, 0.5, 0.333};
  float tier = tiers[int(random(tiers.length))];
  float strength = constrain(tier * (1.0 - random(0, 0.01)), 0.01, 1.0);

  best.vel = PVector.mult(aim, strength * MAX_SPEED);
}

// ---------- Rendering ----------

void renderScene() {
  background(0);

  stroke(255);
  strokeWeight(2);
  noFill();
  rect(fx0, fy0, fx1 - fx0, fy1 - fy0, 55);

  stroke(255, 40);
  strokeWeight(1);
  for (int i = 1; i < 5; i++) {
    float gx = fx0 + (fx1 - fx0) * i / 5.0;
    line(gx, fy0, gx, fy1);
    float gy = fy0 + (fy1 - fy0) * i / 5.0;
    line(fx0, gy, fx1, gy);
  }

  noStroke();
  fill(255, 0, 0, 60);
  rect(fx0, goalCenterY - goalHalf, goalDepth, goalHalf * 2);
  fill(0, 100, 255, 60);
  rect(fx1 - goalDepth, goalCenterY - goalHalf, goalDepth, goalHalf * 2);

  for (Ball b : balls) drawBall(b);

  if (dragging && selectedBall != null) {
    stroke(255, 220);
    strokeWeight(2);
    line(dragCurrent.x, dragCurrent.y, selectedBall.pos.x, selectedBall.pos.y);
  }

  drawScore();
}

void drawBall(Ball b) {
  noStroke();
  if (b.type == TYPE_WHITE) fill(255);
  else if (b.type == TYPE_RED) fill(220, 40, 40);
  else fill(40, 110, 220);
  ellipse(b.pos.x, b.pos.y, b.r * 2, b.r * 2);

  if (b.isGame) {
    noFill();
    stroke(255, 200, 0);
    strokeWeight(2);
    ellipse(b.pos.x, b.pos.y, b.r * 2 + 6, b.r * 2 + 6);
  }

  // small decorative centre mark, ~0.05%-0.1% of (width+height)
  noStroke();
  fill(0, 0, 0, 100);
  float markR = (width + height) * 0.0007;
  ellipse(b.pos.x, b.pos.y, markR, markR);
}

void drawScore() {
  fill(255, 128, 0, int(255 * 40 / 100.0));
  textSize(28);
  text("+" + scoreRed + "  RED  -  BLUE  " + scoreBlue + "+", width/3, height/2);

  fill(255);
  textSize(14);
  String turnLabel = (currentTurn == TYPE_RED) ? "RED" : "BLUE";
  text("Turn: " + turnLabel, width/2, fy1 + 25);
}







// ============================================================
// CircleGoalGame.pde
// APDE / Processing (0.5.3+) sketch
//
// Billiard-style checkers/football hybrid on a 5x5-marked field.
// 4 white "neutral" balls (one of them is THE ball), 26 red,
// 26 blue. Players/engines shoot their own-colour balls by
// dragging (slingshot style) to push the white game-ball into
// the opponent's goal mouth.
//
// NOTE ON THE SPEC FORMULA:
// The requested ball radius = (width+height) * (1/26) is too
// large to fit 56 non-overlapping circles on one field, so it
// is scaled down further below (ballRadius) while keeping the
// same proportion. Change BALL_RADIUS_DIVISOR to taste.
//
// Touch-only: no keyboard needed. Menu is tap buttons; shooting
// is drag-and-release on your own colour's balls.
// ============================================================

int TYPE_WHITE = 0;
int TYPE_RED   = 1;
int TYPE_BLUE  = 2;

int MODE_MAN_MAN        = 1;
int MODE_ENGINE_ENGINE  = 2;
int MODE_MAN_ENGINE     = 3;

int gameMode = 0;
boolean started = false;

float fx0, fy0, fx1, fy1;      // field rect: 10%-90% of width/height
float ballRadius;
float goalDepth, goalHalf, goalCenterY;

float BALL_RADIUS_DIVISOR = 26.0 * 8.0; // see note above

ArrayList<Ball> balls;
Ball gameBall;

int currentTurn = 1; // starts on RED

Ball selectedBall = null;
PVector dragStart, dragCurrent;
boolean dragging = false;

int scoreRed = 0;
int scoreBlue = 0;

float FRICTION = 0.9;
float STOP_THRESHOLD = 0.03;
float WHITE_ZERO_THRESHOLD = 0.01;
float MAX_SPEED = 18;
float MAX_DRAG = 160;

int aiCooldown = 0;

// ---------- Ball ----------

class Ball {
  PVector pos, vel;
  float r;
  int type;
  boolean isGame;
  Ball(float x, float y, float r_, int t) {
    pos = new PVector(x, y);
    vel = new PVector(0, 0);
    r = r_;
    type = t;
    isGame = false;
  }
}

// ---------- Setup ----------

void setup() {
  fullScreen();
  frameRate(60);
  computeField();
  textAlign(CENTER, CENTER);
}

void computeField() {
  fx0 = width * 0.10;
  fx1 = width * 0.90;
  fy0 = height * 0.10;
  fy1 = height * 0.90;

  ballRadius = (width + height) / BALL_RADIUS_DIVISOR;

  goalDepth   = (fx1 - fx0) * 0.15;         // 15% perpendicular
  goalHalf    = (fy1 - fy0) * 0.25;         // 50% of side length -> half = 25%
  goalCenterY = (fy0 + fy1) / 2.0;
}

void resetRound() {
  balls = new ArrayList<Ball>();
  placeBalls(4, TYPE_WHITE);
  placeBalls(26, TYPE_RED);
  placeBalls(26, TYPE_BLUE);

  gameBall = null;
  for (Ball b : balls) {
    if (b.type == TYPE_WHITE) { gameBall = b; b.isGame = true; break; }
  }

  currentTurn = TYPE_RED;
  selectedBall = null;
  dragging = false;
}

void placeBalls(int n, int type) {
  int placed = 0;
  int attempts = 0;
  while (placed < n && attempts < 20000) {
    attempts++;
    float x = random(fx0 + ballRadius, fx1 - ballRadius);
    float y = random(fy0 + ballRadius, fy1 - ballRadius);
    if (overlapsAny(x, y, ballRadius)) continue;
    if (insideGoal(x, y)) continue;
    balls.add(new Ball(x, y, ballRadius, type));
    placed++;
  }
}

boolean overlapsAny(float x, float y, float r) {
  for (Ball b : balls) {
    if (dist(x, y, b.pos.x, b.pos.y) < r + b.r + 2) return true;
  }
  return false;
}

boolean insideGoal(float x, float y) {
  boolean inLeft  = x < fx0 + goalDepth && y > goalCenterY - goalHalf && y < goalCenterY + goalHalf;
  boolean inRight = x > fx1 - goalDepth && y > goalCenterY - goalHalf && y < goalCenterY + goalHalf;
  return inLeft || inRight;
}

// ---------- Main loop ----------
// "think" fast: run physics 30 times with no drawing, then draw once

void draw() {
  if (!started) { drawMenu(); return; }

  for (int i = 0; i < 30; i++) {
    updatePhysics();
  }
  renderScene();
  maybeTakeAiTurn();
}

// ---------- Touch menu (no keyboard) ----------

float btnW, btnH, btnX, btn1Y, btn2Y, btn3Y;

void layoutMenuButtons() {
  btnW = width * 0.7;
  btnH = height * 0.09;
  btnX = (width - btnW) / 2.0;
  btn1Y = height * 0.40;
  btn2Y = height * 0.52;
  btn3Y = height * 0.64;
}

void drawMenu() {
  layoutMenuButtons();
  background(0);
  fill(255);
  textSize(28);
  text("CIRCLE GOAL", width/2, height*0.25);

  drawMenuButton(btn1Y, "MAN vs MAN");
  drawMenuButton(btn2Y, "ENGINE vs ENGINE");
  drawMenuButton(btn3Y, "MAN vs ENGINE");
}

void drawMenuButton(float y, String label) {
  noStroke();
  fill(40);
  rect(btnX, y, btnW, btnH, 20);
  stroke(255);
  strokeWeight(2);
  noFill();
  rect(btnX, y, btnW, btnH, 20);
  noStroke();
  fill(255);
  textSize(18);
  text(label, btnX + btnW/2.0, y + btnH/2.0);
}

boolean touchInButton(float y) {
  return mouseX > btnX && mouseX < btnX + btnW && mouseY > y && mouseY < y + btnH;
}

// ---------- Physics ----------

void updatePhysics() {
  for (Ball b : balls) {
    b.pos.add(b.vel);
    b.vel.mult(FRICTION);

    // billiard wall bounce, ball always stays inside the rect
    if (b.pos.x - b.r < fx0) { b.pos.x = fx0 + b.r; b.vel.x *= -1; }
    if (b.pos.x + b.r > fx1) { b.pos.x = fx1 - b.r; b.vel.x *= -1; }
    if (b.pos.y - b.r < fy0) { b.pos.y = fy0 + b.r; b.vel.y *= -1; }
    if (b.pos.y + b.r > fy1) { b.pos.y = fy1 - b.r; b.vel.y *= -1; }

    if (b.type == TYPE_WHITE && b.vel.mag() < WHITE_ZERO_THRESHOLD) {
      b.vel.set(0, 0);
    }
  }

  for (int i = 0; i < balls.size(); i++) {
    for (int j = i + 1; j < balls.size(); j++) {
      resolveCollision(balls.get(i), balls.get(j));
    }
  }

  checkGoal();
}

void resolveCollision(Ball a, Ball b) {
  float dx = b.pos.x - a.pos.x;
  float dy = b.pos.y - a.pos.y;
  float d = sqrt(dx*dx + dy*dy);
  float minD = a.r + b.r;
  if (d < 0.0001) { d = 0.0001; dx = 0.0001; dy = 0; }
  if (d < minD) {
    float nx = dx / d;
    float ny = dy / d;
    float overlap = (minD - d) / 2.0;
    a.pos.x -= nx * overlap;  a.pos.y -= ny * overlap;
    b.pos.x += nx * overlap;  b.pos.y += ny * overlap;

    float dvx = b.vel.x - a.vel.x;
    float dvy = b.vel.y - a.vel.y;
    float dot = dvx*nx + dvy*ny;
    if (dot < 0) {
      a.vel.x += dot*nx; a.vel.y += dot*ny;
      b.vel.x -= dot*nx; b.vel.y -= dot*ny;
    }
  }
}

void checkGoal() {
  if (gameBall == null) return;
  Ball g = gameBall;
  boolean inLeftGoal  = g.pos.x - g.r < fx0 + goalDepth && g.pos.y > goalCenterY - goalHalf && g.pos.y < goalCenterY + goalHalf;
  boolean inRightGoal = g.pos.x + g.r > fx1 - goalDepth && g.pos.y > goalCenterY - goalHalf && g.pos.y < goalCenterY + goalHalf;

  if (inLeftGoal)  { scoreBlue++; resetRound(); }
  else if (inRightGoal) { scoreRed++; resetRound(); }
}

// ---------- Input / shooting ----------

boolean humanControls(int team) {
  if (gameMode == MODE_MAN_MAN) return true;
  if (gameMode == MODE_MAN_ENGINE) return team == TYPE_RED; // human = red
  return false; // engine vs engine
}

boolean allBallsStopped() {
  for (Ball b : balls) {
    if (b.vel.mag() > STOP_THRESHOLD) return false;
  }
  return true;
}

void mousePressed() {
  if (!started) {
    if (touchInButton(btn1Y)) { gameMode = MODE_MAN_MAN;      started = true; resetRound(); }
    else if (touchInButton(btn2Y)) { gameMode = MODE_ENGINE_ENGINE; started = true; resetRound(); }
    else if (touchInButton(btn3Y)) { gameMode = MODE_MAN_ENGINE;    started = true; resetRound(); }
    return;
  }
  if (!humanControls(currentTurn) || !allBallsStopped()) return;
  for (Ball b : balls) {
    if (b.type == currentTurn && dist(mouseX, mouseY, b.pos.x, b.pos.y) < b.r) {
      selectedBall = b;
      dragStart = new PVector(mouseX, mouseY);
      dragCurrent = new PVector(mouseX, mouseY);
      dragging = true;
      break;
    }
  }
}

void mouseDragged() {
  if (dragging) dragCurrent.set(mouseX, mouseY);
}

void mouseReleased() {
  if (!dragging || selectedBall == null) return;
  shoot(selectedBall, dragStart, dragCurrent);
  dragging = false;
  selectedBall = null;
  currentTurn = (currentTurn == TYPE_RED) ? TYPE_BLUE : TYPE_RED;
}

void shoot(Ball b, PVector touch, PVector release) {
  // pull-back-and-release, like a billiards cue / slingshot
  PVector dir = PVector.sub(b.pos, release);
  float dragDist = dir.mag();
  if (dragDist < 1) return;
  dir.normalize();

  // touching dead centre of the circle -> full precision -> up to 100%
  // touching near the edge -> lower ceiling on strength
  float touchOffset = dist(touch.x, touch.y, b.pos.x, b.pos.y);
  float centerPrecision = 1.0 - constrain(touchOffset / b.r, 0, 1);

  float rawStrength = constrain(dragDist / MAX_DRAG, 0, 1);
  float finalStrength = constrain(rawStrength * (0.5 + 0.5*centerPrecision) * random(0.9, 1.0), 0.01, 1.0);

  b.vel = PVector.mult(dir, finalStrength * MAX_SPEED);
}

// ---------- Simple AI ("engine") ----------

void maybeTakeAiTurn() {
  if (!allBallsStopped()) { aiCooldown = 20; return; }
  if (humanControls(currentTurn)) return;
  if (aiCooldown > 0) { aiCooldown--; return; }

  aiTakeShot(currentTurn);
  currentTurn = (currentTurn == TYPE_RED) ? TYPE_BLUE : TYPE_RED;
  aiCooldown = 20;
}

void aiTakeShot(int team) {
  if (gameBall == null) return;

  // pick the own-team ball closest to the game ball
  Ball best = null;
  float bestD = Float.MAX_VALUE;
  for (Ball b : balls) {
    if (b.type != team) continue;
    float d = dist(b.pos.x, b.pos.y, gameBall.pos.x, gameBall.pos.y);
    if (d < bestD) { bestD = d; best = b; }
  }
  if (best == null) return;

  float targetX = (team == TYPE_RED) ? fx1 - goalDepth*0.5 : fx0 + goalDepth*0.5;
  float targetY = goalCenterY;

  // proper "ghost ball" billiard aim: to send the game ball toward the
  // goal, aim best's centre at the point on the game ball's far side,
  // offset by the sum of the two radii along the goal direction
  PVector goalDir = new PVector(targetX - gameBall.pos.x, targetY - gameBall.pos.y);
  if (goalDir.mag() < 0.0001) goalDir.set(1, 0);
  goalDir.normalize();
  PVector ghost = PVector.sub(gameBall.pos, PVector.mult(goalDir, best.r + gameBall.r));

  PVector aim = PVector.sub(ghost, best.pos);
  if (aim.mag() < 0.0001) aim.set(1, 0);
  aim.normalize();

  // tiny random angle jitter: roughly 0..0.1% of a full turn, +/-
  float angleJitter = radians(random(-0.1, 0.1) * 3.6);
  aim.rotate(angleJitter);

  // strength tier: maximum / 3-4 / 2-3 / middle / 1-3, minus 0..1% random
  float[] tiers = {1.0, 0.75, 0.667, 0.5, 0.333};
  float tier = tiers[int(random(tiers.length))];
  float strength = constrain(tier * (1.0 - random(0, 0.01)), 0.01, 1.0);

  best.vel = PVector.mult(aim, strength * MAX_SPEED);
}

// ---------- Rendering ----------

void renderScene() {
  background(0);

  stroke(255);
  strokeWeight(2);
  noFill();
  rect(fx0, fy0, fx1 - fx0, fy1 - fy0, 55);

  stroke(255, 40);
  strokeWeight(1);
  for (int i = 1; i < 5; i++) {
    float gx = fx0 + (fx1 - fx0) * i / 5.0;
    line(gx, fy0, gx, fy1);
    float gy = fy0 + (fy1 - fy0) * i / 5.0;
    line(fx0, gy, fx1, gy);
  }

  noStroke();
  fill(255, 0, 0, 60);
  rect(fx0, goalCenterY - goalHalf, goalDepth, goalHalf * 2);
  fill(0, 100, 255, 60);
  rect(fx1 - goalDepth, goalCenterY - goalHalf, goalDepth, goalHalf * 2);

  for (Ball b : balls) drawBall(b);

  if (dragging && selectedBall != null) {
    stroke(255, 220);
    strokeWeight(2);
    line(dragCurrent.x, dragCurrent.y, selectedBall.pos.x, selectedBall.pos.y);
  }

  drawScore();
}

void drawBall(Ball b) {
  noStroke();
  if (b.type == TYPE_WHITE) fill(255);
  else if (b.type == TYPE_RED) fill(220, 40, 40);
  else fill(40, 110, 220);
  ellipse(b.pos.x, b.pos.y, b.r * 2, b.r * 2);

  if (b.isGame) {
    noFill();
    stroke(255, 200, 0);
    strokeWeight(2);
    ellipse(b.pos.x, b.pos.y, b.r * 2 + 6, b.r * 2 + 6);
  }

  // small decorative centre mark, ~0.05%-0.1% of (width+height)
  noStroke();
  fill(0, 0, 0, 100);
  float markR = (width + height) * 0.0007;
  ellipse(b.pos.x, b.pos.y, markR, markR);
}

void drawScore() {
  fill(255, 128, 0, int(255 * 40 / 100.0));
  textSize(28);
  text("+" + scoreRed + "  RED  -  BLUE  " + scoreBlue + "+", width/3, height/2);

  fill(255);
  textSize(14);
  String turnLabel = (currentTurn == TYPE_RED) ? "RED" : "BLUE";
  text("Turn: " + turnLabel, width/2, fy1 + 25);
}






// ============================================================
// CircleGoalGame.pde
// APDE / Processing (0.5.3+) sketch
//
// Billiard-style checkers/football hybrid on a 5x5-marked field.
// 4 white "neutral" balls (one of them is THE ball), 26 red,
// 26 blue. Players/engines shoot their own-colour balls by
// dragging (slingshot style) to push the white game-ball into
// the opponent's goal mouth.
//
// NOTE ON THE SPEC FORMULA:
// The requested ball radius = (width+height) * (1/26) is too
// large to fit 56 non-overlapping circles on one field, so it
// is scaled down further below (ballRadius) while keeping the
// same proportion. Change BALL_RADIUS_DIVISOR to taste.
//
// Touch-only: no keyboard needed. Menu is tap buttons; shooting
// is drag-and-release on your own colour's balls.
// ============================================================

int TYPE_WHITE = 0;
int TYPE_RED   = 1;
int TYPE_BLUE  = 2;

int MODE_MAN_MAN        = 1;
int MODE_ENGINE_ENGINE  = 2;
int MODE_MAN_ENGINE     = 3;

int gameMode = 0;
boolean started = false;

float fx0, fy0, fx1, fy1;      // field rect: 10%-90% of width/height
float ballRadius;
float goalDepth, goalHalf, goalCenterY;

float BALL_RADIUS_DIVISOR = 26.0 * 8.0; // see note above

ArrayList<Ball> balls;
Ball gameBall;

int currentTurn = 1; // starts on RED

Ball selectedBall = null;
PVector dragStart, dragCurrent;
boolean dragging = false;

int scoreRed = 0;
int scoreBlue = 0;

float FRICTION = 0.9;
float STOP_THRESHOLD = 0.03;
float WHITE_ZERO_THRESHOLD = 0.01;
float MAX_SPEED = 18;
float MAX_DRAG = 160;

int aiCooldown = 0;

// ---------- Ball ----------

class Ball {
  PVector pos, vel;
  float r;
  int type;
  boolean isGame;
  Ball(float x, float y, float r_, int t) {
    pos = new PVector(x, y);
    vel = new PVector(0, 0);
    r = r_;
    type = t;
    isGame = false;
  }
}

// ---------- Setup ----------

void setup() {
  fullScreen();
  frameRate(60);
  computeField();
  textAlign(CENTER, CENTER);
}

void computeField() {
  fx0 = width * 0.10;
  fx1 = width * 0.90;
  fy0 = height * 0.10;
  fy1 = height * 0.90;

  ballRadius = (width + height) / BALL_RADIUS_DIVISOR;

  goalDepth   = (fx1 - fx0) * 0.15;         // 15% perpendicular
  goalHalf    = (fy1 - fy0) * 0.25;         // 50% of side length -> half = 25%
  goalCenterY = (fy0 + fy1) / 2.0;
}

void resetRound() {
  balls = new ArrayList<Ball>();
  placeBalls(4, TYPE_WHITE);
  placeBalls(26, TYPE_RED);
  placeBalls(26, TYPE_BLUE);

  gameBall = null;
  for (Ball b : balls) {
    if (b.type == TYPE_WHITE) { gameBall = b; b.isGame = true; break; }
  }

  currentTurn = TYPE_RED;
  selectedBall = null;
  dragging = false;
}

void placeBalls(int n, int type) {
  int placed = 0;
  int attempts = 0;
  while (placed < n && attempts < 20000) {
    attempts++;
    float x = random(fx0 + ballRadius, fx1 - ballRadius);
    float y = random(fy0 + ballRadius, fy1 - ballRadius);
    if (overlapsAny(x, y, ballRadius)) continue;
    if (insideGoal(x, y)) continue;
    balls.add(new Ball(x, y, ballRadius, type));
    placed++;
  }
}

boolean overlapsAny(float x, float y, float r) {
  for (Ball b : balls) {
    if (dist(x, y, b.pos.x, b.pos.y) < r + b.r + 2) return true;
  }
  return false;
}

boolean insideGoal(float x, float y) {
  boolean inLeft  = x < fx0 + goalDepth && y > goalCenterY - goalHalf && y < goalCenterY + goalHalf;
  boolean inRight = x > fx1 - goalDepth && y > goalCenterY - goalHalf && y < goalCenterY + goalHalf;
  return inLeft || inRight;
}

// ---------- Main loop ----------
// "think" fast: run physics 30 times with no drawing, then draw once

void draw() {
  if (!started) { drawMenu(); return; }

  for (int i = 0; i < 30; i++) {
    updatePhysics();
  }
  renderScene();
  maybeTakeAiTurn();
}

// ---------- Touch menu (no keyboard) ----------

float btnW, btnH, btnX, btn1Y, btn2Y, btn3Y;

void layoutMenuButtons() {
  btnW = width * 0.7;
  btnH = height * 0.09;
  btnX = (width - btnW) / 2.0;
  btn1Y = height * 0.40;
  btn2Y = height * 0.52;
  btn3Y = height * 0.64;
}

void drawMenu() {
  layoutMenuButtons();
  background(0);
  fill(255);
  textSize(28);
  text("CIRCLE GOAL", width/2, height*0.25);

  drawMenuButton(btn1Y, "MAN vs MAN");
  drawMenuButton(btn2Y, "ENGINE vs ENGINE");
  drawMenuButton(btn3Y, "MAN vs ENGINE");
}

void drawMenuButton(float y, String label) {
  noStroke();
  fill(40);
  rect(btnX, y, btnW, btnH, 20);
  stroke(255);
  strokeWeight(2);
  noFill();
  rect(btnX, y, btnW, btnH, 20);
  noStroke();
  fill(255);
  textSize(18);
  text(label, btnX + btnW/2.0, y + btnH/2.0);
}

boolean touchInButton(float y) {
  return mouseX > btnX && mouseX < btnX + btnW && mouseY > y && mouseY < y + btnH;
}

// ---------- Physics ----------

void updatePhysics() {
  for (Ball b : balls) {
    b.pos.add(b.vel);
    b.vel.mult(FRICTION);

    // billiard wall bounce, ball always stays inside the rect
    if (b.pos.x - b.r < fx0) { b.pos.x = fx0 + b.r; b.vel.x *= -1; }
    if (b.pos.x + b.r > fx1) { b.pos.x = fx1 - b.r; b.vel.x *= -1; }
    if (b.pos.y - b.r < fy0) { b.pos.y = fy0 + b.r; b.vel.y *= -1; }
    if (b.pos.y + b.r > fy1) { b.pos.y = fy1 - b.r; b.vel.y *= -1; }

    if (b.type == TYPE_WHITE && b.vel.mag() < WHITE_ZERO_THRESHOLD) {
      b.vel.set(0, 0);
    }
  }

  for (int i = 0; i < balls.size(); i++) {
    for (int j = i + 1; j < balls.size(); j++) {
      resolveCollision(balls.get(i), balls.get(j));
    }
  }

  checkGoal();
}

void resolveCollision(Ball a, Ball b) {
  float dx = b.pos.x - a.pos.x;
  float dy = b.pos.y - a.pos.y;
  float d = sqrt(dx*dx + dy*dy);
  float minD = a.r + b.r;
  if (d < 0.0001) { d = 0.0001; dx = 0.0001; dy = 0; }
  if (d < minD) {
    float nx = dx / d;
    float ny = dy / d;
    float overlap = (minD - d) / 2.0;
    a.pos.x -= nx * overlap;  a.pos.y -= ny * overlap;
    b.pos.x += nx * overlap;  b.pos.y += ny * overlap;

    float dvx = b.vel.x - a.vel.x;
    float dvy = b.vel.y - a.vel.y;
    float dot = dvx*nx + dvy*ny;
    if (dot < 0) {
      a.vel.x += dot*nx; a.vel.y += dot*ny;
      b.vel.x -= dot*nx; b.vel.y -= dot*ny;
    }
  }
}

void checkGoal() {
  if (gameBall == null) return;
  Ball g = gameBall;
  boolean inLeftGoal  = g.pos.x - g.r < fx0 + goalDepth && g.pos.y > goalCenterY - goalHalf && g.pos.y < goalCenterY + goalHalf;
  boolean inRightGoal = g.pos.x + g.r > fx1 - goalDepth && g.pos.y > goalCenterY - goalHalf && g.pos.y < goalCenterY + goalHalf;

  if (inLeftGoal)  { scoreBlue++; resetRound(); }
  else if (inRightGoal) { scoreRed++; resetRound(); }
}

// ---------- Input / shooting ----------

boolean humanControls(int team) {
  if (gameMode == MODE_MAN_MAN) return true;
  if (gameMode == MODE_MAN_ENGINE) return team == TYPE_RED; // human = red
  return false; // engine vs engine
}

boolean allBallsStopped() {
  for (Ball b : balls) {
    if (b.vel.mag() > STOP_THRESHOLD) return false;
  }
  return true;
}

void mousePressed() {
  if (!started) {
    if (touchInButton(btn1Y)) { gameMode = MODE_MAN_MAN;      started = true; resetRound(); }
    else if (touchInButton(btn2Y)) { gameMode = MODE_ENGINE_ENGINE; started = true; resetRound(); }
    else if (touchInButton(btn3Y)) { gameMode = MODE_MAN_ENGINE;    started = true; resetRound(); }
    return;
  }
  if (!humanControls(currentTurn) || !allBallsStopped()) return;
  for (Ball b : balls) {
    if (b.type == currentTurn && dist(mouseX, mouseY, b.pos.x, b.pos.y) < b.r) {
      selectedBall = b;
      dragStart = new PVector(mouseX, mouseY);
      dragCurrent = new PVector(mouseX, mouseY);
      dragging = true;
      break;
    }
  }
}

void mouseDragged() {
  if (dragging) dragCurrent.set(mouseX, mouseY);
}

void mouseReleased() {
  if (!dragging || selectedBall == null) return;
  shoot(selectedBall, dragStart, dragCurrent);
  dragging = false;
  selectedBall = null;
  currentTurn = (currentTurn == TYPE_RED) ? TYPE_BLUE : TYPE_RED;
}

void shoot(Ball b, PVector touch, PVector release) {
  // pull-back-and-release, like a billiards cue / slingshot
  PVector dir = PVector.sub(b.pos, release);
  float dragDist = dir.mag();
  if (dragDist < 1) return;
  dir.normalize();

  // touching dead centre of the circle -> full precision -> up to 100%
  // touching near the edge -> lower ceiling on strength
  float touchOffset = dist(touch.x, touch.y, b.pos.x, b.pos.y);
  float centerPrecision = 1.0 - constrain(touchOffset / b.r, 0, 1);

  float rawStrength = constrain(dragDist / MAX_DRAG, 0, 1);
  float finalStrength = constrain(rawStrength * (0.5 + 0.5*centerPrecision) * random(0.9, 1.0), 0.01, 1.0);

  b.vel = PVector.mult(dir, finalStrength * MAX_SPEED);
}

// ---------- Simple AI ("engine") ----------

void maybeTakeAiTurn() {
  if (!allBallsStopped()) { aiCooldown = 20; return; }
  if (humanControls(currentTurn)) return;
  if (aiCooldown > 0) { aiCooldown--; return; }

  aiTakeShot(currentTurn);
  currentTurn = (currentTurn == TYPE_RED) ? TYPE_BLUE : TYPE_RED;
  aiCooldown = 20;
}

void aiTakeShot(int team) {
  if (gameBall == null) return;

  // pick the own-team ball closest to the game ball
  Ball best = null;
  float bestD = Float.MAX_VALUE;
  for (Ball b : balls) {
    if (b.type != team) continue;
    float d = dist(b.pos.x, b.pos.y, gameBall.pos.x, gameBall.pos.y);
    if (d < bestD) { bestD = d; best = b; }
  }
  if (best == null) return;

  float targetX = (team == TYPE_RED) ? fx1 - goalDepth*0.5 : fx0 + goalDepth*0.5;
  float targetY = goalCenterY;

  // proper "ghost ball" billiard aim: to send the game ball toward the
  // goal, aim best's centre at the point on the game ball's far side,
  // offset by the sum of the two radii along the goal direction
  PVector goalDir = new PVector(targetX - gameBall.pos.x, targetY - gameBall.pos.y);
  if (goalDir.mag() < 0.0001) goalDir.set(1, 0);
  goalDir.normalize();
  PVector ghost = PVector.sub(gameBall.pos, PVector.mult(goalDir, best.r + gameBall.r));

  PVector aim = PVector.sub(ghost, best.pos);
  if (aim.mag() < 0.0001) aim.set(1, 0);
  aim.normalize();

  // tiny random angle jitter: roughly 0..0.1% of a full turn, +/-
  float angleJitter = radians(random(-0.1, 0.1) * 3.6);
  aim.rotate(angleJitter);

  // strength tier: maximum / 3-4 / 2-3 / middle / 1-3, minus 0..1% random
  float[] tiers = {1.0, 0.75, 0.667, 0.5, 0.333};
  float tier = tiers[int(random(tiers.length))];
  float strength = constrain(tier * (1.0 - random(0, 0.01)), 0.01, 1.0);

  best.vel = PVector.mult(aim, strength * MAX_SPEED);
}

// ---------- Rendering ----------

void renderScene() {
  background(0);

  stroke(255);
  strokeWeight(2);
  noFill();
  rect(fx0, fy0, fx1 - fx0, fy1 - fy0, 55);

  stroke(255, 40);
  strokeWeight(1);
  for (int i = 1; i < 5; i++) {
    float gx = fx0 + (fx1 - fx0) * i / 5.0;
    line(gx, fy0, gx, fy1);
    float gy = fy0 + (fy1 - fy0) * i / 5.0;
    line(fx0, gy, fx1, gy);
  }

  noStroke();
  fill(255, 0, 0, 60);
  rect(fx0, goalCenterY - goalHalf, goalDepth, goalHalf * 2);
  fill(0, 100, 255, 60);
  rect(fx1 - goalDepth, goalCenterY - goalHalf, goalDepth, goalHalf * 2);

  for (Ball b : balls) drawBall(b);

  if (dragging && selectedBall != null) {
    stroke(255, 220);
    strokeWeight(2);
    line(dragCurrent.x, dragCurrent.y, selectedBall.pos.x, selectedBall.pos.y);
  }

  drawScore();
}

void drawBall(Ball b) {
  noStroke();
  if (b.type == TYPE_WHITE) fill(255);
  else if (b.type == TYPE_RED) fill(220, 40, 40);
  else fill(40, 110, 220);
  ellipse(b.pos.x, b.pos.y, b.r * 2, b.r * 2);

  if (b.isGame) {
    noFill();
    stroke(255, 200, 0);
    strokeWeight(2);
    ellipse(b.pos.x, b.pos.y, b.r * 2 + 6, b.r * 2 + 6);
  }

  // small decorative centre mark, ~0.05%-0.1% of (width+height)
  noStroke();
  fill(0, 0, 0, 100);
  float markR = (width + height) * 0.0007;
  ellipse(b.pos.x, b.pos.y, markR, markR);
}

void drawScore() {
  fill(255, 128, 0, int(255 * 40 / 100.0));
  textSize(28);
  text("+" + scoreRed + "  RED  -  BLUE  " + scoreBlue + "+", width/3, height/2);

  fill(255);
  textSize(14);
  String turnLabel = (currentTurn == TYPE_RED) ? "RED" : "BLUE";
  text("Turn: " + turnLabel, width/2, fy1 + 25);
}
*/













































