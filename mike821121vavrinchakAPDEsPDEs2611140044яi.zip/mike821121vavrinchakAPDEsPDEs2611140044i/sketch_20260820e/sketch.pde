






         



////SEE///ok////ok////////


/*
  SMALL UCI CHESS ENGINE
  Processing / APDE 0.5.3

  No external libraries.

  UCI commands supported:
    uci
    isready
    ucinewgame
    position startpos
    position startpos moves e2e4 e7e5
    go depth 3
    stop
    quit

  Processing UI:
    Touch/click a piece, then touch/click destination.
*/

int[] board = new int[64];

boolean whiteTurn = true;
boolean engineThinking = false;
boolean engineIsWhite = false;

int selected = -1;

String lastMove = "";

int searchDepth = 3;

int[] pieceValue = {
  0,
  100, 320, 330, 500, 900, 20000,
  -100, -320, -330, -500, -900, -20000
};

// ------------------------------------------------------------
// PROCESSING
// ------------------------------------------------------------

void setup() {
  fullScreen(P2D);

  textAlign(CENTER, CENTER);
  rectMode(CORNER);

  newGame();

  println("Small APDE Chess Engine");
  println("UCI ready");
}

void draw() {
  background(35);

  drawBoard();
  drawPieces();

  if (engineThinking) {
    fill(255);
    textSize(30);
    text("ENGINE THINKING...", width/2, height - 50);
  }
}

void drawBoard() {

  float s = min(width, height - 80) / 8.0;

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {

      int sq = y * 8 + x;

      if ((x + y) % 2 == 0)
        fill(230, 210, 170);
      else
        fill(110, 80, 50);

      rect(x*s, y*s, s, s);

      if (sq == selected) {
        noFill();
        stroke(255, 0, 0);
        strokeWeight(5);
        rect(x*s+3, y*s+3, s-6, s-6);
        noStroke();
      }
    }
  }
}

void drawPieces() {

  float s = min(width, height - 80) / 8.0;

  textSize(s * 0.65);

  for (int sq = 0; sq < 64; sq++) {

    int p = board[sq];

    if (p == 0)
      continue;

    int x = sq % 8;
    int y = sq / 8;

    fill(p > 0 ? 255 : 20);

    text(pieceChar(p),
         x*s + s/2,
         y*s + s/2);
  }
}

String pieceChar(int p) {

  if (p == 1)  return "P";
  if (p == 2)  return "N";
  if (p == 3)  return "B";
  if (p == 4)  return "R";
  if (p == 5)  return "Q";
  if (p == 6)  return "K";

  if (p == -1) return "p";
  if (p == -2) return "n";
  if (p == -3) return "b";
  if (p == -4) return "r";
  if (p == -5) return "q";
  if (p == -6) return "k";

  return "";
}

void mousePressed() {

  float s = min(width, height - 80) / 8.0;

  if (mouseY >= 8*s)
    return;

  int x = int(mouseX / s);
  int y = int(mouseY / s);

  if (x < 0 || x > 7 || y < 0 || y > 7)
    return;

  int sq = y * 8 + x;

  if (selected == -1) {

    if (board[sq] != 0 &&
        ((whiteTurn && board[sq] > 0) ||
         (!whiteTurn && board[sq] < 0))) {

      selected = sq;
    }

  } else {

    if (selected != sq) {

      if (legalMove(selected, sq)) {

        makeMove(selected, sq);

        lastMove =
          squareName(selected) +
          squareName(sq);

        selected = -1;

        if (!whiteTurn && !engineThinking) {
          engineMove();
        }

      } else {

        selected = -1;
      }

    } else {
      selected = -1;
    }
  }
}

// ------------------------------------------------------------
// NEW GAME
// ------------------------------------------------------------

void newGame() {

  for (int i = 0; i < 64; i++)
    board[i] = 0;

  // Black
  board[0] = -4;
  board[1] = -2;
  board[2] = -3;
  board[3] = -5;
  board[4] = -6;
  board[5] = -3;
  board[6] = -2;
  board[7] = -4;

  for (int i = 8; i < 16; i++)
    board[i] = -1;

  // White
  board[56] = 4;
  board[57] = 2;
  board[58] = 3;
  board[59] = 5;
  board[60] = 6;
  board[61] = 3;
  board[62] = 2;
  board[63] = 4;

  for (int i = 48; i < 56; i++)
    board[i] = 1;

  whiteTurn = true;
  selected = -1;
  lastMove = "";
}

// ------------------------------------------------------------
// MOVE
// ------------------------------------------------------------

boolean legalMove(int from, int to) {

  int p = board[from];

  if (p == 0)
    return false;

  if (whiteTurn && p < 0)
    return false;

  if (!whiteTurn && p > 0)
    return false;

  if (board[to] != 0) {

    if ((p > 0 && board[to] > 0) ||
        (p < 0 && board[to] < 0))
      return false;
  }

  return pieceCanMove(from, to, p);
}

boolean pieceCanMove(int from, int to, int p) {

  int fx = from % 8;
  int fy = from / 8;

  int tx = to % 8;
  int ty = to / 8;

  int dx = tx - fx;
  int dy = ty - fy;

  int adx = abs(dx);
  int ady = abs(dy);

  int color = p > 0 ? 1 : -1;

  // PAWN
  if (abs(p) == 1) {

    int dir = color == 1 ? -1 : 1;

    if (dx == 0 && dy == dir && board[to] == 0)
      return true;

    if (dx == 0 &&
        dy == 2*dir &&
        ((color == 1 && fy == 6) ||
         (color == -1 && fy == 1))) {

      int mid = from + dir*8;

      if (board[mid] == 0 && board[to] == 0)
        return true;
    }

    if (adx == 1 &&
        dy == dir &&
        board[to] != 0)
      return true;

    return false;
  }

  // KNIGHT
  if (abs(p) == 2) {

    return (adx == 1 && ady == 2) ||
           (adx == 2 && ady == 1);
  }

  // KING
  if (abs(p) == 6) {

    return adx <= 1 && ady <= 1;
  }

  // BISHOP
  if (abs(p) == 3) {

    if (adx != ady)
      return false;

    return clearLine(from, to);
  }

  // ROOK
  if (abs(p) == 4) {

    if (dx != 0 && dy != 0)
      return false;

    return clearLine(from, to);
  }

  // QUEEN
  if (abs(p) == 5) {

    if (dx == 0 || dy == 0 ||
        adx == ady)
      return clearLine(from, to);

    return false;
  }

  return false;
}

// ------------------------------------------------------------
// LINE TEST
// ------------------------------------------------------------

boolean clearLine(int from, int to) {

  int fx = from % 8;
  int fy = from / 8;

  int tx = to % 8;
  int ty = to / 8;

  int sx = Integer.signum(tx - fx);
  int sy = Integer.signum(ty - fy);

  int x = fx + sx;
  int y = fy + sy;

  while (x != tx || y != ty) {

    int sq = y*8 + x;

    if (board[sq] != 0)
      return false;

    x += sx;
    y += sy;
  }

  return true;
}

// ------------------------------------------------------------
// MAKE MOVE
// ------------------------------------------------------------

void makeMove(int from, int to) {

  board[to] = board[from];
  board[from] = 0;

  // simple promotion
  int p = board[to];

  if (p == 1 && to/8 == 0)
    board[to] = 5;

  if (p == -1 && to/8 == 7)
    board[to] = -5;

  whiteTurn = !whiteTurn;
}

// ------------------------------------------------------------
// ENGINE
// ------------------------------------------------------------

void engineMove() {

  engineThinking = true;

  int bestFrom = -1;
  int bestTo = -1;

  int bestScore = -999999;

  for (int from = 0; from < 64; from++) {

    if (board[from] >= 0)
      continue;

    for (int to = 0; to < 64; to++) {

      if (!pieceCanMove(from, to, board[from]))
        continue;

      if (board[to] < 0)
        continue;

      int captured = board[to];

      board[to] = board[from];
      board[from] = 0;

      int score =
        -search(searchDepth - 1,
                -1000000,
                1000000,
                true);

      board[from] = board[to];
      board[to] = captured;

      if (score > bestScore) {

        bestScore = score;

        bestFrom = from;
        bestTo = to;
      }
    }
  }

  if (bestFrom != -1) {

    makeMove(bestFrom, bestTo);

    lastMove =
      squareName(bestFrom) +
      squareName(bestTo);

    println("bestmove " + lastMove);
  }

  engineThinking = false;
}

// ------------------------------------------------------------
// ALPHA BETA
// ------------------------------------------------------------

int search(int depth,
           int alpha,
           int beta,
           boolean white) {

  if (depth <= 0)
    return evaluate();

  int best = -999999;

  boolean found = false;

  for (int from = 0; from < 64; from++) {

    int p = board[from];

    if (p == 0)
      continue;

    if (white && p < 0)
      continue;

    if (!white && p > 0)
      continue;

    for (int to = 0; to < 64; to++) {

      if (!pieceCanMove(from, to, p))
        continue;

      if (board[to] != 0 &&
          ((p > 0 && board[to] > 0) ||
           (p < 0 && board[to] < 0)))
        continue;

      found = true;

      int captured = board[to];

      board[to] = board[from];
      board[from] = 0;

      int score =
        -search(depth - 1,
                -beta,
                -alpha,
                !white);

      board[from] = board[to];
      board[to] = captured;

      if (score > best)
        best = score;

      if (score > alpha)
        alpha = score;

      if (alpha >= beta)
        return alpha;
    }
  }

  if (!found)
    return evaluate();

  return best;
}

// ------------------------------------------------------------
// EVALUATION
// ------------------------------------------------------------

int evaluate() {

  int score = 0;

  for (int i = 0; i < 64; i++) {

    int p = board[i];

    if (p == 0)
      continue;

    score += pieceValue[p > 0 ? p : 6-p];
  }

  return score;
}

// ------------------------------------------------------------
// UCI
// ------------------------------------------------------------

void uci(String command) {

  command = trim(command);

  println("UCI COMMAND: " + command);

  if (command.equals("uci")) {

    println("id name SmallAPDE");
    println("id author APDE");
    println("uciok");
    return;
  }

  if (command.equals("isready")) {

    println("readyok");
    return;
  }

  if (command.equals("ucinewgame")) {

    newGame();
    return;
  }

  if (command.equals("position startpos")) {

    newGame();
    return;
  }

  if (command.startsWith("position startpos moves")) {

    newGame();

    String[] a = split(command, ' ');

    for (int i = 3; i < a.length; i++) {

      if (a[i].length() >= 4) {

        int from =
          parseSquare(a[i].substring(0,2));

        int to =
          parseSquare(a[i].substring(2,4));

        if (from >= 0 && to >= 0) {

          board[to] = board[from];
          board[from] = 0;

          whiteTurn = !whiteTurn;
        }
      }
    }

    return;
  }

  if (command.startsWith("go")) {

    int d = 3;

    String[] a = split(command, ' ');

    for (int i = 0; i < a.length-1; i++) {

      if (a[i].equals("depth"))
        d = int(a[i+1]);
    }

    searchDepth = constrain(d, 1, 5);

    if (!whiteTurn)
      engineMove();

    return;
  }

  if (command.equals("stop")) {

    engineThinking = false;
    return;
  }

  if (command.equals("quit")) {

    println("quit");
    return;
  }
}

// ------------------------------------------------------------
// SQUARE CONVERSION
// ------------------------------------------------------------

String squareName(int sq) {

  int x = sq % 8;
  int y = sq / 8;

  char file = char('a' + x);
  char rank = char('8' - y);

  return "" + file + rank;
}

int parseSquare(String s) {

  if (s.length() != 2)
    return -1;

  int x = s.charAt(0) - 'a';
  int y = '8' - s.charAt(1);

  if (x < 0 || x > 7 ||
      y < 0 || y > 7)
    return -1;

  return y*8 + x;
}

// ------------------------------------------------------------
// TEST UCI COMMANDS
// ------------------------------------------------------------

void keyPressed() {

  if (key == '1')
    uci("uci");

  if (key == '2')
    uci("isready");

  if (key == '3')
    uci("ucinewgame");

  if (key == '4')
    uci("position startpos");

  if (key == '5')
    uci("position startpos moves e2e4 e7e5");

  if (key == '6')
    uci("go depth 3");
}
















/////SEE/////














     

























/*
  SMALL APDE CHESS ENGINE v3
  APDE 0.5.3 / Processing Java

  ENGINE:
    - Legal chess moves
    - Check / checkmate / stalemate
    - Castling
    - En-passant
    - Promotion
    - Alpha-beta
    - Iterative deepening
    - Move ordering
    - Transposition table
    - 10-position history

  UI:
    Human = WHITE
    Engine = BLACK

  UCI:
    uci
    isready
    ucinewgame
    position startpos
    position startpos moves e2e4 e7e5
    go depth 4
    stop
    quit

  KEYBOARD:
    1 = uci
    2 = isready
    3 = new game
    4 = start position
    5 = e2e4 e7e5
    6 = engine depth 3
    7 = engine depth 4
    8 = engine depth 5
        *  /

int[] board = new int[64];

boolean whiteTurn = true;
boolean engineThinking = false;
boolean stopSearch = false;

int selected = -1;

int maxDepth = 4;
int currentDepth = 0;

long nodes = 0;
long searchStart;

// ------------------------------------------------------------
// CASTLING / EN PASSANT
// ------------------------------------------------------------

boolean castleWK;
boolean castleWQ;
boolean castleBK;
boolean castleBQ;

int enPassant = -1;

// ------------------------------------------------------------
// 10 POSITION HISTORY
// ------------------------------------------------------------

int[][] historyBoard = new int[10][64];

boolean[] historyTurn = new boolean[10];

boolean[] historyWK = new boolean[10];
boolean[] historyWQ = new boolean[10];
boolean[] historyBK = new boolean[10];
boolean[] historyBQ = new boolean[10];

int[] historyEP = new int[10];

int historyCount = 0;

// ------------------------------------------------------------
// MOVE
// ------------------------------------------------------------

class Move {

  int from;
  int to;

  int promotion;

  boolean castle;
  boolean enPassant;

  int captured;

  int score;

  Move(int f, int t) {
    from = f;
    to = t;
    promotion = 0;
    castle = false;
    enPassant = false;
    captured = 0;
    score = 0;
  }
}

// ------------------------------------------------------------
// TRANSPOSITION TABLE
// ------------------------------------------------------------

class TTEntry {

  long key;

  int depth;
  int score;

  int flag;

  int bestMove;

  TTEntry() {
    key = 0;
    depth = -1;
    score = 0;
    flag = 0;
    bestMove = -1;
  }
}

final int TT_SIZE = 32768;

TTEntry[] tt = new TTEntry[TT_SIZE];

final int TT_EXACT = 0;
final int TT_ALPHA = 1;
final int TT_BETA = 2;

// ------------------------------------------------------------
// PIECE VALUES
// ------------------------------------------------------------

int[] pieceValue = {
  0,
  100,
  320,
  330,
  500,
  900,
  20000
};

// ------------------------------------------------------------
// SETUP
// ------------------------------------------------------------

void setup() {

  fullScreen(P2D);

  textAlign(CENTER, CENTER);

  for (int i = 0; i < TT_SIZE; i++)
    tt[i] = new TTEntry();

  newGame();

  println("================================");
  println(" SMALL APDE CHESS ENGINE v3");
  println(" APDE 0.5.3");
  println("================================");
  println("UCI READY");
}

// ------------------------------------------------------------
// DRAW
// ------------------------------------------------------------

void draw() {

  background(30);

  float s = min(width, height - 90) / 8.0;

  drawBoard(s);
  drawPieces(s);

  fill(255);
  textSize(22);

  if (engineThinking) {

    text(
      "ENGINE DEPTH " +
      currentDepth +
      "  NODES " +
      nodes,
      width / 2,
      height - 40
    );

  } else {

    if (inCheck(whiteTurn))
      text("CHECK", width / 2, height - 40);
    else
      text(
        whiteTurn ? "WHITE" : "BLACK",
        width / 2,
        height - 40
      );
  }
}

// ------------------------------------------------------------
// DRAW BOARD
// ------------------------------------------------------------

void drawBoard(float s) {

  noStroke();

  for (int y = 0; y < 8; y++) {

    for (int x = 0; x < 8; x++) {

      if ((x + y) % 2 == 0)
        fill(230, 210, 170);
      else
        fill(105, 75, 50);

      rect(
        x * s,
        y * s,
        s,
        s
      );

      int sq = y * 8 + x;

      if (sq == selected) {

        noFill();

        stroke(255, 0, 0);
        strokeWeight(5);

        rect(
          x * s + 3,
          y * s + 3,
          s - 6,
          s - 6
        );

        noStroke();
      }
    }
  }
}

// ------------------------------------------------------------
// DRAW PIECES
// ------------------------------------------------------------

void drawPieces(float s) {

  textSize(s * 0.62);

  for (int sq = 0; sq < 64; sq++) {

    int p = board[sq];

    if (p == 0)
      continue;

    int x = sq % 8;
    int y = sq / 8;

    if (p > 0)
      fill(255);
    else
      fill(10);

    text(
      pieceChar(p),
      x * s + s / 2,
      y * s + s / 2
    );
  }
}

// ------------------------------------------------------------
// PIECE CHARACTER
// ------------------------------------------------------------

String pieceChar(int p) {

  if (p == 1) return "P";
  if (p == 2) return "N";
  if (p == 3) return "B";
  if (p == 4) return "R";
  if (p == 5) return "Q";
  if (p == 6) return "K";

  if (p == -1) return "p";
  if (p == -2) return "n";
  if (p == -3) return "b";
  if (p == -4) return "r";
  if (p == -5) return "q";
  if (p == -6) return "k";

  return "";
}

// ------------------------------------------------------------
// TOUCH
// ------------------------------------------------------------

void mousePressed() {

  float s = min(width, height - 90) / 8.0;

  if (mouseY >= s * 8)
    return;

  if (engineThinking)
    return;

  if (!whiteTurn)
    return;

  int x = int(mouseX / s);
  int y = int(mouseY / s);

  if (!inside(x, y))
    return;

  int sq = y * 8 + x;

  if (selected == -1) {

    if (board[sq] > 0)
      selected = sq;

    return;
  }

  if (sq == selected) {

    selected = -1;

    return;
  }

  ArrayList<Move> moves =
    generateLegalMoves(true);

  for (int i = 0; i < moves.size(); i++) {

    Move m = moves.get(i);

    if (m.from == selected &&
        m.to == sq) {

      makeMove(m);

      println(
        "move " +
        squareName(m.from) +
        squareName(m.to)
      );

      selected = -1;

      if (!whiteTurn)
        engineMove();

      return;
    }
  }

  selected = -1;
}

// ------------------------------------------------------------
// NEW GAME
// ------------------------------------------------------------

void newGame() {

  for (int i = 0; i < 64; i++)
    board[i] = 0;

  // BLACK

  board[0] = -4;
  board[1] = -2;
  board[2] = -3;
  board[3] = -5;
  board[4] = -6;
  board[5] = -3;
  board[6] = -2;
  board[7] = -4;

  for (int i = 8; i < 16; i++)
    board[i] = -1;

  // WHITE

  board[56] = 4;
  board[57] = 2;
  board[58] = 3;
  board[59] = 5;
  board[60] = 6;
  board[61] = 3;
  board[62] = 2;
  board[63] = 4;

  for (int i = 48; i < 56; i++)
    board[i] = 1;

  whiteTurn = true;

  castleWK = true;
  castleWQ = true;

  castleBK = true;
  castleBQ = true;

  enPassant = -1;

  selected = -1;

  historyCount = 0;

  saveHistory();

  clearTT();

  nodes = 0;
}

// ------------------------------------------------------------
// CLEAR TT
// ------------------------------------------------------------

void clearTT() {

  for (int i = 0; i < TT_SIZE; i++) {

    tt[i].key = 0;
    tt[i].depth = -1;
    tt[i].bestMove = -1;
  }
}

// ------------------------------------------------------------
// LEGAL MOVES
// ------------------------------------------------------------

ArrayList<Move> generateLegalMoves(boolean white) {

  ArrayList<Move> result =
    new ArrayList<Move>();

  for (int from = 0; from < 64; from++) {

    int p = board[from];

    if (p == 0)
      continue;

    if (white && p < 0)
      continue;

    if (!white && p > 0)
      continue;

    ArrayList<Move> pseudo =
      generatePseudo(from);

    for (int i = 0; i < pseudo.size(); i++) {

      Move m = pseudo.get(i);

      makeMove(m);

      boolean legal =
        !inCheck(white);

      undoLastMove();

      if (legal)
        result.add(m);
    }
  }

  return result;
}

// ------------------------------------------------------------
// PSEUDO MOVES
// ------------------------------------------------------------

ArrayList<Move> generatePseudo(int from) {

  ArrayList<Move> list =
    new ArrayList<Move>();

  int p = board[from];

  int color = p > 0 ? 1 : -1;

  int type = abs(p);

  int x = from % 8;
  int y = from / 8;

  // PAWN

  if (type == 1) {

    int dir = color > 0 ? -1 : 1;

    int start = color > 0 ? 6 : 1;

    int ny = y + dir;

    if (inside(x, ny)) {

      int to = ny * 8 + x;

      if (board[to] == 0) {

        addPawnMove(
          list,
          from,
          to,
          color
        );

        if (y == start) {

          int to2 =
            (y + 2 * dir) * 8 + x;

          if (board[to2] == 0)
            list.add(
              new Move(from, to2)
            );
        }
      }
    }

    for (int dx = -1; dx <= 1; dx += 2) {

      int nx = x + dx;

      if (!inside(nx, ny))
        continue;

      int to = ny * 8 + nx;

      if (board[to] != 0 &&
          ((board[to] > 0) != (color > 0))) {

        addPawnMove(
          list,
          from,
          to,
          color
        );
      }

      if (to == enPassant) {

        Move m =
          new Move(from, to);

        m.enPassant = true;

        list.add(m);
      }
    }

    return list;
  }

  // KNIGHT

  if (type == 2) {

    int[][] d = {
      {1,2},
      {2,1},
      {-1,2},
      {-2,1},
      {1,-2},
      {2,-1},
      {-1,-2},
      {-2,-1}
    };

    for (int i = 0; i < 8; i++)
      addNormal(
        list,
        from,
        x + d[i][0],
        y + d[i][1]
      );

    return list;
  }

  // BISHOP

  if (type == 3) {

    slide(list, from, x, y, 1, 1);
    slide(list, from, x, y, 1, -1);
    slide(list, from, x, y, -1, 1);
    slide(list, from, x, y, -1, -1);

    return list;
  }

  // ROOK

  if (type == 4) {

    slide(list, from, x, y, 1, 0);
    slide(list, from, x, y, -1, 0);
    slide(list, from, x, y, 0, 1);
    slide(list, from, x, y, 0, -1);

    return list;
  }

  // QUEEN

  if (type == 5) {

    slide(list, from, x, y, 1, 0);
    slide(list, from, x, y, -1, 0);
    slide(list, from, x, y, 0, 1);
    slide(list, from, x, y, 0, -1);

    slide(list, from, x, y, 1, 1);
    slide(list, from, x, y, 1, -1);
    slide(list, from, x, y, -1, 1);
    slide(list, from, x, y, -1, -1);

    return list;
  }

  // KING

  if (type == 6) {

    for (int dx = -1; dx <= 1; dx++) {

      for (int dy = -1; dy <= 1; dy++) {

        if (dx == 0 && dy == 0)
          continue;

        addNormal(
          list,
          from,
          x + dx,
          y + dy
        );
      }
    }

    // WHITE CASTLING

    if (color > 0) {

      if (castleWK &&
          board[61] == 0 &&
          board[62] == 0 &&
          !squareAttacked(60, false) &&
          !squareAttacked(61, false) &&
          !squareAttacked(62, false)) {

        Move m = new Move(60, 62);
        m.castle = true;

        list.add(m);
      }

      if (castleWQ &&
          board[59] == 0 &&
          board[58] == 0 &&
          board[57] == 0 &&
          !squareAttacked(60, false) &&
          !squareAttacked(59, false) &&
          !squareAttacked(58, false)) {

        Move m = new Move(60, 58);
        m.castle = true;

        list.add(m);
      }
    }

    // BLACK CASTLING

    else {

      if (castleBK &&
          board[5] == 0 &&
          board[6] == 0 &&
          !squareAttacked(4, true) &&
          !squareAttacked(5, true) &&
          !squareAttacked(6, true)) {

        Move m = new Move(4, 6);
        m.castle = true;

        list.add(m);
      }

      if (castleBQ &&
          board[3] == 0 &&
          board[2] == 0 &&
          board[1] == 0 &&
          !squareAttacked(4, true) &&
          !squareAttacked(3, true) &&
          !squareAttacked(2, true)) {

        Move m = new Move(4, 2);
        m.castle = true;

        list.add(m);
      }
    }

    return list;
  }

  return list;
}

// ------------------------------------------------------------
// PAWN MOVE
// ------------------------------------------------------------

void addPawnMove(
  ArrayList<Move> list,
  int from,
  int to,
  int color
) {

  Move m = new Move(from, to);

  int rank = to / 8;

  if ((color > 0 && rank == 0) ||
      (color < 0 && rank == 7)) {

    m.promotion = 5 * color;
  }

  list.add(m);
}

// ------------------------------------------------------------
// NORMAL MOVE
// ------------------------------------------------------------

void addNormal(
  ArrayList<Move> list,
  int from,
  int x,
  int y
) {

  if (!inside(x, y))
    return;

  int to = y * 8 + x;

  int p = board[from];

  if (board[to] != 0 &&
      ((board[to] > 0) == (p > 0)))
    return;

  list.add(
    new Move(from, to)
  );
}

// ------------------------------------------------------------
// SLIDE
// ------------------------------------------------------------

void slide(
  ArrayList<Move> list,
  int from,
  int x,
  int y,
  int dx,
  int dy
) {

  int p = board[from];

  x += dx;
  y += dy;

  while (inside(x, y)) {

    int to = y * 8 + x;

    if (board[to] == 0) {

      list.add(
        new Move(from, to)
      );

    } else {

      if ((board[to] > 0) != (p > 0)) {

        Move m =
          new Move(from, to);

        m.captured = board[to];

        list.add(m);
      }

      break;
    }

    x += dx;
    y += dy;
  }
}

// ------------------------------------------------------------
// MAKE MOVE
// ------------------------------------------------------------

void makeMove(Move m) {

  saveHistory();

  int p = board[m.from];

  m.captured = board[m.to];

  board[m.to] = p;
  board[m.from] = 0;

  // EN PASSANT

  if (m.enPassant) {

    if (p > 0)
      board[m.to + 8] = 0;
    else
      board[m.to - 8] = 0;
  }

  // PROMOTION

  if (m.promotion != 0)
    board[m.to] = m.promotion;

  // CASTLING ROOK

  if (m.castle) {

    if (m.to == 62) {

      board[61] = board[63];
      board[63] = 0;
    }

    if (m.to == 58) {

      board[59] = board[56];
      board[56] = 0;
    }

    if (m.to == 6) {

      board[5] = board[7];
      board[7] = 0;
    }

    if (m.to == 2) {

      board[3] = board[0];
      board[0] = 0;
    }
  }

  // CASTLING RIGHTS

  if (p == 6) {

    castleWK = false;
    castleWQ = false;
  }

  if (p == -6) {

    castleBK = false;
    castleBQ = false;
  }

  if (m.from == 63 || m.to == 63)
    castleWK = false;

  if (m.from == 56 || m.to == 56)
    castleWQ = false;

  if (m.from == 7 || m.to == 7)
    castleBK = false;

  if (m.from == 0 || m.to == 0)
    castleBQ = false;

  // NEW EN-PASSANT SQUARE

  enPassant = -1;

  if (abs(p) == 1 &&
      abs(m.to - m.from) == 16) {

    enPassant =
      (m.to + m.from) / 2;
  }

  whiteTurn = !whiteTurn;
}

// ------------------------------------------------------------
// UNDO
// ------------------------------------------------------------

void undoLastMove() {

  if (historyCount <= 0)
    return;

  historyCount--;

  for (int i = 0; i < 64; i++)
    board[i] =
      historyBoard[historyCount][i];

  whiteTurn =
    historyTurn[historyCount];

  castleWK =
    historyWK[historyCount];

  castleWQ =
    historyWQ[historyCount];

  castleBK =
    historyBK[historyCount];

  castleBQ =
    historyBQ[historyCount];

  enPassant =
    historyEP[historyCount];
}

// ------------------------------------------------------------
// HISTORY
// ------------------------------------------------------------

void saveHistory() {

  if (historyCount >= 10)
    historyCount = 9;

  for (int i = 0; i < 64; i++)
    historyBoard[historyCount][i] =
      board[i];

  historyTurn[historyCount] =
    whiteTurn;

  historyWK[historyCount] =
    castleWK;

  historyWQ[historyCount] =
    castleWQ;

  historyBK[historyCount] =
    castleBK;

  historyBQ[historyCount] =
    castleBQ;

  historyEP[historyCount] =
    enPassant;

  historyCount++;
}

// ------------------------------------------------------------
// CHECK
// ------------------------------------------------------------

boolean inCheck(boolean white) {

  int king = white ? 6 : -6;

  for (int i = 0; i < 64; i++) {

    if (board[i] == king)
      return squareAttacked(
        i,
        !white
      );
  }

  return true;
}

// ------------------------------------------------------------
// ATTACK
// ------------------------------------------------------------

boolean squareAttacked(
  int sq,
  boolean byWhite
) {

  int x = sq % 8;
  int y = sq / 8;

  int pawn =
    byWhite ? 1 : -1;

  int py =
    y + (byWhite ? 1 : -1);

  if (inside(x - 1, py) &&
      board[py * 8 + x - 1] == pawn)
    return true;

  if (inside(x + 1, py) &&
      board[py * 8 + x + 1] == pawn)
    return true;

  int knight =
    byWhite ? 2 : -2;

  int[][] nd = {
    {1,2},
    {2,1},
    {-1,2},
    {-2,1},
    {1,-2},
    {2,-1},
    {-1,-2},
    {-2,-1}
  };

  for (int i = 0; i < 8; i++) {

    int nx = x + nd[i][0];
    int ny = y + nd[i][1];

    if (inside(nx, ny) &&
        board[ny * 8 + nx] == knight)
      return true;
  }

  int bishop =
    byWhite ? 3 : -3;

  int rook =
    byWhite ? 4 : -4;

  int queen =
    byWhite ? 5 : -5;

  if (rayAttack(
        x,y,1,1,
        bishop,queen))
    return true;

  if (rayAttack(
        x,y,1,-1,
        bishop,queen))
    return true;

  if (rayAttack(
        x,y,-1,1,
        bishop,queen))
    return true;

  if (rayAttack(
        x,y,-1,-1,
        bishop,queen))
    return true;

  if (rayAttack(
        x,y,1,0,
        rook,queen))
    return true;

  if (rayAttack(
        x,y,-1,0,
        rook,queen))
    return true;

  if (rayAttack(
        x,y,0,1,
        rook,queen))
    return true;

  if (rayAttack(
        x,y,0,-1,
        rook,queen))
    return true;

  int king =
    byWhite ? 6 : -6;

  for (int dx = -1; dx <= 1; dx++) {

    for (int dy = -1; dy <= 1; dy++) {

      if (dx == 0 && dy == 0)
        continue;

      int nx = x + dx;
      int ny = y + dy;

      if (inside(nx, ny) &&
          board[ny * 8 + nx] == king)
        return true;
    }
  }

  return false;
}

// ------------------------------------------------------------
// RAY ATTACK
// ------------------------------------------------------------

boolean rayAttack(
  int x,
  int y,
  int dx,
  int dy,
  int piece,
  int queen
) {

  x += dx;
  y += dy;

  while (inside(x, y)) {

    int p = board[y * 8 + x];

    if (p != 0)
      return p == piece || p == queen;

    x += dx;
    y += dy;
  }

  return false;
}

// ============================================================
// ENGINE
// ============================================================

// ------------------------------------------------------------
// ENGINE MOVE
// ------------------------------------------------------------

void engineMove() {

  engineThinking = true;
  stopSearch = false;

  nodes = 0;

  searchStart = millis();

  Move best = null;

  int bestScore = -10000000;

  // ITERATIVE DEEPENING

  for (int depth = 1;
       depth <= maxDepth;
       depth++) {

    currentDepth = depth;

    ArrayList<Move> moves =
      generateLegalMoves(false);

    if (moves.size() == 0)
      break;

    orderMoves(moves);

    Move depthBest = null;

    int depthBestScore =
      -10000000;

    for (int i = 0;
         i < moves.size();
         i++) {

      if (stopSearch)
        break;

      Move m = moves.get(i);

      makeMove(m);

      int score =
        -search(
          depth - 1,
          -10000000,
          10000000
        );

      undoLastMove();

      m.score = score;

      if (score > depthBestScore) {

        depthBestScore = score;
        depthBest = m;
      }
    }

    if (stopSearch)
      break;

    if (depthBest != null) {

      best = depthBest;
      bestScore = depthBestScore;

      println(
        "depth " +
        depth +
        " score " +
        bestScore +
        " nodes " +
        nodes
      );
    }
  }

  if (best != null) {

    String moveText =
      squareName(best.from) +
      squareName(best.to);

    makeMove(best);

    println(
      "bestmove " +
      moveText
    );
  }

  engineThinking = false;

  currentDepth = 0;
}

// ------------------------------------------------------------
// SEARCH
// ------------------------------------------------------------

int search(
  int depth,
  int alpha,
  int beta
) {

  nodes++;

  if ((nodes & 4095) == 0) {

    if (stopSearch)






  ////    return evaluate();


       return - 99;







    if (millis() - searchStart > 15000) {

      stopSearch = true;






   /////   return evaluate();

        return - 99;








    }
  }

  long key = positionKey();

  int index =
    (int)(abs(key) % TT_SIZE);

  TTEntry entry = tt[index];

  int originalAlpha = alpha;

  if (entry.key == key &&
      entry.depth >= depth) {

    if (entry.flag == TT_EXACT)
      return entry.score;

    if (entry.flag == TT_ALPHA &&
        entry.score <= alpha)
      return entry.score;

    if (entry.flag == TT_BETA &&
        entry.score >= beta)
      return entry.score;
  }

  ArrayList<Move> moves =
    generateLegalMoves(whiteTurn);

  if (moves.size() == 0) {

    if (inCheck(whiteTurn))
      return -100000 + depth;

    return 0;
  }

  if (depth <= 0)
    return evaluateForSide();

  orderMoves(moves);

  int best = -10000000;

  int bestMove = -1;

  for (int i = 0; i < moves.size(); i++) {

    if (stopSearch)
      break;

    Move m = moves.get(i);

    makeMove(m);

    int score =
      -search(
        depth - 1,
        -beta,
        -alpha
      );

    undoLastMove();

    if (score > best) {

      best = score;

      bestMove =
        m.from * 64 + m.to;
    }

    if (score > alpha)
      alpha = score;

    if (alpha >= beta)
      break;
  }

  int flag = TT_EXACT;

  if (best <= originalAlpha)
    flag = TT_ALPHA;
  else if (best >= beta)
    flag = TT_BETA;

  entry.key = key;
  entry.depth = depth;
  entry.score = best;
  entry.flag = flag;
  entry.bestMove = bestMove;

  return best;
}

// ------------------------------------------------------------
// MOVE ORDERING
// ------------------------------------------------------------

void orderMoves(
  ArrayList<Move> moves
) {

  for (int i = 0;
       i < moves.size();
       i++) {

    Move m = moves.get(i);

    int score = 0;

    if (m.captured != 0) {

      score +=
        10 * pieceValue[abs(m.captured)];

      score -=
        pieceValue[abs(board[m.from])];
    }

    if (m.promotion != 0)
      score += 800;

    if (m.castle)
      score += 50;

    // center bonus

    int tx = m.to % 8;
    int ty = m.to / 8;

    if (tx >= 2 && tx <= 5 &&
        ty >= 2 && ty <= 5)
      score += 10;

    m.score = score;
  }

  // INSERTION SORT

  for (int i = 1;
       i < moves.size();
       i++) {

    Move key = moves.get(i);

    int j = i - 1;

    while (j >= 0 &&
           moves.get(j).score < key.score) {

      moves.set(
        j + 1,
        moves.get(j)
      );

      j--;
    }

    moves.set(j + 1, key);
  }
}

// ------------------------------------------------------------
// EVALUATION
// ------------------------------------------------------------

int evaluateForSide() {

  int score = 0;

  for (int i = 0; i < 64; i++) {

    int p = board[i];

    if (p == 0)
      continue;

    int value =
      pieceValue[abs(p)];

    score +=
      p > 0 ? value : -value;

    // CENTER CONTROL

    int x = i % 8;
    int y = i / 8;

    if (x >= 2 && x <= 5 &&
        y >= 2 && y <= 5) {

      score +=
        p > 0 ? 4 : -4;
    }
  }

  ArrayList<Move> moves =
    generatePseudoAll(whiteTurn);

  score +=
    whiteTurn ?
    moves.size() * 2 :
    -moves.size() * 2;

  return whiteTurn ?
    score :
    -score;
}

// ------------------------------------------------------------
// PSEUDO ALL
// ------------------------------------------------------------

ArrayList<Move> generatePseudoAll(
  boolean white
) {

  ArrayList<Move> list =
    new ArrayList<Move>();

  for (int from = 0; from < 64; from++) {

    int p = board[from];

    if (p == 0)
      continue;

    if (white && p < 0)
      continue;

    if (!white && p > 0)
      continue;

    list.addAll(
      generatePseudo(from)
    );
  }

  return list;
}

// ------------------------------------------------------------
// POSITION HASH
// ------------------------------------------------------------

long positionKey() {

  long h = 1469598103934665603L;

  for (int i = 0; i < 64; i++) {

    h ^= (board[i] + 7);

    h *= 1099511628211L;
  }

  h ^= whiteTurn ? 1 : 2;

  h *= 1099511628211L;

  if (castleWK) h ^= 3;
  if (castleWQ) h ^= 5;
  if (castleBK) h ^= 7;
  if (castleBQ) h ^= 11;

  h ^= enPassant + 17;

  return h;
}

// ------------------------------------------------------------
// UCI
// ------------------------------------------------------------

void uci(String command) {

  command = trim(command);

  println("> " + command);

  if (command.equals("uci")) {

    println(
      "id name SmallAPDE-Chess-v3"
    );

    println(
      "id author APDE"
    );

    println(
      "option name Depth type spin " +
      "default 4 min 1 max 6"
    );

    println("uciok");

    return;
  }

  if (command.equals("isready")) {

    println("readyok");

    return;
  }

  if (command.equals("ucinewgame")) {

    newGame();

    return;
  }

  if (command.equals("stop")) {

    stopSearch = true;

    return;
  }

  if (command.equals("quit")) {

    stopSearch = true;

    println("quit");

    return;
  }

  if (command.startsWith(
        "position startpos")) {

    newGame();

    int pos =
      command.indexOf("moves");

    if (pos >= 0) {

      String rest =
        trim(
          command.substring(
            pos + 5
          )
        );

      if (rest.length() > 0) {

        String[] a =
          split(rest, ' ');

        for (int i = 0;
             i < a.length;
             i++) {

          applyUCIMove(a[i]);
        }
      }
    }

    return;
  }

  if (command.startsWith("go")) {

    int d = 4;

    String[] a =
      split(command, ' ');

    for (int i = 0;
         i < a.length - 1;
         i++) {

      if (a[i].equals("depth"))
        d = int(a[i + 1]);
    }

    maxDepth =
      constrain(d, 1, 6);

    if (!whiteTurn)
      engineMove();

    return;
  }
}

// ------------------------------------------------------------
// APPLY UCI MOVE
// ------------------------------------------------------------

void applyUCIMove(String s) {

  if (s.length() < 4)
    return;

  int from =
    parseSquare(
      s.substring(0, 2)
    );

  int to =
    parseSquare(
      s.substring(2, 4)
    );

  if (from < 0 || to < 0)
    return;

  ArrayList<Move> moves =
    generateLegalMoves(whiteTurn);

  for (int i = 0;
       i < moves.size();
       i++) {

    Move m = moves.get(i);

    if (m.from == from &&
        m.to == to) {

      makeMove(m);

      println(
        "played " + s
      );

      return;
    }
  }

  println(
    "ILLEGAL MOVE: " + s
  );
}

// ------------------------------------------------------------
// STATUS
// ------------------------------------------------------------

void printStatus() {

  ArrayList<Move> moves =
    generateLegalMoves(whiteTurn);

  if (moves.size() == 0) {

    if (inCheck(whiteTurn)) {

      if (whiteTurn)
        println(
          "CHECKMATE: BLACK WINS"
        );
      else
        println(
          "CHECKMATE: WHITE WINS"
        );

    } else {

      println("STALEMATE");
    }

  } else if (inCheck(whiteTurn)) {

    println("CHECK");

  } else {

    println("NORMAL");
  }
}

// ------------------------------------------------------------
// SQUARE
// ------------------------------------------------------------

String squareName(int sq) {

  int x = sq % 8;
  int y = sq / 8;

  return "" +
    char('a' + x) +
    char('8' - y);
}

int parseSquare(String s) {

  if (s.length() != 2)
    return -1;

  int x =
    s.charAt(0) - 'a';

  int y =
    '8' - s.charAt(1);

  if (!inside(x, y))
    return -1;

  return y * 8 + x;
}

// ------------------------------------------------------------
// INSIDE
// ------------------------------------------------------------

boolean inside(int x, int y) {

  return
    x >= 0 &&
    x < 8 &&
    y >= 0 &&
    y < 8;
}

// ------------------------------------------------------------
// KEYBOARD
// ------------------------------------------------------------

void keyPressed() {

  if (key == '1')
    uci("uci");

  if (key == '2')
    uci("isready");

  if (key == '3')
    uci("ucinewgame");

  if (key == '4')
    uci("position startpos");

  if (key == '5')
    uci(
      "position startpos moves " +
      "e2e4 e7e5"
    );

  if (key == '6')
    uci("go depth 3");

  if (key == '7')
    uci("go depth 4");

  if (key == '8')
    uci("go depth 5");

  if (key == '9')
    printStatus();

  if (key == 's')
    uci("stop");
}


















*/





































