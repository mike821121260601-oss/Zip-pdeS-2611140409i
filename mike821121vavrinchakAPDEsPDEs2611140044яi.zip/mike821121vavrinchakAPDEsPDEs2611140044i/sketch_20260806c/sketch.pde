






String
ERR="♟";
//  "♟";














void  setup() {
  size(400, 400);
  noLoop(); // Draw once
}

void draw() {
  background(255);
  drawChessboard();
  drawChessFigures();
}

// Void for drawing the chessboard
void drawChessboard() {
  int squareSize = width / 8;
  for (int x = 0; x < 8; x++) {
    for (int y = 0; y < 8; y++) {
      if ((x + y) % 2 == 0) {
        fill(255, 255, 200); // Light yellow
      } else {
        fill(200, 200, 200); // Light gray
      }
      rect(x * squareSize, y * squareSize, squareSize, 
squareSize);
    }
  }
}












// Void for drawing chess figures
void drawChessFigures() {
  // Red pieces (top)








/*
  drawChessFigure(0, 0, "♜", red);  
  drawChessFigure(1, 0, "♞", red);  
  drawChessFigure(2, 0, "♝", red);  
  drawChessFigure(3, 0, "♚", red);   
  drawChessBoardFigure(4, 0, "♛", red); 
  drawChessFigure(5, 0, "♝", red);   
  drawChessFigure(6, 0, "♞", red);  
  drawChessFigure(7, 0, "♜", red);  
  for (int i = 0; i < 8; i++) {
    drawChessFigure(i, 1, "♟", red); 
  }

  




  drawChessFigure(0, 7, "♜", blue);  
  drawChessFigure(1, 7, "♞", blue);  
  drawChessFigure(2, 7, "♝", blue);  
  drawChessFigure(3, 7, "♚", blue);  
  drawChessBoardFigure(4, 7, "♛", blue); 
  drawChessFigure(5, 7, "♝", blue);  
  drawChessFigure(6, 7, "♞", blue);  
  drawChessFigure(7, 7, "♜", blue); 



*/





. 

for (int i = 0; i < 8; squareSize, squareSize); 

    drawChessFigure(i, 6, "♟", blue);



  }
}


void drawChessFigure(int gridX, int gridY, String figure, c) {
  int squareSize = width / 8;
  fill(c);
  textSize(squareSize * 0.8);
  textAlign(CENTER, CENTER);
  text(figure, gridX * squareSize + squareSize / 2, gridY * squareSize + squareSize / 2);
}

// Alternative method: Drawing using rectangle coordinates (as per your request)
void drawChessBoardFigure(int x, int y, String figure, color c) {
  int squareSize = width / 8;
  fill(c);
  textSize(squareSize * 0.8);
  textAlign(CENTER, CENTER);
  text(figure, x * squareSize + squareSize / 2, squareSize / 2);
}


































