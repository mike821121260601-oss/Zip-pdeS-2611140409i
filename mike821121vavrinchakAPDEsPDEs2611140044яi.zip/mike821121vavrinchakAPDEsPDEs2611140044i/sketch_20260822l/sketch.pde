
// Version 3 – P3D spheres version (more visual, still playable)
int NUM = 16;
float BALL_R = 14;
float MARGIN = 60;

Ball[] balls = new Ball[NUM];
boolean aiming = false;
PVector aimS, aimE;
float camZ = 0;

void setup() {
  size(displayWidth, displayHeight, P3D);



  orientation(LANDSCAPE);


      ////orientation(PORTRAIT);


  frameRate(50);
  reset();
}

void reset() {
  balls[0] = new Ball(width*0.25, height/2, color(255), true);
  float sx = width*0.65, sy = height/2, d = BALL_R*2.1;
  int id = 1;
  for (int r=0; r<5; r++) {
    for (int c=0; c<=r; c++) {
      if (id>=NUM) break;
      float x = sx + r*d*0.866;
      float y = sy - r*d/2 + c*d;
      balls[id++] = new Ball(x, y, color(random(70,255),random(40,190),random(30,170)), false);
    }
  }
}

void draw() {
  background(10, 30, 15);
  lights();
  ambientLight(60, 80, 50);
  directionalLight(200, 200, 180, 0.4, 0.6, -1);
  
  // table
  pushMatrix();
  translate(width/2, height/2, -30);
  fill(20, 100, 40); noStroke();
  box(width-2*MARGIN, height-2*MARGIN, 20);
  popMatrix();
  
  // cushions hint
  stroke(80, 40, 10); strokeWeight(6); noFill();
  rect(MARGIN, MARGIN, width-2*MARGIN, height-2*MARGIN);
  
  for (Ball b : balls) b.move();
  for (int i=0; i<NUM; i++)
    for (int j=i+1; j<NUM; j++) balls[i].hit(balls[j]);
  
  for (Ball b : balls) b.show();
  
  if (aiming) {
    stroke(255, 180); strokeWeight(3);
    line(aimS.x, aimS.y, aimE.x, aimE.y);
  }
  
  // HUD
  camera();
  fill(255); textSize(18);
  text("P3D Pool – drag white ball  |  R = reset", 20, 30);
}

void mousePressed() {
  if (dist(mouseX,mouseY,balls[0].p.x,balls[0].p.y) < BALL_R*4) {
    aiming=true; aimS=balls[0].p.copy(); aimE=new PVector(mouseX,mouseY);
  }
}
void mouseDragged(){ if(aiming) aimE.set(mouseX,mouseY); }
void mouseReleased(){
  if(aiming){
    PVector d=PVector.sub(aimS,aimE);
    float pwr=constrain(d.mag()/10,0,15);
    d.normalize().mult(pwr);
    balls[0].v.add(d);
  }
  aiming=false;
}
void keyPressed(){ if(key=='r'||key=='R') reset(); }

class Ball {
  PVector p, v; color col; boolean cue;
  Ball(float x,float y,color c,boolean isCue){ p=new PVector(x,y); v=new PVector(); col=c; cue=isCue; }
  void move(){
    p.add(v); v.mult(0.986);
    if(p.x<MARGIN+BALL_R){p.x=MARGIN+BALL_R;v.x*=-0.9;}
    if(p.x>width-MARGIN-BALL_R){p.x=width-MARGIN-BALL_R;v.x*=-0.9;}
    if(p.y<MARGIN+BALL_R){p.y=MARGIN+BALL_R;v.y*=-0.9;}
    if(p.y>height-MARGIN-BALL_R){p.y=height-MARGIN-BALL_R;v.y*=-0.9;}
  }
  void hit(Ball o){
    float d=dist(p.x,p.y,o.p.x,o.p.y);
    if(d<BALL_R*2 && d>0.01){
      PVector n=PVector.sub(o.p,p).normalize();
      float ov=BALL_R*2-d;
      p.sub(PVector.mult(n,ov*0.5)); o.p.add(PVector.mult(n,ov*0.5));
      float imp=v.dot(n)-o.v.dot(n);
      v.sub(PVector.mult(n,imp)); o.v.add(PVector.mult(n,imp));
      v.mult(0.965); o.v.mult(0.965);
    }
  }
  void show(){
    pushMatrix();
    translate(p.x, p.y, 0);
    fill(col); noStroke();
    sphereDetail(10);
    sphere(BALL_R);
    popMatrix();
  }
}
























