



























float cc=200 ;float oo=333 ;
float c=200 ;float o=222 ;





void setup() {
  size(displayWidth, displayHeight, P2D) ;
  println(displayWidth) ;
  println(displayHeight) ;
  noStroke() ;

orientation(PORTRAIT) ;

t1w1=0;

}





int t1w1=0;
void draw() {
  if( (int(random(1,11111))==9)
  ||(t1w1==0) ) 
  {t1w1=1;
  
  
  
  fill(0,0,0);rect
  (0,0,displayWidth, displayHeight) ;

float f55x55=random(0,55*55);
rectMode(CENTER);
ellipseMode(CENTER) ;
int fff=1;
for(int f=1;f<56;f++){
 for(int ff=1;ff<56;ff++){
 if(fff==1){
   fill(255,255,1);fff=2;
 }  else{
   fill(211,211,111);fff=1;
 }
  rect( 
  displayWidth /30+(f*displayWidth /60),
  displayHeight /30+(ff*displayHeight/60),
  displayWidth /60,displayHeight /60);
   
   
   if(f55x55>random(0,55*55)){
    int f1i12=int(random(-2,15)) ; 
     if(f1i12==1){  fill(205,1,11);
    rect( 
  displayWidth /30+(f*displayWidth /60),
  displayHeight /30+(ff*displayHeight/60),
  displayWidth /60,displayHeight /60);  } 
  
  
  if(f1i12==2){fill(11,1,205);rect( 
  displayWidth /30+(f*displayWidth /60),
  displayHeight /30+(ff*displayHeight/60),
  displayWidth /60,displayHeight /60);}
     
    if(f1i12==3){fill(11,1,205);rect( 
  displayWidth /30+(f*displayWidth /60),     
 displayHeight /30+(ff*displayHeight/60),
  displayWidth /60,displayHeight /60);
  fill(251,255,111); rect( 
  displayWidth /30+(f*displayWidth /60),     
 displayHeight /30+(ff*displayHeight/60),
  displayWidth /160,displayHeight /160);}
     
     
     if(f1i12==4){fill(205,1,11);rect( 
  displayWidth /30+(f*displayWidth /60),     
 displayHeight /30+(ff*displayHeight/60),
     displayWidth /60,displayHeight /60);
  fill(111,251,255); rect( 
  displayWidth /30+(f*displayWidth /60), 
     displayHeight /30+(ff*displayHeight/60),
  displayWidth /160,displayHeight /160);}
    
     if(f1i12==5){fill(11,1,205);ellipse ( 
  displayWidth /30+(f*displayWidth /60),
  displayHeight /30+(ff*displayHeight/60),
    displayWidth /60,displayHeight /60);}
    
    if(f1i12==6){fill(205,1,11);ellipse ( 
  displayWidth /30+(f*displayWidth /60),
  displayHeight /30+(ff*displayHeight/60),
    displayWidth /60,displayHeight /60);}
    
    if(f1i12==7){fill(205,1,11);triangle( 
  displayWidth /30+(f*displayWidth /60),
  displayHeight /30+(ff*displayHeight/60)
  -displayHeight /120,
   displayWidth /30+(f*displayWidth /60)
   - displayWidth /120,
  displayHeight /30+(ff*displayHeight/60)
  +displayHeight /120,
  displayWidth /30+(f*displayWidth /60)
   +displayWidth /120,
  displayHeight /30+(ff*displayHeight/60)
  +displayHeight /120  );}
    
    if(f1i12==8){fill(11,1,205);triangle( 
  displayWidth /30+(f*displayWidth /60),
  displayHeight /30+(ff*displayHeight/60)
   - displayHeight /120,
   displayWidth /30+(f*displayWidth /60)
   - displayWidth /120,
  displayHeight /30+(ff*displayHeight/60)
    +displayHeight /120,
  displayWidth /30+(f*displayWidth /60)
   +displayWidth /120,
  displayHeight /30+(ff*displayHeight/60)
    +displayHeight /120  );}
    
    if(f1i12==9){fill(11,1,205);rect ( 
  displayWidth /30+(f*displayWidth /60),
  displayHeight /30+(ff*displayHeight/60),
    displayWidth /60,displayHeight /120);
    rect ( 
  displayWidth /30+(f*displayWidth /60),
  displayHeight /30+(ff*displayHeight/60),
    displayWidth /120,displayHeight /60);
    }
    
    
    if(f1i12==10){fill(205,1,11);rect ( 
  displayWidth /30+(f*displayWidth /60),
  displayHeight /30+(ff*displayHeight/60),
    displayWidth /60,displayHeight /120);
    rect ( 
  displayWidth /30+(f*displayWidth /60),
  displayHeight /30+(ff*displayHeight/60),
    displayWidth /120,displayHeight /60);} 
    
    if(f1i12==11){fill(205,1,11);rect ( 
  displayWidth /30+(f*displayWidth /60)
  -displayWidth /240,
  displayHeight /30+(ff*displayHeight/60)
  -displayHeight /240,
    displayWidth /150,displayHeight /150);
    rect ( 
  displayWidth /30+(f*displayWidth /60)
  +displayWidth /240,
  displayHeight /30+(ff*displayHeight/60)
  +displayHeight /240,
    displayWidth /150,displayHeight /150);
    rect ( 
  displayWidth /30+(f*displayWidth /60)
  -displayWidth /240,
  displayHeight /30+(ff*displayHeight/60)
  +displayHeight /240,
    displayWidth /150,displayHeight /150);
    rect ( 
  displayWidth /30+(f*displayWidth /60)
  +displayWidth /240,
  displayHeight /30+(ff*displayHeight/60)
  -displayHeight /240,
    displayWidth /150,displayHeight /150);} 
    
    if(f1i12==12){fill(11,1,205);rect ( 
  displayWidth /30+(f*displayWidth /60)
  -displayWidth /240,
  displayHeight /30+(ff*displayHeight/60)
    -displayHeight /240,
    displayWidth /150,displayHeight /150);
    rect ( 
    displayWidth /30+(f*displayWidth /60)
  +displayWidth /240,
  displayHeight /30+(ff*displayHeight/60)
     +displayHeight /240,
    displayWidth /150,displayHeight /150);
    rect ( 
    displayWidth /30+(f*displayWidth /60)
  -displayWidth /240,
  displayHeight /30+(ff*displayHeight/60)  
     +displayHeight /240,
    displayWidth /150,displayHeight /150);
    rect ( 
    displayWidth /30+(f*displayWidth /60)
  +displayWidth /240,
  displayHeight /30+(ff*displayHeight/60)
     -displayHeight /240,
    displayWidth /150,displayHeight /150);} 
    
    
    
    
    
    
    
     
     
     
   }
   
   
   
   
   
   
   
 } 
  
  
  
  
}


























 
  
  
  
  
  
  
  


























































  
  cc=random(0,displayWidth) ;
  oo=random(0,displayWidth ) ;
  c=random(0,displayHeight) ;
  o=random(0,displayHeight) ;
  
  fill(255,0,0) ;
  ellipse(cc, c, float(
  displayWidth/55+
  displayHeight/55), 
  float(displayWidth/55+
  displayHeight/55)
  
  
  );fill(0,0,255);
  ellipse(oo,o,
  displayWidth/55+
  displayHeight/55,
  displayWidth/55+
  displayHeight/55) ;
  fill(255,111,111);
  ellipse(cc, c, 22,22);
  fill(111,111,255);
  ellipse(oo,o,22,22);
  
  
  
  
  
  
  
  
  
  
} 
}