

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import android.view.View;
import android.view.WindowManager;

String[] keyLabels = {
  "1", "2", "3",
  "4", "5", "6",
  "7", "8", "9"
};

boolean[] keyPressed = new boolean[9];
float[] keyAlpha = new float[9];

int keySize;
int startX, startY;
int gap = 18;

void setup() {
  fullScreen();
  orientation(PORTRAIT);
  
  // Hide status bar + navigation bar (immersive)
  hideSystemUI();
  
  textAlign(CENTER, CENTER);
  noStroke();
  
  // Calculate 3x3 grid size
  keySize = min(width, height) / 5;
  startX = (width - (3 * keySize + 2 * gap)) / 2;
  startY = height / 2 -int (1.5 * keySize + gap);
  
  for (int i = 0; i < 9; i++) {
    keyAlpha[i] = 180;
  }
  
  // Create notification channel (needed for Android 8+)
  createNotificationChannel();
}

void draw() {
  background(8, 12, 28);
  
  // Title
  fill(140, 200, 255);
  textSize(42);
  text("NEW AI  •  9 KEYS", width/2, 90);
  
  // Draw 9 keys
  for (int i = 0; i < 9; i++) {
    int col = i % 3;
    int row = i / 3;
    
    float x = startX + col * (keySize + gap);
    float y = startY + row * (keySize + gap);
    
    // Key background
    if (keyPressed[i]) {
      fill(80, 160, 255, 230);
    } else {
      fill(30, 60, 120, keyAlpha[i]);
    }
    
    rect(x, y, keySize, keySize, 22);
    
    // Key number
    fill(220, 240, 255);
    textSize(48);
    text(keyLabels[i], x + keySize/2, y + keySize/2);
  }
  
  // Bottom hint
  fill(150, 180, 220, 160);
  textSize(22);
  text("Tap keys 1-9  •  Key 5 = Notification", width/2, height - 70);
}

void mousePressed() {
  for (int i = 0; i < 9; i++) {
    int col = i % 3;
    int row = i / 3;
    
    float x = startX + col * (keySize + gap);
    float y = startY + row * (keySize + gap);
    
    if (mouseX > x && mouseX < x + keySize &&
        mouseY > y && mouseY < y + keySize) {
      
      keyPressed[i] = true;
      
      // Key 5 sends a system notification
      if (i == 4) {
        sendNotification("New AI", "Key 5 pressed – System notification active");
      }
    }
  }
}

void mouseReleased() {
  for (int i = 0; i < 9; i++) {
    keyPressed[i] = false;
  }
}

// ========== SYSTEM UI (Status Bar) ==========
void hideSystemUI() {
  View decorView = getActivity().getWindow().getDecorView();
  decorView.setSystemUiVisibility(
    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
    | View.SYSTEM_UI_FLAG_FULLSCREEN
    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
  );
  
  getActivity().getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
}

// ========== NOTIFICATION ==========
void createNotificationChannel() {
  if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
    NotificationChannel channel = new NotificationChannel(
      "new_ai_channel",
      "New AI Channel",
      NotificationManager.IMPORTANCE_DEFAULT
    );
    channel.setDescription("Notifications from New AI app");
    
    NotificationManager manager = getActivity().getSystemService(NotificationManager.class);
    manager.createNotificationChannel(channel);
  }
}

void sendNotification(String title, String message) {
  NotificationManager manager = getActivity().getSystemService(NotificationManager.class);
  
  Intent intent = new Intent(getActivity(), getActivity().getClass());
  PendingIntent pendingIntent = PendingIntent.getActivity(
    getActivity(), 0, intent,
    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
  );
  
  Notification.Builder builder;
  
  if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
    builder = new Notification.Builder(getActivity(), "new_ai_channel");
  } else {
  //  
builder = new Notification.Builder(getActivity(), "err" );
  }
  
  builder.setContentTitle(title)
         .setContentText(message)
         .setSmallIcon(android.R.drawable.ic_dialog_info)
         .setContentIntent(pendingIntent)
         .setAutoCancel(true);
  
  manager.notify(1, builder.build());
}



























