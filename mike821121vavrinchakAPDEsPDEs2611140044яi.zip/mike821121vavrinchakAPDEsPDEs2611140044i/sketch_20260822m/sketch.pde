


// APDE Chess – Human vs Engine
// Depth rises in endgame, shows PV + arrows

int SQ = 0;
int BOARD_X, BOARD_Y;
int[] board = new int[64];          // 0=empty, 1-6 white, 7-12 black
int side = 0;                       // 0=white (human), 1=black (engine)
boolean thinking = false;
String pvLine = "";
String info = "Your move (White)";
int bestFrom = -1, bestTo = -1;
int[] pvFrom = new int[32];
int[] pvTo   = new int[32];
int pvLen = 0;

int nodes;
long startTime;

// Piece values
int[] val = {0,100,320,330,500,900,20000};

// Directions
int[] knight = {-17,-15,-10,-6,6,10,15,17};
int[] king   = {-9,-8,-7,-1,1,7,8,9};
int[] bishop = {-9,-7,7,9};
int[] rook   = {-8,-1,1,8};

void setup() {
  size(displayWidth, displayHeight);
  orientation(PORTRAIT);
  textAlign(CENTER, CENTER);
  textSize(18);
  
  SQ = min(width, height-180) / 8;
  BOARD_X = (width - SQ*8) / 2;
  BOARD_Y = 40;
  
  startPos();
}

void startPos() {
  // Standard starting position (simple array)
  int[] start = {
    10,8,9,11,12,9,8,10,
    7,7,7,7,7,7,7,7,
    0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,
    1,1,1,1,1,1,1,1,
    4,2,3,5,6,3,2,4
  };
  for (int i=0; i<64; i++) board[i] = start[i];
  side = 0;
  thinking = false;
  info = "Your move (White)";
  pvLine = "";
  bestFrom = bestTo = -1;
  pvLen = 0;
}

void draw() {
  background(30, 30, 40);
  
  drawBoard();
  drawPieces();
  drawArrows();
  drawInfo();
  
  if (thinking) {
    // engine move is calculated in mouseReleased / after human move
  }
}

void drawBoard() {
  for (int r=0; r<8; r++) {
    for (int f=0; f<8; f++) {
      boolean light = (r+f) % 2 == 0;
      fill(light ? color(240,217,181) 
    : color(181,136,99));
      noStroke();
      rect(BOARD_X + f*SQ, BOARD_Y + r*SQ, SQ, SQ);
    }
  }
  // coordinates
  fill(200);
  textSize(14+22);
  for (int i=0; i<8; i++) {
    text("abcdefgh".charAt(i), BOARD_X + i*SQ + SQ/2, BOARD_Y + 8*SQ + 14);
    text(8-i, BOARD_X - 14, BOARD_Y + i*SQ + SQ/2);
  }
}

void drawPieces() {
  textSize(SQ * 0.7);
  for (int i=0; i<64; i++) {
    if (board[i] == 0) continue;
    int f = i % 8, r = i / 8;
    float x = BOARD_X + f*SQ + SQ/2;
    float y = BOARD_Y + r*SQ + SQ/2;
    
    String s = "";
    switch(board[i]) {
      case 1: s="♙"; break; case 2: s="♘"; break; case 3: s="♗"; break;
      case 4: s="♖"; break; case 5: s="♕"; break; case 6: s="♔"; break;
      case 7: s="♟"; break; case 8: s="♞"; break; case 9: s="♝"; break;
      case 10:s="♜"; break; case 11:s="♛"; break; case 12:s="♚"; break;
    }
    fill(board[i] <= 6 ? 255 : 20);
    text(s, x, y);
  }
}

void drawArrows() {
  if (bestFrom < 0) return;
  strokeWeight(5);
  stroke(0, 180, 255, 200);
  drawArrow(bestFrom, bestTo);
  
  // PV arrows (thinner)
  strokeWeight(3);
  stroke(0, 255, 100, 160);
  for (int i=0; i<pvLen-1 && i<4; i++) {
    drawArrow(pvFrom[i], pvTo[i]);
  }
}

void drawArrow(int from, int to) {
  int ff = from%8, fr = from/8;
  int tf = to%8,   tr = to/8;
  float x1 = BOARD_X + ff*SQ + SQ/2;
  float y1 = BOARD_Y + fr*SQ + SQ/2;
  float x2 = BOARD_X + tf*SQ + SQ/2;
  float y2 = BOARD_Y + tr*SQ + SQ/2;
  
  line(x1, y1, x2, y2);
  // simple arrow head
  float a = atan2(y2-y1, x2-x1);
  line(x2, y2, x2 - 12*cos(a-0.4), y2 - 12*sin(a-0.4));
  line(x2, y2, x2 - 12*cos(a+0.4), y2 - 12*sin(a+0.4));
}

void drawInfo() {
  fill(40, 40, 55);
  rect(0, BOARD_Y + 8*SQ + 30, width, height - (BOARD_Y + 8*SQ + 30));
  
  fill(255);
  textSize(18 +22);
  textAlign(LEFT, TOP);
  text(info, 20, BOARD_Y + 8*SQ + 45  +22);
  
  textSize(15+22);
  fill(180, 255, 180);
  text("PV: " + pvLine, 20+22, BOARD_Y + 8*SQ + 75  +22 +52);
  
  fill(200);
  text("Tap piece then destination  |  Engine depth rises in endgame", 20, BOARD_Y + 8*SQ + 105);
  textAlign(CENTER, CENTER);
}

// ---------- Human move ----------
int selected = -1;

void mousePressed() {
  if (thinking || side != 0) return;
  
  int f = (mouseX - BOARD_X) / SQ;
  int r = (mouseY - BOARD_Y) / SQ;
  if (f<0 || f>7 || r<0 || r>7) return;
  int sq = r*8 + f;
  
  if (selected == -1) {
    if (board[sq] >= 1 && board[sq] <= 6) {   // white piece
      selected = sq;
    }
  } else {
    if (sq == selected) {
      selected = -1;
      return;
    }
    // try move
    if (isLegal(selected, sq, 0)) {
      makeMove(selected, sq);
      selected = -1;
      side = 1;
      info = "Engine thinking...";
      thinking = true;
      // run engine on next frame
    } else {
      if (board[sq] >= 1 && board[sq] <= 6) selected = sq;
      else selected = -1;
    }
  }
}

void mouseReleased() {
  if (thinking && side == 1) {
    // engine move
    int maxDepth = countPieces() <= 10 ? 12 : (countPieces() <= 6 ? 15 : 7);
    int[] move = search(maxDepth);
    if (move[0] >= 0) {
      makeMove(move[0], move[1]);
      bestFrom = move[0];
      bestTo   = move[1];
    }
    side = 0;
    thinking = false;
    info = "Your move (White)  – depth used: " + maxDepth;
  }
}

// ---------- Engine (simple alpha-beta) ----------
int[] search(int depth) {
  nodes = 0;
  startTime = millis();
  int bestScore = -999999;
  int bf = -1, bt = -1;
  pvLen = 0;
  
  ArrayList<int[]> moves = genMoves(1);   // black to move
  for (int[] m : moves) {
    int old = board[m[1]];
    board[m[1]] = board[m[0]];
    board[m[0]] = 0;
    
    int score = -alphaBeta(depth-1, -999999, 999999, 0);
    
    board[m[0]] = board[m[1]];
    board[m[1]] = old;
    
    if (score > bestScore) {
      bestScore = score;
      bf = m[0]; bt = m[1];
    }
  }
  
  // build simple PV (just the best move for now)
  pvLine = sqName(bf) + sqName(bt) + "  (" + bestScore + ")";
  pvFrom[0] = bf; pvTo[0] = bt; pvLen = 1;
  
  return new int[]{bf, bt};
}

int alphaBeta(int depth, int alpha, int beta, int s) {
  nodes++;
  if (depth == 0) return evaluate(s);
  
  ArrayList<int[]> moves = genMoves(s);
  if (moves.isEmpty()) return evaluate(s);  // no mates detection for simplicity
  
  for (int[] m : moves) {
    int old = board[m[1]];
    board[m[1]] = board[m[0]];
    board[m[0]] = 0;
    
    int score = -alphaBeta(depth-1, -beta, -alpha, 1-s);
    
    board[m[0]] = board[m[1]];
    board[m[1]] = old;
    
    if (score >= beta) return beta;
    if (score > alpha) alpha = score;
  }
  return alpha;
}

int evaluate(int s) {
  int score = 0;
  for (int i=0; i<64; i++) {
    int p = board[i];
    if (p == 0) continue;
    int v = val[p > 6 ? p-6 : p];
    if (p <= 6) score += v; else score -= v;
  }
  return (s == 0) ? score : -score;
}

int countPieces() {
  int c = 0;
  for (int i=0; i<64; i++) if (board[i] != 0) c++;
  return c;
}

// very simplified legal move generator (enough for demo)
ArrayList<int[]> genMoves(int s) {
  ArrayList<int[]> list = new ArrayList<int[]>();
  int minP = (s==0) ? 1 : 7;
  int maxP = (s==0) ? 6 : 12;
  
  for (int from=0; from<64; from++) {
    int p = board[from];
    if (p < minP || p > maxP) continue;
    
    int type = (p > 6) ? p-6 : p;
    
    if (type == 1) { // pawn
      int dir = (s==0) ? -8 : 8;
      int to = from + dir;
      if (to>=0 && to<64 && board[to]==0) list.add(new int[]{from,to});
      // captures
      for (int d : new int[]{dir-1, dir+1}) {
        to = from + d;
        if (to>=0 && to<64 && abs((to%8)-(from%8))==1) {
          int t = board[to];
          if (t != 0 && ((s==0 && t>6) || (s==1 && t<=6))) list.add(new int[]{from,to});
        }
      }
    }
    else if (type == 2) { // knight
      for (int d : knight) {
        int to = from + d;
        if (to<0||to>63) continue;
        if (abs((to%8)-(from%8)) > 2) continue;
        int t = board[to];
        if (t==0 || ((s==0&&t>6)||(s==1&&t<=6))) list.add(new int[]{from,to});
      }
    }
    else if (type == 6) { // king
      for (int d : king) {
        int to = from + d;
        if (to<0||to>63) continue;
        if (abs((to%8)-(from%8)) > 1) continue;
        int t = board[to];
        if (t==0 || ((s==0&&t>6)||(s==1&&t<=6))) list.add(new int[]{from,to});
      }
    }
    else { // sliding
      int[] dirs = (type==3) ? bishop : (type==4) ? rook : new int[]{-9,-8,-7,-1,1,7,8,9};
      for (int d : dirs) {
        int to = from;
        while (true) {
          to += d;
          if (to<0||to>63) break;
          if (abs((to%8)-((to-d)%8)) > 1 && (d==1||d==-1||abs(d)==7||abs(d)==9)) break;
          int t = board[to];
          if (t==0) list.add(new int[]{from,to});
          else {
            if ((s==0&&t>6)||(s==1&&t<=6)) list.add(new int[]{from,to});
            break;
          }
        }
      }
    }
  }
  return list;
}

boolean isLegal(int from, int to, int s) {
  ArrayList<int[]> moves = genMoves(s);
  for (int[] m : moves) if (m[0]==from && m[1]==to) return true;
  return false;
}

void makeMove(int from, int to) {
  board[to] = board[from];
  board[from] = 0;
}

String sqName(int sq) {
  if (sq < 0) return "";
  return "" + "abcdefgh".charAt(sq%8) + (8 - sq/8);
}






















