










// TURTLES TOURNAMENT 4 INSPIRED FIGHTER PROTOTYPE
// Processing (Java Mode) - Desktop Application

// Fighter properties
class Fighter {
  float x, y;
  float width, height;
  float health;
  float speed = 5;
  float jumpPower = 10;
  float yVelocity = 0;
  boolean isJumping = false;
  boolean onGround = true;
  
  Fighter(float x, float y, float w, float h) {
    this.x = x;
    this.y = y;
    this.width = w;
    this.height = h;
    this.health = 100;
  }
  
  void update() {
    // Gravity
    if (!onGround) {
      yVelocity += 0.5;  // Gravity
      y += yVelocity;
      
      // Ground collision
      if (y >= height - 50) {
        y = height - 50;
        yVelocity = 0;
        isJumping = false;
        onGround = true;
      }
    }
  }
  
  void jump() {
    if (onGround) {
      isJumping = true;
      onGround = false;
      yVelocity = jumpPower;
    }
  }
  
  void move(String direction) {
    if (direction == "left" && x > 50) {
      x -= speed;
    } 
    if (direction == "right" && x < width - width - 50) {
      x += speed;
    }
  }
  
  void display() {
    fill(255);
    stroke(0);
    rect(x, y, width, height);
    fill(0, 0, 255, 150);  // Blue body
    rect(x + width/4, y + height/4, width/2, height/2);
    fill(255, 0, 0);      // Red head
    ellipse(x + width/2, y + height/4, 20, 20);
  }
}

// Game setup
Fighter player1, player2;

void setup() {


  ///size(800, 600);

  size(displayWidth, displayHeight, P2D) ;


  // Create fighters
  player1 = new Fighter(150, height - 100, 80, 50);
  player2 = new Fighter(650, height - 100, 80, 50);
}

void draw() {
  background(0, 150, 0);  // Green background
  
  // Draw ground
  fill(100, 50, 0);
  rect(0, height - 50, width, 50);
  
  // Update and display fighters
  player1.update();
  player2.update();
  
  player1.display();
  player2.display();
  
  // Display health bars
  fill(255, 0, 0);
  rect(player1.x, 10, player1.health, 20);
  rect(player2.x + player2.width + 20, 10, player2.health, 20);
  
  // Display instructions
  fill(255);
  textSize(16+19);
  text("P1: Left/Right Arrow - Move | Space - Jump", 10, 30);
  text("P2: A/D - Move | S - Jump", 400, 30+99);
}

// Input handling
void keyPressed() {
  // Player 1 controls (arrow keys)
  if (keyCode == LEFT) {
    player1.move("left");
  } 
  if (keyCode == RIGHT) {
    player1.move("right");
  } 
  if (key == ' ') {
    player1.jump();
  }
  
  // Player 2 controls (A/D keys)
  if (key == 'a') {
    player2.move("left");
  } 
  if (key == 'd') {
    player2.move("right");
  } 
  if (key == 's') {
    player2.jump();
  }
}






















