



////SEE///ok////ok////////


/*
  SMALL UCI CHESS ENGINE
  Processing / APDE 0.5.3

  No external libraries.

  UCI commands supported:
    uci
    isready
    ucinewgame
    position startpos
    position startpos moves e2e4 e7e5
    go depth 3
    stop
    quit

  Processing UI:
    Touch/click a piece, then touch/click destination.
*/

int[] board = new int[64];

boolean whiteTurn = true;
boolean engineThinking = false;
boolean engineIsWhite = false;

int selected = -1;

String lastMove = "";

int searchDepth = 3;

int[] pieceValue = {
  0,
  100, 320, 330, 500, 900, 20000,
  -100, -320, -330, -500, -900, -20000
};

// ------------------------------------------------------------
// PROCESSING
// ------------------------------------------------------------

void setup() {
  fullScreen(P2D);

  textAlign(CENTER, CENTER);
  rectMode(CORNER);

  newGame();

  println("Small APDE Chess Engine");
  println("UCI ready");
}

void draw() {
  background(35);

  drawBoard();
  drawPieces();

  if (engineThinking) {
    fill(255);
    textSize(30);
    text("ENGINE THINKING...", width/2, height - 50);
  }
}

void drawBoard() {

  float s = min(width, height - 80) / 8.0;

  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {

      int sq = y * 8 + x;

      if ((x + y) % 2 == 0)
        fill(230, 210, 170);
      else
        fill(110, 80, 50);

      rect(x*s, y*s, s, s);

      if (sq == selected) {
        noFill();
        stroke(255, 0, 0);
        strokeWeight(5);
        rect(x*s+3, y*s+3, s-6, s-6);
        noStroke();
      }
    }
  }
}

void drawPieces() {

  float s = min(width, height - 80) / 8.0;

  textSize(s * 0.65);

  for (int sq = 0; sq < 64; sq++) {

    int p = board[sq];

    if (p == 0)
      continue;

    int x = sq % 8;
    int y = sq / 8;

    fill(p > 0 ? 255 : 20);

    text(pieceChar(p),
         x*s + s/2,
         y*s + s/2);
  }
}

String pieceChar(int p) {

  if (p == 1)  return "P";
  if (p == 2)  return "N";
  if (p == 3)  return "B";
  if (p == 4)  return "R";
  if (p == 5)  return "Q";
  if (p == 6)  return "K";

  if (p == -1) return "p";
  if (p == -2) return "n";
  if (p == -3) return "b";
  if (p == -4) return "r";
  if (p == -5) return "q";
  if (p == -6) return "k";

  return "";
}

void mousePressed() {

  float s = min(width, height - 80) / 8.0;

  if (mouseY >= 8*s)
    return;

  int x = int(mouseX / s);
  int y = int(mouseY / s);

  if (x < 0 || x > 7 || y < 0 || y > 7)
    return;

  int sq = y * 8 + x;

  if (selected == -1) {

    if (board[sq] != 0 &&
        ((whiteTurn && board[sq] > 0) ||
         (!whiteTurn && board[sq] < 0))) {

      selected = sq;
    }

  } else {

    if (selected != sq) {

      if (legalMove(selected, sq)) {

        makeMove(selected, sq);

        lastMove =
          squareName(selected) +
          squareName(sq);

        selected = -1;

        if (!whiteTurn && !engineThinking) {
          engineMove();
        }

      } else {

        selected = -1;
      }

    } else {
      selected = -1;
    }
  }
}

// ------------------------------------------------------------
// NEW GAME
// ------------------------------------------------------------

void newGame() {

  for (int i = 0; i < 64; i++)
    board[i] = 0;

  // Black
  board[0] = -4;
  board[1] = -2;
  board[2] = -3;
  board[3] = -5;
  board[4] = -6;
  board[5] = -3;
  board[6] = -2;
  board[7] = -4;

  for (int i = 8; i < 16; i++)
    board[i] = -1;

  // White
  board[56] = 4;
  board[57] = 2;
  board[58] = 3;
  board[59] = 5;
  board[60] = 6;
  board[61] = 3;
  board[62] = 2;
  board[63] = 4;

  for (int i = 48; i < 56; i++)
    board[i] = 1;

  whiteTurn = true;
  selected = -1;
  lastMove = "";
}

// ------------------------------------------------------------
// MOVE
// ------------------------------------------------------------

boolean legalMove(int from, int to) {

  int p = board[from];

  if (p == 0)
    return false;

  if (whiteTurn && p < 0)
    return false;

  if (!whiteTurn && p > 0)
    return false;

  if (board[to] != 0) {

    if ((p > 0 && board[to] > 0) ||
        (p < 0 && board[to] < 0))
      return false;
  }

  return pieceCanMove(from, to, p);
}

boolean pieceCanMove(int from, int to, int p) {

  int fx = from % 8;
  int fy = from / 8;

  int tx = to % 8;
  int ty = to / 8;

  int dx = tx - fx;
  int dy = ty - fy;

  int adx = abs(dx);
  int ady = abs(dy);

  int color = p > 0 ? 1 : -1;

  // PAWN
  if (abs(p) == 1) {

    int dir = color == 1 ? -1 : 1;

    if (dx == 0 && dy == dir && board[to] == 0)
      return true;

    if (dx == 0 &&
        dy == 2*dir &&
        ((color == 1 && fy == 6) ||
         (color == -1 && fy == 1))) {

      int mid = from + dir*8;

      if (board[mid] == 0 && board[to] == 0)
        return true;
    }

    if (adx == 1 &&
        dy == dir &&
        board[to] != 0)
      return true;

    return false;
  }

  // KNIGHT
  if (abs(p) == 2) {

    return (adx == 1 && ady == 2) ||
           (adx == 2 && ady == 1);
  }

  // KING
  if (abs(p) == 6) {

    return adx <= 1 && ady <= 1;
  }

  // BISHOP
  if (abs(p) == 3) {

    if (adx != ady)
      return false;

    return clearLine(from, to);
  }

  // ROOK
  if (abs(p) == 4) {

    if (dx != 0 && dy != 0)
      return false;

    return clearLine(from, to);
  }

  // QUEEN
  if (abs(p) == 5) {

    if (dx == 0 || dy == 0 ||
        adx == ady)
      return clearLine(from, to);

    return false;
  }

  return false;
}

// ------------------------------------------------------------
// LINE TEST
// ------------------------------------------------------------

boolean clearLine(int from, int to) {

  int fx = from % 8;
  int fy = from / 8;

  int tx = to % 8;
  int ty = to / 8;

  int sx = Integer.signum(tx - fx);
  int sy = Integer.signum(ty - fy);

  int x = fx + sx;
  int y = fy + sy;

  while (x != tx || y != ty) {

    int sq = y*8 + x;

    if (board[sq] != 0)
      return false;

    x += sx;
    y += sy;
  }

  return true;
}

// ------------------------------------------------------------
// MAKE MOVE
// ------------------------------------------------------------

void makeMove(int from, int to) {

  board[to] = board[from];
  board[from] = 0;

  // simple promotion
  int p = board[to];

  if (p == 1 && to/8 == 0)
    board[to] = 5;

  if (p == -1 && to/8 == 7)
    board[to] = -5;

  whiteTurn = !whiteTurn;
}

// ------------------------------------------------------------
// ENGINE
// ------------------------------------------------------------

void engineMove() {

  engineThinking = true;

  int bestFrom = -1;
  int bestTo = -1;

  int bestScore = -999999;

  for (int from = 0; from < 64; from++) {

    if (board[from] >= 0)
      continue;

    for (int to = 0; to < 64; to++) {

      if (!pieceCanMove(from, to, board[from]))
        continue;

      if (board[to] < 0)
        continue;

      int captured = board[to];

      board[to] = board[from];
      board[from] = 0;

      int score =
        -search(searchDepth - 1,
                -1000000,
                1000000,
                true);

      board[from] = board[to];
      board[to] = captured;

      if (score > bestScore) {

        bestScore = score;

        bestFrom = from;
        bestTo = to;
      }
    }
  }

  if (bestFrom != -1) {

    makeMove(bestFrom, bestTo);

    lastMove =
      squareName(bestFrom) +
      squareName(bestTo);

    println("bestmove " + lastMove);
  }

  engineThinking = false;
}

// ------------------------------------------------------------
// ALPHA BETA
// ------------------------------------------------------------

int search(int depth,
           int alpha,
           int beta,
           boolean white) {

  if (depth <= 0)
    return evaluate();

  int best = -999999;

  boolean found = false;

  for (int from = 0; from < 64; from++) {

    int p = board[from];

    if (p == 0)
      continue;

    if (white && p < 0)
      continue;

    if (!white && p > 0)
      continue;

    for (int to = 0; to < 64; to++) {

      if (!pieceCanMove(from, to, p))
        continue;

      if (board[to] != 0 &&
          ((p > 0 && board[to] > 0) ||
           (p < 0 && board[to] < 0)))
        continue;

      found = true;

      int captured = board[to];

      board[to] = board[from];
      board[from] = 0;

      int score =
        -search(depth - 1,
                -beta,
                -alpha,
                !white);

      board[from] = board[to];
      board[to] = captured;

      if (score > best)
        best = score;

      if (score > alpha)
        alpha = score;

      if (alpha >= beta)
        return alpha;
    }
  }

  if (!found)
    return evaluate();

  return best;
}

// ------------------------------------------------------------
// EVALUATION
// ------------------------------------------------------------

int evaluate() {

  int score = 0;

  for (int i = 0; i < 64; i++) {

    int p = board[i];

    if (p == 0)
      continue;

    score += pieceValue[p > 0 ? p : 6-p];
  }

  return score;
}

// ------------------------------------------------------------
// UCI
// ------------------------------------------------------------

void uci(String command) {

  command = trim(command);

  println("UCI COMMAND: " + command);

  if (command.equals("uci")) {

    println("id name SmallAPDE");
    println("id author APDE");
    println("uciok");
    return;
  }

  if (command.equals("isready")) {

    println("readyok");
    return;
  }

  if (command.equals("ucinewgame")) {

    newGame();
    return;
  }

  if (command.equals("position startpos")) {

    newGame();
    return;
  }

  if (command.startsWith("position startpos moves")) {

    newGame();

    String[] a = split(command, ' ');

    for (int i = 3; i < a.length; i++) {

      if (a[i].length() >= 4) {

        int from =
          parseSquare(a[i].substring(0,2));

        int to =
          parseSquare(a[i].substring(2,4));

        if (from >= 0 && to >= 0) {

          board[to] = board[from];
          board[from] = 0;

          whiteTurn = !whiteTurn;
        }
      }
    }

    return;
  }

  if (command.startsWith("go")) {

    int d = 3;

    String[] a = split(command, ' ');

    for (int i = 0; i < a.length-1; i++) {

      if (a[i].equals("depth"))
        d = int(a[i+1]);
    }

    searchDepth = constrain(d, 1, 5);

    if (!whiteTurn)
      engineMove();

    return;
  }

  if (command.equals("stop")) {

    engineThinking = false;
    return;
  }

  if (command.equals("quit")) {

    println("quit");
    return;
  }
}

// ------------------------------------------------------------
// SQUARE CONVERSION
// ------------------------------------------------------------

String squareName(int sq) {

  int x = sq % 8;
  int y = sq / 8;

  char file = char('a' + x);
  char rank = char('8' - y);

  return "" + file + rank;
}

int parseSquare(String s) {

  if (s.length() != 2)
    return -1;

  int x = s.charAt(0) - 'a';
  int y = '8' - s.charAt(1);

  if (x < 0 || x > 7 ||
      y < 0 || y > 7)
    return -1;

  return y*8 + x;
}

// ------------------------------------------------------------
// TEST UCI COMMANDS
// ------------------------------------------------------------

void keyPressed() {

  if (key == '1')
    uci("uci");

  if (key == '2')
    uci("isready");

  if (key == '3')
    uci("ucinewgame");

  if (key == '4')
    uci("position startpos");

  if (key == '5')
    uci("position startpos moves e2e4 e7e5");

  if (key == '6')
    uci("go depth 3");
}








/////SEE/////














