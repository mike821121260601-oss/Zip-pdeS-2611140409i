



// ============================================================
// NEW FONT LABORATORY
// APDE / Processing
//
// NO HEX DISPLAY
// DECIMAL CHARACTER NUMBERS
//
// Touch a small character -> large view
// LEFT / RIGHT -> previous / next page
// UP / DOWN -> change selected character
// ============================================================

import android.graphics.Paint;
import android.graphics.Typeface;

Paint sysFont;

int selected = 9812;     // ♔
int pageStart = 9600;

int cellW = 100;
int cellH = 95;

boolean showOnlyGlyphs = true;

void setup() {
  fullScreen();

  sysFont = new Paint();
  sysFont.setTypeface(
    Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
  );
  sysFont.setTextAlign(Paint.Align.CENTER);
  sysFont.setTextSize(55);

  textAlign(CENTER, CENTER);
}

void draw() {
  background(18);

  drawHeader();
  drawCharacterGrid();
  drawBigCharacter();
}

// ------------------------------------------------------------
// HEADER
// ------------------------------------------------------------

void drawHeader() {

  fill(255);
  textSize(22);

  text(
    "NEW FONT LABORATORY",
    width / 2,
    25
  );

  textSize(16);

  text(
    "DECIMAL CHARACTER NUMBER: " + selected,
    width / 2,
    52
  );
}

// ------------------------------------------------------------
// SMALL CHARACTER GRID
// ------------------------------------------------------------

void drawCharacterGrid() {

  int top = 70;

  int cols = max(1, width / cellW);
  int rows = max(1, (height - 300) / cellH);

  int count = cols * rows;

  for (int i = 0; i < count; i++) {

    int c = pageStart + i;

    if (c > 0x10FFFF) break;

    int col = i % cols;
    int row = i / cols;

    float x = col * cellW + cellW / 2;
    float y = top + row * cellH + cellH / 2;

    boolean glyph = hasGlyph(c);

    stroke(65);
    noFill();

    if (c == selected) {
      stroke(255);
      strokeWeight(3);
    } else {
      strokeWeight(1);
    }

    rectMode(CENTER);
    rect(
      x,
      y,
      cellW - 4,
      cellH - 4
    );

    strokeWeight(1);

    if (glyph) {

      fill(255);

      textSize(42);

      text(
        charString(c),
        x,
        y - 10
      );

    } else {

      fill(80);

      textSize(13);

      text(
        "NO CHARACTER",
        x,
        y - 10
      );
    }

    // DECIMAL NUMBER
    fill(180);

    textSize(13);

    text(
      "" + c,
      x,
      y + 28
    );
  }
}

// ------------------------------------------------------------
// LARGE CHARACTER
// ------------------------------------------------------------

void drawBigCharacter() {

  float y = height - 125;

  stroke(100);
  line(
    0,
    height - 230,
    width,
    height - 230
  );

  boolean glyph = hasGlyph(selected);

  if (glyph) {

    fill(255);

    textSize(120);

    text(
      charString(selected),
      width / 2,
      y
    );

  } else {

    fill(100);

    textSize(35);

    text(
      "NO GLYPH",
      width / 2,
      y
    );
  }

  fill(220);

  textSize(18);

  text(
    "CHARACTER NUMBER = " + selected,
    width / 2,
    height - 55
  );

  fill(150);

  textSize(15);

  text(
    "Touch character | LEFT/RIGHT page | UP/DOWN select",
    width / 2,
    height - 28
  );
}

// ------------------------------------------------------------
// CHECK SYSTEM FONT
// ------------------------------------------------------------

boolean hasGlyph(int c) {

  String s = charString(c);

  if (s.length() == 0)
    return false;

  try {

    return sysFont.hasGlyph(s);

  } catch(Exception e) {

    return false;
  }
}

// ------------------------------------------------------------
// NUMBER -> CHARACTER
// ------------------------------------------------------------

String charString(int c) {

  try {

    return new String(
      Character.toChars(c)
    );

  } catch(Exception e) {

    return "";
  }
}

// ------------------------------------------------------------
// TOUCH
// ------------------------------------------------------------

void mousePressed() {

  int top = 70;

  int cols = max(1, width / cellW);

  int col = (int)(mouseX / cellW);

  int row = (int)((mouseY - top) / cellH);

  if (col < 0 || col >= cols)
    return;

  if (row < 0)
    return;

  int c =
    pageStart +
    row * cols +
    col;

  if (c >= 0 && c <= 0x10FFFF) {

    selected = c;
  }
}

// ------------------------------------------------------------
// KEYBOARD
// ------------------------------------------------------------

void keyPressed() {

  int cols = max(1, width / cellW);
  int rows = max(1, (height - 300) / cellH);

  int page = cols * rows;

  // NEXT PAGE
  if (keyCode == RIGHT) {

    pageStart += page;

    if (pageStart > 0x10FFFF)
      pageStart = 0;
  }

  // PREVIOUS PAGE
  if (keyCode == LEFT) {

    pageStart -= page;

    if (pageStart < 0)
      pageStart = 0;
  }

  // SELECT PREVIOUS
  if (keyCode == UP) {

    selected--;

    if (selected < 0)
      selected = 0;
  }

  // SELECT NEXT
  if (keyCode == DOWN) {

    selected++;

    if (selected > 0x10FFFF)
      selected = 0;
  }

  // CHESS CHARACTERS
  if (key == 'c' || key == 'C') {

    pageStart = 0x2654;
    selected = 0x2654;
  }
}
























