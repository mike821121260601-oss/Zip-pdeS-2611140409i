


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Environment;
import android.util.DisplayMetrics;
import android.view.Surface;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;

import java.io.File;

Activity activity;

MediaProjectionManager projectionManager;
MediaProjection mediaProjection;
VirtualDisplay virtualDisplay;
MediaRecorder mediaRecorder;

int REQUEST_CODE = 9999;

boolean recording = false;

int screenWidth;
int screenHeight;
int screenDensity;

String videoFile;


// --------------------------------------------------
// SETUP
// --------------------------------------------------

void setup() {

  orientation(PORTRAIT);

  activity = getActivity();

  DisplayMetrics dm = new DisplayMetrics();
  activity.getWindowManager()
          .getDefaultDisplay()
          .getRealMetrics(dm);

  screenWidth  = dm.widthPixels;
  screenHeight = dm.heightPixels;
  screenDensity = dm.densityDpi;

  background(0);

  textAlign(CENTER, CENTER);
  textSize(35);

  projectionManager =
    (MediaProjectionManager)
    activity.getSystemService(
    Context.MEDIA_PROJECTION_SERVICE);

  println("SCREEN = " +
          screenWidth + " x " +
          screenHeight);

  println("PRESS SCREEN TO START");

}


// --------------------------------------------------
// DRAW
// --------------------------------------------------

void draw() {

  background(20);

  fill(255);

  if (!recording) {

    text("TOUCH TO RECORD", width/2, height/2);

  } else {

    text("RECORDING...", width/2, height/2);

  }

}


// --------------------------------------------------
// TOUCH
// --------------------------------------------------

void mousePressed() {

  if (!recording) {

    startScreenPermission();

  }

}


// --------------------------------------------------
// ASK ANDROID FOR SCREEN CAPTURE PERMISSION
// --------------------------------------------------

void startScreenPermission() {

  Intent intent =
    projectionManager.createScreenCaptureIntent();

  activity.startActivityForResult(
    intent,
    REQUEST_CODE
  );

}


// --------------------------------------------------
// RESULT FROM ANDROID SCREEN CAPTURE DIALOG
// --------------------------------------------------

@Override
public void onActivityResult(
  int requestCode,
  int resultCode,
  Intent data) {

  super.onActivityResult(
    requestCode,
    resultCode,
    data
  );

  if (requestCode == REQUEST_CODE) {

    if (resultCode == Activity.RESULT_OK) {

      mediaProjection =
        projectionManager.getMediaProjection(
        resultCode,
        data
      );

      startRecording();

    } else {

      println("SCREEN RECORDING DENIED");

    }

  }

}


// --------------------------------------------------
// START RECORDING
// --------------------------------------------------

void startRecording() {

  try {

    recording = true;

    // --------------------------------------------
    // FILE
    // --------------------------------------------

    File movieFolder =
      Environment.getExternalStoragePublicDirectory(
      Environment.DIRECTORY_MOVIES
    );

    if (!movieFolder.exists()) {
      movieFolder.mkdirs();
    }

    videoFile =
      new File(
      movieFolder,
      "APDE_SCREEN_5_SECONDS_" +
      System.currentTimeMillis() +
      ".mp4"
      ).getAbsolutePath();

    println("VIDEO FILE:");
    println(videoFile);


    // --------------------------------------------
    // MEDIA RECORDER
    // --------------------------------------------

    mediaRecorder =
      new MediaRecorder();

    mediaRecorder.setVideoSource(
      MediaRecorder.VideoSource.SURFACE
    );

    mediaRecorder.setOutputFormat(
      MediaRecorder.OutputFormat.MPEG_4
    );

    mediaRecorder.setVideoEncoder(
      MediaRecorder.VideoEncoder.H264
    );

    mediaRecorder.setVideoEncodingBitRate(
      8000000
    );

    mediaRecorder.setVideoFrameRate(
      30
    );

    mediaRecorder.setVideoSize(
      screenWidth,
      screenHeight
    );

    mediaRecorder.setOutputFile(
      videoFile
    );

    mediaRecorder.prepare();


    // --------------------------------------------
    // SURFACE
    // --------------------------------------------

    Surface surface =
      mediaRecorder.getSurface();


    // --------------------------------------------
    // VIRTUAL DISPLAY
    // --------------------------------------------

    virtualDisplay =
      mediaProjection.createVirtualDisplay(
      "APDE_SCREEN_RECORD",
      screenWidth,
      screenHeight,
      screenDensity,
      DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
      surface,
      null,
      null
    );


    // --------------------------------------------
    // START
    // --------------------------------------------

    mediaRecorder.start();

    println("RECORDING STARTED");

    // EXACTLY 5 SECONDS

    new Thread(
      new Runnable() {

        public void run() {

          try {

            Thread.sleep(5000);

          } catch(Exception e) {

          }

          activity.runOnUiThread(
            new Runnable() {

              public void run() {

                stopRecording();

              }

            }
          );

        }

      }
    ).start();


  } catch(Exception e) {

    println("RECORD ERROR:");
    println(e);

    recording = false;

  }

}


// --------------------------------------------------
// STOP RECORDING
// --------------------------------------------------

void stopRecording() {

  if (!recording) {
    return;
  }

  recording = false;


  try {

    if (mediaRecorder != null) {

      mediaRecorder.stop();
      mediaRecorder.reset();
      mediaRecorder.release();

      mediaRecorder = null;

    }

  } catch(Exception e) {

    println("STOP ERROR:");
    println(e);

  }


  // --------------------------------------------
  // RELEASE VIRTUAL DISPLAY
  // --------------------------------------------

  if (virtualDisplay != null) {

    virtualDisplay.release();
    virtualDisplay = null;

  }


  // --------------------------------------------
  // RELEASE MEDIA PROJECTION
  // --------------------------------------------

  if (mediaProjection != null) {

    mediaProjection.stop();
    mediaProjection = null;

  }


  println("--------------------------");
  println("RECORDING FINISHED");
  println("5 SECONDS");
  println(videoFile);
  println("--------------------------");

}





























