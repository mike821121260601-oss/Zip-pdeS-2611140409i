





//////2CHESS ENGINES2 /////IAM///////
void settings() {
size(displayWidth, displayHeight, P2D) ;} 
void setup() {
size(displayWidth, displayHeight, P2D) ; 


  } 
float [] [] b88f=new float [8][8];
int [] [] b88i=new int [8][8];
short [] [] b88s=new short [8][8];
byte [] [] b88b=new byte [8][8];
float [] [] [] mf=new float [30][30][9999] ;
int [] [] [] mi=new int [30][30][9999] ;
short [] [] [] ms=new short [30][30][9999] ;
byte [] [] [] mb=new byte [30][30][9999] ;




float[] [] bstrtf=new float[8][8];
   //  bstrtf={{}} ;
int [] [] bstrti=new int [8][8];
   //  bstrti={{}} ;
short [] [] bstrts=new short [8][8];
   //  bstrts={{}} ;
byte [] [] bstrtb=new byte [8][8];
   //  bstrtb={{}} ;







short shortshort=32767;    


 
  byte bytebyte=127;

//shortshort=-32768;
//bytebyte=-128;


/*
shortshort=-32768;
bytebyte=-128;
shortshort=-32768;
bytebyte=-128;

*/

































