




















byte mikevavrinchakgrogkmusicAPDE;

/*
APDE example using android.media.AudioTrack (simple sine wave tone generator)
In APDE (Android Processing Development Environment), you can directly import and use Android Java classes like AudioTrack.
Full Sketch Example */
import android.media.AudioTrack;
import android.media.AudioFormat;
import android.media.AudioManager;

AudioTrack audioTrack;
boolean isPlaying = false;
float frequency = 440;  // A4 note
int sampleRate = 44100;

void setup() {
  fullScreen();
  textAlign(CENTER, CENTER);
  textSize(32);
  
  // Initialize AudioTrack
  int channelConfig = AudioFormat.CHANNEL_OUT_MONO;
  int audioFormat = AudioFormat.ENCODING_PCM_16BIT;
  int minBufferSize = AudioTrack.getMinBufferSize(sampleRate, channelConfig, audioFormat);
  
  audioTrack = new AudioTrack(
    AudioManager.STREAM_MUSIC,
    sampleRate,
    channelConfig,
    audioFormat,
    minBufferSize * 4,  

    AudioTrack.MODE_STREAM
  );
  
  audioTrack.play();
  isPlaying = true;
  
  thread("audioThread");  
// Run audio generation in background thread
}

void draw() {
  background(0);
  fill(255);
  text("AudioTrack Sine Wave\nFrequency: " + nf(frequency, 0, 0) + " Hz\nTap to change frequency", width/2, height/2);
  
  // Visual feedback
  float amp = (sin(

//frameCount
60


 * 0.1) * 50 + 100) ;
  ellipse(width/2, height/3, amp, amp);
}

void mousePressed() {
  // Change frequency on tap
  frequency = random(200, 800);
}

void onPause() {
  super.onPause();
  stopAudio();
}

void stopAudio() {
  if (audioTrack != null) {
    isPlaying = false;
    audioTrack.stop();
    audioTrack.release();
    audioTrack = null;
  }
}

// Background thread for continuous audio generation
void audioThread() {
  short[] buffer = new short[1024];
  double phase = 0.0;
  double twoPi = 2 * PI;
  
  while (isPlaying && audioTrack != null) {
    for (int i = 0; i < buffer.length; i++) {
      // Generate sine wave
      buffer[i] = (short) (32767 * Math.sin(phase));  // 16-bit amplitude
      phase += twoPi * frequency / sampleRate;
      if (phase > twoPi) phase -= twoPi;
    }
    
    audioTrack.write(buffer, 0, buffer.length);
  }
}



/*
How to Use in APDE
Create a new sketch in APDE.
Paste the code above.
Run it on your device.
Tap the screen to randomly change the tone frequency.
Notes
Permissions: For audio output, you usually don't need extra permissions, but test on the device.
Performance: This runs audio generation on a separate thread to avoid blocking the drawing thread.
Customization: Modify frequency, buffer size, or add amplitude control.
Cleanup: The onPause() ensures the track stops when the app is paused.
For more complex audio (e.g., loading samples), you can extend this by generating different waveforms or reading from byte arrays.
This is a minimal, functional example focused on AudioTrack. Let me know if you want variations (square wave, multiple tones, microphone input with AudioRecord, etc.)!

*/










