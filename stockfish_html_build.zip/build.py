#!/usr/bin/env python3
"""Збирає stockfish_game.html: Stockfish 1.0 (WASM) + дошка в одному файлі.
Потрібен Emscripten (em++ у PATH). Запуск: python3 build.py"""
import pathlib, subprocess

here = pathlib.Path(__file__).resolve().parent
subprocess.check_call([
    'em++', '-O3', '-DNDEBUG', '-DSF_LIB',
    '-fno-strict-enums', '-fno-strict-aliasing',
    str(here / 'stockfish_single.cpp'), '-o', str(here / 'sf.js'),
    '-sMODULARIZE=1', '-sEXPORT_NAME=createSF', '-sSINGLE_FILE=1',
    '-sENVIRONMENT=worker',
    '-sEXPORTED_FUNCTIONS=_sf_init,_sf_cmd', '-sEXPORTED_RUNTIME_METHODS=ccall',
    '-sALLOW_MEMORY_GROWTH=1', '-sINITIAL_MEMORY=128MB', '-sSTACK_SIZE=8MB',
])
js = (here / 'sf.js').read_text(encoding='utf-8').replace('</script', '<\\/script')
tpl = (here / 'chess_template.html').read_text(encoding='utf-8')
assert '/*__SF_JS__*/' in tpl
(here / 'stockfish_game.html').write_text(tpl.replace('/*__SF_JS__*/', js, 1), encoding='utf-8')
print('Готово: stockfish_game.html')
