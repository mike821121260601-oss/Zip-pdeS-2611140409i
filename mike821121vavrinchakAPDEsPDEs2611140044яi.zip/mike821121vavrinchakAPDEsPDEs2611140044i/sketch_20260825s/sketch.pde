



int num = 40;
float[] x = new float[num];
float[] y = new float[num];
float[] vx = new float[num];
float[] vy = new float[num];

void setup() {
  size(400, 600);
  for (int i = 0; i < num; i++) {
    x[i] = random(width);
    y[i] = random(height);
    vx[i] = random(-2, 2);
    vy[i] = random(-2, 2);
  }
}

void draw() {
  background(20, 80, 20);
  
  for (int i = 0; i < num; i++) {
    x[i] += vx[i];
    y[i] += vy[i];
    
    // відскок від країв
    if (x[i] < 0 || x[i] > width)  vx[i] *= -1;
    if (y[i] < 0 || y[i] > height) vy[i] *= -1;
    
    fill(255, 150, 50);
    ellipse(x[i], y[i], 20, 20);
  }
  
  // лінії між близькими кульками
  stroke(255, 255, 0, 100);
  for (int i = 0; i < num; i++) {
    for (int j = i+1; j < num; j++) {
      float d = dist(x[i], y[i], x[j], y[j]);
      if (d < 80) {
        line(x[i], y[i], x[j], y[j]);
      }
    }
  }
}









/*

int num = 40;
float[] x = new float[num];
float[] y = new float[num];
float[] vx = new float[num];
float[] vy = new float[num];

void setup() {
  size(400, 600);
  for (int i = 0; i < num; i++) {
    x[i] = random(width);
    y[i] = random(height);
    vx[i] = random(-2, 2);
    vy[i] = random(-2, 2);
  }
}

void draw() {
  background(20, 80, 20);
  
  for (int i = 0; i < num; i++) {
    x[i] += vx[i];
    y[i] += vy[i];
    
    // відскок від країв
    if (x[i] < 0 || x[i] > width)  vx[i] *= -1;
    if (y[i] < 0 || y[i] > height) vy[i] *= -1;
    
    fill(255, 150, 50);
    ellipse(x[i], y[i], 20, 20);
  }
  
  // лінії між близькими кульками
  stroke(255, 255, 0, 100);
  for (int i = 0; i < num; i++) {
    for (int j = i+1; j < num; j++) {
      float d = dist(x[i], y[i], x[j], y[j]);
      if (d < 80) {
        line(x[i], y[i], x[j], y[j]);
      }
    }
  }
}



*/

































