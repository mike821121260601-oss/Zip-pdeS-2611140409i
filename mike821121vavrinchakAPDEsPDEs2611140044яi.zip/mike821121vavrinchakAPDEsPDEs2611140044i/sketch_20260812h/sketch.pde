


//GPT//




import android.app.Activity;
import android.content.pm.ActivityInfo;

Activity activity;

void setup() {
  fullScreen();
  
  activity = this.getActivity();
  
  textAlign(CENTER, CENTER);
  textSize(32);
}

void draw() {
  background(30);
  
  // MENU
  fill(60);
  rect(5, 5, width-10, height-10);
  
  // 4 keys
  drawKey(20, 20, width-40, height/4-30, "PORTRAIT");
  drawKey(20, height/4+10, width-40, height/4-30, "BACK PORTRAIT");
  drawKey(20, height/2+0, width-40, height/4-30, "LANDSCAPE");
  drawKey(20, height*3/4-10, width-40, height/4-30, "BACK LANDSCAPE");
}

void drawKey(float x, float y, float w, float h, String s) {
  fill(90);
  rect(x, y, w, h, 20);
  
  fill(255);
  text(s, x+w/2, y+h/2);
}

void mousePressed() {

  // PORTRAIT
  if (mouseY > 20 &&
      mouseY < height/4-10) {
      
    activity.setRequestedOrientation(
      ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
    );
  }

  // BACK PORTRAIT
  else if (mouseY > height/4+10 &&
           mouseY < height/2-20) {
           
    activity.setRequestedOrientation(
      ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT
    );
  }

  // LANDSCAPE
  else if (mouseY > height/2 &&
           mouseY < height*3/4-20) {
           
    activity.setRequestedOrientation(
      ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
    );
  }

  // BACK LANDSCAPE
  else if (mouseY > height*3/4-10 &&
           mouseY < height) {
           
    activity.setRequestedOrientation(
      ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE
    );
  }
}










