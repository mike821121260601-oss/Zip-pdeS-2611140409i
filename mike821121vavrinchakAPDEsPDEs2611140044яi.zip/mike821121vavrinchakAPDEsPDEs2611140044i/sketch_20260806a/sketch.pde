










/*
Here’s a ready-to-run APDE / Processing sketch that 
draws a simple 3D skeleton (points + lines) that
 rotates continuously.
*/
// APDE / Processing 3D Skeleton – continuous rotation

float angle = 0;

void setup() {
  size(800, 800, P3D);
  smooth();
}

void draw() {
  background(10);
  lights();
  ambientLight(40, 40, 60);
  
  translate(width/2, height/2, 0);
  
  // continuous rotation
  rotateY(angle);
  rotateX(angle * 0.4);
  rotateZ(angle * 0.2);
  angle += 0.015;
  
  // scale so it fits nicely
  scale(2.2);
  
  strokeWeight(3);
  stroke(180, 220, 255);
  fill(255, 80);
  
  // === JOINT POSITIONS (relative) ===
  PVector head   = new PVector(  0, -120,  0);
  PVector neck   = new PVector(  0,  -90,  0);
  PVector torso  = new PVector(  0,  -20,  0);
  PVector hip    = new PVector(  0,   40,  0);
  
  PVector lShoulder = new PVector(-50, -85,  0);
  PVector rShoulder = new PVector( 50, -85,  0);
  PVector lElbow    = new PVector(-85, -30, 15);
  PVector rElbow    = new PVector( 85, -30,-15);
  PVector lHand     = new PVector(-95,  30, 25);
  PVector rHand     = new PVector( 95,  30,-25);
  
  PVector lHip   = new PVector(-30,  45,  0);
  PVector rHip   = new PVector( 30,  45,  0);
  PVector lKnee  = new PVector(-35, 110, 10);
  PVector rKnee  = new PVector( 35, 110,-10);
  PVector lFoot  = new PVector(-40, 170, 20);
  PVector rFoot  = new PVector( 40, 170,-20);
  
  // === DRAW BONES (lines) ===
  // spine
  lineV(head, neck);
  lineV(neck, torso);
  lineV(torso, hip);
  
  // arms
  lineV(neck, lShoulder);
  lineV(neck, rShoulder);
  lineV(lShoulder, lElbow);
  lineV(rShoulder, rElbow);
  lineV(lElbow, lHand);
  lineV(rElbow, rHand);
  
  // legs
  lineV(hip, lHip);
  lineV(hip, rHip);
  lineV(lHip, lKnee);
  lineV(rHip, rKnee);
  lineV(lKnee, lFoot);
  lineV(rKnee, rFoot);
  
  // === DRAW JOINTS (points / spheres) ===
  noStroke();
  fill(100, 200, 255);
  
  joint(head, 14);
  joint(neck, 10);
  joint(torso, 12);
  joint(hip, 12);
  
  joint(lShoulder, 9);
  joint(rShoulder, 9);
  joint(lElbow, 8);
  joint(rElbow, 8);
  joint(lHand, 7);
  joint(rHand, 7);
  
  joint(lHip, 9);
  joint(rHip, 9);
  joint(lKnee, 8);
  joint(rKnee, 8);
  joint(lFoot, 7);
  joint(rFoot, 7);
}

// helper: draw a line between two PVectors
void lineV(PVector a, PVector b) {
  line(a.x, a.y, a.z, b.x, b.y, b.z);
}

// helper: draw a joint as a small sphere
void joint(PVector p, float size) {
  pushMatrix();
  translate(p.x, p.y, p.z);
  sphere(size);
  popMatrix();
}
/*


How to use in APDE
Open APDE → New sketch
Paste the code
Set renderer to P3D (already done in size)
Run
The skeleton will keep spinning forever on all three axes.
You can change the speed by editing angle += 0.015; 
or the joint positions to make a different pose.






*/





















