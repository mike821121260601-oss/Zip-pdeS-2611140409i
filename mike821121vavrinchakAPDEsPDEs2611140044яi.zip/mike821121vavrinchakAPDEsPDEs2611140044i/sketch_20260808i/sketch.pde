







/*


APDE / Processing (P3D) sketch: spheres walking on 3D mountains
This is a complete, ready-to-paste sketch for APDE (or desktop Processing). It generates a Perlin-noise mountain terrain and several spheres that “walk” / roll across the surface, sticking to the heightmap.
// APDE / Processing 3D - Spheres walking on mountains
// Paste into a new sketch and run (P3D)
*/








int cols, rows;
int scl = 20;          // terrain resolution (smaller = more detail, slower)
int w = 2000;          // terrain width
int h = 1600;          // terrain depth
float flying = 0;      // optional scrolling

float[][] terrain;

ArrayList<Walker> walkers = new ArrayList<Walker>();

void setup() {
  size(displayWidth, displayHeight, P3D);  // or size(800, 600, P3D) on desktop
  // orientation(LANDSCAPE);              // uncomment on APDE if needed

  cols = w / scl;
  rows = h / scl;
  terrain = new float[cols][rows];

  // Create several walking spheres
  for (int i = 0; i < 12; i++) {
    walkers.add(new Walker());
  }
}

void draw() {
  background(20, 30, 50);
  lights();
  ambientLight(40, 40, 50);

  // Optional: slowly scroll the terrain
  // flying -= 0.05;

  // Generate / update heightmap
  float yoff = flying;
  for (int y = 0; y < rows; y++) {
    float xoff = 0;
    for (int x = 0; x < cols; x++) {
      terrain[x][y] = map(noise(xoff, yoff), 0, 1, -120, 280);
      xoff += 0.12;
    }
    yoff += 0.12;
  }

  // Camera / view
  translate(width/2, height/2 + 80, -800);
  rotateX(PI / 3.2);
  translate(-w/2, -h/2);

  // Draw mountains
  noStroke();
  for (int y = 0; y < rows-1; y++) {
    beginShape(TRIANGLE_STRIP);
    for (int x = 0; x < cols; x++) {
      float h1 = terrain[x][y];
      float h2 = terrain[x][y+1];

      // Simple height-based coloring
      float bright = map(h1, -120, 280, 40, 255);
      fill(bright * 0.3, bright * 0.6, bright * 0.25);

      vertex(x * scl, y * scl, h1);
      vertex(x * scl, (y+1) * scl, h2);
    }
    endShape();
  }

  // Update & draw walking spheres
  for (Walker w : walkers) {
    w.update();
    w.display();
  }
}

// -------------------------------------------------
// Sphere that walks on the terrain surface
// -------------------------------------------------
class Walker {
  float x, z;          // position on the grid (world units)
  float speed;
  float angle;         // direction of movement
  float radius = 18;
  color col;

  Walker() {
    x = random(w * 0.1, w * 0.9);
    z = random(h * 0.1, h * 0.9);
    speed = random(1.8, 4.2);
    angle = random(TWO_PI);
    col = color(random(180, 255), random(100, 220), random(150, 255));
  }

  void update() {
    // Move
    x += cos(angle) * speed;
    z += sin(angle) * speed;

    // Bounce / turn when near edges
    if (x < 40 || x > w - 40 || z < 40 || z > h - 40) {
      angle += PI + random(-0.6, 0.6);
    }

    // Occasionally change direction a bit (looks more “alive”)
    if (random(1) < 0.008) {
      angle += random(-0.8, 0.8);
    }
  }

  void display() {
    // Sample height at current position
    int gridX = constrain(int(x / scl), 0, cols-1);
    int gridZ = constrain(int(z / scl), 0, rows-1);
    float y = terrain[gridX][gridZ] + radius;   // sit on surface

    pushMatrix();
    translate(x, z, y);
    noStroke();
    fill(col);
    sphereDetail(12);          // lower = faster on mobile
    sphere(radius);
    popMatrix();
  }
}




/*
How to use in APDE
Create a new sketch.
Paste the whole code.
Run on device / emulator (P3D works well on modern Android).
Quick customizations
More / fewer spheres → change the loop for (int i = 0; i < 12; i++)
Bigger / smaller mountains → change the map(..., -120, 280)
Smoother or sharper terrain → change the 0.12 noise step
Faster / slower walkers → change speed range
Make them bounce higher or add simple gravity by storing a vy and integrating
Would you like a version with:
touch / tilt controls so you can steer one sphere,
particle trails,
better lighting / fog,
or a first-person camera following a sphere?
Just say the word and I’ll adjust the code.





*/






















































