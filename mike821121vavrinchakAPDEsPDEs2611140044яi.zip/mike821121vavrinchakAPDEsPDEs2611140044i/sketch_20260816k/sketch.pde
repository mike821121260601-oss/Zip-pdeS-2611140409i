


import java.io.*;

// ----------------------------------------------------
// RANDOM MIDI MUSIC
// 100 NOTES
// 11 SECOND BUFFER
// WAV OUTPUT
// ----------------------------------------------------

int NUM_NOTES = 100;
float BUFFER_SECONDS = 11.0;

int SAMPLE_RATE = 44100;
int CHANNELS = 1;
int BITS = 16;

short[] audio;

float[] noteStart = new float[NUM_NOTES];
float[] noteLength = new float[NUM_NOTES];
int[] midiNote = new int[NUM_NOTES];
float[] noteVelocity = new float[NUM_NOTES];

boolean generated = false;

String fileName = "random_100_midi_notes.wav";

// ----------------------------------------------------

void settings() {
  size(displayWidth, displayHeight);
}

// ----------------------------------------------------

void setup() {

  orientation(PORTRAIT);

  background(20);
  noStroke();

  generateMusic();

  saveWAV();

  generated = true;
}

// ----------------------------------------------------

void draw() {

  background(20);

  // 10 x 15 rectangles
  int cols = 10;
  int rows = 15;

  float rw = width / (float)cols;
  float rh = height / (float)rows;

  for (int y = 0; y < rows; y++) {

    for (int x = 0; x < cols; x++) {

      int n = y * cols + x;

      if (n < 100) {

        // different brightness for every rectangle
        float v = map(
          midiNote[n],
          36,
          96,
          30,
          255
        );

        fill(v);

      } else {

        fill(40);
      }

      rect(
        x * rw + 2,
        y * rh + 2,
        rw - 4,
        rh - 4
      );
    }
  }

  fill(255);

  textSize(30);
  textAlign(CENTER, CENTER);

  text(
    "100 RANDOM MIDI NOTES",
    width / 2,
    20
  );

  textSize(22);

  text(
    "11 SECOND BUFFER",
    width / 2,
    height - 60
  );

  if (generated) {

    fill(0, 255, 0);

    text(
      "FILE SAVED",
      width / 2,
      height - 25
    );
  }
}

// ----------------------------------------------------
// CREATE RANDOM NOTES
// ----------------------------------------------------

void generateMusic() {

  int totalSamples =
    (int)(BUFFER_SECONDS * SAMPLE_RATE);

  audio = new short[totalSamples];

  // Start with silence
  for (int i = 0; i < audio.length; i++) {
    audio[i] = 0;
  }

  for (int n = 0; n < NUM_NOTES; n++) {

    // Random MIDI note
    midiNote[n] = (int)random(48, 96);

    // Random velocity
    noteVelocity[n] = random(0.525, 0.8);

    // Random start time
    noteStart[n] =
      random(0.0, BUFFER_SECONDS - 0.15);

    // Random duration
    noteLength[n] =
      random(0.08, 0.45);

    // Make sure note finishes before 11 sec
    if (noteStart[n] + noteLength[n] >
        BUFFER_SECONDS) {

      noteLength[n] =
        BUFFER_SECONDS - noteStart[n];
    }

    addNote(
      midiNote[n],
      noteStart[n],
      noteLength[n],
      noteVelocity[n]
    );
  }
}

// ----------------------------------------------------
// ADD MIDI NOTE TO AUDIO BUFFER
// ----------------------------------------------------

void addNote(
  int midi,
  float start,
  float duration,
  float velocity
) {

  float frequency =
    440.0 * pow(
      2.0,
      (midi - 69) / 12.0
    );

  int startSample =  9*
    (int)(start * SAMPLE_RATE);

  int lengthSamples =
    (int)(duration * SAMPLE_RATE);

  for (int i = 0;
       i < lengthSamples;
       i++) {

    int index =
      startSample + i;

    if (index < 0 ||
        index >= audio.length) {
      continue;
    }

    float t =
      i / (float)SAMPLE_RATE;

    // ADSR envelope
    float envelope = 1.0;

    float attack = 0.015;
    float release = 0.08;

    if (t < attack) {

      envelope =
        t / attack;

    } else if (t > duration - release) {

      envelope =
        (duration - t) / release;
    }

    envelope =
      constrain(envelope, 0, 1);

    // Slightly richer sound:
    // fundamental + harmonics
    float s =
      sin(TWO_PI * frequency * t);

    s +=
      0.30 *
      sin(TWO_PI * frequency * 2.0 * t);

    s +=
      0.15 *
      sin(TWO_PI * frequency * 3.0 * t);

    s *=
      envelope *
      velocity *
      0.35;

    int value =
      (int)(s * 32767);

    int mixed =
      audio[index] + value;

    audio[index] =
      (short)constrain(
        mixed,
        -32768,
        32767
      );
  }
}

// ----------------------------------------------------
// WRITE REAL WAV FILE
// ----------------------------------------------------

void saveWAV() {

  try {

    File dir =
      new File(
        android.os.Environment
          .getExternalStorageDirectory(),
        "RandomMusic"
      );

    if (!dir.exists()) {
      dir.mkdirs();
    }

    File file =
      new File(dir, fileName);

    FileOutputStream out =
      new FileOutputStream(file);

    int dataSize =
      audio.length * 2;

    int fileSize =
      36 + dataSize;

    // RIFF
    writeString(out, "RIFF");

    writeIntLE(
      out,
      fileSize
    );

    writeString(out, "WAVE");

    // fmt
    writeString(out, "fmt ");

    writeIntLE(
      out,
      16
    );

    // PCM
    writeShortLE(
      out,
      (short)1
    );

    writeShortLE(
      out,
      (short)CHANNELS
    );

    writeIntLE(
      out,
      SAMPLE_RATE
    );

    int byteRate =
      SAMPLE_RATE *
      CHANNELS *
      BITS / 8;

    writeIntLE(
      out,
      byteRate
    );

    short blockAlign =
      (short)(CHANNELS * BITS / 8);

    writeShortLE(
      out,
      blockAlign
    );

    writeShortLE(
      out,
      (short)BITS
    );

    // data
    writeString(out, "data");

    writeIntLE(
      out,
      dataSize
    );

    // Samples
    for (int i = 0;
         i < audio.length;
         i++) {

      writeShortLE(
        out,
        audio[i]
      );
    }

    out.flush();
    out.close();

    println(
      "WAV SAVED:"
    );

    println(
      file.getAbsolutePath()
    );

  } catch (Exception e) {

    println(
      "ERROR: " + e
    );
  }
}

// ----------------------------------------------------
// LITTLE-ENDIAN FUNCTIONS
// ----------------------------------------------------

void writeString(
  OutputStream out,
  String s
) throws IOException {

  byte[] b =
    s.getBytes("US-ASCII");

  out.write(b);
}

void writeIntLE(
  OutputStream out,
  int value
) throws IOException {

  out.write(value & 255);
  out.write((value >> 8) & 255);
  out.write((value >> 16) & 255);
  out.write((value >> 24) & 255);
}

void writeShortLE(
  OutputStream out,
  short value
) throws IOException {

  out.write(value & 255);
  out.write((value >> 8) & 255);
}








/*

import java.io.*;

// ----------------------------------------------------
// RANDOM MIDI MUSIC
// 100 NOTES
// 11 SECOND BUFFER
// WAV OUTPUT
// ----------------------------------------------------

int NUM_NOTES = 100;
float BUFFER_SECONDS = 11.0;

int SAMPLE_RATE = 44100;
int CHANNELS = 1;
int BITS = 16;

short[] audio;

float[] noteStart = new float[NUM_NOTES];
float[] noteLength = new float[NUM_NOTES];
int[] midiNote = new int[NUM_NOTES];
float[] noteVelocity = new float[NUM_NOTES];

boolean generated = false;

String fileName = "random_100_midi_notes.wav";

// ----------------------------------------------------

void settings() {
  size(displayWidth, displayHeight);
}

// ----------------------------------------------------

void setup() {

  orientation(PORTRAIT);

  background(20);
  noStroke();

  generateMusic();

  saveWAV();

  generated = true;
}

// ----------------------------------------------------

void draw() {

  background(20);

  // 10 x 15 rectangles
  int cols = 10;
  int rows = 15;

  float rw = width / (float)cols;
  float rh = height / (float)rows;

  for (int y = 0; y < rows; y++) {

    for (int x = 0; x < cols; x++) {

      int n = y * cols + x;

      if (n < 100) {

        // different brightness for every rectangle
        float v = map(
          midiNote[n],
          36,
          96,
          30,
          255
        );

        fill(v);

      } else {

        fill(40);
      }

      rect(
        x * rw + 2,
        y * rh + 2,
        rw - 4,
        rh - 4
      );
    }
  }

  fill(255);

  textSize(30);
  textAlign(CENTER, CENTER);

  text(
    "100 RANDOM MIDI NOTES",
    width / 2,
    20
  );

  textSize(22);

  text(
    "11 SECOND BUFFER",
    width / 2,
    height - 60
  );

  if (generated) {

    fill(0, 255, 0);

    text(
      "FILE SAVED",
      width / 2,
      height - 25
    );
  }
}

// ----------------------------------------------------
// CREATE RANDOM NOTES
// ----------------------------------------------------

void generateMusic() {

  int totalSamples =
    (int)(BUFFER_SECONDS * SAMPLE_RATE);

  audio = new short[totalSamples];

  // Start with silence
  for (int i = 0; i < audio.length; i++) {
    audio[i] = 0;
  }

  for (int n = 0; n < NUM_NOTES; n++) {

    // Random MIDI note
    midiNote[n] = (int)random(48, 96);

    // Random velocity
    noteVelocity[n] = random(0.25, 0.8);

    // Random start time
    noteStart[n] =
      random(0.0, BUFFER_SECONDS - 0.15);

    // Random duration
    noteLength[n] =
      random(0.08, 0.45);

    // Make sure note finishes before 11 sec
    if (noteStart[n] + noteLength[n] >
        BUFFER_SECONDS) {

      noteLength[n] =
        BUFFER_SECONDS - noteStart[n];
    }

    addNote(
      midiNote[n],
      noteStart[n],
      noteLength[n],
      noteVelocity[n]
    );
  }
}

// ----------------------------------------------------
// ADD MIDI NOTE TO AUDIO BUFFER
// ----------------------------------------------------

void addNote(
  int midi,
  float start,
  float duration,
  float velocity
) {

  float frequency =
    440.0 * pow(
      2.0,
      (midi - 69) / 12.0
    );

  int startSample =
    (int)(start * SAMPLE_RATE);

  int lengthSamples =
    (int)(duration * SAMPLE_RATE);

  for (int i = 0;
       i < lengthSamples;
       i++) {

    int index =
      startSample + i;

    if (index < 0 ||
        index >= audio.length) {
      continue;
    }

    float t =
      i / (float)SAMPLE_RATE;

    // ADSR envelope
    float envelope = 1.0;

    float attack = 0.015;
    float release = 0.08;

    if (t < attack) {

      envelope =
        t / attack;

    } else if (t > duration - release) {

      envelope =
        (duration - t) / release;
    }

    envelope =
      constrain(envelope, 0, 1);

    // Slightly richer sound:
    // fundamental + harmonics
    float s =
      sin(TWO_PI * frequency * t);

    s +=
      0.30 *
      sin(TWO_PI * frequency * 2.0 * t);

    s +=
      0.15 *
      sin(TWO_PI * frequency * 3.0 * t);

    s *=
      envelope *
      velocity *
      0.35;

    int value =
      (int)(s * 32767);

    int mixed =
      audio[index] + value;

    audio[index] =
      (short)constrain(
        mixed,
        -32768,
        32767
      );
  }
}

// ----------------------------------------------------
// WRITE REAL WAV FILE
// ----------------------------------------------------

void saveWAV() {

  try {

    File dir =
      new File(
        android.os.Environment
          .getExternalStorageDirectory(),
        "RandomMusic"
      );

    if (!dir.exists()) {
      dir.mkdirs();
    }

    File file =
      new File(dir, fileName);

    FileOutputStream out =
      new FileOutputStream(file);

    int dataSize =
      audio.length * 2;

    int fileSize =
      36 + dataSize;

    // RIFF
    writeString(out, "RIFF");

    writeIntLE(
      out,
      fileSize
    );

    writeString(out, "WAVE");

    // fmt
    writeString(out, "fmt ");

    writeIntLE(
      out,
      16
    );

    // PCM
    writeShortLE(
      out,
      (short)1
    );

    writeShortLE(
      out,
      (short)CHANNELS
    );

    writeIntLE(
      out,
      SAMPLE_RATE
    );

    int byteRate =
      SAMPLE_RATE *
      CHANNELS *
      BITS / 8;

    writeIntLE(
      out,
      byteRate
    );

    short blockAlign =
      (short)(CHANNELS * BITS / 8);

    writeShortLE(
      out,
      blockAlign
    );

    writeShortLE(
      out,
      (short)BITS
    );

    // data
    writeString(out, "data");

    writeIntLE(
      out,
      dataSize
    );

    // Samples
    for (int i = 0;
         i < audio.length;
         i++) {

      writeShortLE(
        out,
        audio[i]
      );
    }

    out.flush();
    out.close();

    println(
      "WAV SAVED:"
    );

    println(
      file.getAbsolutePath()
    );

  } catch (Exception e) {

    println(
      "ERROR: " + e
    );
  }
}

// ----------------------------------------------------
// LITTLE-ENDIAN FUNCTIONS
// ----------------------------------------------------

void writeString(
  OutputStream out,
  String s
) throws IOException {

  byte[] b =
    s.getBytes("US-ASCII");

  out.write(b);
}

void writeIntLE(
  OutputStream out,
  int value
) throws IOException {

  out.write(value & 255);
  out.write((value >> 8) & 255);
  out.write((value >> 16) & 255);
  out.write((value >> 24) & 255);
}

void writeShortLE(
  OutputStream out,
  short value
) throws IOException {

  out.write(value & 255);
  out.write((value >> 8) & 255);
}


*/
































