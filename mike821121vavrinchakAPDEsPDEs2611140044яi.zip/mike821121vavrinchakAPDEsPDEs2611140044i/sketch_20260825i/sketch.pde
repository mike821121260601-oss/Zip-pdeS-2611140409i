


/*
  ChessGame.pde
  Single-file APDE / Processing Android chess

  Based on the class structure of:
  m3sharma/ChessGame

  No external libraries.
  No chess font.
  Pieces are drawn with simple geometry/letters.

  Controls:
    TOUCH = select / move
    FLIP  = rotate board
    NEW   = new game
    WHITE = human controls White
    BLACK = human controls Black

  Android / APDE friendly.
*/

final int EMPTY = 0;
final int WPAWN = 1;
final int WKNIGHT = 2;
final int WBISHOP = 3;
final int WROOK = 4;
final int WQUEEN = 5;
final int WKING = 6;

final int BPAWN = -1;
final int BKNIGHT = -2;
final int BBISHOP = -3;
final int BROOK = -4;
final int BQUEEN = -5;
final int BKING = -6;

int[][] board = new int[8][8];

boolean whiteTurn = true;
boolean flipped = false;

int selectedR = -1;
int selectedC = -1;

boolean gameOver = false;
String message = "WHITE TO MOVE";

boolean whiteHuman = true;
boolean blackHuman = true;

int boardX, boardY, squareSize;

boolean dragging = false;

boolean[] legal = new boolean[64];

boolean whiteKingMoved = false;
boolean blackKingMoved = false;

boolean whiteRookLeftMoved = false;
boolean whiteRookRightMoved = false;
boolean blackRookLeftMoved = false;
boolean blackRookRightMoved = false;


// ------------------------------------------------------------
// PROCESSING
// ------------------------------------------------------------

void setup() {
  fullScreen();
  orientation(PORTRAIT);
  textAlign(CENTER, CENTER);
  rectMode(CORNER);

  newGame();
}


void draw() {

  background(25);

  calculateBoardGeometry();

  drawBoard();
  drawPieces();
  drawSelection();
  drawButtons();

  if (gameOver) {
    fill(0, 180);
    rect(0, height/2 - 60, width, 120);

    fill(255);
    textSize(30);
    text(message, width/2, height/2);

    textSize(16);
    text("TOUCH NEW", width/2, height/2 + 40);
  }
}


// ------------------------------------------------------------
// BOARD GEOMETRY
// ------------------------------------------------------------

void calculateBoardGeometry() {

  squareSize = min(width / 8, height * 7 / 10 / 8);

  boardX = (width - squareSize * 8) / 2;
  boardY = 70;
}


// ------------------------------------------------------------
// NEW GAME
// ------------------------------------------------------------

void newGame() {

  for (int r = 0; r < 8; r++)
    for (int c = 0; c < 8; c++)
      board[r][c] = EMPTY;

  // BLACK

  board[0][0] = BROOK;
  board[0][1] = BKNIGHT;
  board[0][2] = BBISHOP;
  board[0][3] = BQUEEN;
  board[0][4] = BKING;
  board[0][5] = BBISHOP;
  board[0][6] = BKNIGHT;
  board[0][7] = BROOK;

  for (int c = 0; c < 8; c++)
    board[1][c] = BPAWN;


  // WHITE

  for (int c = 0; c < 8; c++)
    board[6][c] = WPAWN;

  board[7][0] = WROOK;
  board[7][1] = WKNIGHT;
  board[7][2] = WBISHOP;
  board[7][3] = WQUEEN;
  board[7][4] = WKING;
  board[7][5] = WBISHOP;
  board[7][6] = WKNIGHT;
  board[7][7] = WROOK;


  whiteTurn = true;

  selectedR = -1;
  selectedC = -1;

  gameOver = false;

  message = "WHITE TO MOVE";

  whiteKingMoved = false;
  blackKingMoved = false;

  whiteRookLeftMoved = false;
  whiteRookRightMoved = false;
  blackRookLeftMoved = false;
  blackRookRightMoved = false;

  clearLegal();
}


// ------------------------------------------------------------
// BOARD DRAW
// ------------------------------------------------------------

void drawBoard() {

  stroke(50);
  strokeWeight(1);

  for (int r = 0; r < 8; r++) {

    for (int c = 0; c < 8; c++) {

      int rr = flipped ? 7-r : r;
      int cc = flipped ? 7-c : c;

      float x = boardX + cc * squareSize;
      float y = boardY + rr * squareSize;

      if ((r+c)%2 == 0)
        fill(235, 210, 170);
      else
        fill(110, 75, 45);

      rect(x, y, squareSize, squareSize);
    }
  }
}


// ------------------------------------------------------------
// PIECES
// ------------------------------------------------------------

void drawPieces() {

  textSize(squareSize * 0.58);

  for (int r = 0; r < 8; r++) {

    for (int c = 0; c < 8; c++) {

      int p = board[r][c];

      if (p == EMPTY)
        continue;

      int rr = flipped ? 7-r : r;
      int cc = flipped ? 7-c : c;

      float x = boardX + cc * squareSize + squareSize/2;
      float y = boardY + rr * squareSize + squareSize/2;

      drawPiece(p, x, y);
    }
  }
}


void drawPiece(int p, float x, float y) {

  String s = "";

  int a = abs(p);

  if (a == WPAWN)   s = "P";
  if (a == WKNIGHT) s = "N";
  if (a == WBISHOP) s = "B";
  if (a == WROOK)   s = "R";
  if (a == WQUEEN)  s = "Q";
  if (a == WKING)   s = "K";

  if (p > 0) {

    fill(250);
    stroke(0);
    strokeWeight(3);

  } else {

    fill(20);
    stroke(255);
    strokeWeight(2);
  }

  text(s, x, y);
}


// ------------------------------------------------------------
// SELECTION
// ------------------------------------------------------------

void drawSelection() {

  if (selectedR < 0)
    return;

  int rr = flipped ? 7-selectedR : selectedR;
  int cc = flipped ? 7-selectedC : selectedC;

  float x = boardX + cc * squareSize;
  float y = boardY + rr * squareSize;

  noFill();
  stroke(255, 220, 0);
  strokeWeight(5);
  rect(x+3, y+3, squareSize-6, squareSize-6);

  // Legal destinations

  noStroke();
  fill(0, 200, 0, 130);

  for (int r = 0; r < 8; r++) {

    for (int c = 0; c < 8; c++) {

      if (!legal[r*8+c])
        continue;

      int br = flipped ? 7-r : r;
      int bc = flipped ? 7-c : c;

      float cx = boardX + bc*squareSize + squareSize/2;
      float cy = boardY + br*squareSize + squareSize/2;

      ellipse(cx, cy, squareSize*0.25, squareSize*0.25);
    }
  }
}


// ------------------------------------------------------------
// BUTTONS
// ------------------------------------------------------------

void drawButtons() {

  int y = boardY + squareSize*8 + 15;

  button(10, y, 90, 48, "NEW");
  button(110, y, 90, 48, "FLIP");
  button(210, y, 90, 48, "WHITE");
  button(310, y, 90, 48, "BLACK");

  fill(255);
  textSize(17);

  String side = whiteTurn ? "WHITE TO MOVE" : "BLACK TO MOVE";

  if (gameOver)
    side = message;

  text(side, width/2, 40);
}


void button(int x, int y, int w, int h, String s) {

  fill(60);
  stroke(180);
  strokeWeight(2);
  rect(x, y, w, h, 8);

  fill(255);
  textSize(15);
  text(s, x+w/2, y+h/2);
}


// ------------------------------------------------------------
// TOUCH
// ------------------------------------------------------------

void mousePressed() {

  if (gameOver) {

    int y = boardY + squareSize*8 + 15;

    if (mouseX >= 10 && mouseX <= 100 &&
        mouseY >= y && mouseY <= y+48) {

      newGame();
    }

    return;
  }


  int by = boardY + squareSize*8 + 15;

  // NEW

  if (mouseX >= 10 && mouseX <= 100 &&
      mouseY >= by && mouseY <= by+48) {

    newGame();
    return;
  }


  // FLIP

  if (mouseX >= 110 && mouseX <= 200 &&
      mouseY >= by && mouseY <= by+48) {

    flipped = !flipped;
    return;
  }


  // WHITE

  if (mouseX >= 210 && mouseX <= 300 &&
      mouseY >= by && mouseY <= by+48) {

    whiteHuman = true;
    blackHuman = false;

    message = whiteTurn ?
      "WHITE TO MOVE" :
      "BLACK ENGINE";

    return;
  }


  // BLACK

  if (mouseX >= 310 && mouseX <= 400 &&
      mouseY >= by && mouseY <= by+48) {

    whiteHuman = false;
    blackHuman = true;

    message = whiteTurn ?
      "WHITE ENGINE" :
      "BLACK TO MOVE";

    return;
  }


  // Board touch

  if (mouseX < boardX ||
      mouseX >= boardX + squareSize*8 ||
      mouseY < boardY ||
      mouseY >= boardY + squareSize*8)
    return;


  int visualC = int((mouseX-boardX)/squareSize);
  int visualR = int((mouseY-boardY)/squareSize);

  int c = flipped ? 7-visualC : visualC;
  int r = flipped ? 7-visualR : visualR;

  selectSquare(r, c);
}


// ------------------------------------------------------------
// SELECT / MOVE
// ------------------------------------------------------------

void selectSquare(int r, int c) {

  int p = board[r][c];

  boolean human =
    whiteTurn ? whiteHuman : blackHuman;

  if (!human)
    return;


  // Nothing selected

  if (selectedR < 0) {

    if (p != EMPTY &&
        ((p > 0) == whiteTurn)) {

      selectedR = r;
      selectedC = c;

      calculateLegalMoves(r, c);
    }

    return;
  }


  // Same square

  if (r == selectedR && c == selectedC) {

    selectedR = -1;
    selectedC = -1;

    clearLegal();

    return;
  }


  // Another own piece

  if (p != EMPTY &&
      ((p > 0) == whiteTurn)) {

    selectedR = r;
    selectedC = c;

    calculateLegalMoves(r, c);

    return;
  }


  // Destination

  if (legal[r*8+c]) {

    makeMove(selectedR, selectedC, r, c);

    selectedR = -1;
    selectedC = -1;

    clearLegal();

    return;
  }
}


// ------------------------------------------------------------
// LEGAL MOVES
// ------------------------------------------------------------

void clearLegal() {

  for (int i = 0; i < 64; i++)
    legal[i] = false;
}


void calculateLegalMoves(int r, int c) {

  clearLegal();

  int p = board[r][c];

  if (p == EMPTY)
    return;

  int color = p > 0 ? 1 : -1;

  int type = abs(p);


  if (type == 1)
    pawnMoves(r,c,color);

  else if (type == 2)
    knightMoves(r,c,color);

  else if (type == 3)
    bishopMoves(r,c,color);

  else if (type == 4)
    rookMoves(r,c,color);

  else if (type == 5) {
    bishopMoves(r,c,color);
    rookMoves(r,c,color);
  }

  else if (type == 6)
    kingMoves(r,c,color);
}


// ------------------------------------------------------------
// PAWN
// ------------------------------------------------------------

void pawnMoves(int r, int c, int color) {

  int dir = color == 1 ? -1 : 1;

  int nr = r + dir;

  if (inside(nr,c) && board[nr][c] == EMPTY) {

    addLegal(nr,c);

    int start = color == 1 ? 6 : 1;

    if (r == start &&
        board[r+2*dir][c] == EMPTY) {

      addLegal(r+2*dir,c);
    }
  }


  for (int dc=-1; dc<=1; dc+=2) {

    int nc = c + dc;

    if (!inside(nr,nc))
      continue;

    int target = board[nr][nc];

    if (target != EMPTY &&
        (target > 0) != (color > 0)) {

      addLegal(nr,nc);
    }
  }
}


// ------------------------------------------------------------
// KNIGHT
// ------------------------------------------------------------

void knightMoves(int r, int c, int color) {

  int[] dr = {-2,-2,-1,-1,1,1,2,2};
  int[] dc = {-1,1,-2,2,-2,2,-1,1};

  for (int i=0; i<8; i++) {

    int nr = r+dr[i];
    int nc = c+dc[i];

    if (!inside(nr,nc))
      continue;

    if (board[nr][nc] == EMPTY ||
        (board[nr][nc] > 0) != (color > 0)) {

      addLegal(nr,nc);
    }
  }
}


// ------------------------------------------------------------
// BISHOP
// ------------------------------------------------------------

void bishopMoves(int r, int c, int color) {

  slide(r,c,color,1,1);
  slide(r,c,color,1,-1);
  slide(r,c,color,-1,1);
  slide(r,c,color,-1,-1);
}


// ------------------------------------------------------------
// ROOK
// ------------------------------------------------------------

void rookMoves(int r, int c, int color) {

  slide(r,c,color,1,0);
  slide(r,c,color,-1,0);
  slide(r,c,color,0,1);
  slide(r,c,color,0,-1);
}


// ------------------------------------------------------------
// SLIDING PIECES
// ------------------------------------------------------------

void slide(int r, int c, int color, int dr, int dc) {

  int nr = r+dr;
  int nc = c+dc;

  while (inside(nr,nc)) {

    if (board[nr][nc] == EMPTY) {

      addLegal(nr,nc);

    } else {

      if ((board[nr][nc] > 0) != (color > 0))
        addLegal(nr,nc);

      break;
    }

    nr += dr;
    nc += dc;
  }
}


// ------------------------------------------------------------
// KING
// ------------------------------------------------------------

void kingMoves(int r, int c, int color) {

  for (int dr=-1; dr<=1; dr++) {

    for (int dc=-1; dc<=1; dc++) {

      if (dr == 0 && dc == 0)
        continue;

      int nr = r+dr;
      int nc = c+dc;

      if (!inside(nr,nc))
        continue;

      if (board[nr][nc] == EMPTY ||
          (board[nr][nc] > 0) != (color > 0)) {

        addLegal(nr,nc);
      }
    }
  }


  // Castling

  if (color == 1 && r == 7 && c == 4 &&
      !whiteKingMoved) {

    if (!whiteRookRightMoved &&
        board[7][5] == EMPTY &&
        board[7][6] == EMPTY) {

      addLegal(7,6);
    }

    if (!whiteRookLeftMoved &&
        board[7][1] == EMPTY &&
        board[7][2] == EMPTY &&
        board[7][3] == EMPTY) {

      addLegal(7,2);
    }
  }


  if (color == -1 && r == 0 && c == 4 &&
      !blackKingMoved) {

    if (!blackRookRightMoved &&
        board[0][5] == EMPTY &&
        board[0][6] == EMPTY) {

      addLegal(0,6);
    }

    if (!blackRookLeftMoved &&
        board[0][1] == EMPTY &&
        board[0][2] == EMPTY &&
        board[0][3] == EMPTY) {

      addLegal(0,2);
    }
  }
}


// ------------------------------------------------------------
// MOVE
// ------------------------------------------------------------

void makeMove(int r1, int c1, int r2, int c2) {

  int p = board[r1][c1];

  // Castling

  if (abs(p) == 6 && abs(c2-c1) == 2) {

    if (c2 == 6) {

      board[r2][5] = board[r2][7];
      board[r2][7] = EMPTY;

    } else if (c2 == 2) {

      board[r2][3] = board[r2][0];
      board[r2][0] = EMPTY;
    }
  }


  board[r2][c2] = p;
  board[r1][c1] = EMPTY;


  // King / rook movement flags

  if (p == WKING)
    whiteKingMoved = true;

  if (p == BKING)
    blackKingMoved = true;


  if (p == WROOK) {

    if (r1 == 7 && c1 == 0)
      whiteRookLeftMoved = true;

    if (r1 == 7 && c1 == 7)
      whiteRookRightMoved = true;
  }


  if (p == BROOK) {

    if (r1 == 0 && c1 == 0)
      blackRookLeftMoved = true;

    if (r1 == 0 && c1 == 7)
      blackRookRightMoved = true;
  }


  // Pawn promotion

  if (p == WPAWN && r2 == 0)
    board[r2][c2] = WQUEEN;

  if (p == BPAWN && r2 == 7)
    board[r2][c2] = BQUEEN;


  // Switch player

  whiteTurn = !whiteTurn;


  // Check king

  if (kingMissing(!whiteTurn)) {

    gameOver = true;

    message = whiteTurn ?
      "BLACK WINS" :
      "WHITE WINS";

    return;
  }


  message = whiteTurn ?
    "WHITE TO MOVE" :
    "BLACK TO MOVE";
}


// ------------------------------------------------------------
// KING CHECK
// ------------------------------------------------------------

boolean kingMissing(boolean white) {

  int king = white ? WKING : BKING;

  for (int r=0; r<8; r++)
    for (int c=0; c<8; c++)
      if (board[r][c] == king)
        return false;

  return true;
}


// ------------------------------------------------------------
// HELPERS
// ------------------------------------------------------------

void addLegal(int r, int c) {

  if (inside(r,c))
    legal[r*8+c] = true;
}


boolean inside(int r, int c) {

  return r >= 0 &&
         r < 8 &&
         c >= 0 &&
         c < 8;
}






























