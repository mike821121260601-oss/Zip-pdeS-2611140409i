


// Simple Billiard for APDE 0.5.3///FRISTION////
// Touch/drag to aim and shoot the white ball

Ball[] balls = new Ball[7];
Ball cue;
float friction = 0.985  +0.01 +0.003;
boolean shooting = false;
float power = 0;
PVector aim;

void setup() {
  size(displayWidth, displayHeight);






 /// orientation(LANDSCAPE );







  
  // Cue ball
  cue = new Ball(width*0.25, height/2, color(255));
  
  // Other balls
  float startX = width*0.65;
  float startY = height/2;
  float r = 22;
  int idx = 0;
  for (int row = 0; row < 3 *1; row++) {
    for (int col = 0; col <= row; col++) {
      float x = startX + row * r * 1.75;
      float y = startY + (col - row/2.0) * r * 2;
      balls[idx++] = new 
Ball(x, y, color(random(50,255), random(50,255), 
 random(50,255)));
    }
  }
}

void draw() {
  background(20, 90, 40);  // green table
  
  // Table border
  noFill();
  stroke(139, 90, 43);
  strokeWeight(20);
  rect(30, 30, width-60, height-60, 15);
  
  // Update & draw balls
  cue.update();
  cue.show();
  
  for (Ball b : balls) {
    if (b != null) {
      b.update();
      b.show();
    }
  }
  
  // Collisions
  checkCollisions();
  
  // Aim line when touching
  if (mousePressed && !isMoving()) {
    stroke(255, 180);
    strokeWeight(2);
    line(cue.pos.x, cue.pos.y, mouseX, mouseY);
    
    // Power circle
    power = dist(cue.pos.x, cue.pos.y,
    mouseX, mouseY) * 0.08  *9/9;
    power = constrain(power, 0, 18    *9/9  );
    noFill();
    stroke(255, 100);
 ellipse(cue.pos.x, cue.pos.y, power*8, power*8);
  }
}

void mouseReleased() {
  if (!isMoving()) {
    PVector dir = new PVector
 (cue.pos.x - mouseX, cue.pos.y - mouseY);
    dir.normalize();
    cue.vel = dir.mult(power);
  }
}

boolean isMoving() {
  if (cue.vel.mag() > 0.3) return true;
  for (Ball b : balls) {
    if (b != null && b.vel.mag() > 0.3) return true;
  }
  return false;
}

void checkCollisions() {
  // Cue vs others
  for (int i = 0; i < balls.length; i++) {
    if (balls[i] != null) {
      collide(cue, balls[i]);
    }
  }
  // Between colored balls
  for (int i = 0; i < balls.length; i++) {
    for (int j = i+1; j < balls.length; j++) {
      if (balls[i] != null && balls[j] != null) {
        collide(balls[i], balls[j]);
      }
    }
  }
}

void collide(Ball a, Ball b) {
  float d = dist(a.pos.x, a.pos.y, b.pos.x, b.pos.y);
  if (d < a.r + b.r) {
    // Simple elastic collision
    PVector normal = PVector.sub
  (b.pos, a.pos).normalize();
    PVector relativeVel = PVector.sub(a.vel, b.vel);
    float speed = relativeVel.dot(normal);


   ///   speed *=9;////




    
    if (speed > 0) {
      a.vel.sub(PVector.mult(normal, speed));
      b.vel.add(PVector.mult(normal, speed));
    }
    
    // Separate overlapping balls
    float overlap = (a.r + b.r - d) / 2;
    a.pos.sub(PVector.mult(normal, overlap));
    b.pos.add(PVector.mult(normal, overlap));
  }
}

class Ball {
  PVector pos, vel;
  float r = 18;
  color c;
  
  Ball(float x, float y, color col) {
    pos = new PVector(x, y);
    vel = new PVector(0, 0);
    c = col;
  }
  
  void update() {
    pos.add(vel);
    vel.mult(friction);
    
    // Bounce on borders
    if (pos.x < 50 + r || pos.x > width - 50 - r) {
      vel.x *= -0.9;
      pos.x = constrain(pos.x, 50 + r, width - 50 - r);
    }
    if (pos.y < 50 + r || pos.y > height - 50 - r) {
      vel.y *= -0.9;
      pos.y = constrain(pos.y, 50 + r, height - 50 - r);
    }
    
    // Stop very slow balls
    if (vel.mag() < 0.15) vel.set(0, 0);
  }
  
  void show() {
    noStroke();
    fill(c);
    ellipse(pos.x, pos.y, r*2, r*2);
    
    // Highlight
    fill(255, 80);
  ellipse(pos.x - r*0.3, pos.y - r*0.3, r*0.6, r*0.6);
  }
}

























/*

// Simple Billiard for APDE 0.5.3
// Touch/drag to aim and shoot the white ball

Ball[] balls = new Ball[7];
Ball cue;
float friction = 0.985;
boolean shooting = false;
float power = 0;
PVector aim;

void setup() {
  size(displayWidth, displayHeight);
  orientation(LANDSCAPE);
  
  // Cue ball
  cue = new Ball(width*0.25, height/2, color(255));
  
  // Other balls
  float startX = width*0.65;
  float startY = height/2;
  float r = 22;
  int idx = 0;
  for (int row = 0; row < 3; row++) {
    for (int col = 0; col <= row; col++) {
      float x = startX + row * r * 1.75;
      float y = startY + (col - row/2.0) * r * 2;
      balls[idx++] = new Ball(x, y, 
color(random(50,255), random(50,255), random(50,255)));
    }
  }
}

void draw() {
  background(20, 90, 40);  // green table
  
  // Table border
  noFill();
  stroke(139, 90, 43);
  strokeWeight(20);
  rect(30, 30, width-60, height-60, 15);
  
  // Update & draw balls
  cue.update();
  cue.show();
  
  for (Ball b : balls) {
    if (b != null) {
      b.update();
      b.show();
    }
  }
  
  // Collisions
  checkCollisions();
  
  // Aim line when touching
  if (mousePressed && !isMoving()) {
    stroke(255, 180);
    strokeWeight(2);
    line(cue.pos.x, cue.pos.y, mouseX, mouseY);
    
    // Power circle
    power = dist(cue.pos.x, cue.pos.y, 
   mouseX, mouseY) * 0.08;
    power = constrain(power, 0, 18);
    noFill();
    stroke(255, 100);
    ellipse(cue.pos.x, cue.pos.y, power*8, power*8);
  }
}

void mouseReleased() {
  if (!isMoving()) {
    PVector dir = new PVector
  (cue.pos.x - mouseX, cue.pos.y - mouseY);
    dir.normalize();
    cue.vel = dir.mult(power);
  }
}

boolean isMoving() {
  if (cue.vel.mag() > 0.3) return true;
  for (Ball b : balls) {
    if (b != null && b.vel.mag() > 0.3) return true;
  }
  return false;
}

void checkCollisions() {
  // Cue vs others
  for (int i = 0; i < balls.length; i++) {
    if (balls[i] != null) {
      collide(cue, balls[i]);
    }
  }
  // Between colored balls
  for (int i = 0; i < balls.length; i++) {
    for (int j = i+1; j < balls.length; j++) {
      if (balls[i] != null && balls[j] != null) {
        collide(balls[i], balls[j]);
      }
    }
  }
}

void collide(Ball a, Ball b) {
  float d = dist(a.pos.x, a.pos.y, b.pos.x, b.pos.y);
  if (d < a.r + b.r) {
    // Simple elastic collision
 PVector normal = PVector.sub(b.pos, a.pos).normalize();
    PVector relativeVel = PVector.sub(a.vel, b.vel);
    float speed = relativeVel.dot(normal);
    
    if (speed > 0) {
      a.vel.sub(PVector.mult(normal, speed));
      b.vel.add(PVector.mult(normal, speed));
    }
    
    // Separate overlapping balls
    float overlap = (a.r + b.r - d) / 2;
    a.pos.sub(PVector.mult(normal, overlap));
    b.pos.add(PVector.mult(normal, overlap));
  }
}

class Ball {
  PVector pos, vel;
  float r = 18;
  color c;
  
  Ball(float x, float y, color col) {
    pos = new PVector(x, y);
    vel = new PVector(0, 0);
    c = col;
  }
  
  void update() {
    pos.add(vel);
    vel.mult(friction);
    
    // Bounce on borders
    if (pos.x < 50 + r || pos.x > width - 50 - r) {
      vel.x *= -0.9;
      pos.x = constrain(pos.x, 50 + r, width - 50 - r);
    }
    if (pos.y < 50 + r || pos.y > height - 50 - r) {
      vel.y *= -0.9;
      pos.y = constrain(pos.y, 50 + r, height - 50 - r);
    }
    
    // Stop very slow balls
    if (vel.mag() < 0.15) vel.set(0, 0);
  }
  
  void show() {
    noStroke();
    fill(c);
    ellipse(pos.x, pos.y, r*2, r*2);
    
    // Highlight
    fill(255, 80);
    ellipse(pos.x - r*0.3, pos.y - r*0.3, r*0.6, r*0.6);
  }
}


// Simple Billiard for APDE 0.5.3
// Touch/drag to aim and shoot the white ball

Ball[] balls = new Ball[7];
Ball cue;
float friction = 0.985;
boolean shooting = false;
float power = 0;
PVector aim;

void setup() {
  size(displayWidth, displayHeight);
  orientation(LANDSCAPE);
  
  // Cue ball
  cue = new Ball(width*0.25, height/2, color(255));
  
  // Other balls
  float startX = width*0.65;
  float startY = height/2;
  float r = 22;
  int idx = 0;
  for (int row = 0; row < 3; row++) {
    for (int col = 0; col <= row; col++) {
      float x = startX + row * r * 1.75;
      float y = startY + (col - row/2.0) * r * 2;
      balls[idx++] = new Ball(x, y, color(random(50,255), random(50,255), random(50,255)));
    }
  }
}

void draw() {
  background(20, 90, 40);  // green table
  
  // Table border
  noFill();
  stroke(139, 90, 43);
  strokeWeight(20);
  rect(30, 30, width-60, height-60, 15);
  
  // Update & draw balls
  cue.update();
  cue.show();
  
  for (Ball b : balls) {
    if (b != null) {
      b.update();
      b.show();
    }
  }
  
  // Collisions
  checkCollisions();
  
  // Aim line when touching
  if (mousePressed && !isMoving()) {
    stroke(255, 180);
    strokeWeight(2);
    line(cue.pos.x, cue.pos.y, mouseX, mouseY);
    
    // Power circle
    power = dist(cue.pos.x, cue.pos.y, mouseX, mouseY) * 0.08;
    power = constrain(power, 0, 18);
    noFill();
    stroke(255, 100);
    ellipse(cue.pos.x, cue.pos.y, power*8, power*8);
  }
}

void mouseReleased() {
  if (!isMoving()) {
    PVector dir = new PVector(cue.pos.x - mouseX, cue.pos.y - mouseY);
    dir.normalize();
    cue.vel = dir.mult(power);
  }
}

boolean isMoving() {
  if (cue.vel.mag() > 0.3) return true;
  for (Ball b : balls) {
    if (b != null && b.vel.mag() > 0.3) return true;
  }
  return false;
}

void checkCollisions() {
  // Cue vs others
  for (int i = 0; i < balls.length; i++) {
    if (balls[i] != null) {
      collide(cue, balls[i]);
    }
  }
  // Between colored balls
  for (int i = 0; i < balls.length; i++) {
    for (int j = i+1; j < balls.length; j++) {
      if (balls[i] != null && balls[j] != null) {
        collide(balls[i], balls[j]);
      }
    }
  }
}

void collide(Ball a, Ball b) {
  float d = dist(a.pos.x, a.pos.y, b.pos.x, b.pos.y);
  if (d < a.r + b.r) {
    // Simple elastic collision
    PVector normal = PVector.sub(b.pos, a.pos).normalize();
    PVector relativeVel = PVector.sub(a.vel, b.vel);
    float speed = relativeVel.dot(normal);
    
    if (speed > 0) {
      a.vel.sub(PVector.mult(normal, speed));
      b.vel.add(PVector.mult(normal, speed));
    }
    
    // Separate overlapping balls
    float overlap = (a.r + b.r - d) / 2;
    a.pos.sub(PVector.mult(normal, overlap));
    b.pos.add(PVector.mult(normal, overlap));
  }
}

class Ball {
  PVector pos, vel;
  float r = 18;
  color c;
  
  Ball(float x, float y, color col) {
    pos = new PVector(x, y);
    vel = new PVector(0, 0);
    c = col;
  }
  
  void update() {
    pos.add(vel);
    vel.mult(friction);
    
    // Bounce on borders
    if (pos.x < 50 + r || pos.x > width - 50 - r) {
      vel.x *= -0.9;
      pos.x = constrain(pos.x, 50 + r, width - 50 - r);
    }
    if (pos.y < 50 + r || pos.y > height - 50 - r) {
      vel.y *= -0.9;
      pos.y = constrain(pos.y, 50 + r, height - 50 - r);
    }
    
    // Stop very slow balls
    if (vel.mag() < 0.15) vel.set(0, 0);
  }
  
  void show() {
    noStroke();
    fill(c);
    ellipse(pos.x, pos.y, r*2, r*2);
    
    // Highlight
    fill(255, 80);
    ellipse(pos.x - r*0.3, pos.y - r*0.3, r*0.6, r*0.6);
  }
}


*/

































