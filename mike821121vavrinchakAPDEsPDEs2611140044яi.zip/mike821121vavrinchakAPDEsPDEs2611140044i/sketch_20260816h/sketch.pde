

//
 import android.hardware.Camera;
// import android.hardware.Camera.PictureCallback;
import android.view.Surface;
import android.graphics.SurfaceTexture;
import android.os.Environment;
import android.content.pm.PackageManager;
import android.Manifest;
import android.media.ExifInterface;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;


// ----------------------------------------------------
// APDE CAMERA - FRONT + REAR
// Android 9
// ----------------------------------------------------

Camera cam = null;

SurfaceTexture fakeSurface;

int cameraNumber = -1;

boolean cameraBusy = false;

String message = "READY";

int frontX;
int frontY;
int frontW;
int frontH;

int rearX;
int rearY;
int rearW;
int rearH;


// ----------------------------------------------------
// SETUP
// ----------------------------------------------------

void setup() {

  size(displayWidth, displayHeight, P2D);

  orientation(PORTRAIT);

  textAlign(CENTER, CENTER);

  frontW = int(width * 0.80);
  frontH = int(height * 0.18);

  frontX = int(width * 0.10);
  frontY = int(height * 0.20);

  rearW = int(width * 0.80);
  rearH = int(height * 0.18);

  rearX = int(width * 0.10);
  rearY = int(height * 0.55);


  // Android 6+ runtime permission
/*
  if (checkSelfPermission(Manifest.permission.CAMERA)
      != PackageManager.PERMISSION_GRANTED) {

    requestPermissions(
      new String[] {
        Manifest.permission.CAMERA,
        Manifest.permission.WRITE_EXTERNAL_STORAGE
      },
      500
      );

    message = "CAMERA PERMISSION";
  }
  else {
    message = "READY";
  }
}


*/




// ----------------------------------------------------
// DRAW
// ----------------------------------------------------

void draw() {

  background(25);

  // title
  fill(255);
  textSize(width * 0.055);
  text("APDE CAMERA", width/2, height * 0.08);


  // FRONT rectangle
  fill(30, 150, 255);
  rect(frontX, frontY, frontW, frontH);

  fill(255);
  textSize(width * 0.055);
  text("FRONT CAMERA",
       frontX + frontW/2,
       frontY + frontH/2);


  // REAR rectangle
  fill(30, 200, 80);
  rect(rearX, rearY, rearW, rearH);

  fill(255);
  text("REAR CAMERA",
       rearX + rearW/2,
       rearY + rearH/2);


  // status
  fill(255, 220, 0);
  textSize(width * 0.045);
  text(message, width/2, height * 0.85);
}


// ----------------------------------------------------
// TOUCH
// ----------------------------------------------------

void mousePressed() {

  if (cameraBusy) return;

  // FRONT
  if (mouseX >= frontX &&
      mouseX <= frontX + frontW &&
      mouseY >= frontY &&
      mouseY <= frontY + frontH) {

    takePhoto(true);
  }


  // REAR
  if (mouseX >= rearX &&
      mouseX <= rearX + rearW &&
      mouseY >= rearY &&
      mouseY <= rearY + rearH) {

    takePhoto(false);
  }
}


// ----------------------------------------------------
// TAKE PHOTO
// ----------------------------------------------------

void takePhoto(boolean front) {

  if (checkSelfPermission(Manifest.permission.CAMERA)
      != PackageManager.PERMISSION_GRANTED) {

    message = "NO CAMERA PERMISSION";
    return;
  }


  if (cameraBusy) return;

  cameraBusy = true;


  if (front) {
    message = "OPEN FRONT CAMERA";
    openCamera(Camera.CameraInfo.CAMERA_FACING_FRONT);
  }
  else {
    message = "OPEN REAR CAMERA";
    openCamera(Camera.CameraInfo.CAMERA_FACING_BACK);
  }


  if (cam == null) {

    message = "CAMERA ERROR";
    cameraBusy = false;

    return;
  }


  try {

    // ------------------------------------------------
    // CAMERA SETTINGS
    // ------------------------------------------------

    Camera.Parameters p = cam.getParameters();

    if (p.getSupportedPictureSizes() != null) {

      Camera.Size best = null;

      for (Camera.Size s : p.getSupportedPictureSizes()) {

        if (best == null) {
          best = s;
        }

        // choose large picture
        if (s.width * s.height >
            best.width * best.height) {

          best = s;
        }
      }

      if (best != null) {
        p.setPictureSize(best.width, best.height);
      }
    }

    cam.setParameters(p);


    // ------------------------------------------------
    // START PREVIEW
    // ------------------------------------------------

    if (fakeSurface == null) {
      fakeSurface = new SurfaceTexture(10);
    }

    cam.setPreviewTexture(fakeSurface);

    cam.startPreview();


    // small delay before taking photo
    delay(300);


    cam.takePicture(
      null,
      null,
      pictureCallback
      );

  }
  catch (Exception e) {

    message = "TAKE PHOTO ERROR";

    println(e);

    releaseCamera();

    cameraBusy = false;
  }
}


// ----------------------------------------------------
// OPEN CAMERA
// ----------------------------------------------------

void openCamera(int facing) {

  releaseCamera();


  int numberOfCameras = Camera.getNumberOfCameras();

  Camera.CameraInfo info =
    new Camera.CameraInfo();


  for (int i = 0; i < numberOfCameras; i++) {

    Camera.getCameraInfo(i, info);

    if (info.facing == facing) {

      cameraNumber = i;
      break;
    }
  }


  if (cameraNumber < 0) {

    message = "CAMERA NOT FOUND";
    cameraBusy = false;

    return;
  }


  try {

    cam = Camera.open(cameraNumber);

    setCameraOrientation(facing);

  }
  catch (Exception e) {

    println(e);

    cam = null;

    message = "CAMERA OPEN ERROR";

    cameraBusy = false;
  }
}


// ----------------------------------------------------
// CAMERA ORIENTATION
// ----------------------------------------------------

void setCameraOrientation(int facing) {

  if (cam == null) return;


  Camera.CameraInfo info =
    new Camera.CameraInfo();

  Camera.getCameraInfo(cameraNumber, info);


  // Processing Android portrait screen
  int rotation =
    getActivity()
    .getWindowManager()
    .getDefaultDisplay()
    .getRotation();


  int degrees = 0;

  if (rotation == Surface.ROTATION_0) {
    degrees = 0;
  }
  else if (rotation == Surface.ROTATION_90) {
    degrees = 90;
  }
  else if (rotation == Surface.ROTATION_180) {
    degrees = 180;
  }
  else if (rotation == Surface.ROTATION_270) {
    degrees = 270;
  }


  int result;


  if (info.facing ==
      Camera.CameraInfo.CAMERA_FACING_FRONT) {

    result =
      (info.orientation + degrees) % 360;

    result =
      (360 - result) % 360;

  }
  else {

    result =
      (info.orientation - degrees + 360) % 360;
  }


  cam.setDisplayOrientation(result);
}


// ----------------------------------------------------
// JPEG CALLBACK
// ----------------------------------------------------

PictureCallback pictureCallback =
  new PictureCallback() {

  public void onPictureTaken(
    byte[] data,
    Camera camera) {


    if (data == null) {

      message = "EMPTY IMAGE";

      releaseCamera();

      cameraBusy = false;

      return;
    }


    try {

      // ------------------------------------------------
      // CREATE DIRECTORY
      // ------------------------------------------------

      File pictures =
        Environment.getExternalStoragePublicDirectory(
        Environment.DIRECTORY_PICTURES
        );


      File folder =
        new File(
        pictures,
        "APDECamera"
        );


      if (!folder.exists()) {
        folder.mkdirs();
      }


      // ------------------------------------------------
      // FILE NAME
      // ------------------------------------------------

      String time =
        new SimpleDateFormat(
        "yyyyMMdd_HHmmss_SSS",
        Locale.US
        ).format(
        new Date()
        );


      String name;


      if (cameraNumber >= 0) {

        Camera.CameraInfo info =
          new Camera.CameraInfo();

        Camera.getCameraInfo(
          cameraNumber,
          info
          );


        if (info.facing ==
          Camera.CameraInfo.CAMERA_FACING_FRONT) {

          name =
            "FRONT_" +
            time +
            ".jpg";

        }
        else {

          name =
            "REAR_" +
            time +
            ".jpg";
        }

      }
      else {

        name =
          "CAMERA_" +
          time +
          ".jpg";
      }


      File file =
        new File(
        folder,
        name
        );


      // ------------------------------------------------
      // WRITE JPEG
      // ------------------------------------------------

      FileOutputStream out =
        new FileOutputStream(file);

      out.write(data);

      out.flush();

      out.close();


      // ------------------------------------------------
      // MESSAGE
      // ------------------------------------------------

      message =
        "SAVED: " +
        name;

      println(
        "PHOTO SAVED:"
        );

      println(
        file.getAbsolutePath()
        );


    }
    catch (Exception e) {

      println(e);

      message =
        "SAVE ERROR";
    }


    // ------------------------------------------------
    // RELEASE CAMERA
    // ------------------------------------------------

    releaseCamera();

    cameraBusy = false;
  }
};


// ----------------------------------------------------
// RELEASE CAMERA
// ----------------------------------------------------

void releaseCamera() {

  if (cam != null) {

    try {

      cam.stopPreview();

    }
    catch (Exception e) {
    }


    try {

      cam.release();

    }
    catch (Exception e) {
    }


    cam = null;
  }


  cameraNumber = -1;
}


// ----------------------------------------------------
// ACTIVITY PAUSE
// ----------------------------------------------------

void onPause() {

  super.onPause();

  releaseCamera();

  cameraBusy = false;
}


// ----------------------------------------------------
// ACTIVITY RESUME
// ----------------------------------------------------

void onResume() {

  super.onResume();
}


// ----------------------------------------------------
// PERMISSION RESULT
// ----------------------------------------------------

void onRequestPermissionsResult(
  int requestCode,
  String[] permissions,
  int[] grantResults) {

  super.onRequestPermissionsResult(
    requestCode,
    permissions,
    grantResults
    );


  if (requestCode == 500) {

    if (grantResults.length > 0 &&
        grantResults[0] ==
        PackageManager.PERMISSION_GRANTED) {

      message =
        "PERMISSION OK";

    }
    else {

      message =
        "CAMERA PERMISSION DENIED";
    }
  }
}
















/*


CAMERA
WRITE_EXTERNAL_STORAGE

android.permission.CAMERA
android.permission.WRITE_EXTERNAL_STORAGE

Pictures/APDECamera/

FRONT_20260816_032800_123.jpg
REAR_20260816_032805_456.jpg









*/





















