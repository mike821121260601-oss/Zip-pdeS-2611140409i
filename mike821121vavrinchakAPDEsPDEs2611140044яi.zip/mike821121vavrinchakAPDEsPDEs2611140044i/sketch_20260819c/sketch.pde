



////GOOD/////


import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;

AudioTrack track;
Thread audioThread;
volatile boolean playing = true;

int sampleRate = 44100;
int bufferSize;
short[] buffer;

volatile float frequency = 5000;   // start at 5 kHz
volatile float amplitude = 0.5f;   // 0.0 – 1.0

void setup() {
  fullScreen();
  orientation(PORTRAIT);   // or LANDSCAPE if you prefer
  noStroke();
  
  bufferSize = AudioTrack.getMinBufferSize(
    sampleRate,
    AudioFormat.CHANNEL_OUT_MONO,
    AudioFormat.ENCODING_PCM_16BIT
  );
  
  if (bufferSize == AudioTrack.ERROR || bufferSize == AudioTrack.ERROR_BAD_VALUE) {
    bufferSize = sampleRate / 10;   // fallback \~100 ms
  }
  
  buffer = new short[bufferSize];
  
  track = new AudioTrack(
    AudioManager.STREAM_MUSIC,
    sampleRate,
    AudioFormat.CHANNEL_OUT_MONO,
    AudioFormat.ENCODING_PCM_16BIT,
    bufferSize,
    AudioTrack.MODE_STREAM
  );
  
  track.play();
  
  // Continuous sine-wave thread
  audioThread = new Thread(new Runnable() {
    public void run() {
      double phase = 0.0;
      final double twoPi = 2.0 * Math.PI;
      
      while (playing) {
        float freq = frequency;
        float amp  = amplitude;
        
        double phaseInc = twoPi * freq / sampleRate;
        
        for (int i = 0; i < bufferSize; i++) {
          buffer[i] = (short)(amp * Math.sin(phase) * Short.MAX_VALUE);
          phase += phaseInc;
          if (phase > twoPi) phase -= twoPi;
        }
        
        track.write(buffer, 0, bufferSize);
      }
    }
  });
  audioThread.start();
}

void draw() {
  background(30);
  
  // Draw a centered square / rectangle
  fill(80, 180, 255);
  float size = min(width, height) * 0.6;
  rectMode(CENTER);
  rect(width/2, height/2, size, size);
  
  // Visual feedback of current settings
  fill(255);
  textAlign(CENTER, CENTER);
  textSize(28);
  text("Freq: " + nf(frequency, 0, 0) + " Hz", width/2, height - 80);
  text("Vol:  " + nf(amplitude * 100, 0, 0) + " %", width/2, height - 40);
}

void mouseDragged() {
  updateParams(mouseX, mouseY);
}

void mousePressed() {
  updateParams(mouseX, mouseY);
}

// Map touch position to frequency & volume
void updateParams(float x, float y) {
  // Left → 5 kHz, Right → 20 kHz
  frequency = map(x, 0, width, 5000, 20000);
  frequency = constrain(frequency, 5000, 20000);
  
  // Upper → 90 % volume, Lower → 10 % volume
  amplitude = map(y, 0, height, 0.90, 0.10);
  amplitude = constrain(amplitude, 0.10, 0.90);
}

void stop() {
  playing = false;
  if (audioThread != null) {
    try { audioThread.join(200); } catch (Exception e) {}
  }
  if (track != null) {
    track.stop();
    track.release();
  }
  super.stop();
}





////good////


























