










/////manvsman///////

// ====================== CHESS - Full Processing Sketch ======================
// Click a piece to select it, then click a valid square to move.
// White moves first.

final int BOARD_SIZE = 8;
final int TILE = 80;                 // pixel size of each square
final int OFFSET = 40;               // margin around the board

PImage[] whitePieces = new PImage[6];
PImage[] blackPieces = new PImage[6];

Piece[][] board = new Piece[BOARD_SIZE][BOARD_SIZE];
boolean whiteTurn = true;
Piece selected = null;
ArrayList<PVector> validMoves = new ArrayList<PVector>();
boolean gameOver = false;
String winner = "";

void setup() {
  size(720, 720);
  textAlign(CENTER, CENTER);
  textSize(20);
  
  // Load piece images (or draw them with shapes if images are missing)
  // You can replace these with your own PNGs later
  loadPieces();
  resetBoard();
}

void draw() {
  background(40);
  drawBoard();
  drawPieces();
  drawHighlights();
  drawStatus();
}

void mousePressed() {
  if (gameOver) return;
  
  int col = (mouseX - OFFSET) / TILE;
  int row = (mouseY - OFFSET) / TILE;
  
  if (col < 0 || col >= 8 || row < 0 || row >= 8) return;
  
  if (selected == null) {
    // Select a piece
    Piece p = board[row][col];
    if (p != null && p.isWhite == whiteTurn) {
      selected = p;
      validMoves = p.getValidMoves(board);
    }
  } else {
    // Try to move
    boolean moved = false;
    for (PVector m : validMoves) {
      if ((int)m.x == col && (int)m.y == row) {
        makeMove(selected, col, row);
        moved = true;
        break;
      }
    }
    
    // Deselect if clicked elsewhere or after move
    selected = null;
    validMoves.clear();
    
    if (!moved) {
      // Maybe select a different piece of the same color
      Piece p = board[row][col];
      if (p != null && p.isWhite == whiteTurn) {
        selected = p;
        validMoves = p.getValidMoves(board);
      }
    }
  }
}

void keyPressed() {
  if (key == 'r' || key == 'R') {
    resetBoard();
    gameOver = false;
    winner = "";
    whiteTurn = true;
    selected = null;
    validMoves.clear();
  }
}

// ====================== BOARD & DRAWING ======================

void drawBoard() {
  for (int r = 0; r < 8; r++) {
    for (int c = 0; c < 8; c++) {
      if ((r + c) % 2 == 0) fill(240, 217, 181);  // light
      else fill(181, 136, 99);                     // dark
      rect(OFFSET + c * TILE, OFFSET + r * TILE, TILE, TILE);
    }
  }
}

void drawPieces() {
  for (int r = 0; r < 8; r++) {
    for (int c = 0; c < 8; c++) {
      Piece p = board[r][c];
      if (p != null) {
        p.draw(OFFSET + c * TILE, OFFSET + r * TILE);
      }
    }
  }
}

void drawHighlights() {
  if (selected != null) {
    // Selected square
    fill(255, 255, 0, 100);
    noStroke();
    rect(OFFSET + selected.col * TILE, OFFSET + selected.row * TILE, TILE, TILE);
    
    // Valid moves
    for (PVector m : validMoves) {
      fill(0, 255, 0, 120);
      ellipse(OFFSET + m.x * TILE + TILE/2, OFFSET + m.y * TILE + TILE/2, 30, 30);
    }
  }
}

void drawStatus() {
  fill(255);
  String status = whiteTurn ? "White's turn" : "Black's turn";
  if (gameOver) status = winner + " wins!  Press R to restart";
  text(status, width/2, 20);
  text("Press R to restart", width/2, height - 20);
}

// ====================== GAME LOGIC ======================

void makeMove(Piece p, int toCol, int toRow) {
  // Capture
  if (board[toRow][toCol] != null) {
    board[toRow][toCol] = null;
  }
  
  // Move
  board[p.row][p.col] = null;
  p.col = toCol;
  p.row = toRow;
  board[toRow][toCol] = p;
  p.hasMoved = true;
  
  // Pawn promotion (simple → Queen)
  if (p instanceof Pawn) {
    if ((p.isWhite && p.row == 0) || (!p.isWhite && p.row == 7)) {
      board[p.row][p.col] = new Queen(p.isWhite, p.col, p.row);
    }
  }
  
  // Switch turn
  whiteTurn = !whiteTurn;
  
  // Very simple game-over: if a king is missing
  if (!hasKing(true)) {
    gameOver = true;
    winner = "Black";
  } else if (!hasKing(false)) {
    gameOver = true;
    winner = "White";
  }
}

boolean hasKing(boolean white) {
  for (int r = 0; r < 8; r++)
    for (int c = 0; c < 8; c++)
      if (board[r][c] instanceof King && board[r][c].isWhite == white)
        return true;
  return false;
}

void resetBoard() {
  // Clear
  for (int r = 0; r < 8; r++)
    for (int c = 0; c < 8; c++)
      board[r][c] = null;
  
  // White pieces (bottom)
  board[7][0] = new Rook(true, 0, 7);
  board[7][1] = new Knight(true, 1, 7);
  board[7][2] = new Bishop(true, 2, 7);
  board[7][3] = new Queen(true, 3, 7);
  board[7][4] = new King(true, 4, 7);
  board[7][5] = new Bishop(true, 5, 7);
  board[7][6] = new Knight(true, 6, 7);
  board[7][7] = new Rook(true, 7, 7);
  for (int c = 0; c < 8; c++) board[6][c] = new Pawn(true, c, 6);
  
  // Black pieces (top)
  board[0][0] = new Rook(false, 0, 0);
  board[0][1] = new Knight(false, 1, 0);
  board[0][2] = new Bishop(false, 2, 0);
  board[0][3] = new Queen(false, 3, 0);
  board[0][4] = new King(false, 4, 0);
  board[0][5] = new Bishop(false, 5, 0);
  board[0][6] = new Knight(false, 6, 0);
  board[0][7] = new Rook(false, 7, 0);
  for (int c = 0; c < 8; c++) board[1][c] = new Pawn(false, c, 1);
}

// ====================== PIECE CLASSES ======================

abstract class Piece {
  boolean isWhite;
  int col, row;
  boolean hasMoved = false;
  
  Piece(boolean isWhite, int col, int row) {
    this.isWhite = isWhite;
    this.col = col;
    this.row = row;
  }
  
  abstract void draw(float x, float y);
  abstract ArrayList<PVector> getValidMoves(Piece[][] b);
  
  boolean isEnemy(Piece other) {
    return other != null && other.isWhite != this.isWhite;
  }
  
  boolean isFriendly(Piece other) {
    return other != null && other.isWhite == this.isWhite;
  }
  
  boolean inBounds(int c, int r) {
    return c >= 0 && c < 8 && r >= 0 && r < 8;
  }
}

// ---------- King ----------
class King extends Piece {
  King(boolean w, int c, int r) { super(w, c, r); }
  
  void draw(float x, float y) {
    fill(isWhite ? 255 : 30);
    stroke(0);
    strokeWeight(2);
    // Simple crown shape
    ellipse(x + TILE/2, y + TILE/2 + 5, 40, 40);
    triangle(x+20, y+25, x+30, y+10, x+40, y+25);
    triangle(x+40, y+25, x+50, y+10, x+60, y+25);
  }
  
  ArrayList<PVector> getValidMoves(Piece[][] b) {
    ArrayList<PVector> moves = new ArrayList<PVector>();
    int[] dc = {-1,0,1,-1,1,-1,0,1};
    int[] dr = {-1,-1,-1,0,0,1,1,1};
    for (int i = 0; i < 8; i++) {
      int nc = col + dc[i];
      int nr = row + dr[i];
      if (inBounds(nc, nr) && !isFriendly(b[nr][nc])) {
        moves.add(new PVector(nc, nr));
      }
    }
    return moves;
  }
}

// ---------- Queen ----------
class Queen extends Piece {
  Queen(boolean w, int c, int r) { super(w, c, r); }
  
  void draw(float x, float y) {
    fill(isWhite ? 255 : 30);
    stroke(0);
    strokeWeight(2);
    ellipse(x + TILE/2, y + TILE/2, 45, 45);
    // Points
    for (int i = 0; i < 5; i++) {
      float a = i * TWO_PI / 5 - HALF_PI;
      line(x+TILE/2, y+TILE/2, x+TILE/2 + cos(a)*28, y+TILE/2 + sin(a)*28);
    }
  }
  
  ArrayList<PVector> getValidMoves(Piece[][] b) {
    ArrayList<PVector> moves = new ArrayList<PVector>();
    // Combine rook + bishop directions
    int[][] dirs = {{0,1},{0,-1},{1,0},{-1,0},{1,1},{1,-1},{-1,1},{-1,-1}};
    for (int[] d : dirs) {
      for (int step = 1; step < 8; step++) {
        int nc = col + d[0]*step;
        int nr = row + d[1]*step;
        if (!inBounds(nc, nr)) break;
        if (isFriendly(b[nr][nc])) break;
        moves.add(new PVector(nc, nr));
        if (isEnemy(b[nr][nc])) break;
      }
    }
    return moves;
  }
}

// ---------- Rook ----------
class Rook extends Piece {
  Rook(boolean w, int c, int r) { super(w, c, r); }
  
  void draw(float x, float y) {
    fill(isWhite ? 255 : 30);
    stroke(0);
    strokeWeight(2);
    rect(x + 20, y + 25, 40, 40);
    // Battlements
    for (int i = 0; i < 3; i++) {
      rect(x + 18 + i*15, y + 15, 12, 12);
    }
  }
  
  ArrayList<PVector> getValidMoves(Piece[][] b) {
    ArrayList<PVector> moves = new ArrayList<PVector>();
    int[][] dirs = {{0,1},{0,-1},{1,0},{-1,0}};
    for (int[] d : dirs) {
      for (int step = 1; step < 8; step++) {
        int nc = col + d[0]*step;
        int nr = row + d[1]*step;
        if (!inBounds(nc, nr)) break;
        if (isFriendly(b[nr][nc])) break;
        moves.add(new PVector(nc, nr));
        if (isEnemy(b[nr][nc])) break;
      }
    }
    return moves;
  }
}

// ---------- Bishop ----------
class Bishop extends Piece {
  Bishop(boolean w, int c, int r) { super(w, c, r); }
  
  void draw(float x, float y) {
    fill(isWhite ? 255 : 30);
    stroke(0);
    strokeWeight(2);
    // Mitre shape
    triangle(x+TILE/2, y+15, x+20, y+55, x+60, y+55);
    ellipse(x+TILE/2, y+20, 20, 20);
  }
  
  ArrayList<PVector> getValidMoves(Piece[][] b) {
    ArrayList<PVector> moves = new ArrayList<PVector>();
    int[][] dirs = {{1,1},{1,-1},{-1,1},{-1,-1}};
    for (int[] d : dirs) {
      for (int step = 1; step < 8; step++) {
        int nc = col + d[0]*step;
        int nr = row + d[1]*step;
        if (!inBounds(nc, nr)) break;
        if (isFriendly(b[nr][nc])) break;
        moves.add(new PVector(nc, nr));
        if (isEnemy(b[nr][nc])) break;
      }
    }
    return moves;
  }
}

// ---------- Knight ----------
class Knight extends Piece {
  Knight(boolean w, int c, int r) { super(w, c, r); }
  
  void draw(float x, float y) {
    fill(isWhite ? 255 : 30);
    stroke(0);
    strokeWeight(2);
    // Horse head approximation
    ellipse(x + TILE/2, y + TILE/2 + 5, 35, 40);
    triangle(x+25, y+25, x+45, y+10, x+55, y+30);
  }
  
  ArrayList<PVector> getValidMoves(Piece[][] b) {
    ArrayList<PVector> moves = new ArrayList<PVector>();
    int[] dc = {1,2,2,1,-1,-2,-2,-1};
    int[] dr = {-2,-1,1,2,2,1,-1,-2};
    for (int i = 0; i < 8; i++) {
      int nc = col + dc[i];
      int nr = row + dr[i];
      if (inBounds(nc, nr) && !isFriendly(b[nr][nc])) {
        moves.add(new PVector(nc, nr));
      }
    }
    return moves;
  }
}

// ---------- Pawn ----------
class Pawn extends Piece {
  Pawn(boolean w, int c, int r) { super(w, c, r); }
  
  void draw(float x, float y) {
    fill(isWhite ? 255 : 30);
    stroke(0);
    strokeWeight(2);
    ellipse(x + TILE/2, y + TILE/2 - 5, 30, 30);
    ellipse(x + TILE/2, y + TILE/2 + 15, 40, 25);
  }
  
  ArrayList<PVector> getValidMoves(Piece[][] b) {
    ArrayList<PVector> moves = new ArrayList<PVector>();
    int dir = isWhite ? -1 : 1;   // white goes up (decreasing row)
    
    // Forward one
    int nr = row + dir;
    if (inBounds(col, nr) && b[nr][col] == null) {
      moves.add(new PVector(col, nr));
      // Forward two from starting rank
      if (!hasMoved) {
        int nr2 = row + 2*dir;
        if (inBounds(col, nr2) && b[nr2][col] == null) {
          moves.add(new PVector(col, nr2));
        }
      }
    }
    
    // Captures
    for (int dc = -1; dc <= 1; dc += 2) {
      int nc = col + dc;
      if (inBounds(nc, nr) && isEnemy(b[nr][nc])) {
        moves.add(new PVector(nc, nr));
      }
    }
    return moves;
  }
}

// Optional: load real images if you have them
void loadPieces() {
  // Example:
  // whitePieces[0] = loadImage("white_king.png");
  // ... etc
  // For now we draw with shapes, so this can stay empty.
}


///////manvsman///////











