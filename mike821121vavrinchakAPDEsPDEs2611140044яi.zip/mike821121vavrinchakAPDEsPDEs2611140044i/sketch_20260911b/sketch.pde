
// Chess for APDE 0.5.3
// 1 = My engine (stronger)
// 2 = Just-style
// 3 = Cuckoo-style  
// 4 = P4-style (weak + random)
// Computer randomly chooses one engine each game
// Portrait: board at bottom | Landscape: board on left
// Pieces rounded (*0.70)

int boardSize, squareSize, boardX, boardY;
boolean isPortrait;

int[] board = new int[64];
// 1-6 white (P N B R Q K), 7-12 black

color lightSq = color(240, 217, 181);
color darkSq  = color(181, 136, 99);
color whitePiece = color(250);
color blackPiece = color(40);
color selectCol = color(255, 255, 0, 140);
color lastMoveCol = color(0, 200, 255, 90);

int selected = -1;
int lastFrom = -1, lastTo = -1;
boolean whiteToMove = true;
boolean gameOver = false;
String status = "";
String engineName = "";
int currentEngine = 1;

int[] pieceVal = {0, 100, 320, 330, 500, 900, 20000};

void setup() {
  size(displayWidth, displayHeight);
  orientation(PORTRAIT);
  textAlign(CENTER, CENTER);
  initBoard();
  chooseRandomEngine();
  calculateLayout();
}

void draw() {
  background(35);
  calculateLayout();
  drawBoard();
  drawPieces();
  
  fill(230);
  textSize(16);
  if (isPortrait) {
    text(status, width/2, 28);
    text("Engine: " + engineName + "   (R=restart  1-4=select)", width/2, 52);
  } else {
    text(status, width - 110, height/2 - 20);
    text(engineName, width - 110, height/2 + 10);
  }
}

void calculateLayout() {
  isPortrait = height > width;
  if (isPortrait) {
    boardSize = min(width - 20, (int)(height * 0.72));
    squareSize = boardSize / 8;
    boardX = (width - boardSize) / 2;
    boardY = height - boardSize - 15;
  } else {
    boardSize = min(height - 20, (int)(width * 0.72));
    squareSize = boardSize / 8;
    boardX = 15;
    boardY = (height - boardSize) / 2;
  }
}

void initBoard() {
  int[] start = {
    10,8,9,11,12,9,8,10,
    7,7,7,7,7,7,7,7,
    0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,
    1,1,1,1,1,1,1,1,
    4,2,3,5,6,3,2,4
  };
  for (int i=0; i<64; i++) board[i] = start[i];
  whiteToMove = true;
  selected = -1;
  lastFrom = lastTo = -1;
  gameOver = false;
  status = "Your move (White)";
}

void chooseRandomEngine() {
  currentEngine = 1 + (int)random(4);
  if (currentEngine == 1) engineName = "1 MyEngine";
  else if (currentEngine == 2) engineName = "2 Just";
  else if (currentEngine == 3) engineName = "3 Cuckoo";
  else engineName = "4 P4";
}

void drawBoard() {
  for (int r=0; r<8; r++) {
    for (int c=0; c<8; c++) {
      int sq = r*8 + c;
      fill( ((r+c)%2==0) ? lightSq : darkSq );
      noStroke();
      rect(boardX + c*squareSize, boardY + r*squareSize, squareSize, squareSize);
      
      if (sq == lastFrom || sq == lastTo) {
        fill(lastMoveCol);
        rect(boardX + c*squareSize, boardY + r*squareSize, squareSize, squareSize);
      }
      if (sq == selected) {
        fill(selectCol);
        rect(boardX + c*squareSize, boardY + r*squareSize, squareSize, squareSize);
      }
    }
  }
}

void drawPieces() {
  for (int i=0; i<64; i++) {
    if (board[i] == 0) continue;
    int r = i / 8, c = i % 8;
    float cx = boardX + c*squareSize + squareSize*0.5;
    float cy = boardY + r*squareSize + squareSize*0.5;
    float s = squareSize * 0.70;
    
    boolean isWhite = board[i] <= 6;
    fill(isWhite ? whitePiece : blackPiece);
    stroke(isWhite ? 60 : 220);
    strokeWeight(1.8);
    
    int p = board[i] > 6 ? board[i]-6 : board[i];
    
    switch(p) {
      case 1: // Pawn round
        ellipse(cx, cy + s*0.05, s*0.55, s*0.55);
        break;
      case 2: // Knight rounded
        beginShape();
        vertex(cx, cy - s*0.38);
        quadraticVertex(cx + s*0.4, cy, cx + s*0.28, cy + s*0.35);
        quadraticVertex(cx, cy + s*0.25, cx - s*0.28, cy + s*0.35);
        quadraticVertex(cx - s*0.4, cy, cx, cy - s*0.38);
        endShape(CLOSE);
        break;
      case 3: // Bishop diamond
        beginShape();
        vertex(cx, cy - s*0.4);
        quadraticVertex(cx + s*0.32, cy, cx, cy + s*0.4);
        quadraticVertex(cx - s*0.32, cy, cx, cy - s*0.4);
        endShape(CLOSE);
        break;
      case 4: // Rook rounded rect
        rect(cx - s*0.28, cy - s*0.28, s*0.56, s*0.56, s*0.12);
        break;
      case 5: // Queen
        ellipse(cx, cy, s*0.68, s*0.68);
        strokeWeight(2.5);
        line(cx - s*0.22, cy, cx + s*0.22, cy);
        line(cx, cy - s*0.22, cx, cy + s*0.22);
        break;
      case 6: // King
        noFill();
        strokeWeight(2.2);
        ellipse(cx, cy, s*0.55, s*0.55);
        strokeWeight(3.5);
        line(cx - s*0.28, cy, cx + s*0.28, cy);
        line(cx, cy - s*0.28, cx, cy + s*0.28);
        break;
    }
  }
}

void mousePressed() {
  if (gameOver) {
    initBoard();
    chooseRandomEngine();
    return;
  }
  
  int c = (int)((mouseX - boardX) / squareSize);
  int r = (int)((mouseY - boardY) / squareSize);
  if (c < 0 || c > 7 || r < 0 || r > 7) return;
  
  int sq = r*8 + c;
  
  if (selected == -1) {
    if (board[sq] != 0 && board[sq] <= 6 && whiteToMove) {
      selected = sq;
    }
  } else {
    if (sq == selected) {
      selected = -1;
    } else if (isLegal(selected, sq)) {
      makeMove(selected, sq);
      selected = -1;
      whiteToMove = false;
      status = "Computer thinking...";
      thread("computerMoveThread");
    } else if (board[sq] != 0 && board[sq] <= 6) {
      selected = sq;
    } else {
      selected = -1;
    }
  }
}

void computerMoveThread() {
  delay(350 + (int)random(250));
  computerMove();
}

void computerMove() {
  if (gameOver) return;
  
  ArrayList<int[]> moves = generateMoves(false);
  if (moves.isEmpty()) {
    gameOver = true;
    status = "You win!";
    return;
  }
  
  int[] best = null;
  int bestScore = -999999;
  
  for (int[] m : moves) {
    int sc = 0;
    if (currentEngine == 1) sc = evalMyEngine(m[0], m[1]);
    else if (currentEngine == 2) sc = evalJust(m[0], m[1]);
    else if (currentEngine == 3) sc = evalCuckoo(m[0], m[1]);
    else sc = evalP4(m[0], m[1]);
    
    if (sc > bestScore) {
      bestScore = sc;
      best = m;
    }
  }
  
  if (best != null) makeMove(best[0], best[1]);
  
  whiteToMove = true;
  if (!gameOver) status = "Your move (White)";
}

// 1 MyEngine - strongest of the four small engines
int evalMyEngine(int from, int to) {
  int score = 0;
  int captured = board[to];
  if (captured != 0) {
    int p = captured > 6 ? captured-6 : captured;
    score += pieceVal[p] * 3;
  }
  int tr = to/8, tc = to%8;
  score += (4 - abs(3.5 - tr)) * 8 + (4 - abs(3.5 - tc)) * 8;
  if (from/8 >= 6) score += 15;
  if (board[from] == 12) score -= 40;
  score += (int)random(-25, 25);
  return score;
}

// 2 Just-style
int evalJust(int from, int to) {
  int captured = board[to];
  if (captured == 0) return (int)random(0, 40);
  int p = captured > 6 ? captured-6 : captured;
  return pieceVal[p] + (int)random(-20, 20);
}

// 3 Cuckoo-style
int evalCuckoo(int from, int to) {
  int score = 0;
  int captured = board[to];
  if (captured != 0) {
    int p = captured > 6 ? captured-6 : captured;
    score += pieceVal[p] * 2;
  }
  int tr = to/8, tc = to%8;
  score += (3 - abs(3.5-tr))*6 + (3 - abs(3.5-tc))*6;
  score += (int)random(-40, 40);
  return score;
}

// 4 P4-style (weak)
int evalP4(int from, int to) {
  int score = (int)random(-100, 120);
  int captured = board[to];
  if (captured != 0) {
    int p = captured > 6 ? captured-6 : captured;
    score += pieceVal[p] / 2;
  }
  return score;
}

boolean isLegal(int from, int to) {
  if (from < 0 || from > 63 || to < 0 || to > 63) return false;
  if (board[from] == 0) return false;
  
  boolean isWhite = board[from] <= 6;
  if (board[to] != 0) {
    boolean targetWhite = board[to] <= 6;
    if (isWhite == targetWhite) return false;
  }
  
  int piece = board[from] > 6 ? board[from]-6 : board[from];
  int fr = from/8, fc = from%8;
  int tr = to/8, tc = to%8;
  int dr = tr - fr, dc = tc - fc;
  
  switch(piece) {
    case 1:
      if (isWhite) {
        if (dc==0 && dr==-1 && board[to]==0) return true;
        if (dc==0 && dr==-2 && fr==6 && board[to]==0 && board[from-8]==0) return true;
        if (abs(dc)==1 && dr==-1 && board[to]!=0) return true;
      } else {
        if (dc==0 && dr==1 && board[to]==0) return true;
        if (dc==0 && dr==2 && fr==1 && board[to]==0 && board[from+8]==0) return true;
        if (abs(dc)==1 && dr==1 && board[to]!=0) return true;
      }
      return false;
    case 2: return (abs(dr)==2 && abs(dc)==1) || (abs(dr)==1 && abs(dc)==2);
    case 3: if (abs(dr)!=abs(dc)) return false; return clearPath(from,to);
    case 4: if (dr!=0 && dc!=0) return false; return clearPath(from,to);
    case 5: if (dr!=0 && dc!=0 && abs(dr)!=abs(dc)) return false; return clearPath(from,to);
    case 6: return abs(dr)<=1 && abs(dc)<=1;
  }
  return false;
}

boolean clearPath(int from, int to) {
  int fr=from/8, fc=from%8, tr=to/8, tc=to%8;
  int dr = (int)Math.signum(tr-fr);
  int dc = (int)Math.signum(tc-fc);
  int r = fr+dr, c = fc+dc;
  while (r != tr || c != tc) {
    if (board[r*8+c] != 0) return false;
    r += dr; c += dc;
  }
  return true;
}

void makeMove(int from, int to) {
  lastFrom = from;
  lastTo = to;
  
  int piece = board[from];
  if (piece == 1 && to < 8) piece = 5;
  if (piece == 7 && to > 55) piece = 11;
  
  board[to] = piece;
  board[from] = 0;
  
  boolean wK=false, bK=false;
  for (int i=0; i<64; i++) {
    if (board[i]==6) wK=true;
    if (board[i]==12) bK=true;
  }
  if (!wK) { gameOver=true; status="Black wins!"; }
  if (!bK) { gameOver=true; status="White wins!"; }
}

ArrayList<int[]> generateMoves(boolean forWhite) {
  ArrayList<int[]> list = new ArrayList<int[]>();
  for (int f=0; f<64; f++) {
    if (board[f]==0) continue;
    boolean isW = board[f] <= 6;
    if (isW != forWhite) continue;
    for (int t=0; t<64; t++) {
      if (isLegal(f, t)) list.add(new int[]{f,t});
    }
  }
  return list;
}

void keyPressed() {
  if (key=='r' || key=='R') {
    initBoard();
    chooseRandomEngine();
  }
  if (key=='1') { currentEngine=1; engineName="1 MyEngine"; }
  if (key=='2') { currentEngine=2; engineName="2 Just"; }
  if (key=='3') { currentEngine=3; engineName="3 Cuckoo"; }
  if (key=='4') { currentEngine=4; engineName="4 P4"; }
}









/*



// Chess for APDE 0.5.3
// 1 = My engine (stronger)
// 2 = Just-style
// 3 = Cuckoo-style  
// 4 = P4-style (weak + random)
// Computer randomly chooses one engine each game
// Portrait: board at bottom | Landscape: board on left
// Pieces rounded (*0.70)

int boardSize, squareSize, boardX, boardY;
boolean isPortrait;

int[] board = new int[64];
// 1-6 white (P N B R Q K), 7-12 black

color lightSq = color(240, 217, 181);
color darkSq  = color(181, 136, 99);
color whitePiece = color(250);
color blackPiece = color(40);
color selectCol = color(255, 255, 0, 140);
color lastMoveCol = color(0, 200, 255, 90);

int selected = -1;
int lastFrom = -1, lastTo = -1;
boolean whiteToMove = true;
boolean gameOver = false;
String status = "";
String engineName = "";
int currentEngine = 1;

int[] pieceVal = {0, 100, 320, 330, 500, 900, 20000};

void setup() {
  size(displayWidth, displayHeight);
  orientation(PORTRAIT);
  textAlign(CENTER, CENTER);
  initBoard();
  chooseRandomEngine();
  calculateLayout();
}

void draw() {
  background(35);
  calculateLayout();
  drawBoard();
  drawPieces();
  
  fill(230);
  textSize(16);
  if (isPortrait) {
    text(status, width/2, 28);
    text("Engine: " + engineName + "   (R=restart  1-4=select)", width/2, 52);
  } else {
    text(status, width - 110, height/2 - 20);
    text(engineName, width - 110, height/2 + 10);
  }
}

void calculateLayout() {
  isPortrait = height > width;
  if (isPortrait) {
    boardSize = min(width - 20, (int)(height * 0.72));
    squareSize = boardSize / 8;
    boardX = (width - boardSize) / 2;
    boardY = height - boardSize - 15;
  } else {
    boardSize = min(height - 20, (int)(width * 0.72));
    squareSize = boardSize / 8;
    boardX = 15;
    boardY = (height - boardSize) / 2;
  }
}

void initBoard() {
  int[] start = {
    10,8,9,11,12,9,8,10,
    7,7,7,7,7,7,7,7,
    0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,
    1,1,1,1,1,1,1,1,
    4,2,3,5,6,3,2,4
  };
  for (int i=0; i<64; i++) board[i] = start[i];
  whiteToMove = true;
  selected = -1;
  lastFrom = lastTo = -1;
  gameOver = false;
  status = "Your move (White)";
}

void chooseRandomEngine() {
  currentEngine = 1 + (int)random(4);
  if (currentEngine == 1) engineName = "1 MyEngine";
  else if (currentEngine == 2) engineName = "2 Just";
  else if (currentEngine == 3) engineName = "3 Cuckoo";
  else engineName = "4 P4";
}

void drawBoard() {
  for (int r=0; r<8; r++) {
    for (int c=0; c<8; c++) {
      int sq = r*8 + c;
      fill( ((r+c)%2==0) ? lightSq : darkSq );
      noStroke();
      rect(boardX + c*squareSize, boardY + r*squareSize, squareSize, squareSize);
      
      if (sq == lastFrom || sq == lastTo) {
        fill(lastMoveCol);
        rect(boardX + c*squareSize, boardY + r*squareSize, squareSize, squareSize);
      }
      if (sq == selected) {
        fill(selectCol);
        rect(boardX + c*squareSize, boardY + r*squareSize, squareSize, squareSize);
      }
    }
  }
}

void drawPieces() {
  for (int i=0; i<64; i++) {
    if (board[i] == 0) continue;
    int r = i / 8, c = i % 8;
    float cx = boardX + c*squareSize + squareSize*0.5;
    float cy = boardY + r*squareSize + squareSize*0.5;
    float s = squareSize * 0.70;
    
    boolean isWhite = board[i] <= 6;
    fill(isWhite ? whitePiece : blackPiece);
    stroke(isWhite ? 60 : 220);
    strokeWeight(1.8);
    
    int p = board[i] > 6 ? board[i]-6 : board[i];
    
    switch(p) {
      case 1: // Pawn round
        ellipse(cx, cy + s*0.05, s*0.55, s*0.55);
        break;
      case 2: // Knight rounded
        beginShape();
        vertex(cx, cy - s*0.38);
        quadraticVertex(cx + s*0.4, cy, cx + s*0.28, cy + s*0.35);
        quadraticVertex(cx, cy + s*0.25, cx - s*0.28, cy + s*0.35);
        quadraticVertex(cx - s*0.4, cy, cx, cy - s*0.38);
        endShape(CLOSE);
        break;
      case 3: // Bishop diamond
        beginShape();
        vertex(cx, cy - s*0.4);
        quadraticVertex(cx + s*0.32, cy, cx, cy + s*0.4);
        quadraticVertex(cx - s*0.32, cy, cx, cy - s*0.4);
        endShape(CLOSE);
        break;
      case 4: // Rook rounded rect
        rect(cx - s*0.28, cy - s*0.28, s*0.56, s*0.56, s*0.12);
        break;
      case 5: // Queen
        ellipse(cx, cy, s*0.68, s*0.68);
        strokeWeight(2.5);
        line(cx - s*0.22, cy, cx + s*0.22, cy);
        line(cx, cy - s*0.22, cx, cy + s*0.22);
        break;
      case 6: // King
        noFill();
        strokeWeight(2.2);
        ellipse(cx, cy, s*0.55, s*0.55);
        strokeWeight(3.5);
        line(cx - s*0.28, cy, cx + s*0.28, cy);
        line(cx, cy - s*0.28, cx, cy + s*0.28);
        break;
    }
  }
}

void mousePressed() {
  if (gameOver) {
    initBoard();
    chooseRandomEngine();
    return;
  }
  
  int c = (int)((mouseX - boardX) / squareSize);
  int r = (int)((mouseY - boardY) / squareSize);
  if (c < 0 || c > 7 || r < 0 || r > 7) return;
  
  int sq = r*8 + c;
  
  if (selected == -1) {
    if (board[sq] != 0 && board[sq] <= 6 && whiteToMove) {
      selected = sq;
    }
  } else {
    if (sq == selected) {
      selected = -1;
    } else if (isLegal(selected, sq)) {
      makeMove(selected, sq);
      selected = -1;
      whiteToMove = false;
      status = "Computer thinking...";
      thread("computerMoveThread");
    } else if (board[sq] != 0 && board[sq] <= 6) {
      selected = sq;
    } else {
      selected = -1;
    }
  }
}

void computerMoveThread() {
  delay(350 + (int)random(250));
  computerMove();
}

void computerMove() {
  if (gameOver) return;
  
  ArrayList<int[]> moves = generateMoves(false);
  if (moves.isEmpty()) {
    gameOver = true;
    status = "You win!";
    return;
  }
  
  int[] best = null;
  int bestScore = -999999;
  
  for (int[] m : moves) {
    int sc = 0;
    if (currentEngine == 1) sc = evalMyEngine(m[0], m[1]);
    else if (currentEngine == 2) sc = evalJust(m[0], m[1]);
    else if (currentEngine == 3) sc = evalCuckoo(m[0], m[1]);
    else sc = evalP4(m[0], m[1]);
    
    if (sc > bestScore) {
      bestScore = sc;
      best = m;
    }
  }
  
  if (best != null) makeMove(best[0], best[1]);
  
  whiteToMove = true;
  if (!gameOver) status = "Your move (White)";
}

// 1 MyEngine - strongest of the four small engines
int evalMyEngine(int from, int to) {
  int score = 0;
  int captured = board[to];
  if (captured != 0) {
    int p = captured > 6 ? captured-6 : captured;
    score += pieceVal[p] * 3;
  }
  int tr = to/8, tc = to%8;
  score += (4 - abs(3.5 - tr)) * 8 + (4 - abs(3.5 - tc)) * 8;
  if (from/8 >= 6) score += 15;
  if (board[from] == 12) score -= 40;
  score += (int)random(-25, 25);
  return score;
}

// 2 Just-style
int evalJust(int from, int to) {
  int captured = board[to];
  if (captured == 0) return (int)random(0, 40);
  int p = captured > 6 ? captured-6 : captured;
  return pieceVal[p] + (int)random(-20, 20);
}

// 3 Cuckoo-style
int evalCuckoo(int from, int to) {
  int score = 0;
  int captured = board[to];
  if (captured != 0) {
    int p = captured > 6 ? captured-6 : captured;
    score += pieceVal[p] * 2;
  }
  int tr = to/8, tc = to%8;
  score += (3 - abs(3.5-tr))*6 + (3 - abs(3.5-tc))*6;
  score += (int)random(-40, 40);
  return score;
}

// 4 P4-style (weak)
int evalP4(int from, int to) {
  int score = (int)random(-100, 120);
  int captured = board[to];
  if (captured != 0) {
    int p = captured > 6 ? captured-6 : captured;
    score += pieceVal[p] / 2;
  }
  return score;
}

boolean isLegal(int from, int to) {
  if (from < 0 || from > 63 || to < 0 || to > 63) return false;
  if (board[from] == 0) return false;
  
  boolean isWhite = board[from] <= 6;
  if (board[to] != 0) {
    boolean targetWhite = board[to] <= 6;
    if (isWhite == targetWhite) return false;
  }
  
  int piece = board[from] > 6 ? board[from]-6 : board[from];
  int fr = from/8, fc = from%8;
  int tr = to/8, tc = to%8;
  int dr = tr - fr, dc = tc - fc;
  
  switch(piece) {
    case 1:
      if (isWhite) {
        if (dc==0 && dr==-1 && board[to]==0) return true;
        if (dc==0 && dr==-2 && fr==6 && board[to]==0 && board[from-8]==0) return true;
        if (abs(dc)==1 && dr==-1 && board[to]!=0) return true;
      } else {
        if (dc==0 && dr==1 && board[to]==0) return true;
        if (dc==0 && dr==2 && fr==1 && board[to]==0 && board[from+8]==0) return true;
        if (abs(dc)==1 && dr==1 && board[to]!=0) return true;
      }
      return false;
    case 2: return (abs(dr)==2 && abs(dc)==1) || (abs(dr)==1 && abs(dc)==2);
    case 3: if (abs(dr)!=abs(dc)) return false; return clearPath(from,to);
    case 4: if (dr!=0 && dc!=0) return false; return clearPath(from,to);
    case 5: if (dr!=0 && dc!=0 && abs(dr)!=abs(dc)) return false; return clearPath(from,to);
    case 6: return abs(dr)<=1 && abs(dc)<=1;
  }
  return false;
}

boolean clearPath(int from, int to) {
  int fr=from/8, fc=from%8, tr=to/8, tc=to%8;
  int dr = (int)Math.signum(tr-fr);
  int dc = (int)Math.signum(tc-fc);
  int r = fr+dr, c = fc+dc;
  while (r != tr || c != tc) {
    if (board[r*8+c] != 0) return false;
    r += dr; c += dc;
  }
  return true;
}

void makeMove(int from, int to) {
  lastFrom = from;
  lastTo = to;
  
  int piece = board[from];
  if (piece == 1 && to < 8) piece = 5;
  if (piece == 7 && to > 55) piece = 11;
  
  board[to] = piece;
  board[from] = 0;
  
  boolean wK=false, bK=false;
  for (int i=0; i<64; i++) {
    if (board[i]==6) wK=true;
    if (board[i]==12) bK=true;
  }
  if (!wK) { gameOver=true; status="Black wins!"; }
  if (!bK) { gameOver=true; status="White wins!"; }
}

ArrayList<int[]> generateMoves(boolean forWhite) {
  ArrayList<int[]> list = new ArrayList<int[]>();
  for (int f=0; f<64; f++) {
    if (board[f]==0) continue;
    boolean isW = board[f] <= 6;
    if (isW != forWhite) continue;
    for (int t=0; t<64; t++) {
      if (isLegal(f, t)) list.add(new int[]{f,t});
    }
  }
  return list;
}

void keyPressed() {
  if (key=='r' || key=='R') {
    initBoard();
    chooseRandomEngine();
  }
  if (key=='1') { currentEngine=1; engineName="1 MyEngine"; }
  if (key=='2') { currentEngine=2; engineName="2 Just"; }
  if (key=='3') { currentEngine=3; engineName="3 Cuckoo"; }
  if (key=='4') { currentEngine=4; engineName="4 P4"; }
}








// Chess for APDE 0.5.3
// 1 = My engine (stronger)
// 2 = Just-style
// 3 = Cuckoo-style  
// 4 = P4-style (weak + random)
// Computer randomly chooses one engine each game
// Portrait: board at bottom | Landscape: board on left
// Pieces rounded (*0.70)

int boardSize, squareSize, boardX, boardY;
boolean isPortrait;

int[] board = new int[64];
// 1-6 white (P N B R Q K), 7-12 black

color lightSq = color(240, 217, 181);
color darkSq  = color(181, 136, 99);
color whitePiece = color(250);
color blackPiece = color(40);
color selectCol = color(255, 255, 0, 140);
color lastMoveCol = color(0, 200, 255, 90);

int selected = -1;
int lastFrom = -1, lastTo = -1;
boolean whiteToMove = true;
boolean gameOver = false;
String status = "";
String engineName = "";
int currentEngine = 1;

int[] pieceVal = {0, 100, 320, 330, 500, 900, 20000};

void setup() {
  size(displayWidth, displayHeight);
  orientation(PORTRAIT);
  textAlign(CENTER, CENTER);
  initBoard();
  chooseRandomEngine();
  calculateLayout();
}

void draw() {
  background(35);
  calculateLayout();
  drawBoard();
  drawPieces();
  
  fill(230);
  textSize(16);
  if (isPortrait) {
    text(status, width/2, 28);
    text("Engine: " + engineName + "   (R=restart  1-4=select)", width/2, 52);
  } else {
    text(status, width - 110, height/2 - 20);
    text(engineName, width - 110, height/2 + 10);
  }
}

void calculateLayout() {
  isPortrait = height > width;
  if (isPortrait) {
    boardSize = min(width - 20, (int)(height * 0.72));
    squareSize = boardSize / 8;
    boardX = (width - boardSize) / 2;
    boardY = height - boardSize - 15;
  } else {
    boardSize = min(height - 20, (int)(width * 0.72));
    squareSize = boardSize / 8;
    boardX = 15;
    boardY = (height - boardSize) / 2;
  }
}

void initBoard() {
  int[] start = {
    10,8,9,11,12,9,8,10,
    7,7,7,7,7,7,7,7,
    0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,
    1,1,1,1,1,1,1,1,
    4,2,3,5,6,3,2,4
  };
  for (int i=0; i<64; i++) board[i] = start[i];
  whiteToMove = true;
  selected = -1;
  lastFrom = lastTo = -1;
  gameOver = false;
  status = "Your move (White)";
}

void chooseRandomEngine() {
  currentEngine = 1 + (int)random(4);
  if (currentEngine == 1) engineName = "1 MyEngine";
  else if (currentEngine == 2) engineName = "2 Just";
  else if (currentEngine == 3) engineName = "3 Cuckoo";
  else engineName = "4 P4";
}

void drawBoard() {
  for (int r=0; r<8; r++) {
    for (int c=0; c<8; c++) {
      int sq = r*8 + c;
      fill( ((r+c)%2==0) ? lightSq : darkSq );
      noStroke();
      rect(boardX + c*squareSize, boardY + r*squareSize, squareSize, squareSize);
      
      if (sq == lastFrom || sq == lastTo) {
        fill(lastMoveCol);
        rect(boardX + c*squareSize, boardY + r*squareSize, squareSize, squareSize);
      }
      if (sq == selected) {
        fill(selectCol);
        rect(boardX + c*squareSize, boardY + r*squareSize, squareSize, squareSize);
      }
    }
  }
}

void drawPieces() {
  for (int i=0; i<64; i++) {
    if (board[i] == 0) continue;
    int r = i / 8, c = i % 8;
    float cx = boardX + c*squareSize + squareSize*0.5;
    float cy = boardY + r*squareSize + squareSize*0.5;
    float s = squareSize * 0.70;
    
    boolean isWhite = board[i] <= 6;
    fill(isWhite ? whitePiece : blackPiece);
    stroke(isWhite ? 60 : 220);
    strokeWeight(1.8);
    
    int p = board[i] > 6 ? board[i]-6 : board[i];
    
    switch(p) {
      case 1: // Pawn round
        ellipse(cx, cy + s*0.05, s*0.55, s*0.55);
        break;
      case 2: // Knight rounded
        beginShape();
        vertex(cx, cy - s*0.38);
        quadraticVertex(cx + s*0.4, cy, cx + s*0.28, cy + s*0.35);
        quadraticVertex(cx, cy + s*0.25, cx - s*0.28, cy + s*0.35);
        quadraticVertex(cx - s*0.4, cy, cx, cy - s*0.38);
        endShape(CLOSE);
        break;
      case 3: // Bishop diamond
        beginShape();
        vertex(cx, cy - s*0.4);
        quadraticVertex(cx + s*0.32, cy, cx, cy + s*0.4);
        quadraticVertex(cx - s*0.32, cy, cx, cy - s*0.4);
        endShape(CLOSE);
        break;
      case 4: // Rook rounded rect
        rect(cx - s*0.28, cy - s*0.28, s*0.56, s*0.56, s*0.12);
        break;
      case 5: // Queen
        ellipse(cx, cy, s*0.68, s*0.68);
        strokeWeight(2.5);
        line(cx - s*0.22, cy, cx + s*0.22, cy);
        line(cx, cy - s*0.22, cx, cy + s*0.22);
        break;
      case 6: // King
        noFill();
        strokeWeight(2.2);
        ellipse(cx, cy, s*0.55, s*0.55);
        strokeWeight(3.5);
        line(cx - s*0.28, cy, cx + s*0.28, cy);
        line(cx, cy - s*0.28, cx, cy + s*0.28);
        break;
    }
  }
}

void mousePressed() {
  if (gameOver) {
    initBoard();
    chooseRandomEngine();
    return;
  }
  
  int c = (int)((mouseX - boardX) / squareSize);
  int r = (int)((mouseY - boardY) / squareSize);
  if (c < 0 || c > 7 || r < 0 || r > 7) return;
  
  int sq = r*8 + c;
  
  if (selected == -1) {
    if (board[sq] != 0 && board[sq] <= 6 && whiteToMove) {
      selected = sq;
    }
  } else {
    if (sq == selected) {
      selected = -1;
    } else if (isLegal(selected, sq)) {
      makeMove(selected, sq);
      selected = -1;
      whiteToMove = false;
      status = "Computer thinking...";
      thread("computerMoveThread");
    } else if (board[sq] != 0 && board[sq] <= 6) {
      selected = sq;
    } else {
      selected = -1;
    }
  }
}

void computerMoveThread() {
  delay(350 + (int)random(250));
  computerMove();
}

void computerMove() {
  if (gameOver) return;
  
  ArrayList<int[]> moves = generateMoves(false);
  if (moves.isEmpty()) {
    gameOver = true;
    status = "You win!";
    return;
  }
  
  int[] best = null;
  int bestScore = -999999;
  
  for (int[] m : moves) {
    int sc = 0;
    if (currentEngine == 1) sc = evalMyEngine(m[0], m[1]);
    else if (currentEngine == 2) sc = evalJust(m[0], m[1]);
    else if (currentEngine == 3) sc = evalCuckoo(m[0], m[1]);
    else sc = evalP4(m[0], m[1]);
    
    if (sc > bestScore) {
      bestScore = sc;
      best = m;
    }
  }
  
  if (best != null) makeMove(best[0], best[1]);
  
  whiteToMove = true;
  if (!gameOver) status = "Your move (White)";
}

// 1 MyEngine - strongest of the four small engines
int evalMyEngine(int from, int to) {
  int score = 0;
  int captured = board[to];
  if (captured != 0) {
    int p = captured > 6 ? captured-6 : captured;
    score += pieceVal[p] * 3;
  }
  int tr = to/8, tc = to%8;
  score += (4 - abs(3.5 - tr)) * 8 + (4 - abs(3.5 - tc)) * 8;
  if (from/8 >= 6) score += 15;
  if (board[from] == 12) score -= 40;
  score += (int)random(-25, 25);
  return score;
}

// 2 Just-style
int evalJust(int from, int to) {
  int captured = board[to];
  if (captured == 0) return (int)random(0, 40);
  int p = captured > 6 ? captured-6 : captured;
  return pieceVal[p] + (int)random(-20, 20);
}

// 3 Cuckoo-style
int evalCuckoo(int from, int to) {
  int score = 0;
  int captured = board[to];
  if (captured != 0) {
    int p = captured > 6 ? captured-6 : captured;
    score += pieceVal[p] * 2;
  }
  int tr = to/8, tc = to%8;
  score += (3 - abs(3.5-tr))*6 + (3 - abs(3.5-tc))*6;
  score += (int)random(-40, 40);
  return score;
}

// 4 P4-style (weak)
int evalP4(int from, int to) {
  int score = (int)random(-100, 120);
  int captured = board[to];
  if (captured != 0) {
    int p = captured > 6 ? captured-6 : captured;
    score += pieceVal[p] / 2;
  }
  return score;
}

boolean isLegal(int from, int to) {
  if (from < 0 || from > 63 || to < 0 || to > 63) return false;
  if (board[from] == 0) return false;
  
  boolean isWhite = board[from] <= 6;
  if (board[to] != 0) {
    boolean targetWhite = board[to] <= 6;
    if (isWhite == targetWhite) return false;
  }
  
  int piece = board[from] > 6 ? board[from]-6 : board[from];
  int fr = from/8, fc = from%8;
  int tr = to/8, tc = to%8;
  int dr = tr - fr, dc = tc - fc;
  
  switch(piece) {
    case 1:
      if (isWhite) {
        if (dc==0 && dr==-1 && board[to]==0) return true;
        if (dc==0 && dr==-2 && fr==6 && board[to]==0 && board[from-8]==0) return true;
        if (abs(dc)==1 && dr==-1 && board[to]!=0) return true;
      } else {
        if (dc==0 && dr==1 && board[to]==0) return true;
        if (dc==0 && dr==2 && fr==1 && board[to]==0 && board[from+8]==0) return true;
        if (abs(dc)==1 && dr==1 && board[to]!=0) return true;
      }
      return false;
    case 2: return (abs(dr)==2 && abs(dc)==1) || (abs(dr)==1 && abs(dc)==2);
    case 3: if (abs(dr)!=abs(dc)) return false; return clearPath(from,to);
    case 4: if (dr!=0 && dc!=0) return false; return clearPath(from,to);
    case 5: if (dr!=0 && dc!=0 && abs(dr)!=abs(dc)) return false; return clearPath(from,to);
    case 6: return abs(dr)<=1 && abs(dc)<=1;
  }
  return false;
}

boolean clearPath(int from, int to) {
  int fr=from/8, fc=from%8, tr=to/8, tc=to%8;
  int dr = (int)Math.signum(tr-fr);
  int dc = (int)Math.signum(tc-fc);
  int r = fr+dr, c = fc+dc;
  while (r != tr || c != tc) {
    if (board[r*8+c] != 0) return false;
    r += dr; c += dc;
  }
  return true;
}

void makeMove(int from, int to) {
  lastFrom = from;
  lastTo = to;
  
  int piece = board[from];
  if (piece == 1 && to < 8) piece = 5;
  if (piece == 7 && to > 55) piece = 11;
  
  board[to] = piece;
  board[from] = 0;
  
  boolean wK=false, bK=false;
  for (int i=0; i<64; i++) {
    if (board[i]==6) wK=true;
    if (board[i]==12) bK=true;
  }
  if (!wK) { gameOver=true; status="Black wins!"; }
  if (!bK) { gameOver=true; status="White wins!"; }
}

ArrayList<int[]> generateMoves(boolean forWhite) {
  ArrayList<int[]> list = new ArrayList<int[]>();
  for (int f=0; f<64; f++) {
    if (board[f]==0) continue;
    boolean isW = board[f] <= 6;
    if (isW != forWhite) continue;
    for (int t=0; t<64; t++) {
      if (isLegal(f, t)) list.add(new int[]{f,t});
    }
  }
  return list;
}

void keyPressed() {
  if (key=='r' || key=='R') {
    initBoard();
    chooseRandomEngine();
  }
  if (key=='1') { currentEngine=1; engineName="1 MyEngine"; }
  if (key=='2') { currentEngine=2; engineName="2 Just"; }
  if (key=='3') { currentEngine=3; engineName="3 Cuckoo"; }
  if (key=='4') { currentEngine=4; engineName="4 P4"; }
}



















*/








