






///////PPP444AAAWWWNNN. JJJJSSSS///////GROK////
/**
 * Chess Board + Engine  –  single file for APDE 0.5.3 (Android 9)
 *
 * Features:
 *  - Graphical chess board with Unicode pieces
 *  - Human plays White, simple alpha-beta engine plays Black
 *  - Touch to select piece then destination
 *  - New Game / Force Engine Move buttons
 *
 * Open this single .pde in APDE → Android mode → Run.
 * Tested conceptually for Android 9 / APDE 0.5.3.
 *
 * Engine inspired by the classic p4wn ideas (public domain)
 * but re-implemented in pure Processing/Java for APDE compatibility.
 */

int SQUARE;
int BOARD_X, BOARD_Y;
int selected = -1;          // 0..63 or -1
boolean whiteTurn = true;
boolean thinking = false;
String status = "White to move – tap a piece";
int[] board = new int[64];  // 0 empty, 1-6 white, 9-14 black (same encoding as many engines)

// Piece values for evaluation
final int[] PIECE_VAL = {0, 100, 320, 330, 500, 900, 20000};

// Simple piece-square tables (midgame, from white's view)
final int[] PST_P = {
  0,0,0,0,0,0,0,0, 50,50,50,50,50,50,50,50,
  10,10,20,30,30,20,10,10, 5,5,10,25,25,10,5,5,
  0,0,0,20,20,0,0,0, 5,-5,-10,0,0,-10,-5,5,
  5,10,10,-20,-20,10,10,5, 0,0,0,0,0,0,0,0
};
final int[] PST_N = {
  -50,-40,-30,-30,-30,-30,-40,-50, -40,-20,0,0,0,0,-20,-40,
  -30,0,10,15,15,10,0,-30, -30,5,15,20,20,15,5,-30,
  -30,0,15,20,20,15,0,-30, -30,5,10,15,15,10,5,-30,
  -40,-20,0,5,5,0,-20,-40, -50,-40,-30,-30,-30,-30,-40,-50
};
final int[] PST_B = {
  -20,-10,-10,-10,-10,-10,-10,-20, -10,0,0,0,0,0,0,-10,
  -10,0,5,10,10,5,0,-10, -10,5,5,10,10,5,5,-10,
  -10,0,10,10,10,10,0,-10, -10,10,10,10,10,10,10,-10,
  -10,5,0,0,0,0,5,-10, -20,-10,-10,-10,-10,-10,-10,-20
};
final int[] PST_R = {
  0,0,0,0,0,0,0,0, 5,10,10,10,10,10,10,5,
  -5,0,0,0,0,0,0,-5, -5,0,0,0,0,0,0,-5,
  -5,0,0,0,0,0,0,-5, -5,0,0,0,0,0,0,-5,
  -5,0,0,0,0,0,0,-5, 0,0,0,5,5,0,0,0
};
final int[] PST_Q = {
  -20,-10,-10,-5,-5,-10,-10,-20, -10,0,0,0,0,0,0,-10,
  -10,0,5,5,5,5,0,-10, -5,0,5,5,5,5,0,-5,
  0,0,5,5,5,5,0,-5, -10,5,5,5,5,5,0,-10,
  -10,0,5,0,0,0,0,-10, -20,-10,-10,-5,-5,-10,-10,-20
};
final int[] PST_K = {
  -30,-40,-40,-50,-50,-40,-40,-30, -30,-40,-40,-50,-50,-40,-40,-30,
  -30,-40,-40,-50,-50,-40,-40,-30, -30,-40,-40,-50,-50,-40,-40,-30,
  -20,-30,-30,-40,-40,-30,-30,-20, -10,-20,-20,-20,-20,-20,-20,-10,
  20,20,0,0,0,0,20,20, 20,30,10,0,0,10,30,20
};

void setup() {
  fullScreen();
  orientation(PORTRAIT);
  textAlign(CENTER, CENTER);
  resetGame();
}

void draw() {
  background(30, 32, 40);
  
  // Layout
  int topBar = 80;
  int bottomBar = 140;
  SQUARE = min((width - 40) / 8, (height - topBar - bottomBar) / 8);
  BOARD_X = (width - SQUARE * 8) / 2;
  BOARD_Y = topBar + 20;
  
  // Title
  fill(220);
  textSize(32);
  text("Chess + Engine (APDE)", width/2, 40);
  
  // Board
  for (int r = 0; r < 8; r++) {
    for (int c = 0; c < 8; c++) {
      int sq = r * 8 + c;
      boolean light = ((r + c) & 1) == 0;
      fill(light ? color(235, 210, 170) : color(160, 110, 70));
      noStroke();
      rect(BOARD_X + c * SQUARE, BOARD_Y + r * SQUARE, SQUARE, SQUARE);
      
      if (sq == selected) {
        fill(255, 255, 0, 120);
        rect(BOARD_X + c * SQUARE, BOARD_Y + r * SQUARE, SQUARE, SQUARE);
      }
      
      int p = board[sq];
      if (p != 0) {
        drawPiece(p, BOARD_X + c * SQUARE + SQUARE/2, BOARD_Y + r * SQUARE + SQUARE/2, SQUARE);
      }
    }
  }
  
  // Status
  fill(thinking ? color(255, 200, 80) : color(210));
  textSize(26);
  text(status, width/2, height - 100);
  
  // Buttons
  drawBtn(width/2 - 210, height - 70, 190, 55, "New Game");
  drawBtn(width/2 + 20,  height - 70, 190, 55, "Engine Move");
}

void drawBtn(float x, float y, float w, float h, String label) {
  fill(55, 90, 140);
  rect(x, y, w, h, 14);
  fill(255);
  textSize(24);
  text(label, x + w/2, y + h/2);
}

void drawPiece(int p, float x, float y, float s) {
  boolean white = p < 8;
  fill(white ? 250 : 30);
  textSize(s * 0.75);
  String sym = "";
  switch (p & 7) {
    case 1: sym = white ? "\u2659" : "\u265F"; break; // P
    case 2: sym = white ? "\u2658" : "\u265E"; break; // N
    case 3: sym = white ? "\u2657" : "\u265D"; break; // B
    case 4: sym = white ? "\u2656" : "\u265C"; break; // R
    case 5: sym = white ? "\u2655" : "\u265B"; break; // Q
    case 6: sym = white ? "\u2654" : "\u265A"; break; // K
  }
  text(sym, x, y);
}

void mousePressed() {
  // Buttons
  if (mouseY > height - 80) {
    if (mouseX > width/2 - 210 && mouseX < width/2 - 20) {
      resetGame();
      return;
    }
    if (mouseX > width/2 + 20 && mouseX < width/2 + 210) {
      if (!thinking && !whiteTurn) {
        // already black's turn
      } else if (!thinking) {
        // force engine even if white to move (demo)
        thinking = true;
        status = "Engine thinking…";
        thread("engineMoveThread");
      }
      return;
    }
  }
  
  if (thinking) return;
  
  int c = (mouseX - BOARD_X) / SQUARE;
  int r = (mouseY - BOARD_Y) / SQUARE;
  if (c < 0 || c > 7 || r < 0 || r > 7) return;
  int sq = r * 8 + c;
  
  if (selected == -1) {
    int p = board[sq];
    if (p != 0 && ((p < 8) == whiteTurn)) {
      selected = sq;
    }
  } else {
    if (sq == selected) {
      selected = -1;
    } else {
      if (tryMove(selected, sq)) {
        selected = -1;
        whiteTurn = false;
        status = "Black (engine) thinking…";
        thinking = true;
        thread("engineMoveThread");
      } else {
        // reselect if own piece
        int p = board[sq];
        if (p != 0 && ((p < 8) == whiteTurn)) selected = sq;
        else selected = -1;
      }
    }
  }
}

void resetGame() {
  // Standard starting position (index 0 = a8)
  // 1=P 2=N 3=B 4=R 5=Q 6=K ; +8 for black
  board = new int[] {
    12,10,11,13,14,11,10,12,   // rank 8
     9, 9, 9, 9, 9, 9, 9, 9,   // rank 7
     0, 0, 0, 0, 0, 0, 0, 0,
     0, 0, 0, 0, 0, 0, 0, 0,
     0, 0, 0, 0, 0, 0, 0, 0,
     0, 0, 0, 0, 0, 0, 0, 0,
     1, 1, 1, 1, 1, 1, 1, 1,   // rank 2
     4, 2, 3, 5, 6, 3, 2, 4    // rank 1
  };
  whiteTurn = true;
  selected = -1;
  thinking = false;
  status = "White to move – tap a piece";
}

boolean tryMove(int from, int to) {
  // Extremely simplified legality – only basic non-capture / capture of opposite
  // A full legal-move generator is longer; this is a playable demo.
  int p = board[from];
  if (p == 0) return false;
  int target = board[to];
  boolean white = p < 8;
  if (target != 0 && ((target < 8) == white)) return false; // same color
  
  // Accept the move (no full validation for brevity – improve later)
  board[to] = p;
  board[from] = 0;
  
  // Auto-promote
  if ((p == 1 && to < 8) || (p == 9 && to >= 56)) {
    board[to] = white ? 5 : 13; // queen
  }
  return true;
}

// ============== Simple Engine (alpha-beta, depth 3) ==============
void engineMoveThread() {
  int bestFrom = -1, bestTo = -1;
  int bestScore = whiteTurn ? -999999 : 999999;
  int depth = 3;
  
  // Generate all pseudo-legal moves for the side to move
  ArrayList<int[]> moves = generateMoves(whiteTurn);
  
  for (int[] m : moves) {
    int from = m[0], to = m[1];
    int captured = board[to];
    int piece = board[from];
    board[to] = piece;
    board[from] = 0;
    
    // promote
    boolean promoted = false;
    if ((piece == 1 && to < 8) || (piece == 9 && to >= 56)) {
      board[to] = (piece < 8) ? 5 : 13;
      promoted = true;
    }
    
    int score = alphabeta(depth - 1, !whiteTurn, -999999, 999999);
    
    // undo
    board[from] = piece;
    board[to] = captured;
    
    if (whiteTurn) {
      if (score > bestScore) { bestScore = score; bestFrom = from; bestTo = to; }
    } else {
      if (score < bestScore) { bestScore = score; bestFrom = from; bestTo = to; }
    }
  }
  
  // Apply best move on main thread
  final int f = bestFrom, t = bestTo;
  final int sc = bestScore;
  // Processing Android: use handler-like via redraw / variables
  if (f >= 0) {
    int captured = board[t];
    int piece = board[f];
    board[t] = piece;
    board[f] = 0;
    if ((piece == 1 && t < 8) || (piece == 9 && t >= 56)) {
      board[t] = (piece < 8) ? 5 : 13;
    }
    whiteTurn = !whiteTurn;
    status = whiteTurn ? "White to move" : "Black to move";
  } else {
    status = "No moves – game over?";
  }
  thinking = false;
}

int alphabeta(int depth, boolean maximizing, int alpha, int beta) {
  if (depth == 0) return evaluate();
  
  ArrayList<int[]> moves = generateMoves(maximizing);
  if (moves.isEmpty()) return maximizing ? -100000 : 100000; // checkmate-ish
  
  if (maximizing) {
    int maxEval = -999999;
    for (int[] m : moves) {
      int from = m[0], to = m[1];
      int captured = board[to];
      int piece = board[from];
      board[to] = piece;
      board[from] = 0;
      if ((piece == 1 && to < 8) || (piece == 9 && to >= 56)) board[to] = 5;
      
      int eval = alphabeta(depth - 1, false, alpha, beta);
      
      board[from] = piece;
      board[to] = captured;
      
      maxEval = max(maxEval, eval);
      alpha = max(alpha, eval);
      if (beta <= alpha) break;
    }
    return maxEval;
  } else {
    int minEval = 999999;
    for (int[] m : moves) {
      int from = m[0], to = m[1];
      int captured = board[to];
      int piece = board[from];
      board[to] = piece;
      board[from] = 0;
      if ((piece == 9 && to >= 56) || (piece == 1 && to < 8)) board[to] = 13;
      
      int eval = alphabeta(depth - 1, true, alpha, beta);
      
      board[from] = piece;
      board[to] = captured;
      
      minEval = min(minEval, eval);
      beta = min(beta, eval);
      if (beta <= alpha) break;
    }
    return minEval;
  }
}

int evaluate() {
  int score = 0;
  for (int sq = 0; sq < 64; sq++) {
    int p = board[sq];
    if (p == 0) continue;
    boolean white = p < 8;
    int type = p & 7;
    int val = PIECE_VAL[type];
    int pst = 0;
    int idx = white ? sq : (63 - sq);
    switch (type) {
      case 1: pst = PST_P[idx]; break;
      case 2: pst = PST_N[idx]; break;
      case 3: pst = PST_B[idx]; break;
      case 4: pst = PST_R[idx]; break;
      case 5: pst = PST_Q[idx]; break;
      case 6: pst = PST_K[idx]; break;
    }
    if (white) score += val + pst;
    else score -= val + pst;
  }
  return score;
}

ArrayList<int[]> generateMoves(boolean forWhite) {
  ArrayList<int[]> list = new ArrayList<int[]>();
  for (int from = 0; from < 64; from++) {
    int p = board[from];
    if (p == 0) continue;
    if ((p < 8) != forWhite) continue;
    
    int type = p & 7;
    int r = from / 8, c = from % 8;
    
    if (type == 1) { // pawn
      int dir = forWhite ? -1 : 1;
      int nr = r + dir;
      if (nr >= 0 && nr < 8) {
        int to = nr * 8 + c;
        if (board[to] == 0) {
          list.add(new int[]{from, to});
          // double step
          if ((forWhite && r == 6) || (!forWhite && r == 1)) {
            int nr2 = r + 2 * dir;
            int to2 = nr2 * 8 + c;
            if (board[to2] == 0) list.add(new int[]{from, to2});
          }
        }
        // captures
        for (int dc = -1; dc <= 1; dc += 2) {
          int nc = c + dc;
          if (nc >= 0 && nc < 8) {
            int toC = nr * 8 + nc;
            int t = board[toC];
            if (t != 0 && ((t < 8) != forWhite)) list.add(new int[]{from, toC});
          }
        }
      }
    } else if (type == 2) { // knight
      int[][] deltas = {{-2,-1},{-2,1},{-1,-2},{-1,2},{1,-2},{1,2},{2,-1},{2,1}};
      for (int[] d : deltas) {
        int nr = r + d[0], nc = c + d[1];
        if (nr >= 0 && nr < 8 && nc >= 0 && nc < 8) {
          int to = nr * 8 + nc;
          int t = board[to];
          if (t == 0 || ((t < 8) != forWhite)) list.add(new int[]{from, to});
        }
      }
    } else if (type == 3 || type == 4 || type == 5) { // B R Q
      int[][] dirs;
      if (type == 3) dirs = new int[][]{{-1,-1},{-1,1},{1,-1},{1,1}};
      else if (type == 4) dirs = new int[][]{{-1,0},{1,0},{0,-1},{0,1}};
      else dirs = new int[][]{{-1,-1},{-1,1},{1,-1},{1,1},{-1,0},{1,0},{0,-1},{0,1}};
      
      for (int[] d : dirs) {
        int nr = r + d[0], nc = c + d[1];
        while (nr >= 0 && nr < 8 && nc >= 0 && nc < 8) {
          int to = nr * 8 + nc;
          int t = board[to];
          if (t == 0) {
            list.add(new int[]{from, to});
          } else {
            if ((t < 8) != forWhite) list.add(new int[]{from, to});
            break;
          }
          nr += d[0]; nc += d[1];
        }
      }
    } else if (type == 6) { // king
      for (int dr = -1; dr <= 1; dr++) {
        for (int dc = -1; dc <= 1; dc++) {
          if (dr == 0 && dc == 0) continue;
          int nr = r + dr, nc = c + dc;
          if (nr >= 0 && nr < 8 && nc >= 0 && nc < 8) {
            int to = nr * 8 + nc;
            int t = board[to];
            if (t == 0 || ((t < 8) != forWhite)) list.add(new int[]{from, to});
          }
        }
      }
    }
  }
  return list;
}

/*
*/


/*


*/



/**
 * Chess Board + Engine  –  single file for APDE 0.5.3 (Android 9)
 *
 * Features:
 *  - Graphical chess board with Unicode pieces
 *  - Human plays White, simple alpha-beta engine plays Black
 *  - Touch to select piece then destination
 *  - New Game / Force Engine Move buttons
 *
 * Open this single .pde in APDE → Android mode → Run.
 * Tested conceptually for Android 9 / APDE 0.5.3.
 *
 * Engine inspired by the classic p4wn ideas (public domain)
 * but re-implemented in pure Processing/Java for APDE compatibility.
 */


/*

.

int SQUARE;
int BOARD_X, BOARD_Y;
int selected = -1;          // 0..63 or -1
boolean whiteTurn = true;
boolean thinking = false;
String status = "White to move – tap a piece";
int[] board = new int[64];  // 0 empty, 1-6 white, 9-14 black (same encoding as many engines)

// Piece values for evaluation
final int[] PIECE_VAL = {0, 100, 320, 330, 500, 900, 20000};

// Simple piece-square tables (midgame, from white's view)
final int[] PST_P = {
  0,0,0,0,0,0,0,0, 50,50,50,50,50,50,50,50,
  10,10,20,30,30,20,10,10, 5,5,10,25,25,10,5,5,
  0,0,0,20,20,0,0,0, 5,-5,-10,0,0,-10,-5,5,
  5,10,10,-20,-20,10,10,5, 0,0,0,0,0,0,0,0
};
final int[] PST_N = {
  -50,-40,-30,-30,-30,-30,-40,-50, -40,-20,0,0,0,0,-20,-40,
  -30,0,10,15,15,10,0,-30, -30,5,15,20,20,15,5,-30,
  -30,0,15,20,20,15,0,-30, -30,5,10,15,15,10,5,-30,
  -40,-20,0,5,5,0,-20,-40, -50,-40,-30,-30,-30,-30,-40,-50
};
final int[] PST_B = {
  -20,-10,-10,-10,-10,-10,-10,-20, -10,0,0,0,0,0,0,-10,
  -10,0,5,10,10,5,0,-10, -10,5,5,10,10,5,5,-10,
  -10,0,10,10,10,10,0,-10, -10,10,10,10,10,10,10,-10,
  -10,5,0,0,0,0,5,-10, -20,-10,-10,-10,-10,-10,-10,-20
};
final int[] PST_R = {
  0,0,0,0,0,0,0,0, 5,10,10,10,10,10,10,5,
  -5,0,0,0,0,0,0,-5, -5,0,0,0,0,0,0,-5,
  -5,0,0,0,0,0,0,-5, -5,0,0,0,0,0,0,-5,
  -5,0,0,0,0,0,0,-5, 0,0,0,5,5,0,0,0
};
final int[] PST_Q = {
  -20,-10,-10,-5,-5,-10,-10,-20, -10,0,0,0,0,0,0,-10,
  -10,0,5,5,5,5,0,-10, -5,0,5,5,5,5,0,-5,
  0,0,5,5,5,5,0,-5, -10,5,5,5,5,5,0,-10,
  -10,0,5,0,0,0,0,-10, -20,-10,-10,-5,-5,-10,-10,-20
};
final int[] PST_K = {
  -30,-40,-40,-50,-50,-40,-40,-30, -30,-40,-40,-50,-50,-40,-40,-30,
  -30,-40,-40,-50,-50,-40,-40,-30, -30,-40,-40,-50,-50,-40,-40,-30,
  -20,-30,-30,-40,-40,-30,-30,-20, -10,-20,-20,-20,-20,-20,-20,-10,
  20,20,0,0,0,0,20,20, 20,30,10,0,0,10,30,20
};

void setup() {
  fullScreen();
  orientation(PORTRAIT);
  textAlign(CENTER, CENTER);
  resetGame();
}

void draw() {
  background(30, 32, 40);
  
  // Layout
  int topBar = 80;
  int bottomBar = 140;
  SQUARE = min((width - 40) / 8, (height - topBar - bottomBar) / 8);
  BOARD_X = (width - SQUARE * 8) / 2;
  BOARD_Y = topBar + 20;
  
  // Title
  fill(220);
  textSize(32);
  text("Chess + Engine (APDE)", width/2, 40);
  
  // Board
  for (int r = 0; r < 8; r++) {
    for (int c = 0; c < 8; c++) {
      int sq = r * 8 + c;
      boolean light = ((r + c) & 1) == 0;
      fill(light ? color(235, 210, 170) : color(160, 110, 70));
      noStroke();
      rect(BOARD_X + c * SQUARE, BOARD_Y + r * SQUARE, SQUARE, SQUARE);
      
      if (sq == selected) {
        fill(255, 255, 0, 120);
        rect(BOARD_X + c * SQUARE, BOARD_Y + r * SQUARE, SQUARE, SQUARE);
      }
      
      int p = board[sq];
      if (p != 0) {
        drawPiece(p, BOARD_X + c * SQUARE + SQUARE/2, BOARD_Y + r * SQUARE + SQUARE/2, SQUARE);
      }
    }
  }
  
  // Status
  fill(thinking ? color(255, 200, 80) : color(210));
  textSize(26);
  text(status, width/2, height - 100);
  
  // Buttons
  drawBtn(width/2 - 210, height - 70, 190, 55, "New Game");
  drawBtn(width/2 + 20,  height - 70, 190, 55, "Engine Move");
}

void drawBtn(float x, float y, float w, float h, String label) {
  fill(55, 90, 140);
  rect(x, y, w, h, 14);
  fill(255);
  textSize(24);
  text(label, x + w/2, y + h/2);
}

void drawPiece(int p, float x, float y, float s) {
  boolean white = p < 8;
  fill(white ? 250 : 30);
  textSize(s * 0.75);
  String sym = "";
  switch (p & 7) {
    case 1: sym = white ? "\u2659" : "\u265F"; break; // P
    case 2: sym = white ? "\u2658" : "\u265E"; break; // N
    case 3: sym = white ? "\u2657" : "\u265D"; break; // B
    case 4: sym = white ? "\u2656" : "\u265C"; break; // R
    case 5: sym = white ? "\u2655" : "\u265B"; break; // Q
    case 6: sym = white ? "\u2654" : "\u265A"; break; // K
  }
  text(sym, x, y);
}

void mousePressed() {
  // Buttons
  if (mouseY > height - 80) {
    if (mouseX > width/2 - 210 && mouseX < width/2 - 20) {
      resetGame();
      return;
    }
    if (mouseX > width/2 + 20 && mouseX < width/2 + 210) {
      if (!thinking && !whiteTurn) {
        // already black's turn
      } else if (!thinking) {
        // force engine even if white to move (demo)
        thinking = true;
        status = "Engine thinking…";
        thread("engineMoveThread");
      }
      return;
    }
  }
  
  if (thinking) return;
  
  int c = (mouseX - BOARD_X) / SQUARE;
  int r = (mouseY - BOARD_Y) / SQUARE;
  if (c < 0 || c > 7 || r < 0 || r > 7) return;
  int sq = r * 8 + c;
  
  if (selected == -1) {
    int p = board[sq];
    if (p != 0 && ((p < 8) == whiteTurn)) {
      selected = sq;
    }
  } else {
    if (sq == selected) {
      selected = -1;
    } else {
      if (tryMove(selected, sq)) {
        selected = -1;
        whiteTurn = false;
        status = "Black (engine) thinking…";
        thinking = true;
        thread("engineMoveThread");
      } else {
        // reselect if own piece
        int p = board[sq];
        if (p != 0 && ((p < 8) == whiteTurn)) selected = sq;
        else selected = -1;
      }
    }
  }
}

void resetGame() {
  // Standard starting position (index 0 = a8)
  // 1=P 2=N 3=B 4=R 5=Q 6=K ; +8 for black
  board = new int[] {
    12,10,11,13,14,11,10,12,   // rank 8
     9, 9, 9, 9, 9, 9, 9, 9,   // rank 7
     0, 0, 0, 0, 0, 0, 0, 0,
     0, 0, 0, 0, 0, 0, 0, 0,
     0, 0, 0, 0, 0, 0, 0, 0,
     0, 0, 0, 0, 0, 0, 0, 0,
     1, 1, 1, 1, 1, 1, 1, 1,   // rank 2
     4, 2, 3, 5, 6, 3, 2, 4    // rank 1
  };
  whiteTurn = true;
  selected = -1;
  thinking = false;
  status = "White to move – tap a piece";
}

boolean tryMove(int from, int to) {
  // Extremely simplified legality – only basic non-capture / capture of opposite
  // A full legal-move generator is longer; this is a playable demo.
  int p = board[from];
  if (p == 0) return false;
  int target = board[to];
  boolean white = p < 8;
  if (target != 0 && ((target < 8) == white)) return false; // same color
  
  // Accept the move (no full validation for brevity – improve later)
  board[to] = p;
  board[from] = 0;
  
  // Auto-promote
  if ((p == 1 && to < 8) || (p == 9 && to >= 56)) {
    board[to] = white ? 5 : 13; // queen
  }
  return true;
}

// ============== Simple Engine (alpha-beta, depth 3) ==============
void engineMoveThread() {
  int bestFrom = -1, bestTo = -1;
  int bestScore = whiteTurn ? -999999 : 999999;
  int depth = 3;
  
  // Generate all pseudo-legal moves for the side to move
  ArrayList<int[]> moves = generateMoves(whiteTurn);
  
  for (int[] m : moves) {
    int from = m[0], to = m[1];
    int captured = board[to];
    int piece = board[from];
    board[to] = piece;
    board[from] = 0;
    
    // promote
    boolean promoted = false;
    if ((piece == 1 && to < 8) || (piece == 9 && to >= 56)) {
      board[to] = (piece < 8) ? 5 : 13;
      promoted = true;
    }
    
    int score = alphabeta(depth - 1, !whiteTurn, -999999, 999999);
    
    // undo
    board[from] = piece;
    board[to] = captured;
    
    if (whiteTurn) {
      if (score > bestScore) { bestScore = score; bestFrom = from; bestTo = to; }
    } else {
      if (score < bestScore) { bestScore = score; bestFrom = from; bestTo = to; }
    }
  }
  
  // Apply best move on main thread
  final int f = bestFrom, t = bestTo;
  final int sc = bestScore;
  // Processing Android: use handler-like via redraw / variables
  if (f >= 0) {
    int captured = board[t];
    int piece = board[f];
    board[t] = piece;
    board[f] = 0;
    if ((piece == 1 && t < 8) || (piece == 9 && t >= 56)) {
      board[t] = (piece < 8) ? 5 : 13;
    }
    whiteTurn = !whiteTurn;
    status = whiteTurn ? "White to move" : "Black to move";
  } else {
    status = "No moves – game over?";
  }
  thinking = false;
}

int alphabeta(int depth, boolean maximizing, int alpha, int beta) {
  if (depth == 0) return evaluate();
  
  ArrayList<int[]> moves = generateMoves(maximizing);
  if (moves.isEmpty()) return maximizing ? -100000 : 100000; // checkmate-ish
  
  if (maximizing) {
    int maxEval = -999999;
    for (int[] m : moves) {
      int from = m[0], to = m[1];
      int captured = board[to];
      int piece = board[from];
      board[to] = piece;
      board[from] = 0;
      if ((piece == 1 && to < 8) || (piece == 9 && to >= 56)) board[to] = 5;
      
      int eval = alphabeta(depth - 1, false, alpha, beta);
      
      board[from] = piece;
      board[to] = captured;
      
      maxEval = max(maxEval, eval);
      alpha = max(alpha, eval);
      if (beta <= alpha) break;
    }
    return maxEval;
  } else {
    int minEval = 999999;
    for (int[] m : moves) {
      int from = m[0], to = m[1];
      int captured = board[to];
      int piece = board[from];
      board[to] = piece;
      board[from] = 0;
      if ((piece == 9 && to >= 56) || (piece == 1 && to < 8)) board[to] = 13;
      
      int eval = alphabeta(depth - 1, true, alpha, beta);
      
      board[from] = piece;
      board[to] = captured;
      
      minEval = min(minEval, eval);
      beta = min(beta, eval);
      if (beta <= alpha) break;
    }
    return minEval;
  }
}

int evaluate() {
  int score = 0;
  for (int sq = 0; sq < 64; sq++) {
    int p = board[sq];
    if (p == 0) continue;
    boolean white = p < 8;
    int type = p & 7;
    int val = PIECE_VAL[type];
    int pst = 0;
    int idx = white ? sq : (63 - sq);
    switch (type) {
      case 1: pst = PST_P[idx]; break;
      case 2: pst = PST_N[idx]; break;
      case 3: pst = PST_B[idx]; break;
      case 4: pst = PST_R[idx]; break;
      case 5: pst = PST_Q[idx]; break;
      case 6: pst = PST_K[idx]; break;
    }
    if (white) score += val + pst;
    else score -= val + pst;
  }
  return score;
}

ArrayList<int[]> generateMoves(boolean forWhite) {
  ArrayList<int[]> list = new ArrayList<int[]>();
  for (int from = 0; from < 64; from++) {
    int p = board[from];
    if (p == 0) continue;
    if ((p < 8) != forWhite) continue;
    
    int type = p & 7;
    int r = from / 8, c = from % 8;
    
    if (type == 1) { // pawn
      int dir = forWhite ? -1 : 1;
      int nr = r + dir;
      if (nr >= 0 && nr < 8) {
        int to = nr * 8 + c;
        if (board[to] == 0) {
          list.add(new int[]{from, to});
          // double step
          if ((forWhite && r == 6) || (!forWhite && r == 1)) {
            int nr2 = r + 2 * dir;
            int to2 = nr2 * 8 + c;
            if (board[to2] == 0) list.add(new int[]{from, to2});
          }
        }
        // captures
        for (int dc = -1; dc <= 1; dc += 2) {
          int nc = c + dc;
          if (nc >= 0 && nc < 8) {
            int toC = nr * 8 + nc;
            int t = board[toC];
            if (t != 0 && ((t < 8) != forWhite)) list.add(new int[]{from, toC});
          }
        }
      }
    } else if (type == 2) { // knight
      int[][] deltas = {{-2,-1},{-2,1},{-1,-2},{-1,2},{1,-2},{1,2},{2,-1},{2,1}};
      for (int[] d : deltas) {
        int nr = r + d[0], nc = c + d[1];
        if (nr >= 0 && nr < 8 && nc >= 0 && nc < 8) {
          int to = nr * 8 + nc;
          int t = board[to];
          if (t == 0 || ((t < 8) != forWhite)) list.add(new int[]{from, to});
        }
      }
    } else if (type == 3 || type == 4 || type == 5) { // B R Q
      int[][] dirs;
      if (type == 3) dirs = new int[][]{{-1,-1},{-1,1},{1,-1},{1,1}};
      else if (type == 4) dirs = new int[][]{{-1,0},{1,0},{0,-1},{0,1}};
      else dirs = new int[][]{{-1,-1},{-1,1},{1,-1},{1,1},{-1,0},{1,0},{0,-1},{0,1}};
      
      for (int[] d : dirs) {
        int nr = r + d[0], nc = c + d[1];
        while (nr >= 0 && nr < 8 && nc >= 0 && nc < 8) {
          int to = nr * 8 + nc;
          int t = board[to];
          if (t == 0) {
            list.add(new int[]{from, to});
          } else {
            if ((t < 8) != forWhite) list.add(new int[]{from, to});
            break;
          }
          nr += d[0]; nc += d[1];
        }
      }
    } else if (type == 6) { // king
      for (int dr = -1; dr <= 1; dr++) {
        for (int dc = -1; dc <= 1; dc++) {
          if (dr == 0 && dc == 0) continue;
          int nr = r + dr, nc = c + dc;
          if (nr >= 0 && nr < 8 && nc >= 0 && nc < 8) {
            int to = nr * 8 + nc;
            int t = board[to];
            if (t == 0 || ((t < 8) != forWhite)) list.add(new int[]{from, to});
          }
        }
      }
    }
  }
  return list;
}




*/




/**
 * Chess Board + Engine  –  single file for APDE 0.5.3 (Android 9)
 *
 * Features:
 *  - Graphical chess board with Unicode pieces
 *  - Human plays White, simple alpha-beta engine plays Black
 *  - Touch to select piece then destination
 *  - New Game / Force Engine Move buttons
 *
 * Open this single .pde in APDE → Android mode → Run.
 * Tested conceptually for Android 9 / APDE 0.5.3.
 *
 * Engine inspired by the classic p4wn ideas (public domain)
 * but re-implemented in pure Processing/Java for APDE compatibility.
 */


/*




int SQUARE;
int BOARD_X, BOARD_Y;
int selected = -1;          // 0..63 or -1
boolean whiteTurn = true;
boolean thinking = false;
String status = "White to move – tap a piece";
int[] board = new int[64];  // 0 empty, 1-6 white, 9-14 black (same encoding as many engines)

// Piece values for evaluation
final int[] PIECE_VAL = {0, 100, 320, 330, 500, 900, 20000};

// Simple piece-square tables (midgame, from white's view)
final int[] PST_P = {
  0,0,0,0,0,0,0,0, 50,50,50,50,50,50,50,50,
  10,10,20,30,30,20,10,10, 5,5,10,25,25,10,5,5,
  0,0,0,20,20,0,0,0, 5,-5,-10,0,0,-10,-5,5,
  5,10,10,-20,-20,10,10,5, 0,0,0,0,0,0,0,0
};
final int[] PST_N = {
  -50,-40,-30,-30,-30,-30,-40,-50, -40,-20,0,0,0,0,-20,-40,
  -30,0,10,15,15,10,0,-30, -30,5,15,20,20,15,5,-30,
  -30,0,15,20,20,15,0,-30, -30,5,10,15,15,10,5,-30,
  -40,-20,0,5,5,0,-20,-40, -50,-40,-30,-30,-30,-30,-40,-50
};
final int[] PST_B = {
  -20,-10,-10,-10,-10,-10,-10,-20, -10,0,0,0,0,0,0,-10,
  -10,0,5,10,10,5,0,-10, -10,5,5,10,10,5,5,-10,
  -10,0,10,10,10,10,0,-10, -10,10,10,10,10,10,10,-10,
  -10,5,0,0,0,0,5,-10, -20,-10,-10,-10,-10,-10,-10,-20
};
final int[] PST_R = {
  0,0,0,0,0,0,0,0, 5,10,10,10,10,10,10,5,
  -5,0,0,0,0,0,0,-5, -5,0,0,0,0,0,0,-5,
  -5,0,0,0,0,0,0,-5, -5,0,0,0,0,0,0,-5,
  -5,0,0,0,0,0,0,-5, 0,0,0,5,5,0,0,0
};
final int[] PST_Q = {
  -20,-10,-10,-5,-5,-10,-10,-20, -10,0,0,0,0,0,0,-10,
  -10,0,5,5,5,5,0,-10, -5,0,5,5,5,5,0,-5,
  0,0,5,5,5,5,0,-5, -10,5,5,5,5,5,0,-10,
  -10,0,5,0,0,0,0,-10, -20,-10,-10,-5,-5,-10,-10,-20
};
final int[] PST_K = {
  -30,-40,-40,-50,-50,-40,-40,-30, -30,-40,-40,-50,-50,-40,-40,-30,
  -30,-40,-40,-50,-50,-40,-40,-30, -30,-40,-40,-50,-50,-40,-40,-30,
  -20,-30,-30,-40,-40,-30,-30,-20, -10,-20,-20,-20,-20,-20,-20,-10,
  20,20,0,0,0,0,20,20, 20,30,10,0,0,10,30,20
};

void setup() {
  fullScreen();
  orientation(PORTRAIT);
  textAlign(CENTER, CENTER);
  resetGame();
}

void draw() {
  background(30, 32, 40);
  
  // Layout
  int topBar = 80;
  int bottomBar = 140;
  SQUARE = min((width - 40) / 8, (height - topBar - bottomBar) / 8);
  BOARD_X = (width - SQUARE * 8) / 2;
  BOARD_Y = topBar + 20;
  
  // Title
  fill(220);
  textSize(32);
  text("Chess + Engine (APDE)", width/2, 40);
  
  // Board
  for (int r = 0; r < 8; r++) {
    for (int c = 0; c < 8; c++) {
      int sq = r * 8 + c;
      boolean light = ((r + c) & 1) == 0;
      fill(light ? color(235, 210, 170) : color(160, 110, 70));
      noStroke();
      rect(BOARD_X + c * SQUARE, BOARD_Y + r * SQUARE, SQUARE, SQUARE);
      
      if (sq == selected) {
        fill(255, 255, 0, 120);
        rect(BOARD_X + c * SQUARE, BOARD_Y + r * SQUARE, SQUARE, SQUARE);
      }
      
      int p = board[sq];
      if (p != 0) {
        drawPiece(p, BOARD_X + c * SQUARE + SQUARE/2, BOARD_Y + r * SQUARE + SQUARE/2, SQUARE);
      }
    }
  }
  
  // Status
  fill(thinking ? color(255, 200, 80) : color(210));
  textSize(26);
  text(status, width/2, height - 100);
  
  // Buttons
  drawBtn(width/2 - 210, height - 70, 190, 55, "New Game");
  drawBtn(width/2 + 20,  height - 70, 190, 55, "Engine Move");
}

void drawBtn(float x, float y, float w, float h, String label) {
  fill(55, 90, 140);
  rect(x, y, w, h, 14);
  fill(255);
  textSize(24);
  text(label, x + w/2, y + h/2);
}

void drawPiece(int p, float x, float y, float s) {
  boolean white = p < 8;
  fill(white ? 250 : 30);
  textSize(s * 0.75);
  String sym = "";
  switch (p & 7) {
    case 1: sym = white ? "\u2659" : "\u265F"; break; // P
    case 2: sym = white ? "\u2658" : "\u265E"; break; // N
    case 3: sym = white ? "\u2657" : "\u265D"; break; // B
    case 4: sym = white ? "\u2656" : "\u265C"; break; // R
    case 5: sym = white ? "\u2655" : "\u265B"; break; // Q
    case 6: sym = white ? "\u2654" : "\u265A"; break; // K
  }
  text(sym, x, y);
}

void mousePressed() {
  // Buttons
  if (mouseY > height - 80) {
    if (mouseX > width/2 - 210 && mouseX < width/2 - 20) {
      resetGame();
      return;
    }
    if (mouseX > width/2 + 20 && mouseX < width/2 + 210) {
      if (!thinking && !whiteTurn) {
        // already black's turn
      } else if (!thinking) {
        // force engine even if white to move (demo)
        thinking = true;
        status = "Engine thinking…";
        thread("engineMoveThread");
      }
      return;
    }
  }
  
  if (thinking) return;
  
  int c = (mouseX - BOARD_X) / SQUARE;
  int r = (mouseY - BOARD_Y) / SQUARE;
  if (c < 0 || c > 7 || r < 0 || r > 7) return;
  int sq = r * 8 + c;
  
  if (selected == -1) {
    int p = board[sq];
    if (p != 0 && ((p < 8) == whiteTurn)) {
      selected = sq;
    }
  } else {
    if (sq == selected) {
      selected = -1;
    } else {
      if (tryMove(selected, sq)) {
        selected = -1;
        whiteTurn = false;
        status = "Black (engine) thinking…";
        thinking = true;
        thread("engineMoveThread");
      } else {
        // reselect if own piece
        int p = board[sq];
        if (p != 0 && ((p < 8) == whiteTurn)) selected = sq;
        else selected = -1;
      }
    }
  }
}

void resetGame() {
  // Standard starting position (index 0 = a8)
  // 1=P 2=N 3=B 4=R 5=Q 6=K ; +8 for black
  board = new int[] {
    12,10,11,13,14,11,10,12,   // rank 8
     9, 9, 9, 9, 9, 9, 9, 9,   // rank 7
     0, 0, 0, 0, 0, 0, 0, 0,
     0, 0, 0, 0, 0, 0, 0, 0,
     0, 0, 0, 0, 0, 0, 0, 0,
     0, 0, 0, 0, 0, 0, 0, 0,
     1, 1, 1, 1, 1, 1, 1, 1,   // rank 2
     4, 2, 3, 5, 6, 3, 2, 4    // rank 1
  };
  whiteTurn = true;
  selected = -1;
  thinking = false;
  status = "White to move – tap a piece";
}

boolean tryMove(int from, int to) {
  // Extremely simplified legality – only basic non-capture / capture of opposite
  // A full legal-move generator is longer; this is a playable demo.
  int p = board[from];
  if (p == 0) return false;
  int target = board[to];
  boolean white = p < 8;
  if (target != 0 && ((target < 8) == white)) return false; // same color
  
  // Accept the move (no full validation for brevity – improve later)
  board[to] = p;
  board[from] = 0;
  
  // Auto-promote
  if ((p == 1 && to < 8) || (p == 9 && to >= 56)) {
    board[to] = white ? 5 : 13; // queen
  }
  return true;
}

// ============== Simple Engine (alpha-beta, depth 3) ==============
void engineMoveThread() {
  int bestFrom = -1, bestTo = -1;
  int bestScore = whiteTurn ? -999999 : 999999;
  int depth = 3;
  
  // Generate all pseudo-legal moves for the side to move
  ArrayList<int[]> moves = generateMoves(whiteTurn);
  
  for (int[] m : moves) {
    int from = m[0], to = m[1];
    int captured = board[to];
    int piece = board[from];
    board[to] = piece;
    board[from] = 0;
    
    // promote
    boolean promoted = false;
    if ((piece == 1 && to < 8) || (piece == 9 && to >= 56)) {
      board[to] = (piece < 8) ? 5 : 13;
      promoted = true;
    }
    
    int score = alphabeta(depth - 1, !whiteTurn, -999999, 999999);
    
    // undo
    board[from] = piece;
    board[to] = captured;
    
    if (whiteTurn) {
      if (score > bestScore) { bestScore = score; bestFrom = from; bestTo = to; }
    } else {
      if (score < bestScore) { bestScore = score; bestFrom = from; bestTo = to; }
    }
  }
  
  // Apply best move on main thread
  final int f = bestFrom, t = bestTo;
  final int sc = bestScore;
  // Processing Android: use handler-like via redraw / variables
  if (f >= 0) {
    int captured = board[t];
    int piece = board[f];
    board[t] = piece;
    board[f] = 0;
    if ((piece == 1 && t < 8) || (piece == 9 && t >= 56)) {
      board[t] = (piece < 8) ? 5 : 13;
    }
    whiteTurn = !whiteTurn;
    status = whiteTurn ? "White to move" : "Black to move";
  } else {
    status = "No moves – game over?";
  }
  thinking = false;
}

int alphabeta(int depth, boolean maximizing, int alpha, int beta) {
  if (depth == 0) return evaluate();
  
  ArrayList<int[]> moves = generateMoves(maximizing);
  if (moves.isEmpty()) return maximizing ? -100000 : 100000; // checkmate-ish
  
  if (maximizing) {
    int maxEval = -999999;
    for (int[] m : moves) {
      int from = m[0], to = m[1];
      int captured = board[to];
      int piece = board[from];
      board[to] = piece;
      board[from] = 0;
      if ((piece == 1 && to < 8) || (piece == 9 && to >= 56)) board[to] = 5;
      
      int eval = alphabeta(depth - 1, false, alpha, beta);
      
      board[from] = piece;
      board[to] = captured;
      
      maxEval = max(maxEval, eval);
      alpha = max(alpha, eval);
      if (beta <= alpha) break;
    }
    return maxEval;
  } else {
    int minEval = 999999;
    for (int[] m : moves) {
      int from = m[0], to = m[1];
      int captured = board[to];
      int piece = board[from];
      board[to] = piece;
      board[from] = 0;
      if ((piece == 9 && to >= 56) || (piece == 1 && to < 8)) board[to] = 13;
      
      int eval = alphabeta(depth - 1, true, alpha, beta);
      
      board[from] = piece;
      board[to] = captured;
      
      minEval = min(minEval, eval);
      beta = min(beta, eval);
      if (beta <= alpha) break;
    }
    return minEval;
  }
}

int evaluate() {
  int score = 0;
  for (int sq = 0; sq < 64; sq++) {
    int p = board[sq];
    if (p == 0) continue;
    boolean white = p < 8;
    int type = p & 7;
    int val = PIECE_VAL[type];
    int pst = 0;
    int idx = white ? sq : (63 - sq);
    switch (type) {
      case 1: pst = PST_P[idx]; break;
      case 2: pst = PST_N[idx]; break;
      case 3: pst = PST_B[idx]; break;
      case 4: pst = PST_R[idx]; break;
      case 5: pst = PST_Q[idx]; break;
      case 6: pst = PST_K[idx]; break;
    }
    if (white) score += val + pst;
    else score -= val + pst;
  }
  return score;
}

ArrayList<int[]> generateMoves(boolean forWhite) {
  ArrayList<int[]> list = new ArrayList<int[]>();
  for (int from = 0; from < 64; from++) {
    int p = board[from];
    if (p == 0) continue;
    if ((p < 8) != forWhite) continue;
    
    int type = p & 7;
    int r = from / 8, c = from % 8;
    
    if (type == 1) { // pawn
      int dir = forWhite ? -1 : 1;
      int nr = r + dir;
      if (nr >= 0 && nr < 8) {
        int to = nr * 8 + c;
        if (board[to] == 0) {
          list.add(new int[]{from, to});
          // double step
          if ((forWhite && r == 6) || (!forWhite && r == 1)) {
            int nr2 = r + 2 * dir;
            int to2 = nr2 * 8 + c;
            if (board[to2] == 0) list.add(new int[]{from, to2});
          }
        }
        // captures
        for (int dc = -1; dc <= 1; dc += 2) {
          int nc = c + dc;
          if (nc >= 0 && nc < 8) {
            int toC = nr * 8 + nc;
            int t = board[toC];
            if (t != 0 && ((t < 8) != forWhite)) list.add(new int[]{from, toC});
          }
        }
      }
    } else if (type == 2) { // knight
      int[][] deltas = {{-2,-1},{-2,1},{-1,-2},{-1,2},{1,-2},{1,2},{2,-1},{2,1}};
      for (int[] d : deltas) {
        int nr = r + d[0], nc = c + d[1];
        if (nr >= 0 && nr < 8 && nc >= 0 && nc < 8) {
          int to = nr * 8 + nc;
          int t = board[to];
          if (t == 0 || ((t < 8) != forWhite)) list.add(new int[]{from, to});
        }
      }
    } else if (type == 3 || type == 4 || type == 5) { // B R Q
      int[][] dirs;
      if (type == 3) dirs = new int[][]{{-1,-1},{-1,1},{1,-1},{1,1}};
      else if (type == 4) dirs = new int[][]{{-1,0},{1,0},{0,-1},{0,1}};
      else dirs = new int[][]{{-1,-1},{-1,1},{1,-1},{1,1},{-1,0},{1,0},{0,-1},{0,1}};
      
      for (int[] d : dirs) {
        int nr = r + d[0], nc = c + d[1];
        while (nr >= 0 && nr < 8 && nc >= 0 && nc < 8) {
          int to = nr * 8 + nc;
          int t = board[to];
          if (t == 0) {
            list.add(new int[]{from, to});
          } else {
            if ((t < 8) != forWhite) list.add(new int[]{from, to});
            break;
          }
          nr += d[0]; nc += d[1];
        }
      }
    } else if (type == 6) { // king
      for (int dr = -1; dr <= 1; dr++) {
        for (int dc = -1; dc <= 1; dc++) {
          if (dr == 0 && dc == 0) continue;
          int nr = r + dr, nc = c + dc;
          if (nr >= 0 && nr < 8 && nc >= 0 && nc < 8) {
            int to = nr * 8 + nc;
            int t = board[to];
            if (t == 0 || ((t < 8) != forWhite)) list.add(new int[]{from, to});
          }
        }
      }
    }
  }
  return list;
}



*/













/**
 * Chess Board + Engine  –  single file for APDE 0.5.3 (Android 9)
 *
 * Features:
 *  - Graphical chess board with Unicode pieces
 *  - Human plays White, simple alpha-beta engine plays Black
 *  - Touch to select piece then destination
 *  - New Game / Force Engine Move buttons
 *
 * Open this single .pde in APDE → Android mode → Run.
 * Tested conceptually for Android 9 / APDE 0.5.3.
 *
 * Engine inspired by the classic p4wn ideas (public domain)
 * but re-implemented in pure Processing/Java for APDE compatibility.
 */

/*


int SQUARE;
int BOARD_X, BOARD_Y;
int selected = -1;          // 0..63 or -1
boolean whiteTurn = true;
boolean thinking = false;
String status = "White to move – tap a piece";
int[] board = new int[64];  // 0 empty, 1-6 white, 9-14 black (same encoding as many engines)

// Piece values for evaluation
final int[] PIECE_VAL = {0, 100, 320, 330, 500, 900, 20000};

// Simple piece-square tables (midgame, from white's view)
final int[] PST_P = {
  0,0,0,0,0,0,0,0, 50,50,50,50,50,50,50,50,
  10,10,20,30,30,20,10,10, 5,5,10,25,25,10,5,5,
  0,0,0,20,20,0,0,0, 5,-5,-10,0,0,-10,-5,5,
  5,10,10,-20,-20,10,10,5, 0,0,0,0,0,0,0,0
};
final int[] PST_N = {
  -50,-40,-30,-30,-30,-30,-40,-50, -40,-20,0,0,0,0,-20,-40,
  -30,0,10,15,15,10,0,-30, -30,5,15,20,20,15,5,-30,
  -30,0,15,20,20,15,0,-30, -30,5,10,15,15,10,5,-30,
  -40,-20,0,5,5,0,-20,-40, -50,-40,-30,-30,-30,-30,-40,-50
};
final int[] PST_B = {
  -20,-10,-10,-10,-10,-10,-10,-20, -10,0,0,0,0,0,0,-10,
  -10,0,5,10,10,5,0,-10, -10,5,5,10,10,5,5,-10,
  -10,0,10,10,10,10,0,-10, -10,10,10,10,10,10,10,-10,
  -10,5,0,0,0,0,5,-10, -20,-10,-10,-10,-10,-10,-10,-20
};
final int[] PST_R = {
  0,0,0,0,0,0,0,0, 5,10,10,10,10,10,10,5,
  -5,0,0,0,0,0,0,-5, -5,0,0,0,0,0,0,-5,
  -5,0,0,0,0,0,0,-5, -5,0,0,0,0,0,0,-5,
  -5,0,0,0,0,0,0,-5, 0,0,0,5,5,0,0,0
};
final int[] PST_Q = {
  -20,-10,-10,-5,-5,-10,-10,-20, -10,0,0,0,0,0,0,-10,
  -10,0,5,5,5,5,0,-10, -5,0,5,5,5,5,0,-5,
  0,0,5,5,5,5,0,-5, -10,5,5,5,5,5,0,-10,
  -10,0,5,0,0,0,0,-10, -20,-10,-10,-5,-5,-10,-10,-20
};
final int[] PST_K = {
  -30,-40,-40,-50,-50,-40,-40,-30, -30,-40,-40,-50,-50,-40,-40,-30,
  -30,-40,-40,-50,-50,-40,-40,-30, -30,-40,-40,-50,-50,-40,-40,-30,
  -20,-30,-30,-40,-40,-30,-30,-20, -10,-20,-20,-20,-20,-20,-20,-10,
  20,20,0,0,0,0,20,20, 20,30,10,0,0,10,30,20
};

void setup() {
  fullScreen();
  orientation(PORTRAIT);
  textAlign(CENTER, CENTER);
  resetGame();
}

void draw() {
  background(30, 32, 40);
  
  // Layout
  int topBar = 80;
  int bottomBar = 140;
  SQUARE = min((width - 40) / 8, (height - topBar - bottomBar) / 8);
  BOARD_X = (width - SQUARE * 8) / 2;
  BOARD_Y = topBar + 20;
  
  // Title
  fill(220);
  textSize(32);
  text("Chess + Engine (APDE)", width/2, 40);
  
  // Board
  for (int r = 0; r < 8; r++) {
    for (int c = 0; c < 8; c++) {
      int sq = r * 8 + c;
      boolean light = ((r + c) & 1) == 0;
      fill(light ? color(235, 210, 170) : color(160, 110, 70));
      noStroke();
      rect(BOARD_X + c * SQUARE, BOARD_Y + r * SQUARE, SQUARE, SQUARE);
      
      if (sq == selected) {
        fill(255, 255, 0, 120);
        rect(BOARD_X + c * SQUARE, BOARD_Y + r * SQUARE, SQUARE, SQUARE);
      }
      
      int p = board[sq];
      if (p != 0) {
        drawPiece(p, BOARD_X + c * SQUARE + SQUARE/2, BOARD_Y + r * SQUARE + SQUARE/2, SQUARE);
      }
    }
  }
  
  // Status
  fill(thinking ? color(255, 200, 80) : color(210));
  textSize(26);
  text(status, width/2, height - 100);
  
  // Buttons
  drawBtn(width/2 - 210, height - 70, 190, 55, "New Game");
  drawBtn(width/2 + 20,  height - 70, 190, 55, "Engine Move");
}

void drawBtn(float x, float y, float w, float h, String label) {
  fill(55, 90, 140);
  rect(x, y, w, h, 14);
  fill(255);
  textSize(24);
  text(label, x + w/2, y + h/2);
}

void drawPiece(int p, float x, float y, float s) {
  boolean white = p < 8;
  fill(white ? 250 : 30);
  textSize(s * 0.75);
  String sym = "";
  switch (p & 7) {
    case 1: sym = white ? "\u2659" : "\u265F"; break; // P
    case 2: sym = white ? "\u2658" : "\u265E"; break; // N
    case 3: sym = white ? "\u2657" : "\u265D"; break; // B
    case 4: sym = white ? "\u2656" : "\u265C"; break; // R
    case 5: sym = white ? "\u2655" : "\u265B"; break; // Q
    case 6: sym = white ? "\u2654" : "\u265A"; break; // K
  }
  text(sym, x, y);
}

void mousePressed() {
  // Buttons
  if (mouseY > height - 80) {
    if (mouseX > width/2 - 210 && mouseX < width/2 - 20) {
      resetGame();
      return;
    }
    if (mouseX > width/2 + 20 && mouseX < width/2 + 210) {
      if (!thinking && !whiteTurn) {
        // already black's turn
      } else if (!thinking) {
        // force engine even if white to move (demo)
        thinking = true;
        status = "Engine thinking…";
        thread("engineMoveThread");
      }
      return;
    }
  }
  
  if (thinking) return;
  
  int c = (mouseX - BOARD_X) / SQUARE;
  int r = (mouseY - BOARD_Y) / SQUARE;
  if (c < 0 || c > 7 || r < 0 || r > 7) return;
  int sq = r * 8 + c;
  
  if (selected == -1) {
    int p = board[sq];
    if (p != 0 && ((p < 8) == whiteTurn)) {
      selected = sq;
    }
  } else {
    if (sq == selected) {
      selected = -1;
    } else {
      if (tryMove(selected, sq)) {
        selected = -1;
        whiteTurn = false;
        status = "Black (engine) thinking…";
        thinking = true;
        thread("engineMoveThread");
      } else {
        // reselect if own piece
        int p = board[sq];
        if (p != 0 && ((p < 8) == whiteTurn)) selected = sq;
        else selected = -1;
      }
    }
  }
}

void resetGame() {
  // Standard starting position (index 0 = a8)
  // 1=P 2=N 3=B 4=R 5=Q 6=K ; +8 for black
  board = new int[] {
    12,10,11,13,14,11,10,12,   // rank 8
     9, 9, 9, 9, 9, 9, 9, 9,   // rank 7
     0, 0, 0, 0, 0, 0, 0, 0,
     0, 0, 0, 0, 0, 0, 0, 0,
     0, 0, 0, 0, 0, 0, 0, 0,
     0, 0, 0, 0, 0, 0, 0, 0,
     1, 1, 1, 1, 1, 1, 1, 1,   // rank 2
     4, 2, 3, 5, 6, 3, 2, 4    // rank 1
  };
  whiteTurn = true;
  selected = -1;
  thinking = false;
  status = "White to move – tap a piece";
}

boolean tryMove(int from, int to) {
  // Extremely simplified legality – only basic non-capture / capture of opposite
  // A full legal-move generator is longer; this is a playable demo.
  int p = board[from];
  if (p == 0) return false;
  int target = board[to];
  boolean white = p < 8;
  if (target != 0 && ((target < 8) == white)) return false; // same color
  
  // Accept the move (no full validation for brevity – improve later)
  board[to] = p;
  board[from] = 0;
  
  // Auto-promote
  if ((p == 1 && to < 8) || (p == 9 && to >= 56)) {
    board[to] = white ? 5 : 13; // queen
  }
  return true;
}

// ============== Simple Engine (alpha-beta, depth 3) ==============
void engineMoveThread() {
  int bestFrom = -1, bestTo = -1;
  int bestScore = whiteTurn ? -999999 : 999999;
  int depth = 3;
  
  // Generate all pseudo-legal moves for the side to move
  ArrayList<int[]> moves = generateMoves(whiteTurn);
  
  for (int[] m : moves) {
    int from = m[0], to = m[1];
    int captured = board[to];
    int piece = board[from];
    board[to] = piece;
    board[from] = 0;
    
    // promote
    boolean promoted = false;
    if ((piece == 1 && to < 8) || (piece == 9 && to >= 56)) {
      board[to] = (piece < 8) ? 5 : 13;
      promoted = true;
    }
    
    int score = alphabeta(depth - 1, !whiteTurn, -999999, 999999);
    
    // undo
    board[from] = piece;
    board[to] = captured;
    
    if (whiteTurn) {
      if (score > bestScore) { bestScore = score; bestFrom = from; bestTo = to; }
    } else {
      if (score < bestScore) { bestScore = score; bestFrom = from; bestTo = to; }
    }
  }
  
  // Apply best move on main thread
  final int f = bestFrom, t = bestTo;
  final int sc = bestScore;
  // Processing Android: use handler-like via redraw / variables
  if (f >= 0) {
    int captured = board[t];
    int piece = board[f];
    board[t] = piece;
    board[f] = 0;
    if ((piece == 1 && t < 8) || (piece == 9 && t >= 56)) {
      board[t] = (piece < 8) ? 5 : 13;
    }
    whiteTurn = !whiteTurn;
    status = whiteTurn ? "White to move" : "Black to move";
  } else {
    status = "No moves – game over?";
  }
  thinking = false;
}

int alphabeta(int depth, boolean maximizing, int alpha, int beta) {
  if (depth == 0) return evaluate();
  
  ArrayList<int[]> moves = generateMoves(maximizing);
  if (moves.isEmpty()) return maximizing ? -100000 : 100000; // checkmate-ish
  
  if (maximizing) {
    int maxEval = -999999;
    for (int[] m : moves) {
      int from = m[0], to = m[1];
      int captured = board[to];
      int piece = board[from];
      board[to] = piece;
      board[from] = 0;
      if ((piece == 1 && to < 8) || (piece == 9 && to >= 56)) board[to] = 5;
      
      int eval = alphabeta(depth - 1, false, alpha, beta);
      
      board[from] = piece;
      board[to] = captured;
      
      maxEval = max(maxEval, eval);
      alpha = max(alpha, eval);
      if (beta <= alpha) break;
    }
    return maxEval;
  } else {
    int minEval = 999999;
    for (int[] m : moves) {
      int from = m[0], to = m[1];
      int captured = board[to];
      int piece = board[from];
      board[to] = piece;
      board[from] = 0;
      if ((piece == 9 && to >= 56) || (piece == 1 && to < 8)) board[to] = 13;
      
      int eval = alphabeta(depth - 1, true, alpha, beta);
      
      board[from] = piece;
      board[to] = captured;
      
      minEval = min(minEval, eval);
      beta = min(beta, eval);
      if (beta <= alpha) break;
    }
    return minEval;
  }
}

int evaluate() {
  int score = 0;
  for (int sq = 0; sq < 64; sq++) {
    int p = board[sq];
    if (p == 0) continue;
    boolean white = p < 8;
    int type = p & 7;
    int val = PIECE_VAL[type];
    int pst = 0;
    int idx = white ? sq : (63 - sq);
    switch (type) {
      case 1: pst = PST_P[idx]; break;
      case 2: pst = PST_N[idx]; break;
      case 3: pst = PST_B[idx]; break;
      case 4: pst = PST_R[idx]; break;
      case 5: pst = PST_Q[idx]; break;
      case 6: pst = PST_K[idx]; break;
    }
    if (white) score += val + pst;
    else score -= val + pst;
  }
  return score;
}

ArrayList<int[]> generateMoves(boolean forWhite) {
  ArrayList<int[]> list = new ArrayList<int[]>();
  for (int from = 0; from < 64; from++) {
    int p = board[from];
    if (p == 0) continue;
    if ((p < 8) != forWhite) continue;
    
    int type = p & 7;
    int r = from / 8, c = from % 8;
    
    if (type == 1) { // pawn
      int dir = forWhite ? -1 : 1;
      int nr = r + dir;
      if (nr >= 0 && nr < 8) {
        int to = nr * 8 + c;
        if (board[to] == 0) {
          list.add(new int[]{from, to});
          // double step
          if ((forWhite && r == 6) || (!forWhite && r == 1)) {
            int nr2 = r + 2 * dir;
            int to2 = nr2 * 8 + c;
            if (board[to2] == 0) list.add(new int[]{from, to2});
          }
        }
        // captures
        for (int dc = -1; dc <= 1; dc += 2) {
          int nc = c + dc;
          if (nc >= 0 && nc < 8) {
            int toC = nr * 8 + nc;
            int t = board[toC];
            if (t != 0 && ((t < 8) != forWhite)) list.add(new int[]{from, toC});
          }
        }
      }
    } else if (type == 2) { // knight
      int[][] deltas = {{-2,-1},{-2,1},{-1,-2},{-1,2},{1,-2},{1,2},{2,-1},{2,1}};
      for (int[] d : deltas) {
        int nr = r + d[0], nc = c + d[1];
        if (nr >= 0 && nr < 8 && nc >= 0 && nc < 8) {
          int to = nr * 8 + nc;
          int t = board[to];
          if (t == 0 || ((t < 8) != forWhite)) list.add(new int[]{from, to});
        }
      }
    } else if (type == 3 || type == 4 || type == 5) { // B R Q
      int[][] dirs;
      if (type == 3) dirs = new int[][]{{-1,-1},{-1,1},{1,-1},{1,1}};
      else if (type == 4) dirs = new int[][]{{-1,0},{1,0},{0,-1},{0,1}};
      else dirs = new int[][]{{-1,-1},{-1,1},{1,-1},{1,1},{-1,0},{1,0},{0,-1},{0,1}};
      
      for (int[] d : dirs) {
        int nr = r + d[0], nc = c + d[1];
        while (nr >= 0 && nr < 8 && nc >= 0 && nc < 8) {
          int to = nr * 8 + nc;
          int t = board[to];
          if (t == 0) {
            list.add(new int[]{from, to});
          } else {
            if ((t < 8) != forWhite) list.add(new int[]{from, to});
            break;
          }
          nr += d[0]; nc += d[1];
        }
      }
    } else if (type == 6) { // king
      for (int dr = -1; dr <= 1; dr++) {
        for (int dc = -1; dc <= 1; dc++) {
          if (dr == 0 && dc == 0) continue;
          int nr = r + dr, nc = c + dc;
          if (nr >= 0 && nr < 8 && nc >= 0 && nc < 8) {
            int to = nr * 8 + nc;
            int t = board[to];
            if (t == 0 || ((t < 8) != forWhite)) list.add(new int[]{from, to});
          }
        }
      }
    }
  }
  return list;
}










*/




















































































