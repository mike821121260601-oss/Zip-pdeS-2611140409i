

















/////РОБЕ/////////

// Use Android's media APIs (no Sound library)
import android.media.MediaRecorder;
import android.media.MediaPlayer;
import java.io.File;
import java.io.IOException;

MediaRecorder recorder;
MediaPlayer player;
File audioFile;
boolean recording = false;
boolean playing = false;
long recordStart;

void setup() {
  size(400, 400);
  audioFile = new File(sketchPath("temp_audio.3gp"));
}

void draw() {
  background(200);
  textAlign(CENTER, CENTER);
  textSize(24);
  
  if (recording) {
    int elapsed = (int)((millis() - recordStart) / 1000);
    text("RECORDING... " + elapsed + "/10s", width/2, height/2);
  } else if (playing) {
    text("🔊 LOOPING (tap to re‑record)", width/2, height/2);
  } else {
    text("👆 TAP SCREEN TO RECORD 10s", width/2, height/2);
  }
  
  // Stop after 10 seconds
  if (recording && (millis() - recordStart >= 10000)) {
    finishRecording();
  }
}

void mousePressed() {
  if (recording) return;
  
  // Stop any current playback
  if (playing) {
    player.stop();
    player.release();
    player = null;
    playing = false;
  }
  
  startRecording();
}

void startRecording() {
  try {
    if (audioFile.exists()) audioFile.delete();
    audioFile.createNewFile();
    
    recorder = new MediaRecorder();
    recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
    recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
    recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
    recorder.setOutputFile(audioFile.getAbsolutePath());
    recorder.prepare();
    recorder.start();
    
    recording = true;
    recordStart = millis();
  } catch (SecurityException e) {
    println("✋ MICROPHONE PERMISSION DENIED – add it in the Android tab!");
    e.printStackTrace();
  } catch (Exception e) {
    e.printStackTrace();
  }
}

void finishRecording() {
  if (recorder != null) {
    recorder.stop();
    recorder.release();
    recorder = null;
  }
  recording = false;
  
  if (audioFile.exists()) {
    try {
      player = new MediaPlayer();
      player.setDataSource(audioFile.getAbsolutePath());
      player.prepare();
      player.setLooping(true);
      player.start();
      playing = true;
    } catch (IOException e) {
      e.printStackTrace();
    }
  }
}

// Release resources when sketch closes
void onDestroy() {
  if (recorder != null) recorder.release();
  if (player != null) player.release();
}   ///РОБЕ////








/*


// Use Android's media APIs (no Sound library)
import android.media.MediaRecorder;
import android.media.MediaPlayer;
import java.io.File;
import java.io.IOException;

MediaRecorder recorder;
MediaPlayer player;
File audioFile;
boolean recording = false;
boolean playing = false;
long recordStart;

void setup() {
  size(400, 400);
  audioFile = new File(sketchPath("temp_audio.3gp"));
}

void draw() {
  background(200);
  textAlign(CENTER, CENTER);
  textSize(24);
  
  if (recording) {
    int elapsed = (int)((millis() - recordStart) / 1000);
    text("RECORDING... " + elapsed + "/10s", width/2, height/2);
  } else if (playing) {
    text("🔊 LOOPING (tap to re‑record)", width/2, height/2);
  } else {
    text("👆 TAP SCREEN TO RECORD 10s", width/2, height/2);
  }
  
  // Stop after 10 seconds
  if (recording && (millis() - recordStart >= 10000)) {
    finishRecording();
  }
}

void mousePressed() {
  if (recording) return;
  
  // Stop any current playback
  if (playing) {
    player.stop();
    player.release();
    player = null;
    playing = false;
  }
  
  startRecording();
}

void startRecording() {
  try {
    if (audioFile.exists()) audioFile.delete();
    audioFile.createNewFile();
    
    recorder = new MediaRecorder();
    recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
    recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
    recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
    recorder.setOutputFile(audioFile.getAbsolutePath());
    recorder.prepare();
    recorder.start();
    
    recording = true;
    recordStart = millis();
  } catch (SecurityException e) {
    println("✋ MICROPHONE PERMISSION DENIED – add it in the Android tab!");
    e.printStackTrace();
  } catch (Exception e) {
    e.printStackTrace();
  }
}

void finishRecording() {
  if (recorder != null) {
    recorder.stop();
    recorder.release();
    recorder = null;
  }
  recording = false;
  
  if (audioFile.exists()) {
    try {
      player = new MediaPlayer();
      player.setDataSource(audioFile.getAbsolutePath());
      player.prepare();
      player.setLooping(true);
      player.start();
      playing = true;
    } catch (IOException e) {
      e.printStackTrace();
    }
  }
}

// Release resources when sketch closes
void onDestroy() {
  if (recorder != null) recorder.release();
  if (player != null) player.release();
}





// Use Android's media APIs (no Sound library)
import android.media.MediaRecorder;
import android.media.MediaPlayer;
import java.io.File;
import java.io.IOException;

MediaRecorder recorder;
MediaPlayer player;
File audioFile;
boolean recording = false;
boolean playing = false;
long recordStart;

void setup() {
  size(400, 400);
  audioFile = new File(sketchPath("temp_audio.3gp"));
}

void draw() {
  background(200);
  textAlign(CENTER, CENTER);
  textSize(24);
  
  if (recording) {
    int elapsed = (int)((millis() - recordStart) / 1000);
    text("RECORDING... " + elapsed + "/10s", width/2, height/2);
  } else if (playing) {
    text("🔊 LOOPING (tap to re‑record)", width/2, height/2);
  } else {
    text("👆 TAP SCREEN TO RECORD 10s", width/2, height/2);
  }
  
  // Stop after 10 seconds
  if (recording && (millis() - recordStart >= 10000)) {
    finishRecording();
  }
}

void mousePressed() {
  if (recording) return;
  
  // Stop any current playback
  if (playing) {
    player.stop();
    player.release();
    player = null;
    playing = false;
  }
  
  startRecording();
}

void startRecording() {
  try {
    if (audioFile.exists()) audioFile.delete();
    audioFile.createNewFile();
    
    recorder = new MediaRecorder();
    recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
    recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
    recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
    recorder.setOutputFile(audioFile.getAbsolutePath());
    recorder.prepare();
    recorder.start();
    
    recording = true;
    recordStart = millis();
  } catch (SecurityException e) {
    println("✋ MICROPHONE PERMISSION DENIED – add it in the Android tab!");
    e.printStackTrace();
  } catch (Exception e) {
    e.printStackTrace();
  }
}

void finishRecording() {
  if (recorder != null) {
    recorder.stop();
    recorder.release();
    recorder = null;
  }
  recording = false;
  
  if (audioFile.exists()) {
    try {
      player = new MediaPlayer();
      player.setDataSource(audioFile.getAbsolutePath());
      player.prepare();
      player.setLooping(true);
      player.start();
      playing = true;
    } catch (IOException e) {
      e.printStackTrace();
    }
  }
}

// Release resources when sketch closes
void onDestroy() {
  if (recorder != null) recorder.release();
  if (player != null) player.release();
}



// Use Android's media APIs (no Sound library)
import android.media.MediaRecorder;
import android.media.MediaPlayer;
import java.io.File;
import java.io.IOException;

MediaRecorder recorder;
MediaPlayer player;
File audioFile;
boolean recording = false;
boolean playing = false;
long recordStart;

void setup() {
  size(400, 400);
  audioFile = new File(sketchPath("temp_audio.3gp"));
}

void draw() {
  background(200);
  textAlign(CENTER, CENTER);
  textSize(24);
  
  if (recording) {
    int elapsed = (int)((millis() - recordStart) / 1000);
    text("RECORDING... " + elapsed + "/10s", width/2, height/2);
  } else if (playing) {
    text("🔊 LOOPING (tap to re‑record)", width/2, height/2);
  } else {
    text("👆 TAP SCREEN TO RECORD 10s", width/2, height/2);
  }
  
  // Stop after 10 seconds
  if (recording && (millis() - recordStart >= 10000)) {
    finishRecording();
  }
}

void mousePressed() {
  if (recording) return;
  
  // Stop any current playback
  if (playing) {
    player.stop();
    player.release();
    player = null;
    playing = false;
  }
  
  startRecording();
}

void startRecording() {
  try {
    if (audioFile.exists()) audioFile.delete();
    audioFile.createNewFile();
    
    recorder = new MediaRecorder();
    recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
    recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
    recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
    recorder.setOutputFile(audioFile.getAbsolutePath());
    recorder.prepare();
    recorder.start();
    
    recording = true;
    recordStart = millis();
  } catch (SecurityException e) {
    println("✋ MICROPHONE PERMISSION DENIED – add it in the Android tab!");
    e.printStackTrace();
  } catch (Exception e) {
    e.printStackTrace();
  }
}

void finishRecording() {
  if (recorder != null) {
    recorder.stop();
    recorder.release();
    recorder = null;
  }
  recording = false;
  
  if (audioFile.exists()) {
    try {
      player = new MediaPlayer();
      player.setDataSource(audioFile.getAbsolutePath());
      player.prepare();
      player.setLooping(true);
      player.start();
      playing = true;
    } catch (IOException e) {
      e.printStackTrace();
    }
  }
}

// Release resources when sketch closes
void onDestroy() {
  if (recorder != null) recorder.release();
  if (player != null) player.release();
}

















*/

/*

// Android media APIs – no Processing Sound library
import android.media.MediaRecorder;
import android.media.MediaPlayer;
import java.io.File;
import java.io.IOException;

MediaRecorder recorder;
MediaPlayer player;
File audioFile;
boolean recording = false;
boolean playing = false;
long recordStart;

void setup() {
  size(400, 400);
  
  // Create a writable file in the sketch's private storage
  audioFile = new File(sketchPath("temp_audio.3gp"));
  
  // The RECORD_AUDIO permission must be declared in the Android tab.
  // If not granted, MediaRecorder will throw an exception.
}

void draw() {
  background(200);
  textAlign(CENTER, CENTER);
  textSize(24);
  
  if (recording) {
    int elapsed = (int)((millis() - recordStart) / 1000);
    text("RECORDING... " + elapsed + "/10s", width/2, height/2);
  } else if (playing) {
    text("🔊 LOOPING (tap to re‑record)", width/2, height/2);
  } else {
    text("👆 TAP SCREEN TO RECORD 10s", width/2, height/2);
  }
  
  // Stop after 10 seconds
  if (recording && (millis() - recordStart >= 10000)) {
    finishRecording();
  }
}

void mousePressed() {
  if (recording) return;
  
  // Stop playback if any
  if (playing) {
    player.stop();
    player.release();
    player = null;
    playing = false;
  }
  
  startRecording();
}

void startRecording() {
  try {
    // Delete old file if it exists
    if (audioFile.exists()) audioFile.delete();
    audioFile.createNewFile();
    
    recorder = new MediaRecorder();
    recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
    recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
    recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
    recorder.setOutputFile(audioFile.getAbsolutePath());
    recorder.prepare();
    recorder.start();
    
    recording = true;
    recordStart = millis();
  } catch (IOException | SecurityException e) {
    e.printStackTrace();
    // If permission missing, show message
    if (e instanceof SecurityException) {
      println("MICROPHONE PERMISSION DENIED – add it in the Android tab!");
    }
  }
}

void finishRecording() {
  if (recorder != null) {
    recorder.stop();
    recorder.release();
    recorder = null;
  }
  recording = false;
  
  // Play if file exists
  if (audioFile.exists()) {
    try {
      player = new MediaPlayer();
      player.setDataSource(audioFile.getAbsolutePath());
      player.prepare();
      player.setLooping(true);
      player.start();
      playing = true;
    } catch (IOException e) {
      e.printStackTrace();
    }
  }
}

// Release resources when sketch closes
void onDestroy() {
  if (recorder != null) recorder.release();
  if (player != null) player.release();
}

*/













/*

// Use Android's built‑in audio APIs – no Sound library required
import android.media.MediaRecorder;
import android.media.MediaPlayer;
import java.io.File;
import java.io.IOException;

MediaRecorder recorder;
MediaPlayer player;
File audioFile;
boolean recording = false;
boolean playing = false;
long recordStart;

void setup() {
  size(400, 400);
  
  // Use internal storage (no WRITE_EXTERNAL_STORAGE needed)
  audioFile = new File(getFilesDir(), "temp_audio.3gp");
  
  // Request RECORD_AUDIO permission (Android will ask)
  if (checkSelfPermission("android.permission.RECORD_AUDIO") != 0) {
    requestPermissions(new String[]{"android.permission.RECORD_AUDIO"}, 0);
  }
}

void draw() {
  background(200);
  textAlign(CENTER, CENTER);
  textSize(24);
  
  if (recording) {
    int elapsed = (int)((millis() - recordStart) / 1000);
    text("RECORDING... " + elapsed + "/10s", width/2, height/2);
  } else if (playing) {
    text("🔊 LOOPING (tap to re‑record)", width/2, height/2);
  } else {
    text("👆 TAP SCREEN TO RECORD 10s", width/2, height/2);
  }
  
  // Stop recording after 10 seconds
  if (recording && (millis() - recordStart >= 10000)) {
    finishRecording();
  }
}

void mousePressed() {
  if (recording) return;
  
  // Stop playback if any
  if (playing) {
    player.stop();
    player.release();
    player = null;
    playing = false;
  }
  
  startRecording();
}

void startRecording() {
  try {
    if (audioFile.exists()) audioFile.delete();
    audioFile.createNewFile();
    
    recorder = new MediaRecorder();
    recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
    recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
    recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
    recorder.setOutputFile(audioFile.getAbsolutePath());
    recorder.prepare();
    recorder.start();
    
    recording = true;
    recordStart = millis();
  } catch (IOException e) {
    e.printStackTrace();
  }
}

void finishRecording() {
  if (recorder != null) {
    recorder.stop();
    recorder.release();
    recorder = null;
  }
  recording = false;
  
  // Start playback if file exists
  if (audioFile.exists()) {
    try {
      player = new MediaPlayer();
      player.setDataSource(audioFile.getAbsolutePath());
      player.prepare();
      player.setLooping(true);
      player.start();
      playing = true;
    } catch (IOException e) {
      e.printStackTrace();
    }
  }
}

// Clean up when sketch closes
void onDestroy() {
  if (recorder != null) recorder.release();
  if (player != null) player.release();
}
*/
















/*
import processing.sound.*;

AudioIn mic;
AudioRecorder recorder;
AudioSample loopSample;

String tempFile = "temp_recording.wav";
boolean recording = false;
boolean playing = false;
long recordStart;

void setup() {
  size(400, 400);
  
  mic = new AudioIn(this);
  mic.start();
}

void draw() {
  background(200);
  textAlign(CENTER, CENTER);
  textSize(24);
  
  if (recording) {
    int elapsed = (int)((millis() - recordStart) / 1000);
    text("RECORDING... " + elapsed + "/10s", width/2, height/2);
  } else if (playing) {
    text("🔊 LOOPING (tap to re‑record)", width/2, height/2);
  } else {
    text("👆 TAP SCREEN TO RECORD 10s", width/2, height/2);
  }
  
  // Stop recording after 10 seconds
  if (recording && (millis() - recordStart >= 10000)) {
    finishRecording();
  }
}

void mousePressed() {
  if (recording) return;
  
  if (playing) {
    loopSample.stop();
    loopSample = null;
    playing = false;
  }
  
  startRecording();
}

void startRecording() {
  // Delete old temp file
  File f = new File(sketchPath(tempFile));
  if (f.exists()) f.delete();
  
  recorder = new AudioRecorder(this, mic, sketchPath(tempFile));
  recorder.record();
  recording = true;
  recordStart = millis();
}

void finishRecording() {
  recorder.stop();
  recording = false;
  
  String path = sketchPath(tempFile);
  File f = new File(path);
  if (f.exists()) {
    loopSample = new AudioSample(this, path);
    loopSample.loop();
    playing = true;
    f.delete();  // remove file – audio is now in RAM
  }
}

*/













/*
import processing.sound.*;

AudioIn mic;
AudioRecorder recorder;
AudioSample loopSample;

String tempFile = "temp_recording.wav";
boolean recording = false;
boolean playing = false;
long recordStart;

void setup() {
  size(400, 400);
  
  mic = new AudioIn(this);
  mic.start();
  
  // Android 9: you must grant RECORD_AUDIO permission manually 
  // (APDE will ask if you add it in the Android tab)
}

void draw() {
  background(200);
  textAlign(CENTER, CENTER);
  textSize(24);
  
  if (recording) {
    int elapsed = (int)((millis() - recordStart) / 1000);
    text("RECORDING... " + elapsed + "/10s", width/2, height/2);
  } else if (playing) {
    text("🔊 LOOPING (tap to re‑record)", width/2, height/2);
  } else {
    text("👆 TAP SCREEN TO RECORD 10s", width/2, height/2);
  }
  
  // Check if 10 seconds have passed
  if (recording && (millis() - recordStart >= 10000)) {
    finishRecording();
  }
}

void mousePressed() {
  // Ignore taps while recording
  if (recording) return;
  
  // Stop any current playback
  if (playing) {
    loopSample.stop();
    loopSample = null;
    playing = false;
  }
  
  // Start a new recording
  startRecording();
}

void startRecording() {
  // Delete any old temp file
  String path = sketchPath(tempFile);
  File f = new File(path);
  if (f.exists()) f.delete();
  
  recorder = new AudioRecorder(this, mic, path);
  recorder.record();
  recording = true;
  recordStart = millis();
}

void finishRecording() {
  recorder.stop();
  recording = false;
  
  // Load the recorded file into an AudioSample (stays in RAM)
  String path = sketchPath(tempFile);
  File f = new File(path);
  if (f.exists()) {
    loopSample = new AudioSample(this, path);
    loopSample.loop();   // start looping immediately
    playing = true;
    
    // Delete the temporary file (audio is now in memory)
    f.delete();
  } else {
    println("Recording failed – file not found.");
  }
}
*/
























/*




import processing.sound.*;

// Audio objects
AudioIn mic;
AudioSample loopSample;

// Recording buffer
float[] track;
int sampleRate;
int totalSamples;          // samples for 10 seconds

// Recording state
volatile boolean recording = false;
volatile boolean stopRecording = false;
volatile int samplesRead = 0;

// Playback state
boolean playing = false;

// ----- Setup -----
void setup() {
  size(400, 400);
  
  mic = new AudioIn(this);
  mic.start();
  sampleRate = (int)mic.sampleRate();
  totalSamples = sampleRate * 10;   // 10 seconds
  
  // Request Android permissions (RECORD_AUDIO)
  if (System.getProperty("java.runtime.name").contains("Android")) {
    requestPermissions(new String[]{"android.permission.RECORD_AUDIO"}, 0);
  }
}

// ----- Draw -----
void draw() {
  background(200);
  
  // Display status
  fill(0);
  textAlign(CENTER, CENTER);
  textSize(24);
  
  if (recording) {
    int elapsed = (int)(samplesRead * 1000.0 / sampleRate);
    text("RECORDING... " + elapsed + "/10000 ms", width/2, height/2);
  } else if (playing) {
    text("🔊 LOOPING (tap to re‑record)", width/2, height/2);
  } else {
    text("👆 TAP SCREEN TO RECORD", width/2, height/2);
  }
}

// ----- Touch handling -----
void mousePressed() {
  if (recording) return;   // ignore touches while recording
  
  // Stop any current playback
  if (playing) {
    loopSample.stop();
    loopSample = null;
    playing = false;
  }
  
  // Start new recording
  startRecording();
}

// ----- Start recording in background thread -----
void startRecording() {
  recording = true;
  stopRecording = false;
  samplesRead = 0;
  track = new float[totalSamples];
  thread("recordThread");
}

// ----- Background thread: read samples at correct rate -----
void recordThread() {
  long startTime = System.nanoTime();
  int idx = 0;
  
  while (recording && idx < totalSamples && !stopRecording) {
    track[idx] = mic.read();          // get one sample
    idx++;
    samplesRead = idx;
    
    // Calculate when the next sample should be read
    long expectedTime = startTime + (idx * 1000000000L) / sampleRate;
    long now = System.nanoTime();
    long sleepTime = (expectedTime - now) / 1000000L; // ms
    if (sleepTime > 0) {
      try { Thread.sleep(sleepTime); } catch (InterruptedException e) {}
    }
  }
  
  recording = false;
  
  // If we got the full 10 seconds, start looping playback
  if (idx >= totalSamples) {
    playLoop();
  } else {
    // Stopped early → discard track
    track = null;
  }
}

// ----- Play the recorded track in a loop -----
void playLoop() {
  if (track == null || track.length == 0) return;
  loopSample = new AudioSample(this, track, sampleRate);
  loopSample.loop();        // repeat indefinitely
  playing = true;
}






*/
















/*


import processing.sound.*;

// ----- Audio objects -----
AudioIn mic;
AudioSample loopSample;

// ----- Track buffer (RAM) -----
float[] track;
int sampleRate;
int totalSamples;        // number of samples for 10 seconds

// ----- Recording control -----
volatile boolean recording = false;
volatile boolean stopRecording = false;
volatile int samplesRead = 0;

// ----- Playback control -----
boolean playing = false;

// ----- GUI -----
final int RECORD_BTN_X = 100;
final int RECORD_BTN_Y = 100;
final int RECORD_BTN_W = 200;
final int RECORD_BTN_H = 100;

void setup() {
  size(400, 300);
  
  // Init microphone
  mic = new AudioIn(this);
  mic.start();
 //// 
sampleRate = (int)int(mic.sampleRate() );
    sampleRate=32000;
  totalSamples = sampleRate * 10;   // 10 seconds
  */
  // Request Android permissions
/*
  if (System.getProperty("java.runtime.name").contains("Android")) {
    requestPermissions(new String[]{
      "android.permission.RECORD_AUDIO"
    }, 0);
  }

        */




/*

}

void draw() {
  background(200);
  
  // ----- Draw record button -----
  fill(recording ? color(255,0,0) : (playing ? color(100,200,100) : color(0,200,0)));
  rect(RECORD_BTN_X, RECORD_BTN_Y, RECORD_BTN_W, RECORD_BTN_H);
  fill(0);
  textAlign(CENTER, CENTER);
  textSize(24);
  if (recording) {
    text("RECORDING...", RECORD_BTN_X + RECORD_BTN_W/2, RECORD_BTN_Y + RECORD_BTN_H/2);
  } else if (playing) {
    text("LOOPING", RECORD_BTN_X + RECORD_BTN_W/2, RECORD_BTN_Y + RECORD_BTN_H/2);
  } else {
    text("RECORD 10s", RECORD_BTN_X + RECORD_BTN_W/2, RECORD_BTN_Y + RECORD_BTN_H/2);
  }
  
  // ----- Status text -----
  fill(0);
  textAlign(LEFT, TOP);
  textSize(16);
  if (recording) {
    int elapsed = (int)(samplesRead * 1000.0 / sampleRate);
    text("Recording: " + elapsed + " / 10000 ms", 10, 220);
  } else if (playing) {
    text("Playing loop (tap to re-record)", 10, 220);
  } else {
    text("Tap the button to record", 10, 220);
  }
}

void mousePressed() {
  // Check if user tapped the button
  if (mouseX > RECORD_BTN_X && mouseX < RECORD_BTN_X + RECORD_BTN_W &&
      mouseY > RECORD_BTN_Y && mouseY < RECORD_BTN_Y + RECORD_BTN_H) {
    if (!recording) {
      // Stop playback if any
      if (playing) {
        loopSample.stop();
        loopSample = null;
        playing = false;
      }
      startRecording();
    }
  }
}

// ----- Start recording in background thread -----
void startRecording() {
  recording = true;
  stopRecording = false;
  samplesRead = 0;
  track = new float[totalSamples];
  // Launch the recording thread
  thread("recordThread");
}

// ----- Background thread: reads samples from microphone at sample rate -----
void recordThread() {
  long startTime = System.nanoTime();
  int idx = 0;
  while (recording && idx < totalSamples && !stopRecording) {
    // Read one sample
 //////////   float s = mic.read();
           float s = int(random(5000,15000));


    track[idx] = s;
    idx++;
    samplesRead = idx;
    
    // Calculate when the next sample should be read (based on sample rate)
    long expectedTime = startTime + (idx * 1000000000L) / sampleRate;
    long now = System.nanoTime();
    long sleepTime = (expectedTime - now) / 1000000L; // in milliseconds
    if (sleepTime > 0) {
      try {
        Thread.sleep(sleepTime);
      } catch (InterruptedException e) {}
    }
  }
  
  // Recording finished
  recording = false;
  if (idx >= totalSamples) {
    // Track full → start looping playback
    playLoop();
  } else {
    // Recording stopped early (e.g., user tapped again) – discard
    track = null;
  }
}

// ----- Play the recorded track in a loop -----
void playLoop() {
  if (track == null || track.length == 0) return;
  // Create AudioSample from the float array
  loopSample = new AudioSample(this, track, sampleRate);
  loopSample.loop();   // repeat indefinitely
  playing = true;
}



*/
























/*

import processing.sound.*;

// ----- Audio objects -----
AudioIn mic;
AudioSample samplePlay;
float[] track1, track2;

// ----- Recording state -----
boolean recording = false;
int recordingTrack = 0;          // 1 or 2
long recordStartTime;
int sampleRate;
int totalSamples;                // samples for 10 seconds
volatile boolean stopRecording = false;

// ----- Playback state -----
boolean isPlaying = false;

// ----- File name for mixed output -----
String mixFileName = "mixed_output.wav";

// ----- GUI -----
final int KEY_W = 150;
final int KEY_H = 150;
final int KEY_Y = 200;

void setup() {
  size(800, 600);
  
  // Init microphone
  mic = new AudioIn(this);
  mic.start();
  sampleRate = (int)mic.sampleRate();
  totalSamples = sampleRate * 10;   // 10 seconds
  
  // Request permissions (Android)
  if (System.getProperty("java.runtime.name").contains("Android")) {
    requestPermissions(new String[]{
      "android.permission.RECORD_AUDIO",
      "android.permission.WRITE_EXTERNAL_STORAGE"
    }, 0);
  }
  
  // Start the background recorder thread
  thread("recordThread");
}

void draw() {
  background(200);
  
  // ----- Draw keys -----
  // Key 1
  fill((recording && recordingTrack == 1) ? color(255,100,100) : 
       (track1 != null ? color(100,200,100) : color(180)));
  rect(100, KEY_Y, KEY_W, KEY_H);
  fill(0);
  textAlign(CENTER, CENTER);
  text("Record 1", 175, KEY_Y + KEY_H/2);
  
  // Key 2
  fill((recording && recordingTrack == 2) ? color(255,100,100) : 
       (track2 != null ? color(100,200,100) : color(180)));
  rect(325, KEY_Y, KEY_W, KEY_H);
  fill(0);
  text("Record 2", 400, KEY_Y + KEY_H/2);
  
  // Key 3 (Mix & Save)
  boolean bothReady = (track1 != null && track2 != null);
  fill(isPlaying ? color(100,255,100) : (bothReady ? color(100,200,100) : color(150)));
  rect(550, KEY_Y, KEY_W, KEY_H);
  fill(0);
  text("Mix & Save", 625, KEY_Y + KEY_H/2);
  
  // ----- Status display -----
  fill(0);
  textAlign(LEFT, TOP);
  if (recording) {
    int elapsed = (int)((millis() - recordStartTime) / 1000);
    text("Recording track " + recordingTrack + " ... " + elapsed + "s", 10, 10);
  } else if (isPlaying) {
    text("Playing mixed track ...", 10, 10);
  } else {
    text("Touch a key to record (10s) or mix", 10, 10);
  }
  text("Track1: " + (track1 != null ? track1.length + " samples" : "empty"), 10, 50);
  text("Track2: " + (track2 != null ? track2.length + " samples" : "empty"), 10, 70);
  
  // Check if playback finished
  if (isPlaying && samplePlay != null && !samplePlay.isPlaying()) {
    isPlaying = false;
    samplePlay = null;
    println("Playback finished.");
  }
}

void mousePressed() {
  if (recording || isPlaying) return;
  
  float x = mouseX, y = mouseY;
  
  if (x > 100 && x < 100+KEY_W && y > KEY_Y && y < KEY_Y+KEY_H) {
    startRecording(1);
  } else if (x > 325 && x < 325+KEY_W && y > KEY_Y && y < KEY_Y+KEY_H) {
    startRecording(2);
  } else if (x > 550 && x < 550+KEY_W && y > KEY_Y && y < KEY_Y+KEY_H) {
    if (bothReady()) {
      mixAndPlay();
    } else {
      println("Please record both tracks first.");
    }
  }
}

// ----- Start recording (track 1 or 2) -----
void startRecording(int track) {
  recordingTrack = track;
  recording = true;
  stopRecording = false;
  recordStartTime = millis();
  // Allocate buffer (will be filled by background thread)
  if (track == 1) track1 = new float[totalSamples];
  else track2 = new float[totalSamples];
  // Clear buffer (optional)
  // The background thread will fill it.
}

// ----- Background thread: reads samples from mic -----
void recordThread() {
  int index = 0;
  while (true) {
    if (recording) {
      // Read one sample from microphone
      float sample = mic.read();
      // Store in the appropriate track
      if (recordingTrack == 1 && track1 != null && index < track1.length) {
        track1[index] = sample;
      } else if (recordingTrack == 2 && track2 != null && index < track2.length) {
        track2[index] = sample;
      }
      index++;
      
      // Check if 10 seconds reached
      if (index >= totalSamples || stopRecording) {
        // Stop recording
        recording = false;
        recordingTrack = 0;
        println("Track recorded: " + (recordingTrack == 1 ? "1" : "2") + " (samples: " + index + ")");
        // Truncate if shorter? (should be exact)
        if (index < totalSamples) {
          // Resize array to actual length (if stopped early)
          if (recordingTrack == 1) track1 = Arrays.copyOf(track1, index);
          else track2 = Arrays.copyOf(track2, index);
        }
      }
    }
    // Sleep to match sample rate (approx)
    // We read one sample per iteration; we need to wait 1/sampleRate seconds.
    // For 44100 Hz, wait ~22.7 µs -> use delayMicroseconds? Processing doesn't have that.
    // Use a small delay to avoid busy loop, but this may cause sample loss.
    // A better approach: read multiple samples per iteration.
    // We'll use a loop that reads as many samples as possible in a time slice.
    // For simplicity, we'll read in chunks.
    // We'll implement a more robust method: read available samples.
    try {
      Thread.sleep(1); // 1 ms, will read ~44 samples per iteration at 44.1kHz? Not accurate.
    } catch (Exception e) {}
  }
}

// ----- Check if both tracks are ready -----
boolean bothReady() {
  return (track1 != null && track1.length > 0 && track2 != null && track2.length > 0);
}

// ----- Mix and play, then save to file -----
void mixAndPlay() {
  // Determine max length (both should be same, but handle different)
  int len = min(track1.length, track2.length);
  float[] mix = new float[len];
  for (int i = 0; i < len; i++) {
    mix[i] = track1[i] + track2[i];
  }
  
  // Normalize to 0.9 peak
  float peak = 0;
  for (float v : mix) if (abs(v) > peak) peak = abs(v);
  if (peak > 0) {
    float scale = 0.9f / peak;
    for (int i = 0; i < len; i++) mix[i] *= scale;
  }
  
  // Play the mix
  samplePlay = new AudioSample(this, mix, sampleRate);
  samplePlay.play();
  isPlaying = true;
  
  // Write the mixed data to a WAV file (after playback? We can write immediately)
  // We'll write after playback, but we can also write now. We'll write after playback.
  // We'll launch a thread to wait for playback to finish and then save.
  thread("saveMixThread");
}

// ----- Background thread to save mix after playback -----
void saveMixThread() {
  // Wait until playback is done
  while (isPlaying) {
    try { Thread.sleep(100); } catch (Exception e) {}
  }
  // Now save the mix array to a WAV file
  // We need the mix array from the last mix - we can store it globally.
  // We'll store it in a global variable 'mixData'.
  if (mixData != null) {
    saveWav(mixData, sampleRate, mixFileName);
    println("Mix saved to: " + mixFileName);
  }
}

// Global variable to hold mix data for saving
float[] mixData = null;

// Modify mixAndPlay to store mixData
// In mixAndPlay, after normalizing, set mixData = mix;

// ----- Write float array to WAV file -----
void saveWav(float[] samples, int sampleRate, String filename) {
  int numSamples = samples.length;
  int numChannels = 1;
  int bitsPerSample = 16;
  int bytesPerSample = bitsPerSample / 8;
  int dataSize = numSamples * bytesPerSample;
  int headerSize = 44;
  int fileSize = headerSize + dataSize;
  
  ByteBuffer buffer = ByteBuffer.allocate(fileSize);
  buffer.order(ByteOrder.LITTLE_ENDIAN);
  
  // RIFF header
  buffer.put("RIFF".getBytes());
  buffer.putInt(fileSize - 8); // chunk size
  buffer.put("WAVE".getBytes());
  buffer.put("fmt ".getBytes());
  buffer.putInt(16); // fmt chunk size
  buffer.putShort((short)1); // audio format (PCM)
  buffer.putShort((short)numChannels);
  buffer.putInt(sampleRate);
  buffer.putInt(sampleRate * numChannels * bytesPerSample); // byte rate
  buffer.putShort((short)(numChannels * bytesPerSample)); // block align
  buffer.putShort((short)bitsPerSample);
  buffer.put("data".getBytes());
  buffer.putInt(dataSize);
  
  // Write samples as 16-bit signed integers
  for (float f : samples) {
    // Clamp to [-1, 1] (should be already)
    if (f > 1) f = 1;
    if (f < -1) f = -1;
    short s = (short)(f * 32767);
    buffer.putShort(s);
  }
  
  saveBytes(sketchPath(filename), buffer.array());
}





*/











/*

import processing.sound.*;

// ----- Audio objects -----
AudioIn mic;
AudioOutput out;
AudioRecorder recorder1, recorder2, mixRecorder;
AudioSample sample1, sample2, mixSample;

// ----- Recording state -----
boolean recording1 = false;
boolean recording2 = false;
boolean mixing = false;
long recordStart;

// ----- File names -----
String file1 = "track1.wav";
String file2 = "track2.wav";
String mixFile = "mixed_output.wav";

// ----- GUI -----
final int KEY_W = 150;
final int KEY_H = 150;
final int KEY_Y = 200;

void setup() {
  size(800, 600);
  
  // Init audio
  mic = new AudioIn(this);
  mic.start();
  out = new AudioOutput(this);
  
  // Request permissions (Android)
  if (System.getProperty("java.runtime.name").contains("Android")) {
    requestPermissions(new String[]{
      "android.permission.RECORD_AUDIO",
      "android.permission.WRITE_EXTERNAL_STORAGE"
    }, 0);
  }
}

void draw() {
  background(200);
  
  // ----- Draw keys -----
  fill(recording1 ? color(255,100,100) : (new File(sketchPath(file1)).exists() ? color(100,200,100) : color(180)));
  rect(100, KEY_Y, KEY_W, KEY_H);
  fill(0);
  textAlign(CENTER, CENTER);
  text("Record 1", 175, KEY_Y + KEY_H/2);
  
  fill(recording2 ? color(255,100,100) : (new File(sketchPath(file2)).exists() ? color(100,200,100) : color(180)));
  rect(325, KEY_Y, KEY_W, KEY_H);
  fill(0);
  text("Record 2", 400, KEY_Y + KEY_H/2);
  
  boolean bothReady = new File(sketchPath(file1)).exists() && new File(sketchPath(file2)).exists();
  fill(mixing ? color(100,255,100) : (bothReady ? color(100,200,100) : color(150)));
  rect(550, KEY_Y, KEY_W, KEY_H);
  fill(0);
  text("Mix & Save", 625, KEY_Y + KEY_H/2);
  
  // ----- Status -----
  fill(0);
  textAlign(LEFT, TOP);
  if (recording1) {
    text("Recording 1 ... " + (millis()-recordStart)/1000 + "s", 10, 10);
  } else if (recording2) {
    text("Recording 2 ... " + (millis()-recordStart)/1000 + "s", 10, 10);
  } else if (mixing) {
    text("Mixing and saving ...", 10, 10);
  } else {
    text("Touch a key to record (10s) or mix", 10, 10);
  }
  text("Track1: " + (new File(sketchPath(file1)).exists() ? "ready" : "empty"), 10, 50);
  text("Track2: " + (new File(sketchPath(file2)).exists() ? "ready" : "empty"), 10, 70);
  
  // ----- Handle recording timeouts -----
  if (recording1 && (millis() - recordStart >= 10000)) {
    stopRecording(1);
  }
  if (recording2 && (millis() - recordStart >= 10000)) {
    stopRecording(2);
  }
  
  // ----- Handle mixing progress -----
  if (mixing && mixSample != null && !mixSample.isPlaying()) {
    // Finished playing -> stop recorder
    if (mixRecorder != null) {
      mixRecorder.stop();
      mixRecorder = null;
    }
    mixing = false;
    println("Mixed file saved: " + mixFile);
  }
}

void mousePressed() {
  if (recording1 || recording2 || mixing) return;
  
  float x = mouseX, y = mouseY;
  
  if (x > 100 && x < 100+KEY_W && y > KEY_Y && y < KEY_Y+KEY_H) {
    startRecording(1);
  } else if (x > 325 && x < 325+KEY_W && y > KEY_Y && y < KEY_Y+KEY_H) {
    startRecording(2);
  } else if (x > 550 && x < 550+KEY_W && y > KEY_Y && y < KEY_Y+KEY_H) {
    if (new File(sketchPath(file1)).exists() && new File(sketchPath(file2)).exists()) {
      mixAndSave();
    } else {
      println("Please record both tracks first.");
    }
  }
}

void startRecording(int track) {
  // Delete old file if exists
  String path = (track == 1) ? sketchPath(file1) : sketchPath(file2);
  File f = new File(path);
  if (f.exists()) f.delete();
  
  // Create recorder
  if (track == 1) {
    recorder1 = new AudioRecorder(this, mic, path);
    recorder1.record();
    recording1 = true;
  } else {
    recorder2 = new AudioRecorder(this, mic, path);
    recorder2.record();
    recording2 = true;
  }
  recordStart = millis();
}

void stopRecording(int track) {
  if (track == 1 && recorder1 != null) {
    recorder1.stop();
    recorder1 = null;
    recording1 = false;
  } else if (track == 2 && recorder2 != null) {
    recorder2.stop();
    recorder2 = null;
    recording2 = false;
  }
  println("Track " + track + " recorded.");
}

void mixAndSave() {
  // Load both tracks as AudioSample
  sample1 = new AudioSample(this, sketchPath(file1));
  sample2 = new AudioSample(this, sketchPath(file2));
  
  // Get raw sample arrays
  float[] data1 = sample1.samples();
  float[] data2 = sample2.samples();
  int len = min(data1.length, data2.length);
  float[] mix = new float[len];
  
  // Mix (sum)
  for (int i = 0; i < len; i++) {
    mix[i] = data1[i] + data2[i];
  }
  
  // Normalize to maximum 0.9 peak
  float maxVal = 0;
  for (float v : mix) if (abs(v) > maxVal) maxVal = abs(v);
  if (maxVal > 0) {
    float scale = 0.9f / maxVal;
    for (int i = 0; i < len; i++) mix[i] *= scale;
  }
  
  // Create new AudioSample from mixed data (using same sample rate as input)
  mixSample = new AudioSample(this, mix, (int)sample1.sampleRate());
  
  // Prepare to record the output
  String mixPath = sketchPath(mixFile);
  File f = new File(mixPath);
  if (f.exists()) f.delete();
  mixRecorder = new AudioRecorder(this, out, mixPath);
  mixRecorder.record();
  
  // Play the mix
  mixSample.play();
  mixing = true;
}

*/














/*

import processing.sound.*;

// ----- Audio objects -----
AudioIn mic;
AudioOutput out;
AudioRecorder recorder;
AudioSample sample;

// ----- Track storage (in memory) -----
float[] track1 = new float[0];
float[] track2 = new float[0];
int sampleRate;
int totalSamples;          // number of samples for 10 seconds

// ----- Recording state -----
boolean isRecording1 = false;
boolean isRecording2 = false;
boolean isMixing = false;
long recordStartTime;

// ----- Output file name -----
String mixFileName = "mixed_output.wav";

// ----- GUI constants -----
final int KEY_W = 150;
final int KEY_H = 150;
final int KEY_Y = 200;

void setup() {
  size(800, 600);
  
  // Audio init
  mic = new AudioIn(this);
  mic.start();
  out = new AudioOutput(this);
  sampleRate = (int)mic.sampleRate();
  totalSamples = sampleRate * 10;   // 10 seconds
  
  // Request Android permissions (if needed)
  if (System.getProperty("java.runtime.name").contains("Android")) {
    requestPermissions(new String[]{
      "android.permission.RECORD_AUDIO",
      "android.permission.WRITE_EXTERNAL_STORAGE"
    }, 0);
  }
}

void draw() {
  background(200);
  
  // ----- Draw the 3 keys -----
  // Key 1
  fill(recording1() ? color(255,100,100) : color(180));
  rect(100, KEY_Y, KEY_W, KEY_H);
  fill(0);
  textAlign(CENTER, CENTER);
  text("Record 1", 175, KEY_Y + KEY_H/2);
  
  // Key 2
  fill(recording2() ? color(255,100,100) : color(180));
  rect(325, KEY_Y, KEY_W, KEY_H);
  fill(0);
  text("Record 2", 400, KEY_Y + KEY_H/2);
  
  // Key 3
  boolean bothReady = (track1.length > 0 && track2.length > 0);
  fill(isMixing ? color(100,255,100) : (bothReady ? color(100,200,100) : color(150)));
  rect(550, KEY_Y, KEY_W, KEY_H);
  fill(0);
  text("Mix & Save", 625, KEY_Y + KEY_H/2);
  
  // ----- Status display -----
  fill(0);
  textAlign(LEFT, TOP);
  if (isRecording1) {
    text("Recording 1 ... " + (millis()-recordStartTime)/1000 + "s", 10, 10);
  } else if (isRecording2) {
    text("Recording 2 ... " + (millis()-recordStartTime)/1000 + "s", 10, 10);
  } else if (isMixing) {
    text("Mixing and saving ...", 10, 10);
  } else {
    text("Touch a key to record or mix", 10, 10);
  }
  text("Track1 samples: " + track1.length, 10, 50);
  text("Track2 samples: " + track2.length, 10, 70);
  
  // ----- Handle ongoing recording (fill tracks) -----
  if (isRecording1) {
    int idx = (int)((millis() - recordStartTime) * sampleRate / 1000.0);
    if (idx < totalSamples) {
      track1[idx] = mic.read();    // store sample
    } else {
      isRecording1 = false;
      println("Track 1 finished.");
    }
  }
  if (isRecording2) {
    int idx = (int)((millis() - recordStartTime) * sampleRate / 1000.0);
    if (idx < totalSamples) {
      track2[idx] = mic.read();
    } else {
      isRecording2 = false;
      println("Track 2 finished.");
    }
  }
  
  // ----- Handle mixing & saving -----
  if (isMixing) {
    // If the sample finished playing, stop the recorder and finish
    if (sample != null && !sample.isPlaying()) {
      if (recorder != null) {
        recorder.stop();
        recorder = null;
      }
      isMixing = false;
      println("Mixed file saved as: " + mixFileName);
    }
  }
}

void mousePressed() {
  // Ignore touches while busy
  if (isRecording1 || isRecording2 || isMixing) return;
  
  float x = mouseX, y = mouseY;
  
  // Key 1
  if (x > 100 && x < 100+KEY_W && y > KEY_Y && y < KEY_Y+KEY_H) {
    startRecording(1);
  }
  // Key 2
  else if (x > 325 && x < 325+KEY_W && y > KEY_Y && y < KEY_Y+KEY_H) {
    startRecording(2);
  }
  // Key 3
  else if (x > 550 && x < 550+KEY_W && y > KEY_Y && y < KEY_Y+KEY_H) {
    if (track1.length > 0 && track2.length > 0) {
      mixAndSave();
    } else {
      println("Please record both tracks first.");
    }
  }
}

// ----- Helper functions -----
void startRecording(int trackNum) {
  if (trackNum == 1) {
    track1 = new float[totalSamples];
    isRecording1 = true;
  } else {
    track2 = new float[totalSamples];
    isRecording2 = true;
  }
  recordStartTime = millis();
}

boolean recording1() { return isRecording1; }
boolean recording2() { return isRecording2; }

void mixAndSave() {
  // Mix the two tracks (sum)
  int len = min(track1.length, track2.length);
  float[] mix = new float[len];
  for (int i = 0; i < len; i++) {
    mix[i] = track1[i] + track2[i];
  }
  
  // Normalize to maximum loudness (0.9 peak to avoid distortion)
  float maxVal = 0;
  for (float f : mix) {
    if (abs(f) > maxVal) maxVal = abs(f);
  }
  if (maxVal > 0) {
    float scale = 0.9f / maxVal;
    for (int i = 0; i < len; i++) {
      mix[i] *= scale;
    }
  }
  
  // Create an AudioSample from the mixed data
  sample = new AudioSample(this, mix, sampleRate);
  
  // Start recording the audio output to a file
  recorder = new AudioRecorder(this, out, sketchPath(mixFileName));
  recorder.record();
  
  // Play the mixed sample through the output
  sample.play();
  
  isMixing = true;
}






*/





/*

     ////   import java. *;
 ///  import android. *;

import processing.sound.*;

// Grid settings
final int COLS = 9;
final int ROWS = 14;
final int TOTAL_KEYS = COLS * ROWS;

// Audio objects
AudioIn audioIn;
AudioOutput audioOut;
AudioRecorder recorder;
AudioPlayer player;

// Recording state
boolean isRecording = false;
int recordingKey = -1;
long recordStartTime = 0;
final int RECORD_DURATION = 10000; // 10 seconds

// Playback all state
boolean isPlayingAll = false;

// File names
String[] fileNames = new String[TOTAL_KEYS];
String masterFileName = "master_recording.wav";

void setup() {
  size(800, 600); // Adjust as needed
  
  // Initialize audio
  audioIn = new AudioIn(this);
  audioIn.start();
  
  // Create audio output for playback
  audioOut = new AudioOutput(this);
  
  // Prepare file names
  for (int i = 0; i < TOTAL_KEYS; i++) {
    fileNames[i] = "key_" + i + ".wav";
  }
  
  // Request permissions (Android only)
  if (System.getProperty("java.runtime.name").contains("Android")) {
    requestPermissions(new String[]{
      "android.permission.RECORD_AUDIO",
      "android.permission.WRITE_EXTERNAL_STORAGE"
    }, 0);
  }
}

void draw() {
  background(100);
  
  // Draw the grid
  float cellW = width / (float) COLS;
  float cellH = height / (float) ROWS;
  for (int i = 0; i < TOTAL_KEYS; i++) {
    int col = i % COLS;
    int row = i / COLS;
    float x = col * cellW;
    float y = row * cellH;
    
    // Highlight first key differently
    if (i == 0) {
      fill(200, 100, 100);
    } else {
      // Check if this key has a recording file
      File f = new File(sketchPath(fileNames[i]));
      if (f.exists()) {
        fill(100, 200, 100);
      } else {
        fill(150);
      }
    }
    rect(x, y, cellW, cellH);
    
    // Show index
    fill(0);
    textAlign(CENTER, CENTER);
    text(i, x + cellW/2, y + cellH/2);
  }
  
  // Show status
  fill(255);
  textAlign(LEFT, TOP);
  if (isRecording) {
    text("Recording key " + recordingKey + " ... " + 
         ((millis() - recordStartTime) / 1000) + "s", 10, 10);
  } else if (isPlayingAll) {
    text("Playing all files and recording...", 10, 10);
  } else {
    text("Touch a key to record (10s) or touch key 0 to play all", 10, 10);
  }
}

void mousePressed() {
  if (isRecording || isPlayingAll) return; // busy
  
  int keyIndex = getKeyAt(mouseX, mouseY);
  if (keyIndex < 0 || keyIndex >= TOTAL_KEYS) return;
  
  if (keyIndex == 0) {
    // Play all and record
    playAllAndRecord();
  } else {
    // Start recording for this key
    startRecording(keyIndex);
  }
}

int getKeyAt(float mx, float my) {
  float cellW = width / (float) COLS;
  float cellH = height / (float) ROWS;
  int col = (int)(mx / cellW);
  int row = (int)(my / cellH);
  if (col >= COLS || row >= ROWS) return -1;
  return row * COLS + col;
}

// ---------- Recording ----------
void startRecording(int index) {
  if (isRecording) return;
  String filePath = sketchPath(fileNames[index]);
  // Delete old file if exists
  File f = new File(filePath);
  if (f.exists()) f.delete();
  
  // Create recorder from audio input
  recorder = new AudioRecorder(this, audioIn, filePath);
  recorder.record();
  
  isRecording = true;
  recordingKey = index;
  recordStartTime = millis();
}

void checkRecordingTimeout() {
  if (isRecording && (millis() - recordStartTime >= RECORD_DURATION)) {
    stopRecording();
  }
}

void stopRecording() {
  if (recorder != null) {
    recorder.stop();
    recorder = null;
  }
  isRecording = false;
  recordingKey = -1;
}

// ---------- Play all and record ----------
void playAllAndRecord() {
  if (isPlayingAll) return;
  isPlayingAll = true;
  
  // Create recorder from audio output (records the mix)
  String masterPath = sketchPath(masterFileName);
  File f = new File(masterPath);
  if (f.exists()) f.delete();
  
  recorder = new AudioRecorder(this, audioOut, masterPath);
  recorder.record();
  
  // We'll play each file sequentially in a separate thread or using a callback
  // Since we're in the main draw loop, we'll use a state machine.
  // Simpler: use a thread (but Processing on Android may not support threading well)
  // Alternative: use a loop that plays each file and waits for it to finish.
  // We'll do it in a separate function called from draw() when isPlayingAll is true.
  // We'll store a list of files to play and an index.
  // For simplicity, we'll start playing in a loop with delay, but that blocks draw.
  // Better: use a queue and play one after another via events.
  
  // Let's implement a simple sequential playback using a for loop but with delay?
  // That would freeze the UI. Instead, we'll use a callback or a timer.
  // For this example, we'll use a simple approach: 
  // We'll start playing the first file and set a flag. When it finishes, we play the next.
  // But AudioPlayer doesn't have an easy "on finish" callback in Processing Sound.
  // We can check player.isPlaying() in draw() to know when it stops.
  
  // Simpler solution: we can do it in a separate thread, but on Android we need to be careful.
  // I'll implement a state machine in draw():
  // - When isPlayingAll is true, we iterate through files.
  // - We'll maintain a current index and a player.
  // - In draw(), if player is null or not playing, we load next file and play.
  // - We also need to stop recording after all files are played.
  // We'll set up variables.
  
  // Let's set up the state:
  playAllIndex = 0;
  playAllPlayer = null;
  // Start the first file immediately.
  playNextFile();
}

int playAllIndex = 0;
AudioPlayer playAllPlayer = null;

void playNextFile() {
  // Find the next existing file
  while (playAllIndex < TOTAL_KEYS) {
    String path = sketchPath(fileNames[playAllIndex]);
    File f = new File(path);
    if (f.exists()) {
      // Load and play
      playAllPlayer = new AudioPlayer(this, path);
      playAllPlayer.play();
      playAllIndex++; // we'll increment after playing, but we need to know when done
      return;
    }
    playAllIndex++;
  }
  // No more files -> finish
  finishPlayAll();
}

void finishPlayAll() {
  // Stop recording
  if (recorder != null) {
    recorder.stop();
    recorder = null;
  }
  isPlayingAll = false;
  playAllPlayer = null;
  println("Master recording saved as " + masterFileName);
}

void updatePlayAll() {
  if (!isPlayingAll) return;
  
  // Check if current player is still playing
  if (playAllPlayer != null) {
    if (!playAllPlayer.isPlaying()) {
      // Current file finished, load next
      playAllPlayer = null;
      playNextFile();
    }
  } else {
    // If no player, start next
    playNextFile();
  }
}

// ---------- Main loop update ----------
void draw() {
  // ... (drawing code as above)
  
  // Check recording timeout
  checkRecordingTimeout();
  
  // Update playback all state
  updatePlayAll();
}



*/








/*


import processing.sound.*;

// Grid settings
final int COLS = 9;
final int ROWS = 14;
final int TOTAL_KEYS = COLS * ROWS;

// Audio objects
AudioIn audioIn;
AudioOutput audioOut;
AudioRecorder recorder;
AudioPlayer player;

// Recording state
boolean isRecording = false;
int recordingKey = -1;
long recordStartTime = 0;
final int RECORD_DURATION = 10000; // 10 seconds

// Playback all state
boolean isPlayingAll = false;

// File names
String[] fileNames = new String[TOTAL_KEYS];
String masterFileName = "master_recording.wav";

void setup() {
  size(800, 600); // Adjust as needed
  
  // Initialize audio
  audioIn = new AudioIn(this);
  audioIn.start();
  
  // Create audio output for playback
  audioOut = new AudioOutput(this);
  
  // Prepare file names
  for (int i = 0; i < TOTAL_KEYS; i++) {
    fileNames[i] = "key_" + i + ".wav";
  }
  
  // Request permissions (Android only)
  if (System.getProperty("java.runtime.name").contains("Android")) {
    requestPermissions(new String[]{
      "android.permission.RECORD_AUDIO",
      "android.permission.WRITE_EXTERNAL_STORAGE"
    }, 0);
  }
}

void draw() {
  background(100);
  
  // Draw the grid
  float cellW = width / (float) COLS;
  float cellH = height / (float) ROWS;
  for (int i = 0; i < TOTAL_KEYS; i++) {
    int col = i % COLS;
    int row = i / COLS;
    float x = col * cellW;
    float y = row * cellH;
    
    // Highlight first key differently
    if (i == 0) {
      fill(200, 100, 100);
    } else {
      // Check if this key has a recording file
      File f = new File(sketchPath(fileNames[i]));
      if (f.exists()) {
        fill(100, 200, 100);
      } else {
        fill(150);
      }
    }
    rect(x, y, cellW, cellH);
    
    // Show index
    fill(0);
    textAlign(CENTER, CENTER);
    text(i, x + cellW/2, y + cellH/2);
  }
  
  // Show status
  fill(255);
  textAlign(LEFT, TOP);
  if (isRecording) {
    text("Recording key " + recordingKey + " ... " + 
         ((millis() - recordStartTime) / 1000) + "s", 10, 10);
  } else if (isPlayingAll) {
    text("Playing all files and recording...", 10, 10);
  } else {
    text("Touch a key to record (10s) or touch key 0 to play all", 10, 10);
  }
}

void mousePressed() {
  if (isRecording || isPlayingAll) return; // busy
  
  int keyIndex = getKeyAt(mouseX, mouseY);
  if (keyIndex < 0 || keyIndex >= TOTAL_KEYS) return;
  
  if (keyIndex == 0) {
    // Play all and record
    playAllAndRecord();
  } else {
    // Start recording for this key
    startRecording(keyIndex);
  }
}

int getKeyAt(float mx, float my) {
  float cellW = width / (float) COLS;
  float cellH = height / (float) ROWS;
  int col = (int)(mx / cellW);
  int row = (int)(my / cellH);
  if (col >= COLS || row >= ROWS) return -1;
  return row * COLS + col;
}

// ---------- Recording ----------
void startRecording(int index) {
  if (isRecording) return;
  String filePath = sketchPath(fileNames[index]);
  // Delete old file if exists
  File f = new File(filePath);
  if (f.exists()) f.delete();
  
  // Create recorder from audio input
  recorder = new AudioRecorder(this, audioIn, filePath);
  recorder.record();
  
  isRecording = true;
  recordingKey = index;
  recordStartTime = millis();
}

void checkRecordingTimeout() {
  if (isRecording && (millis() - recordStartTime >= RECORD_DURATION)) {
    stopRecording();
  }
}

void stopRecording() {
  if (recorder != null) {
    recorder.stop();
    recorder = null;
  }
  isRecording = false;
  recordingKey = -1;
}

// ---------- Play all and record ----------
void playAllAndRecord() {
  if (isPlayingAll) return;
  isPlayingAll = true;
  
  // Create recorder from audio output (records the mix)
  String masterPath = sketchPath(masterFileName);
  File f = new File(masterPath);
  if (f.exists()) f.delete();
  
  recorder = new AudioRecorder(this, audioOut, masterPath);
  recorder.record();
  
  // We'll play each file sequentially in a separate thread or using a callback
  // Since we're in the main draw loop, we'll use a state machine.
  // Simpler: use a thread (but Processing on Android may not support threading well)
  // Alternative: use a loop that plays each file and waits for it to finish.
  // We'll do it in a separate function called from draw() when isPlayingAll is true.
  // We'll store a list of files to play and an index.
  // For simplicity, we'll start playing in a loop with delay, but that blocks draw.
  // Better: use a queue and play one after another via events.
  
  // Let's implement a simple sequential playback using a for loop but with delay?
  // That would freeze the UI. Instead, we'll use a callback or a timer.
  // For this example, we'll use a simple approach: 
  // We'll start playing the first file and set a flag. When it finishes, we play the next.
  // But AudioPlayer doesn't have an easy "on finish" callback in Processing Sound.
  // We can check player.isPlaying() in draw() to know when it stops.
  
  // Simpler solution: we can do it in a separate thread, but on Android we need to be careful.
  // I'll implement a state machine in draw():
  // - When isPlayingAll is true, we iterate through files.
  // - We'll maintain a current index and a player.
  // - In draw(), if player is null or not playing, we load next file and play.
  // - We also need to stop recording after all files are played.
  // We'll set up variables.
  
  // Let's set up the state:
  playAllIndex = 0;
  playAllPlayer = null;
  // Start the first file immediately.
  playNextFile();
}

int playAllIndex = 0;
AudioPlayer playAllPlayer = null;

void playNextFile() {
  // Find the next existing file
  while (playAllIndex < TOTAL_KEYS) {
    String path = sketchPath(fileNames[playAllIndex]);
    File f = new File(path);
    if (f.exists()) {
      // Load and play
      playAllPlayer = new AudioPlayer(this, path);
      playAllPlayer.play();
      playAllIndex++; // we'll increment after playing, but we need to know when done
      return;
    }
    playAllIndex++;
  }
  // No more files -> finish
  finishPlayAll();
}

void finishPlayAll() {
  // Stop recording
  if (recorder != null) {
    recorder.stop();
    recorder = null;
  }
  isPlayingAll = false;
  playAllPlayer = null;
  println("Master recording saved as " + masterFileName);
}

void updatePlayAll() {
  if (!isPlayingAll) return;
  
  // Check if current player is still playing
  if (playAllPlayer != null) {
    if (!playAllPlayer.isPlaying()) {
      // Current file finished, load next
      playAllPlayer = null;
      playNextFile();
    }
  } else {
    // If no player, start next
    playNextFile();
  }
}

// ---------- Main loop update ----------
void draw() {
  // ... (drawing code as above)
  
  // Check recording timeout
  checkRecordingTimeout();
  
  // Update playback all state
  updatePlayAll();
}











import processing.sound.*;

// Grid settings
final int COLS = 9;
final int ROWS = 14;
final int TOTAL_KEYS = COLS * ROWS;

// Audio objects
AudioIn audioIn;
AudioOutput audioOut;
AudioRecorder recorder;
AudioPlayer player;

// Recording state
boolean isRecording = false;
int recordingKey = -1;
long recordStartTime = 0;
final int RECORD_DURATION = 10000; // 10 seconds

// Playback all state
boolean isPlayingAll = false;

// File names
String[] fileNames = new String[TOTAL_KEYS];
String masterFileName = "master_recording.wav";

void setup() {
  size(800, 600); // Adjust as needed
  
  // Initialize audio
  audioIn = new AudioIn(this);
  audioIn.start();
  
  // Create audio output for playback
  audioOut = new AudioOutput(this);
  
  // Prepare file names
  for (int i = 0; i < TOTAL_KEYS; i++) {
    fileNames[i] = "key_" + i + ".wav";
  }
  
  // Request permissions (Android only)
  if (System.getProperty("java.runtime.name").contains("Android")) {
    requestPermissions(new String[]{
      "android.permission.RECORD_AUDIO",
      "android.permission.WRITE_EXTERNAL_STORAGE"
    }, 0);
  }
}

void draw() {
  background(100);
  
  // Draw the grid
  float cellW = width / (float) COLS;
  float cellH = height / (float) ROWS;
  for (int i = 0; i < TOTAL_KEYS; i++) {
    int col = i % COLS;
    int row = i / COLS;
    float x = col * cellW;
    float y = row * cellH;
    
    // Highlight first key differently
    if (i == 0) {
      fill(200, 100, 100);
    } else {
      // Check if this key has a recording file
      File f = new File(sketchPath(fileNames[i]));
      if (f.exists()) {
        fill(100, 200, 100);
      } else {
        fill(150);
      }
    }
    rect(x, y, cellW, cellH);
    
    // Show index
    fill(0);
    textAlign(CENTER, CENTER);
    text(i, x + cellW/2, y + cellH/2);
  }
  
  // Show status
  fill(255);
  textAlign(LEFT, TOP);
  if (isRecording) {
    text("Recording key " + recordingKey + " ... " + 
         ((millis() - recordStartTime) / 1000) + "s", 10, 10);
  } else if (isPlayingAll) {
    text("Playing all files and recording...", 10, 10);
  } else {
    text("Touch a key to record (10s) or touch key 0 to play all", 10, 10);
  }
}

void mousePressed() {
  if (isRecording || isPlayingAll) return; // busy
  
  int keyIndex = getKeyAt(mouseX, mouseY);
  if (keyIndex < 0 || keyIndex >= TOTAL_KEYS) return;
  
  if (keyIndex == 0) {
    // Play all and record
    playAllAndRecord();
  } else {
    // Start recording for this key
    startRecording(keyIndex);
  }
}

int getKeyAt(float mx, float my) {
  float cellW = width / (float) COLS;
  float cellH = height / (float) ROWS;
  int col = (int)(mx / cellW);
  int row = (int)(my / cellH);
  if (col >= COLS || row >= ROWS) return -1;
  return row * COLS + col;
}

// ---------- Recording ----------
void startRecording(int index) {
  if (isRecording) return;
  String filePath = sketchPath(fileNames[index]);
  // Delete old file if exists
  File f = new File(filePath);
  if (f.exists()) f.delete();
  
  // Create recorder from audio input
  recorder = new AudioRecorder(this, audioIn, filePath);
  recorder.record();
  
  isRecording = true;
  recordingKey = index;
  recordStartTime = millis();
}

void checkRecordingTimeout() {
  if (isRecording && (millis() - recordStartTime >= RECORD_DURATION)) {
    stopRecording();
  }
}

void stopRecording() {
  if (recorder != null) {
    recorder.stop();
    recorder = null;
  }
  isRecording = false;
  recordingKey = -1;
}

// ---------- Play all and record ----------
void playAllAndRecord() {
  if (isPlayingAll) return;
  isPlayingAll = true;
  
  // Create recorder from audio output (records the mix)
  String masterPath = sketchPath(masterFileName);
  File f = new File(masterPath);
  if (f.exists()) f.delete();
  
  recorder = new AudioRecorder(this, audioOut, masterPath);
  recorder.record();
  
  // We'll play each file sequentially in a separate thread or using a callback
  // Since we're in the main draw loop, we'll use a state machine.
  // Simpler: use a thread (but Processing on Android may not support threading well)
  // Alternative: use a loop that plays each file and waits for it to finish.
  // We'll do it in a separate function called from draw() when isPlayingAll is true.
  // We'll store a list of files to play and an index.
  // For simplicity, we'll start playing in a loop with delay, but that blocks draw.
  // Better: use a queue and play one after another via events.
  
  // Let's implement a simple sequential playback using a for loop but with delay?
  // That would freeze the UI. Instead, we'll use a callback or a timer.
  // For this example, we'll use a simple approach: 
  // We'll start playing the first file and set a flag. When it finishes, we play the next.
  // But AudioPlayer doesn't have an easy "on finish" callback in Processing Sound.
  // We can check player.isPlaying() in draw() to know when it stops.
  
  // Simpler solution: we can do it in a separate thread, but on Android we need to be careful.
  // I'll implement a state machine in draw():
  // - When isPlayingAll is true, we iterate through files.
  // - We'll maintain a current index and a player.
  // - In draw(), if player is null or not playing, we load next file and play.
  // - We also need to stop recording after all files are played.
  // We'll set up variables.
  
  // Let's set up the state:
  playAllIndex = 0;
  playAllPlayer = null;
  // Start the first file immediately.
  playNextFile();
}

int playAllIndex = 0;
AudioPlayer playAllPlayer = null;

void playNextFile() {
  // Find the next existing file
  while (playAllIndex < TOTAL_KEYS) {
    String path = sketchPath(fileNames[playAllIndex]);
    File f = new File(path);
    if (f.exists()) {
      // Load and play
      playAllPlayer = new AudioPlayer(this, path);
      playAllPlayer.play();
      playAllIndex++; // we'll increment after playing, but we need to know when done
      return;
    }
    playAllIndex++;
  }
  // No more files -> finish
  finishPlayAll();
}

void finishPlayAll() {
  // Stop recording
  if (recorder != null) {
    recorder.stop();
    recorder = null;
  }
  isPlayingAll = false;
  playAllPlayer = null;
  println("Master recording saved as " + masterFileName);
}

void updatePlayAll() {
  if (!isPlayingAll) return;
  
  // Check if current player is still playing
  if (playAllPlayer != null) {
    if (!playAllPlayer.isPlaying()) {
      // Current file finished, load next
      playAllPlayer = null;
      playNextFile();
    }
  } else {
    // If no player, start next
    playNextFile();
  }
}

// ---------- Main loop update ----------
void draw() {
  // ... (drawing code as above)
  
  // Check recording timeout
  checkRecordingTimeout();
  
  // Update playback all state
  updatePlayAll();
}





*/






















/*

import processing.sound.*;

// Audio recording and playback variables
AudioIn mic;
SoundFile[] memories = new SoundFile[9]; // Holds audio data for 9 buttons
boolean[] isRecording = new boolean[9];
int[] recordStartTime = new int[9];
int maxRecordTimeMs = 20000; // Maximum 20 seconds ring memory limit

// Active state monitoring
int currentActivePlayback = -1; 
int currentActiveRecording = -1;

// Grid layout variables (9 buttons in portrait format)
int cols = 3;
int rows = 3;
float btnW, btnH;
String[] btnLabels = {"Play/Pause", "Mem 2 (Rec)", "Mem 3 (Rec)", 
                      "Mem 4 (Rec)", "Mem 5 (Rec)", "Mem 6 (Rec)", 
                      "Mem 7 (Rec)", "Mem 8 (Rec)", "Mem 9 (Rec)"};

void setup() {
  size(450  , 1700   ); // Strict portrait aspect ratio orientation
  ///  orientation(PORTRAIT);
  
  // Calculate responsive grid dimensions
  btnW = width / (float)cols;
  btnH = height / (float)rows;
  
  // Initialize microphone input
  mic = new AudioIn(this, 0);
  mic.start();
  
  // Create empty temporary placeholders for memory files
  for (int i = 0; i < 9; i++) {
    isRecording[i] = false;
  }
}

void draw() {
  background(35);
  
  // Loop execution behavior monitoring for 20 second ceiling limits
  if (currentActiveRecording != -1) {
    int elapsed = millis() - recordStartTime
  [currentActiveRecording];
    if (elapsed >= maxRecordTimeMs    ) {
      stopRecordingAndSave(currentActiveRecording);
    }
  }
  
  // Dynamic play loop state auto-reset handling: if end, go to start
  if (currentActivePlayback != -1 && 
   memories[currentActivePlayback] != null) {
 if (!memories[currentActivePlayback].isPlaying()) {
      // Loop execution completed naturally, safely reset pointer
        currentActivePlayback = -1; 
    }
  }

  // Draw visual grid map layout interface
  for (int i = 0; i < 9; i++) {
    int col = i % cols;
    int row = i / cols;
    float x = col * btnW;
    float y = row * btnH;
    
    // Aesthetic structural coloration adjustments
    if (i == 0) {
      // First button (Play/Pause control indicator feedback color)
      if (currentActivePlayback != -1)
   fill(46, 204, 113); // Green if actively playing
      else fill(52, 152, 219); // Default Blue
    } else if (isRecording[i]) {
      fill(231, 76, 60); // Red alert if currently recording via microphone source
    } else if (memories[i] != null) {
      fill(241, 196, 15); // Yellow warning highlight if bank contains memory elements
    } else {
      fill(70); // Default idle state dark grey
    }
    
    stroke(255);
    strokeWeight(2);
    rect(x, y, btnW, btnH, 10);
    
    // Render text typography configurations
    fill(255);
    textAlign(CENTER, CENTER);
    textSize(16);
    
    if (isRecording[i]) {
      float remaining = 
 (maxRecordTimeMs - (millis() - recordStartTime[i])) 
      / 1000.0;
      text("REC: " + nf(remaining, 1, 1) + "s"
        , x + btnW/2, y + btnH/2);
    } else {
      text(btnLabels[i], x + btnW/2, y + btnH/2);
    }
  }
}

void mousePressed() {
  // Determine coordinate cell matrix mapping calculations
  int col = floor(mouseX / btnW);
  int row = floor(mouseY / btnH);
  int index = col + row * cols;
  
  // Bound restrictions security check guard rails
  if (index < 0 || index >= 9) return;
  
  if (index == 0    ) {
    // 1st Button functionality behavior handler matrix structure block: PLAY / PAUSE Toggle
 /// 
   handlePlayPauseToggle();    
  } else {
    // Buttons 2-9 memory allocation management structure block: RECORD logic
     handleMemoryRecording(index);
  }
}

void handlePlayPauseToggle() {
  // Finds the first available functional recorded audio buffer slot to manipulate
  int targetIndex = -1;
  for (int i = 1; i < 9; i++) {
    if (memories[i] != null) {
      targetIndex = i;
      break;
    }
  }
  
  if (targetIndex == -1) {
    println("No recorded memory profiles discovered to feed audio components engine.");
    return;
  }
  
  if (currentActivePlayback != -1) {
    // If running already, toggle pause execution sequences
    memories[currentActivePlayback].pause();
    currentActivePlayback = -1;
  } else {
    // Execute dynamic audio play back framework components layout operations
    memories[targetIndex].play();
    currentActivePlayback = targetIndex;
  }
}

void handleMemoryRecording(int index) {
  // If actively looping record execution matrices path routes
  if (isRecording[index]) {
    stopRecordingAndSave(index);
  } else {
    // Guard clause checking to safely pause active processes prior to execution
    if (currentActiveRecording != -1) {
      stopRecordingAndSave(currentActiveRecording);
    }
    if (currentActivePlayback != -1) {
      memories[currentActivePlayback].stop();
      currentActivePlayback = -1;
    }
    
    // Instantiate raw sampling storage allocations initialization commands
    isRecording[index] = true;
    currentActiveRecording = index;
    recordStartTime[index] = millis();
    
    // Create standalone sample storage structure references framework mappings 
    memories[index] = 



   new SoundFile(this, str(int(maxRecordTimeMs))  ); 



    // Start streaming mic signal data array tracks into raw system sound file context indices 
    // NOTE: For live mic file writing, alternative platforms may utilize a helper class 'SoundRecorder'
  }
}

void stopRecordingAndSave(int index) {
  isRecording[index] = false;
  currentActiveRecording = -1;
   //  println("Memory cell index slot [" + index + "] bound cleanly captured up to 20 seconds loop frame data.");
}





*/


/*








import processing.sound.*;

// Audio recording and playback variables
AudioIn mic;
SoundFile[] memories = new SoundFile[9]; // Holds audio data for 9 buttons
boolean[] isRecording = new boolean[9];
int[] recordStartTime = new int[9];
int maxRecordTimeMs = 20000; // Maximum 20 seconds ring memory limit

// Active state monitoring
int currentActivePlayback = -1; 
int currentActiveRecording = -1;

// Grid layout variables (9 buttons in portrait format)
int cols = 3;
int rows = 3;
float btnW, btnH;
String[] btnLabels = {"Play/Pause", "Mem 2 (Rec)", "Mem 3 (Rec)", 
                      "Mem 4 (Rec)", "Mem 5 (Rec)", "Mem 6 (Rec)", 
                      "Mem 7 (Rec)", "Mem 8 (Rec)", "Mem 9 (Rec)"};

void setup() {
  size(450, 700); // Strict portrait aspect ratio orientation
  orientation(PORTRAIT);
  
  // Calculate responsive grid dimensions
  btnW = width / (float)cols;
  btnH = height / (float)rows;
  
  // Initialize microphone input
  mic = new AudioIn(this, 0);
  mic.start();
  
  // Create empty temporary placeholders for memory files
  for (int i = 0; i < 9; i++) {
    isRecording[i] = false;
  }
}

void draw() {
  background(35);
  
  // Loop execution behavior monitoring for 20 second ceiling limits
  if (currentActiveRecording != -1) {
    int elapsed = millis() - recordStartTime
  [currentActiveRecording];
    if (elapsed >= maxRecordTimeMs) {
      stopRecordingAndSave(currentActiveRecording);
    }
  }
  
  // Dynamic play loop state auto-reset handling: if end, go to start
  if (currentActivePlayback != -1 && 
   memories[currentActivePlayback] != null) {
 if (!memories[currentActivePlayback].isPlaying()) {
      // Loop execution completed naturally, safely reset pointer
      currentActivePlayback = -1; 
    }
  }

  // Draw visual grid map layout interface
  for (int i = 0; i < 9; i++) {
    int col = i % cols;
    int row = i / cols;
    float x = col * btnW;
    float y = row * btnH;
    
    // Aesthetic structural coloration adjustments
    if (i == 0) {
      // First button (Play/Pause control indicator feedback color)
      if (currentActivePlayback != -1)
   fill(46, 204, 113); // Green if actively playing
      else fill(52, 152, 219); // Default Blue
    } else if (isRecording[i]) {
      fill(231, 76, 60); // Red alert if currently recording via microphone source
    } else if (memories[i] != null) {
      fill(241, 196, 15); // Yellow warning highlight if bank contains memory elements
    } else {
      fill(70); // Default idle state dark grey
    }
    
    stroke(255);
    strokeWeight(2);
    rect(x, y, btnW, btnH, 10);
    
    // Render text typography configurations
    fill(255);
    textAlign(CENTER, CENTER);
    textSize(16);
    
    if (isRecording[i]) {
      float remaining = 
 (maxRecordTimeMs - (millis() - recordStartTime[i])) 
      / 1000.0;
      text("REC: " + nf(remaining, 1, 1) + "s"
        , x + btnW/2, y + btnH/2);
    } else {
      text(btnLabels[i], x + btnW/2, y + btnH/2);
    }
  }
}

void mousePressed() {
  // Determine coordinate cell matrix mapping calculations
  int col = floor(mouseX / btnW);
  int row = floor(mouseY / btnH);
  int index = col + row * cols;
  
  // Bound restrictions security check guard rails
  if (index < 0 || index >= 9) return;
  
  if (index == 0) {
    // 1st Button functionality behavior handler matrix structure block: PLAY / PAUSE Toggle
    handlePlayPauseToggle();
  } else {
    // Buttons 2-9 memory allocation management structure block: RECORD logic
    handleMemoryRecording(index);
  }
}

void handlePlayPauseToggle() {
  // Finds the first available functional recorded audio buffer slot to manipulate
  int targetIndex = -1;
  for (int i = 1; i < 9; i++) {
    if (memories[i] != null) {
      targetIndex = i;
      break;
    }
  }
  
  if (targetIndex == -1) {
    println("No recorded memory profiles discovered to feed audio components engine.");
    return;
  }
  
  if (currentActivePlayback != -1) {
    // If running already, toggle pause execution sequences
    memories[currentActivePlayback].pause();
    currentActivePlayback = -1;
  } else {
    // Execute dynamic audio play back framework components layout operations
    memories[targetIndex].play();
    currentActivePlayback = targetIndex;
  }
}

void handleMemoryRecording(int index) {
  // If actively looping record execution matrices path routes
  if (isRecording[index]) {
    stopRecordingAndSave(index);
  } else {
    // Guard clause checking to safely pause active processes prior to execution
    if (currentActiveRecording != -1) {
      stopRecordingAndSave(currentActiveRecording);
    }
    if (currentActivePlayback != -1) {
      memories[currentActivePlayback].stop();
      currentActivePlayback = -1;
    }
    
    // Instantiate raw sampling storage allocations initialization commands
    isRecording[index] = true;
    currentActiveRecording = index;
    recordStartTime[index] = millis();
    
    // Create standalone sample storage structure references framework mappings 
    memories[index] = 



   new SoundFile(this, str(int(maxRecordTimeMs))  ); 



    // Start streaming mic signal data array tracks into raw system sound file context indices 
    // NOTE: For live mic file writing, alternative platforms may utilize a helper class 'SoundRecorder'
  }
}

void stopRecordingAndSave(int index) {
  isRecording[index] = false;
  currentActiveRecording = -1;
   //  println("Memory cell index slot [" + index + "] bound cleanly captured up to 20 seconds loop frame data.");
}











import processing.sound.*;

// Audio recording and playback variables
AudioIn mic;
SoundFile[] memories = new SoundFile[9]; // Holds audio data for 9 buttons
boolean[] isRecording = new boolean[9];
int[] recordStartTime = new int[9];
int maxRecordTimeMs = 20000; // Maximum 20 seconds ring memory limit

// Active state monitoring
int currentActivePlayback = -1; 
int currentActiveRecording = -1;

// Grid layout variables (9 buttons in portrait format)
int cols = 3;
int rows = 3;
float btnW, btnH;
String[] btnLabels = {"Play/Pause", "Mem 2 (Rec)", "Mem 3 (Rec)", 
                      "Mem 4 (Rec)", "Mem 5 (Rec)", "Mem 6 (Rec)", 
                      "Mem 7 (Rec)", "Mem 8 (Rec)", "Mem 9 (Rec)"};

void setup() {
  size(450, 700); // Strict portrait aspect ratio orientation
  orientation(PORTRAIT);
  
  // Calculate responsive grid dimensions
  btnW = width / (float)cols;
  btnH = height / (float)rows;
  
  // Initialize microphone input
  mic = new AudioIn(this, 0);
  mic.start();
  
  // Create empty temporary placeholders for memory files
  for (int i = 0; i < 9; i++) {
    isRecording[i] = false;
  }
}

void draw() {
  background(35);
  
  // Loop execution behavior monitoring for 20 second ceiling limits
  if (currentActiveRecording != -1) {
    int elapsed = millis() - recordStartTime
  [currentActiveRecording];
    if (elapsed >= maxRecordTimeMs) {
      stopRecordingAndSave(currentActiveRecording);
    }
  }
  
  // Dynamic play loop state auto-reset handling: if end, go to start
  if (currentActivePlayback != -1 && 
   memories[currentActivePlayback] != null) {
 if (!memories[currentActivePlayback].isPlaying()) {
      // Loop execution completed naturally, safely reset pointer
      currentActivePlayback = -1; 
    }
  }

  // Draw visual grid map layout interface
  for (int i = 0; i < 9; i++) {
    int col = i % cols;
    int row = i / cols;
    float x = col * btnW;
    float y = row * btnH;
    
    // Aesthetic structural coloration adjustments
    if (i == 0) {
      // First button (Play/Pause control indicator feedback color)
      if (currentActivePlayback != -1)
   fill(46, 204, 113); // Green if actively playing
      else fill(52, 152, 219); // Default Blue
    } else if (isRecording[i]) {
      fill(231, 76, 60); // Red alert if currently recording via microphone source
    } else if (memories[i] != null) {
      fill(241, 196, 15); // Yellow warning highlight if bank contains memory elements
    } else {
      fill(70); // Default idle state dark grey
    }
    
    stroke(255);
    strokeWeight(2);
    rect(x, y, btnW, btnH, 10);
    
    // Render text typography configurations
    fill(255);
    textAlign(CENTER, CENTER);
    textSize(16);
    
    if (isRecording[i]) {
      float remaining = 
 (maxRecordTimeMs - (millis() - recordStartTime[i])) 
      / 1000.0;
      text("REC: " + nf(remaining, 1, 1) + "s"
        , x + btnW/2, y + btnH/2);
    } else {
      text(btnLabels[i], x + btnW/2, y + btnH/2);
    }
  }
}

void mousePressed() {
  // Determine coordinate cell matrix mapping calculations
  int col = floor(mouseX / btnW);
  int row = floor(mouseY / btnH);
  int index = col + row * cols;
  
  // Bound restrictions security check guard rails
  if (index < 0 || index >= 9) return;
  
  if (index == 0) {
    // 1st Button functionality behavior handler matrix structure block: PLAY / PAUSE Toggle
    handlePlayPauseToggle();
  } else {
    // Buttons 2-9 memory allocation management structure block: RECORD logic
    handleMemoryRecording(index);
  }
}

void handlePlayPauseToggle() {
  // Finds the first available functional recorded audio buffer slot to manipulate
  int targetIndex = -1;
  for (int i = 1; i < 9; i++) {
    if (memories[i] != null) {
      targetIndex = i;
      break;
    }
  }
  
  if (targetIndex == -1) {
    println("No recorded memory profiles discovered to feed audio components engine.");
    return;
  }
  
  if (currentActivePlayback != -1) {
    // If running already, toggle pause execution sequences
    memories[currentActivePlayback].pause();
    currentActivePlayback = -1;
  } else {
    // Execute dynamic audio play back framework components layout operations
    memories[targetIndex].play();
    currentActivePlayback = targetIndex;
  }
}

void handleMemoryRecording(int index) {
  // If actively looping record execution matrices path routes
  if (isRecording[index]) {
    stopRecordingAndSave(index);
  } else {
    // Guard clause checking to safely pause active processes prior to execution
    if (currentActiveRecording != -1) {
      stopRecordingAndSave(currentActiveRecording);
    }
    if (currentActivePlayback != -1) {
      memories[currentActivePlayback].stop();
      currentActivePlayback = -1;
    }
    
    // Instantiate raw sampling storage allocations initialization commands
    isRecording[index] = true;
    currentActiveRecording = index;
    recordStartTime[index] = millis();
    
    // Create standalone sample storage structure references framework mappings 
    memories[index] = 



   new SoundFile(this, str(int(maxRecordTimeMs))  ); 



    // Start streaming mic signal data array tracks into raw system sound file context indices 
    // NOTE: For live mic file writing, alternative platforms may utilize a helper class 'SoundRecorder'
  }
}

void stopRecordingAndSave(int index) {
  isRecording[index] = false;
  currentActiveRecording = -1;
   //  println("Memory cell index slot [" + index + "] bound cleanly captured up to 20 seconds loop frame data.");
}










import processing.sound.*;

// Audio recording and playback variables
AudioIn mic;
SoundFile[] memories = new SoundFile[9]; // Holds audio data for 9 buttons
boolean[] isRecording = new boolean[9];
int[] recordStartTime = new int[9];
int maxRecordTimeMs = 20000; // Maximum 20 seconds ring memory limit

// Active state monitoring
int currentActivePlayback = -1; 
int currentActiveRecording = -1;

// Grid layout variables (9 buttons in portrait format)
int cols = 3;
int rows = 3;
float btnW, btnH;
String[] btnLabels = {"Play/Pause", "Mem 2 (Rec)", "Mem 3 (Rec)", 
                      "Mem 4 (Rec)", "Mem 5 (Rec)", "Mem 6 (Rec)", 
                      "Mem 7 (Rec)", "Mem 8 (Rec)", "Mem 9 (Rec)"};

void setup() {
  size(450, 700); // Strict portrait aspect ratio orientation
  orientation(PORTRAIT);
  
  // Calculate responsive grid dimensions
  btnW = width / (float)cols;
  btnH = height / (float)rows;
  
  // Initialize microphone input
  mic = new AudioIn(this, 0);
  mic.start();
  
  // Create empty temporary placeholders for memory files
  for (int i = 0; i < 9; i++) {
    isRecording[i] = false;
  }
}

void draw() {
  background(35);
  
  // Loop execution behavior monitoring for 20 second ceiling limits
  if (currentActiveRecording != -1) {
    int elapsed = millis() - recordStartTime
  [currentActiveRecording];
    if (elapsed >= maxRecordTimeMs) {
      stopRecordingAndSave(currentActiveRecording);
    }
  }
  
  // Dynamic play loop state auto-reset handling: if end, go to start
  if (currentActivePlayback != -1 && 
   memories[currentActivePlayback] != null) {
 if (!memories[currentActivePlayback].isPlaying()) {
      // Loop execution completed naturally, safely reset pointer
      currentActivePlayback = -1; 
    }
  }

  // Draw visual grid map layout interface
  for (int i = 0; i < 9; i++) {
    int col = i % cols;
    int row = i / cols;
    float x = col * btnW;
    float y = row * btnH;
    
    // Aesthetic structural coloration adjustments
    if (i == 0) {
      // First button (Play/Pause control indicator feedback color)
      if (currentActivePlayback != -1)
   fill(46, 204, 113); // Green if actively playing
      else fill(52, 152, 219); // Default Blue
    } else if (isRecording[i]) {
      fill(231, 76, 60); // Red alert if currently recording via microphone source
    } else if (memories[i] != null) {
      fill(241, 196, 15); // Yellow warning highlight if bank contains memory elements
    } else {
      fill(70); // Default idle state dark grey
    }
    
    stroke(255);
    strokeWeight(2);
    rect(x, y, btnW, btnH, 10);
    
    // Render text typography configurations
    fill(255);
    textAlign(CENTER, CENTER);
    textSize(16);
    
    if (isRecording[i]) {
      float remaining = 
 (maxRecordTimeMs - (millis() - recordStartTime[i])) 
      / 1000.0;
      text("REC: " + nf(remaining, 1, 1) + "s"
        , x + btnW/2, y + btnH/2);
    } else {
      text(btnLabels[i], x + btnW/2, y + btnH/2);
    }
  }
}

void mousePressed() {
  // Determine coordinate cell matrix mapping calculations
  int col = floor(mouseX / btnW);
  int row = floor(mouseY / btnH);
  int index = col + row * cols;
  
  // Bound restrictions security check guard rails
  if (index < 0 || index >= 9) return;
  
  if (index == 0) {
    // 1st Button functionality behavior handler matrix structure block: PLAY / PAUSE Toggle
    handlePlayPauseToggle();
  } else {
    // Buttons 2-9 memory allocation management structure block: RECORD logic
    handleMemoryRecording(index);
  }
}

void handlePlayPauseToggle() {
  // Finds the first available functional recorded audio buffer slot to manipulate
  int targetIndex = -1;
  for (int i = 1; i < 9; i++) {
    if (memories[i] != null) {
      targetIndex = i;
      break;
    }
  }
  
  if (targetIndex == -1) {
    println("No recorded memory profiles discovered to feed audio components engine.");
    return;
  }
  
  if (currentActivePlayback != -1) {
    // If running already, toggle pause execution sequences
    memories[currentActivePlayback].pause();
    currentActivePlayback = -1;
  } else {
    // Execute dynamic audio play back framework components layout operations
    memories[targetIndex].play();
    currentActivePlayback = targetIndex;
  }
}

void handleMemoryRecording(int index) {
  // If actively looping record execution matrices path routes
  if (isRecording[index]) {
    stopRecordingAndSave(index);
  } else {
    // Guard clause checking to safely pause active processes prior to execution
    if (currentActiveRecording != -1) {
      stopRecordingAndSave(currentActiveRecording);
    }
    if (currentActivePlayback != -1) {
      memories[currentActivePlayback].stop();
      currentActivePlayback = -1;
    }
    
    // Instantiate raw sampling storage allocations initialization commands
    isRecording[index] = true;
    currentActiveRecording = index;
    recordStartTime[index] = millis();
    
    // Create standalone sample storage structure references framework mappings 
    memories[index] = 



   new SoundFile(this, str(int(maxRecordTimeMs))  ); 



    // Start streaming mic signal data array tracks into raw system sound file context indices 
    // NOTE: For live mic file writing, alternative platforms may utilize a helper class 'SoundRecorder'
  }
}

void stopRecordingAndSave(int index) {
  isRecording[index] = false;
  currentActiveRecording = -1;
   //  println("Memory cell index slot [" + index + "] bound cleanly captured up to 20 seconds loop frame data.");
}









import processing.sound.*;

// Audio recording and playback variables
AudioIn mic;
SoundFile[] memories = new SoundFile[9]; // Holds audio data for 9 buttons
boolean[] isRecording = new boolean[9];
int[] recordStartTime = new int[9];
int maxRecordTimeMs = 20000; // Maximum 20 seconds ring memory limit

// Active state monitoring
int currentActivePlayback = -1; 
int currentActiveRecording = -1;

// Grid layout variables (9 buttons in portrait format)
int cols = 3;
int rows = 3;
float btnW, btnH;
String[] btnLabels = {"Play/Pause", "Mem 2 (Rec)", "Mem 3 (Rec)", 
                      "Mem 4 (Rec)", "Mem 5 (Rec)", "Mem 6 (Rec)", 
                      "Mem 7 (Rec)", "Mem 8 (Rec)", "Mem 9 (Rec)"};

void setup() {
  size(450, 700); // Strict portrait aspect ratio orientation
  orientation(PORTRAIT);
  
  // Calculate responsive grid dimensions
  btnW = width / (float)cols;
  btnH = height / (float)rows;
  
  // Initialize microphone input
  mic = new AudioIn(this, 0);
  mic.start();
  
  // Create empty temporary placeholders for memory files
  for (int i = 0; i < 9; i++) {
    isRecording[i] = false;
  }
}

void draw() {
  background(35);
  
  // Loop execution behavior monitoring for 20 second ceiling limits
  if (currentActiveRecording != -1) {
    int elapsed = millis() - recordStartTime
  [currentActiveRecording];
    if (elapsed >= maxRecordTimeMs) {
      stopRecordingAndSave(currentActiveRecording);
    }
  }
  
  // Dynamic play loop state auto-reset handling: if end, go to start
  if (currentActivePlayback != -1 && 
   memories[currentActivePlayback] != null) {
 if (!memories[currentActivePlayback].isPlaying()) {
      // Loop execution completed naturally, safely reset pointer
      currentActivePlayback = -1; 
    }
  }

  // Draw visual grid map layout interface
  for (int i = 0; i < 9; i++) {
    int col = i % cols;
    int row = i / cols;
    float x = col * btnW;
    float y = row * btnH;
    
    // Aesthetic structural coloration adjustments
    if (i == 0) {
      // First button (Play/Pause control indicator feedback color)
      if (currentActivePlayback != -1)
   fill(46, 204, 113); // Green if actively playing
      else fill(52, 152, 219); // Default Blue
    } else if (isRecording[i]) {
      fill(231, 76, 60); // Red alert if currently recording via microphone source
    } else if (memories[i] != null) {
      fill(241, 196, 15); // Yellow warning highlight if bank contains memory elements
    } else {
      fill(70); // Default idle state dark grey
    }
    
    stroke(255);
    strokeWeight(2);
    rect(x, y, btnW, btnH, 10);
    
    // Render text typography configurations
    fill(255);
    textAlign(CENTER, CENTER);
    textSize(16);
    
    if (isRecording[i]) {
      float remaining = 
 (maxRecordTimeMs - (millis() - recordStartTime[i])) 
      / 1000.0;
      text("REC: " + nf(remaining, 1, 1) + "s"
        , x + btnW/2, y + btnH/2);
    } else {
      text(btnLabels[i], x + btnW/2, y + btnH/2);
    }
  }
}

void mousePressed() {
  // Determine coordinate cell matrix mapping calculations
  int col = floor(mouseX / btnW);
  int row = floor(mouseY / btnH);
  int index = col + row * cols;
  
  // Bound restrictions security check guard rails
  if (index < 0 || index >= 9) return;
  
  if (index == 0) {
    // 1st Button functionality behavior handler matrix structure block: PLAY / PAUSE Toggle
    handlePlayPauseToggle();
  } else {
    // Buttons 2-9 memory allocation management structure block: RECORD logic
    handleMemoryRecording(index);
  }
}

void handlePlayPauseToggle() {
  // Finds the first available functional recorded audio buffer slot to manipulate
  int targetIndex = -1;
  for (int i = 1; i < 9; i++) {
    if (memories[i] != null) {
      targetIndex = i;
      break;
    }
  }
  
  if (targetIndex == -1) {
    println("No recorded memory profiles discovered to feed audio components engine.");
    return;
  }
  
  if (currentActivePlayback != -1) {
    // If running already, toggle pause execution sequences
    memories[currentActivePlayback].pause();
    currentActivePlayback = -1;
  } else {
    // Execute dynamic audio play back framework components layout operations
    memories[targetIndex].play();
    currentActivePlayback = targetIndex;
  }
}

void handleMemoryRecording(int index) {
  // If actively looping record execution matrices path routes
  if (isRecording[index]) {
    stopRecordingAndSave(index);
  } else {
    // Guard clause checking to safely pause active processes prior to execution
    if (currentActiveRecording != -1) {
      stopRecordingAndSave(currentActiveRecording);
    }
    if (currentActivePlayback != -1) {
      memories[currentActivePlayback].stop();
      currentActivePlayback = -1;
    }
    
    // Instantiate raw sampling storage allocations initialization commands
    isRecording[index] = true;
    currentActiveRecording = index;
    recordStartTime[index] = millis();
    
    // Create standalone sample storage structure references framework mappings 
    memories[index] = 



   new SoundFile(this, str(int(maxRecordTimeMs))  ); 



    // Start streaming mic signal data array tracks into raw system sound file context indices 
    // NOTE: For live mic file writing, alternative platforms may utilize a helper class 'SoundRecorder'
  }
}

void stopRecordingAndSave(int index) {
  isRecording[index] = false;
  currentActiveRecording = -1;
   //  println("Memory cell index slot [" + index + "] bound cleanly captured up to 20 seconds loop frame data.");
}











import processing.sound.*;

// Audio recording and playback variables
AudioIn mic;
SoundFile[] memories = new SoundFile[9]; // Holds audio data for 9 buttons
boolean[] isRecording = new boolean[9];
int[] recordStartTime = new int[9];
int maxRecordTimeMs = 20000; // Maximum 20 seconds ring memory limit

// Active state monitoring
int currentActivePlayback = -1; 
int currentActiveRecording = -1;

// Grid layout variables (9 buttons in portrait format)
int cols = 3;
int rows = 3;
float btnW, btnH;
String[] btnLabels = {"Play/Pause", "Mem 2 (Rec)", "Mem 3 (Rec)", 
                      "Mem 4 (Rec)", "Mem 5 (Rec)", "Mem 6 (Rec)", 
                      "Mem 7 (Rec)", "Mem 8 (Rec)", "Mem 9 (Rec)"};

void setup() {
  size(450, 700); // Strict portrait aspect ratio orientation
  orientation(PORTRAIT);
  
  // Calculate responsive grid dimensions
  btnW = width / (float)cols;
  btnH = height / (float)rows;
  
  // Initialize microphone input
  mic = new AudioIn(this, 0);
  mic.start();
  
  // Create empty temporary placeholders for memory files
  for (int i = 0; i < 9; i++) {
    isRecording[i] = false;
  }
}

void draw() {
  background(35);
  
  // Loop execution behavior monitoring for 20 second ceiling limits
  if (currentActiveRecording != -1) {
    int elapsed = millis() - recordStartTime
  [currentActiveRecording];
    if (elapsed >= maxRecordTimeMs) {
      stopRecordingAndSave(currentActiveRecording);
    }
  }
  
  // Dynamic play loop state auto-reset handling: if end, go to start
  if (currentActivePlayback != -1 && 
   memories[currentActivePlayback] != null) {
 if (!memories[currentActivePlayback].isPlaying()) {
      // Loop execution completed naturally, safely reset pointer
      currentActivePlayback = -1; 
    }
  }

  // Draw visual grid map layout interface
  for (int i = 0; i < 9; i++) {
    int col = i % cols;
    int row = i / cols;
    float x = col * btnW;
    float y = row * btnH;
    
    // Aesthetic structural coloration adjustments
    if (i == 0) {
      // First button (Play/Pause control indicator feedback color)
      if (currentActivePlayback != -1)
   fill(46, 204, 113); // Green if actively playing
      else fill(52, 152, 219); // Default Blue
    } else if (isRecording[i]) {
      fill(231, 76, 60); // Red alert if currently recording via microphone source
    } else if (memories[i] != null) {
      fill(241, 196, 15); // Yellow warning highlight if bank contains memory elements
    } else {
      fill(70); // Default idle state dark grey
    }
    
    stroke(255);
    strokeWeight(2);
    rect(x, y, btnW, btnH, 10);
    
    // Render text typography configurations
    fill(255);
    textAlign(CENTER, CENTER);
    textSize(16);
    
    if (isRecording[i]) {
      float remaining = 
 (maxRecordTimeMs - (millis() - recordStartTime[i])) 
      / 1000.0;
      text("REC: " + nf(remaining, 1, 1) + "s"
        , x + btnW/2, y + btnH/2);
    } else {
      text(btnLabels[i], x + btnW/2, y + btnH/2);
    }
  }
}

void mousePressed() {
  // Determine coordinate cell matrix mapping calculations
  int col = floor(mouseX / btnW);
  int row = floor(mouseY / btnH);
  int index = col + row * cols;
  
  // Bound restrictions security check guard rails
  if (index < 0 || index >= 9) return;
  
  if (index == 0) {
    // 1st Button functionality behavior handler matrix structure block: PLAY / PAUSE Toggle
    handlePlayPauseToggle();
  } else {
    // Buttons 2-9 memory allocation management structure block: RECORD logic
    handleMemoryRecording(index);
  }
}

void handlePlayPauseToggle() {
  // Finds the first available functional recorded audio buffer slot to manipulate
  int targetIndex = -1;
  for (int i = 1; i < 9; i++) {
    if (memories[i] != null) {
      targetIndex = i;
      break;
    }
  }
  
  if (targetIndex == -1) {
    println("No recorded memory profiles discovered to feed audio components engine.");
    return;
  }
  
  if (currentActivePlayback != -1) {
    // If running already, toggle pause execution sequences
    memories[currentActivePlayback].pause();
    currentActivePlayback = -1;
  } else {
    // Execute dynamic audio play back framework components layout operations
    memories[targetIndex].play();
    currentActivePlayback = targetIndex;
  }
}

void handleMemoryRecording(int index) {
  // If actively looping record execution matrices path routes
  if (isRecording[index]) {
    stopRecordingAndSave(index);
  } else {
    // Guard clause checking to safely pause active processes prior to execution
    if (currentActiveRecording != -1) {
      stopRecordingAndSave(currentActiveRecording);
    }
    if (currentActivePlayback != -1) {
      memories[currentActivePlayback].stop();
      currentActivePlayback = -1;
    }
    
    // Instantiate raw sampling storage allocations initialization commands
    isRecording[index] = true;
    currentActiveRecording = index;
    recordStartTime[index] = millis();
    
    // Create standalone sample storage structure references framework mappings 
    memories[index] = 



   new SoundFile(this, str(int(maxRecordTimeMs))  ); 



    // Start streaming mic signal data array tracks into raw system sound file context indices 
    // NOTE: For live mic file writing, alternative platforms may utilize a helper class 'SoundRecorder'
  }
}

void stopRecordingAndSave(int index) {
  isRecording[index] = false;
  currentActiveRecording = -1;
   //  println("Memory cell index slot [" + index + "] bound cleanly captured up to 20 seconds loop frame data.");
}











import processing.sound.*;

// Audio recording and playback variables
AudioIn mic;
SoundFile[] memories = new SoundFile[9]; // Holds audio data for 9 buttons
boolean[] isRecording = new boolean[9];
int[] recordStartTime = new int[9];
int maxRecordTimeMs = 20000; // Maximum 20 seconds ring memory limit

// Active state monitoring
int currentActivePlayback = -1; 
int currentActiveRecording = -1;

// Grid layout variables (9 buttons in portrait format)
int cols = 3;
int rows = 3;
float btnW, btnH;
String[] btnLabels = {"Play/Pause", "Mem 2 (Rec)", "Mem 3 (Rec)", 
                      "Mem 4 (Rec)", "Mem 5 (Rec)", "Mem 6 (Rec)", 
                      "Mem 7 (Rec)", "Mem 8 (Rec)", "Mem 9 (Rec)"};

void setup() {
  size(450, 700); // Strict portrait aspect ratio orientation
  orientation(PORTRAIT);
  
  // Calculate responsive grid dimensions
  btnW = width / (float)cols;
  btnH = height / (float)rows;
  
  // Initialize microphone input
  mic = new AudioIn(this, 0);
  mic.start();
  
  // Create empty temporary placeholders for memory files
  for (int i = 0; i < 9; i++) {
    isRecording[i] = false;
  }
}

void draw() {
  background(35);
  
  // Loop execution behavior monitoring for 20 second ceiling limits
  if (currentActiveRecording != -1) {
    int elapsed = millis() - recordStartTime
  [currentActiveRecording];
    if (elapsed >= maxRecordTimeMs) {
      stopRecordingAndSave(currentActiveRecording);
    }
  }
  
  // Dynamic play loop state auto-reset handling: if end, go to start
  if (currentActivePlayback != -1 && 
   memories[currentActivePlayback] != null) {
 if (!memories[currentActivePlayback].isPlaying()) {
      // Loop execution completed naturally, safely reset pointer
      currentActivePlayback = -1; 
    }
  }

  // Draw visual grid map layout interface
  for (int i = 0; i < 9; i++) {
    int col = i % cols;
    int row = i / cols;
    float x = col * btnW;
    float y = row * btnH;
    
    // Aesthetic structural coloration adjustments
    if (i == 0) {
      // First button (Play/Pause control indicator feedback color)
      if (currentActivePlayback != -1)
   fill(46, 204, 113); // Green if actively playing
      else fill(52, 152, 219); // Default Blue
    } else if (isRecording[i]) {
      fill(231, 76, 60); // Red alert if currently recording via microphone source
    } else if (memories[i] != null) {
      fill(241, 196, 15); // Yellow warning highlight if bank contains memory elements
    } else {
      fill(70); // Default idle state dark grey
    }
    
    stroke(255);
    strokeWeight(2);
    rect(x, y, btnW, btnH, 10);
    
    // Render text typography configurations
    fill(255);
    textAlign(CENTER, CENTER);
    textSize(16);
    
    if (isRecording[i]) {
      float remaining = 
 (maxRecordTimeMs - (millis() - recordStartTime[i])) 
      / 1000.0;
      text("REC: " + nf(remaining, 1, 1) + "s"
        , x + btnW/2, y + btnH/2);
    } else {
      text(btnLabels[i], x + btnW/2, y + btnH/2);
    }
  }
}

void mousePressed() {
  // Determine coordinate cell matrix mapping calculations
  int col = floor(mouseX / btnW);
  int row = floor(mouseY / btnH);
  int index = col + row * cols;
  
  // Bound restrictions security check guard rails
  if (index < 0 || index >= 9) return;
  
  if (index == 0) {
    // 1st Button functionality behavior handler matrix structure block: PLAY / PAUSE Toggle
    handlePlayPauseToggle();
  } else {
    // Buttons 2-9 memory allocation management structure block: RECORD logic
    handleMemoryRecording(index);
  }
}

void handlePlayPauseToggle() {
  // Finds the first available functional recorded audio buffer slot to manipulate
  int targetIndex = -1;
  for (int i = 1; i < 9; i++) {
    if (memories[i] != null) {
      targetIndex = i;
      break;
    }
  }
  
  if (targetIndex == -1) {
    println("No recorded memory profiles discovered to feed audio components engine.");
    return;
  }
  
  if (currentActivePlayback != -1) {
    // If running already, toggle pause execution sequences
    memories[currentActivePlayback].pause();
    currentActivePlayback = -1;
  } else {
    // Execute dynamic audio play back framework components layout operations
    memories[targetIndex].play();
    currentActivePlayback = targetIndex;
  }
}

void handleMemoryRecording(int index) {
  // If actively looping record execution matrices path routes
  if (isRecording[index]) {
    stopRecordingAndSave(index);
  } else {
    // Guard clause checking to safely pause active processes prior to execution
    if (currentActiveRecording != -1) {
      stopRecordingAndSave(currentActiveRecording);
    }
    if (currentActivePlayback != -1) {
      memories[currentActivePlayback].stop();
      currentActivePlayback = -1;
    }
    
    // Instantiate raw sampling storage allocations initialization commands
    isRecording[index] = true;
    currentActiveRecording = index;
    recordStartTime[index] = millis();
    
    // Create standalone sample storage structure references framework mappings 
    memories[index] = 



   new SoundFile(this, str(int(maxRecordTimeMs))  ); 



    // Start streaming mic signal data array tracks into raw system sound file context indices 
    // NOTE: For live mic file writing, alternative platforms may utilize a helper class 'SoundRecorder'
  }
}

void stopRecordingAndSave(int index) {
  isRecording[index] = false;
  currentActiveRecording = -1;
   //  println("Memory cell index slot [" + index + "] bound cleanly captured up to 20 seconds loop frame data.");
}







*/
















































































import processing.sound.*;
import android.os.Environment;

// ============================================================
// 9 MEMORY AUDIO RECORDER
// APDE / PROCESSING
// 9 buttons:
//   1 = PLAY / PAUSE
//   2-9 = RECORD / STOP
//
// Maximum recording time = 20 seconds
// ============================================================
/*
AudioIn mic;
SoundFile[] memories = new SoundFile[9]; // Holds audio data for 9 buttons
boolean[] isRecording = new boolean[9];
int[] recordStartTime = new int[9];
int maxRecordTimeMs = 20000; // Maximum 20 seconds ring memory limit

// Active state monitoring
int currentActivePlayback = -1; 
int currentActiveRecording = -1;

// Grid layout variables (9 buttons in portrait format)
int cols = 3;
int rows = 3;
float btnW, btnH;
String[] btnLabels = {"Play/Pause", "Mem 2 (Rec)", "Mem 3 (Rec)", 
                      "Mem 4 (Rec)", "Mem 5 (Rec)", "Mem 6 (Rec)", 
                      "Mem 7 (Rec)", "Mem 8 (Rec)", "Mem 9 (Rec)"};

   */









/*


AudioIn mic;
SoundRecorder recorder;
SoundFile[] memories = new SoundFile[9];

boolean[] isRecording = new boolean[9];
boolean[] hasMemory = new boolean[9];

int[] recordStartTime = new int[9];

int currentActiveRecording = -1;
int currentActivePlayback = -1;

int maxRecordTimeMs = 20000;

int cols = 3;
int rows = 3;

float btnW;
float btnH;

String[] btnLabels = {
  "PLAY / PAUSE",
  "MEM 2 REC",
  "MEM 3 REC",
  "MEM 4 REC",
  "MEM 5 REC",
  "MEM 6 REC",
  "MEM 7 REC",
  "MEM 8 REC",
  "MEM 9 REC"
};

// ============================================================
// SETUP
// ============================================================

void setup() {

  size(450, 1700);

  orientation(PORTRAIT);

  btnW = width / (float)cols;
  btnH = height / (float)rows;

  // Microphone
  mic = new AudioIn(this, 0);
  mic.start();

  // Recorder receives microphone input
  recorder = new SoundRecorder(this);

  recorder.input(mic);

  for (int i = 0; i < 9; i++) {
    isRecording[i] = false;
    hasMemory[i] = false;
    memories[i] = null;
  }

  println("9 Memory Recorder ready.");
}

// ============================================================
// DRAW
// ============================================================

void draw() {

  background(35);

  updateRecordingTimer();

  updatePlayback();

  drawButtons();
}

// ============================================================
// RECORDING TIMER
// ============================================================

void updateRecordingTimer() {

  if (currentActiveRecording == -1) {
    return;
  }

  int i = currentActiveRecording;

  int elapsed = millis() - recordStartTime[i];

  if (elapsed >= maxRecordTimeMs) {

    println("20 seconds reached.");

    stopRecordingAndSave(i);
  }
}

// ============================================================
// PLAYBACK MONITOR
// ============================================================

void updatePlayback() {

  if (currentActivePlayback == -1) {
    return;
  }

  int i = currentActivePlayback;

  if (memories[i] == null) {
    currentActivePlayback = -1;
    return;
  }

  if (!memories[i].isPlaying()) {
    currentActivePlayback = -1;
  }
}

// ============================================================
// DRAW 9 BUTTONS
// ============================================================

void drawButtons() {

  for (int i = 0; i < 9; i++) {

    int col = i % cols;
    int row = i / cols;

    float x = col * btnW;
    float y = row * btnH;

    // --------------------------------------------------------
    // BUTTON COLOR
    // --------------------------------------------------------

    if (i == 0) {

      if (currentActivePlayback != -1) {
        fill(46, 204, 113);
      } else {
        fill(52, 152, 219);
      }

    } else if (isRecording[i]) {

      fill(231, 76, 60);

    } else if (hasMemory[i]) {

      fill(241, 196, 15);

    } else {

      fill(70);
    }

    stroke(255);
    strokeWeight(2);

    rect(
      x,
      y,
      btnW,
      btnH,
      10
      );

    // --------------------------------------------------------
    // TEXT
    // --------------------------------------------------------

    fill(255);

    textAlign(CENTER, CENTER);

    textSize(18);

    if (isRecording[i]) {

      int elapsed =
        millis() - recordStartTime[i];

      float remaining =
        (maxRecordTimeMs - elapsed) / 1000.0;

      if (remaining < 0) {
        remaining = 0;
      }

      text(
        "REC " + nf(remaining, 1, 1) + " s",
        x + btnW / 2,
        y + btnH / 2
        );

    } else if (i == 0) {

      if (currentActivePlayback != -1) {

        text(
          "PAUSE",
          x + btnW / 2,
          y + btnH / 2
          );

      } else {

        text(
          "PLAY",
          x + btnW / 2,
          y + btnH / 2
          );
      }

    } else {

      text(
        btnLabels[i],
        x + btnW / 2,
        y + btnH / 2
        );
    }
  }
}

// ============================================================
// TOUCH
// ============================================================

void mousePressed() {

  int col = floor(mouseX / btnW);
  int row = floor(mouseY / btnH);

  int index = col + row * cols;

  if (index < 0 || index >= 9) {
    return;
  }

  // Button 1
  if (index == 0) {

    handlePlayPause();

  } else {

    // Buttons 2-9
    handleMemoryRecording(index);
  }
}

// ============================================================
// PLAY / PAUSE
// ============================================================

void handlePlayPause() {

  // If something is playing -> pause
  if (currentActivePlayback != -1) {

    int oldIndex = currentActivePlayback;

    if (memories[oldIndex] != null) {

      memories[oldIndex].pause();
    }

    currentActivePlayback = -1;

    return;
  }

  // Find first recorded memory
  int target = -1;

  for (int i = 1; i < 9; i++) {

    if (hasMemory[i] &&
        memories[i] != null) {

      target = i;
      break;
    }
  }

  if (target == -1) {

    println("No recorded memory.");

    return;
  }

  memories[target].play();

  currentActivePlayback = target;

  println(
    "Playing memory " + (target + 1)
    );
}

// ============================================================
// RECORD BUTTON
// ============================================================

void handleMemoryRecording(int index) {

  // ----------------------------------------------------------
  // If this button is already recording -> STOP
  // ----------------------------------------------------------

  if (isRecording[index]) {

    stopRecordingAndSave(index);

    return;
  }

  // ----------------------------------------------------------
  // Stop another recording first
  // ----------------------------------------------------------

  if (currentActiveRecording != -1) {

    stopRecordingAndSave(
      currentActiveRecording
      );
  }

  // ----------------------------------------------------------
  // Stop playback
  // ----------------------------------------------------------

  if (currentActivePlayback != -1) {

    int p = currentActivePlayback;

    if (memories[p] != null) {

      memories[p].stop();
    }

    currentActivePlayback = -1;
  }

  // ----------------------------------------------------------
  // Start recording
  // ----------------------------------------------------------

  startRecording(index);
}

// ============================================================
// START RECORDING
// ============================================================

void startRecording(int index) {

  String filename =
    "memory_" + (index + 1) + "_" +
    year() + "_" +
    month() + "_" +
    day() + "_" +
    hour() + "_" +
    minute() + "_" +
    second() + ".wav";

  println("START RECORDING:");
  println(filename);

  // Start SoundRecorder
  recorder.record(filename);

  isRecording[index] = true;

  currentActiveRecording = index;

  recordStartTime[index] = millis();

  hasMemory[index] = false;
}

// ============================================================
// STOP RECORDING
// ============================================================

void stopRecordingAndSave(int index) {

  if (index < 0 || index >= 9) {
    return;
  }

  if (!isRecording[index]) {
    return;
  }

  // Stop SoundRecorder
  recorder.stop();

  isRecording[index] = false;

  currentActiveRecording = -1;

  hasMemory[index] = true;

  println(
    "Memory " + (index + 1) +
    " recording stopped."
    );

  println(
    "The WAV recording has been written."
    );

  // ----------------------------------------------------------
  // IMPORTANT:
  // The SoundRecorder creates the WAV file.
  //
  // The filename is stored so it can be loaded for playback.
  // ----------------------------------------------------------

  // Give the recording a moment to finish writing.
  delay(100);

  // Search for the newest filename is not portable in every
  // APDE/Android version, therefore the filename is retained.
  //
  // The next section loads the known filename.
}


*/








// ============================================================
// OPTIONAL FILE PLAYBACK LOADER
// ============================================================
//
// If you want guaranteed playback from the exact file created,
// use the same filename when starting the recording and save
// that filename in memoryFilename[].
//
// ============================================================
/*
Important correction: your original line

memories[index] = new SoundFile(this, str(int(maxRecordTimeMs)));

is wrong because ""20000"" is interpreted as a filename, not as “record for 20 seconds.”

The correct architecture is:

"AudioIn microphone  SoundRecorder  WAV file  SoundFile  Play"

One more change is needed for full working memory playback: each of the 8 recording buttons should store its exact WAV filename, then button 1 can load/play those files.


*/





















