









// Checkers.pde  –  Fixed for APDE
import java.util.ArrayList;
import java.util.HashSet;

final int BOARD_SIZE = 8;
final int EMPTY = 0;
final int BLACK_MAN = 1;
final int BLACK_KING = 2;
final int WHITE_MAN = -1;
final int WHITE_KING = -2;

int[][] board;
int cellSize;
int turn = 1;               // 1 = Black (human), -1 = White (AI)
boolean gameOver = false;
String statusMsg = "Your turn (Black)";
ArrayList selectedPath = new ArrayList();
ArrayList legalMoves = new ArrayList();
int aiDepth = 3;

void setup() {
  size(720, 820);
  orientation(PORTRAIT);
  cellSize = width / BOARD_SIZE;
  board = createInitialBoard();
  textAlign(CENTER, CENTER);
  textSize(22);
}

void draw() {
  background(40);
  drawBoard();
  drawPieces();
  drawStatus();
  
  if (!gameOver && turn == -1) {
    statusMsg = "Engine thinking...";
    ArrayList best = findBestMove(aiDepth);
    if (best != null) {
      applyMove(best);
      turn = 1;
      statusMsg = "Your turn (Black)";
      generateLegalMoves();
      if (legalMoves.size() == 0) {
        gameOver = true;
        statusMsg = "You have no moves. White wins!";
      }
    } else {
      gameOver = true;
      statusMsg = "White has no moves. You win!";
    }
  }
}

void mousePressed() {
  if (gameOver || turn != 1) return;
  
  int c = mouseX / cellSize;
  int r = mouseY / cellSize;
  if (r < 0 || r >= BOARD_SIZE || c < 0 || c >= BOARD_SIZE) return;
  
  PVector clicked = new PVector(r, c);
  
  if (selectedPath.size() == 0) {
    if (pieceColor(board[r][c]) == 1) {
      selectedPath.add(clicked);
      generateLegalMovesFrom(selectedPath);
    }
  } else {
    ArrayList candidate = new ArrayList(selectedPath);
    candidate.add(clicked);
    
    boolean isLegal = false;
    for (int i = 0; i < legalMoves.size(); i++) {
      ArrayList m = (ArrayList) legalMoves.get(i);
      if (pathsEqual(m, candidate)) {
        applyMove(m);
        selectedPath.clear();
        turn = -1;
        statusMsg = "Engine thinking...";
        isLegal = true;
        break;
      }
    }
    
    if (!isLegal) {
      boolean canExtend = false;
      for (int i = 0; i < legalMoves.size(); i++) {
        ArrayList m = (ArrayList) legalMoves.get(i);
        if (m.size() > selectedPath.size() && pathStartsWith(m, selectedPath)) {
          PVector next = (PVector) m.get(selectedPath.size());
          if (next.x == clicked.x && next.y == clicked.y) {
            selectedPath.add(clicked);
            canExtend = true;
            break;
          }
        }
      }
      if (!canExtend) {
        selectedPath.clear();
        if (pieceColor(board[r][c]) == 1) {
          selectedPath.add(clicked);
          generateLegalMovesFrom(selectedPath);
        }
      }
    }
  }
}

// -------------------- Board & Rules --------------------

int[][] createInitialBoard() {
  int[][] b = new int[BOARD_SIZE][BOARD_SIZE];
  for (int r = 0; r < 3; r++) {
    for (int c = 0; c < BOARD_SIZE; c++) {
      if ((r + c) % 2 == 1) b[r][c] = WHITE_MAN;
    }
  }
  for (int r = 5; r < 8; r++) {
    for (int c = 0; c < BOARD_SIZE; c++) {
      if ((r + c) % 2 == 1) b[r][c] = BLACK_MAN;
    }
  }
  return b;
}

int pieceColor(int p) {
  if (p > 0) return 1;
  if (p < 0) return -1;
  return 0;
}

boolean isKing(int p) {
  return abs(p) == 2;
}

PVector[] getDirections(int p) {
  if (isKing(p)) {
    return new PVector[]{ 
      new PVector(-1, -1), new PVector(-1, 1), 
      new PVector(1, -1), new PVector(1, 1) 
    };
  }
  if (p > 0) {
    return new PVector[]{ new PVector(-1, -1), new PVector(-1, 1) };
  }
  return new PVector[]{ new PVector(1, -1), new PVector(1, 1) };
}

void generateLegalMoves() {
  legalMoves.clear();
  ArrayList captures = new ArrayList();
  ArrayList quiet = new ArrayList();
  
  for (int r = 0; r < BOARD_SIZE; r++) {
    for (int c = 0; c < BOARD_SIZE; c++) {
      if (pieceColor(board[r][c]) != turn) continue;
      
      // Quiet moves
      PVector[] dirs = getDirections(board[r][c]);
      for (int d = 0; d < dirs.length; d++) {
        int nr = r + (int)dirs[d].x;
        int nc = c + (int)dirs[d].y;
        if (inBounds(nr, nc) && board[nr][nc] == EMPTY && isDark(nr, nc)) {
          ArrayList m = new ArrayList();
          m.add(new PVector(r, c));
          m.add(new PVector(nr, nc));
          quiet.add(m);
        }
      }
      
      // Captures
      findJumps(r, c, new ArrayList(), new HashSet(), captures);
    }
  }
  
  if (captures.size() > 0) {
    legalMoves.addAll(captures);
  } else {
    legalMoves.addAll(quiet);
  }
}

void generateLegalMovesFrom(ArrayList startPath) {
  legalMoves.clear();
  if (startPath.size() == 0) return;
  
  PVector start = (PVector) startPath.get(0);
  int sr = (int)start.x;
  int sc = (int)start.y;
  
  ArrayList captures = new ArrayList();
  findJumps(sr, sc, new ArrayList(), new HashSet(), captures);
  
  for (int i = 0; i < captures.size(); i++) {
    ArrayList m = (ArrayList) captures.get(i);
    if (pathStartsWith(m, startPath)) {
      legalMoves.add(m);
    }
  }
  
  if (legalMoves.size() == 0) {
    int p = board[sr][sc];
    PVector[] dirs = getDirections(p);
    for (int d = 0; d < dirs.length; d++) {
      int nr = sr + (int)dirs[d].x;
      int nc = sc + (int)dirs[d].y;
      if (inBounds(nr, nc) && board[nr][nc] == EMPTY && isDark(nr, nc)) {
        ArrayList m = new ArrayList();
        m.add(new PVector(sr, sc));
        m.add(new PVector(nr, nc));
        legalMoves.add(m);
      }
    }
  }
}

void findJumps(int r, int c, ArrayList path, HashSet visited, ArrayList results) {
  if (path.size() == 0) {
    path.add(new PVector(r, c));
  }
  
  boolean found = false;
  PVector origin = (PVector) path.get(0);
  int p = board[(int)origin.x][(int)origin.y];
  
  PVector[] dirs = getDirections(p);
  for (int d = 0; d < dirs.length; d++) {
    int jr = r + (int)dirs[d].x;
    int jc = c + (int)dirs[d].y;
    int lr = r + 2 * (int)dirs[d].x;
    int lc = c + 2 * (int)dirs[d].y;
    
    String key = jr + "," + jc;
    if (inBounds(jr, jc) && inBounds(lr, lc) &&
        pieceColor(board[jr][jc]) == -turn &&
        board[lr][lc] == EMPTY && isDark(lr, lc) &&
        !visited.contains(key)) {
      
      visited.add(key);
      ArrayList newPath = new ArrayList(path);
      newPath.add(new PVector(lr, lc));
      findJumps(lr, lc, newPath, visited, results);
      visited.remove(key);
      found = true;
    }
  }
  
  if (!found && path.size() > 1) {
    results.add(new ArrayList(path));
  }
}

void applyMove(ArrayList move) {
  PVector start = (PVector) move.get(0);
  int sr = (int)start.x;
  int sc = (int)start.y;
  int p = board[sr][sc];
  board[sr][sc] = EMPTY;
  
  for (int i = 1; i < move.size(); i++) {
    PVector curr = (PVector) move.get(i);
    PVector prev = (PVector) move.get(i - 1);
    int r = (int)curr.x;
    int c = (int)curr.y;
    
    if (abs(r - (int)prev.x) == 2) {
      int jr = (r + (int)prev.x) / 2;
      int jc = (c + (int)prev.y) / 2;
      board[jr][jc] = EMPTY;
    }
    board[r][c] = p;
  }
  
  // Promotion
  PVector end = (PVector) move.get(move.size() - 1);
  int er = (int)end.x;
  int ec = (int)end.y;
  if (p == BLACK_MAN && er == 0) board[er][ec] = BLACK_KING;
  if (p == WHITE_MAN && er == 7) board[er][ec] = WHITE_KING;
}

// -------------------- AI --------------------

ArrayList findBestMove(int depth) {
  int bestScore = Integer.MAX_VALUE;
  ArrayList bestMove = null;
  
  generateLegalMoves();
  for (int i = 0; i < legalMoves.size(); i++) {
    ArrayList m = (ArrayList) legalMoves.get(i);
    int[][] copy = copyBoard(board);
    applyMove(m);
    int score = minimax(depth - 1, Integer.MIN_VALUE, Integer.MAX_VALUE, true);
    board = copy;
    
    if (score < bestScore) {
      bestScore = score;
      bestMove = m;
    }
  }
  return bestMove;
}

int minimax(int depth, int alpha, int beta, boolean maximizing) {
  int color = maximizing ? 1 : -1;
  int oldTurn = turn;
  turn = color;
  generateLegalMoves();
  ArrayList moves = new ArrayList(legalMoves);
  turn = oldTurn;
  
  if (depth == 0 || moves.size() == 0) {
    return evaluate();
  }
  
  if (maximizing) {
    int maxEval = Integer.MIN_VALUE;
    for (int i = 0; i < moves.size(); i++) {
      ArrayList m = (ArrayList) moves.get(i);
      int[][] copy = copyBoard(board);
      applyMove(m);
      int eval = minimax(depth - 1, alpha, beta, false);
      board = copy;
      maxEval = max(maxEval, eval);
      alpha = max(alpha, eval);
      if (beta <= alpha) break;
    }
    return maxEval;
  } else {
    int minEval = Integer.MAX_VALUE;
    for (int i = 0; i < moves.size(); i++) {
      ArrayList m = (ArrayList) moves.get(i);
      int[][] copy = copyBoard(board);
      applyMove(m);
      int eval = minimax(depth - 1, alpha, beta, true);
      board = copy;
      minEval = min(minEval, eval);
      beta = min(beta, eval);
      if (beta <= alpha) break;
    }
    return minEval;
  }
}

int evaluate() {
  int score = 0;
  for (int r = 0; r < BOARD_SIZE; r++) {
    for (int c = 0; c < BOARD_SIZE; c++) {
      int p = board[r][c];
      if (p == BLACK_MAN) score += 100 + (7 - r);
      else if (p == BLACK_KING) score += 200;
      else if (p == WHITE_MAN) score -= 100 + r;
      else if (p == WHITE_KING) score -= 200;
    }
  }
  return score;
}

// -------------------- Helpers & Drawing --------------------

boolean inBounds(int r, int c) {
  return r >= 0 && r < BOARD_SIZE && c >= 0 && c < BOARD_SIZE;
}

boolean isDark(int r, int c) {
  return (r + c) % 2 == 1;
}

int[][] copyBoard(int[][] src) {
  int[][] dst = new int[BOARD_SIZE][BOARD_SIZE];
  for (int i = 0; i < BOARD_SIZE; i++) {
    arrayCopy(src[i], dst[i]);
  }
  return dst;
}

boolean pathsEqual(ArrayList a, ArrayList b) {
  if (a.size() != b.size()) return false;
  for (int i = 0; i < a.size(); i++) {
    PVector pa = (PVector) a.get(i);
    PVector pb = (PVector) b.get(i);
    if (pa.x != pb.x || pa.y != pb.y) return false;
  }
  return true;
}

boolean pathStartsWith(ArrayList full, ArrayList prefix) {
  if (prefix.size() > full.size()) return false;
  for (int i = 0; i < prefix.size(); i++) {
    PVector pf = (PVector) full.get(i);
    PVector pp = (PVector) prefix.get(i);
    if (pf.x != pp.x || pf.y != pp.y) return false;
  }
  return true;
}

void drawBoard() {
  for (int r = 0; r < BOARD_SIZE; r++) {
    for (int c = 0; c < BOARD_SIZE; c++) {
      if (isDark(r, c)) fill(139, 90, 43);
      else fill(245, 222, 179);
      rect(c * cellSize, r * cellSize, cellSize, cellSize);
      
      // Highlight selected path
      for (int i = 0; i < selectedPath.size(); i++) {
        PVector p = (PVector) selectedPath.get(i);
        if ((int)p.x == r && (int)p.y == c) {
          fill(255, 255, 0, 120);
          rect(c * cellSize, r * cellSize, cellSize, cellSize);
        }
      }
    }
  }
}

void drawPieces() {
  for (int r = 0; r < BOARD_SIZE; r++) {
    for (int c = 0; c < BOARD_SIZE; c++) {
      int p = board[r][c];
      if (p == 0) continue;
      
      float cx = c * cellSize + cellSize / 2.0;
      float cy = r * cellSize + cellSize / 2.0;
      float rad = cellSize * 0.38;
      
      if (p > 0) fill(30);
      else fill(240, 240, 240);
      
      stroke(20);
      strokeWeight(2);
      ellipse(cx, cy, rad * 2, rad * 2);
      
      if (isKing(p)) {
        fill(p > 0 ? 200 : 50);
        noStroke();
        ellipse(cx, cy, rad * 0.9, rad * 0.9);
      }
    }
  }
  noStroke();
}

void drawStatus() {
  fill(30);
  rect(0, BOARD_SIZE * cellSize, width, height - BOARD_SIZE * cellSize);
  fill(255);
  text(statusMsg, width/2, BOARD_SIZE * cellSize + 40);
  text("Tap black piece, then destination", width/2, BOARD_SIZE * cellSize + 75);
}









