













/*
APDE / Processing (Android) example: 3D rotating
 mountains (points + lines, random heights 0–100)
Copy-paste this into APDE
 (or any Processing P3D sketch). Size is 555×555 as
 requested. It builds a grid of random heights, draws
 both points and connecting lines (wireframe terrain), and 
continuously rotates in 3D.
*/
// APDE EXAMPLE 3D MOUNTAINS
// 555 555 | POINTS + LINES | HEIGHTS RANDOM 0-100 | ALL-TIME 3D ROTATION

int cols = 40;
int rows = 40;
float[][] heights;
float spacing;
float rotY = 0;
float rotX = -0.4;

void setup() {
  size(555, 555, P3D);
  spacing = 400.0 / (cols - 1);   // terrain roughly 400 units wide
  heights = new float[cols][rows];
  
  // random heights 0..100
  for (int i = 0; i < cols; i++) {
    for (int j = 0; j < rows; j++) {
      heights[i][j] = random(0, 100);
    }
  }
}

void draw() {
  background(10, 15, 30);
  lights();
  
  // center + continuous 3D rotation
  translate(width/2, height/2 + 40, -200);
  rotateX(rotX);
  rotateY(rotY);
  rotY += 0.008;                 // all-time slow rotation
  
  // draw points + lines
  strokeWeight(1.5);
  noFill();
  
  // horizontal lines + points
  for (int j = 0; j < rows; j++) {
    beginShape(LINES);
    for (int i = 0; i < cols-1; i++) {
      float x1 = (i - cols/2.0) * spacing;
      float z1 = (j - rows/2.0) * spacing;
      float y1 = -heights[i][j];          // negative so mountains go up
      
      float x2 = ((i+1) - cols/2.0) * spacing;
      float z2 = (j - rows/2.0) * spacing;
      float y2 = -heights[i+1][j];
      
      // color by height
      float c = map(heights[i][j], 0, 100, 80, 255);
      stroke(c*0.6, c*0.8, 255);
      
      vertex(x1, y1, z1);
      vertex(x2, y2, z2);
      
      // points
      point(x1, y1, z1);
    }
    endShape();
  }
  
  // vertical lines
  for (int i = 0; i < cols; i++) {
    beginShape(LINES);
    for (int j = 0; j < rows-1; j++) {
      float x1 = (i - cols/2.0) * spacing;
      float z1 = (j - rows/2.0) * spacing;
      float y1 = -heights[i][j];
      
      float x2 = (i - cols/2.0) * spacing;
      float z2 = ((j+1) - rows/2.0) * spacing;
      float y2 = -heights[i][j+1];
      
      float c = map(heights[i][j], 0, 100, 80, 255);
      stroke(c*0.5, c, 220);
      
      vertex(x1, y1, z1);
      vertex(x2, y2, z2);
    }
    endShape();
  }
}




/*
Quick notes for APDE
Uses P3D (works on Android).
Heights are pure random(0, 100) as requested.
Both points and lines are drawn.
Continuous rotation via rotY += 0.008.
You can raise cols/rows (e.g. 60) for denser mountains, or lower for better performance on older devices.
To reseed the terrain, just restart the sketch (or add a touch to regenerate the height array).
Run it and you should see a wireframe mountain range slowly spinning. Enjoy!

*/



















