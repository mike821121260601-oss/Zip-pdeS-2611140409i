


// OpenProcessing Chess Game (.pde)
// Click and drag a piece to move it.

int tileSize;
int selectedRow = -1;
int selectedCol = -1;
boolean isDragging = false;

// Board representation: uppercase for White, lowercase for Black
// R=Rook, N=Knight, B=Bishop, Q=Queen, K=King, P=Pawn, '.'=Empty
char[][] board = {
  {'r', 'n', 'b', 'q', 'k', 'b', 'n', 'r'},
  {'p', 'p', 'p', 'p', 'p', 'p', 'p', 'p'},
  {'.', '.', '.', '.', '.', '.', '.', '.'},
  {'.', '.', '.', '.', '.', '.', '.', '.'},
  {'.', '.', '.', '.', '.', '.', '.', '.'},
  {'.', '.', '.', '.', '.', '.', '.', '.'},
  {'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P'},
  {'R', 'N', 'B', 'Q', 'K', 'B', 'N', 'R'}
};

void setup() {
  size(600, 600);
  tileSize = width / 8;
  textAlign(CENTER, CENTER);
  textSize(tileSize * 0.75);
}

void draw() {
  drawBoard();
  drawPieces();
}

// Renders the alternating checkerboard pattern
void drawBoard() {
  for (int row = 0; row < 8; row++) {
    for (int col = 0; col < 8; col++) {
      if ((row + col) % 2 == 0) {
        fill(240, 217, 181); // Light square
      } else {
        fill(181, 136, 99);  // Dark square
      }
      noStroke();
      rect(col * tileSize, row * tileSize, tileSize, tileSize);
    }
  }
}

// Map characters to Unicode chess symbols and render them
void drawPieces() {
  for (int row = 0; row < 8; row++) {
    for (int col = 0; col < 8; col++) {
      char piece = board[row][col];
      
      // If we are dragging this specific piece, skip drawing it here
      if (isDragging && row == selectedRow && col == selectedCol) {
        continue;
      }
      
      if (piece != '.') {
        String sym = getPieceSymbol(piece);
        // White pieces are uppercase, Black are lowercase
        if (Character.isUpperCase(piece)) {
          fill(255); // White piece fill
          stroke(0); // Optional border hint
        } else {
          fill(0);   // Black piece fill
        }
        text(sym, col * tileSize + tileSize/2, row * tileSize + tileSize/2);
      }
    }
  }
  
  // Render the dragged piece directly under the mouse pointer
  if (isDragging && selectedRow != -1 && selectedCol != -1) {
    char piece = board[selectedRow][selectedCol];
    if (Character.isUpperCase(piece)) {
      fill(255);
    } else {
      fill(0);
    }
    text(getPieceSymbol(piece), mouseX, mouseY);
  }
}

// Convert board characters to actual visual symbols
String getPieceSymbol(char piece) {
  switch (Character.toLowerCase(piece)) {
    case 'r': return "♜";
    case 'n': return "♞";
    case 'b': return "♝";
    case 'q': return "♛";
    case 'k': return "♚";
    case 'p': return "♟";
    default: return "";
  }
}

void mousePressed() {
  int col = mouseX / tileSize;
  int row = mouseY / tileSize;
  
  // Check boundaries and make sure the selected square isn't empty
  if (row >= 0 && row < 8 && col >= 0 && col < 8) {
    if (board[row][col] != '.') {
      selectedRow = row;
      selectedCol = col;
      isDragging = true;
    }
  }
}

void mouseReleased() {
  if (isDragging) {
    int targetCol = mouseX / tileSize;
    int targetRow = mouseY / tileSize;
    
    // Ensure the drop destination is within board boundaries
    if (targetRow >= 0 && targetRow < 8 && targetCol >= 0 && targetCol < 8) {
      // Prevent replacing yourself unless it's a new square
      if (targetRow != selectedRow || targetCol != selectedCol) {
        board[targetRow][targetCol] = board[selectedRow][selectedCol];
        board[selectedRow][selectedCol] = '.';
      }
    }
    
    // Reset state
    isDragging = false;
    selectedRow = -1;
    selectedCol = -1;
  }
}













