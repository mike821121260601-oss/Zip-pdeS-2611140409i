Stockfish 1.0 -> один HTML-файл

Файли:
  stockfish_single.cpp  - увесь Stockfish 1.0 в одному C++ файлі
                          (звичайна збірка: g++ -O3 -DNDEBUG -fno-strict-enums -fno-strict-aliasing stockfish_single.cpp -lpthread)
  chess_template.html   - сторінка з дошкою (рушій сюди вбудовується збіркою)
  build.py              - збирає stockfish_game.html (потрібен Emscripten: em++ у PATH)

Збірка:  python3 build.py   ->  stockfish_game.html (один файл, працює офлайн)
Режими:  рушій проти рушія (різний час на хід) або людина (білі) проти рушія.
