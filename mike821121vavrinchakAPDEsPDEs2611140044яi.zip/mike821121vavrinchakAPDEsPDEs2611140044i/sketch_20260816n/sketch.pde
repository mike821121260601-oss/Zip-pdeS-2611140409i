

import android.media.AudioTrack;
import android.media.AudioFormat;
import android.media.AudioManager;

// ----------------------------------------------------
// 25 MUSIC KEYS
// ----------------------------------------------------

float[] notes = {
  261.63, 277.18, 293.66, 311.13, 329.63,
  349.23, 369.99, 392.00, 415.30, 440.00,
  466.16, 493.88, 523.25, 554.37, 587.33,
  622.25, 659.25, 698.46, 739.99, 783.99,
  830.61, 880.00, 932.33, 987.77, 1046.50
};

String[] noteName = {
  "C4","C#4","D4","D#4","E4",
  "F4","F#4","G4","G#4","A4",
  "A#4","B4","C5","C#5","D5",
  "D#5","E5","F5","F#5","G5",
  "G#5","A5","A#5","B5","C6"
};

// ----------------------------------------------------
// AUDIO
// ----------------------------------------------------

int sampleRate = 44100;

AudioTrack audio;

boolean playing = false;

int currentKey = -1;

float currentVolume = 0.9;
float currentTimeMultiplier = 1.0;

long lastTouchTime = 0;

int repeatTime = 90;

// ----------------------------------------------------
// SETUP
// ----------------------------------------------------

void setup() {

  size(displayWidth, displayHeight, P2D);

  orientation(PORTRAIT);

  textAlign(CENTER, CENTER);

  createAudio();

}

// ----------------------------------------------------
// AUDIO SETUP
// ----------------------------------------------------

void createAudio() {

  int bufferSize =
    AudioTrack.getMinBufferSize(
      sampleRate,
      AudioFormat.CHANNEL_OUT_MONO,
      AudioFormat.ENCODING_PCM_16BIT
    );

  audio = new AudioTrack(
    AudioManager.STREAM_MUSIC,
    sampleRate,
    AudioFormat.CHANNEL_OUT_MONO,
    AudioFormat.ENCODING_PCM_16BIT,
    bufferSize,
    AudioTrack.MODE_STREAM
  );

  audio.play();
}

// ----------------------------------------------------
// DRAW
// ----------------------------------------------------

void draw() {

  background(15);

  float keyW = width / 5.0;
  float keyH = height / 5.0;

  for (int i = 0; i < 25; i++) {

    int col = i % 5;
    int row = i / 5;

    float x = col * keyW;
    float y = row * keyH;

    // -------------------------------
    // KEY
    // -------------------------------

    if (i == currentKey) {
      fill(255, 180, 40);
    } else {
      fill(40, 90, 190);
    }

    stroke(255);
    strokeWeight(2);

    rect(
      x + 3,
      y + 3,
      keyW - 6,
      keyH - 6
    );

    // -------------------------------
    // LEFT / RIGHT DIVISION
    // -------------------------------

    stroke(255, 100);

    line(
      x + keyW / 2,
      y + 3,
      x + keyW / 2,
      y + keyH - 3
    );

    // -------------------------------
    // NOTE NAME
    // -------------------------------

    fill(255);

    textSize(min(keyW, keyH) * 0.18);

    text(
      noteName[i],
      x + keyW / 2,
      y + keyH * 0.25
    );

    // -------------------------------
    // LEFT SIDE
    // VOLUME
    // -------------------------------

    textSize(min(keyW, keyH) * 0.09);

    text(
      "VOL",
      x + keyW * 0.25,
      y + keyH * 0.55
    );

    // -------------------------------
    // RIGHT SIDE
    // TIME
    // -------------------------------

    text(
      "TIME",
      x + keyW * 0.75,
      y + keyH * 0.55
    );

    // -------------------------------
    // SCALE LABELS
    // -------------------------------

    textSize(min(keyW, keyH) * 0.065);

    text(
      "90%",
      x + keyW * 0.25,
      y + keyH * 0.70
    );

    text(
      "10%",
      x + keyW * 0.25,
      y + keyH * 0.92
    );

    text(
      "×100",
      x + keyW * 0.75,
      y + keyH * 0.70
    );

    text(
      "×1",
      x + keyW * 0.75,
      y + keyH * 0.92
    );
  }

  // ------------------------------------------------
  // CURRENT VALUES
  // ------------------------------------------------

  fill(255);

  textSize(18);

  text(
    "VOLUME " +
    int(currentVolume * 100) +
    "%    TIME ×" +
    nf(currentTimeMultiplier, 1, 1),
    width / 2,
    height - 15
  );
}

// ----------------------------------------------------
// TOUCH START
// ----------------------------------------------------

boolean touchStartedIAM() {

  handleTouch(mouseX, mouseY, true);

  return true;
}

// ----------------------------------------------------
// TOUCH MOVE
// ----------------------------------------------------

boolean touchMovedIAM() {

  handleTouch(mouseX, mouseY, false);

  return true;
}

// ----------------------------------------------------
// TOUCH END
// ----------------------------------------------------

boolean touchEndedIAM() {

  currentKey = -1;

  return true;
}

// ----------------------------------------------------
// HANDLE TOUCH
// ----------------------------------------------------

void handleTouch(float tx, float ty, boolean firstTouch) {

  float keyW = width / 5.0;
  float keyH = height / 5.0;

  if (tx < 0 || tx >= width) return;
  if (ty < 0 || ty >= height) return;

  int col = int(tx / keyW);
  int row = int(ty / keyH);

  if (col < 0 || col >= 5) return;
  if (row < 0 || row >= 5) return;

  int key = row * 5 + col;

  // ------------------------------------------------
  // POSITION INSIDE KEY
  // ------------------------------------------------

  float keyX = col * keyW;
  float keyY = row * keyH;

  float localX = tx - keyX;
  float localY = ty - keyY;

  float vertical = localY / keyH;

  vertical = constrain(vertical, 0, 1);

  // ------------------------------------------------
  // LEFT SIDE = VOLUME
  // TOP 90%
  // BOTTOM 10%
  // ------------------------------------------------

  if (localX < keyW / 2.0) {

    currentVolume =
      0.90 - vertical * 0.80;

    currentVolume =
      constrain(currentVolume, 0.10, 0.90);

  }

  // ------------------------------------------------
  // RIGHT SIDE = TIME
  // TOP ×100
  // BOTTOM ×1
  // ------------------------------------------------

  else {

    currentTimeMultiplier =
      100.0 - vertical * 99.0;

    currentTimeMultiplier =
      constrain(
        currentTimeMultiplier,
        1.0,
        100.0
      );
  }

  // ------------------------------------------------
  // NEW KEY
  // ------------------------------------------------

  if (key != currentKey) {

    currentKey = key;

    playCurrentNote(
      notes[key],
      currentVolume,
      currentTimeMultiplier
    );

    lastTouchTime = millis();

  }

  // ------------------------------------------------
  // CONTINUOUS DRAG
  // ------------------------------------------------

  else {

    if (millis() - lastTouchTime > repeatTime) {

      playCurrentNote(
        notes[key],
        currentVolume,
        currentTimeMultiplier
      );

      lastTouchTime = millis();

    }
  }
}

// ----------------------------------------------------
// PLAY NOTE
// ----------------------------------------------------

void playCurrentNote(
  final float frequency,
  final float volume,
  final float multiplier
) {

  final int duration =
    int(300.0 * multiplier);

  Thread t = new Thread(
    new Runnable() {

      public void run() {

        playTone(
          frequency,
          volume,
          duration
        );

      }
    }
  );

  t.start();
}

// ----------------------------------------------------
// GENERATE SINE WAVE
// ----------------------------------------------------

void playTone(
  float frequency,
  float volume,
  int duration
) {

  if (audio == null) return;

  int samples =
    int(sampleRate * duration / 1000.0);

  // Protect memory for very long notes
  if (samples > sampleRate * 30)
    samples = sampleRate * 30;

  short[] buffer =
    new short[samples];

  for (int i = 0; i < samples; i++) {

    float time =
      (float)i / sampleRate;

    // ---------------------------------------------
    // ATTACK
    // ---------------------------------------------

    float envelope = 1.0;

    int attack =
      int(sampleRate * 0.015);

    if (attack < 1)
      attack = 1;

    if (i < attack) {

      envelope =
        (float)i / attack;
    }

    // ---------------------------------------------
    // RELEASE
    // ---------------------------------------------

    int release =
      int(sampleRate * 0.08);

    if (release < 1)
      release = 1;

    if (i > samples - release) {

      envelope =
        (float)(samples - i) / release;
    }

    envelope =
      constrain(envelope, 0, 1);

    // ---------------------------------------------
    // SINE
    // ---------------------------------------------

    double wave =
      Math.sin(
        2.0 *
        Math.PI *
        frequency *
        time
      );

    buffer[i] =
      (short)(
        wave *
        16000.0 *
        volume *
        envelope
      );
  }

  // ---------------------------------------------
  // PLAY
  // ---------------------------------------------

  synchronized(audio) {

    if (audio.getPlayState() !=
        AudioTrack.PLAYSTATE_PLAYING) {

      audio.play();
    }

    audio.write(
      buffer,
      0,
      buffer.length
    );
  }
}

// ----------------------------------------------------
// PAUSE
// ----------------------------------------------------

void onPause() {

  super.onPause();

  if (audio != null) {

    try {
      audio.pause();
    }
    catch(Exception e) {
    }
  }
}

// ----------------------------------------------------
// RESUME
// ----------------------------------------------------

void onResume() {

  super.onResume();

  if (audio != null) {

    try {
      audio.play();
    }
    catch(Exception e) {
    }
  }
}

// ----------------------------------------------------
// DESTROY
// ----------------------------------------------------

void onDestroy() {

  if (audio != null) {

    try {
      audio.stop();
      audio.release();
    }
    catch(Exception e) {
    }
  }

  super.onDestroy();
}
































