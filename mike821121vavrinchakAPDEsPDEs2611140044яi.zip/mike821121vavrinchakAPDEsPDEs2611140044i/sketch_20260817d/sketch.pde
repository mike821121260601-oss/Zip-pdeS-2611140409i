


// Mortal Combat 2D - APDE / Processing Android version
// Controls (on-screen buttons + optional keyboard)

Fighter p1, p2;
boolean gameOver = false;
int winner = 0;

// Virtual buttons
Button btnLeft1, btnRight1, btnJump1, btnPunch1, btnKick1;
Button btnLeft2, btnRight2, btnJump2, btnPunch2, btnKick2;

void setup() {
  fullScreen(P2D);






  orientation(LANDSCAPE);
  

      orientation(PORTRAIT);




  float ground = height * 0.75;
  
  p1 = new Fighter(width * 0.2, ground, color(0, 168, 255), 1);
  p2 = new Fighter(width * 0.7, ground, color(233, 69, 96), -1);
  
  // Player 1 buttons (left side)
  float btnSize = height * 0.12;
  float margin = 20;
  
  btnLeft1  = new Button(margin, height - btnSize*2 - margin*2, btnSize, btnSize, "←");
  btnRight1 = new Button(margin + btnSize + 10, height - btnSize*2 - margin*2, btnSize, btnSize, "→");
  btnJump1  = new Button(margin + btnSize*0.5, height - btnSize - margin, btnSize, btnSize, "↑");
  btnPunch1 = new Button(margin + btnSize*2 + 30, height - btnSize*2 - margin*2, btnSize, btnSize, "P");
  btnKick1  = new Button(margin + btnSize*3 + 40, height - btnSize*2 - margin*2, btnSize, btnSize, "K");
  
  // Player 2 buttons (right side)
  btnLeft2  = new Button(width - margin - btnSize*4 - 40, height - btnSize*2 - margin*2, btnSize, btnSize, "←");
  btnRight2 = new Button(width - margin - btnSize*3 - 30, height - btnSize*2 - margin*2, btnSize, btnSize, "→");
  btnJump2  = new Button(width - margin - btnSize*3.5 - 30, height - btnSize - margin, btnSize, btnSize, "↑");
  btnPunch2 = new Button(width - margin - btnSize*2 - 10, height - btnSize*2 - margin*2, btnSize, btnSize, "P");
  btnKick2  = new Button(width - margin - btnSize, height - btnSize*2 - margin*2, btnSize, btnSize, "K");
}

void draw() {
  background(20, 20, 40);
  
  // Arena floor
  fill(15, 50, 90);
  noStroke();
  rect(0, height * 0.75 + 80, width, height);
  
  stroke(233, 69, 96);
  strokeWeight(3);
  line(0, height * 0.75 + 80, width, height * 0.75 + 80);
  
  // Pillars
  fill(80, 50, 130);
  noStroke();
  rect(30, height * 0.3, 50, height * 0.5);
  rect(width - 80, height * 0.3, 50, height * 0.5);
  
  if (!gameOver) {
    // Read virtual buttons
    boolean p1Left  = btnLeft1.pressed;
    boolean p1Right = btnRight1.pressed;
    boolean p1Jump  = btnJump1.pressed;
    boolean p1Punch = btnPunch1.pressed;
    boolean p1Kick  = btnKick1.pressed;
    
    boolean p2Left  = btnLeft2.pressed;
    boolean p2Right = btnRight2.pressed;
    boolean p2Jump  = btnJump2.pressed;
    boolean p2Punch = btnPunch2.pressed;
    boolean p2Kick  = btnKick2.pressed;
    
    p1.update(p1Left, p1Right, p1Jump, p1Punch, p1Kick);
    p2.update(p2Left, p2Right, p2Jump, p2Punch, p2Kick);
    
    checkHits();
  }
  
  p1.display();
  p2.display();
  
  // Health bars
  drawHealthBar(30, 30, p1.health, color(0, 168, 255), "P1");
  drawHealthBar(width - 310, 30, p2.health, color(233, 69, 96), "P2");
  
  // Buttons
  btnLeft1.display();
  btnRight1.display();
  btnJump1.display();
  btnPunch1.display();
  btnKick1.display();
  
  btnLeft2.display();
  btnRight2.display();
  btnJump2.display();
  btnPunch2.display();
  btnKick2.display();
  
  if (gameOver) {
    textAlign(CENTER, CENTER);
    textSize(48);
    fill(255, 255, 0);
    String msg = (winner == 1) ? "PLAYER 1 WINS!\nFINISH HIM!" : "PLAYER 2 WINS!\nFINISH HIM!";
    text(msg, width/2, height/2);
    
    textSize(24);
    fill(200);
    text("Tap screen to restart", width/2, height/2 + 100);
  }
}

void drawHealthBar(float x, float y, float health, color c, String label) {
  fill(255);
  textAlign(LEFT, BOTTOM);
  textSize(18);
  text(label, x, y - 5);
  
  fill(40);
  stroke(255);
  strokeWeight(2);
  rect(x, y, 280, 22);
  
  fill(c);
  noStroke();
  rect(x, y, 280 * (health / 100.0), 22);
}

void checkHits() {
  // P1 attacks P2
  if (p1.isAttacking()) {
    Rect atk = p1.getAttackBox();
    if (atk != null && rectCollision(atk, p2.getBody())) {
      p2.takeDamage(p1.isKicking() ? 12 : 8);
    }
  }
  // P2 attacks P1
  if (p2.isAttacking()) {
    Rect atk = p2.getAttackBox();
    if (atk != null && rectCollision(atk, p1.getBody())) {
      p1.takeDamage(p2.isKicking() ? 12 : 8);
    }
  }
  
  if (p1.health <= 0) {
    gameOver = true;
    winner = 2;
  } else if (p2.health <= 0) {
    gameOver = true;
    winner = 1;
  }
}

boolean rectCollision(Rect a, Rect b) {
  return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
}

void mousePressed() {
  if (gameOver) {
    // Restart
    float ground = height * 0.75;
    p1 = new Fighter(width * 0.2, ground, color(0, 168, 255), 1);
    p2 = new Fighter(width * 0.7, ground, color(233, 69, 96), -1);
    gameOver = false;
    winner = 0;
    return;
  }
  
  btnLeft1.checkPress(mouseX, mouseY);
  btnRight1.checkPress(mouseX, mouseY);
  btnJump1.checkPress(mouseX, mouseY);
  btnPunch1.checkPress(mouseX, mouseY);
  btnKick1.checkPress(mouseX, mouseY);
  
  btnLeft2.checkPress(mouseX, mouseY);
  btnRight2.checkPress(mouseX, mouseY);
  btnJump2.checkPress(mouseX, mouseY);
  btnPunch2.checkPress(mouseX, mouseY);
  btnKick2.checkPress(mouseX, mouseY);
}

void mouseReleased() {
  btnLeft1.pressed = false;
  btnRight1.pressed = false;
  btnJump1.pressed = false;
  btnPunch1.pressed = false;
  btnKick1.pressed = false;
  
  btnLeft2.pressed = false;
  btnRight2.pressed = false;
  btnJump2.pressed = false;
  btnPunch2.pressed = false;
  btnKick2.pressed = false;
}

void mouseDragged() {
  // Keep buttons held while dragging
  mousePressed();
}

// ===================== Classes =====================

class Rect {
  float x, y, w, h;
  Rect(float x, float y, float w, float h) {
    this.x = x; this.y = y; this.w = w; this.h = h;
  }
}

class Button {
  float x, y, w, h;
  String label;
  boolean pressed = false;
  
  Button(float x, float y, float w, float h, String label) {
    this.x = x; this.y = y; this.w = w; this.h = h;
    this.label = label;
  }
  
  void checkPress(float mx, float my) {
    if (mx > x && mx < x + w && my > y && my < y + h) {
      pressed = true;
    }
  }
  
  void display() {
    if (pressed) fill(255, 200, 50);
    else fill(60, 60, 80, 200);
    stroke(255);
    strokeWeight(2);
    rect(x, y, w, h, 12);
    
    fill(255);
    textAlign(CENTER, CENTER);
    textSize(h * 0.4);
    text(label, x + w/2, y + h/2);
  }
}

class Fighter {
  float x, y;
  float w = 50;
  float h = 90;
  float vx = 0, vy = 0;
  color col;
  int facing;          // 1 = right, -1 = left
  float health = 100;
  boolean punching = false;
  boolean kicking = false;
  int attackTimer = 0;
  int hitCooldown = 0;
  boolean onGround = true;
  float groundY;
  
  Fighter(float x, float y, color col, int facing) {
    this.x = x;
    this.y = y;
    this.col = col;
    this.facing = facing;
    this.groundY = y;
  }
  
  void update(boolean left, boolean right, boolean jump, boolean punch, boolean kick) {
    vx = 0;
    if (left)  { vx = -6; facing = -1; }
    if (right) { vx =  6; facing =  1; }
    
    if (jump && onGround) {
      vy = -16;
      onGround = false;
    }
    
    if (attackTimer <= 0) {
      if (punch) {
        punching = true;
        kicking = false;
        attackTimer = 18;
      } else if (kick) {
        kicking = true;
        punching = false;
        attackTimer = 22;
      }
    }
    
    if (attackTimer > 0) {
      attackTimer--;
      if (attackTimer == 0) {
        punching = false;
        kicking = false;
      }
    }
    
    if (hitCooldown > 0) hitCooldown--;
    
    // Physics
    vy += 0.8;
    x += vx;
    y += vy;
    
    if (y >= groundY) {
      y = groundY;
      vy = 0;
      onGround = true;
    }
    
    // Walls
    if (x < 40) x = 40;
    if (x > width - w - 40) x = width - w - 40;
  }
  
  boolean isAttacking() {
    return (punching || kicking) && attackTimer > 8;
  }
  
  boolean isKicking() {
    return kicking;
  }
  
  Rect getAttackBox() {
    if (!punching && !kicking) return null;
    float range = kicking ? 70 : 55;
    float height = kicking ? 40 : 30;
    float yOff = kicking ? 40 : 25;
    float ax = (facing == 1) ? x + w : x - range;
    return new Rect(ax, y + yOff, range, height);
  }
  
  Rect getBody() {
    return new Rect(x, y, w, h);
  }
  
  void takeDamage(float amount) {
    if (hitCooldown > 0) return;
    health = max(0, health - amount);
    hitCooldown = 25;
    vx = facing * -10;
    vy = -5;
    onGround = false;
  }
  
  void display() {
    // Body
    fill(col);
    noStroke();
    rect(x, y, w, h);
    
    // Head
    fill(255, 219, 172);
    rect(x + 10, y - 28, 30, 30);
    
    // Eyes
    fill(0);
    if (facing == 1) {
      rect(x + 28, y - 18, 6, 6);
    } else {
      rect(x + 16, y - 18, 6, 6);
    }
    
    // Attack visual
    if (punching || kicking) {
      Rect box = getAttackBox();
      if (box != null) {
        if (kicking) fill(255, 100, 0, 180);
        else fill(255, 255, 0, 180);
        rect(box.x, box.y, box.w, box.h);
      }
    }
    
    // Simple legs when in air
    if (!onGround) {
      fill(col);
      rect(x + 5, y + h, 15, 20);
      rect(x + 30, y + h, 15, 20);
    }
  }
}



























