















import java.io.*;

Process stockfishProcess;
BufferedReader reader;
BufferedWriter writer;
String internalPath;
String responseText = "Натисніть на екран,\nщоб викликати Stockfish";

void setup() {
  fullScreen();
  orientation(PORTRAIT);
  

//InputStream in = getContext().getAssets().open("stockfish");



  // Шлях до внутрішньої пам'яті нашого застосунку на Android
 //new/// internalPath = getFilesDir().getAbsolutePath() + "/stockfish";
  internalPath = getContext().getFilesDir().getAbsolutePath() + "/stockfish";

  // Копіюємо Stockfish з папки data (assets) у систему та даємо права
  prepareStockfish();
  
  // Запуск рушія
  try {
    ProcessBuilder pb = new ProcessBuilder(internalPath);
    stockfishProcess = pb.start();
    
    reader = new BufferedReader(new InputStreamReader(stockfishProcess.getInputStream()));
    writer = new BufferedWriter(new OutputStreamWriter(stockfishProcess.getOutputStream()));
    
    sendUCI("uci");
  } catch (Exception e) {
    responseText = "Помилка запуску!\nПеревір��е архітектуру файлу.";
    e.printStackTrace();
  }
}

void draw() {
  background(40);
  fill(255);
  textAlign(CENTER, CENTER);
  textSize(48); // Більший шрифт для екрана смартфона
  text(responseText, width/2, height/2);
}

void mousePressed() {
  responseText = "Аналіз...";
  
  // Надсилаємо тестову позицію
  sendUCI("position startpos moves e2e4");
  sendUCI("go movetime 1000"); // Думати 1 секунду
  
  // Зчитуємо хід
  getBestMove();
}

void sendUCI(String command) {
  try {
    writer.write(command + "\n");
    writer.flush();
  } catch (Exception e) {
    e.printStackTrace();
  }
}

void getBestMove() {
  // Запускаємо окремий потік, щоб інтерфейс Android не зависав під час очікування відповіді
  thread("readBestMove");
}

void readBestMove() {
  try {
    String line;
    while ((line = reader.readLine()) != null) {
      if (line.startsWith("bestmove")) {
        String[] tokens = split(line, ' ');
        responseText = "Рекомендація Stockfish:\n" + tokens[1];
        break;
      }
    }
  } catch (Exception e) {
    e.printStackTrace();
  }
}

// Функція копіювання бінарника в пам'ять Android та видачі прав виконання
void prepareStockfish() {
  try {
    File outFile = new File(internalPath);
    
    // Якщо файлу ще немає у внутрішній пам'яті — копіюємо
    if (!outFile.exists()) {
   ///new///   InputStream in = activity.getAssets().open("stockfish");
    InputStream in = getContext().getAssets().open("stockfish");



  OutputStream out = new FileOutputStream(outFile);
      byte[] buffer = new byte[1024];
      int read;
      while ((read = in.read(buffer)) != -1) {
        out.write(buffer, 0, read);
      }
      in.close();
      out.flush();
      out.close();
    }
    
    // НАДВАЖЛИВО ДЛЯ ANDROID: Робимо файл виконуваним (аналог chmod +x)
    outFile.setExecutable(true, true);
    
  } catch (Exception e) {
    e.printStackTrace();
  }
}

void exit() {
  if (stockfishProcess != null) {
    stockfishProcess.destroy();
  }
  super.exit();
}










/*
import java.io.*;

Process stockfishProcess;
BufferedReader reader;
BufferedWriter writer;

void setup() {
  size(400, 400);
  background(50);
  fill(255);
  textAlign(CENTER, CENTER);
  textSize(16);
  text("Натисніть ПРОБІЛ, щоб\nзапитати хід у Stockfish", width/2, height/2);

  // 1. Вкажіть точний шлях до завантаженого файлу Stockfish на вашому ПК
  // Наприклад: "C:\\chess\\stockfish.exe" або просто "stockfish" якщо він у системних зміних
  String stockfishPath = "C:\\path\\to\\your\\stockfish.exe"; 

  try {
    // 2. Запуск процесу Stockfish
    ProcessBuilder pb = new ProcessBuilder(stockfishPath);
    stockfishProcess = pb.start();
    
    // 3. Налаштув��ння потоків введення/виведення (I/O)
    reader = new BufferedReader(new InputStreamReader(stockfishProcess.getInputStream()));
    writer = new BufferedWriter(new OutputStreamWriter(stockfishProcess.getOutputStream()));
    
    // 4. Ініціалізація UCI протоколу
    sendUCI("uci");
    
  } catch (Exception e) {
    println("Помилка запуску Stockfish. Перевірте шлях до файлу!");
    e.printStackTrace();
  }
}

void draw() {
  // Тут зазвичай малюється ваша шахівниця
}

void keyPressed() {
  if (key == ' ') {
    println("\n--- Запит ходу у Stockfish ---");
    
    // Задаємо позицію (наприклад, початкова + перший хід білих e2e4)
    sendUCI("position startpos moves e2e4");
    
    // Наказуємо шукати найкращий хід протягом 1000 мілісекунд (1 секунда)
    sendUCI("go movetime 1000");
    
    // Читаємо відповідь, поки рушій не видасть "bestmove"
    getBestMove();
  }
}

// Функція для відправки команд у Stockfish
void sendUCI(String command) {
  try {
    writer.write(command + "\n");
    writer.flush();
  } catch (Exception e) {
    e.printStackTrace();
  }
}

// Функція для зчитування та пошуку найкращого ходу
void getBestMove() {
  try {
    String line;
    // Stockfish аналізує і випльовує багато рядків (info depth...), чекаємо на фінальний рядок
    while ((line = reader.readLine()) != null) {
      println(line); // Виводимо лог аналізу в консоль Processing
      
      if (line.startsWith("bestmove")) {
        // Рядок виглядає як "bestmove e7e5 ponder g1f3"
        String[] tokens = split(line, ' ');
        String bestMove = tokens[1]; 
        
        println("\n⭐ РЕКОМЕНД��ЦІЯ СТОКФІША: " + bestMove);
        break; // Знайшли хід — виходимо з циклу
      }
    }
  } catch (Exception e) {
    e.printStackTrace();
  }
}

// Обов'язково закриваємо процес при виході з програми
void exit() {
  if (stockfishProcess != null) {
    stockfishProcess.destroy();
  }
  super.exit();
}

//PPPCCC/////

*/













