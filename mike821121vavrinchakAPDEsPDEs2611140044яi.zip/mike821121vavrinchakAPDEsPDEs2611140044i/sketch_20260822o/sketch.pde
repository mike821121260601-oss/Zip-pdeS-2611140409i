

// Realistic 3D Skeleton – matching your hand-drawn pose
// APDE 0.5.3  |  P3D

float rotY = 0;
float rotX = -0.3;

void setup() {
  size(displayWidth, displayHeight, P3D);
  orientation(PORTRAIT);
  smooth(8);
}

void draw() {
  background(12, 14, 20);
  
  // Soft ambient + directional light for realistic look
  ambientLight(40, 45, 55);
  directionalLight(220, 220, 230, 0.4, 0.6, -1);
  directionalLight(80, 90, 110, -0.8, 0.3, 0.5);
  
  translate(width/2, height/2 + 80, 0);
  rotateX(rotX);
  rotateY(rotY);
  scale(2.8);                     // overall size
  
  // Auto-rotate slowly
  rotY += 0.008;
  
  // Optional: manual control with touch / mouse
  if (mousePressed) {
    rotY += (mouseX - pmouseX) * 0.01;
    rotX += (mouseY - pmouseY) * 0.01;
  }
  
  drawSkeleton();
}

void drawSkeleton() {
  // Joint radius
  float jr = 4.2;
  
  // ========== JOINT POSITIONS (matching your drawing) ==========
  // All coordinates relative to pelvis center
  
  // Head & neck
  PVector head      = new PVector(  0, -118,  8);
  PVector neck      = new PVector(  0, -98,   5);
  
  // Shoulders
  PVector shoulderL = new PVector(-28, -88,  12);
  PVector shoulderR = new PVector( 28, -88,  12);
  
  // Arms – left arm raised / dynamic
  PVector elbowL    = new PVector(-58, -72,  35);
  PVector wristL    = new PVector(-78, -48,  52);
  PVector handL     = new PVector(-88, -32,  58);
  
  // Right arm extended downward-right
  PVector elbowR    = new PVector( 62, -55,  18);
  PVector wristR    = new PVector( 95, -28,  25);
  PVector handR     = new PVector(112, -12,  28);
  
  // Spine / torso
  PVector chest     = new PVector(  0, -70,   6);
  PVector midSpine  = new PVector(  0, -42,   2);
  PVector pelvis    = new PVector(  0,   0,   0);
  
  // Hips
  PVector hipL      = new PVector(-18,   5,   4);
  PVector hipR      = new PVector( 18,   5,   4);
  
  // Left leg (more bent / forward)
  PVector kneeL     = new PVector(-32,  48,  28);
  PVector ankleL    = new PVector(-28,  95,  12);
  PVector footL     = new PVector(-35, 108,  22);
  
  // Right leg (straighter, slightly back)
  PVector kneeR     = new PVector( 25,  52, -8);
  PVector ankleR    = new PVector( 22, 102, -5);
  PVector footR     = new PVector( 18, 115,  5);
  
  // Extra detail joints (matching the many small circles in your drawing)
  PVector clavicleL = new PVector(-14, -92,  10);
  PVector clavicleR = new PVector( 14, -92,  10);
  PVector sternum   = new PVector(  0, -78,   8);
  
  // ========== DRAW BONES ==========
  stroke(210, 215, 225);
  strokeWeight(2.8);
  
  // Head to neck
  bone(head, neck);
  
  // Neck / clavicles / shoulders
  bone(neck, clavicleL);
  bone(neck, clavicleR);
  bone(clavicleL, shoulderL);
  bone(clavicleR, shoulderR);
  bone(shoulderL, shoulderR);
  
  // Spine
  bone(neck, sternum);
  bone(sternum, chest);
  bone(chest, midSpine);
  bone(midSpine, pelvis);
  
  // Left arm
  bone(shoulderL, elbowL);
  bone(elbowL, wristL);
  bone(wristL, handL);
  
  // Right arm
  bone(shoulderR, elbowR);
  bone(elbowR, wristR);
  bone(wristR, handR);
  
  // Hips
  bone(pelvis, hipL);
  bone(pelvis, hipR);
  bone(hipL, hipR);
  
  // Left leg
  bone(hipL, kneeL);
  bone(kneeL, ankleL);
  bone(ankleL, footL);
  
  // Right leg
  bone(hipR, kneeR);
  bone(kneeR, ankleR);
  bone(ankleR, footR);
  
  // ========== DRAW JOINTS (spheres) ==========
  noStroke();
  fill(235, 240, 250);
  
  joint(head, jr * 1.6);
  joint(neck, jr * 0.9);
  joint(clavicleL, jr * 0.7);
  joint(clavicleR, jr * 0.7);
  joint(shoulderL, jr * 1.1);
  joint(shoulderR, jr * 1.1);
  joint(elbowL, jr);
  joint(elbowR, jr);
  joint(wristL, jr * 0.85);
  joint(wristR, jr * 0.85);
  joint(handL, jr * 0.7);
  joint(handR, jr * 0.7);
  joint(sternum, jr * 0.8);
  joint(chest, jr * 0.9);
  joint(midSpine, jr * 0.85);
  joint(pelvis, jr * 1.15);
  joint(hipL, jr * 1.05);
  joint(hipR, jr * 1.05);
  joint(kneeL, jr * 1.05);
  joint(kneeR, jr * 1.05);
  joint(ankleL, jr * 0.9);
  joint(ankleR, jr * 0.9);
  joint(footL, jr * 0.75);
  joint(footR, jr * 0.75);
  
  // Small head detail (like the tiny circles on top of your drawing)
  pushMatrix();
  translate(head.x, head.y - 8, head.z);
  sphere(jr * 0.55);
  popMatrix();
}

void bone(PVector a, PVector b) {
  line(a.x, a.y, a.z, b.x, b.y, b.z);
}

void joint(PVector p, float r) {
  pushMatrix();
  translate(p.x, p.y, p.z);
  sphere(r);
  popMatrix();
}
























