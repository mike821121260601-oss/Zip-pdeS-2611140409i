









/*
 ============================================================
 CHESS ANALYZER V2
 APDE 0.5.3
 ONE PDE FILE

 Chess board
 FEN
 BEST MOVE
 Alpha-Beta search
 Material + positional evaluation
 Depth 1..4
 Undo
 New game
 Transparent background

 IMPORTANT:
 This is a small local chess engine.
 It is NOT Stockfish itself.
 ============================================================
*/

import android.graphics.*;
import android.view.*;
import android.content.*;


// ============================================================
// BOARD
// ============================================================

char[][] board = new char[8][8];

boolean whiteTurn = true;

int selectedX = -1;
int selectedY = -1;

int oldX = -1;
int oldY = -1;

String bestMove = "-";
int bestScore = 0;

int searchDepth = 3;

boolean thinking = false;

ArrayList<Position> history =
  new ArrayList<Position>();


// ============================================================
// SETUP
// ============================================================

void setup() {

  fullScreen();

  orientation(LANDSCAPE);

  // Transparent
  background(0, 0);

  setStartPosition();

}


// ============================================================
// DRAW
// ============================================================

void draw() {

  clear();

  drawBoard();

  drawPieces();

  drawSelection();

  drawControls();

  drawInfo();

}


// ============================================================
// START POSITION
// ============================================================

void setStartPosition() {

  setFEN(
    "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
  );

}


// ============================================================
// FEN
// ============================================================

void setFEN(String fen) {

  String[] p = split(fen, ' ');

  String[] rows = split(p[0], '/');

  for (int y = 0; y < 8; y++) {

    int x = 0;

    for (int i = 0; i < rows[y].length(); i++) {

      char c = rows[y].charAt(i);

      if (c >= '1' && c <= '8') {

        int n = c - '0';

        for (int k = 0; k < n; k++) {
          board[y][x] = '.';
          x++;
        }

      } else {

        board[y][x] = c;
        x++;
      }
    }
  }

  if (p.length > 1) {
    whiteTurn = p[1].equals("w");
  }

  selectedX = -1;
  selectedY = -1;

  bestMove = "-";
  bestScore = 0;
}


// ============================================================
// FEN OUTPUT
// ============================================================

String getFEN() {

  String s = "";

  for (int y = 0; y < 8; y++) {

    int empty = 0;

    for (int x = 0; x < 8; x++) {

      char c = board[y][x];

      if (c == '.') {

        empty++;

      } else {

        if (empty > 0) {
          s += empty;
          empty = 0;
        }

        s += c;
      }
    }

    if (empty > 0)
      s += empty;

    if (y != 7)
      s += "/";
  }

  s += whiteTurn ? " w " : " b ";

  s += "- - 0 1";

  return s;
}


// ============================================================
// BOARD DRAW
// ============================================================

void drawBoard() {

  float size =
    min(width * 0.72,
        height * 0.88);

  float bx =
    (width - size) / 2.0;

  float by =
    35;

  float sq =
    size / 8.0;

  noStroke();

  for (int y = 0; y < 8; y++) {

    for (int x = 0; x < 8; x++) {

      if ((x+y)%2 == 0)
        fill(235);
      else
        fill(90);

      rect(
        bx + x*sq,
        by + y*sq,
        sq,
        sq
      );
    }
  }

  stroke(0);
  noFill();

  rect(
    bx,
    by,
    size,
    size
  );
}


// ============================================================
// PIECES
// ============================================================

void drawPieces() {

  float size =
    min(width * 0.72,
        height * 0.88);

  float bx =
    (width - size) / 2.0;

  float by = 35;

  float sq = size / 8.0;

  textAlign(CENTER, CENTER);

  for (int y = 0; y < 8; y++) {

    for (int x = 0; x < 8; x++) {

      char p = board[y][x];

      if (p == '.')
        continue;

      if (Character.isUpperCase(p))
        fill(250);
      else
        fill(20);

      stroke(0);
      strokeWeight(2);

      textSize(sq * 0.68);

      text(
        pieceSymbol(p),
        bx + x*sq + sq/2,
        by + y*sq + sq/2
      );
    }
  }
}


// ============================================================
// PIECE SYMBOLS
// ============================================================

String pieceSymbol(char p) {

  if (p == 'K') return "K";
  if (p == 'Q') return "Q";
  if (p == 'R') return "R";
  if (p == 'B') return "B";
  if (p == 'N') return "N";
  if (p == 'P') return "P";

  if (p == 'k') return "K";
  if (p == 'q') return "Q";
  if (p == 'r') return "R";
  if (p == 'b') return "B";
  if (p == 'n') return "N";
  if (p == 'p') return "P";

  return "";
}


// ============================================================
// SELECTION
// ============================================================

void drawSelection() {

  if (selectedX < 0)
    return;

  float size =
    min(width * 0.72,
        height * 0.88);

  float bx =
    (width - size) / 2.0;

  float by = 35;

  float sq = size / 8.0;

  noFill();
  stroke(0,255,0);
  strokeWeight(5);

  rect(
    bx + selectedX*sq,
    by + selectedY*sq,
    sq,
    sq
  );

  strokeWeight(1);
}


// ============================================================
// CONTROLS
// ============================================================

void drawControls() {

  int x = 10;
  int y = 10;

  button(x,y,90,45,"NEW");

  button(x+100,y,110,45,"UNDO");

  button(
    x+220,
    y,
    160,
    45,
    "BEST MOVE"
  );

  button(
    x+390,
    y,
    70,
    45,
    "D-"
  );

  button(
    x+470,
    y,
    70,
    45,
    "D+"
  );
}


void button(
  int x,
  int y,
  int w,
  int h,
  String text
) {

  noStroke();

  fill(25,25,25,220);

  rect(
    x,y,w,h,
    8
  );

  fill(255);

  textAlign(
    CENTER,
    CENTER
  );

  textSize(16);

  text(
    text,
    x+w/2,
    y+h/2
  );
}


// ============================================================
// INFO
// ============================================================

void drawInfo() {

  fill(0,0,0,190);

  rect(
    5,
    height-90,
    width-10,
    85,
    8
  );

  fill(255);

  textAlign(
    LEFT,
    TOP
  );

  textSize(16);

  String side =
    whiteTurn ? "WHITE" : "BLACK";

  text(
    "TURN: " + side,
    15,
    height-82
  );

  text(
    "DEPTH: " + searchDepth,
    15,
    height-60
  );

  text(
    "BEST: " + bestMove,
    150,
    height-82
  );

  text(
    "SCORE: " +
    nf(bestScore/100.0,1,2),
    150,
    height-60
  );

  textSize(10);

  String f = getFEN();

  text(
    "FEN: " + f,
    300,
    height-70
  );
}


// ============================================================
// TOUCH
// ============================================================

void mousePressed() {

  float size =
    min(width * 0.72,
        height * 0.88);

  float bx =
    (width-size)/2.0;

  float by = 35;

  float sq = size/8.0;

  // ------------------------------------------
  // buttons
  // ------------------------------------------

  if (mouseY >= 10 &&
      mouseY <= 55) {

    if (mouseX >= 10 &&
        mouseX <= 100) {

      setStartPosition();
      return;
    }

    if (mouseX >= 110 &&
        mouseX <= 220) {

      undoMove();
      return;
    }

    if (mouseX >= 230 &&
        mouseX <= 390) {

      findBestMove();
      return;
    }

    if (mouseX >= 400 &&
        mouseX <= 460) {

      searchDepth--;

      if (searchDepth < 1)
        searchDepth = 1;

      return;
    }

    if (mouseX >= 480 &&
        mouseX <= 550) {

      searchDepth++;

      if (searchDepth > 4)
        searchDepth = 4;

      return;
    }
  }

  // ------------------------------------------
  // board
  // ------------------------------------------

  if (mouseX < bx ||
      mouseX > bx+size ||
      mouseY < by ||
      mouseY > by+size)
    return;

  int x =
    int((mouseX-bx)/sq);

  int y =
    int((mouseY-by)/sq);

  if (x < 0 || x > 7 ||
      y < 0 || y > 7)
    return;

  char p =
    board[y][x];

  // select
  if (selectedX < 0) {

    if (p != '.' &&
        sameSide(p,whiteTurn)) {

      selectedX = x;
      selectedY = y;
    }

    return;
  }

  // same square
  if (selectedX == x &&
      selectedY == y) {

    selectedX = -1;
    selectedY = -1;

    return;
  }

  // try move
  ArrayList<Move> moves =
    generateLegalMoves(
      board,
      whiteTurn
    );

  Move chosen = null;

  for (Move m : moves) {

    if (m.x1 == selectedX &&
        m.y1 == selectedY &&
        m.x2 == x &&
        m.y2 == y) {

      chosen = m;
      break;
    }
  }

  if (chosen != null) {

    savePosition();

    makeMove(
      board,
      chosen
    );

    whiteTurn =
      !whiteTurn;

    bestMove = "-";

  } else {

    if (p != '.' &&
        sameSide(p,whiteTurn)) {

      selectedX = x;
      selectedY = y;

      return;
    }
  }

  selectedX = -1;
  selectedY = -1;
}


// ============================================================
// SIDE
// ============================================================

boolean sameSide(
  char p,
  boolean white
) {

  if (white)
    return Character.isUpperCase(p);

  return Character.isLowerCase(p);
}


// ============================================================
// SAVE
// ============================================================

void savePosition() {

  Position p =
    new Position();

  for (int y=0;y<8;y++)
    for (int x=0;x<8;x++)
      p.b[y][x]=board[y][x];

  p.white = whiteTurn;

  history.add(p);

  if (history.size() > 50)
    history.remove(0);
}


// ============================================================
// UNDO
// ============================================================

void undoMove() {

  if (history.size()==0)
    return;

  Position p =
    history.remove(
      history.size()-1
    );

  for (int y=0;y<8;y++)
    for (int x=0;x<8;x++)
      board[y][x]=p.b[y][x];

  whiteTurn = p.white;

  bestMove = "-";
}


// ============================================================
// BEST MOVE
// ============================================================

void findBestMove() {

  if (thinking)
    return;

  thinking = true;

  ArrayList<Move> moves =
    generateLegalMoves(
      board,
      whiteTurn
    );

  if (moves.size()==0) {
    thinking=false;
    return;
  }

  int best =
    whiteTurn ?
    -10000000 :
    10000000;

  Move bestM =
    moves.get(0);

  for (Move m : moves) {

    char[][] copy =
      copyBoard(board);

    makeMove(
      copy,
      m
    );

    int score =
      alphaBeta(
        copy,
        !whiteTurn,
        searchDepth-1,
        -10000000,
        10000000
      );

    if (whiteTurn) {

      if (score > best) {
        best = score;
        bestM = m;
      }

    } else {

      if (score < best) {
        best = score;
        bestM = m;
      }
    }
  }

  bestScore = best;

  bestMove =
    moveString(bestM);

  thinking=false;
}


// ============================================================
// ALPHA BETA
// ============================================================

int alphaBeta(
  char[][] b,
  boolean side,
  int depth,
  int alpha,
  int beta
) {

  if (depth <= 0)
    return evaluate(b);

  ArrayList<Move> moves =
    generateLegalMoves(
      b,
      side
    );

  if (moves.size()==0) {

    if (kingInCheck(b,side))
      return side ?
        -900000 + depth :
         900000 - depth;

    return 0;
  }

  if (side) {

    int best =
      -10000000;

    for (Move m : moves) {

      char[][] n =
        copyBoard(b);

      makeMove(n,m);

      int v =
        alphaBeta(
          n,
          false,
          depth-1,
          alpha,
          beta
        );

      if (v > best)
        best = v;

      if (best > alpha)
        alpha = best;

      if (beta <= alpha)
        break;
    }

    return best;

  } else {

    int best =
      10000000;

    for (Move m : moves) {

      char[][] n =
        copyBoard(b);

      makeMove(n,m);

      int v =
        alphaBeta(
          n,
          true,
          depth-1,
          alpha,
          beta
        );

      if (v < best)
        best = v;

      if (best < beta)
        beta = best;

      if (beta <= alpha)
        break;
    }

    return best;
  }
}


// ============================================================
// EVALUATION
// ============================================================

int evaluate(char[][] b) {

  int score=0;

  for (int y=0;y<8;y++) {

    for (int x=0;x<8;x++) {

      char p=b[y][x];

      int v=pieceValue(p);

      if (Character.isUpperCase(p))
        score += v;
      else
        score -= v;

      // small positional bonus
      if (p=='P')
        score += (6-y)*4;

      if (p=='p')
        score -= (y-1)*4;

      // center control
      if (x>=2 && x<=5 &&
          y>=2 && y<=5) {

        if (Character.isUpperCase(p))
          score += 2;
        else
          score -= 2;
      }
    }
  }

  return score;
}


int pieceValue(char p) {

  char q =
    Character.toLowerCase(p);

  if (q=='p') return 100;
  if (q=='n') return 320;
  if (q=='b') return 330;
  if (q=='r') return 500;
  if (q=='q') return 900;
  if (q=='k') return 20000;

  return 0;
}


// ============================================================
// MOVE GENERATION
// ============================================================

ArrayList<Move>
generateLegalMoves(
  char[][] b,
  boolean side
) {

  ArrayList<Move> all =
    new ArrayList<Move>();

  for (int y=0;y<8;y++) {

    for (int x=0;x<8;x++) {

      char p=b[y][x];

      if (p=='.')
        continue;

      if (!sameSide(p,side))
        continue;

      generatePieceMoves(
        b,x,y,p,all
      );
    }
  }

  ArrayList<Move> legal =
    new ArrayList<Move>();

  for (Move m : all) {

    char[][] n =
      copyBoard(b);

    makeMove(n,m);

    if (!kingInCheck(n,side))
      legal.add(m);
  }

  return legal;
}


// ============================================================
// PIECE MOVES
// ============================================================

void generatePieceMoves(
  char[][] b,
  int x,
  int y,
  char p,
  ArrayList<Move> out
) {

  char q =
    Character.toLowerCase(p);

  boolean white =
    Character.isUpperCase(p);

  if (q=='p') {

    int dir =
      white ? -1 : 1;

    int start =
      white ? 6 : 1;

    int ny=y+dir;

    if (inside(x,ny) &&
        b[ny][x]=='.') {

      out.add(
        new Move(x,y,x,ny)
      );

      if (y==start &&
          b[y+2*dir][x]=='.') {

        out.add(
          new Move(
            x,y,
            x,y+2*dir
          )
        );
      }
    }

    for (int dx=-1;dx<=1;dx+=2) {

      int nx=x+dx;

      if (!inside(nx,ny))
        continue;

      if (b[ny][nx]!='.' &&
          Character.isUpperCase(
            b[ny][nx]
          ) != white) {

        out.add(
          new Move(
            x,y,nx,ny
          )
        );
      }
    }

    return;
  }


  if (q=='n') {

    int[][] d = {
      {1,2},{2,1},
      {-1,2},{-2,1},
      {1,-2},{2,-1},
      {-1,-2},{-2,-1}
    };

    for (int i=0;i<8;i++) {

      addIfLegalSquare(
        b,x,y,
        x+d[i][0],
        y+d[i][1],
        white,
        out
      );
    }

    return;
  }


  if (q=='k') {

    for (int dx=-1;dx<=1;dx++) {

      for (int dy=-1;dy<=1;dy++) {

        if (dx==0 && dy==0)
          continue;

        addIfLegalSquare(
          b,x,y,
          x+dx,y+dy,
          white,
          out
        );
      }
    }

    return;
  }


  if (q=='b' ||
      q=='r' ||
      q=='q') {

    if (q=='b' ||
        q=='q') {

      slide(
        b,x,y,
        1,1,white,out
      );

      slide(
        b,x,y,
        1,-1,white,out
      );

      slide(
        b,x,y,
        -1,1,white,out
      );

      slide(
        b,x,y,
        -1,-1,white,out
      );
    }

    if (q=='r' ||
        q=='q') {

      slide(
        b,x,y,
        1,0,white,out
      );

      slide(
        b,x,y,
        -1,0,white,out
      );

      slide(
        b,x,y,
        0,1,white,out
      );

      slide(
        b,x,y,
        0,-1,white,out
      );
    }
  }
}


// ============================================================
// SLIDE
// ============================================================

void slide(
  char[][] b,
  int x,
  int y,
  int dx,
  int dy,
  boolean white,
  ArrayList<Move> out
) {

  int nx=x+dx;
  int ny=y+dy;

  while (inside(nx,ny)) {

    char p=b[ny][nx];

    if (p=='.') {

      out.add(
        new Move(
          x,y,nx,ny
        )
      );

    } else {

      if (
        Character.isUpperCase(p)
        != white
      ) {

        out.add(
          new Move(
            x,y,nx,ny
          )
        );
      }

      break;
    }

    nx+=dx;
    ny+=dy;
  }
}


// ============================================================
// ADD SQUARE
// ============================================================

void addIfLegalSquare(
  char[][] b,
  int x,
  int y,
  int nx,
  int ny,
  boolean white,
  ArrayList<Move> out
) {

  if (!inside(nx,ny))
    return;

  char p=b[ny][nx];

  if (p=='.' ||
      Character.isUpperCase(p)
      != white) {

    out.add(
      new Move(
        x,y,nx,ny
      )
    );
  }
}


// ============================================================
// MAKE MOVE
// ============================================================

void makeMove(
  char[][] b,
  Move m
) {

  char p =
    b[m.y1][m.x1];

  b[m.y2][m.x2] = p;

  b[m.y1][m.x1] = '.';

  // automatic queen promotion
  if (p=='P' &&
      m.y2==0)

    b[m.y2][m.x2]='Q';

  if (p=='p' &&
      m.y2==7)

    b[m.y2][m.x2]='q';
}


// ============================================================
// CHECK
// ============================================================

boolean kingInCheck(
  char[][] b,
  boolean white
) {

  int kx=-1;
  int ky=-1;

  char king =
    white ? 'K' : 'k';

  for (int y=0;y<8;y++)
    for (int x=0;x<8;x++)
      if (b[y][x]==king) {
        kx=x;
        ky=y;
      }

  if (kx<0)
    return true;

  return squareAttacked(
    b,
    kx,
    ky,
    !white
  );
}


// ============================================================
// ATTACKED
// ============================================================

boolean squareAttacked(
  char[][] b,
  int tx,
  int ty,
  boolean byWhite
) {

  for (int y=0;y<8;y++) {

    for (int x=0;x<8;x++) {

      char p=b[y][x];

      if (p=='.')
        continue;

      if (Character.isUpperCase(p)
          != byWhite)
        continue;

      char q =
        Character.toLowerCase(p);

      if (q=='p') {

        int dir =
          byWhite ? -1 : 1;

        if (ty==y+dir &&
            abs(tx-x)==1)
          return true;
      }

      else if (q=='n') {

        int dx=abs(tx-x);
        int dy=abs(ty-y);

        if ((dx==1 && dy==2) ||
            (dx==2 && dy==1))
          return true;
      }

      else if (q=='k') {

        if (max(
          abs(tx-x),
          abs(ty-y)
        )==1)
          return true;
      }

      else {

        int dx =
          Integer.signum(tx-x);

        int dy =
          Integer.signum(ty-y);

        boolean diagonal =
          abs(tx-x)==abs(ty-y);

        boolean straight =
          tx==x || ty==y;

        boolean ok=false;

        if (q=='b')
          ok=diagonal;

        if (q=='r')
          ok=straight;

        if (q=='q')
          ok=diagonal || straight;

        if (ok) {

          int cx=x+dx;
          int cy=y+dy;

          boolean clear=true;

          while (cx!=tx ||
                 cy!=ty) {

            if (b[cy][cx]!='.') {
              clear=false;
              break;
            }

            cx+=dx;
            cy+=dy;
          }

          if (clear)
            return true;
        }
      }
    }
  }

  return false;
}


// ============================================================
// COPY BOARD
// ============================================================

char[][] copyBoard(
  char[][] b
) {

  char[][] n =
    new char[8][8];

  for (int y=0;y<8;y++)
    for (int x=0;x<8;x++)
      n[y][x]=b[y][x];

  return n;
}


// ============================================================
// INSIDE
// ============================================================

boolean inside(
  int x,
  int y
) {

  return
    x>=0 &&
    x<8 &&
    y>=0 &&
    y<8;
}


// ============================================================
// MOVE STRING
// ============================================================

String moveString(
  Move m
) {

  if (m==null)
    return "-";

  return
    squareName(m.x1,m.y1)
    +
    squareName(m.x2,m.y2);
}


String squareName(
  int x,
  int y
) {

  char file =
    (char)('a'+x);

  char rank =
    (char)('8'-y);

  return ""+file+rank;
}


// ============================================================
// MOVE CLASS
// ============================================================

class Move {

  int x1,y1;
  int x2,y2;

  Move(
    int a,
    int b,
    int c,
    int d
  ) {

    x1=a;
    y1=b;
    x2=c;
    y2=d;
  }
}


// ============================================================
// POSITION CLASS
// ============================================================

class Position {

  char[][] b =
    new char[8][8];

  boolean white;
}


// ============================================================
// OPTIONAL FEN EXAMPLES
// ============================================================

/*

  Starting position:

  setFEN(
  "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w - - 0 1"
  );


  Example position:

  setFEN(
  "r1bqk2r/pppp1ppp/2n2n2/8/2B1P3/2N2N2/PPPP1PPP/R1BQK2R w - - 0 1"
  );

*/


// ============================================================
// END
// ============================================================























