











/*

Here is an APDE / Processing Java example with a dark yellow background, 20 red spheres, 20 blue spheres, 4 white spheres, random positions, and moving lights.



*/




int N = 44;

float[] x = new float[N];
float[] y = new float[N];
float[] z = new float[N];

int[] type = new int[N];

float R;

void setup() {
  fullScreen(P3D);






  R = width * height / 40.0 / 40.0 * 2.0/80;









  // 20 red
  for (int i = 0; i < 20; i++) type[i] = 0;

  // 20 blue
  for (int i = 20; i < 40; i++) type[i] = 1;

  // 4 white
  for (int i = 40; i < 44; i++) type[i] = 2;

  // Random positions
  for (int i = 0; i < N; i++) {
    x[i] = random(-width / 2*0, width / 2*2);
    y[i] = random(-height / 2*0, height / 2*2);
    z[i] = random(-400, 400)*0;
  }

  noStroke();
}

void draw() {
  background(75, 75, 0);




/*
  // Camera
  camera(
    0, 0, 700,
    0, 0, 0,
    0, 1, 0
  );

*/





  // Moving lights
  float t = millis() * 0.002;

  float lx1 = cos(t) * 500;
  float ly1 = sin(t * 1.3) * 400;
  float lz1 = 300;

  float lx2 = sin(t * 0.7) * 500;
  float ly2 = cos(t) * 400;
  float lz2 = -300;

  pointLight(255, 180, 180, lx1, ly1, lz1);
  pointLight(100, 150, 255, lx2, ly2, lz2);

  // Draw spheres
  for (int i = 0; i < N; i++) {

    pushMatrix();

    translate(x[i], y[i], z[i]);

    if (type[i] == 0) {
      // RED
      fill(255, 0, 0);
    }
    else if (type[i] == 1) {
      // BLUE
      fill(0, 80, 255);
    }
    else {
      // WHITE
      fill(255);
    }

    sphere(R);

    popMatrix();
  }
}


/*
Result: 44 3D spheres are randomly distributed on the screen, with 20 red + 20 blue + 4 white, and two colored lights continuously moving around them.



*/











