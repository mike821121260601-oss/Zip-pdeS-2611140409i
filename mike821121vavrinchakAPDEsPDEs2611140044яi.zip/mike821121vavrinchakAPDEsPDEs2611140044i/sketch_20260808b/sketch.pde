













//GPT//MY2ASKS//




// APDE / Processing Java
// FOOTBALL: RED VS BLUE
// 20 red + 20 blue + 4 footballs
// 2 goals
// Collision physics
// No sphere overlap
// No sphere outside screen

int N = 44;

float[] x = new float[N];
float[] y = new float[N];
float[] z = new float[N];

float[] vx = new float[N];
float[] vy = new float[N];

int[] type = new int[N];

float R;
float oldW, oldH;

int points = 0;

void setup() {


//orientation(LANDSCAPE) ;

  fullScreen(P3D);







  R = min(width, height) / 28.0;

  oldW = width;
  oldH = height;

  // -----------------------------
  // 20 RED
  // -----------------------------
  for (int i = 0; i < 20; i++) {
    type[i] = 0;
  }

  // -----------------------------
  // 20 BLUE
  // -----------------------------
  for (int i = 20; i < 40; i++) {
    type[i] = 1;
  }

  // -----------------------------
  // 4 WHITE BALLS
  // -----------------------------
  for (int i = 40; i < 44; i++) {
    type[i] = 2;
  }

  // -----------------------------
  // RANDOM POSITIONS
  // WITHOUT OVERLAPPING
  // -----------------------------
  for (int i = 0; i < N; i++) {

    boolean good = false;

    while (!good) {

      x[i] = random(R, width - R);
      y[i] = random(R + 60, height - R);

      good = true;

      for (int j = 0; j < i; j++) {

        float dx = x[i] - x[j];
        float dy = y[i] - y[j];

        float d = sqrt(dx * dx + dy * dy);

        if (d < R * 2.2) {
          good = false;
          break;
        }
      }
    }

    z[i] = 0;

    // Very slow movement:
    // 0.01 - 0.1 pixel/frame
    float speed = random(0.01, 0.1);




//speed *=333;








    float a = random(TWO_PI);

    vx[i] = cos(a) * speed;
    vy[i] = sin(a) * speed;







  }

  noStroke();
}

// =====================================================
// DRAW
// =====================================================

void draw() {

  background(75, 75, 0);

  // Detect screen-size change
  if (width != oldW || height != oldH) {

    oldW = width;
    oldH = height;

    R = min(width, height) / 28.0;

    // Correct all spheres for new screen size
    for (int i = 0; i < N; i++) {

      x[i] = constrain(x[i], R, width - R);
      y[i] = constrain(y[i], R + 60, height - R);

      // Recalculate direction
      float a = atan2(vy[i], vx[i]);

      float speed = sqrt(
        vx[i] * vx[i] +
        vy[i] * vy[i]
      );

      if (speed < 0.01) speed = 0.05;

      vx[i] = cos(a) * speed;
      vy[i] = sin(a) * speed;
    }
  }

  // =================================================
  // MOVING LIGHTS
  // =================================================

  float t = millis() * 0.002;

  float lx1 = cos(t) * width * 0.5;
  float ly1 = sin(t * 1.3) * height * 0.5;
  float lz1 = 300;

  float lx2 = sin(t * 0.7) * width * 0.5;
  float ly2 = cos(t) * height * 0.5;
  float lz2 = -300;

  pointLight(
    255, 180, 180,
    lx1, ly1, lz1
  );

  pointLight(
    100, 150, 255,
    lx2, ly2, lz2
  );

  // =================================================
  // GOALS
  // =================================================

  drawGoals();












for(int
 mike821121vavrinchak2608081247uakalushlujki=0;
mike821121vavrinchak2608081247uakalushlujki<222;
mike821121vavrinchak2608081247uakalushlujki++){


//mike821121vavrinchak2608081247uakalushlujki
//ifgivefreedonationmoneyonnumber380687501635forinternet
//250uah7$monthCANtryDOmore............. 








  // =================================================
  // MOVE SPHERES
  // =================================================

  for (int i = 0; i < N; i++) {

    x[i] += vx[i];
    y[i] += vy[i];

    // -----------------------------------------------
    // SCREEN WALLS
    // -----------------------------------------------

    if (x[i] < R) {
      x[i] = R;
      vx[i] = abs(vx[i]);
    }

    if (x[i] > width - R) {
      x[i] = width - R;
      vx[i] = -abs(vx[i]);
    }

    if (y[i] < R + 60) {
      y[i] = R + 60;
      vy[i] = abs(vy[i]);
    }

    if (y[i] > height - R) {
      y[i] = height - R;
      vy[i] = -abs(vy[i]);
    }
  }

  // =================================================
  // SPHERE COLLISIONS
  // =================================================

  for (int i = 0; i < N; i++) {

    for (int j = i + 1; j < N; j++) {

      float dx = x[j] - x[i];
      float dy = y[j] - y[i];

      float d = sqrt(dx * dx + dy * dy);

      float minDist = R * 2.0;

      if (d < minDist) {

        // Prevent zero distance
        if (d < 0.001) {
          dx = 1;
          dy = 0;
          d = 1;
        }

        // Normal vector
        float nx = dx / d;
        float ny = dy / d;

        // Separate spheres
        float push = (minDist - d) / 2.0;

        x[i] -= nx * push;
        y[i] -= ny * push;

        x[j] += nx * push;
        y[j] += ny * push;

        // Relative velocity
        float rvx = vx[j] - vx[i];
        float rvy = vy[j] - vy[i];

        // Velocity along collision normal
        float rel = rvx * nx + rvy * ny;

        // Only collide if moving toward each other
        if (rel < 0) {

          // Equal-mass elastic collision
          vx[i] += rel * nx;
          vy[i] += rel * ny;

          vx[j] -= rel * nx;
          vy[j] -= rel * ny;
        }

        // Make sure they continue moving
        keepSpeed(i);
        keepSpeed(j);
      }
    }
  }

  // =================================================
  // CHECK GOALS
  // =================================================

  for (int i = 40; i < 44; i++) {

    // GOAL 1 = LEFT
    if (inGoal1(i)) {

      points += 1;

      resetBall(i);

      continue;
    }

    // GOAL 2 = RIGHT
    if (inGoal2(i)) {

      points -= 1;

      resetBall(i);
    }
  }










}








  // =================================================
  // DRAW SPHERES
  // =================================================

  for (int i = 0; i < N; i++) {

    pushMatrix();

    translate(x[i], y[i], z[i]);

    if (type[i] == 0) {

      // RED TEAM
      fill(255, 0, 0);

    } else if (type[i] == 1) {

      // BLUE TEAM
      fill(0, 80, 255);

    } else {

      // FOOTBALL
      fill(255);
    }

    sphere(R);

    popMatrix();
  }

  // =================================================
  // SCORE
  // =================================================

  drawScore();








stroke(0,0,0,111);




fill(255,255,255,255);
textSize(32);

  text(
    "RED  " + points + "  BLUE",
    width / 2,
   height-55- 10  - 48
  );

  textSize(18);

  text(
    "GOAL 1: +1       GOAL 2: -1",
    width / 2,
 height-11-   48
  );



fill(255,255,255,255);
textSize(32);

  text(
    "RED  " + points + "  BLUE",
    width / 2,
   height-55- 10  - 48
  );

  textSize(18);

  text(
    "GOAL 1: +1       GOAL 2: -1",
    width / 2,
 height-11-   48
  );






noStroke();









}

// =====================================================
// KEEP SPEED BETWEEN 0.01 AND 0.1
// =====================================================

void keepSpeed(int i) {

  float speed = sqrt(
    vx[i] * vx[i] +
    vy[i] * vy[i]
  );

  if (speed < 0.01) {

    float a = random(TWO_PI);

    vx[i] = cos(a) * 0.01;
    vy[i] = sin(a) * 0.01;

  } else if (speed > 0.1) {

    vx[i] *= 0.1 / speed;
    vy[i] *= 0.1 / speed;
  }
}

// =====================================================
// GOAL 1
// =====================================================

boolean inGoal1(int i) {

  float goalW = width * 0.12;
  float goalH = height * 0.35;

  float gy = height / 2;

  return
    x[i] < goalW &&
    y[i] > gy - goalH / 2 &&
    y[i] < gy + goalH / 2;
}

// =====================================================
// GOAL 2
// =====================================================

boolean inGoal2(int i) {

  float goalW = width * 0.12;
  float goalH = height * 0.35;

  float gy = height / 2;

  return
    x[i] > width - goalW &&
    y[i] > gy - goalH / 2 &&
    y[i] < gy + goalH / 2;
}

// =====================================================
// BALL AFTER GOAL
// CENTER + RANDOM DIAGONAL * 0.1
// =====================================================

void resetBall(int i) {

  float diagonal =
    sqrt(
      width * width +
      height * height
    );

  float offset = diagonal * 0.1;

  x[i] = width / 2 +
         random(-offset, offset);

  y[i] = height / 2 +
         random(-offset, offset);

  // Keep inside screen
  x[i] = constrain(
    x[i],
    R,
    width - R
  );

  y[i] = constrain(
    y[i],
    R + 60,
    height - R
  );

  // New random direction
  float a = random(TWO_PI);

  float speed = random(0.01, 0.1);

  vx[i] = cos(a) * speed;
  vy[i] = sin(a) * speed;

  // Move it away from other spheres
  separateBall(i);
}

// =====================================================
// MAKE BALL NOT OVERLAP ANOTHER SPHERE
// =====================================================

void separateBall(int i) {

  for (int attempt = 0; attempt < 100; attempt++) {

    boolean good = true;

    for (int j = 0; j < N; j++) {

      if (j == i) continue;

      float dx = x[i] - x[j];
      float dy = y[i] - y[j];

      float d = sqrt(dx * dx + dy * dy);

      if (d < R * 2.1) {
        good = false;
        break;
      }
    }

    if (good) return;

    float diagonal =
      sqrt(
        width * width +
        height * height
      );

    float offset = diagonal * 0.1;

    x[i] = width / 2 +
           random(-offset, offset);

    y[i] = height / 2 +
           random(-offset, offset);

    x[i] = constrain(
      x[i],
      R,
      width - R
    );

    y[i] = constrain(
      y[i],
      R + 60,
      height - R
    );
  }
}

// =====================================================
// DRAW GOALS
// =====================================================

void drawGoals() {

  float goalW = width * 0.12;
  float goalH = height * 0.35;

  float gy = height / 2;

  // LEFT GOAL
  pushMatrix();

  translate(
    goalW / 2,
    gy,
    -5
  );

  fill(255, 50, 50, 100);

  box(
    goalW,
    goalH,
    10
  );

  popMatrix();

  // RIGHT GOAL
  pushMatrix();

  translate(
    width - goalW / 2,
    gy,
    -5
  );

  fill(50, 100, 255, 100);

  box(
    goalW,
    goalH,
    10
  );

  popMatrix();
}

// =====================================================
// SCORE DISPLAY
// =====================================================

void drawScore() {

  hint(DISABLE_DEPTH_TEST);

  fill(255);





 textAlign(CENTER, TOP);


//textAlign(CENTER, CENTER);




  textSize(32);

  text(
    "RED  " + points + "  BLUE",
    width / 2,
    10
  );

  textSize(18);

  text(
    "GOAL 1: +1       GOAL 2: -1",
    width / 2,
    48
  );










  hint(ENABLE_DEPTH_TEST);
}










//footballSPHERES//




























