

// APDE – Huge 100000×100000 Labyrinth + Scrolling Camera
// Circle moves, cannot enter walls
// LEFT/RIGHT keys or touch to turn

float worldW = 10000;
float worldH = 10000;

float playerX, playerY;
float playerR = 22;
float angle = 0;
float speed = 6.0;

int wallCount = 2500;          // lots of rectangles across the huge area
float[][] walls;               // [x, y, w, h]

float camX, camY;              // camera top-left

void setup() {
  size(displayWidth, displayHeight);
  // size(900, 1600);          // optional fixed size for testing
  
  // Start near the center of the huge world
  playerX = worldW / 2;
  playerY = worldH / 2;
  
  // Generate random labyrinth rectangles across the whole world
  walls = new float[wallCount][4];
  for (int i = 0; i < wallCount; i++) {
    walls[i][0] = random(0, worldW - 200);
    walls[i][1] = random(0, worldH - 200);
    walls[i][2] = random(60, 400);     // width
    walls[i][3] = random(60, 400);     // height
  }
  
  // Make sure player starts in open space
  while (hitsAnyWall(playerX, playerY)) {
    playerX = random(1000, worldW - 1000);
    playerY = random(1000, worldH - 1000);
  }
  
  updateCamera();
}

void draw() {
  background(12);
  
  // ---- Move player ----
  float nextX = playerX + cos(angle) * speed;
  float nextY = playerY + sin(angle) * speed;
  
  // Slide along walls (X then Y)
  if (!hitsAnyWall(nextX, playerY)) playerX = nextX;
  if (!hitsAnyWall(playerX, nextY)) playerY = nextY;
  
  // Keep inside world
  playerX = constrain(playerX, playerR, worldW - playerR);
  playerY = constrain(playerY, playerR, worldH - playerR);
  
  updateCamera();
  
  // ---- Draw everything relative to camera ----
  pushMatrix();
  translate(-camX, -camY);
  
  // Draw only walls that are visible on screen (big speed boost)
  noFill();
  stroke(160, 210, 255);
  strokeWeight(2);
  for (int i = 0; i < wallCount; i++) {
    float wx = walls[i][0];
    float wy = walls[i][1];
    float ww = walls[i][2];
    float wh = walls[i][3];
    
    // Culling: only draw if the rectangle is near the camera view
    if (wx + ww > camX - 50 && wx < camX + width + 50 &&
        wy + wh > camY - 50 && wy < camY + height + 50) {
      rect(wx, wy, ww, wh);
    }
  }
  
  // Player circle
  fill(255, 70, 70);
  noStroke();
  ellipse(playerX, playerY, playerR*2, playerR*2);
  
  // Direction line
  stroke(255);
  strokeWeight(3);
  line(playerX, playerY,
       playerX + cos(angle)*playerR*1.8,
       playerY + sin(angle)*playerR*1.8);
  
  popMatrix();
  
  // Optional HUD
  fill(255);
  textSize(28);
  text("X: " + int(playerX) + "   Y: " + int(playerY), 20, 40);
  text("World: 100000 × 100000", 20, 80);
}

void updateCamera() {
  // Center camera on player
  camX = playerX - width/2;
  camY = playerY - height/2;
  
  // Clamp camera so it never shows outside the world
  camX = constrain(camX, 0, worldW - width);
  camY = constrain(camY, 0, worldH - height);
}

// Circle vs rectangle collision
boolean hitsAnyWall(float cx, float cy) {
  for (int i = 0; i < wallCount; i++) {
    float wx = walls[i][0];
    float wy = walls[i][1];
    float ww = walls[i][2];
    float wh = walls[i][3];
    
    float closestX = constrain(cx, wx, wx + ww);
    float closestY = constrain(cy, wy, wy + wh);
    float dx = cx - closestX;
    float dy = cy - closestY;
    if (dx*dx + dy*dy < playerR*playerR) return true;
  }
  return false;
}

// ---- Controls ----
void keyPressed() {
  if (keyCode == LEFT)  angle -= 0.20;
  if (keyCode == RIGHT) angle += 0.20;
}

void mouseDragged() {
  angle += (mouseX - pmouseX) * 0.015;
}

void mousePressed() {
  if (mouseX < width/2) angle -= 0.30;
  else                  angle += 0.30;
}

























