











///8chess8mike821121vavrinchak2609052115/////
void settings() 
{size(displayWidth, displayHeight, JAVA2D) ;} 
void size() 
{size(displayWidth, displayHeight, JAVA2D) ;} 
short [] [] bu=new short[30][30];
  short [] [] [] u=new short[30][30][1002];
short [] [] [] uu=new short[30][30][1002];
short [] [] [] uuu=new short[30][30][1002];


void iu(
short a1,short  b1, short c1,short  d1, 
short e1,short  f1, short g1,short  h1, 
short a2,short  b2, short c2,short  d2, 
short e2,short  f2, short g2,short  h2, 
short a3,short  b3, short c3,short  d3, 
short e3,short  f3, short g3,short  h3, 
short a4,short  b4, short c4,short  d4, 
short e4,short  f4, short g4,short  h4, 

short a5,short  b5, short c5,short  d5, 
short e5,short  f5, short g5,short  h5, 
short a6,short  b6, short c6,short  d6, 
short e6,short  f6, short g6,short  h6, 
short a7,short  b7, short c7,short  d7, 
short e7,short  f7, short g7,short  h7, 
short a8,short  b8, short c8,short  d8, 
short e8,short  f8, short g8,short  h8, 

short wu, 

short o, 

short fi, short ve, short ho, 
short vvee, short hhoo, short ta, 
short qu







      ) {

bu[1][1]=a1;bu[2][1]=b1;bu[3][1]=c1;bu[4][1]=d1;
bu[5][1]=e1;bu[6][1]=f1;bu[7][1]=g1;bu[8][1]=h1;
bu[1][2]=a2;bu[2][2]=b2;bu[3][2]=c2;bu[4][2]=d2;
bu[5][2]=e2;bu[6][2]=f2;bu[7][2]=g2;bu[8][2]=h2;

bu[1][3]=a3;bu[2][3]=b3;bu[3][3]=c3;bu[4][3]=d3;
bu[5][3]=e3;bu[6][3]=f3;bu[7][3]=g3;bu[8][3]=h3;
bu[1][4]=a4;bu[2][4]=b4;bu[3][4]=c4;bu[4][4]=d4;
bu[5][4]=e4;bu[6][4]=f4;bu[7][4]=g4;bu[8][4]=h4;


bu[1][5]=a5;bu[2][5]=b5;bu[3][5]=c5;bu[4][5]=d5;
bu[5][5]=e5;bu[6][5]=f5;bu[7][5]=g5;bu[8][5]=h5;
bu[1][6]=a6;bu[2][6]=b6;bu[3][6]=c6;bu[4][6]=d6;
bu[5][6]=e6;bu[6][6]=f6;bu[7][6]=g6;bu[8][6]=h6;

bu[1][7]=a7;bu[2][7]=b7;bu[3][7]=c7;bu[4][7]=d7;
bu[5][7]=e7;bu[6][3]=f7;bu[7][7]=g7;bu[8][7]=h7;
bu[1][8]=a8;bu[2][8]=b8;bu[3][8]=c8;bu[4][8]=d8;
bu[5][8]=e8;bu[6][8]=f8;bu[7][8]=g8;bu[8][8]=h8;



} 






















  float mx, my, px, py;
void mousePressed() {
stroke(66,66,99);fill(222,0,0);
line(pmouseX,pmouseY,mouseX,mouseY);



mx=mouseX;my=mouseY;



px=pmouseX;py=pmouseY;




}  





float w, h;
void draw() {fill(0,0,0);
w=width;h=height;
rect(0,0,width,50+height/50);

textSize(43);fill(222,255,0);
textMode(CENTER) ;
stroke(0,222,255);strokeWeight(1);
text(mx+"#" +my+"#" +px+"#" +py, 22,31+h/50);





} 
















