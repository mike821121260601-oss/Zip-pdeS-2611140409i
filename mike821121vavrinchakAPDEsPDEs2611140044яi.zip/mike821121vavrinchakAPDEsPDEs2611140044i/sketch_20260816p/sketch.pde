








// ============================================================
// APDE CHESS - 3 BOARDS
// Human touch moves
// 10 position history for every board
// +1 / -1 change selected board
// BACK restores previous position
// No chess font - pieces are Processing shapes
// ============================================================

int BOARDS = 3;
int HISTORY = 10;

int selectedBoard = 0;

// Board state
// 0 empty
// 1-6 white pieces
// 7-12 black pieces
int[][][] board = new int[BOARDS][8][8];

// History
int[][][][] history = new int[BOARDS][HISTORY][8][8];
int[] historyCount = new int[BOARDS];
int[] historyPos = new int[BOARDS];

boolean pieceSelected = false;
int selectedR = -1;
int selectedC = -1;

int boardX;
int boardY;
int squareSize;

int buttonH;

int backX, backW;
int minusX, minusW;
int plusX, plusW;

PFont font;

// ------------------------------------------------------------

void settings() {
  size(displayWidth, displayHeight, P2D);
}

// ------------------------------------------------------------

void setup() {

  orientation(PORTRAIT);

  //surface.setTitle("3 Board Chess");

  font = createFont("Sans", 28);
  textFont(font);

  setupBoards();

  // Save initial position
  for (int b = 0; b < BOARDS; b++) {
    saveHistory(b);
  }
}

// ------------------------------------------------------------

void draw() {

  background(30);

  calculateBoardSize();

  drawTopInformation();

  drawChessBoard();

  drawButtons();

}

// ------------------------------------------------------------
// BOARD SIZE
// ------------------------------------------------------------

void calculateBoardSize() {

  squareSize = min(width / 8, (height - 170) / 8);

  boardX = (width - squareSize * 8) / 2;

  boardY = 85;
}

// ------------------------------------------------------------
// INITIAL CHESS POSITION
// ------------------------------------------------------------

void setupBoards() {

  for (int b = 0; b < BOARDS; b++) {

    clearBoard(b);

    setupStartingPosition(b);
  }
}

// ------------------------------------------------------------

void clearBoard(int b) {

  for (int r = 0; r < 8; r++) {

    for (int c = 0; c < 8; c++) {

      board[b][r][c] = 0;
    }
  }
}

// ------------------------------------------------------------

void setupStartingPosition(int b) {

  // Black back row
  board[b][0][0] = 12;
  board[b][0][1] = 10;
  board[b][0][2] = 11;
  board[b][0][3] = 9;
  board[b][0][4] = 8;
  board[b][0][5] = 11;
  board[b][0][6] = 10;
  board[b][0][7] = 12;

  // Black pawns
  for (int c = 0; c < 8; c++) {
    board[b][1][c] = 7;
  }

  // White pawns
  for (int c = 0; c < 8; c++) {
    board[b][6][c] = 1;
  }

  // White back row
  board[b][7][0] = 6;
  board[b][7][1] = 4;
  board[b][7][2] = 5;
  board[b][7][3] = 3;
  board[b][7][4] = 2;
  board[b][7][5] = 5;
  board[b][7][6] = 4;
  board[b][7][7] = 6;
}

// ------------------------------------------------------------
// DRAW INFORMATION
// ------------------------------------------------------------

void drawTopInformation() {

  fill(255);
  textAlign(CENTER, CENTER);

  textSize(25);

  text(
    "CHESS BOARD " + (selectedBoard + 1) + " / " + BOARDS,
    width / 2,
    25
  );

  textSize(15);

  text(
    "HISTORY " +
    historyPos[selectedBoard] +
    " / " +
    max(1, historyCount[selectedBoard]),
    width / 2,
    57
  );
}

// ------------------------------------------------------------
// DRAW CHESS BOARD
// ------------------------------------------------------------

void drawChessBoard() {

  for (int r = 0; r < 8; r++) {

    for (int c = 0; c < 8; c++) {

      int x = boardX + c * squareSize;
      int y = boardY + r * squareSize;

      // Board colors
      if ((r + c) % 2 == 0) {
        fill(235, 210, 170);
      } else {
        fill(120, 80, 45);
      }

      rect(x, y, squareSize, squareSize);

      // Selected square
      if (pieceSelected &&
          r == selectedR &&
          c == selectedC) {

        noFill();
        stroke(0, 255, 0);
        strokeWeight(5);

        rect(
          x + 3,
          y + 3,
          squareSize - 6,
          squareSize - 6
        );

        noStroke();
      }

      // Piece
      int p = board[selectedBoard][r][c];

      if (p != 0) {

        drawPiece(
          p,
          x + squareSize / 2,
          y + squareSize / 2,
          squareSize
        );
      }
    }
  }
}

// ============================================================
// PIECES
// ============================================================

void drawPiece(int p, float x, float y, float s) {

  boolean whitePiece = p <= 6;

  // White / black piece body
  if (whitePiece) {
    fill(245);
    stroke(20);
  } else {
    fill(25);
    stroke(240);
  }

  strokeWeight(2);

  int type = p;

  if (!whitePiece) {
    type = p - 6;
  }

  if (type == 1) drawPawn(x, y, s);
  if (type == 2) drawKing(x, y, s);
  if (type == 3) drawQueen(x, y, s);
  if (type == 4) drawRook(x, y, s);
  if (type == 5) drawBishop(x, y, s);
  if (type == 6) drawKnight(x, y, s);

  noStroke();
}

// ------------------------------------------------------------
// PAWN
// ------------------------------------------------------------

void drawPawn(float x, float y, float s) {

  ellipse(x, y - s * .18, s * .27, s * .27);

  rectMode(CENTER);

  rect(
    x,
    y + s * .08,
    s * .30,
    s * .30
  );

  rect(
    x,
    y + s * .28,
    s * .48,
    s * .13
  );

  rectMode(CORNER);
}

// ------------------------------------------------------------
// KING
// ------------------------------------------------------------

void drawKing(float x, float y, float s) {

  rectMode(CENTER);

  rect(
    x,
    y + s * .18,
    s * .42,
    s * .45
  );

  rect(
    x,
    y + s * .39,
    s * .58,
    s * .13
  );

  line(
    x,
    y - s * .36,
    x,
    y - s * .05
  );

  line(
    x - s * .12,
    y - s * .21,
    x + s * .12,
    y - s * .21
  );

  rectMode(CORNER);
}

// ------------------------------------------------------------
// QUEEN
// ------------------------------------------------------------

void drawQueen(float x, float y, float s) {

  triangle(
    x - s * .25,
    y - s * .22,

    x,
    y - s * .38,

    x + s * .25,
    y - s * .22
  );

  ellipse(
    x,
    y - s * .25,
    s * .20,
    s * .20
  );

  rectMode(CENTER);

  rect(
    x,
    y + s * .13,
    s * .42,
    s * .40
  );

  rect(
    x,
    y + s * .36,
    s * .58,
    s * .12
  );

  rectMode(CORNER);
}

// ------------------------------------------------------------
// ROOK
// ------------------------------------------------------------

void drawRook(float x, float y, float s) {

  rectMode(CENTER);

  rect(
    x,
    y + s * .13,
    s * .43,
    s * .47
  );

  rect(
    x,
    y - s * .20,
    s * .52,
    s * .18
  );

  // Rook top blocks
  rect(
    x - s * .18,
    y - s * .31,
    s * .11,
    s * .20
  );

  rect(
    x,
    y - s * .31,
    s * .11,
    s * .20
  );

  rect(
    x + s * .18,
    y - s * .31,
    s * .11,
    s * .20
  );

  rect(
    x,
    y + s * .38,
    s * .58,
    s * .12
  );

  rectMode(CORNER);
}

// ------------------------------------------------------------
// BISHOP
// ------------------------------------------------------------

void drawBishop(float x, float y, float s) {

  ellipse(
    x,
    y - s * .25,
    s * .28,
    s * .35
  );

  triangle(
    x,
    y - s * .40,
    x - s * .25,
    y + s * .12,
    x + s * .25,
    y + s * .12
  );

  rectMode(CENTER);

  rect(
    x,
    y + s * .25,
    s * .45,
    s * .18
  );

  rect(
    x,
    y + s * .38,
    s * .58,
    s * .12
  );

  rectMode(CORNER);
}

// ------------------------------------------------------------
// KNIGHT
// ------------------------------------------------------------

void drawKnight(float x, float y, float s) {

  beginShape();

  vertex(x - s * .22, y + s * .34);

  vertex(x - s * .22, y - s * .05);

  vertex(x - s * .10, y - s * .30);

  vertex(x + s * .08, y - s * .40);

  vertex(x + s * .27, y - s * .18);

  vertex(x + s * .18, y - s * .02);

  vertex(x + s * .25, y + s * .34);

  endShape(CLOSE);

  ellipse(
    x + s * .08,
    y - s * .20,
    s * .06,
    s * .06
  );

  rectMode(CENTER);

  rect(
    x,
    y + s * .40,
    s * .58,
    s * .12
  );

  rectMode(CORNER);
}

// ============================================================
// BUTTONS
// ============================================================

void drawButtons() {

  int y = height - 70;

  buttonH = 55;

  minusW = width / 5;
  plusW = width / 5;
  backW = width / 3;

  minusX = 10;
  backX = (width - backW) / 2;
  plusX = width - plusW - 10;

  // MINUS
  fill(70);
  rect(minusX, y, minusW, buttonH, 10);

  // BACK
  fill(90);
  rect(backX, y, backW, buttonH, 10);

  // PLUS
  fill(70);
  rect(plusX, y, plusW, buttonH, 10);

  fill(255);

  textAlign(CENTER, CENTER);
  textSize(30);

  text(
    "-1",
    minusX + minusW / 2,
    y + buttonH / 2
  );

  text(
    "BACK",
    backX + backW / 2,
    y + buttonH / 2
  );

  text(
    "+1",
    plusX + plusW / 2,
    y + buttonH / 2
  );
}

// ============================================================
// TOUCH
// ============================================================

void mousePressed() {

  float x = mouseX;
  float y = mouseY;

  // -----------------------------------------
  // -1 BOARD
  // -----------------------------------------

  if (x >= minusX &&
      x <= minusX + minusW &&
      y >= height - 80) {

    selectedBoard--;

    if (selectedBoard < 0) {
      selectedBoard = BOARDS - 1;
    }

    cancelSelection();

    return;
  }

  // -----------------------------------------
  // BACK
  // -----------------------------------------

  if (x >= backX &&
      x <= backX + backW &&
      y >= height - 80) {

    backMove();

    return;
  }

  // -----------------------------------------
  // +1 BOARD
  // -----------------------------------------

  if (x >= plusX &&
      x <= plusX + plusW &&
      y >= height - 80) {

    selectedBoard++;

    if (selectedBoard >= BOARDS) {
      selectedBoard = 0;
    }

    cancelSelection();

    return;
  }

  // -----------------------------------------
  // CHESS BOARD TOUCH
  // -----------------------------------------

  if (x >= boardX &&
      x < boardX + squareSize * 8 &&
      y >= boardY &&
      y < boardY + squareSize * 8) {

    int c = int((x - boardX) / squareSize);
    int r = int((y - boardY) / squareSize);

    chessTouch(r, c);
  }
}

// ============================================================
// HUMAN CHESS MOVE
// ============================================================

void chessTouch(int r, int c) {

  int p = board[selectedBoard][r][c];

  // -----------------------------------------
  // FIRST TOUCH = SELECT PIECE
  // -----------------------------------------

  if (!pieceSelected) {

    if (p != 0) {

      // Human starts with white pieces.
      // After every move the side changes.
      // This simple version allows selecting
      // any existing piece.

      selectedR = r;
      selectedC = c;

      pieceSelected = true;
    }

    return;
  }

  // -----------------------------------------
  // SECOND TOUCH = MOVE
  // -----------------------------------------

  if (r == selectedR &&
      c == selectedC) {

    cancelSelection();

    return;
  }

  int movingPiece =
    board[selectedBoard][selectedR][selectedC];

  // Cannot capture own color
  if (p != 0) {

    boolean movingWhite = movingPiece <= 6;
    boolean targetWhite = p <= 6;

    if (movingWhite == targetWhite) {

      selectedR = r;
      selectedC = c;

      return;
    }
  }

  // Save position BEFORE move
  saveHistory(selectedBoard);

  // Move piece
  board[selectedBoard][r][c] = movingPiece;

  board[selectedBoard][selectedR][selectedC] = 0;

  cancelSelection();
}

// ============================================================
// CANCEL SELECTION
// ============================================================

void cancelSelection() {

  pieceSelected = false;

  selectedR = -1;
  selectedC = -1;
}

// ============================================================
// HISTORY
// ============================================================

void saveHistory(int b) {

  // If history is full, remove oldest
  // by shifting positions.

  if (historyCount[b] >= HISTORY) {

    for (int h = 0; h < HISTORY - 1; h++) {

      copyPosition(
        history[b][h + 1],
        history[b][h]
      );
    }

    historyCount[b] = HISTORY - 1;
  }

  int index = historyCount[b];

  copyPosition(
    board[b],
    history[b][index]
  );

  historyCount[b]++;

  historyPos[b] = historyCount[b] - 1;
}

// ============================================================
// BACK MOVE
// ============================================================

void backMove() {

  int b = selectedBoard;

  if (historyCount[b] <= 1) {
    return;
  }

  // Remove current position
  historyCount[b]--;

  int previous =
    historyCount[b] - 1;

  copyPosition(
    history[b][previous],
    board[b]
  );

  historyPos[b] = previous;

  cancelSelection();
}

// ============================================================
// COPY BOARD
// ============================================================

void copyPosition(
  int[][] source,
  int[][] destination) {

  for (int r = 0; r < 8; r++) {

    for (int c = 0; c < 8; c++) {

      destination[r][c] =
        source[r][c];
    }
  }
}

// ============================================================
// OPTIONAL ANDROID BACK BUTTON
// ============================================================

@Override
public void onBackPressed() {

  if (pieceSelected) {

    cancelSelection();

  } else {

    backMove();
  }
}



























