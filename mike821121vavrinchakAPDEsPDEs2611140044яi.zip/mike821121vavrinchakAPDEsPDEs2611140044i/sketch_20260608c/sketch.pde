





int KetaiZIP;

import processing.sound.*;
TriOsc triOsc;
Env env;
float attachTime=0.001;
float sustainTime=0.004;
float sustainLevel=0.2;
float releaseTime=0.2;
int [] midisequence={60,61,62,63,
64,65,66,67,68,69,70,71,72};
int duration=200;
int trigger=0;











