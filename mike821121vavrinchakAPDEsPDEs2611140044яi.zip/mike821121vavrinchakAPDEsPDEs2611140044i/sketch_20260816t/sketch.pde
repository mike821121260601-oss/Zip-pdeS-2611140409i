
///GOOD///WORK////

// APDE / Processing Android – 9×14 random tone-pad
// 1–21 kHz, 15 s sweeps, volume 10↔90 %
// SAFE version: skips new buffers when maximum concurrent tracks is reached

import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;

int cols = 14;
int rows = 9;
float cellW, cellH;

// ---- Safety limit ----
final int MAX_CONCURRENT = 12;   // change this if needed (8–16 is usually safe)
int activeTracks = 0;

void setup() {
  fullScreen();
  orientation(LANDSCAPE);
  cellW = width  / (float)cols;
  cellH = height / (float)rows;
  textAlign(CENTER, CENTER);
  textSize(18);
}

void draw() {
  background(20);
  
  for (int y = 0; y < rows; y++) {
    for (int x = 0; x < cols; x++) {
      float px = x * cellW;
      float py = y * cellH;
      
      if (mousePressed && mouseX > px && mouseX < px+cellW &&
                           mouseY > py && mouseY < py+cellH) {
        fill(80, 180, 255);
      } else {
        fill(40 + (x+y)%3 * 15);
      }
      stroke(90);
      rect(px+1, py+1, cellW-2, cellH-2, 6);
      
      fill(200);
      text((y*cols + x + 1), px + cellW/2, py + cellH/2);
    }
  }
  
  // optional: show how many tracks are currently playing
  fill(255, 200, 50);
  text("Active: " + activeTracks + " / " + MAX_CONCURRENT, width/2, 30);
}

void mousePressed() {
  // each key tries to start 9 random sweeps
  for (int i = 0; i < 9; i++) {
    
    // ---- SAFETY CHECK ----
    synchronized(this) {
      if (activeTracks >= MAX_CONCURRENT) {
        // skip this tone – buffer limit reached
        continue;
      }
      activeTracks++;
    }
    
    float f1 = random(1000, 21000);
    float f2 = random(1000, 21000);
    boolean volUp = random(1) > 0.5;
    float duration = 15.0;
    
    playSweep(f1, f2, volUp, duration);
  }
}

void playSweep(final float startHz, final float endHz,
               final boolean volumeRising, final float durationSec) {
  
  new Thread(new Runnable() {
    public void run() {
      AudioTrack track = null;
      try {
        int sampleRate = 44100;
        int numSamples = (int)(durationSec * sampleRate);
        short[] buffer = new short[numSamples];
        
        float volStart = volumeRising ? 0.10f : 0.90f;
        float volEnd   = volumeRising ? 0.90f : 0.10f;
        
        for (int i = 0; i < numSamples; i++) {
          float t = i / (float)sampleRate;
          float progress = i / (float)(numSamples - 1);
          
          float freq = lerp(startHz, endHz, progress);
          float amp  = lerp(volStart, volEnd, progress);
          
          float sample = (float)(Math.sin(2 * Math.PI * freq * t) * amp);
          buffer[i] = (short)(sample * 32767);
        }
        
        track = new AudioTrack(
            AudioManager.STREAM_MUSIC,
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            buffer.length * 2,
            AudioTrack.MODE_STATIC);
        
        track.write(buffer, 0, buffer.length);
        track.play();
        
        Thread.sleep((long)(durationSec * 1000) + 80);
        
      } catch (Exception e) {
        // any error → just ignore this tone
      } finally {
        if (track != null) {
          try {
            track.stop();
            track.release();
          } catch (Exception e) {}
        }
        
        // free the slot
        synchronized(this) {
          activeTracks = max(0, activeTracks - 1);
        }
      }
    }
  }).start();
}







//uncrashed///


































