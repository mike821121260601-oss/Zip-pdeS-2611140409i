


// Version 2 – 66 balls chaos (your original idea, 2D for APDE performance)
int NUM = 66;
float BALL_R = 8;
float MARGIN = 35;

Ball[] balls = new Ball[NUM];
boolean aiming = false;
PVector aimS, aimE;

void setup() {
  size(displayWidth, displayHeight);


 ///// orientation(LANDSCAPE);



  frameRate(55);
  reset();
}

void reset() {
  for (int i=0; i<NUM; i++) {
    float x, y;
    boolean ok;
    do {
      ok = true;
      x = random(MARGIN+BALL_R, width-MARGIN-BALL_R);
      y = random(MARGIN+BALL_R, height-MARGIN-BALL_R);
      for (int j=0; j<i; j++) {
        if (dist(x,y,balls[j].p.x,balls[j].p.y) < BALL_R*2.1) { ok=false; break; }
      }
    } while (!ok);
    color c = (i==0) ? color(255) : color(random(50,255), random(40,200), random(30,180));
    balls[i] = new Ball(x, y, c, i==0);
  }
}

void draw() {
  background(18, 55, 28);
  fill(22, 115, 48); noStroke();
  rect(MARGIN, MARGIN, width-2*MARGIN, height-2*MARGIN, 6);
  stroke(70, 35, 12); strokeWeight(7); noFill();
  rect(MARGIN, MARGIN, width-2*MARGIN, height-2*MARGIN, 6);
  
  for (Ball b : balls) b.move();
  for (int i=0; i<NUM; i++)
    for (int j=i+1; j<NUM; j++) balls[i].hit(balls[j]);
  
  for (Ball b : balls) b.show();
  
  if (aiming) {
    stroke(255, 200); strokeWeight(2.5);
    line(aimS.x, aimS.y, aimE.x, aimE.y);
  }
  fill(255); textSize(18);
  text("66 balls – drag white ball  |  R = reset", 20, height-18);
}

void mousePressed() {
  if (dist(mouseX,mouseY,balls[0].p.x,balls[0].p.y) < BALL_R*4) {
    aiming = true; aimS = balls[0].p.copy(); aimE = new PVector(mouseX,mouseY);
  }
}
void mouseDragged() { if (aiming) aimE.set(mouseX,mouseY); }
void mouseReleased() {
  if (aiming) {
    PVector d = PVector.sub(aimS, aimE);
    float pwr = constrain(d.mag()/9, 0, 14);
    d.normalize().mult(pwr);
    balls[0].v.add(d);
  }
  aiming = false;
}
void keyPressed() { if (key=='r'||key=='R') reset(); }

class Ball {
  PVector p, v; color col; boolean cue;
  Ball(float x,float y,color c,boolean isCue){ p=new PVector(x,y); v=new PVector(); col=c; cue=isCue; }
  void move() {
    p.add(v); v.mult(0.991);
    if (p.x < MARGIN+BALL_R){p.x=MARGIN+BALL_R;v.x*=-0.9;}
    if (p.x > width-MARGIN-BALL_R){p.x=width-MARGIN-BALL_R;v.x*=-0.9;}
    if (p.y < MARGIN+BALL_R){p.y=MARGIN+BALL_R;v.y*=-0.9;}
    if (p.y > height-MARGIN-BALL_R){p.y=height-MARGIN-BALL_R;v.y*=-0.9;}
  }
  void hit(Ball o) {
    float d=dist(p.x,p.y,o.p.x,o.p.y);
    if (d<BALL_R*2 && d>0.01) {
      PVector n=PVector.sub(o.p,p).normalize();
      float ov=BALL_R*2-d;
      p.sub(PVector.mult(n,ov*0.5)); o.p.add(PVector.mult(n,ov*0.5));
      float imp = (v.dot(n)-o.v.dot(n));
      v.sub(PVector.mult(n,imp)); o.v.add(PVector.mult(n,imp));
      v.mult(0.96); o.v.mult(0.96);
    }
  }
  void show(){ noStroke(); fill(col); ellipse(p.x,p.y,BALL_R*2,BALL_R*2); if(cue){fill(0);ellipse(p.x,p.y,4,4);} }
}























