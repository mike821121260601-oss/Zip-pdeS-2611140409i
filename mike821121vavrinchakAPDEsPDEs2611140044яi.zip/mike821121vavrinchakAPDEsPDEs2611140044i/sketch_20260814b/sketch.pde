












// APDE - 9 KEY NOTIFICATION
// Android / Processing

String[] names = {
  "KEY 1", "KEY 2", "KEY 3",
  "KEY 4", "KEY 5", "KEY 6",
  "KEY 7", "KEY 8", "KEY 9"
};

boolean[] pressed = new boolean[9];

void setup() {
  size(displayWidth, displayHeight, P2D);
  orientation(PORTRAIT);

  textAlign(CENTER, CENTER);
  textSize(28);
}

void draw() {
  background(20);

  // TITLE
  fill(255);
  textSize(32);
  text("NOTIFICATION", width/2, height*0.08);

  // 9 KEYS
  float marginX = width * 0.05;
  float marginY = height * 0.15;

  float gap = width * 0.02;
  float keyW = (width - 2*marginX - 2*gap) / 3.0;
  float keyH = height * 0.16;

  for (int i = 0; i < 9; i++) {

    int col = i % 3;
    int row = i / 3;

    float x = marginX + col * (keyW + gap);
    float y = marginY + row * (keyH + gap);

    if (pressed[i]) {
      fill(0, 220, 80);
    } else {
      fill(60, 60, 70);
    }

    rect(x, y, keyW, keyH, 20);

    fill(255);
    textSize(25);
    text(names[i], x + keyW/2, y + keyH/2);
  }
}

void mousePressed() {

  float marginX = width * 0.05;
  float marginY = height * 0.15;

  float gap = width * 0.02;
  float keyW = (width - 2*marginX - 2*gap) / 3.0;
  float keyH = height * 0.16;

  for (int i = 0; i < 9; i++) {

    int col = i % 3;
    int row = i / 3;

    float x = marginX + col * (keyW + gap);
    float y = marginY + row * (keyH + gap);

    if (mouseX >= x &&
        mouseX <= x + keyW &&
        mouseY >= y &&
        mouseY <= y + keyH) {

      pressed[i] = true;

      // NOTIFICATION
      println("NOTIFICATION: " + names[i]);
    }
  }
}

void mouseReleased() {

  for (int i = 0; i < 9; i++) {
    pressed[i] = false;
  }
}


















