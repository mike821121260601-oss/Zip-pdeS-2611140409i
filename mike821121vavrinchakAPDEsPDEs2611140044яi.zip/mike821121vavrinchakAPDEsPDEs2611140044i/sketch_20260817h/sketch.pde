      





// ============================================================
// APDE CODE GAME - BOARD 27 x 27
// Processing version
// void draw()
// fill yellow + lightgrey squares
// mouseX mouseY = HUMAN move
// ENGINE thinking.... move
// BACK key (b / B) = Undo last move(s)
// ============================================================

int BOARD = 27;
int CELL = 22 + 5 + 11;
int MARGIN = 30;
int[][] board;          // 0 empty, 1 Black (Human), 2 White (Engine)
int currentPlayer = 1;  // 1 = Human
boolean engineThinking = false;
String message = "HUMAN move  |  Click a square   |  [B] Undo";
int lastX = -1, lastY = -1;
int thinkTimer = 0;

// === MOVE HISTORY for Undo ===
ArrayList<int[]> moveHistory;   // each entry: {x, y, player}

void setup() {
  size(displayWidth, displayHeight, JAVA2D);

  board = new int[BOARD][BOARD];
  moveHistory = new ArrayList<int[]>();
  resetBoard();
  textAlign(LEFT, CENTER);
  textSize(14);
}

void resetBoard() {
  for (int y = 0; y < BOARD; y++) {
    for (int x = 0; x < BOARD; x++) {
      board[y][x] = 0;
    }
  }
  currentPlayer = 1;
  engineThinking = false;
  message = "HUMAN move  |  Click a square   |  [B] Undo";
  lastX = -1;
  lastY = -1;
  thinkTimer = 0;
  moveHistory.clear();
}

void draw() {
  background(30, 30, 40);

  // Title
  fill(255, 220, 80);
  text("APDE BOARD 27 x 27   |   mouseX mouseY   |   [B] BACK", MARGIN, 18);

  // Draw 27x27 yellow / lightgrey squares
  for (int y = 0; y < BOARD; y++) {
    for (int x = 0; x < BOARD; x++) {
      int px = MARGIN + x * CELL;
      int py = MARGIN + 25 + y * CELL;

      if ((x + y) % 2 == 0) {
        fill(255, 220, 80);      // yellow
      } else {
        fill(210, 210, 210);     // lightgrey
      }
      stroke(60);
      rect(px, py, CELL, CELL);

      // Stones
      if (board[y][x] == 1) {          // Human Black
        fill(20);
        noStroke();
        ellipse(px + CELL/2, py + CELL/2, CELL-6, CELL-6);
      } else if (board[y][x] == 2) {   // Engine White
        fill(245);
        stroke(40);
        strokeWeight(2);
        ellipse(px + CELL/2, py + CELL/2, CELL-6, CELL-6);
      }
    }
  }

  // Highlight last move
  if (lastX >= 0) {
    stroke(220, 40, 40);
    strokeWeight(3);
    noFill();
    rect(MARGIN + lastX*CELL, MARGIN + 25 + lastY*CELL, CELL, CELL);
  }

  // Message
  fill(engineThinking ? color(255, 220, 80) : color(40, 180, 80));
  text(message, MARGIN, height - 28);

  // Engine thinking delay
  if (engineThinking) {
    thinkTimer--;
    if (thinkTimer <= 0) {
      doEngineMove();
      engineThinking = false;
      currentPlayer = 1;
      message = "ENGINE moved  |  HUMAN move   |  [B] Undo";
    }
  }
}

void mousePressed() {
  if (currentPlayer != 1 || engineThinking) return;

  int bx = (mouseX - MARGIN) / CELL;
  int by = (mouseY - MARGIN - 25) / CELL;

  if (bx >= 0 && bx < BOARD && by >= 0 && by < BOARD) {
    if (board[by][bx] == 0) {
      placeStone(bx, by, 1);               // HUMAN Black
      message = "HUMAN placed (" + (bx+1) + "," + (by+1) + ")  |  ENGINE thinking....";
      currentPlayer = 2;
      engineThinking = true;
      thinkTimer = 25;
    }
  }
}

void placeStone(int x, int y, int player) {
  board[y][x] = player;
  lastX = x;
  lastY = y;
  // Remember the move for undo
  moveHistory.add(new int[]{x, y, player});
}

void undoLastMove() {
  if (moveHistory.size() == 0) {
    message = "No moves to undo";
    return;
  }

  // Cancel any pending engine thinking
  engineThinking = false;
  thinkTimer = 0;

  // Remove last move
  int[] last = moveHistory.remove(moveHistory.size() - 1);
  board[last[1]][last[0]] = 0;

  // Also undo the engine move if the last human move was followed by engine
  // (so one press of B undoes both Human + Engine)
  if (last[2] == 1 && moveHistory.size() > 0) {
    int[] prev = moveHistory.get(moveHistory.size() - 1);
    if (prev[2] == 2) {   // previous was engine
      moveHistory.remove(moveHistory.size() - 1);
      board[prev[1]][prev[0]] = 0;
    }
  }

  // Restore last move highlight
  if (moveHistory.size() > 0) {
    int[] prev = moveHistory.get(moveHistory.size() - 1);
    lastX = prev[0];
    lastY = prev[1];
  } else {
    lastX = -1;
    lastY = -1;
  }

  currentPlayer = 1;
  message = "UNDO  |  HUMAN move   |  [B] Undo again";
}

void doEngineMove() {
  ArrayList<int[]> empties = new ArrayList<int[]>();
  for (int y = 0; y < BOARD; y++) {
    for (int x = 0; x < BOARD; x++) {
      if (board[y][x] == 0) {
        empties.add(new int[]{x, y});
      }
    }
  }
  if (empties.size() == 0) {
    message = "Board full";
    return;
  }

  int cx = BOARD / 2;
  int cy = BOARD / 2;
  ArrayList<int[]> candidates = new ArrayList<int[]>();

  // Prefer near last human move
  if (lastX >= 0) {
    for (int[] p : empties) {
      if (abs(p[0]-lastX) <= 3 && abs(p[1]-lastY) <= 3) {
        candidates.add(p);
      }
    }
  }

  // Or prefer center
  if (candidates.size() == 0) {
    for (int[] p : empties) {
      if (abs(p[0]-cx) <= 5 && abs(p[1]-cy) <= 5) {
        candidates.add(p);
      }
    }
  }

  if (candidates.size() == 0) {
    candidates = empties;
  }

  int[] choice = candidates.get(int(random(candidates.size())));
  placeStone(choice[0], choice[1], 2);    // ENGINE White
}

void keyPressed() {
  if (key == 'r' || key == 'R') {
    resetBoard();
  }
  // BACK / Undo key
  if (key == 'b' || key == 'B') {
    undoLastMove();
  }
}













