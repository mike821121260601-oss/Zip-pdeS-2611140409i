

// APDE / Processing
// 3D TERRAIN + TOUCH CONTROLS
// P3D

float camX = 0;
float camY = -250;
float camZ = 0;

float yaw = 0;       // left/right direction
float pitch = 0;     // up/down view angle

float moveSpeed = 8;

int terrainSize = 80;
float cell = 80;

float[][] terrain;

boolean upKey, downKey;
boolean leftKey, rightKey;
boolean angleLeft, angleRight;
boolean angleUp, angleDown;
boolean frontKey, backKey;

void setup() {
  fullScreen(P3D);

  terrain = new float[terrainSize][terrainSize];

  // Generate terrain
  for (int z = 0; z < terrainSize; z++) {
    for (int x = 0; x < terrainSize; x++) {

      float n1 = noise(x * 0.06, z * 0.06);
      float n2 = noise(x * 0.015, z * 0.015);

      terrain[x][z] =
        (n1 - 0.5) * 500 +
        (n2 - 0.5) * 1000;
    }
  }

  // Start near center
  camX = terrainSize * cell / 2;
  camZ = terrainSize * cell / 2;

  noStroke();
}

void draw() {
  background(70, 100, 150);

  updateControls();

  // Camera direction
  float dirX = sin(yaw);
  float dirZ = cos(yaw);

  float lookX = camX + dirX * 500;
  float lookZ = camZ + dirZ * 500;

  float lookY =
    camY +
    sin(pitch) * 500;

  camera(
    camX, camY, camZ,
    lookX, lookY, lookZ,
    0, 1, 0
  );

  lights();

  drawTerrain();

  // Draw controls after 3D scene
  hint(DISABLE_DEPTH_TEST);
  camera();
  drawKeys();
  hint(ENABLE_DEPTH_TEST);
}

// ------------------------------------------------
// TERRAIN
// ------------------------------------------------

void drawTerrain() {

  pushMatrix();

  translate(
    -terrainSize * cell / 2,
    0,
    -terrainSize * cell / 2
  );

  for (int z = 0; z < terrainSize - 1; z++) {

    beginShape(TRIANGLE_STRIP);

    for (int x = 0; x < terrainSize; x++) {

      float h1 = terrain[x][z];
      float h2 = terrain[x][z + 1];

      vertex(
        x * cell,
        h1,
        z * cell
      );

      vertex(
        x * cell,
        h2,
        (z + 1) * cell
      );
    }

    endShape();
  }

  popMatrix();
}

// ------------------------------------------------
// MOVEMENT
// ------------------------------------------------

void updateControls() {

  float speed = moveSpeed;

  // Forward / back
  if (upKey || frontKey) {
    camX += sin(yaw) * speed;
    camZ += cos(yaw) * speed;
  }

  if (downKey || backKey) {
    camX -= sin(yaw) * speed;
    camZ -= cos(yaw) * speed;
  }

  // Turn
  if (leftKey) {
    yaw -= 0.035;
  }

  if (rightKey) {
    yaw += 0.035;
  }

  // View angle left/right
  if (angleLeft) {
    yaw -= 0.025;
  }

  if (angleRight) {
    yaw += 0.025;
  }

  // Look up/down
  if (angleUp) {
    pitch -= 0.025;
  }

  if (angleDown) {
    pitch += 0.025;
  }

  pitch = constrain(
    pitch,
    -1.3,
    1.3
  );
}

// ------------------------------------------------
// TOUCH KEYS
// ------------------------------------------------

void drawKeys() {

  int w = width;
  int h = height;

  // Button dimensions
  int bw = w / 6;
  int bh = h / 12;

  // LEFT
  button(
    20,
    h - bh * 2 - 20,
    bw,
    bh,
    "LEFT"
  );

  // RIGHT
  button(
    40 + bw,
    h - bh * 2 - 20,
    bw,
    bh,
    "RIGHT"
  );

  // UP
  button(
    20 + bw / 2,
    h - bh * 3 - 30,
    bw,
    bh,
    "UP"
  );

  // DOWN
  button(
    20 + bw / 2,
    h - bh - 10,
    bw,
    bh,
    "DOWN"
  );

  // ANGLE LEFT
  button(
    w - bw * 2 - 30,
    h - bh * 3 - 30,
    bw,
    bh,
    "ANGLE L"
  );

  // ANGLE RIGHT
  button(
    w - bw - 20,
    h - bh * 3 - 30,
    bw,
    bh,
    "ANGLE R"
  );

  // ANGLE UP
  button(
    w - bw * 2 - 30,
    h - bh * 2 - 20,
    bw,
    bh,
    "ANGLE UP"
  );

  // ANGLE DOWN
  button(
    w - bw - 20,
    h - bh * 2 - 20,
    bw,
    bh,
    "ANGLE DOWN"
  );

  // FRONT
  button(
    w / 2 - bw - 10,
    h - bh - 10,
    bw,
    bh,
    "FRONT"
  );

  // BACK
  button(
    w / 2 + 10,
    h - bh - 10,
    bw,
    bh,
    "BACK"
  );
}

void button(
  int x,
  int y,
  int w,
  int h,
  String text
) {

  fill(30, 30, 30, 190);
  rect(x, y, w, h, 15);

  fill(255);
  textAlign(CENTER, CENTER);
  textSize(22);
  text(text, x + w/2, y + h/2);
}

// ------------------------------------------------
// TOUCH
// ------------------------------------------------

void touchStarted() {

  checkTouch(mouseX, mouseY, true);
}

void touchMoved() {

  checkTouch(mouseX, mouseY, true);
}

void touchEnded() {

  upKey = false;
  downKey = false;
  leftKey = false;
  rightKey = false;

  angleLeft = false;
  angleRight = false;
  angleUp = false;
  angleDown = false;

  frontKey = false;
  backKey = false;
}

void checkTouch(
  float tx,
  float ty,
  boolean pressed
) {

  int w = width;
  int h = height;

  int bw = w / 6;
  int bh = h / 12;

  upKey =
    inside(
      tx,
      ty,
      20 + bw/2,
      h - bh * 3 - 30,
      bw,
      bh
    );

  downKey =
    inside(
      tx,
      ty,
      20 + bw/2,
      h - bh - 10,
      bw,
      bh
    );

  leftKey =
    inside(
      tx,
      ty,
      20,
      h - bh * 2 - 20,
      bw,
      bh
    );

  rightKey =
    inside(
      tx,
      ty,
      40 + bw,
      h - bh * 2 - 20,
      bw,
      bh
    );

  angleLeft =
    inside(
      tx,
      ty,
      w - bw * 2 - 30,
      h - bh * 3 - 30,
      bw,
      bh
    );

  angleRight =
    inside(
      tx,
      ty,
      w - bw - 20,
      h - bh * 3 - 30,
      bw,
      bh
    );

  angleUp =
    inside(
      tx,
      ty,
      w - bw * 2 - 30,
      h - bh * 2 - 20,
      bw,
      bh
    );

  angleDown =
    inside(
      tx,
      ty,
      w - bw - 20,
      h - bh * 2 - 20,
      bw,
      bh
    );

  frontKey =
    inside(
      tx,
      ty,
      w/2 - bw - 10,
      h - bh - 10,
      bw,
      bh
    );

  backKey =
    inside(
      tx,
      ty,
      w/2 + 10,
      h - bh - 10,
      bw,
      bh
    );
}

boolean inside(
  float px,
  float py,
  float x,
  float y,
  float w,
  float h
) {

  return
    px >= x &&
    px <= x + w &&
    py >= y &&
    py <= y + h;
}



























