




















float cc=200;
float c=200;
float oo=222;
float o=222;
float t=0-111;
float cccc=random(11)-random(11);
float ccc=random(11)-random(11);
float oooo=random(11)-random(11);
float ooo=random(11)-random(11);
float ee=177;float e=177;
float eeee=random(11)-random(11);
float eee=random(11)-random(11);


float [] [] s=new float[99][8];









void setup() {
  size(displayWidth,displayHeight,P2D); 

orientation(PORTRAIT) ;

//fullScreen(P2D) ;
t=-111;noStroke() ;
}



void draw() {  

if(t<=0){t++;}
if(int(round(random(111111))) ==9){t=1;}
if((int(round(random(111))) ==9)&&
(t>=0)) {t=2;}





  

if(t==0-110){
//t=1;
noStroke() ;
for(int f=0;f<99;f++){
  s[f][1]=random(320);
    s[f][2]=random(555);
    s[f][3]=random(11)-random(11);
s[f][4]=random(11)-random(11);
    s[f][5]=round(random(255));
    s[f][6]=round(random(255));

s[f][7]=round(random(255));
}
}





if((t==1)||(t==0)||(t<0)){





  
 for(float f=0;f<11;f++){
  
  
for(int ff=0;ff<99;ff++){
s[ff][1]=s[ff][1]+s[ff][3];
s[ff][2]=s[ff][2]+s[ff][4];

if(s[ff][1]<0){s[ff][1]=0;
s[ff][3]=-s[ff][3];}

if(s[ff][2]<0){s[ff][2]=0;
s[ff][4]=-s[ff][4];}

if(s[ff][1]>displayWidth ){
s[ff][1]=displayWidth ;
s[ff][3]=-s[ff][3];}

if(s[ff][2]>displayHeight ){
s[ff][2]=displayHeight ;
s[ff][4]=-s[ff][4];}



fill(s[ff] [5],s[ff][6],s[ff][7]);
ellipse(s[ff][1],s[ff][2],22,22);

}




 oo=oo+oooo;
 cc=cc+cccc;
 c=c+ccc;o=o+ooo; 
  ee=ee+eeee;
  e=e+eee;
  
  if(oo>displayWidth) {
    oo=displayWidth;oooo=-oooo;
  }
  
  if(cc>displayWidth) {
    cc=displayWidth;cccc=-cccc;
  }
  
  if(oo<0){
    oo=0;oooo=-oooo;
  }
  
  if(cc<0){
    cc=0;cccc=-cccc;
  }
  
  
  
  
  
  
  
  
  if(o>displayHeight) {
    o=displayHeight;ooo=-ooo;
  }
  if(c>displayHeight) {
    c=displayHeight;ccc=-ccc;
  }
  if(c<0){
    c=0;ccc=-ccc;
  }
  
  if(o<0){
    o=0;ooo=-ooo;
  }
  
  
  
  
  if(e<0){e=0;eee=-eee;}
  if(e>displayHeight){
    e=displayHeight;eee=-eee;
  }
  
  
  if(ee<0){
    ee=0;eeee=-eeee;
  }
  
  if(ee>displayWidth){
    ee=displayWidth;
    eeee=-eeee;
  }
  
  
  
  
  
  fill(1,255,1);
  ellipse(ee,e,22, 22);
fill(255,1,1);  
  ellipse(cc, c, 22,22);
  fill(1,1,255);
  ellipse(oo,o,22,22);
  
}
  
}

} 









