




// Simple Chess for APDE 0.5.3
// Board: only rectangles, no text
// Portrait  -> board at bottom
// Landscape -> board on left
// Engine: very small & easy (low Elo)

int boardSize;
int squareSize;
int boardX, boardY;
boolean isPortrait;

// Board representation (0=empty, 1-6 white, 7-12 black)
// 1=P,2=N,3=B,4=R,5=Q,6=K
int[] board = new int[64];

// Piece colors
color lightSq = color(240, 217, 181);
color darkSq  = color(181, 136, 99);
color whitePiece = color(255);
color blackPiece = color(30);
color selectCol = color(255, 255, 0, 120);
color moveCol   = color(0, 255, 0, 100);

int selected = -1;
boolean whiteToMove = true;
boolean gameOver = false;
String status = "";

// Simple piece values for evaluation
int[] pieceVal = {0, 100, 320, 330, 500, 900, 20000};

void setup() {
  // APDE will handle size, but we force orientation awareness
  orientation(PORTRAIT); // start in portrait, will adapt
  size(displayWidth, displayHeight);
  textAlign(CENTER, CENTER);
  initBoard();
  calculateLayout();
}

void draw() {
  background(40);
  calculateLayout();
  drawBoard();
  drawPieces();
  
  // Status bar
  fill(220);
  textSize(18);
  if (isPortrait) {
    text(status, width/2, 30);
  } else {
    text(status, width - 100, height/2);
  }
}

void calculateLayout() {
  isPortrait = (height > width);
  
  if (isPortrait) {
    // Board at bottom
    boardSize = round(min(width, height * 0.7)) ;
    squareSize = boardSize / 8;
    boardX = (width - boardSize) / 2;
    boardY = height - boardSize - 20;
  } else {
    // Board on left
    boardSize = round(min(height, width * 0.7)) ;
    squareSize = boardSize / 8;
    boardX = 20;
    boardY = (height - boardSize) / 2;
  }
}

void initBoard() {
  // Standard starting position
  int[] start = {
    10,8,9,11,12,9,8,10,
    7,7,7,7,7,7,7,7,
    0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,
    1,1,1,1,1,1,1,1,
    4,2,3,5,6,3,2,4
  };
  for (int i=0; i<64; i++) board[i] = start[i];
  whiteToMove = true;
  selected = -1;
  gameOver = false;
  status = "White to move";
}

void drawBoard() {
  for (int r=0; r<8; r++) {
    for (int c=0; c<8; c++) {
      int sq = r*8 + c;
      boolean light = ((r + c) % 2 == 0);
      fill(light ? lightSq : darkSq);
      noStroke();
      rect(boardX + c*squareSize, boardY + r*squareSize, squareSize, squareSize);
      
      // Highlight
      if (sq == selected) {
        fill(selectCol);
        rect(boardX + c*squareSize, boardY + r*squareSize, squareSize, squareSize);
      }
    }
  }
}

void drawPieces() {
  for (int i=0; i<64; i++) {
    if (board[i] == 0) continue;
    int r = i / 8;
    int c = i % 8;
    float cx = boardX + c*squareSize + squareSize/2;
    float cy = boardY + r*squareSize + squareSize/2;
    float s = squareSize * 0.7;
    
    boolean isWhite = board[i] <= 6;
    fill(isWhite ? whitePiece : blackPiece);
    stroke(isWhite ? 80 : 200);
    strokeWeight(2);
    
    int p = board[i] > 6 ? board[i]-6 : board[i];
    
    // Simple geometric pieces (no text)
    switch(p) {
      case 1: // Pawn - circle
        ellipse(cx, cy, s*0.6, s*0.6);
        break;
      case 2: // Knight - triangle
        triangle(cx, cy-s*0.4, cx-s*0.35, cy+s*0.35, cx+s*0.35, cy+s*0.35);
        break;
      case 3: // Bishop - diamond
        quad(cx, cy-s*0.4, cx+s*0.3, cy, cx, cy+s*0.4, cx-s*0.3, cy);
        break;
      case 4: // Rook - square
        rect(cx-s*0.3, cy-s*0.3, s*0.6, s*0.6);
        break;
      case 5: // Queen - circle + cross
        ellipse(cx, cy, s*0.7, s*0.7);
        line(cx-s*0.25, cy, cx+s*0.25, cy);
        line(cx, cy-s*0.25, cx, cy+s*0.25);
        break;
      case 6: // King - cross
        strokeWeight(4);
        line(cx-s*0.3, cy, cx+s*0.3, cy);
        line(cx, cy-s*0.3, cx, cy+s*0.3);
        noFill();
        ellipse(cx, cy, s*0.5, s*0.5);
        break;
    }
  }
}

void mousePressed() {
  if (gameOver) {
    initBoard();
    return;
  }
  
  int c = (mouseX - boardX) / squareSize;
  int r = (mouseY - boardY) / squareSize;
  if (c < 0 || c > 7 || r < 0 || r > 7) return;
  
  int sq = r*8 + c;
  
  if (selected == -1) {
    // Select own piece
    if (board[sq] != 0) {
      boolean isWhite = board[sq] <= 6;
      if (isWhite == whiteToMove) {
        selected = sq;
      }
    }
  } else {
    if (sq == selected) {
      selected = -1;
    } else {
      // Try move
      if (isLegal(selected, sq)) {
        makeMove(selected, sq);
        selected = -1;
        whiteToMove = !whiteToMove;
        status = whiteToMove ? "White to move" : "Black thinking...";
        
        // Engine move (Black)
        if (!whiteToMove && !gameOver) {
          delay(300);
          engineMove();
        }
      } else {
        // Reselect if own piece
        if (board[sq] != 0) {
          boolean isWhite = board[sq] <= 6;
          if (isWhite == whiteToMove) selected = sq;
          else selected = -1;
        } else {
          selected = -1;
        }
      }
    }
  }
}

boolean isLegal(int from, int to) {
  if (from < 0 || from > 63 || to < 0 || to > 63) return false;
  if (board[from] == 0) return false;
  
  boolean isWhite = board[from] <= 6;
  if (board[to] != 0) {
    boolean targetWhite = board[to] <= 6;
    if (isWhite == targetWhite) return false; // cannot capture own
  }
  
  int piece = board[from] > 6 ? board[from]-6 : board[from];
  int fr = from / 8, fc = from % 8;
  int tr = to / 8, tc = to % 8;
  int dr = tr - fr, dc = tc - fc;
  
  // Very simplified legality (enough for a small engine)
  switch(piece) {
    case 1: // Pawn
      if (isWhite) {
        if (dc == 0 && dr == -1 && board[to] == 0) return true;
        if (dc == 0 && dr == -2 && fr == 6 && board[to] == 0 && board[from-8] == 0) return true;
        if (abs(dc) == 1 && dr == -1 && board[to] != 0) return true;
      } else {
        if (dc == 0 && dr == 1 && board[to] == 0) return true;
        if (dc == 0 && dr == 2 && fr == 1 && board[to] == 0 && board[from+8] == 0) return true;
        if (abs(dc) == 1 && dr == 1 && board[to] != 0) return true;
      }
      return false;
    case 2: // Knight
      return (abs(dr)==2 && abs(dc)==1) || (abs(dr)==1 && abs(dc)==2);
    case 3: // Bishop
      if (abs(dr) != abs(dc)) return false;
      return clearPath(from, to);
    case 4: // Rook
      if (dr != 0 && dc != 0) return false;
      return clearPath(from, to);
    case 5: // Queen
      if (dr != 0 && dc != 0 && abs(dr) != abs(dc)) return false;
      return clearPath(from, to);
    case 6: // King
      return abs(dr) <= 1 && abs(dc) <= 1;
  }
  return false;
}

boolean clearPath(int from, int to) {
  int fr = from/8, fc = from%8;
  int tr = to/8, tc = to%8;
  int dr = Integer.signum(tr-fr);
  int dc = Integer.signum(tc-fc);
  int r = fr + dr, c = fc + dc;
  while (r != tr || c != tc) {
    if (board[r*8 + c] != 0) return false;
    r += dr; c += dc;
  }
  return true;
}

void makeMove(int from, int to) {
  // Promotion (always to Queen for simplicity)
  int piece = board[from];
  if (piece == 1 && to < 8) piece = 5;      // white pawn -> Q
  if (piece == 7 && to > 55) piece = 11;    // black pawn -> q
  
  board[to] = piece;
  board[from] = 0;
  
  // Very basic checkmate detection (king captured)
  boolean whiteKing = false, blackKing = false;
  for (int i=0; i<64; i++) {
    if (board[i] == 6) whiteKing = true;
    if (board[i] == 12) blackKing = true;
  }
  if (!whiteKing) { gameOver = true; status = "Black wins!"; }
  if (!blackKing) { gameOver = true; status = "White wins!"; }
}

// ========== SMALL ENGINE ==========
// Extremely simple: generate legal moves + 1-ply evaluation
void engineMove() {
  ArrayList<int[]> moves = generateMoves(false); // black moves
  if (moves.size() == 0) {
    gameOver = true;
    status = "White wins! (no moves)";
    return;
  }
  
  // Pick best by simple material + random
  int bestScore = -999999;
  int[] best = moves.get(0);
  
  for (int[] m : moves) {
    int score = evaluateMove(m[0], m[1]);
    score += (int)random(-30, 30); // small randomness
    if (score > bestScore) {
      bestScore = score;
      best = m;
    }
  }
  
  makeMove(best[0], best[1]);
  whiteToMove = true;
  status = "White to move";
}

ArrayList<int[]> generateMoves(boolean forWhite) {
  ArrayList<int[]> list = new ArrayList<int[]>();
  for (int from=0; from<64; from++) {
    if (board[from] == 0) continue;
    boolean isWhite = board[from] <= 6;
    if (isWhite != forWhite) continue;
    
    for (int to=0; to<64; to++) {
      if (isLegal(from, to)) {
        list.add(new int[]{from, to});
      }
    }
  }
  return list;
}

int evaluateMove(int from, int to) {
  // Simple material evaluation after move
  int captured = board[to];
  int score = 0;
  if (captured != 0) {
    int p = captured > 6 ? captured-6 : captured;
    score += pieceVal[p];
  }
  // Prefer center
  int tr = to/8, tc = to%8;
  score += (3 - abs(3.5-tr)) + (3 - abs(3.5-tc));
  return score;
}

void keyPressed() {
  if (key == 'r' || key == 'R') initBoard();
}








/*



// Simple Chess for APDE 0.5.3
// Board: only rectangles, no text
// Portrait  -> board at bottom
// Landscape -> board on left
// Engine: very small & easy (low Elo)

int boardSize;
int squareSize;
int boardX, boardY;
boolean isPortrait;

// Board representation (0=empty, 1-6 white, 7-12 black)
// 1=P,2=N,3=B,4=R,5=Q,6=K
int[] board = new int[64];

// Piece colors
color lightSq = color(240, 217, 181);
color darkSq  = color(181, 136, 99);
color whitePiece = color(255);
color blackPiece = color(30);
color selectCol = color(255, 255, 0, 120);
color moveCol   = color(0, 255, 0, 100);

int selected = -1;
boolean whiteToMove = true;
boolean gameOver = false;
String status = "";

// Simple piece values for evaluation
int[] pieceVal = {0, 100, 320, 330, 500, 900, 20000};

void setup() {
  // APDE will handle size, but we force orientation awareness
  orientation(PORTRAIT); // start in portrait, will adapt
  size(displayWidth, displayHeight);
  textAlign(CENTER, CENTER);
  initBoard();
  calculateLayout();
}

void draw() {
  background(40);
  calculateLayout();
  drawBoard();
  drawPieces();
  
  // Status bar
  fill(220);
  textSize(18);
  if (isPortrait) {
    text(status, width/2, 30);
  } else {
    text(status, width - 100, height/2);
  }
}

void calculateLayout() {
  isPortrait = (height > width);
  
  if (isPortrait) {
    // Board at bottom
    boardSize = round(min(width, height * 0.7)) ;
    squareSize = boardSize / 8;
    boardX = (width - boardSize) / 2;
    boardY = height - boardSize - 20;
  } else {
    // Board on left
    boardSize = round(min(height, width * 0.7)) ;
    squareSize = boardSize / 8;
    boardX = 20;
    boardY = (height - boardSize) / 2;
  }
}

void initBoard() {
  // Standard starting position
  int[] start = {
    10,8,9,11,12,9,8,10,
    7,7,7,7,7,7,7,7,
    0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,
    1,1,1,1,1,1,1,1,
    4,2,3,5,6,3,2,4
  };
  for (int i=0; i<64; i++) board[i] = start[i];
  whiteToMove = true;
  selected = -1;
  gameOver = false;
  status = "White to move";
}

void drawBoard() {
  for (int r=0; r<8; r++) {
    for (int c=0; c<8; c++) {
      int sq = r*8 + c;
      boolean light = ((r + c) % 2 == 0);
      fill(light ? lightSq : darkSq);
      noStroke();
      rect(boardX + c*squareSize, boardY + r*squareSize, squareSize, squareSize);
      
      // Highlight
      if (sq == selected) {
        fill(selectCol);
        rect(boardX + c*squareSize, boardY + r*squareSize, squareSize, squareSize);
      }
    }
  }
}

void drawPieces() {
  for (int i=0; i<64; i++) {
    if (board[i] == 0) continue;
    int r = i / 8;
    int c = i % 8;
    float cx = boardX + c*squareSize + squareSize/2;
    float cy = boardY + r*squareSize + squareSize/2;
    float s = squareSize * 0.7;
    
    boolean isWhite = board[i] <= 6;
    fill(isWhite ? whitePiece : blackPiece);
    stroke(isWhite ? 80 : 200);
    strokeWeight(2);
    
    int p = board[i] > 6 ? board[i]-6 : board[i];
    
    // Simple geometric pieces (no text)
    switch(p) {
      case 1: // Pawn - circle
        ellipse(cx, cy, s*0.6, s*0.6);
        break;
      case 2: // Knight - triangle
        triangle(cx, cy-s*0.4, cx-s*0.35, cy+s*0.35, cx+s*0.35, cy+s*0.35);
        break;
      case 3: // Bishop - diamond
        quad(cx, cy-s*0.4, cx+s*0.3, cy, cx, cy+s*0.4, cx-s*0.3, cy);
        break;
      case 4: // Rook - square
        rect(cx-s*0.3, cy-s*0.3, s*0.6, s*0.6);
        break;
      case 5: // Queen - circle + cross
        ellipse(cx, cy, s*0.7, s*0.7);
        line(cx-s*0.25, cy, cx+s*0.25, cy);
        line(cx, cy-s*0.25, cx, cy+s*0.25);
        break;
      case 6: // King - cross
        strokeWeight(4);
        line(cx-s*0.3, cy, cx+s*0.3, cy);
        line(cx, cy-s*0.3, cx, cy+s*0.3);
        noFill();
        ellipse(cx, cy, s*0.5, s*0.5);
        break;
    }
  }
}

void mousePressed() {
  if (gameOver) {
    initBoard();
    return;
  }
  
  int c = (mouseX - boardX) / squareSize;
  int r = (mouseY - boardY) / squareSize;
  if (c < 0 || c > 7 || r < 0 || r > 7) return;
  
  int sq = r*8 + c;
  
  if (selected == -1) {
    // Select own piece
    if (board[sq] != 0) {
      boolean isWhite = board[sq] <= 6;
      if (isWhite == whiteToMove) {
        selected = sq;
      }
    }
  } else {
    if (sq == selected) {
      selected = -1;
    } else {
      // Try move
      if (isLegal(selected, sq)) {
        makeMove(selected, sq);
        selected = -1;
        whiteToMove = !whiteToMove;
        status = whiteToMove ? "White to move" : "Black thinking...";
        
        // Engine move (Black)
        if (!whiteToMove && !gameOver) {
          delay(300);
          engineMove();
        }
      } else {
        // Reselect if own piece
        if (board[sq] != 0) {
          boolean isWhite = board[sq] <= 6;
          if (isWhite == whiteToMove) selected = sq;
          else selected = -1;
        } else {
          selected = -1;
        }
      }
    }
  }
}

boolean isLegal(int from, int to) {
  if (from < 0 || from > 63 || to < 0 || to > 63) return false;
  if (board[from] == 0) return false;
  
  boolean isWhite = board[from] <= 6;
  if (board[to] != 0) {
    boolean targetWhite = board[to] <= 6;
    if (isWhite == targetWhite) return false; // cannot capture own
  }
  
  int piece = board[from] > 6 ? board[from]-6 : board[from];
  int fr = from / 8, fc = from % 8;
  int tr = to / 8, tc = to % 8;
  int dr = tr - fr, dc = tc - fc;
  
  // Very simplified legality (enough for a small engine)
  switch(piece) {
    case 1: // Pawn
      if (isWhite) {
        if (dc == 0 && dr == -1 && board[to] == 0) return true;
        if (dc == 0 && dr == -2 && fr == 6 && board[to] == 0 && board[from-8] == 0) return true;
        if (abs(dc) == 1 && dr == -1 && board[to] != 0) return true;
      } else {
        if (dc == 0 && dr == 1 && board[to] == 0) return true;
        if (dc == 0 && dr == 2 && fr == 1 && board[to] == 0 && board[from+8] == 0) return true;
        if (abs(dc) == 1 && dr == 1 && board[to] != 0) return true;
      }
      return false;
    case 2: // Knight
      return (abs(dr)==2 && abs(dc)==1) || (abs(dr)==1 && abs(dc)==2);
    case 3: // Bishop
      if (abs(dr) != abs(dc)) return false;
      return clearPath(from, to);
    case 4: // Rook
      if (dr != 0 && dc != 0) return false;
      return clearPath(from, to);
    case 5: // Queen
      if (dr != 0 && dc != 0 && abs(dr) != abs(dc)) return false;
      return clearPath(from, to);
    case 6: // King
      return abs(dr) <= 1 && abs(dc) <= 1;
  }
  return false;
}

boolean clearPath(int from, int to) {
  int fr = from/8, fc = from%8;
  int tr = to/8, tc = to%8;
  int dr = Integer.signum(tr-fr);
  int dc = Integer.signum(tc-fc);
  int r = fr + dr, c = fc + dc;
  while (r != tr || c != tc) {
    if (board[r*8 + c] != 0) return false;
    r += dr; c += dc;
  }
  return true;
}

void makeMove(int from, int to) {
  // Promotion (always to Queen for simplicity)
  int piece = board[from];
  if (piece == 1 && to < 8) piece = 5;      // white pawn -> Q
  if (piece == 7 && to > 55) piece = 11;    // black pawn -> q
  
  board[to] = piece;
  board[from] = 0;
  
  // Very basic checkmate detection (king captured)
  boolean whiteKing = false, blackKing = false;
  for (int i=0; i<64; i++) {
    if (board[i] == 6) whiteKing = true;
    if (board[i] == 12) blackKing = true;
  }
  if (!whiteKing) { gameOver = true; status = "Black wins!"; }
  if (!blackKing) { gameOver = true; status = "White wins!"; }
}

// ========== SMALL ENGINE ==========
// Extremely simple: generate legal moves + 1-ply evaluation
void engineMove() {
  ArrayList<int[]> moves = generateMoves(false); // black moves
  if (moves.size() == 0) {
    gameOver = true;
    status = "White wins! (no moves)";
    return;
  }
  
  // Pick best by simple material + random
  int bestScore = -999999;
  int[] best = moves.get(0);
  
  for (int[] m : moves) {
    int score = evaluateMove(m[0], m[1]);
    score += (int)random(-30, 30); // small randomness
    if (score > bestScore) {
      bestScore = score;
      best = m;
    }
  }
  
  makeMove(best[0], best[1]);
  whiteToMove = true;
  status = "White to move";
}

ArrayList<int[]> generateMoves(boolean forWhite) {
  ArrayList<int[]> list = new ArrayList<int[]>();
  for (int from=0; from<64; from++) {
    if (board[from] == 0) continue;
    boolean isWhite = board[from] <= 6;
    if (isWhite != forWhite) continue;
    
    for (int to=0; to<64; to++) {
      if (isLegal(from, to)) {
        list.add(new int[]{from, to});
      }
    }
  }
  return list;
}

int evaluateMove(int from, int to) {
  // Simple material evaluation after move
  int captured = board[to];
  int score = 0;
  if (captured != 0) {
    int p = captured > 6 ? captured-6 : captured;
    score += pieceVal[p];
  }
  // Prefer center
  int tr = to/8, tc = to%8;
  score += (3 - abs(3.5-tr)) + (3 - abs(3.5-tc));
  return score;
}

void keyPressed() {
  if (key == 'r' || key == 'R') initBoard();
}










// Simple Chess for APDE 0.5.3
// Board: only rectangles, no text
// Portrait  -> board at bottom
// Landscape -> board on left
// Engine: very small & easy (low Elo)

int boardSize;
int squareSize;
int boardX, boardY;
boolean isPortrait;

// Board representation (0=empty, 1-6 white, 7-12 black)
// 1=P,2=N,3=B,4=R,5=Q,6=K
int[] board = new int[64];

// Piece colors
color lightSq = color(240, 217, 181);
color darkSq  = color(181, 136, 99);
color whitePiece = color(255);
color blackPiece = color(30);
color selectCol = color(255, 255, 0, 120);
color moveCol   = color(0, 255, 0, 100);

int selected = -1;
boolean whiteToMove = true;
boolean gameOver = false;
String status = "";

// Simple piece values for evaluation
int[] pieceVal = {0, 100, 320, 330, 500, 900, 20000};

void setup() {
  // APDE will handle size, but we force orientation awareness
  orientation(PORTRAIT); // start in portrait, will adapt
  size(displayWidth, displayHeight);
  textAlign(CENTER, CENTER);
  initBoard();
  calculateLayout();
}

void draw() {
  background(40);
  calculateLayout();
  drawBoard();
  drawPieces();
  
  // Status bar
  fill(220);
  textSize(18);
  if (isPortrait) {
    text(status, width/2, 30);
  } else {
    text(status, width - 100, height/2);
  }
}

void calculateLayout() {
  isPortrait = (height > width);
  
  if (isPortrait) {
    // Board at bottom
    boardSize = round(min(width, height * 0.7)) ;
    squareSize = boardSize / 8;
    boardX = (width - boardSize) / 2;
    boardY = height - boardSize - 20;
  } else {
    // Board on left
    boardSize = round(min(height, width * 0.7)) ;
    squareSize = boardSize / 8;
    boardX = 20;
    boardY = (height - boardSize) / 2;
  }
}

void initBoard() {
  // Standard starting position
  int[] start = {
    10,8,9,11,12,9,8,10,
    7,7,7,7,7,7,7,7,
    0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,
    1,1,1,1,1,1,1,1,
    4,2,3,5,6,3,2,4
  };
  for (int i=0; i<64; i++) board[i] = start[i];
  whiteToMove = true;
  selected = -1;
  gameOver = false;
  status = "White to move";
}

void drawBoard() {
  for (int r=0; r<8; r++) {
    for (int c=0; c<8; c++) {
      int sq = r*8 + c;
      boolean light = ((r + c) % 2 == 0);
      fill(light ? lightSq : darkSq);
      noStroke();
      rect(boardX + c*squareSize, boardY + r*squareSize, squareSize, squareSize);
      
      // Highlight
      if (sq == selected) {
        fill(selectCol);
        rect(boardX + c*squareSize, boardY + r*squareSize, squareSize, squareSize);
      }
    }
  }
}

void drawPieces() {
  for (int i=0; i<64; i++) {
    if (board[i] == 0) continue;
    int r = i / 8;
    int c = i % 8;
    float cx = boardX + c*squareSize + squareSize/2;
    float cy = boardY + r*squareSize + squareSize/2;
    float s = squareSize * 0.7;
    
    boolean isWhite = board[i] <= 6;
    fill(isWhite ? whitePiece : blackPiece);
    stroke(isWhite ? 80 : 200);
    strokeWeight(2);
    
    int p = board[i] > 6 ? board[i]-6 : board[i];
    
    // Simple geometric pieces (no text)
    switch(p) {
      case 1: // Pawn - circle
        ellipse(cx, cy, s*0.6, s*0.6);
        break;
      case 2: // Knight - triangle
        triangle(cx, cy-s*0.4, cx-s*0.35, cy+s*0.35, cx+s*0.35, cy+s*0.35);
        break;
      case 3: // Bishop - diamond
        quad(cx, cy-s*0.4, cx+s*0.3, cy, cx, cy+s*0.4, cx-s*0.3, cy);
        break;
      case 4: // Rook - square
        rect(cx-s*0.3, cy-s*0.3, s*0.6, s*0.6);
        break;
      case 5: // Queen - circle + cross
        ellipse(cx, cy, s*0.7, s*0.7);
        line(cx-s*0.25, cy, cx+s*0.25, cy);
        line(cx, cy-s*0.25, cx, cy+s*0.25);
        break;
      case 6: // King - cross
        strokeWeight(4);
        line(cx-s*0.3, cy, cx+s*0.3, cy);
        line(cx, cy-s*0.3, cx, cy+s*0.3);
        noFill();
        ellipse(cx, cy, s*0.5, s*0.5);
        break;
    }
  }
}

void mousePressed() {
  if (gameOver) {
    initBoard();
    return;
  }
  
  int c = (mouseX - boardX) / squareSize;
  int r = (mouseY - boardY) / squareSize;
  if (c < 0 || c > 7 || r < 0 || r > 7) return;
  
  int sq = r*8 + c;
  
  if (selected == -1) {
    // Select own piece
    if (board[sq] != 0) {
      boolean isWhite = board[sq] <= 6;
      if (isWhite == whiteToMove) {
        selected = sq;
      }
    }
  } else {
    if (sq == selected) {
      selected = -1;
    } else {
      // Try move
      if (isLegal(selected, sq)) {
        makeMove(selected, sq);
        selected = -1;
        whiteToMove = !whiteToMove;
        status = whiteToMove ? "White to move" : "Black thinking...";
        
        // Engine move (Black)
        if (!whiteToMove && !gameOver) {
          delay(300);
          engineMove();
        }
      } else {
        // Reselect if own piece
        if (board[sq] != 0) {
          boolean isWhite = board[sq] <= 6;
          if (isWhite == whiteToMove) selected = sq;
          else selected = -1;
        } else {
          selected = -1;
        }
      }
    }
  }
}

boolean isLegal(int from, int to) {
  if (from < 0 || from > 63 || to < 0 || to > 63) return false;
  if (board[from] == 0) return false;
  
  boolean isWhite = board[from] <= 6;
  if (board[to] != 0) {
    boolean targetWhite = board[to] <= 6;
    if (isWhite == targetWhite) return false; // cannot capture own
  }
  
  int piece = board[from] > 6 ? board[from]-6 : board[from];
  int fr = from / 8, fc = from % 8;
  int tr = to / 8, tc = to % 8;
  int dr = tr - fr, dc = tc - fc;
  
  // Very simplified legality (enough for a small engine)
  switch(piece) {
    case 1: // Pawn
      if (isWhite) {
        if (dc == 0 && dr == -1 && board[to] == 0) return true;
        if (dc == 0 && dr == -2 && fr == 6 && board[to] == 0 && board[from-8] == 0) return true;
        if (abs(dc) == 1 && dr == -1 && board[to] != 0) return true;
      } else {
        if (dc == 0 && dr == 1 && board[to] == 0) return true;
        if (dc == 0 && dr == 2 && fr == 1 && board[to] == 0 && board[from+8] == 0) return true;
        if (abs(dc) == 1 && dr == 1 && board[to] != 0) return true;
      }
      return false;
    case 2: // Knight
      return (abs(dr)==2 && abs(dc)==1) || (abs(dr)==1 && abs(dc)==2);
    case 3: // Bishop
      if (abs(dr) != abs(dc)) return false;
      return clearPath(from, to);
    case 4: // Rook
      if (dr != 0 && dc != 0) return false;
      return clearPath(from, to);
    case 5: // Queen
      if (dr != 0 && dc != 0 && abs(dr) != abs(dc)) return false;
      return clearPath(from, to);
    case 6: // King
      return abs(dr) <= 1 && abs(dc) <= 1;
  }
  return false;
}

boolean clearPath(int from, int to) {
  int fr = from/8, fc = from%8;
  int tr = to/8, tc = to%8;
  int dr = Integer.signum(tr-fr);
  int dc = Integer.signum(tc-fc);
  int r = fr + dr, c = fc + dc;
  while (r != tr || c != tc) {
    if (board[r*8 + c] != 0) return false;
    r += dr; c += dc;
  }
  return true;
}

void makeMove(int from, int to) {
  // Promotion (always to Queen for simplicity)
  int piece = board[from];
  if (piece == 1 && to < 8) piece = 5;      // white pawn -> Q
  if (piece == 7 && to > 55) piece = 11;    // black pawn -> q
  
  board[to] = piece;
  board[from] = 0;
  
  // Very basic checkmate detection (king captured)
  boolean whiteKing = false, blackKing = false;
  for (int i=0; i<64; i++) {
    if (board[i] == 6) whiteKing = true;
    if (board[i] == 12) blackKing = true;
  }
  if (!whiteKing) { gameOver = true; status = "Black wins!"; }
  if (!blackKing) { gameOver = true; status = "White wins!"; }
}

// ========== SMALL ENGINE ==========
// Extremely simple: generate legal moves + 1-ply evaluation
void engineMove() {
  ArrayList<int[]> moves = generateMoves(false); // black moves
  if (moves.size() == 0) {
    gameOver = true;
    status = "White wins! (no moves)";
    return;
  }
  
  // Pick best by simple material + random
  int bestScore = -999999;
  int[] best = moves.get(0);
  
  for (int[] m : moves) {
    int score = evaluateMove(m[0], m[1]);
    score += (int)random(-30, 30); // small randomness
    if (score > bestScore) {
      bestScore = score;
      best = m;
    }
  }
  
  makeMove(best[0], best[1]);
  whiteToMove = true;
  status = "White to move";
}

ArrayList<int[]> generateMoves(boolean forWhite) {
  ArrayList<int[]> list = new ArrayList<int[]>();
  for (int from=0; from<64; from++) {
    if (board[from] == 0) continue;
    boolean isWhite = board[from] <= 6;
    if (isWhite != forWhite) continue;
    
    for (int to=0; to<64; to++) {
      if (isLegal(from, to)) {
        list.add(new int[]{from, to});
      }
    }
  }
  return list;
}

int evaluateMove(int from, int to) {
  // Simple material evaluation after move
  int captured = board[to];
  int score = 0;
  if (captured != 0) {
    int p = captured > 6 ? captured-6 : captured;
    score += pieceVal[p];
  }
  // Prefer center
  int tr = to/8, tc = to%8;
  score += (3 - abs(3.5-tr)) + (3 - abs(3.5-tc));
  return score;
}

void keyPressed() {
  if (key == 'r' || key == 'R') initBoard();
}






// Simple Chess for APDE 0.5.3
// Board: only rectangles, no text
// Portrait  -> board at bottom
// Landscape -> board on left
// Engine: very small & easy (low Elo)

int boardSize;
int squareSize;
int boardX, boardY;
boolean isPortrait;

// Board representation (0=empty, 1-6 white, 7-12 black)
// 1=P,2=N,3=B,4=R,5=Q,6=K
int[] board = new int[64];

// Piece colors
color lightSq = color(240, 217, 181);
color darkSq  = color(181, 136, 99);
color whitePiece = color(255);
color blackPiece = color(30);
color selectCol = color(255, 255, 0, 120);
color moveCol   = color(0, 255, 0, 100);

int selected = -1;
boolean whiteToMove = true;
boolean gameOver = false;
String status = "";

// Simple piece values for evaluation
int[] pieceVal = {0, 100, 320, 330, 500, 900, 20000};

void setup() {
  // APDE will handle size, but we force orientation awareness
  orientation(PORTRAIT); // start in portrait, will adapt
  size(displayWidth, displayHeight);
  textAlign(CENTER, CENTER);
  initBoard();
  calculateLayout();
}

void draw() {
  background(40);
  calculateLayout();
  drawBoard();
  drawPieces();
  
  // Status bar
  fill(220);
  textSize(18);
  if (isPortrait) {
    text(status, width/2, 30);
  } else {
    text(status, width - 100, height/2);
  }
}

void calculateLayout() {
  isPortrait = (height > width);
  
  if (isPortrait) {
    // Board at bottom
    boardSize = round(min(width, height * 0.7)) ;
    squareSize = boardSize / 8;
    boardX = (width - boardSize) / 2;
    boardY = height - boardSize - 20;
  } else {
    // Board on left
    boardSize = round(min(height, width * 0.7)) ;
    squareSize = boardSize / 8;
    boardX = 20;
    boardY = (height - boardSize) / 2;
  }
}

void initBoard() {
  // Standard starting position
  int[] start = {
    10,8,9,11,12,9,8,10,
    7,7,7,7,7,7,7,7,
    0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,
    1,1,1,1,1,1,1,1,
    4,2,3,5,6,3,2,4
  };
  for (int i=0; i<64; i++) board[i] = start[i];
  whiteToMove = true;
  selected = -1;
  gameOver = false;
  status = "White to move";
}

void drawBoard() {
  for (int r=0; r<8; r++) {
    for (int c=0; c<8; c++) {
      int sq = r*8 + c;
      boolean light = ((r + c) % 2 == 0);
      fill(light ? lightSq : darkSq);
      noStroke();
      rect(boardX + c*squareSize, boardY + r*squareSize, squareSize, squareSize);
      
      // Highlight
      if (sq == selected) {
        fill(selectCol);
        rect(boardX + c*squareSize, boardY + r*squareSize, squareSize, squareSize);
      }
    }
  }
}

void drawPieces() {
  for (int i=0; i<64; i++) {
    if (board[i] == 0) continue;
    int r = i / 8;
    int c = i % 8;
    float cx = boardX + c*squareSize + squareSize/2;
    float cy = boardY + r*squareSize + squareSize/2;
    float s = squareSize * 0.7;
    
    boolean isWhite = board[i] <= 6;
    fill(isWhite ? whitePiece : blackPiece);
    stroke(isWhite ? 80 : 200);
    strokeWeight(2);
    
    int p = board[i] > 6 ? board[i]-6 : board[i];
    
    // Simple geometric pieces (no text)
    switch(p) {
      case 1: // Pawn - circle
        ellipse(cx, cy, s*0.6, s*0.6);
        break;
      case 2: // Knight - triangle
        triangle(cx, cy-s*0.4, cx-s*0.35, cy+s*0.35, cx+s*0.35, cy+s*0.35);
        break;
      case 3: // Bishop - diamond
        quad(cx, cy-s*0.4, cx+s*0.3, cy, cx, cy+s*0.4, cx-s*0.3, cy);
        break;
      case 4: // Rook - square
        rect(cx-s*0.3, cy-s*0.3, s*0.6, s*0.6);
        break;
      case 5: // Queen - circle + cross
        ellipse(cx, cy, s*0.7, s*0.7);
        line(cx-s*0.25, cy, cx+s*0.25, cy);
        line(cx, cy-s*0.25, cx, cy+s*0.25);
        break;
      case 6: // King - cross
        strokeWeight(4);
        line(cx-s*0.3, cy, cx+s*0.3, cy);
        line(cx, cy-s*0.3, cx, cy+s*0.3);
        noFill();
        ellipse(cx, cy, s*0.5, s*0.5);
        break;
    }
  }
}

void mousePressed() {
  if (gameOver) {
    initBoard();
    return;
  }
  
  int c = (mouseX - boardX) / squareSize;
  int r = (mouseY - boardY) / squareSize;
  if (c < 0 || c > 7 || r < 0 || r > 7) return;
  
  int sq = r*8 + c;
  
  if (selected == -1) {
    // Select own piece
    if (board[sq] != 0) {
      boolean isWhite = board[sq] <= 6;
      if (isWhite == whiteToMove) {
        selected = sq;
      }
    }
  } else {
    if (sq == selected) {
      selected = -1;
    } else {
      // Try move
      if (isLegal(selected, sq)) {
        makeMove(selected, sq);
        selected = -1;
        whiteToMove = !whiteToMove;
        status = whiteToMove ? "White to move" : "Black thinking...";
        
        // Engine move (Black)
        if (!whiteToMove && !gameOver) {
          delay(300);
          engineMove();
        }
      } else {
        // Reselect if own piece
        if (board[sq] != 0) {
          boolean isWhite = board[sq] <= 6;
          if (isWhite == whiteToMove) selected = sq;
          else selected = -1;
        } else {
          selected = -1;
        }
      }
    }
  }
}

boolean isLegal(int from, int to) {
  if (from < 0 || from > 63 || to < 0 || to > 63) return false;
  if (board[from] == 0) return false;
  
  boolean isWhite = board[from] <= 6;
  if (board[to] != 0) {
    boolean targetWhite = board[to] <= 6;
    if (isWhite == targetWhite) return false; // cannot capture own
  }
  
  int piece = board[from] > 6 ? board[from]-6 : board[from];
  int fr = from / 8, fc = from % 8;
  int tr = to / 8, tc = to % 8;
  int dr = tr - fr, dc = tc - fc;
  
  // Very simplified legality (enough for a small engine)
  switch(piece) {
    case 1: // Pawn
      if (isWhite) {
        if (dc == 0 && dr == -1 && board[to] == 0) return true;
        if (dc == 0 && dr == -2 && fr == 6 && board[to] == 0 && board[from-8] == 0) return true;
        if (abs(dc) == 1 && dr == -1 && board[to] != 0) return true;
      } else {
        if (dc == 0 && dr == 1 && board[to] == 0) return true;
        if (dc == 0 && dr == 2 && fr == 1 && board[to] == 0 && board[from+8] == 0) return true;
        if (abs(dc) == 1 && dr == 1 && board[to] != 0) return true;
      }
      return false;
    case 2: // Knight
      return (abs(dr)==2 && abs(dc)==1) || (abs(dr)==1 && abs(dc)==2);
    case 3: // Bishop
      if (abs(dr) != abs(dc)) return false;
      return clearPath(from, to);
    case 4: // Rook
      if (dr != 0 && dc != 0) return false;
      return clearPath(from, to);
    case 5: // Queen
      if (dr != 0 && dc != 0 && abs(dr) != abs(dc)) return false;
      return clearPath(from, to);
    case 6: // King
      return abs(dr) <= 1 && abs(dc) <= 1;
  }
  return false;
}

boolean clearPath(int from, int to) {
  int fr = from/8, fc = from%8;
  int tr = to/8, tc = to%8;
  int dr = Integer.signum(tr-fr);
  int dc = Integer.signum(tc-fc);
  int r = fr + dr, c = fc + dc;
  while (r != tr || c != tc) {
    if (board[r*8 + c] != 0) return false;
    r += dr; c += dc;
  }
  return true;
}

void makeMove(int from, int to) {
  // Promotion (always to Queen for simplicity)
  int piece = board[from];
  if (piece == 1 && to < 8) piece = 5;      // white pawn -> Q
  if (piece == 7 && to > 55) piece = 11;    // black pawn -> q
  
  board[to] = piece;
  board[from] = 0;
  
  // Very basic checkmate detection (king captured)
  boolean whiteKing = false, blackKing = false;
  for (int i=0; i<64; i++) {
    if (board[i] == 6) whiteKing = true;
    if (board[i] == 12) blackKing = true;
  }
  if (!whiteKing) { gameOver = true; status = "Black wins!"; }
  if (!blackKing) { gameOver = true; status = "White wins!"; }
}

// ========== SMALL ENGINE ==========
// Extremely simple: generate legal moves + 1-ply evaluation
void engineMove() {
  ArrayList<int[]> moves = generateMoves(false); // black moves
  if (moves.size() == 0) {
    gameOver = true;
    status = "White wins! (no moves)";
    return;
  }
  
  // Pick best by simple material + random
  int bestScore = -999999;
  int[] best = moves.get(0);
  
  for (int[] m : moves) {
    int score = evaluateMove(m[0], m[1]);
    score += (int)random(-30, 30); // small randomness
    if (score > bestScore) {
      bestScore = score;
      best = m;
    }
  }
  
  makeMove(best[0], best[1]);
  whiteToMove = true;
  status = "White to move";
}

ArrayList<int[]> generateMoves(boolean forWhite) {
  ArrayList<int[]> list = new ArrayList<int[]>();
  for (int from=0; from<64; from++) {
    if (board[from] == 0) continue;
    boolean isWhite = board[from] <= 6;
    if (isWhite != forWhite) continue;
    
    for (int to=0; to<64; to++) {
      if (isLegal(from, to)) {
        list.add(new int[]{from, to});
      }
    }
  }
  return list;
}

int evaluateMove(int from, int to) {
  // Simple material evaluation after move
  int captured = board[to];
  int score = 0;
  if (captured != 0) {
    int p = captured > 6 ? captured-6 : captured;
    score += pieceVal[p];
  }
  // Prefer center
  int tr = to/8, tc = to%8;
  score += (3 - abs(3.5-tr)) + (3 - abs(3.5-tc));
  return score;
}

void keyPressed() {
  if (key == 'r' || key == 'R') initBoard();
}





























*/

















