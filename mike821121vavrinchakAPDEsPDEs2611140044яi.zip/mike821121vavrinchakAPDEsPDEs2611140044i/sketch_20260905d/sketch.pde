

// Simple Touch Draw - No Keyboard, Memory Efficient
// Works with Processing Android Mode

void setup() {
  fullScreen();
  background(255);
  stroke(0);
  strokeWeight(8);
  strokeCap(ROUND);
  strokeJoin(ROUND);
}

void draw() {
  // Draw only when touching
  if (mousePressed) {



  /// 
   line(pmouseX, pmouseY, mouseX, mouseY);



  }
}

// Touch auto-clears when you shake or 3-finger tap
void mousePressed() {
 /// if (mouseButton == RIGHT) {
   //////    background(255); // clear on right-click (2-finger tap on mobile)
  ///  }



  line(pmouseX, pmouseY, mouseX, mouseY);
      




}

// Double tap to clear (works on mobile)
void doubleTap() {
  background(255);
}





























