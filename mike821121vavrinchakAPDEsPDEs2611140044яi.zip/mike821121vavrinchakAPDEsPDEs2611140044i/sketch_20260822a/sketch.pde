





// APDE / Processing – Random Labyrinth + Moving Circle
// Controls: LEFT/RIGHT keys or touch/drag to change direction

float playerX, playerY;
float playerR = 18;
float angle = 0;          // direction the circle is facing
float speed = 3.5;

int wallCount = 80;       // number of random rectangles
float[][] walls;          // [x, y, w, h]

void setup() {
  size(displayWidth, displayHeight);   // full screen on Android
  // size(1000, 1000);               // uncomment for fixed size testing
  
  playerX = width/2;
  playerY = height/2;
  
  // Create random labyrinth of rectangles
  walls = new float[wallCount][4];
  for (int i = 0; i < wallCount; i++) {
    walls[i][0] = random(50, width-150);   // x
    walls[i][1] = random(50, height-150);  // y
    walls[i][2] = random(40, 180);         // w
    walls[i][3] = random(40, 180);         // h
  }
  
  // Keep player starting position clear of walls
  while (hitsAnyWall(playerX, playerY)) {
    playerX = random(100, width-100);
    playerY = random(100, height-100);
  }
}

void draw() {
  background(15);
  
  // ---- Draw labyrinth (noFill rectangles) ----
  noFill();
  stroke(180, 220, 255);
  strokeWeight(2);
  for (int i = 0; i < wallCount; i++) {
    rect(walls[i][0], walls[i][1], walls[i][2], walls[i][3]);
  }
  
  // ---- Move circle ----
  float nextX = playerX + cos(angle) * speed;
  float nextY = playerY + sin(angle) * speed;
  
  // Simple wall collision – try X then Y separately (slides along walls)
  if (!hitsAnyWall(nextX, playerY)) {
    playerX = nextX;
  }
  if (!hitsAnyWall(playerX, nextY)) {
    playerY = nextY;
  }
  
  // Keep inside screen
  playerX = constrain(playerX, playerR, width - playerR);
  playerY = constrain(playerY, playerR, height - playerR);
  
  // ---- Draw player circle ----
  fill(255, 80, 80);
  noStroke();
  ellipse(playerX, playerY, playerR*2, playerR*2);
  
  // Direction indicator
  stroke(255);
  strokeWeight(2);
  line(playerX, playerY, 
       playerX + cos(angle)*playerR*1.6, 
       playerY + sin(angle)*playerR*1.6);
}

// ---- Collision helper ----
boolean hitsAnyWall(float cx, float cy) {
  for (int i = 0; i < wallCount; i++) {
    float wx = walls[i][0];
    float wy = walls[i][1];
    float ww = walls[i][2];
    float wh = walls[i][3];
    
    // Circle vs rectangle collision
    float closestX = constrain(cx, wx, wx + ww);
    float closestY = constrain(cy, wy, wy + wh);
    float dx = cx - closestX;
    float dy = cy - closestY;
    if (dx*dx + dy*dy < playerR*playerR) {
      return true;
    }
  }
  return false;
}

// ---- Keyboard controls (LEFT / RIGHT) ----
void keyPressed() {
  if (keyCode == LEFT)  angle -= 0.18;
  if (keyCode == RIGHT) angle += 0.18;
}

// ---- Touch / mouse controls (drag to change angle) ----
void mouseDragged() {
  // Change angle based on horizontal drag
  angle += (mouseX - pmouseX) * 0.012;
}

// Optional: tap left/right half of screen
void mousePressed() {
  if (mouseX < width/2) angle -= 0.25;
  else                  angle += 0.25;
}






















