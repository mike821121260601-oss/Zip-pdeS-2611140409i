













Below is a full APDE Android sketch. It records the whole Android screen, has START / PAUSE / RESUME / STOP buttons, and after STOP creates a second MP4 at 10× playback speed.
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.MediaCodec;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.media.MediaProjection;
import android.media.MediaRecorder;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Environment;
import android.view.Surface;
import android.view.WindowManager;

import java.io.File;
import java.nio.ByteBuffer;


// ============================================================
// SCREEN RECORDER FOR APDE
// ============================================================

MediaProjectionManager projectionManager;
MediaProjection projection;

MediaRecorder recorder;
VirtualDisplay virtualDisplay;

int REQUEST_CAPTURE = 777;

boolean recording = false;
boolean paused = false;
boolean converting = false;

String normalFile;
String fastFile;

int recordWidth;
int recordHeight;


// ============================================================
// SETUP
// ============================================================

void setup() {

  fullScreen();

  orientation(PORTRAIT);

  textAlign(CENTER, CENTER);
  textSize(45);

  recordWidth = displayWidth;
  recordHeight = displayHeight;

  // MediaRecorder needs even dimensions
  if (recordWidth % 2 != 0)
    recordWidth--;

  if (recordHeight % 2 != 0)
    recordHeight--;

  projectionManager =
    (MediaProjectionManager)getActivity().getSystemService(
    Context.MEDIA_PROJECTION_SERVICE);

  normalFile =
    new File(
    Environment.getExternalStoragePublicDirectory(
    Environment.DIRECTORY_MOVIES),
    "ECRANE_RECORDING.mp4"
    ).getAbsolutePath();

  fastFile =
    new File(
    Environment.getExternalStoragePublicDirectory(
    Environment.DIRECTORY_MOVIES),
    "10X SPEED ECRANE special RECORDING.mp4"
    ).getAbsolutePath();
}


// ============================================================
// DRAW BUTTONS
// ============================================================

void draw() {

  background(25);

  fill(255);
  textSize(38);
  text("ECRANE RECORDER", width/2, 55);

  // START
  fill(0, 180, 0);
  rect(30, 110, width-60, 110, 20);

  fill(255);
  text("START RECORDING", width/2, 165);

  // PAUSE / RESUME
  fill(40, 90, 220);
  rect(30, 245, width-60, 110, 20);

  fill(255);

  if (paused)
    text("RESUME", width/2, 300);
  else
    text("PAUSE", width/2, 300);

  // STOP
  fill(210, 30, 30);
  rect(30, 380, width-60, 110, 20);

  fill(255);
  text("STOP", width/2, 435);


  // STATUS

  textSize(28);

  if (converting) {
    fill(255, 220, 0);
    text("CREATING 10X VIDEO...", width/2, 570);
  }
  else if (recording && paused) {
    fill(255, 220, 0);
    text("PAUSED", width/2, 570);
  }
  else if (recording) {
    fill(0, 255, 0);
    text("RECORDING", width/2, 570);
  }
  else {
    fill(220);
    text("READY", width/2, 570);
  }

  textSize(22);

  fill(200);
  text(
    "Output:",
    width/2,
    height-100
    );

  text(
    "10X SPEED ECRANE special RECORDING.mp4",
    width/2,
    height-60
    );
}


// ============================================================
// TOUCH
// ============================================================

void touchStarted() {

  if (converting)
    return;


  // START
  if (mouseY > 110 &&
      mouseY < 220) {

    if (!recording)
      requestScreenCapture();

    return;
  }


  // PAUSE / RESUME
  if (mouseY > 245 &&
      mouseY < 355) {

    if (recording) {

      if (Build.VERSION.SDK_INT >= 24) {

        try {

          if (!paused) {

            recorder.pause();
            paused = true;

          }
          else {

            recorder.resume();
            paused = false;

          }

        }
        catch(Exception e) {

          println(e);

        }
      }
    }

    return;
  }


  // STOP
  if (mouseY > 380 &&
      mouseY < 500) {

    if (recording)
      stopRecording();

    return;
  }
}


// ============================================================
// REQUEST ANDROID SCREEN CAPTURE
// ============================================================

void requestScreenCapture() {

  try {

    Intent intent =
      projectionManager.createScreenCaptureIntent();

    getActivity().startActivityForResult(
      intent,
      REQUEST_CAPTURE
      );

  }
  catch(Exception e) {

    println(e);

  }
}


// ============================================================
// RESULT OF ANDROID SCREEN CAPTURE DIALOG
// ============================================================

@Override
protected void onActivityResult(
  int requestCode,
  int resultCode,
  Intent data) {

  super.onActivityResult(
    requestCode,
    resultCode,
    data
    );


  if (requestCode == REQUEST_CAPTURE) {

    if (resultCode == Activity.RESULT_OK) {

      startRecording(
        resultCode,
        data
        );
    }
    else {

      println("SCREEN CAPTURE CANCELLED");

    }
  }
}


// ============================================================
// START RECORDING
// ============================================================

void startRecording(
  int resultCode,
  Intent data) {

  try {

    projection =
      projectionManager.getMediaProjection(
      resultCode,
      data
      );


    // --------------------------------------------------------
    // DELETE OLD FILE
    // --------------------------------------------------------

    File oldFile =
      new File(normalFile);

    if (oldFile.exists())
      oldFile.delete();


    // --------------------------------------------------------
    // MEDIA RECORDER
    // --------------------------------------------------------

    recorder =
      new MediaRecorder();


    recorder.setVideoSource(
      MediaRecorder.VideoSource.SURFACE
      );


    recorder.setOutputFormat(
      MediaRecorder.OutputFormat.MPEG_4
      );


    recorder.setVideoEncoder(
      MediaRecorder.VideoEncoder.H264
      );


    recorder.setVideoEncodingBitRate(
      8 * 1000 * 1000
      );


    recorder.setVideoFrameRate(
      30
      );


    recorder.setVideoSize(
      recordWidth,
      recordHeight
      );


    recorder.setOutputFile(
      normalFile
      );


    recorder.prepare();


    // --------------------------------------------------------
    // SCREEN VIRTUAL DISPLAY
    // --------------------------------------------------------

    Surface surface =
      recorder.getSurface();


    virtualDisplay =
      projection.createVirtualDisplay(
      "APDE_SCREEN_RECORDER",
      recordWidth,
      recordHeight,
      getResources().getDisplayMetrics().densityDpi,
      0,
      surface,
      null,
      null
      );


    recorder.start();


    recording = true;
    paused = false;

    println("RECORDING STARTED");
    println(normalFile);

  }
  catch(Exception e) {

    println("START ERROR:");
    println(e);

    recording = false;
  }
}


// ============================================================
// STOP RECORDING
// ============================================================

void stopRecording() {

  if (!recording)
    return;


  recording = false;
  paused = false;


  try {

    recorder.stop();

  }
  catch(Exception e) {

    println("RECORDER STOP ERROR");
    println(e);

  }


  try {

    recorder.reset();
    recorder.release();

  }
  catch(Exception e) {

    println(e);

  }


  recorder = null;


  try {

    if (virtualDisplay != null)
      virtualDisplay.release();

  }
  catch(Exception e) {

    println(e);

  }

  virtualDisplay = null;


  try {

    if (projection != null)
      projection.stop();

  }
  catch(Exception e) {

    println(e);

  }

  projection = null;


  // ----------------------------------------------------------
  // CREATE 10X FILE
  // ----------------------------------------------------------

  converting = true;

  println("CREATING 10X VIDEO...");


  new Thread(
    new Runnable() {

      public void run() {

        make10XVideo(
          normalFile,
          fastFile
          );


        converting = false;

        println(
          "10X VIDEO FINISHED:"
          );

        println(fastFile);
      }

    }
    ).start();
}


// ============================================================
// CREATE 10X MP4
//
// Instead of decoding/re-encoding the video,
// this changes the presentation timestamps.
//
// 10,000 microseconds becomes 1,000 microseconds.
// Therefore playback is 10X faster.
// ============================================================

void make10XVideo(
  String input,
  String output) {

  MediaExtractor extractor = null;
  MediaMuxer muxer = null;


  try {

    extractor =
      new MediaExtractor();

    extractor.setDataSource(input);


    File outputFile =
      new File(output);

    if (outputFile.exists())
      outputFile.delete();


    muxer =
      new MediaMuxer(
      output,
      MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4
      );


    int tracks =
      extractor.getTrackCount();


    int[] trackMap =
      new int[tracks];


    for (int i = 0; i < tracks; i++) {

      MediaFormat format =
        extractor.getTrackFormat(i);


      trackMap[i] =
        muxer.addTrack(format);
    }


    muxer.start();


    ByteBuffer buffer =
      ByteBuffer.allocate(1024 * 1024);


    MediaCodec.BufferInfo info =
      new MediaCodec.BufferInfo();


    for (int track = 0;
         track < tracks;
         track++) {


      extractor.unselectTrack(track);

      extractor.selectTrack(track);


      long lastTime = -1;


      while (true) {

        info.offset = 0;

        info.size =
          extractor.readSampleData(
          buffer,
          0
          );


        if (info.size < 0)
          break;


        long originalTime =
          extractor.getSampleTime();


        if (originalTime < 0)
          break;


        // ----------------------------------------------------
        // 10X SPEED
        // ----------------------------------------------------

        long newTime =
          originalTime / 10;


        // Make timestamps strictly increasing
        if (newTime <= lastTime)
          newTime = lastTime + 1;


        info.presentationTimeUs =
          newTime;


        info.flags =
          extractor.getSampleFlags();


        muxer.writeSampleData(
          trackMap[track],
          buffer,
          info
          );


        lastTime =
          newTime;


        extractor.advance();
      }


      extractor.unselectTrack(track);
    }


    muxer.stop();


    println(
      "10X FILE CREATED"
      );

  }
  catch(Exception e) {

    println(
      "10X CONVERSION ERROR:"
      );

    println(e);

  }
  finally {

    try {

      if (extractor != null)
        extractor.release();

    }
    catch(Exception e) {
    }


    try {

      if (muxer != null)
        muxer.release();

    }
    catch(Exception e) {
    }
  }
}
Important APDE setup
Add these permissions to the Android manifest:
<uses-permission android:name="android.permission.RECORD_AUDIO"/>
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE"/>
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"/>
This version records video only. That is intentional: screen capture is much simpler and more reliable without microphone/audio.
The files are placed in:
Movies/ECRANE_RECORDING.mp4
Movies/10X SPEED ECRANE special RECORDING.mp4
The second file is generated when you press STOP, with timestamps changed to make playback 10× faster.










