
public void settings () {smooth(0);}


///pmouseXY///0.5.3///ERRORS////




float ppmouseX, ppmouseY;
int ppmppp=0;
float pppmouseX, pppmouseY;
float x = 200+200-200
+width/2+
///(float) (int) float
(displayWidth/3) ;
float y = 400+ 400-400
+height/2;
float speed = 3 /2;
boolean left, right, up, down;

void setup() {
  ///size(400,600);
 ///size((displayWidth),(displayHeight));//
size((displayWidth),(displayHeight));//

  //   scale( 1/9);///



}




void draw2() {

if  ( random(44)<4) 


{

pppmouseX=pmouseX;pppmouseY=pmouseY;

} 




} 

void draw() { 


ppmppp++;if ( ppmppp>99) {ppmppp=0;} 


if(ppmppp==11){

pppmouseX=mouseX;
pppmouseY=mouseY;

} 

if(ppmppp==66){

ppmouseX=mouseX;
ppmouseY=mouseY;

} 








float prevMouseX = 0;
float storedMouseX = 0;

//void draw() {
  if (frameCount % 11 == 0) {
    prevMouseX = mouseX;
  }
  
  if (frameCount % 66 == 0) {
    storedMouseX = mouseX;
  }
//} 












//if(random(44)<2)draw2() ;
///pppmouseX=pmouseX;pppmouseY=pmouseY;

// ppmouseX=mouseX;ppmouseY=mouseY;



















  background(40);
fill(255,0,0);stroke(255,0,0);
strokeWeight(9-5-1);
point(width/2, height/2) ;


line(pmouseX, pmouseY, mouseX, mouseY) ;

line(pmouseY, pmouseX, mouseY, mouseX) ;



strokeWeight(0.5);
textSize(55);
fill(255);
text(pmouseX+"   " +pmouseY+"   " 
+mouseX+"   " +mouseY, 
width/5,height/3);
fill(255);

text(pppmouseX+"   " +pppmouseY+"   " 
+ppmouseX+"    " +ppmouseY, 
width/6,height/2);



  
  if (left)  x -= speed;
  if (right) x += speed;
  if (up)    y -= speed;
  if (down)  y += speed;
  


  if (left)  x -= speed;
  if (right) x += speed;
  if (up)    y -= speed;
  if (down)  y += speed;




  // межі
  x = constrain(x, 20, width-20);
  y = constrain(y, 20+40, height-20-40);
  
  // персонаж (простий)
  fill(0, 200, 100);
  ellipse(x, y-40, 30, 30); // голова
  rect(x-10, y-25, 20, 40); // тіло
  // ноги
  line(x, y+15, x-15, y+50);
  line(x, y+15, x+15, y+50);




    ////ppmouseX=pmouseX;ppmouseY=pmouseY;





}

void mousePressed() {



line(
pmouseX+11,

pmouseY,mouseX-11,mouseY






) ;










  if (ppmouseX < pppmouseX) { left = true;
      right=false;} 


  if (ppmouseX > pppmouseX ) { right = true;
  left=false;} 


  if (ppmouseY < pppmouseY)   { up = true; 
    down=false;} 


  if (ppmouseY > pppmouseY)  { down = true;
      up=false; } 
  
  // зміна швидкості///


  if (key == '1') speed = 2;
  if (key == '2') speed = 4;
  if (key == '3') speed = 7;





}
























































/*




float x = 200;
float y = 400;
float speed = 3;
boolean left, right, up, down;

void setup() {
  size(400, 600);
}

void draw() {
  background(40);
  
  if (left)  x -= speed;
  if (right) x += speed;
  if (up)    y -= speed;
  if (down)  y += speed;
  
  // межі
  x = constrain(x, 20, width-20);
  y = constrain(y, 20, height-20);
  
  // персонаж (простий)
  fill(0, 200, 100);
  ellipse(x, y-40, 30, 30); // голова
  rect(x-10, y-25, 20, 40); // тіло
  // ноги
  line(x, y+15, x-15, y+50);
  line(x, y+15, x+15, y+50);
}

void keyPressed() {
  if (keyCode == LEFT)  left = true;
  if (keyCode == RIGHT) right = true;
  if (keyCode == UP)    up = true;
  if (keyCode == DOWN)  down = true;
  
  // зміна швид��ості
  if (key == '1') speed = 2;
  if (key == '2') speed = 4;
  if (key == '3') speed = 7;
}

void keyReleased() {
  if (keyCode == LEFT)  left = false;
  if (keyCode == RIGHT) right = false;
  if (keyCode == UP)    up = false;
  if (keyCode == DOWN)  down = false;
}


*/




























