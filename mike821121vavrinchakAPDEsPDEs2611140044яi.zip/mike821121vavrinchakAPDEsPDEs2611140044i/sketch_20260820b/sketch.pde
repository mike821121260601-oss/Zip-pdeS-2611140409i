

import android.media.MediaMetadataRetriever;
import android.os.Looper;
import android.app.Activity;
import android.view.ViewGroup;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.media.MediaPlayer;
import android.content.res.AssetFileDescriptor;
import android.content.Context;
import java.io.IOException;

AssetFileDescriptor afd;
Context context;
Activity act;
SurfaceView mySurface;
SurfaceHolder mSurfaceHolder;
MediaPlayer mMediaPlayer;

String fileName = "test.mp4";   // file in data folder

void setup() {
  size(displayWidth, displayHeight, P2D);
  act = this.getActivity();
  context = act.getApplicationContext();
  Looper.prepare();
  mMediaPlayer = new MediaPlayer();

  try {
    afd = context.getAssets().openFd(fileName);

    MediaMetadataRetriever metaRetriever = new MediaMetadataRetriever();
    metaRetriever.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
    String height = metaRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT);
    if (int(height) < 2) {
      throw new IOException("Invalid video");
    }
  } 
  catch (Exception e) {
    e.printStackTrace();
  }

  mySurface = new SurfaceView(act);
  mSurfaceHolder = mySurface.getHolder();
  mSurfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
  mSurfaceHolder.addCallback(new SurfaceHolder.Callback() {
    @Override
    public void surfaceCreated(SurfaceHolder surfaceHolder) {
      mMediaPlayer.setDisplay(surfaceHolder);
    }
    @Override
    public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i2, int i3) {
      mMediaPlayer.setDisplay(surfaceHolder);
    }
    @Override
    public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
    }
  });

  startVideo();
}

void startVideo() {
  act.runOnUiThread(new Runnable() {
    public void run() {
      try {
        mMediaPlayer.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
        mMediaPlayer.prepare();
        // Full screen
        act.addContentView(mySurface, new ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 
            ViewGroup.LayoutParams.MATCH_PARENT));
        if (!mMediaPlayer.isPlaying()) {
          mMediaPlayer.start();
        }
      } 
      catch (Exception e) {
        e.printStackTrace();
      }
    }
  });
}

void draw() {
  // empty – video is drawn by SurfaceView
}

void onPause() {
  if (mMediaPlayer != null) {
    mMediaPlayer.release();
    mMediaPlayer = null;
  }
  super.onPause();
}

void onStop() {
  if (mMediaPlayer != null) {
    mMediaPlayer.release();
    mMediaPlayer = null;
  }
  super.onStop();
}

void onDestroy() {
  if (mMediaPlayer != null) {
    mMediaPlayer.release();
    mMediaPlayer = null;
  }
  super.onDestroy();
}



////-----1111111----------///////

import android.media.MediaMetadataRetriever;
import android.os.Looper;
import android.app.Activity;
import android.view.ViewGroup;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.media.MediaPlayer;
import android.content.res.AssetFileDescriptor;
import android.content.Context;
import java.io.IOException;

AssetFileDescriptor afd;
Context context;
Activity act;
SurfaceView mySurface;
SurfaceHolder mSurfaceHolder;
MediaPlayer mMediaPlayer;

String fileName = "test.mp4";   // file in data folder

void setup() {
  size(displayWidth, displayHeight, P2D);
  act = this.getActivity();
  context = act.getApplicationContext();
  Looper.prepare();
  mMediaPlayer = new MediaPlayer();

  try {
    afd = context.getAssets().openFd(fileName);

    MediaMetadataRetriever metaRetriever = new MediaMetadataRetriever();
    metaRetriever.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
    String height = metaRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT);
    if (int(height) < 2) {
      throw new IOException("Invalid video");
    }
  } 
  catch (Exception e) {
    e.printStackTrace();
  }

  mySurface = new SurfaceView(act);
  mSurfaceHolder = mySurface.getHolder();
  mSurfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
  mSurfaceHolder.addCallback(new SurfaceHolder.Callback() {
    @Override
    public void surfaceCreated(SurfaceHolder surfaceHolder) {
      mMediaPlayer.setDisplay(surfaceHolder);
    }
    @Override
    public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i2, int i3) {
      mMediaPlayer.setDisplay(surfaceHolder);
    }
    @Override
    public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
    }
  });

  startVideo();
}

void startVideo() {
  act.runOnUiThread(new Runnable() {
    public void run() {
      try {
        mMediaPlayer.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
        mMediaPlayer.prepare();
        // Full screen
        act.addContentView(mySurface, new ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 
            ViewGroup.LayoutParams.MATCH_PARENT));
        if (!mMediaPlayer.isPlaying()) {
          mMediaPlayer.start();
        }
      } 
      catch (Exception e) {
        e.printStackTrace();
      }
    }
  });
}

void draw() {
  // empty – video is drawn by SurfaceView
}

void onPause() {
  if (mMediaPlayer != null) {
    mMediaPlayer.release();
    mMediaPlayer = null;
  }
  super.onPause();
}

void onStop() {
  if (mMediaPlayer != null) {
    mMediaPlayer.release();
    mMediaPlayer = null;
  }
  super.onStop();
}

void onDestroy() {
  if (mMediaPlayer != null) {
    mMediaPlayer.release();
    mMediaPlayer = null;
  }
  super.onDestroy();
}


////------------------1//////77/////


PImage[] photos;
int current = 0;
int interval = 3000;          // ms between photos
int lastChange;

void setup() {
  size(displayWidth, displayHeight, P2D);
  orientation(PORTRAIT);      // or LANDSCAPE
  
  // Load all images (adjust names / count)
  photos = new PImage[5];
  for (int i = 0; i < photos.length; i++) {
    photos[i] = loadImage("img" + i + ".jpg");
  }
  
  lastChange = millis();
  imageMode(CENTER);
}

void draw() {
  background(0);
  
  if (photos[current] != null) {
    // Fit image to screen while keeping aspect ratio
    float scale = min((float)width / photos[current].width, 
                      (float)height / photos[current].height);
    float w = photos[current].width * scale;
    float h = photos[current].height * scale;
    image(photos[current], width/2, height/2, w, h);
  }
  
  // Auto advance
  if (millis() - lastChange > interval) {
    current = (current + 1) % photos.length;
    lastChange = millis();
  }
}

// Optional: tap to go to next photo
void mousePressed() {
  current = (current + 1) % photos.length;
  lastChange = millis();
}





///////-------------/////////

PImage[] photos;
int current = 0;
int interval = 3000;          // ms between photos
int lastChange;

void setup() {
  size(displayWidth, displayHeight, P2D);
  orientation(PORTRAIT);      // or LANDSCAPE
  
  // Load all images (adjust names / count)
  photos = new PImage[5];
  for (int i = 0; i < photos.length; i++) {
    photos[i] = loadImage("img" + i + ".jpg");
  }
  
  lastChange = millis();
  imageMode(CENTER);
}

void draw() {
  background(0);
  
  if (photos[current] != null) {
    // Fit image to screen while keeping aspect ratio
    float scale = min((float)width / photos[current].width, 
                      (float)height / photos[current].height);
    float w = photos[current].width * scale;
    float h = photos[current].height * scale;
    image(photos[current], width/2, height/2, w, h);
  }
  
  // Auto advance
  if (millis() - lastChange > interval) {
    current = (current + 1) % photos.length;
    lastChange = millis();
  }
}

// Optional: tap to go to next photo
void mousePressed() {
  current = (current + 1) % photos.length;
  lastChange = millis();
}


//////---------------///////////



import android.media.MediaPlayer;
import android.media.AudioAttributes;
import android.content.res.AssetFileDescriptor;
import android.content.Context;
import android.app.Activity;
import java.io.IOException;

MediaPlayer mp;
Context context;
Activity act;

String[] playlist = {
  "song1.mp3",
  "song2.mp3",
  "song3.mp3"
  // add more files here
};

int currentTrack = 0;
boolean isPlaying = false;
boolean isApk = false;   // set to true when you export as APK

// UI
int btnSize = 120;
color btnColor = color(40, 120, 220);
color btnActive = color(80, 180, 255);

void setup() {
  size(displayWidth, displayHeight, P2D);
  orientation(PORTRAIT);
  
  act = this.getActivity();
  context = act.getApplicationContext();
  
  // Auto-detect if running as APK or preview (optional)
  // isApk = true;   // force APK mode if needed
  
  loadTrack(currentTrack);
}

void draw() {
  background(20);
  
  // Title
  fill(255);
  textAlign(CENTER, CENTER);
  textSize(42);
  text("APDE Music Player", width/2, 100);
  
  // Current track name
  textSize(32);
  text(playlist[currentTrack], width/2, 180);
  
  // Progress bar (simple)
  if (mp != null && mp.getDuration() > 0) {
    float progress = (float)mp.getCurrentPosition() / mp.getDuration();
    noStroke();
    fill(60);
    rect(50, 250, width-100, 20, 10);
    fill(0, 200, 100);
    rect(50, 250, (width-100)*progress, 20, 10);
    
    // Time
    textSize(24);
    fill(200);
    text(formatTime(mp.getCurrentPosition()) + " / " + formatTime(mp.getDuration()), 
         width/2, 300);
  }
  
  // Buttons
  drawButton(width/2 - 180, height - 250, "PREV", currentTrack > 0);
  drawButton(width/2,       height - 250, isPlaying ? "PAUSE" : "PLAY", true);
  drawButton(width/2 + 180, height - 250, "NEXT", currentTrack < playlist.length-1);
}

void drawButton(float x, float y, String label, boolean enabled) {
  if (enabled && dist(mouseX, mouseY, x, y) < btnSize/2 && mousePressed) {
    fill(btnActive);
  } else {
    fill(enabled ? btnColor : color(80));
  }
  ellipse(x, y, btnSize, btnSize);
  
  fill(255);
  textSize(28);
  text(label, x, y);
}

void mousePressed() {
  // Previous
  if (dist(mouseX, mouseY, width/2 - 180, height - 250) < btnSize/2) {
    if (currentTrack > 0) {
      currentTrack--;
      loadTrack(currentTrack);
      if (isPlaying) play();
    }
  }
  // Play / Pause
  else if (dist(mouseX, mouseY, width/2, height - 250) < btnSize/2) {
    if (isPlaying) {
      pause();
    } else {
      play();
    }
  }
  // Next
  else if (dist(mouseX, mouseY, width/2 + 180, height - 250) < btnSize/2) {
    if (currentTrack < playlist.length - 1) {
      currentTrack++;
      loadTrack(currentTrack);
      if (isPlaying) play();
    }
  }
}

// ========== MediaPlayer helpers ==========

void loadTrack(int index) {
  if (mp != null) {
    mp.release();
    mp = null;
  }
  
  mp = new MediaPlayer();
  
  try {
    mp.setAudioAttributes(new AudioAttributes.Builder()
      .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
      .setUsage(AudioAttributes.USAGE_MEDIA)
      .build());
    
    if (!isApk) {
      // Preview mode (APDE editor)
      mp.setDataSource(sketchPath("") + "/" + playlist[index]);
    } else {
      // APK mode – load from assets/data folder
      AssetFileDescriptor afd = context.getAssets().openFd(playlist[index]);
      mp.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
      afd.close();
    }
    
    mp.prepare();
    mp.setLooping(false);
    
    // Auto next when song ends
    mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
      public void onCompletion(MediaPlayer m) {
        if (currentTrack < playlist.length - 1) {
          currentTrack++;
          loadTrack(currentTrack);
          play();
        } else {
          isPlaying = false;
        }
      }
    });
    
  } catch (Exception e) {
    println("Error loading track: " + e.getMessage());
    e.printStackTrace();
  }
}

void play() {
  if (mp != null && !mp.isPlaying()) {
    mp.start();
    isPlaying = true;
  }
}

void pause() {
  if (mp != null && mp.isPlaying()) {
    mp.pause();
    isPlaying = false;
  }
}

String formatTime(int millis) {
  int sec = millis / 1000;
  int min = sec / 60;
  sec = sec % 60;
  return nf(min, 2) + ":" + nf(sec, 2);
}

// Clean up
void onPause() {
  if (mp != null) {
    mp.pause();
  }
  super.onPause();
}

void onDestroy() {
  if (mp != null) {
    mp.release();
    mp = null;
  }
  super.onDestroy();
}


///////-----------////////

import android.media.MediaPlayer;
import android.media.AudioAttributes;
import android.content.res.AssetFileDescriptor;
import android.content.Context;
import android.app.Activity;
import java.io.IOException;

MediaPlayer mp;
Context context;
Activity act;

String[] playlist = {
  "song1.mp3",
  "song2.mp3",
  "song3.mp3"
  // add more files here
};

int currentTrack = 0;
boolean isPlaying = false;
boolean isApk = false;   // set to true when you export as APK

// UI
int btnSize = 120;
color btnColor = color(40, 120, 220);
color btnActive = color(80, 180, 255);

void setup() {
  size(displayWidth, displayHeight, P2D);
  orientation(PORTRAIT);
  
  act = this.getActivity();
  context = act.getApplicationContext();
  
  // Auto-detect if running as APK or preview (optional)
  // isApk = true;   // force APK mode if needed
  
  loadTrack(currentTrack);
}

void draw() {
  background(20);
  
  // Title
  fill(255);
  textAlign(CENTER, CENTER);
  textSize(42);
  text("APDE Music Player", width/2, 100);
  
  // Current track name
  textSize(32);
  text(playlist[currentTrack], width/2, 180);
  
  // Progress bar (simple)
  if (mp != null && mp.getDuration() > 0) {
    float progress = (float)mp.getCurrentPosition() / mp.getDuration();
    noStroke();
    fill(60);
    rect(50, 250, width-100, 20, 10);
    fill(0, 200, 100);
    rect(50, 250, (width-100)*progress, 20, 10);
    
    // Time
    textSize(24);
    fill(200);
    text(formatTime(mp.getCurrentPosition()) + " / " + formatTime(mp.getDuration()), 
         width/2, 300);
  }
  
  // Buttons
  drawButton(width/2 - 180, height - 250, "PREV", currentTrack > 0);
  drawButton(width/2,       height - 250, isPlaying ? "PAUSE" : "PLAY", true);
  drawButton(width/2 + 180, height - 250, "NEXT", currentTrack < playlist.length-1);
}

void drawButton(float x, float y, String label, boolean enabled) {
  if (enabled && dist(mouseX, mouseY, x, y) < btnSize/2 && mousePressed) {
    fill(btnActive);
  } else {
    fill(enabled ? btnColor : color(80));
  }
  ellipse(x, y, btnSize, btnSize);
  
  fill(255);
  textSize(28);
  text(label, x, y);
}

void mousePressed() {
  // Previous
  if (dist(mouseX, mouseY, width/2 - 180, height - 250) < btnSize/2) {
    if (currentTrack > 0) {
      currentTrack--;
      loadTrack(currentTrack);
      if (isPlaying) play();
    }
  }
  // Play / Pause
  else if (dist(mouseX, mouseY, width/2, height - 250) < btnSize/2) {
    if (isPlaying) {
      pause();
    } else {
      play();
    }
  }
  // Next
  else if (dist(mouseX, mouseY, width/2 + 180, height - 250) < btnSize/2) {
    if (currentTrack < playlist.length - 1) {
      currentTrack++;
      loadTrack(currentTrack);
      if (isPlaying) play();
    }
  }
}

// ========== MediaPlayer helpers ==========

void loadTrack(int index) {
  if (mp != null) {
    mp.release();
    mp = null;
  }
  
  mp = new MediaPlayer();
  
  try {
    mp.setAudioAttributes(new AudioAttributes.Builder()
      .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
      .setUsage(AudioAttributes.USAGE_MEDIA)
      .build());
    
    if (!isApk) {
      // Preview mode (APDE editor)
      mp.setDataSource(sketchPath("") + "/" + playlist[index]);
    } else {
      // APK mode – load from assets/data folder
      AssetFileDescriptor afd = context.getAssets().openFd(playlist[index]);
      mp.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
      afd.close();
    }
    
    mp.prepare();
    mp.setLooping(false);
    
    // Auto next when song ends
    mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
      public void onCompletion(MediaPlayer m) {
        if (currentTrack < playlist.length - 1) {
          currentTrack++;
          loadTrack(currentTrack);
          play();
        } else {
          isPlaying = false;
        }
      }
    });
    
  } catch (Exception e) {
    println("Error loading track: " + e.getMessage());
    e.printStackTrace();
  }
}

void play() {
  if (mp != null && !mp.isPlaying()) {
    mp.start();
    isPlaying = true;
  }
}

void pause() {
  if (mp != null && mp.isPlaying()) {
    mp.pause();
    isPlaying = false;
  }
}

String formatTime(int millis) {
  int sec = millis / 1000;
  int min = sec / 60;
  sec = sec % 60;
  return nf(min, 2) + ":" + nf(sec, 2);
}

// Clean up
void onPause() {
  if (mp != null) {
    mp.pause();
  }
  super.onPause();
}

void onDestroy() {
  if (mp != null) {
    mp.release();
    mp = null;
  }
  super.onDestroy();
}

///////--------------///////



import android.media.MediaPlayer;
import android.media.AudioAttributes;
import android.content.res.AssetFileDescriptor;
import android.content.Context;
import android.app.Activity;
import java.io.IOException;

MediaPlayer mp;
Context context;
Activity act;

String[] playlist = {
  "song1.mp3",
  "song2.mp3",
  "song3.mp3"
  // add more files here
};

int currentTrack = 0;
boolean isPlaying = false;
boolean isApk = false;   // set to true when you export as APK

// UI
int btnSize = 120;
color btnColor = color(40, 120, 220);
color btnActive = color(80, 180, 255);

void setup() {
  size(displayWidth, displayHeight, P2D);
  orientation(PORTRAIT);
  
  act = this.getActivity();
  context = act.getApplicationContext();
  
  // Auto-detect if running as APK or preview (optional)
  // isApk = true;   // force APK mode if needed
  
  loadTrack(currentTrack);
}

void draw() {
  background(20);
  
  // Title
  fill(255);
  textAlign(CENTER, CENTER);
  textSize(42);
  text("APDE Music Player", width/2, 100);
  
  // Current track name
  textSize(32);
  text(playlist[currentTrack], width/2, 180);
  
  // Progress bar (simple)
  if (mp != null && mp.getDuration() > 0) {
    float progress = (float)mp.getCurrentPosition() / mp.getDuration();
    noStroke();
    fill(60);
    rect(50, 250, width-100, 20, 10);
    fill(0, 200, 100);
    rect(50, 250, (width-100)*progress, 20, 10);
    
    // Time
    textSize(24);
    fill(200);
    text(formatTime(mp.getCurrentPosition()) + " / " + formatTime(mp.getDuration()), 
         width/2, 300);
  }
  
  // Buttons
  drawButton(width/2 - 180, height - 250, "PREV", currentTrack > 0);
  drawButton(width/2,       height - 250, isPlaying ? "PAUSE" : "PLAY", true);
  drawButton(width/2 + 180, height - 250, "NEXT", currentTrack < playlist.length-1);
}

void drawButton(float x, float y, String label, boolean enabled) {
  if (enabled && dist(mouseX, mouseY, x, y) < btnSize/2 && mousePressed) {
    fill(btnActive);
  } else {
    fill(enabled ? btnColor : color(80));
  }
  ellipse(x, y, btnSize, btnSize);
  
  fill(255);
  textSize(28);
  text(label, x, y);
}

void mousePressed() {
  // Previous
  if (dist(mouseX, mouseY, width/2 - 180, height - 250) < btnSize/2) {
    if (currentTrack > 0) {
      currentTrack--;
      loadTrack(currentTrack);
      if (isPlaying) play();
    }
  }
  // Play / Pause
  else if (dist(mouseX, mouseY, width/2, height - 250) < btnSize/2) {
    if (isPlaying) {
      pause();
    } else {
      play();
    }
  }
  // Next
  else if (dist(mouseX, mouseY, width/2 + 180, height - 250) < btnSize/2) {
    if (currentTrack < playlist.length - 1) {
      currentTrack++;
      loadTrack(currentTrack);
      if (isPlaying) play();
    }
  }
}

// ========== MediaPlayer helpers ==========

void loadTrack(int index) {
  if (mp != null) {
    mp.release();
    mp = null;
  }
  
  mp = new MediaPlayer();
  
  try {
    mp.setAudioAttributes(new AudioAttributes.Builder()
      .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
      .setUsage(AudioAttributes.USAGE_MEDIA)
      .build());
    
    if (!isApk) {
      // Preview mode (APDE editor)
      mp.setDataSource(sketchPath("") + "/" + playlist[index]);
    } else {
      // APK mode – load from assets/data folder
      AssetFileDescriptor afd = context.getAssets().openFd(playlist[index]);
      mp.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
      afd.close();
    }
    
    mp.prepare();
    mp.setLooping(false);
    
    // Auto next when song ends
    mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
      public void onCompletion(MediaPlayer m) {
        if (currentTrack < playlist.length - 1) {
          currentTrack++;
          loadTrack(currentTrack);
          play();
        } else {
          isPlaying = false;
        }
      }
    });
    
  } catch (Exception e) {
    println("Error loading track: " + e.getMessage());
    e.printStackTrace();
  }
}

void play() {
  if (mp != null && !mp.isPlaying()) {
    mp.start();
    isPlaying = true;
  }
}

void pause() {
  if (mp != null && mp.isPlaying()) {
    mp.pause();
    isPlaying = false;
  }
}

String formatTime(int millis) {
  int sec = millis / 1000;
  int min = sec / 60;
  sec = sec % 60;
  return nf(min, 2) + ":" + nf(sec, 2);
}

// Clean up
void onPause() {
  if (mp != null) {
    mp.pause();
  }
  super.onPause();
}

void onDestroy() {
  if (mp != null) {
    mp.release();
    mp = null;
  }
  super.onDestroy();
}


////-----------------////////



import android.content.Intent;
import android.content.pm.PackageManager;
import android.app.Activity;
import android.widget.Toast;

Activity act;
PackageManager pm;

// List of apps you want to launch (edit these)
String[] appNames = {
  "YouTube",
  "Chrome",
  "Settings",
  "Calculator",
  "Camera"
};

String[] packageNames = {
  "com.google.android.youtube",
  "com.android.chrome",
  "com.android.settings",
  "com.google.android.calculator",
  "com.android.camera2"          // may vary by device
};

int selected = -1;

void setup() {
  size(displayWidth, displayHeight, P2D);
  orientation(PORTRAIT);
  
  act = this.getActivity();
  pm = act.getPackageManager();
  
  textAlign(CENTER, CENTER);
}

void draw() {
  background(25);
  
  fill(255);
  textSize(42);
  text("APDE App Runner", width/2, 80);
  
  textSize(28);
  fill(180);
  text("Tap an app to launch it", width/2, 140);
  
  // Draw buttons
  for (int i = 0; i < appNames.length; i++) {
    float y = 220 + i * 110;
    
    if (selected == i) {
      fill(50, 130, 230);
    } else {
      fill(50);
    }
    
    rectMode(CENTER);
    rect(width/2, y, width - 80, 90, 20);
    
    fill(255);
    textSize(34);
    text(appNames[i], width/2, y);
  }
}

void mousePressed() {
  for (int i = 0; i < appNames.length; i++) {
    float y = 220 + i * 110;
    if (mouseY > y - 45 && mouseY < y + 45) {
      selected = i;
      launchApp(packageNames[i]);
      break;
    }
  }
}

void launchApp(String packageName) {
  try {
    Intent intent = pm.getLaunchIntentForPackage(packageName);
    
    if (intent != null) {
      intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
      act.startActivity(intent);
    } else {
      // App not installed
      Toast.makeText(act, "App not installed: " + packageName, Toast.LENGTH_SHORT).show();
    }
  } 
  catch (Exception e) {
    Toast.makeText(act, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
    e.printStackTrace();
  }
}

///////------------////////


import android.content.Intent;
import android.content.pm.PackageManager;
import android.app.Activity;
import android.widget.Toast;

Activity act;
PackageManager pm;

// List of apps you want to launch (edit these)
String[] appNames = {
  "YouTube",
  "Chrome",
  "Settings",
  "Calculator",
  "Camera"
};

String[] packageNames = {
  "com.google.android.youtube",
  "com.android.chrome",
  "com.android.settings",
  "com.google.android.calculator",
  "com.android.camera2"          // may vary by device
};

int selected = -1;

void setup() {
  size(displayWidth, displayHeight, P2D);
  orientation(PORTRAIT);
  
  act = this.getActivity();
  pm = act.getPackageManager();
  
  textAlign(CENTER, CENTER);
}

void draw() {
  background(25);
  
  fill(255);
  textSize(42);
  text("APDE App Runner", width/2, 80);
  
  textSize(28);
  fill(180);
  text("Tap an app to launch it", width/2, 140);
  
  // Draw buttons
  for (int i = 0; i < appNames.length; i++) {
    float y = 220 + i * 110;
    
    if (selected == i) {
      fill(50, 130, 230);
    } else {
      fill(50);
    }
    
    rectMode(CENTER);
    rect(width/2, y, width - 80, 90, 20);
    
    fill(255);
    textSize(34);
    text(appNames[i], width/2, y);
  }
}

void mousePressed() {
  for (int i = 0; i < appNames.length; i++) {
    float y = 220 + i * 110;
    if (mouseY > y - 45 && mouseY < y + 45) {
      selected = i;
      launchApp(packageNames[i]);
      break;
    }
  }
}

void launchApp(String packageName) {
  try {
    Intent intent = pm.getLaunchIntentForPackage(packageName);
    
    if (intent != null) {
      intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
      act.startActivity(intent);
    } else {
      // App not installed
      Toast.makeText(act, "App not installed: " + packageName, Toast.LENGTH_SHORT).show();
    }
  } 
  catch (Exception e) {
    Toast.makeText(act, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
    e.printStackTrace();
  }
}


////////---------------//////


import android.content.Intent;
import android.content.pm.PackageManager;
import android.app.Activity;
import android.widget.Toast;

Activity act;
PackageManager pm;

// List of apps you want to launch (edit these)
String[] appNames = {
  "YouTube",
  "Chrome",
  "Settings",
  "Calculator",
  "Camera"
};

String[] packageNames = {
  "com.google.android.youtube",
  "com.android.chrome",
  "com.android.settings",
  "com.google.android.calculator",
  "com.android.camera2"          // may vary by device
};

int selected = -1;

void setup() {
  size(displayWidth, displayHeight, P2D);
  orientation(PORTRAIT);
  
  act = this.getActivity();
  pm = act.getPackageManager();
  
  textAlign(CENTER, CENTER);
}

void draw() {
  background(25);
  
  fill(255);
  textSize(42);
  text("APDE App Runner", width/2, 80);
  
  textSize(28);
  fill(180);
  text("Tap an app to launch it", width/2, 140);
  
  // Draw buttons
  for (int i = 0; i < appNames.length; i++) {
    float y = 220 + i * 110;
    
    if (selected == i) {
      fill(50, 130, 230);
    } else {
      fill(50);
    }
    
    rectMode(CENTER);
    rect(width/2, y, width - 80, 90, 20);
    
    fill(255);
    textSize(34);
    text(appNames[i], width/2, y);
  }
}

void mousePressed() {
  for (int i = 0; i < appNames.length; i++) {
    float y = 220 + i * 110;
    if (mouseY > y - 45 && mouseY < y + 45) {
      selected = i;
      launchApp(packageNames[i]);
      break;
    }
  }
}

void launchApp(String packageName) {
  try {
    Intent intent = pm.getLaunchIntentForPackage(packageName);
    
    if (intent != null) {
      intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
      act.startActivity(intent);
    } else {
      // App not installed
      Toast.makeText(act, "App not installed: " + packageName, Toast.LENGTH_SHORT).show();
    }
  } 
  catch (Exception e) {
    Toast.makeText(act, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
    e.printStackTrace();
  }
}

//////7//------------//////777777///////



import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.view.ViewGroup;
import android.app.Activity;
import android.widget.Toast;

Activity act;
WebView webView;

boolean webViewAdded = false;

// Change these
String startUrl = "https://www.google.com";          // online
// String startUrl = "file:///android_asset/index.html";  // local HTML from data folder

void setup() {
  size(displayWidth, displayHeight, P2D);
  orientation(PORTRAIT);
  
  act = this.getActivity();
  
  // Create WebView on UI thread
  act.runOnUiThread(new Runnable() {
    public void run() {
      createWebView();
    }
  });
}

void createWebView() {
  webView = new WebView(act);
  
  WebSettings settings = webView.getSettings();
  settings.setJavaScriptEnabled(true);          // enable JS
  settings.setDomStorageEnabled(true);
  settings.setLoadWithOverviewMode(true);
  settings.setUseWideViewPort(true);
  settings.setBuiltInZoomControls(true);
  settings.setDisplayZoomControls(false);
  settings.setAllowFileAccess(true);
  settings.setAllowContentAccess(true);
  
  // Open links inside the WebView (not external browser)
  webView.setWebViewClient(new WebViewClient());
  
  // Add WebView full screen
  act.addContentView(webView, new ViewGroup.LayoutParams(
    ViewGroup.LayoutParams.MATCH_PARENT,
    ViewGroup.LayoutParams.MATCH_PARENT
  ));
  
  webViewAdded = true;
  
  // Load the page
  webView.loadUrl(startUrl);
}

void draw() {
  // WebView draws itself – keep draw empty or very light
  if (!webViewAdded) {
    background(30);
    fill(255);
    textAlign(CENTER, CENTER);
    textSize(36);
    text("Loading HTML Runner...", width/2, height/2);
  }
}

// Optional: Go back with Android back button
@Override
public void onBackPressed() {
  act.runOnUiThread(new Runnable() {
    public void run() {
      if (webView != null && webView.canGoBack()) {
        webView.goBack();
      } else {
        // exit app
        act.finish();
      }
    }
  });
}

// Clean up
void onPause() {
  if (webView != null) {
    act.runOnUiThread(new Runnable() {
      public void run() {
        webView.onPause();
      }
    });
  }
  super.onPause();
}

void onResume() {
  super.onResume();
  if (webView != null) {
    act.runOnUiThread(new Runnable() {
      public void run() {
        webView.onResume();
      }
    });
  }
}

void onDestroy() {
  if (webView != null) {
    act.runOnUiThread(new Runnable() {
      public void run() {
        webView.destroy();
        webView = null;
      }
    });
  }
  super.onDestroy();
}


///-------------//////


import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.view.ViewGroup;
import android.app.Activity;
import android.widget.Toast;

Activity act;
WebView webView;

boolean webViewAdded = false;

// Change these
String startUrl = "https://www.google.com";          // online
// String startUrl = "file:///android_asset/index.html";  // local HTML from data folder

void setup() {
  size(displayWidth, displayHeight, P2D);
  orientation(PORTRAIT);
  
  act = this.getActivity();
  
  // Create WebView on UI thread
  act.runOnUiThread(new Runnable() {
    public void run() {
      createWebView();
    }
  });
}

void createWebView() {
  webView = new WebView(act);
  
  WebSettings settings = webView.getSettings();
  settings.setJavaScriptEnabled(true);          // enable JS
  settings.setDomStorageEnabled(true);
  settings.setLoadWithOverviewMode(true);
  settings.setUseWideViewPort(true);
  settings.setBuiltInZoomControls(true);
  settings.setDisplayZoomControls(false);
  settings.setAllowFileAccess(true);
  settings.setAllowContentAccess(true);
  
  // Open links inside the WebView (not external browser)
  webView.setWebViewClient(new WebViewClient());
  
  // Add WebView full screen
  act.addContentView(webView, new ViewGroup.LayoutParams(
    ViewGroup.LayoutParams.MATCH_PARENT,
    ViewGroup.LayoutParams.MATCH_PARENT
  ));
  
  webViewAdded = true;
  
  // Load the page
  webView.loadUrl(startUrl);
}

void draw() {
  // WebView draws itself – keep draw empty or very light
  if (!webViewAdded) {
    background(30);
    fill(255);
    textAlign(CENTER, CENTER);
    textSize(36);
    text("Loading HTML Runner...", width/2, height/2);
  }
}

// Optional: Go back with Android back button
@Override
public void onBackPressed() {
  act.runOnUiThread(new Runnable() {
    public void run() {
      if (webView != null && webView.canGoBack()) {
        webView.goBack();
      } else {
        // exit app
        act.finish();
      }
    }
  });
}

// Clean up
void onPause() {
  if (webView != null) {
    act.runOnUiThread(new Runnable() {
      public void run() {
        webView.onPause();
      }
    });
  }
  super.onPause();
}

void onResume() {
  super.onResume();
  if (webView != null) {
    act.runOnUiThread(new Runnable() {
      public void run() {
        webView.onResume();
      }
    });
  }
}

void onDestroy() {
  if (webView != null) {
    act.runOnUiThread(new Runnable() {
      public void run() {
        webView.destroy();
        webView = null;
      }
    });
  }
  super.onDestroy();
}


///--------------////////////


























































































