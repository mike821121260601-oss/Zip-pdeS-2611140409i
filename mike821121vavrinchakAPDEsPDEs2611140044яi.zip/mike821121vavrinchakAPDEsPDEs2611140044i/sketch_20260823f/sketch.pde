






// APDE / Processing P3D – 66-ball billiard
// Table 1.0 × 1.666, ball Ø ≈ 0.060, strength 666 system

int NUM = 66;
float TABLE_W = 1.0;
float TABLE_H = 1.666;
float BALL_D  = 1.0 / 16.66;          // ≈ 0.060
float BALL_R  = BALL_D * 0.5;
float MARGIN  = 0.1666;               // 16.66 % of sides
float STRENGTH0 = 666.0;
float COLLISION_FACTOR = 0.666;
float POINT_OFF = 0.0666;             // 6.66 %

Ball[] balls = new Ball[NUM];
boolean collisionsEnabled = false;
int frameStart = 0;

void setup() {
  size(900, 1500, P3D);               // tall window for 1 : 1.666 ratio
  frameRate(60);
  ortho();                            // keep proportions clean
  randomSeed(666);
  
  // place balls randomly inside safe zone
  for (int i = 0; i < NUM; i++) {
    float x, y;
    boolean ok;
    do {
      ok = true;
      x = random(MARGIN + BALL_R, TABLE_W - MARGIN - BALL_R);
      y = random(MARGIN + BALL_R, TABLE_H - MARGIN - BALL_R);
      for (int j = 0; j < i; j++) {
        if (dist(x, y, balls[j].x, balls[j].y) < BALL_D * 1.05) {
          ok = false;
          break;
        }
      }
    } while (!ok);
    
    float ang = random(TWO_PI);
    float str = STRENGTH0 * random(0.7, 1.0);
    balls[i] = new Ball(x, y, cos(ang)*str*0.001, sin(ang)*str*0.001, str);
  }
  frameStart = frameCount;
}

void draw() {
  background(20);
  
  // camera looking straight down at table
  float scale = min(width / TABLE_W, height / TABLE_H) * 0.92;
  translate(width/2, height/2, 0);
  scale(scale);
  translate(-TABLE_W/2, -TABLE_H/2, 0);
  
  // enable collisions after a short “666” delay
  if (!collisionsEnabled && frameCount - frameStart > 30) {
    collisionsEnabled = true;
  }
  
  // board
  pushMatrix();
  translate(TABLE_W/2, TABLE_H/2, -BALL_R-0.01);
  fill(30, 90, 40);
  noStroke();
  box(TABLE_W, TABLE_H, 0.02);
  popMatrix();
  
  // cushions (thin rectangles)
  stroke(180);
  strokeWeight(0.008);
  noFill();
  rect(0, 0, TABLE_W, TABLE_H);
  
  // center-side perpendicular points (6.66 %)
  stroke(255, 200, 50);
  strokeWeight(0.012);
  float px = TABLE_W * POINT_OFF;
  float py = TABLE_H * POINT_OFF;
  // top / bottom
  line(TABLE_W/2, 0, TABLE_W/2, py);
  line(TABLE_W/2, TABLE_H, TABLE_W/2, TABLE_H - py);
  // left / right
  line(0, TABLE_H/2, px, TABLE_H/2);
  line(TABLE_W, TABLE_H/2, TABLE_W - px, TABLE_H/2);
  
  // physics + draw
  for (Ball b : balls) {
    b.move();
    b.bounce();
  }
  
  if (collisionsEnabled) {
    for (int i = 0; i < NUM; i++) {
      for (int j = i+1; j < NUM; j++) {
        balls[i].collide(balls[j]);
      }
    }
  }
  
  for (Ball b : balls) {
    b.display();
  }
  
  // HUD
  camera();
  fill(255);
  textSize(16);
  text("66 balls | strength system 666 → ×0.666 on hit | no out", 20, 30);
  text("collisions: " + (collisionsEnabled ? "ON" : "waiting…"), 20, 50);
}

class Ball {
  float x, y, vx, vy;
  float strength;
  color c;
  
  Ball(float x, float y, float vx, float vy, float s) {
    this.x = x; this.y = y;
    this.vx = vx; this.vy = vy;
    this.strength = s;
    this.c = color(random(180,255), random(100,220), random(50,150));
  }
  
  void move() {
    // “MOVE DOWN -1” bias
    vy += 0.00002;                    // tiny downward drift
    x += vx;
    y += vy;
    
    // friction / strength decay
    float fric = 0.995;
    vx *= fric;
    vy *= fric;
    strength *= 0.9995;
  }
  
  void bounce() {
    // hard cushions – balls never leave
    if (x < BALL_R) { x = BALL_R; vx = abs(vx); }
    if (x > TABLE_W - BALL_R) { x = TABLE_W - BALL_R; vx = -abs(vx); }
    if (y < BALL_R) { y = BALL_R; vy = abs(vy); }
    if (y > TABLE_H - BALL_R) { y = TABLE_H - BALL_R; vy = -abs(vy); }
  }
  
  void collide(Ball o) {
    float dx = o.x - x;
    float dy = o.y - y;
    float d  = sqrt(dx*dx + dy*dy);
    if (d < BALL_D && d > 0.0001) {
      // separate
      float overlap = BALL_D - d;
      float nx = dx / d;
      float ny = dy / d;
      x -= nx * overlap * 0.5;
      y -= ny * overlap * 0.5;
      o.x += nx * overlap * 0.5;
      o.y += ny * overlap * 0.5;
      
      // simple elastic exchange scaled by remaining strength
      float dvx = vx - o.vx;
      float dvy = vy - o.vy;
      float impact = dvx*nx + dvy*ny;
      if (impact > 0) return;         // already separating
      
      float mag = impact * 0.9;
      vx -= mag * nx;
      vy -= mag * ny;
      o.vx += mag * nx;
      o.vy += mag * ny;
      
      // your rule: both lose strength → ×0.666
      strength *= COLLISION_FACTOR;
      o.strength *= COLLISION_FACTOR;
    }
  }
  
  void display() {
    pushMatrix();
    translate(x, y, 0);
    fill(c);
    noStroke();
    sphereDetail(12);
    sphere(BALL_R);
    
    // tiny strength indicator
    if (strength > 1) {
      stroke(255, 255, 0, 180);
      strokeWeight(0.004);
      line(0, 0, vx*8, vy*8);
    }
    popMatrix();
  }
}

void keyPressed() {
  if (key == 'r' || key == 'R') {
    setup();                          // restart with new random layout
  }
}






































