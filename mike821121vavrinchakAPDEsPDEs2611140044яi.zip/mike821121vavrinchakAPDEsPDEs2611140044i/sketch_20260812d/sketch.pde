






float[] yx = new float[50];
float[] yy = new float[50];
float[] yvx = new float[50];
float[] yvy = new float[50];

float[] bx = new float[50];
float[] by = new float[50];
float[] bvx = new float[50];
float[] bvy = new float[50];

float wx, wy;
float wvx, wvy;

int points = 0;

float R;
float whiteR;

void settings() {
}

void setup() {
  size(displayWidth, displayHeight, P2D);
  orientation(PORTRAIT);

  R = displayWidth / 60.0 + displayHeight / 60.0;
  whiteR = R * 1.25;

  // YELLOW
  for (int i = 0; i < 50; i++) {
    yx[i] = random(R, width - R);
    yy[i] = random(R, height - R);

    yvx[i] = random(-1.5, 1.5);
    yvy[i] = random(-1.5, 1.5);

    if (abs(yvx[i]) < 0.3) yvx[i] = 0.8;
    if (abs(yvy[i]) < 0.3) yvy[i] = 0.8;
  }

  // BLUE
  for (int i = 0; i < 50; i++) {
    bx[i] = random(R, width - R);
    by[i] = random(R, height - R);

    bvx[i] = random(-1.5, 1.5);
    bvy[i] = random(-1.5, 1.5);

    if (abs(bvx[i]) < 0.3) bvx[i] = -0.8;
    if (abs(bvy[i]) < 0.3) bvy[i] = -0.8;
  }

  // WHITE ENGINE
  wx = width / 2;
  wy = height / 2;

  wvx = 0;
  wvy = 0;
}

void draw() {

  background(0);

  // ==========================================
  // YELLOW MOVEMENT
  // ==========================================

  for (int i = 0; i < 50; i++) {

    yx[i] += yvx[i];
    yy[i] += yvy[i];

    if (yx[i] < R) {
      yx[i] = R;
      yvx[i] = abs(yvx[i]);
    }

    if (yx[i] > width - R) {
      yx[i] = width - R;
      yvx[i] = -abs(yvx[i]);
    }

    if (yy[i] < R) {
      yy[i] = R;
      yvy[i] = abs(yvy[i]);
    }

    if (yy[i] > height - R) {
      yy[i] = height - R;
      yvy[i] = -abs(yvy[i]);
    }
  }


  // ==========================================
  // BLUE MOVEMENT
  // ==========================================

  for (int i = 0; i < 50; i++) {

    bx[i] += bvx[i];
    by[i] += bvy[i];

    if (bx[i] < R) {
      bx[i] = R;
      bvx[i] = abs(bvx[i]);
    }

    if (bx[i] > width - R) {
      bx[i] = width - R;
      bvx[i] = -abs(bvx[i]);
    }

    if (by[i] < R) {
      by[i] = R;
      bvy[i] = abs(bvy[i]);
    }

    if (by[i] > height - R) {
      by[i] = height - R;
      bvy[i] = -abs(bvy[i]);
    }
  }


  // ==========================================
  // YELLOW-YELLOW COLLISION
  // ==========================================

  for (int i = 0; i < 50; i++) {
    for (int j = i + 1; j < 50; j++) {

      float dx = yx[j] - yx[i];
      float dy = yy[j] - yy[i];

      float d = sqrt(dx * dx + dy * dy);

      if (d > 0 && d < R) {

        float nx = dx / d;
        float ny = dy / d;

        float push = (R - d) * 0.5;

        yx[i] -= nx * push;
        yy[i] -= ny * push;

        yx[j] += nx * push;
        yy[j] += ny * push;

        float tx = yvx[i];
        float ty = yvy[i];

        yvx[i] = yvx[j];
        yvy[i] = yvy[j];

        yvx[j] = tx;
        yvy[j] = ty;
      }
    }
  }


  // ==========================================
  // BLUE-BLUE COLLISION
  // ==========================================

  for (int i = 0; i < 50; i++) {
    for (int j = i + 1; j < 50; j++) {

      float dx = bx[j] - bx[i];
      float dy = by[j] - by[i];

      float d = sqrt(dx * dx + dy * dy);

      if (d > 0 && d < R) {

        float nx = dx / d;
        float ny = dy / d;

        float push = (R - d) * 0.5;

        bx[i] -= nx * push;
        by[i] -= ny * push;

        bx[j] += nx * push;
        by[j] += ny * push;

        float tx = bvx[i];
        float ty = bvy[i];

        bvx[i] = bvx[j];
        bvy[i] = bvy[j];

        bvx[j] = tx;
        bvy[j] = ty;
      }
    }
  }


  // ==========================================
  // YELLOW-BLUE COLLISION
  // ==========================================

  for (int i = 0; i < 50; i++) {

    for (int j = 0; j < 50; j++) {

      float dx = bx[j] - yx[i];
      float dy = by[j] - yy[i];

      float d = sqrt(dx * dx + dy * dy);

      if (d > 0 && d < R) {

        float nx = dx / d;
        float ny = dy / d;

        float push = R - d;

        yx[i] -= nx * push * 0.5;
        yy[i] -= ny * push * 0.5;

        bx[j] += nx * push * 0.5;
        by[j] += ny * push * 0.5;

        yvx[i] -= nx * 0.03;
        yvy[i] -= ny * 0.03;

        bvx[j] += nx * 0.03;
        bvy[j] += ny * 0.03;
      }
    }
  }


  // ==========================================
  // WHITE THINKING ENGINE
  // ==========================================

  int target = -1;
  float bestDistance = 999999999;

  // Find nearest yellow circle
  for (int i = 0; i < 50; i++) {

    float dx = yx[i] - wx;
    float dy = yy[i] - wy;

    float d = dx * dx + dy * dy;

    if (d < bestDistance) {
      bestDistance = d;
      target = i;
    }
  }


  // ==========================================
  // THINKING
  // ==========================================

  if (target >= 0) {

    float dx = yx[target] - wx;
    float dy = yy[target] - wy;

    float d = sqrt(dx * dx + dy * dy);

    if (d > 1) {

      // Engine accelerates toward target
      wvx += dx / d * 0.035;
      wvy += dy / d * 0.035;
    }
  }


  // ==========================================
  // WHITE AVOIDS BLUE
  // ==========================================

  for (int i = 0; i < 50; i++) {

    float dx = wx - bx[i];
    float dy = wy - by[i];

    float d = sqrt(dx * dx + dy * dy);

    if (d > 0 && d < R * 5) {

      float force = (R * 5 - d) / (R * 5);

      wvx += dx / d * force * 0.15;
      wvy += dy / d * force * 0.15;
    }
  }


  // ==========================================
  // LIMIT WHITE SPEED
  // ==========================================

  float speed = sqrt(wvx * wvx + wvy * wvy);

  if (speed > 4) {
    wvx = wvx / speed * 4;
    wvy = wvy / speed * 4;
  }

  wx += wvx;
  wy += wvy;


  // ==========================================
  // WHITE SCREEN BOUNCE
  // ==========================================

  if (wx < whiteR) {
    wx = whiteR;
    wvx = abs(wvx);
  }

  if (wx > width - whiteR) {
    wx = width - whiteR;
    wvx = -abs(wvx);
  }

  if (wy < whiteR) {
    wy = whiteR;
    wvy = abs(wvy);
  }

  if (wy > height - whiteR) {
    wy = height - whiteR;
    wvy = -abs(wvy);
  }


  // ==========================================
  // WHITE CATCHES YELLOW
  // ==========================================

  for (int i = 0; i < 50; i++) {

    float dx = yx[i] - wx;
    float dy = yy[i] - wy;

    float d = sqrt(dx * dx + dy * dy);

    if (d < whiteR + R) {

      points++;

      // New yellow position
      yx[i] = random(R, width - R);
      yy[i] = random(R, height - R);

      yvx[i] = random(-1.5, 1.5);
      yvy[i] = random(-1.5, 1.5);
    }
  }


  // ==========================================
  // DRAW YELLOW
  // ==========================================

  noStroke();

  for (int i = 0; i < 50; i++) {

    fill(255, 255, 0);

    ellipse(
      yx[i],
      yy[i],
      R,
      R
    );
  }


  // ==========================================
  // DRAW BLUE
  // ==========================================

  for (int i = 0; i < 50; i++) {

    fill(0, 100, 255);

    ellipse(
      bx[i],
      by[i],
      R,
      R
    );
  }


  // ==========================================
  // DRAW WHITE ENGINE CIRCLE
  // ==========================================

  fill(255);

  ellipse(
    wx,
    wy,
    whiteR,
    whiteR
  );


  // ==========================================
  // POINTS
  // ==========================================

  fill(255);

  textSize(35);

  text(
    "POINTS: " + points,
    20,
    45
  );


  // ==========================================
  // ENGINE STATUS
  // ==========================================

  textSize(22);

  if (target >= 0) {

    text(
      "THINKING",
      20,
      75
    );

  }
}









