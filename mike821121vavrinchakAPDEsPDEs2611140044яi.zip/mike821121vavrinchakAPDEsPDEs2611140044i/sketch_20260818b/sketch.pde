

// FIGHTER GAME FOR APDE (ANDROID)
// Touch-based controls with articulated characters

Fighter p1, p2;
float btnW = 120; 
float btnH = 80;

void setup() {
  fullScreen(); // Use full screen for Android
  p1 = new Fighter(100, height - 200, color(0, 255, 0)); // Green Fighter
  p2 = new Fighter(width - 200, height - 200, color(255, 0, 0)); // Red Fighter
}

void draw() {
  background(135, 206, 235); // Sky blue

  // Ground
  fill(34, 139, 34);
  rect(0, height - 100, width, 100);

  p1.update();
  p1.display();
  
  p2.update();
  p2.display();

  drawTouchControls();
}

// --- FIGHTER CLASS ---
class Fighter {
  float x, y, w = 40, h = 100;
  float vy = 0;
  boolean jumping = false;
  color col;

  Fighter(float x, float y, color c) {
    this.x = x;
    this.y = y;
    this.col = c;
  }

  void update() {
    if (jumping) {
      vy += 1.2; // Gravity
      y += vy;
      if (y >= height - 200) {
        y = height - 200;
        jumping = false;
        vy = 0;
      }
    }
  }

  void jump() {
    if (!jumping) {
      jumping = true;
      vy = -30;
    }
  }

  void move(float dir) {
    x += dir * 10;
  }

  void display() {
    stroke(0);
    strokeWeight(4);
    
    // HEAD
    fill(col);
    ellipse(x + 20, y, 40, 40);
    
    // BODY
    line(x + 20, y + 20, x + 20, y + 70);
    
    // HANDS (Arms)
    line(x + 20, y + 40, x, y + 60);      // Left Hand
    line(x + 20, y + 40, x + 40, y + 60); // Right Hand
    
    // FEET (Legs)
    line(x + 20, y + 70, x + 10, y + 100); // Left Foot
    line(x + 20, y + 70, x + 30, y + 100); // Right Foot
  }
}

// --- TOUCH INTERFACE ---
void drawTouchControls() {
  fill(200, 200, 200, 150);
  
  // Player 1 Buttons (Left side)
  rect(20, height - 120, btnW, btnH); // Left
  rect(150, height - 120, btnW, btnH); // Right
  rect(90, height - 220, btnW, btnH); // Jump
  
  // Player 2 Buttons (Right side)
  rect(width - 260, height - 120, btnW, btnH); // Left
  rect(width - 130, height - 120, btnW, btnH); // Right
  rect(width - 190, height - 220, btnW, btnH); // Jump
  
  fill(0);
  textAlign(CENTER);
  text("L", 80, height - 70);
  text("R", 210, height - 70);
  text("JUMP", 150, height - 170);
  
  text("L", width - 200, height - 70);
  text("R", width - 70, height - 70);
  text("JUMP", width - 130, height - 170);
}

// --- TOUCH INPUT HANDLING ---
void mousePressed() {
  float tx = mouseX;
  float ty = mouseY;

  // P1 Controls
  if (ty > height - 120) {
    if (tx > 20 && tx < 140) p1.move(-1); // P1 Left
    if (tx > 150 && tx < 270) p1.move(1);  // P1 Right
  }
  if (ty > height - 220 && ty < height - 120) {
    if (tx > 90 && tx < 210) p1.jump();    // P1 Jump
  }

  // P2 Controls
  if (ty > height - 120) {
    if (tx > width - 260 && tx < width - 140) p2.move(-1); // P2 Left
    if (tx > width - 130 && tx < width - 10) p2.move(1);    // P2 Right
  }
  if (ty > height - 220 && ty < height - 120) {
    if (tx > width - 190 && tx < width - 90) p2.jump();     // P2 Jump
  }
}






























