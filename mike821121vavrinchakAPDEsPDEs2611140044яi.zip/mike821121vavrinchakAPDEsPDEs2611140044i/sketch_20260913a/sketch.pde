







/*
// ChessGame.pde - A foundational 2D board setup
int tileSize;
int[][] board = new int[8][8];

void setup() {
  size(600, 600);
  tileSize = width / 8;
  setupBoard();
}

void draw() {
  drawBoard();
}

void setupBoard() {
  // 0 = Empty, 1 = Pawn, 2 = Rook, 3 = Knight, 4 = Bishop, 5 = Queen, 6 = King
  // (Positive numbers for White, negative numbers for Black)
  
  // Set up Pawns
  for(int i = 0; i < 8; i++) {
    board[i][1] = -1; // Black pawns
    board[i][6] = 1;  // White pawns
  }
  
  // Set up major pieces (Row 0 for Black, Row 7 for White)
  int[] backRow = {2, 3, 4, 5, 6, 4, 3, 2};
  for(int i = 0; i < 8; i++) {
    board[i][0] = -backRow[i];
    board[i][7] = backRow[i];
  }
}

void drawBoard() {
  for (int x = 0; x < 8; x++) {
    for (int y = 0; y < 8; y++) {
      // Alternate tile colors
      if ((x + y) % 2 == 0) {
        fill(240, 217, 181); // Light square
      } else {
        fill(181, 136, 99);  // Dark square
      }
      rect(x * tileSize, y * tileSize, tileSize, tileSize);
      
      // Draw placeholder text for pieces
      if (board[x][y] != 0) {
        fill(board[x][y] > 0 ? 255 : 0);
        textAlign(CENTER, CENTER);
        textSize(16);
        text(getPieceName(board[x][y]), x * tileSize + tileSize/2, y * tileSize + tileSize/2);
      }
    }
  }
}

String getPieceName(int piece) {
  switch(abs(piece)) {
    case 1: return "P";
    case 2: return "R";
    case 3: return "N";
    case 4: return "B";
    case 5: return "Q";
    case 6: return "K";
    default: return "";
  }
}

*/


/*
void setup() {
  fullScreen();
  // sketch looks transparent-ish on a dark UI
}

void draw() {
  // don't call background() if you want strokes to stay
  if (mousePressed) {
    stroke(255, 40, 40);
    strokeWeight(8 * displayDensity);
    line(pmouseX, pmouseY, mouseX, mouseY);
  }
}

*/





/*

boolean flying = false;

float btnX, btnY, btnW, btnH;

void setup() {
  fullScreen();
  orientation(PORTRAIT);

  btnW = 220 * displayDensity;
  btnH = 72 * displayDensity;
  btnX = width * 0.5;
  btnY = 90 * displayDensity;
}

void draw() {
  background(48);

  drawFlyButton(btnX, btnY, btnW, btnH, flying);

  fill(255);
  textAlign(CENTER, CENTER);
  textSize(28 * displayDensity);
  text(flying ? "FLYING" : "IDLE", width * 0.5, height * 0.5);
}

void drawFlyButton(float cx, float cy, float w, float h, boolean active) {
  float left = cx - w * 0.5;
  float top  = cy - h * 0.5;
  float r    = h * 0.5;

  // capsule outline made from lines + arcs
  stroke(active ? color(40, 200, 90) : color(30, 160, 80));
  strokeWeight(4 * displayDensity);
  noFill();

  // top and bottom straight lines of the pill
  line(left + r, top, left + w - r, top);
  line(left + r, top + h, left + w - r, top + h);

  // rounded ends
  arc(left + r, cy, h, h, HALF_PI, PI + HALF_PI);
  arc(left + w - r, cy, h, h, -HALF_PI, HALF_PI);

  // divider line (like the APDE play | menu control)
  float mid = left + w * 0.58;
  line(mid, top + 14 * displayDensity, mid, top + h - 14 * displayDensity);

  // play / fly triangle drawn as 3 lines
  float tx = left + w * 0.28;
  float ty = cy;
  float s  = h * 0.28;
  strokeWeight(5 * displayDensity);
  line(tx - s * 0.35, ty - s, tx - s * 0.35, ty + s);
  line(tx - s * 0.35, ty - s, tx + s, ty);
  line(tx - s * 0.35, ty + s, tx + s, ty);

  // hamburger made of lines
  float hx = left + w * 0.78;
  float gap = 8 * displayDensity;
  float hw  = 16 * displayDensity;
  line(hx - hw, ty - gap, hx + hw, ty - gap);
  line(hx - hw, ty,       hx + hw, ty);
  line(hx - hw, ty + gap, hx + hw, ty + gap);
}

boolean hitFly(float x, float y) {
  return x > btnX - btnW * 0.5 && x < btnX + btnW * 0.5 &&
         y > btnY - btnH * 0.5 && y < btnY + btnH * 0.5;
}

void mousePressed() {
  if (hitFly(mouseX, mouseY)) {
    flying = !flying;
  }
}

*/


