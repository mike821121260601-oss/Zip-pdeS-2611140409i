/**
 * Android Sound Track Builder  Reverse  Timeline
 *  Record mic  File 1
 * - Reverse  File 2
 * - Play File 1 (forward) or File 2 (reversed)
 * - Draw simple pencillines / markersevery \10 s
 * Memory-friendly forsmall devices(target ≤ 50 MB)
 */

/*. */

import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.AudioManager;
import android.media.MediaRecorder;
import android.os.Environment;
import java.io.*;

int SAMPLE_RATE = 22050;       
   // lower = longer track for same MB
int CHANNEL_IN  = AudioFormat.CHANNEL_IN_MONO;
int CHANNEL_OUT = AudioFormat.CHANNEL_OUT_MONO;
int ENCODING    = AudioFormat.ENCODING_PCM_16BIT;
int BYTES_PER_SAMPLE = 2;

AudioRecord recorder;
AudioTrack  player;
boolean isRecording = false;
boolean isPlaying   = false;

File file1, file2;            
    // File 1 = original, File 2 = reversed
String path1, path2;

int bufferSize;
short[] buffer;

// Simple timeline drawing
float timelineY;
float pixelsPerSecond;
long  recordedSamples = 0;

void setup() {
  fullScreen();
  orientation(PORTRAIT);
  textAlign(CENTER, CENTER);
  textSize(36);

  bufferSize = AudioRecord.getMinBufferSize
  (SAMPLE_RATE, CHANNEL_IN, ENCODING);
  bufferSize = max(bufferSize, 4096);
  buffer = new short[bufferSize / 2];

 // Files in app external files dir 
//(safer on modern Android)
 File dir = getActivity().getExternalFilesDir
 (null);
  file1 = new File(dir, "track1.pcm");
  file2 = new File(dir, "track2_reversed.pcm");
  path1 = file1.getAbsolutePath();
  path2 = file2.getAbsolutePath();

  timelineY = height * 0.75;
  pixelsPerSecond = width / 60.0; 
  // rough scale – adjust later

  println("Ready. Max practical size 50 MB");
}

void draw() {
  background(20);

  // Buttons
  drawButton(width*0.1, height*0.08,
 width*0.35, height*0.12, 
isRecording ? "STOP REC" : "REC MIC",
 color(200, 50, 50));
  drawButton(width*0.55, height*0.08,
 width*0.35, height*0.12, "REVERSE  File2",
 color(80, 80, 200));
  drawButton(width*0.1, height*0.25,
 width*0.35, height*0.12, "PLAY File1", 
color(50, 180, 80));
  drawButton(width*0.55, height*0.25,
 width*0.35, height*0.12, "PLAY File2 (REV)",
 color(180, 120, 40));

  // Info
  fill(220);
  textSize(28);
  text
("Track size limit 50 MB", width/2, height*0.42);
  text
("File1: original   File2: reversed", 
width/2, height*0.48);
  if (file1.exists()) {
    float mb = file1.length() / (1024.0*1024.0);
    text(String.format
("File1: %.2f MB", mb), width/2, height*0.54);
  }

  // === Pencil / timeline line drawing ===
  stroke(100);
  strokeWeight(2);
  line(0, timelineY, width, timelineY);   
       // main baseline

 // Markers every \10seconds(visual seek helpers)
  stroke(180, 180, 60);
  strokeWeight(3);
  for (int sec = 0; sec <= 60; sec += 10) {
    float x = sec * pixelsPerSecond;
    if (x > width) break;
    line(x, timelineY - 25, x, timelineY + 25);
  // vertical tick
    fill(200);
    textSize(22);
    text(sec + "s", x, timelineY + 45);
  }

  // Simple “bits / amplitude” sketch
// line (live while recording)
  if (isRecording && buffer != null) {
    stroke(0, 255, 150);
    strokeWeight(1.5);
    noFill();
    beginShape();
  for 
(int i = 0; i < min(buffer.length, 200); i++) {
      float x = map(i, 0, 200, 0, width);
  float y = timelineY - map(abs(buffer[i]), 
   0, 8000, 0, 80);
      vertex(x, y);
    }
    endShape();
  }
}

void drawButton
(float x, float y, float w, float h,
   String label, int col) {
  fill(col);
  rect(x, y, w, h, 20);
  fill(255);
  textSize(32);
  text(label, x + w/2, y + h/2);
}

void mousePressed() {
  // REC / STOP
  if 
(mouseY > height*0.08 && mouseY < height*0.20) {
    if (mouseX < width*0.5) {
      if (!isRecording) startRecording();
      else stopRecording();
    } else {
      // REVERSE button
  if (file1.exists()) reverseFile(file1, file2);
    }
  }
  // PLAY buttons
  if 
(mouseY > height*0.25 && mouseY < height*0.37) {
 if (mouseX < width*0.5) playFile(file1, false);  
 // forward
    else playFile(file2, true);                       // already reversed
  }
}

// ---------- RECORD ----------
void startRecording() {
  try {
    recorder = new 
 AudioRecord(MediaRecorder.AudioSource.MIC,
                             
  SAMPLE_RATE, CHANNEL_IN, ENCODING, bufferSize);

    if (recorder.getState() !=
   AudioRecord.STATE_INITIALIZED) {
      println("AudioRecord init failed");
      return;
    }


final




    FileOutputStream fos =
  new FileOutputStream(file1);
    isRecording = true;
    recorder.startRecording();
    recordedSamples = 0;

    new Thread(new Runnable() {
      public void run() {
        while (isRecording) {
          int read = 
    recorder.read(buffer, 0, buffer.length);
          if (read > 0) {
            try {
    // write short[] as little-endian bytes
              byte[] bytes = new byte[read * 2];
              for (int i = 0; i < read; i++) {
                bytes[i*2]     =
      (byte)(buffer[i] & 0xff);
                bytes[i*2 + 1] =
   (byte)((buffer[i] >> 8) & 0xff);
              }
              fos.write(bytes);
              recordedSamples += read;
            } catch (IOException e)
    { e.printStackTrace(); }
          }
        }
  try { fos.close(); } catch (Exception e) {}
      }
    }).start();

    println("Recording started  " + path1);
  } catch (Exception e) {
    println("Rec error: " + e);
  }
}

void stopRecording() {
  isRecording = false;
  if (recorder != null) {
    recorder.stop();
    recorder.release();
    recorder = null;
  }
  println("Stopped. Samples: " + recordedSamples);
}

// ---------- REVERSE (File1  File2) ----------
void reverseFile(File src, File dst) {
  println
("Reversing…(keepfilesreasonably short forlowRAM)");
  try {
    long len = src.length();
    if (len > 50L * 1024 * 1024) {
      println
 ("File > 50 MB  refuse for memory safety");
      return;
    }

    // Read all samples (for short/medium files). 
//For huge files do chunked reverse later.
    int numSamples = (int)(len / 2);
    short[] samples = new short[numSamples];

    DataInputStream dis =
 new DataInputStream(new FileInputStream(src));
    for (int i = 0; i < numSamples; i++) {
      samples[i] = dis.readShort();  
 // big-endian read  Android files are usually 
// LE, fix if needed
    }
    dis.close();

    // Simple reverse
    DataOutputStream dos = new DataOutputStream
  (new FileOutputStream(dst));
    for (int i = numSamples - 1; i >= 0; i--) {
      dos.writeShort(samples[i]);
    }
    dos.close();
    println("Reversed  " + path2);
  } catch (Exception e) {
    println("Reverse error: " + e);
    e.printStackTrace();
  }
}

// ---------- PLAY ----------
void playFile(


final


File f, boolean alreadyReversed) {
  if (!f.exists() || isPlaying) return;
  isPlaying = true;

  new Thread(new Runnable() {
    public void run() {
      try {
        int minBuf = AudioTrack.getMinBufferSize
(SAMPLE_RATE, CHANNEL_OUT, ENCODING);
        player = new AudioTrack
  (AudioManager.STREAM_MUSIC,
                              

  SAMPLE_RATE, CHANNEL_OUT, ENCODING,
                            

    minBuf, AudioTrack.MODE_STREAM);
        player.play();

    FileInputStream fis = new FileInputStream(f);
        byte[] byteBuf = new byte[minBuf];
        int n;
        while ((n = fis.read(byteBuf)) > 0 &&
         isPlaying) {
          player.write(byteBuf, 0, n);
        }
        fis.close();
        player.stop();
        player.release();
        player = null;
      } catch (Exception e) {
        println("Play error: " + e);
      }
      isPlaying = false;
    }
  }).start();
}

// Clean up
public void pause() {
  super.pause();
  isRecording = false;
  isPlaying = false;
  if (recorder != null)
 { recorder.release(); recorder = null; }
  if (player != null) 
  { player.release();   player = null; }
}



/*

*/







/*


/**
 * Android Sound Track Builder  Reverse  Timeline
 *  Record mic  File 1
 * - Reverse  File 2
 * - Play File 1 (forward) or File 2 (reversed)
 * - Draw simple pencillines / markersevery \10 s
 * Memory-friendly forsmall devices(target ≤ 50 MB)
 */

/*

import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.AudioManager;
import android.media.MediaRecorder;
import android.os.Environment;
import java.io.*;

int SAMPLE_RATE = 22050;       
   // lower = longer track for same MB
int CHANNEL_IN  = AudioFormat.CHANNEL_IN_MONO;
int CHANNEL_OUT = AudioFormat.CHANNEL_OUT_MONO;
int ENCODING    = AudioFormat.ENCODING_PCM_16BIT;
int BYTES_PER_SAMPLE = 2;

AudioRecord recorder;
AudioTrack  player;
boolean isRecording = false;
boolean isPlaying   = false;

File file1, file2;            
    // File 1 = original, File 2 = reversed
String path1, path2;

int bufferSize;
short[] buffer;

// Simple timeline drawing
float timelineY;
float pixelsPerSecond;
long  recordedSamples = 0;

void setup() {
  fullScreen();
  orientation(PORTRAIT);
  textAlign(CENTER, CENTER);
  textSize(36);

  bufferSize = AudioRecord.getMinBufferSize
  (SAMPLE_RATE, CHANNEL_IN, ENCODING);
  bufferSize = max(bufferSize, 4096);
  buffer = new short[bufferSize / 2];

 // Files in app external files dir 
//(safer on modern Android)
 File dir = getActivity().getExternalFilesDir
 (null);
  file1 = new File(dir, "track1.pcm");
  file2 = new File(dir, "track2_reversed.pcm");
  path1 = file1.getAbsolutePath();
  path2 = file2.getAbsolutePath();

  timelineY = height * 0.75;
  pixelsPerSecond = width / 60.0; 
  // rough scale – adjust later

  println("Ready. Max practical size 50 MB");
}

void draw() {
  background(20);

  // Buttons
  drawButton(width*0.1, height*0.08,
 width*0.35, height*0.12, 
isRecording ? "STOP REC" : "REC MIC",
 color(200, 50, 50));
  drawButton(width*0.55, height*0.08,
 width*0.35, height*0.12, "REVERSE  File2",
 color(80, 80, 200));
  drawButton(width*0.1, height*0.25,
 width*0.35, height*0.12, "PLAY File1", 
color(50, 180, 80));
  drawButton(width*0.55, height*0.25,
 width*0.35, height*0.12, "PLAY File2 (REV)",
 color(180, 120, 40));

  // Info
  fill(220);
  textSize(28);
  text
("Track size limit 50 MB", width/2, height*0.42);
  text
("File1: original   File2: reversed", 
width/2, height*0.48);
  if (file1.exists()) {
    float mb = file1.length() / (1024.0*1024.0);
    text(String.format
("File1: %.2f MB", mb), width/2, height*0.54);
  }

  // === Pencil / timeline line drawing ===
  stroke(100);
  strokeWeight(2);
  line(0, timelineY, width, timelineY);   
       // main baseline

 // Markers every \10seconds(visual seek helpers)
  stroke(180, 180, 60);
  strokeWeight(3);
  for (int sec = 0; sec <= 60; sec += 10) {
    float x = sec * pixelsPerSecond;
    if (x > width) break;
    line(x, timelineY - 25, x, timelineY + 25);
  // vertical tick
    fill(200);
    textSize(22);
    text(sec + "s", x, timelineY + 45);
  }

  // Simple “bits / amplitude” sketch
// line (live while recording)
  if (isRecording && buffer != null) {
    stroke(0, 255, 150);
    strokeWeight(1.5);
    noFill();
    beginShape();
  for 
(int i = 0; i < min(buffer.length, 200); i++) {
      float x = map(i, 0, 200, 0, width);
  float y = timelineY - map(abs(buffer[i]), 
   0, 8000, 0, 80);
      vertex(x, y);
    }
    endShape();
  }
}

void drawButton
(float x, float y, float w, float h,
   String label, int col) {
  fill(col);
  rect(x, y, w, h, 20);
  fill(255);
  textSize(32);
  text(label, x + w/2, y + h/2);
}

void mousePressed() {
  // REC / STOP
  if 
(mouseY > height*0.08 && mouseY < height*0.20) {
    if (mouseX < width*0.5) {
      if (!isRecording) startRecording();
      else stopRecording();
    } else {
      // REVERSE button
  if (file1.exists()) reverseFile(file1, file2);
    }
  }
  // PLAY buttons
  if 
(mouseY > height*0.25 && mouseY < height*0.37) {
 if (mouseX < width*0.5) playFile(file1, false);  
 // forward
    else playFile(file2, true);                       // already reversed
  }
}

// ---------- RECORD ----------
void startRecording() {
  try {
    recorder = new 
 AudioRecord(MediaRecorder.AudioSource.MIC,
                             
  SAMPLE_RATE, CHANNEL_IN, ENCODING, bufferSize);

    if (recorder.getState() !=
   AudioRecord.STATE_INITIALIZED) {
      println("AudioRecord init failed");
      return;
    }


final




    FileOutputStream fos =
  new FileOutputStream(file1);
    isRecording = true;
    recorder.startRecording();
    recordedSamples = 0;

    new Thread(new Runnable() {
      public void run() {
        while (isRecording) {
          int read = 
    recorder.read(buffer, 0, buffer.length);
          if (read > 0) {
            try {
    // write short[] as little-endian bytes
              byte[] bytes = new byte[read * 2];
              for (int i = 0; i < read; i++) {
                bytes[i*2]     =
      (byte)(buffer[i] & 0xff);
                bytes[i*2 + 1] =
   (byte)((buffer[i] >> 8) & 0xff);
              }
              fos.write(bytes);
              recordedSamples += read;
            } catch (IOException e)
    { e.printStackTrace(); }
          }
        }
  try { fos.close(); } catch (Exception e) {}
      }
    }).start();

    println("Recording started  " + path1);
  } catch (Exception e) {
    println("Rec error: " + e);
  }
}

void stopRecording() {
  isRecording = false;
  if (recorder != null) {
    recorder.stop();
    recorder.release();
    recorder = null;
  }
  println("Stopped. Samples: " + recordedSamples);
}

// ---------- REVERSE (File1  File2) ----------
void reverseFile(File src, File dst) {
  println
("Reversing…(keepfilesreasonably short forlowRAM)");
  try {
    long len = src.length();
    if (len > 50L * 1024 * 1024) {
      println
 ("File > 50 MB  refuse for memory safety");
      return;
    }

    // Read all samples (for short/medium files). 
//For huge files do chunked reverse later.
    int numSamples = (int)(len / 2);
    short[] samples = new short[numSamples];

    DataInputStream dis =
 new DataInputStream(new FileInputStream(src));
    for (int i = 0; i < numSamples; i++) {
      samples[i] = dis.readShort();  
 // big-endian read  Android files are usually 
// LE, fix if needed
    }
    dis.close();

    // Simple reverse
    DataOutputStream dos = new DataOutputStream
  (new FileOutputStream(dst));
    for (int i = numSamples - 1; i >= 0; i--) {
      dos.writeShort(samples[i]);
    }
    dos.close();
    println("Reversed  " + path2);
  } catch (Exception e) {
    println("Reverse error: " + e);
    e.printStackTrace();
  }
}

// ---------- PLAY ----------
void playFile(


final


File f, boolean alreadyReversed) {
  if (!f.exists() || isPlaying) return;
  isPlaying = true;

  new Thread(new Runnable() {
    public void run() {
      try {
        int minBuf = AudioTrack.getMinBufferSize
(SAMPLE_RATE, CHANNEL_OUT, ENCODING);
        player = new AudioTrack
  (AudioManager.STREAM_MUSIC,
                              

  SAMPLE_RATE, CHANNEL_OUT, ENCODING,
                            

    minBuf, AudioTrack.MODE_STREAM);
        player.play();

    FileInputStream fis = new FileInputStream(f);
        byte[] byteBuf = new byte[minBuf];
        int n;
        while ((n = fis.read(byteBuf)) > 0 &&
         isPlaying) {
          player.write(byteBuf, 0, n);
        }
        fis.close();
        player.stop();
        player.release();
        player = null;
      } catch (Exception e) {
        println("Play error: " + e);
      }
      isPlaying = false;
    }
  }).start();
}

// Clean up
public void pause() {
  super.pause();
  isRecording = false;
  isPlaying = false;
  if (recorder != null)
 { recorder.release(); recorder = null; }
  if (player != null) 
  { player.release();   player = null; }
}

*/



/**
 * Android Sound Track Builder  Reverse  Timeline
 *  Record mic  File 1
 * - Reverse  File 2
 * - Play File 1 (forward) or File 2 (reversed)
 * - Draw simple pencillines / markersevery \10 s
 * Memory-friendly forsmall devices(target ≤ 50 MB)
 */

/*

import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.AudioManager;
import android.media.MediaRecorder;
import android.os.Environment;
import java.io.*;

int SAMPLE_RATE = 22050;       
   // lower = longer track for same MB
int CHANNEL_IN  = AudioFormat.CHANNEL_IN_MONO;
int CHANNEL_OUT = AudioFormat.CHANNEL_OUT_MONO;
int ENCODING    = AudioFormat.ENCODING_PCM_16BIT;
int BYTES_PER_SAMPLE = 2;

AudioRecord recorder;
AudioTrack  player;
boolean isRecording = false;
boolean isPlaying   = false;

File file1, file2;            
    // File 1 = original, File 2 = reversed
String path1, path2;

int bufferSize;
short[] buffer;

// Simple timeline drawing
float timelineY;
float pixelsPerSecond;
long  recordedSamples = 0;

void setup() {
  fullScreen();
  orientation(PORTRAIT);
  textAlign(CENTER, CENTER);
  textSize(36);

  bufferSize = AudioRecord.getMinBufferSize
  (SAMPLE_RATE, CHANNEL_IN, ENCODING);
  bufferSize = max(bufferSize, 4096);
  buffer = new short[bufferSize / 2];

 // Files in app external files dir 
//(safer on modern Android)
 File dir = getActivity().getExternalFilesDir
 (null);
  file1 = new File(dir, "track1.pcm");
  file2 = new File(dir, "track2_reversed.pcm");
  path1 = file1.getAbsolutePath();
  path2 = file2.getAbsolutePath();

  timelineY = height * 0.75;
  pixelsPerSecond = width / 60.0; 
  // rough scale – adjust later

  println("Ready. Max practical size 50 MB");
}

void draw() {
  background(20);

  // Buttons
  drawButton(width*0.1, height*0.08,
 width*0.35, height*0.12, 
isRecording ? "STOP REC" : "REC MIC",
 color(200, 50, 50));
  drawButton(width*0.55, height*0.08,
 width*0.35, height*0.12, "REVERSE  File2",
 color(80, 80, 200));
  drawButton(width*0.1, height*0.25,
 width*0.35, height*0.12, "PLAY File1", 
color(50, 180, 80));
  drawButton(width*0.55, height*0.25,
 width*0.35, height*0.12, "PLAY File2 (REV)",
 color(180, 120, 40));

  // Info
  fill(220);
  textSize(28);
  text
("Track size limit 50 MB", width/2, height*0.42);
  text
("File1: original   File2: reversed", 
width/2, height*0.48);
  if (file1.exists()) {
    float mb = file1.length() / (1024.0*1024.0);
    text(String.format
("File1: %.2f MB", mb), width/2, height*0.54);
  }

  // === Pencil / timeline line drawing ===
  stroke(100);
  strokeWeight(2);
  line(0, timelineY, width, timelineY);   
       // main baseline

 // Markers every \10seconds(visual seek helpers)
  stroke(180, 180, 60);
  strokeWeight(3);
  for (int sec = 0; sec <= 60; sec += 10) {
    float x = sec * pixelsPerSecond;
    if (x > width) break;
    line(x, timelineY - 25, x, timelineY + 25);
  // vertical tick
    fill(200);
    textSize(22);
    text(sec + "s", x, timelineY + 45);
  }

  // Simple “bits / amplitude” sketch
// line (live while recording)
  if (isRecording && buffer != null) {
    stroke(0, 255, 150);
    strokeWeight(1.5);
    noFill();
    beginShape();
  for 
(int i = 0; i < min(buffer.length, 200); i++) {
      float x = map(i, 0, 200, 0, width);
  float y = timelineY - map(abs(buffer[i]), 
   0, 8000, 0, 80);
      vertex(x, y);
    }
    endShape();
  }
}

void drawButton
(float x, float y, float w, float h,
   String label, int col) {
  fill(col);
  rect(x, y, w, h, 20);
  fill(255);
  textSize(32);
  text(label, x + w/2, y + h/2);
}

void mousePressed() {
  // REC / STOP
  if 
(mouseY > height*0.08 && mouseY < height*0.20) {
    if (mouseX < width*0.5) {
      if (!isRecording) startRecording();
      else stopRecording();
    } else {
      // REVERSE button
  if (file1.exists()) reverseFile(file1, file2);
    }
  }
  // PLAY buttons
  if 
(mouseY > height*0.25 && mouseY < height*0.37) {
 if (mouseX < width*0.5) playFile(file1, false);  
 // forward
    else playFile(file2, true);                       // already reversed
  }
}

// ---------- RECORD ----------
void startRecording() {
  try {
    recorder = new 
 AudioRecord(MediaRecorder.AudioSource.MIC,
                             
  SAMPLE_RATE, CHANNEL_IN, ENCODING, bufferSize);

    if (recorder.getState() !=
   AudioRecord.STATE_INITIALIZED) {
      println("AudioRecord init failed");
      return;
    }


final




    FileOutputStream fos =
  new FileOutputStream(file1);
    isRecording = true;
    recorder.startRecording();
    recordedSamples = 0;

    new Thread(new Runnable() {
      public void run() {
        while (isRecording) {
          int read = 
    recorder.read(buffer, 0, buffer.length);
          if (read > 0) {
            try {
    // write short[] as little-endian bytes
              byte[] bytes = new byte[read * 2];
              for (int i = 0; i < read; i++) {
                bytes[i*2]     =
      (byte)(buffer[i] & 0xff);
                bytes[i*2 + 1] =
   (byte)((buffer[i] >> 8) & 0xff);
              }
              fos.write(bytes);
              recordedSamples += read;
            } catch (IOException e)
    { e.printStackTrace(); }
          }
        }
  try { fos.close(); } catch (Exception e) {}
      }
    }).start();

    println("Recording started  " + path1);
  } catch (Exception e) {
    println("Rec error: " + e);
  }
}

void stopRecording() {
  isRecording = false;
  if (recorder != null) {
    recorder.stop();
    recorder.release();
    recorder = null;
  }
  println("Stopped. Samples: " + recordedSamples);
}

// ---------- REVERSE (File1  File2) ----------
void reverseFile(File src, File dst) {
  println
("Reversing…(keepfilesreasonably short forlowRAM)");
  try {
    long len = src.length();
    if (len > 50L * 1024 * 1024) {
      println
 ("File > 50 MB  refuse for memory safety");
      return;
    }

    // Read all samples (for short/medium files). 
//For huge files do chunked reverse later.
    int numSamples = (int)(len / 2);
    short[] samples = new short[numSamples];

    DataInputStream dis =
 new DataInputStream(new FileInputStream(src));
    for (int i = 0; i < numSamples; i++) {
      samples[i] = dis.readShort();  
 // big-endian read  Android files are usually 
// LE, fix if needed
    }
    dis.close();

    // Simple reverse
    DataOutputStream dos = new DataOutputStream
  (new FileOutputStream(dst));
    for (int i = numSamples - 1; i >= 0; i--) {
      dos.writeShort(samples[i]);
    }
    dos.close();
    println("Reversed  " + path2);
  } catch (Exception e) {
    println("Reverse error: " + e);
    e.printStackTrace();
  }
}

// ---------- PLAY ----------
void playFile(


final


File f, boolean alreadyReversed) {
  if (!f.exists() || isPlaying) return;
  isPlaying = true;

  new Thread(new Runnable() {
    public void run() {
      try {
        int minBuf = AudioTrack.getMinBufferSize
(SAMPLE_RATE, CHANNEL_OUT, ENCODING);
        player = new AudioTrack
  (AudioManager.STREAM_MUSIC,
                              

  SAMPLE_RATE, CHANNEL_OUT, ENCODING,
                            

    minBuf, AudioTrack.MODE_STREAM);
        player.play();

    FileInputStream fis = new FileInputStream(f);
        byte[] byteBuf = new byte[minBuf];
        int n;
        while ((n = fis.read(byteBuf)) > 0 &&
         isPlaying) {
          player.write(byteBuf, 0, n);
        }
        fis.close();
        player.stop();
        player.release();
        player = null;
      } catch (Exception e) {
        println("Play error: " + e);
      }
      isPlaying = false;
    }
  }).start();
}

// Clean up
public void pause() {
  super.pause();
  isRecording = false;
  isPlaying = false;
  if (recorder != null)
 { recorder.release(); recorder = null; }
  if (player != null) 
  { player.release();   player = null; }
}

*/













/**
 * Android Sound Track Builder  Reverse  Timeline
 *  Record mic  File 1
 * - Reverse  File 2
 * - Play File 1 (forward) or File 2 (reversed)
 * - Draw simple pencillines / markersevery \10 s
 * Memory-friendly forsmall devices(target ≤ 50 MB)
 */

/* 

import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.AudioManager;
import android.media.MediaRecorder;
import android.os.Environment;
import java.io.*;

int SAMPLE_RATE = 22050;       
   // lower = longer track for same MB
int CHANNEL_IN  = AudioFormat.CHANNEL_IN_MONO;
int CHANNEL_OUT = AudioFormat.CHANNEL_OUT_MONO;
int ENCODING    = AudioFormat.ENCODING_PCM_16BIT;
int BYTES_PER_SAMPLE = 2;

AudioRecord recorder;
AudioTrack  player;
boolean isRecording = false;
boolean isPlaying   = false;

File file1, file2;            
    // File 1 = original, File 2 = reversed
String path1, path2;

int bufferSize;
short[] buffer;

// Simple timeline drawing
float timelineY;
float pixelsPerSecond;
long  recordedSamples = 0;

void setup() {
  fullScreen();
  orientation(PORTRAIT);
  textAlign(CENTER, CENTER);
  textSize(36);

  bufferSize = AudioRecord.getMinBufferSize
  (SAMPLE_RATE, CHANNEL_IN, ENCODING);
  bufferSize = max(bufferSize, 4096);
  buffer = new short[bufferSize / 2];

 // Files in app external files dir 
//(safer on modern Android)
 File dir = getActivity().getExternalFilesDir
 (null);
  file1 = new File(dir, "track1.pcm");
  file2 = new File(dir, "track2_reversed.pcm");
  path1 = file1.getAbsolutePath();
  path2 = file2.getAbsolutePath();

  timelineY = height * 0.75;
  pixelsPerSecond = width / 60.0; 
  // rough scale – adjust later

  println("Ready. Max practical size 50 MB");
}

void draw() {
  background(20);

  // Buttons
  drawButton(width*0.1, height*0.08,
 width*0.35, height*0.12, 
isRecording ? "STOP REC" : "REC MIC",
 color(200, 50, 50));
  drawButton(width*0.55, height*0.08,
 width*0.35, height*0.12, "REVERSE  File2",
 color(80, 80, 200));
  drawButton(width*0.1, height*0.25,
 width*0.35, height*0.12, "PLAY File1", 
color(50, 180, 80));
  drawButton(width*0.55, height*0.25,
 width*0.35, height*0.12, "PLAY File2 (REV)",
 color(180, 120, 40));

  // Info
  fill(220);
  textSize(28);
  text
("Track size limit 50 MB", width/2, height*0.42);
  text
("File1: original   File2: reversed", 
width/2, height*0.48);
  if (file1.exists()) {
    float mb = file1.length() / (1024.0*1024.0);
    text(String.format
("File1: %.2f MB", mb), width/2, height*0.54);
  }

  // === Pencil / timeline line drawing ===
  stroke(100);
  strokeWeight(2);
  line(0, timelineY, width, timelineY);   
       // main baseline

 // Markers every \10seconds(visual seek helpers)
  stroke(180, 180, 60);
  strokeWeight(3);
  for (int sec = 0; sec <= 60; sec += 10) {
    float x = sec * pixelsPerSecond;
    if (x > width) break;
    line(x, timelineY - 25, x, timelineY + 25);
  // vertical tick
    fill(200);
    textSize(22);
    text(sec + "s", x, timelineY + 45);
  }

  // Simple “bits / amplitude” sketch
// line (live while recording)
  if (isRecording && buffer != null) {
    stroke(0, 255, 150);
    strokeWeight(1.5);
    noFill();
    beginShape();
  for 
(int i = 0; i < min(buffer.length, 200); i++) {
      float x = map(i, 0, 200, 0, width);
  float y = timelineY - map(abs(buffer[i]), 
   0, 8000, 0, 80);
      vertex(x, y);
    }
    endShape();
  }
}

void drawButton
(float x, float y, float w, float h,
   String label, int col) {
  fill(col);
  rect(x, y, w, h, 20);
  fill(255);
  textSize(32);
  text(label, x + w/2, y + h/2);
}

void mousePressed() {
  // REC / STOP
  if 
(mouseY > height*0.08 && mouseY < height*0.20) {
    if (mouseX < width*0.5) {
      if (!isRecording) startRecording();
      else stopRecording();
    } else {
      // REVERSE button
  if (file1.exists()) reverseFile(file1, file2);
    }
  }
  // PLAY buttons
  if 
(mouseY > height*0.25 && mouseY < height*0.37) {
 if (mouseX < width*0.5) playFile(file1, false);  
 // forward
    else playFile(file2, true);                       // already reversed
  }
}

// ---------- RECORD ----------
void startRecording() {
  try {
    recorder = new 
 AudioRecord(MediaRecorder.AudioSource.MIC,
                             
  SAMPLE_RATE, CHANNEL_IN, ENCODING, bufferSize);

    if (recorder.getState() !=
   AudioRecord.STATE_INITIALIZED) {
      println("AudioRecord init failed");
      return;
    }


final




    FileOutputStream fos =
  new FileOutputStream(file1);
    isRecording = true;
    recorder.startRecording();
    recordedSamples = 0;

    new Thread(new Runnable() {
      public void run() {
        while (isRecording) {
          int read = 
    recorder.read(buffer, 0, buffer.length);
          if (read > 0) {
            try {
    // write short[] as little-endian bytes
              byte[] bytes = new byte[read * 2];
              for (int i = 0; i < read; i++) {
                bytes[i*2]     =
      (byte)(buffer[i] & 0xff);
                bytes[i*2 + 1] =
   (byte)((buffer[i] >> 8) & 0xff);
              }
              fos.write(bytes);
              recordedSamples += read;
            } catch (IOException e)
    { e.printStackTrace(); }
          }
        }
  try { fos.close(); } catch (Exception e) {}
      }
    }).start();

    println("Recording started  " + path1);
  } catch (Exception e) {
    println("Rec error: " + e);
  }
}

void stopRecording() {
  isRecording = false;
  if (recorder != null) {
    recorder.stop();
    recorder.release();
    recorder = null;
  }
  println("Stopped. Samples: " + recordedSamples);
}

// ---------- REVERSE (File1  File2) ----------
void reverseFile(File src, File dst) {
  println
("Reversing…(keepfilesreasonably short forlowRAM)");
  try {
    long len = src.length();
    if (len > 50L * 1024 * 1024) {
      println
 ("File > 50 MB  refuse for memory safety");
      return;
    }

    // Read all samples (for short/medium files). 
//For huge files do chunked reverse later.
    int numSamples = (int)(len / 2);
    short[] samples = new short[numSamples];

    DataInputStream dis =
 new DataInputStream(new FileInputStream(src));
    for (int i = 0; i < numSamples; i++) {
      samples[i] = dis.readShort();  
 // big-endian read  Android files are usually 
// LE, fix if needed
    }
    dis.close();

    // Simple reverse
    DataOutputStream dos = new DataOutputStream
  (new FileOutputStream(dst));
    for (int i = numSamples - 1; i >= 0; i--) {
      dos.writeShort(samples[i]);
    }
    dos.close();
    println("Reversed  " + path2);
  } catch (Exception e) {
    println("Reverse error: " + e);
    e.printStackTrace();
  }
}

// ---------- PLAY ----------
void playFile(


final


File f, boolean alreadyReversed) {
  if (!f.exists() || isPlaying) return;
  isPlaying = true;

  new Thread(new Runnable() {
    public void run() {
      try {
        int minBuf = AudioTrack.getMinBufferSize
(SAMPLE_RATE, CHANNEL_OUT, ENCODING);
        player = new AudioTrack
  (AudioManager.STREAM_MUSIC,
                              

  SAMPLE_RATE, CHANNEL_OUT, ENCODING,
                            

    minBuf, AudioTrack.MODE_STREAM);
        player.play();

    FileInputStream fis = new FileInputStream(f);
        byte[] byteBuf = new byte[minBuf];
        int n;
        while ((n = fis.read(byteBuf)) > 0 &&
         isPlaying) {
          player.write(byteBuf, 0, n);
        }
        fis.close();
        player.stop();
        player.release();
        player = null;
      } catch (Exception e) {
        println("Play error: " + e);
      }
      isPlaying = false;
    }
  }).start();
}

// Clean up
public void pause() {
  super.pause();
  isRecording = false;
  isPlaying = false;
  if (recorder != null)
 { recorder.release(); recorder = null; }
  if (player != null) 
  { player.release();   player = null; }
}


*/











/**
 * Android Sound Track Builder  Reverse  Timeline
 *  Record mic  File 1
 * - Reverse  File 2
 * - Play File 1 (forward) or File 2 (reversed)
 * - Draw simple pencillines / markersevery \10 s
 * Memory-friendly forsmall devices(target ≤ 50 MB)
 */

/* 

import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.AudioManager;
import android.media.MediaRecorder;
import android.os.Environment;
import java.io.*;

int SAMPLE_RATE = 22050;       
   // lower = longer track for same MB
int CHANNEL_IN  = AudioFormat.CHANNEL_IN_MONO;
int CHANNEL_OUT = AudioFormat.CHANNEL_OUT_MONO;
int ENCODING    = AudioFormat.ENCODING_PCM_16BIT;
int BYTES_PER_SAMPLE = 2;

AudioRecord recorder;
AudioTrack  player;
boolean isRecording = false;
boolean isPlaying   = false;

File file1, file2;            
    // File 1 = original, File 2 = reversed
String path1, path2;

int bufferSize;
short[] buffer;

// Simple timeline drawing
float timelineY;
float pixelsPerSecond;
long  recordedSamples = 0;

void setup() {
  fullScreen();
  orientation(PORTRAIT);
  textAlign(CENTER, CENTER);
  textSize(36);

  bufferSize = AudioRecord.getMinBufferSize
  (SAMPLE_RATE, CHANNEL_IN, ENCODING);
  bufferSize = max(bufferSize, 4096);
  buffer = new short[bufferSize / 2];

 // Files in app external files dir 
//(safer on modern Android)
 File dir = getActivity().getExternalFilesDir
 (null);
  file1 = new File(dir, "track1.pcm");
  file2 = new File(dir, "track2_reversed.pcm");
  path1 = file1.getAbsolutePath();
  path2 = file2.getAbsolutePath();

  timelineY = height * 0.75;
  pixelsPerSecond = width / 60.0; 
  // rough scale – adjust later

  println("Ready. Max practical size 50 MB");
}

void draw() {
  background(20);

  // Buttons
  drawButton(width*0.1, height*0.08,
 width*0.35, height*0.12, 
isRecording ? "STOP REC" : "REC MIC",
 color(200, 50, 50));
  drawButton(width*0.55, height*0.08,
 width*0.35, height*0.12, "REVERSE  File2",
 color(80, 80, 200));
  drawButton(width*0.1, height*0.25,
 width*0.35, height*0.12, "PLAY File1", 
color(50, 180, 80));
  drawButton(width*0.55, height*0.25,
 width*0.35, height*0.12, "PLAY File2 (REV)",
 color(180, 120, 40));

  // Info
  fill(220);
  textSize(28);
  text
("Track size limit 50 MB", width/2, height*0.42);
  text
("File1: original   File2: reversed", 
width/2, height*0.48);
  if (file1.exists()) {
    float mb = file1.length() / (1024.0*1024.0);
    text(String.format
("File1: %.2f MB", mb), width/2, height*0.54);
  }

  // === Pencil / timeline line drawing ===
  stroke(100);
  strokeWeight(2);
  line(0, timelineY, width, timelineY);   
       // main baseline

 // Markers every \10seconds(visual seek helpers)
  stroke(180, 180, 60);
  strokeWeight(3);
  for (int sec = 0; sec <= 60; sec += 10) {
    float x = sec * pixelsPerSecond;
    if (x > width) break;
    line(x, timelineY - 25, x, timelineY + 25);
  // vertical tick
    fill(200);
    textSize(22);
    text(sec + "s", x, timelineY + 45);
  }

  // Simple “bits / amplitude” sketch
// line (live while recording)
  if (isRecording && buffer != null) {
    stroke(0, 255, 150);
    strokeWeight(1.5);
    noFill();
    beginShape();
  for 
(int i = 0; i < min(buffer.length, 200); i++) {
      float x = map(i, 0, 200, 0, width);
  float y = timelineY - map(abs(buffer[i]), 
   0, 8000, 0, 80);
      vertex(x, y);
    }
    endShape();
  }
}

void drawButton
(float x, float y, float w, float h,
   String label, int col) {
  fill(col);
  rect(x, y, w, h, 20);
  fill(255);
  textSize(32);
  text(label, x + w/2, y + h/2);
}

void mousePressed() {
  // REC / STOP
  if 
(mouseY > height*0.08 && mouseY < height*0.20) {
    if (mouseX < width*0.5) {
      if (!isRecording) startRecording();
      else stopRecording();
    } else {
      // REVERSE button
  if (file1.exists()) reverseFile(file1, file2);
    }
  }
  // PLAY buttons
  if 
(mouseY > height*0.25 && mouseY < height*0.37) {
 if (mouseX < width*0.5) playFile(file1, false);  
 // forward
    else playFile(file2, true);                       // already reversed
  }
}

// ---------- RECORD ----------
void startRecording() {
  try {
    recorder = new 
 AudioRecord(MediaRecorder.AudioSource.MIC,
                             
  SAMPLE_RATE, CHANNEL_IN, ENCODING, bufferSize);

    if (recorder.getState() !=
   AudioRecord.STATE_INITIALIZED) {
      println("AudioRecord init failed");
      return;
    }


final




    FileOutputStream fos =
  new FileOutputStream(file1);
    isRecording = true;
    recorder.startRecording();
    recordedSamples = 0;

    new Thread(new Runnable() {
      public void run() {
        while (isRecording) {
          int read = 
    recorder.read(buffer, 0, buffer.length);
          if (read > 0) {
            try {
    // write short[] as little-endian bytes
              byte[] bytes = new byte[read * 2];
              for (int i = 0; i < read; i++) {
                bytes[i*2]     =
      (byte)(buffer[i] & 0xff);
                bytes[i*2 + 1] =
   (byte)((buffer[i] >> 8) & 0xff);
              }
              fos.write(bytes);
              recordedSamples += read;
            } catch (IOException e)
    { e.printStackTrace(); }
          }
        }
  try { fos.close(); } catch (Exception e) {}
      }
    }).start();

    println("Recording started  " + path1);
  } catch (Exception e) {
    println("Rec error: " + e);
  }
}

void stopRecording() {
  isRecording = false;
  if (recorder != null) {
    recorder.stop();
    recorder.release();
    recorder = null;
  }
  println("Stopped. Samples: " + recordedSamples);
}

// ---------- REVERSE (File1  File2) ----------
void reverseFile(File src, File dst) {
  println
("Reversing…(keepfilesreasonably short forlowRAM)");
  try {
    long len = src.length();
    if (len > 50L * 1024 * 1024) {
      println
 ("File > 50 MB  refuse for memory safety");
      return;
    }

    // Read all samples (for short/medium files). 
//For huge files do chunked reverse later.
    int numSamples = (int)(len / 2);
    short[] samples = new short[numSamples];

    DataInputStream dis =
 new DataInputStream(new FileInputStream(src));
    for (int i = 0; i < numSamples; i++) {
      samples[i] = dis.readShort();  
 // big-endian read  Android files are usually 
// LE, fix if needed
    }
    dis.close();

    // Simple reverse
    DataOutputStream dos = new DataOutputStream
  (new FileOutputStream(dst));
    for (int i = numSamples - 1; i >= 0; i--) {
      dos.writeShort(samples[i]);
    }
    dos.close();
    println("Reversed  " + path2);
  } catch (Exception e) {
    println("Reverse error: " + e);
    e.printStackTrace();
  }
}

// ---------- PLAY ----------
void playFile(


final


File f, boolean alreadyReversed) {
  if (!f.exists() || isPlaying) return;
  isPlaying = true;

  new Thread(new Runnable() {
    public void run() {
      try {
        int minBuf = AudioTrack.getMinBufferSize
(SAMPLE_RATE, CHANNEL_OUT, ENCODING);
        player = new AudioTrack
  (AudioManager.STREAM_MUSIC,
                              

  SAMPLE_RATE, CHANNEL_OUT, ENCODING,
                            

    minBuf, AudioTrack.MODE_STREAM);
        player.play();

    FileInputStream fis = new FileInputStream(f);
        byte[] byteBuf = new byte[minBuf];
        int n;
        while ((n = fis.read(byteBuf)) > 0 &&
         isPlaying) {
          player.write(byteBuf, 0, n);
        }
        fis.close();
        player.stop();
        player.release();
        player = null;
      } catch (Exception e) {
        println("Play error: " + e);
      }
      isPlaying = false;
    }
  }).start();
}

// Clean up
public void pause() {
  super.pause();
  isRecording = false;
  isPlaying = false;
  if (recorder != null)
 { recorder.release(); recorder = null; }
  if (player != null) 
  { player.release();   player = null; }
}


*/











/**
 * Android Sound Track Builder  Reverse  Timeline
 *  Record mic  File 1
 * - Reverse  File 2
 * - Play File 1 (forward) or File 2 (reversed)
 * - Draw simple pencillines / markersevery \10 s
 * Memory-friendly forsmall devices(target ≤ 50 MB)
 */

/*

import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.AudioManager;
import android.media.MediaRecorder;
import android.os.Environment;
import java.io.*;

int SAMPLE_RATE = 22050;       
   // lower = longer track for same MB
int CHANNEL_IN  = AudioFormat.CHANNEL_IN_MONO;
int CHANNEL_OUT = AudioFormat.CHANNEL_OUT_MONO;
int ENCODING    = AudioFormat.ENCODING_PCM_16BIT;
int BYTES_PER_SAMPLE = 2;

AudioRecord recorder;
AudioTrack  player;
boolean isRecording = false;
boolean isPlaying   = false;

File file1, file2;            
    // File 1 = original, File 2 = reversed
String path1, path2;

int bufferSize;
short[] buffer;

// Simple timeline drawing
float timelineY;
float pixelsPerSecond;
long  recordedSamples = 0;

void setup() {
  fullScreen();
  orientation(PORTRAIT);
  textAlign(CENTER, CENTER);
  textSize(36);

  bufferSize = AudioRecord.getMinBufferSize
  (SAMPLE_RATE, CHANNEL_IN, ENCODING);
  bufferSize = max(bufferSize, 4096);
  buffer = new short[bufferSize / 2];

 // Files in app external files dir 
//(safer on modern Android)
 File dir = getActivity().getExternalFilesDir
 (null);
  file1 = new File(dir, "track1.pcm");
  file2 = new File(dir, "track2_reversed.pcm");
  path1 = file1.getAbsolutePath();
  path2 = file2.getAbsolutePath();

  timelineY = height * 0.75;
  pixelsPerSecond = width / 60.0; 
  // rough scale – adjust later

  println("Ready. Max practical size 50 MB");
}

void draw() {
  background(20);

  // Buttons
  drawButton(width*0.1, height*0.08,
 width*0.35, height*0.12, 
isRecording ? "STOP REC" : "REC MIC",
 color(200, 50, 50));
  drawButton(width*0.55, height*0.08,
 width*0.35, height*0.12, "REVERSE  File2",
 color(80, 80, 200));
  drawButton(width*0.1, height*0.25,
 width*0.35, height*0.12, "PLAY File1", 
color(50, 180, 80));
  drawButton(width*0.55, height*0.25,
 width*0.35, height*0.12, "PLAY File2 (REV)",
 color(180, 120, 40));

  // Info
  fill(220);
  textSize(28);
  text
("Track size limit 50 MB", width/2, height*0.42);
  text
("File1: original   File2: reversed", 
width/2, height*0.48);
  if (file1.exists()) {
    float mb = file1.length() / (1024.0*1024.0);
    text(String.format
("File1: %.2f MB", mb), width/2, height*0.54);
  }

  // === Pencil / timeline line drawing ===
  stroke(100);
  strokeWeight(2);
  line(0, timelineY, width, timelineY);   
       // main baseline

 // Markers every \10seconds(visual seek helpers)
  stroke(180, 180, 60);
  strokeWeight(3);
  for (int sec = 0; sec <= 60; sec += 10) {
    float x = sec * pixelsPerSecond;
    if (x > width) break;
    line(x, timelineY - 25, x, timelineY + 25);
  // vertical tick
    fill(200);
    textSize(22);
    text(sec + "s", x, timelineY + 45);
  }

  // Simple “bits / amplitude” sketch
// line (live while recording)
  if (isRecording && buffer != null) {
    stroke(0, 255, 150);
    strokeWeight(1.5);
    noFill();
    beginShape();
  for 
(int i = 0; i < min(buffer.length, 200); i++) {
      float x = map(i, 0, 200, 0, width);
  float y = timelineY - map(abs(buffer[i]), 
   0, 8000, 0, 80);
      vertex(x, y);
    }
    endShape();
  }
}

void drawButton
(float x, float y, float w, float h,
   String label, int col) {
  fill(col);
  rect(x, y, w, h, 20);
  fill(255);
  textSize(32);
  text(label, x + w/2, y + h/2);
}

void mousePressed() {
  // REC / STOP
  if 
(mouseY > height*0.08 && mouseY < height*0.20) {
    if (mouseX < width*0.5) {
      if (!isRecording) startRecording();
      else stopRecording();
    } else {
      // REVERSE button
  if (file1.exists()) reverseFile(file1, file2);
    }
  }
  // PLAY buttons
  if 
(mouseY > height*0.25 && mouseY < height*0.37) {
 if (mouseX < width*0.5) playFile(file1, false);  
 // forward
    else playFile(file2, true);                       // already reversed
  }
}

// ---------- RECORD ----------
void startRecording() {
  try {
    recorder = new 
 AudioRecord(MediaRecorder.AudioSource.MIC,
                             
  SAMPLE_RATE, CHANNEL_IN, ENCODING, bufferSize);

    if (recorder.getState() !=
   AudioRecord.STATE_INITIALIZED) {
      println("AudioRecord init failed");
      return;
    }


final




    FileOutputStream fos =
  new FileOutputStream(file1);
    isRecording = true;
    recorder.startRecording();
    recordedSamples = 0;

    new Thread(new Runnable() {
      public void run() {
        while (isRecording) {
          int read = 
    recorder.read(buffer, 0, buffer.length);
          if (read > 0) {
            try {
    // write short[] as little-endian bytes
              byte[] bytes = new byte[read * 2];
              for (int i = 0; i < read; i++) {
                bytes[i*2]     =
      (byte)(buffer[i] & 0xff);
                bytes[i*2 + 1] =
   (byte)((buffer[i] >> 8) & 0xff);
              }
              fos.write(bytes);
              recordedSamples += read;
            } catch (IOException e)
    { e.printStackTrace(); }
          }
        }
  try { fos.close(); } catch (Exception e) {}
      }
    }).start();

    println("Recording started  " + path1);
  } catch (Exception e) {
    println("Rec error: " + e);
  }
}

void stopRecording() {
  isRecording = false;
  if (recorder != null) {
    recorder.stop();
    recorder.release();
    recorder = null;
  }
  println("Stopped. Samples: " + recordedSamples);
}

// ---------- REVERSE (File1  File2) ----------
void reverseFile(File src, File dst) {
  println
("Reversing…(keepfilesreasonably short forlowRAM)");
  try {
    long len = src.length();
    if (len > 50L * 1024 * 1024) {
      println
 ("File > 50 MB  refuse for memory safety");
      return;
    }

    // Read all samples (for short/medium files). 
//For huge files do chunked reverse later.
    int numSamples = (int)(len / 2);
    short[] samples = new short[numSamples];

    DataInputStream dis =
 new DataInputStream(new FileInputStream(src));
    for (int i = 0; i < numSamples; i++) {
      samples[i] = dis.readShort();  
 // big-endian read  Android files are usually 
// LE, fix if needed
    }
    dis.close();

    // Simple reverse
    DataOutputStream dos = new DataOutputStream
  (new FileOutputStream(dst));
    for (int i = numSamples - 1; i >= 0; i--) {
      dos.writeShort(samples[i]);
    }
    dos.close();
    println("Reversed  " + path2);
  } catch (Exception e) {
    println("Reverse error: " + e);
    e.printStackTrace();
  }
}

// ---------- PLAY ----------
void playFile(


final


File f, boolean alreadyReversed) {
  if (!f.exists() || isPlaying) return;
  isPlaying = true;

  new Thread(new Runnable() {
    public void run() {
      try {
        int minBuf = AudioTrack.getMinBufferSize
(SAMPLE_RATE, CHANNEL_OUT, ENCODING);
        player = new AudioTrack
  (AudioManager.STREAM_MUSIC,
                              

  SAMPLE_RATE, CHANNEL_OUT, ENCODING,
                            

    minBuf, AudioTrack.MODE_STREAM);
        player.play();

    FileInputStream fis = new FileInputStream(f);
        byte[] byteBuf = new byte[minBuf];
        int n;
        while ((n = fis.read(byteBuf)) > 0 &&
         isPlaying) {
          player.write(byteBuf, 0, n);
        }
        fis.close();
        player.stop();
        player.release();
        player = null;
      } catch (Exception e) {
        println("Play error: " + e);
      }
      isPlaying = false;
    }
  }).start();
}

// Clean up
public void pause() {
  super.pause();
  isRecording = false;
  isPlaying = false;
  if (recorder != null)
 { recorder.release(); recorder = null; }
  if (player != null) 
  { player.release();   player = null; }
}

*/













/**
 * Android Sound Track Builder  Reverse  Timeline
 *  Record mic  File 1
 * - Reverse  File 2
 * - Play File 1 (forward) or File 2 (reversed)
 * - Draw simple pencillines / markersevery \10 s
 * Memory-friendly forsmall devices(target ≤ 50 MB)
 */

/*

import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.AudioManager;
import android.media.MediaRecorder;
import android.os.Environment;
import java.io.*;

int SAMPLE_RATE = 22050;       
   // lower = longer track for same MB
int CHANNEL_IN  = AudioFormat.CHANNEL_IN_MONO;
int CHANNEL_OUT = AudioFormat.CHANNEL_OUT_MONO;
int ENCODING    = AudioFormat.ENCODING_PCM_16BIT;
int BYTES_PER_SAMPLE = 2;

AudioRecord recorder;
AudioTrack  player;
boolean isRecording = false;
boolean isPlaying   = false;

File file1, file2;            
    // File 1 = original, File 2 = reversed
String path1, path2;

int bufferSize;
short[] buffer;

// Simple timeline drawing
float timelineY;
float pixelsPerSecond;
long  recordedSamples = 0;

void setup() {
  fullScreen();
  orientation(PORTRAIT);
  textAlign(CENTER, CENTER);
  textSize(36);

  bufferSize = AudioRecord.getMinBufferSize
  (SAMPLE_RATE, CHANNEL_IN, ENCODING);
  bufferSize = max(bufferSize, 4096);
  buffer = new short[bufferSize / 2];

 // Files in app external files dir 
//(safer on modern Android)
 File dir = getActivity().getExternalFilesDir
 (null);
  file1 = new File(dir, "track1.pcm");
  file2 = new File(dir, "track2_reversed.pcm");
  path1 = file1.getAbsolutePath();
  path2 = file2.getAbsolutePath();

  timelineY = height * 0.75;
  pixelsPerSecond = width / 60.0; 
  // rough scale – adjust later

  println("Ready. Max practical size 50 MB");
}

void draw() {
  background(20);

  // Buttons
  drawButton(width*0.1, height*0.08,
 width*0.35, height*0.12, 
isRecording ? "STOP REC" : "REC MIC",
 color(200, 50, 50));
  drawButton(width*0.55, height*0.08,
 width*0.35, height*0.12, "REVERSE  File2",
 color(80, 80, 200));
  drawButton(width*0.1, height*0.25,
 width*0.35, height*0.12, "PLAY File1", 
color(50, 180, 80));
  drawButton(width*0.55, height*0.25,
 width*0.35, height*0.12, "PLAY File2 (REV)",
 color(180, 120, 40));

  // Info
  fill(220);
  textSize(28);
  text
("Track size limit 50 MB", width/2, height*0.42);
  text
("File1: original   File2: reversed", 
width/2, height*0.48);
  if (file1.exists()) {
    float mb = file1.length() / (1024.0*1024.0);
    text(String.format
("File1: %.2f MB", mb), width/2, height*0.54);
  }

  // === Pencil / timeline line drawing ===
  stroke(100);
  strokeWeight(2);
  line(0, timelineY, width, timelineY);   
       // main baseline

 // Markers every \10seconds(visual seek helpers)
  stroke(180, 180, 60);
  strokeWeight(3);
  for (int sec = 0; sec <= 60; sec += 10) {
    float x = sec * pixelsPerSecond;
    if (x > width) break;
    line(x, timelineY - 25, x, timelineY + 25);
  // vertical tick
    fill(200);
    textSize(22);
    text(sec + "s", x, timelineY + 45);
  }

  // Simple “bits / amplitude” sketch
// line (live while recording)
  if (isRecording && buffer != null) {
    stroke(0, 255, 150);
    strokeWeight(1.5);
    noFill();
    beginShape();
  for 
(int i = 0; i < min(buffer.length, 200); i++) {
      float x = map(i, 0, 200, 0, width);
  float y = timelineY - map(abs(buffer[i]), 
   0, 8000, 0, 80);
      vertex(x, y);
    }
    endShape();
  }
}

void drawButton
(float x, float y, float w, float h,
   String label, int col) {
  fill(col);
  rect(x, y, w, h, 20);
  fill(255);
  textSize(32);
  text(label, x + w/2, y + h/2);
}

void mousePressed() {
  // REC / STOP
  if 
(mouseY > height*0.08 && mouseY < height*0.20) {
    if (mouseX < width*0.5) {
      if (!isRecording) startRecording();
      else stopRecording();
    } else {
      // REVERSE button
  if (file1.exists()) reverseFile(file1, file2);
    }
  }
  // PLAY buttons
  if 
(mouseY > height*0.25 && mouseY < height*0.37) {
 if (mouseX < width*0.5) playFile(file1, false);  
 // forward
    else playFile(file2, true);                       // already reversed
  }
}

// ---------- RECORD ----------
void startRecording() {
  try {
    recorder = new 
 AudioRecord(MediaRecorder.AudioSource.MIC,
                             
  SAMPLE_RATE, CHANNEL_IN, ENCODING, bufferSize);

    if (recorder.getState() !=
   AudioRecord.STATE_INITIALIZED) {
      println("AudioRecord init failed");
      return;
    }


final




    FileOutputStream fos =
  new FileOutputStream(file1);
    isRecording = true;
    recorder.startRecording();
    recordedSamples = 0;

    new Thread(new Runnable() {
      public void run() {
        while (isRecording) {
          int read = 
    recorder.read(buffer, 0, buffer.length);
          if (read > 0) {
            try {
    // write short[] as little-endian bytes
              byte[] bytes = new byte[read * 2];
              for (int i = 0; i < read; i++) {
                bytes[i*2]     =
      (byte)(buffer[i] & 0xff);
                bytes[i*2 + 1] =
   (byte)((buffer[i] >> 8) & 0xff);
              }
              fos.write(bytes);
              recordedSamples += read;
            } catch (IOException e)
    { e.printStackTrace(); }
          }
        }
  try { fos.close(); } catch (Exception e) {}
      }
    }).start();

    println("Recording started  " + path1);
  } catch (Exception e) {
    println("Rec error: " + e);
  }
}

void stopRecording() {
  isRecording = false;
  if (recorder != null) {
    recorder.stop();
    recorder.release();
    recorder = null;
  }
  println("Stopped. Samples: " + recordedSamples);
}

// ---------- REVERSE (File1  File2) ----------
void reverseFile(File src, File dst) {
  println
("Reversing…(keepfilesreasonably short forlowRAM)");
  try {
    long len = src.length();
    if (len > 50L * 1024 * 1024) {
      println
 ("File > 50 MB  refuse for memory safety");
      return;
    }

    // Read all samples (for short/medium files). 
//For huge files do chunked reverse later.
    int numSamples = (int)(len / 2);
    short[] samples = new short[numSamples];

    DataInputStream dis =
 new DataInputStream(new FileInputStream(src));
    for (int i = 0; i < numSamples; i++) {
      samples[i] = dis.readShort();  
 // big-endian read  Android files are usually 
// LE, fix if needed
    }
    dis.close();

    // Simple reverse
    DataOutputStream dos = new DataOutputStream
  (new FileOutputStream(dst));
    for (int i = numSamples - 1; i >= 0; i--) {
      dos.writeShort(samples[i]);
    }
    dos.close();
    println("Reversed  " + path2);
  } catch (Exception e) {
    println("Reverse error: " + e);
    e.printStackTrace();
  }
}

// ---------- PLAY ----------
void playFile(


final


File f, boolean alreadyReversed) {
  if (!f.exists() || isPlaying) return;
  isPlaying = true;

  new Thread(new Runnable() {
    public void run() {
      try {
        int minBuf = AudioTrack.getMinBufferSize
(SAMPLE_RATE, CHANNEL_OUT, ENCODING);
        player = new AudioTrack
  (AudioManager.STREAM_MUSIC,
                              

  SAMPLE_RATE, CHANNEL_OUT, ENCODING,
                            

    minBuf, AudioTrack.MODE_STREAM);
        player.play();

    FileInputStream fis = new FileInputStream(f);
        byte[] byteBuf = new byte[minBuf];
        int n;
        while ((n = fis.read(byteBuf)) > 0 &&
         isPlaying) {
          player.write(byteBuf, 0, n);
        }
        fis.close();
        player.stop();
        player.release();
        player = null;
      } catch (Exception e) {
        println("Play error: " + e);
      }
      isPlaying = false;
    }
  }).start();
}

// Clean up
public void pause() {
  super.pause();
  isRecording = false;
  isPlaying = false;
  if (recorder != null)
 { recorder.release(); recorder = null; }
  if (player != null) 
  { player.release();   player = null; }
}


*/











/**
 * Android Sound Track Builder  Reverse  Timeline
 *  Record mic  File 1
 * - Reverse  File 2
 * - Play File 1 (forward) or File 2 (reversed)
 * - Draw simple pencillines / markersevery \10 s
 * Memory-friendly forsmall devices(target ≤ 50 MB)
 */

/*

import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.AudioManager;
import android.media.MediaRecorder;
import android.os.Environment;
import java.io.*;

int SAMPLE_RATE = 22050;       
   // lower = longer track for same MB
int CHANNEL_IN  = AudioFormat.CHANNEL_IN_MONO;
int CHANNEL_OUT = AudioFormat.CHANNEL_OUT_MONO;
int ENCODING    = AudioFormat.ENCODING_PCM_16BIT;
int BYTES_PER_SAMPLE = 2;

AudioRecord recorder;
AudioTrack  player;
boolean isRecording = false;
boolean isPlaying   = false;

File file1, file2;            
    // File 1 = original, File 2 = reversed
String path1, path2;

int bufferSize;
short[] buffer;

// Simple timeline drawing
float timelineY;
float pixelsPerSecond;
long  recordedSamples = 0;

void setup() {
  fullScreen();
  orientation(PORTRAIT);
  textAlign(CENTER, CENTER);
  textSize(36);

  bufferSize = AudioRecord.getMinBufferSize
  (SAMPLE_RATE, CHANNEL_IN, ENCODING);
  bufferSize = max(bufferSize, 4096);
  buffer = new short[bufferSize / 2];

 // Files in app external files dir 
//(safer on modern Android)
 File dir = getActivity().getExternalFilesDir
 (null);
  file1 = new File(dir, "track1.pcm");
  file2 = new File(dir, "track2_reversed.pcm");
  path1 = file1.getAbsolutePath();
  path2 = file2.getAbsolutePath();

  timelineY = height * 0.75;
  pixelsPerSecond = width / 60.0; 
  // rough scale – adjust later

  println("Ready. Max practical size 50 MB");
}

void draw() {
  background(20);

  // Buttons
  drawButton(width*0.1, height*0.08,
 width*0.35, height*0.12, 
isRecording ? "STOP REC" : "REC MIC",
 color(200, 50, 50));
  drawButton(width*0.55, height*0.08,
 width*0.35, height*0.12, "REVERSE  File2",
 color(80, 80, 200));
  drawButton(width*0.1, height*0.25,
 width*0.35, height*0.12, "PLAY File1", 
color(50, 180, 80));
  drawButton(width*0.55, height*0.25,
 width*0.35, height*0.12, "PLAY File2 (REV)",
 color(180, 120, 40));

  // Info
  fill(220);
  textSize(28);
  text
("Track size limit 50 MB", width/2, height*0.42);
  text
("File1: original   File2: reversed", 
width/2, height*0.48);
  if (file1.exists()) {
    float mb = file1.length() / (1024.0*1024.0);
    text(String.format
("File1: %.2f MB", mb), width/2, height*0.54);
  }

  // === Pencil / timeline line drawing ===
  stroke(100);
  strokeWeight(2);
  line(0, timelineY, width, timelineY);   
       // main baseline

 // Markers every \10seconds(visual seek helpers)
  stroke(180, 180, 60);
  strokeWeight(3);
  for (int sec = 0; sec <= 60; sec += 10) {
    float x = sec * pixelsPerSecond;
    if (x > width) break;
    line(x, timelineY - 25, x, timelineY + 25);
  // vertical tick
    fill(200);
    textSize(22);
    text(sec + "s", x, timelineY + 45);
  }

  // Simple “bits / amplitude” sketch
// line (live while recording)
  if (isRecording && buffer != null) {
    stroke(0, 255, 150);
    strokeWeight(1.5);
    noFill();
    beginShape();
  for 
(int i = 0; i < min(buffer.length, 200); i++) {
      float x = map(i, 0, 200, 0, width);
  float y = timelineY - map(abs(buffer[i]), 
   0, 8000, 0, 80);
      vertex(x, y);
    }
    endShape();
  }
}

void drawButton
(float x, float y, float w, float h,
   String label, int col) {
  fill(col);
  rect(x, y, w, h, 20);
  fill(255);
  textSize(32);
  text(label, x + w/2, y + h/2);
}

void mousePressed() {
  // REC / STOP
  if 
(mouseY > height*0.08 && mouseY < height*0.20) {
    if (mouseX < width*0.5) {
      if (!isRecording) startRecording();
      else stopRecording();
    } else {
      // REVERSE button
  if (file1.exists()) reverseFile(file1, file2);
    }
  }
  // PLAY buttons
  if 
(mouseY > height*0.25 && mouseY < height*0.37) {
 if (mouseX < width*0.5) playFile(file1, false);  
 // forward
    else playFile(file2, true);                       // already reversed
  }
}

// ---------- RECORD ----------
void startRecording() {
  try {
    recorder = new 
 AudioRecord(MediaRecorder.AudioSource.MIC,
                             
  SAMPLE_RATE, CHANNEL_IN, ENCODING, bufferSize);

    if (recorder.getState() !=
   AudioRecord.STATE_INITIALIZED) {
      println("AudioRecord init failed");
      return;
    }


final




    FileOutputStream fos =
  new FileOutputStream(file1);
    isRecording = true;
    recorder.startRecording();
    recordedSamples = 0;

    new Thread(new Runnable() {
      public void run() {
        while (isRecording) {
          int read = 
    recorder.read(buffer, 0, buffer.length);
          if (read > 0) {
            try {
    // write short[] as little-endian bytes
              byte[] bytes = new byte[read * 2];
              for (int i = 0; i < read; i++) {
                bytes[i*2]     =
      (byte)(buffer[i] & 0xff);
                bytes[i*2 + 1] =
   (byte)((buffer[i] >> 8) & 0xff);
              }
              fos.write(bytes);
              recordedSamples += read;
            } catch (IOException e)
    { e.printStackTrace(); }
          }
        }
  try { fos.close(); } catch (Exception e) {}
      }
    }).start();

    println("Recording started  " + path1);
  } catch (Exception e) {
    println("Rec error: " + e);
  }
}

void stopRecording() {
  isRecording = false;
  if (recorder != null) {
    recorder.stop();
    recorder.release();
    recorder = null;
  }
  println("Stopped. Samples: " + recordedSamples);
}

// ---------- REVERSE (File1  File2) ----------
void reverseFile(File src, File dst) {
  println
("Reversing…(keepfilesreasonably short forlowRAM)");
  try {
    long len = src.length();
    if (len > 50L * 1024 * 1024) {
      println
 ("File > 50 MB  refuse for memory safety");
      return;
    }

    // Read all samples (for short/medium files). 
//For huge files do chunked reverse later.
    int numSamples = (int)(len / 2);
    short[] samples = new short[numSamples];

    DataInputStream dis =
 new DataInputStream(new FileInputStream(src));
    for (int i = 0; i < numSamples; i++) {
      samples[i] = dis.readShort();  
 // big-endian read  Android files are usually 
// LE, fix if needed
    }
    dis.close();

    // Simple reverse
    DataOutputStream dos = new DataOutputStream
  (new FileOutputStream(dst));
    for (int i = numSamples - 1; i >= 0; i--) {
      dos.writeShort(samples[i]);
    }
    dos.close();
    println("Reversed  " + path2);
  } catch (Exception e) {
    println("Reverse error: " + e);
    e.printStackTrace();
  }
}

// ---------- PLAY ----------
void playFile(


final


File f, boolean alreadyReversed) {
  if (!f.exists() || isPlaying) return;
  isPlaying = true;

  new Thread(new Runnable() {
    public void run() {
      try {
        int minBuf = AudioTrack.getMinBufferSize
(SAMPLE_RATE, CHANNEL_OUT, ENCODING);
        player = new AudioTrack
  (AudioManager.STREAM_MUSIC,
                              

  SAMPLE_RATE, CHANNEL_OUT, ENCODING,
                            

    minBuf, AudioTrack.MODE_STREAM);
        player.play();

    FileInputStream fis = new FileInputStream(f);
        byte[] byteBuf = new byte[minBuf];
        int n;
        while ((n = fis.read(byteBuf)) > 0 &&
         isPlaying) {
          player.write(byteBuf, 0, n);
        }
        fis.close();
        player.stop();
        player.release();
        player = null;
      } catch (Exception e) {
        println("Play error: " + e);
      }
      isPlaying = false;
    }
  }).start();
}

// Clean up
public void pause() {
  super.pause();
  isRecording = false;
  isPlaying = false;
  if (recorder != null)
 { recorder.release(); recorder = null; }
  if (player != null) 
  { player.release();   player = null; }
}


*/


























































































































/*


*/




















































