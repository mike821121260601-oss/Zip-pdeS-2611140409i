



// APDE / Processing
// 10,000 3D random lines = human face

int N = 10000;

float[] x1 = new float[N];
float[] y1 = new float[N];
float[] z1 = new float[N];

float[] x2 = new float[N];
float[] y2 = new float[N];
float[] z2 = new float[N];

float rotY = 0;
float rotX = 0;

void settings() {
  size(displayWidth, displayHeight, P3D);
}

void setup() {



///  orientation(LANDSCAPE);




  stroke(255);
  strokeWeight(1);
  generateFace();
}

void draw() {
  background(0);

  translate(width/2, height/2, 0);

  rotateX(rotX);
  rotateY(rotY);

  // Slowly rotate the face
  rotY += 0.003;

  stroke(255, 180);
  strokeWeight(1);

  for (int i = 0; i < N; i++) {
    line(
      x1[i], y1[i], z1[i],
      x2[i], y2[i], z2[i]
    );
  }
}


// ------------------------------------------------
// MAKE 10,000 RANDOM 3D LINES
// ------------------------------------------------

void generateFace() {

  for (int i = 0; i < N; i++) {

    int part = int(random(0, 8));

    float a, b;

    if (part == 0) {
      // FOREHEAD
      a = random(-150, 150);
      b = random(-180, -70);

      x1[i] = a;
      y1[i] = b;
      z1[i] = faceZ(a, b);

    } else if (part == 1) {
      // LEFT CHEEK
      x1[i] = random(-190, -50);
      y1[i] = random(-70, 100);
      z1[i] = faceZ(x1[i], y1[i]);

    } else if (part == 2) {
      // RIGHT CHEEK
      x1[i] = random(50, 190);
      y1[i] = random(-70, 100);
      z1[i] = faceZ(x1[i], y1[i]);

    } else if (part == 3) {
      // CHIN
      x1[i] = random(-110, 110);
      y1[i] = random(80, 190);
      z1[i] = faceZ(x1[i], y1[i]);

    } else if (part == 4) {
      // NOSE
      x1[i] = random(-35, 35);
      y1[i] = random(-40, 70);
      z1[i] = faceZ(x1[i], y1[i]) + random(20, 70);

    } else if (part == 5) {
      // LEFT EYE
      x1[i] = random(-120, -25);
      y1[i] = random(-55, 5);
      z1[i] = faceZ(x1[i], y1[i]) + 10;

    } else if (part == 6) {
      // RIGHT EYE
      x1[i] = random(25, 120);
      y1[i] = random(-55, 5);
      z1[i] = faceZ(x1[i], y1[i]) + 10;

    } else {
      // MOUTH
      x1[i] = random(-90, 90);
      y1[i] = random(55, 110);
      z1[i] = faceZ(x1[i], y1[i]) + 20;
    }


    // Second point is close to first point.
    // This creates a wire-like random face.

    x2[i] = x1[i] + random(-25, 25);
    y2[i] = y1[i] + random(-25, 25);
    z2[i] = z1[i] + random(-25, 25);

  }
}


// ------------------------------------------------
// 3D FACE DEPTH
// ------------------------------------------------

float faceZ(float x, float y) {

  float rx = 190;
  float ry = 230;

  float xx = x / rx;
  float yy = y / ry;

  float q = 1.0 - xx*xx - yy*yy;

  if (q < 0) q = 0;

  float z = sqrt(q) * 120;

  // Nose protrusion
  float nose =
    90 *
    exp(
      -(x*x)/(2*35*35)
      -(sq(y-10))/(2*65*65)
    );

  // Cheek shape
  float cheek =
    25 *
    exp(
      -sq(abs(x)-100)/(2*60*60)
      -sq(y-30)/(2*80*80)
    );

  return z + nose + cheek;
}


// ------------------------------------------------
// TOUCH = NEW RANDOM FACE
// ------------------------------------------------

void mousePressed() {
  generateFace();
}


// ------------------------------------------------
// DRAG = ROTATE
// ------------------------------------------------

void mouseDragged() {

  rotY += (mouseX - pmouseX) * 0.01;
  rotX += (mouseY - pmouseY) * 0.01;
}

























