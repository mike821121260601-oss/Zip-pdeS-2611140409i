


///GPT///UCI FORMAT/////

// ============================================================
// APDE SMALL UCI CHESS ENGINE
// Processing / Java
// ============================================================

String[] board = new String[64];

void setup() {
  println("Small APDE UCI Chess Engine");
  initBoard();

  // Example:
  uci("uci");
  uci("isready");
  uci("position startpos");
  uci("go depth 3");
}

void draw() {
}


// ============================================================
// UCI COMMAND
// ============================================================

void uci(String cmd) {

  println("> " + cmd);

  String[] p = splitTokens(cmd, " ");

  if (p.length == 0) return;

  if (p[0].equals("uci")) {
    println("id name APDE-SmallChess");
    println("id author APDE");
    println("uciok");
  }

  else if (p[0].equals("isready")) {
    println("readyok");
  }

  else if (p[0].equals("ucinewgame")) {
    initBoard();
  }

  else if (p[0].equals("position")) {
    readPosition(p);
  }

  else if (p[0].equals("go")) {

    int depth = 3;

    for (int i = 1; i < p.length - 1; i++) {
      if (p[i].equals("depth")) {
        depth = int(p[i + 1]);
      }
    }

    String move = searchBestMove(depth);

    println("bestmove " + move);
  }
}


// ============================================================
// START POSITION
// ============================================================

void initBoard() {

  for (int i = 0; i < 64; i++)
    board[i] = ".";

  String back = "rnbqkbnr";

  for (int x = 0; x < 8; x++) {

    board[x]     = "" + back.charAt(x);
    board[8 + x] = "p";

    board[48 + x] = "P";
    board[56 + x] = "" + Character.toUpperCase
  (back.charAt(x));
  }
}


// ============================================================
// POSITION COMMAND
// ============================================================

void readPosition(String[] p) {

  initBoard();

  int movesIndex = -1;

  for (int i = 1; i < p.length; i++) {

    if (p[i].equals("startpos")) {
      initBoard();
    }

    if (p[i].equals("moves")) {
      movesIndex = i + 1;
      break;
    }
  }

  if (movesIndex >= 0) {

    for (int i = movesIndex; i < p.length; i++) {

      makeUciMove(p[i]);
    }
  }
}


// ============================================================
// MAKE UCI MOVE
// ============================================================

void makeUciMove(String s) {

  if (s.length() < 4) return;

  int from = square(s.substring(0, 2));
  int to   = square(s.substring(2, 4));

  if (from < 0 || to < 0) return;

  String piece = board[from];

  board[to] = piece;
  board[from] = ".";

  // Promotion
  if (s.length() >= 5) {

    char promo = s.charAt(4);

    if (piece.equals("P"))
      board[to] = "" + Character.toUpperCase(promo);

    if (piece.equals("p"))
      board[to] = "" + Character.toLowerCase(promo);
  }
}


// ============================================================
// SEARCH
// ============================================================

String searchBestMove(int depth) {

  String[] moves = generateMoves();

  if (moves.length == 0)
    return "0000";

  int bestScore = -999999;
  String best = moves[0];

  for (int i = 0; i < moves.length; i++) {

    String oldFrom = board[square(moves[i].substring(0,2))];
    String oldTo   = board[square(moves[i].substring(2,4))];

    makeUciMove(moves[i]);

    int score = -negamax(depth - 1, -999999, 999999);

    int from = square(moves[i].substring(0,2));
    int to   = square(moves[i].substring(2,4));

    board[from] = oldFrom;
    board[to] = oldTo;

    if (score > bestScore) {

      bestScore = score;
      best = moves[i];
    }
  }

  return best;
}


// ============================================================
// NEGAMAX
// ============================================================

int negamax(int depth, int alpha, int beta) {

  if (depth <= 0)
    return evaluate();

  String[] moves = generateMoves();

  if (moves.length == 0)
    return evaluate();

  int best = -999999;

  for (int i = 0; i < moves.length; i++) {

    int from = square(moves[i].substring(0,2));
    int to   = square(moves[i].substring(2,4));

    String oldFrom = board[from];
    String oldTo   = board[to];

    makeUciMove(moves[i]);

    int score =
      -negamax(depth - 1, -beta, -alpha);

    board[from] = oldFrom;
    board[to] = oldTo;

    if (score > best)
      best = score;

    if (score > alpha)
      alpha = score;

    if (alpha >= beta)
      break;
  }

  return best;
}


// ============================================================
// VERY SIMPLE MOVE GENERATOR
// ============================================================

String[] generateMoves() {

  ArrayList<String> list =
    new ArrayList<String>();

  for (int from = 0; from < 64; from++) {

    String p = board[from];

    if (p.equals("."))
      continue;

    // White pieces only for this small example
    if (!Character.isUpperCase(p.charAt(0)))
      continue;

    int x = from % 8;
    int y = from / 8;

    char pc = p.charAt(0);

    if (pc == 'P') {

      if (y > 0) {

        int to = from - 8;

        if (board[to].equals(".")) {
          list.add(moveText(from, to));
        }

        if (x > 0 &&
            !board[from - 9].equals(".") &&
            Character.isLowerCase(
              board[from - 9].charAt(0))) {

          list.add(moveText(from, from - 9));
        }

        if (x < 7 &&
            !board[from - 7].equals(".") &&
            Character.isLowerCase(
              board[from - 7].charAt(0))) {

          list.add(moveText(from, from - 7));
        }
      }
    }

    else if (pc == 'N') {

      knightMoves(list, from);
    }

    else if (pc == 'B') {

      slideMoves(list, from, 1, 1);
      slideMoves(list, from, -1, 1);
      slideMoves(list, from, 1, -1);
      slideMoves(list, from, -1, -1);
    }

    else if (pc == 'R') {

      slideMoves(list, from, 1, 0);
      slideMoves(list, from, -1, 0);
      slideMoves(list, from, 0, 1);
      slideMoves(list, from, 0, -1);
    }

    else if (pc == 'Q') {

      slideMoves(list, from, 1, 1);
      slideMoves(list, from, -1, 1);
      slideMoves(list, from, 1, -1);
      slideMoves(list, from, -1, -1);

      slideMoves(list, from, 1, 0);
      slideMoves(list, from, -1, 0);
      slideMoves(list, from, 0, 1);
      slideMoves(list, from, 0, -1);
    }

    else if (pc == 'K') {

      for (int dx = -1; dx <= 1; dx++) {
        for (int dy = -1; dy <= 1; dy++) {

          if (dx == 0 && dy == 0)
            continue;

          addMove(list, from, x + dx, y + dy);
        }
      }
    }
  }

  return list.toArray(new String[0]);
}


// ============================================================
// KNIGHT
// ============================================================

void knightMoves(ArrayList<String> list, int from) {

  int x = from % 8;
  int y = from / 8;

  int[] dx = {1,2,2,1,-1,-2,-2,-1};
  int[] dy = {-2,-1,1,2,2,1,-1,-2};

  for (int i = 0; i < 8; i++)
    addMove(list, from, x + dx[i], y + dy[i]);
}


// ============================================================
// SLIDING PIECES
// ============================================================

void slideMoves(
  ArrayList<String> list,
  int from,
  int dx,
  int dy) {

  int x = from % 8;
  int y = from / 8;

  while (true) {

    x += dx;
    y += dy;

    if (x < 0 || x > 7 || y < 0 || y > 7)
      break;

    int to = y * 8 + x;

    if (board[to].equals(".")) {

      list.add(moveText(from, to));
    }
    else {

      if (Character.isLowerCase(
          board[to].charAt(0))) {

        list.add(moveText(from, to));
      }

      break;
    }
  }
}


// ============================================================
// ADD MOVE
// ============================================================

void addMove(
  ArrayList<String> list,
  int from,
  int x,
  int y) {

  if (x < 0 || x > 7 || y < 0 || y > 7)
    return;

  int to = y * 8 + x;

  if (board[to].equals(".") ||
      Character.isLowerCase(
        board[to].charAt(0))) {

    list.add(moveText(from, to));
  }
}


// ============================================================
// MOVE -> e2e4
// ============================================================

String moveText(int from, int to) {

  return squareText(from) +
         squareText(to);
}


// ============================================================
// SQUARE
// ============================================================

int square(String s) {

  if (s.length() != 2)
    return -1;

  int x = s.charAt(0) - 'a';
  int y = s.charAt(1) - '1';

  if (x < 0 || x > 7 ||
      y < 0 || y > 7)
    return -1;

  // board[0] = a1
  return y * 8 + x;
}


String squareText(int n) {

  int x = n % 8;
  int y = n / 8;

  return "" +
    (char)('a' + x) +
    (char)('1' + y);
}


// ============================================================
// EVALUATION
// ============================================================

int evaluate() {

  int score = 0;

  for (int i = 0; i < 64; i++) {

    String p = board[i];

    if (p.equals("."))
      continue;

    int v = pieceValue(
      Character.toUpperCase(p.charAt(0)));

    if (Character.isUpperCase(p.charAt(0)))
      score += v;
    else
      score -= v;
  }

  return score;
}


int pieceValue(char p) {

  if (p == 'P') return 100;
  if (p == 'N') return 320;
  if (p == 'B') return 330;
  if (p == 'R') return 500;
  if (p == 'Q') return 900;
  if (p == 'K') return 20000;

  return 0;
}















