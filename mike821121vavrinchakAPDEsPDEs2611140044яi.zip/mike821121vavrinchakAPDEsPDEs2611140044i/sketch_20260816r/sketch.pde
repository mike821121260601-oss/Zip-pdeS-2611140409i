
//errlingplay////
// APDE / Processing Android – 9×14 high-frequency random tone-pad
// 1 kHz – 21 kHz random sweeps + volume envelopes (10 90 %)

import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;

int cols = 14;
int rows = 9;
float cellW, cellH;

void setup() {
  fullScreen();



//  orientation(LANDSCAPE);




  cellW = width  / (float)cols;
  cellH = height / (float)rows;
  textAlign(CENTER, CENTER);
  textSize(18);
}

void draw() {
  background(200);
  
  for (int y = 0; y < rows; y++) {
    for (int x = 0; x < cols; x++) {
      float px = x * cellW;
      float py = y * cellH;
      
      // visual feedback when pressed
      if (mousePressed && mouseX > px && mouseX < px+cellW &&
                           mouseY > py && mouseY < py+cellH) {
        fill(80, 180, 255);
      } else {
        fill(40 + (x+y)%3 * 15);
      }
      stroke(90);
      rect(px+1, py+1, cellW-2, cellH-2, 6);
      
      fill(200);
      text((y*cols + x + 1), px + cellW/2, py + cellH/2);
    }
  }
}

void mousePressed() {
  int col = constrain((int)(mouseX / cellW), 0, cols-1);
  int row = constrain((int)(mouseY / cellH), 0, rows-1);
  
  // each key fires 9 completely independent random sweeps
  for (int i = 0; i < 9; i++) {
    float f1 = random(1000, 21000);   // start Hz  (fully random)
    float f2 = random(1000, 21000);   // end   Hz  (fully random)
    boolean volUp = random(1) > 0.5;  // 10%→90% or 90%→10%
    float duration = random(0.25, 0.55);
    playSweep(f1, f2, volUp, duration);
  }
}

// -----------------------------------------------------------------
// Generate & play one short frequency + volume sweep
void playSweep(final float startHz, final float endHz,
               final boolean volumeRising, final float durationSec) {
  
  new Thread(new Runnable() {
    public void run() {
      int sampleRate = 44100;
      int numSamples = (int)(durationSec * sampleRate);
      short[] buffer = new short[numSamples];
      
      float volStart = volumeRising ? 0.10f : 0.90f;
      float volEnd   = volumeRising ? 0.90f : 0.10f;
      
      for (int i = 0; i < numSamples; i++) {
        float t = i / (float)sampleRate;
        float progress = i / (float)(numSamples-1);
        
        // linear frequency sweep (fully random endpoints)
        float freq = lerp(startHz, endHz, progress);
        
        // linear volume envelope
        float amp  = lerp(volStart, volEnd, progress);
        
        float sample = (float)(Math.sin(2 * Math.PI * freq * t) * amp);
        buffer[i] = (short)(sample * 32767);
      }
      
      AudioTrack track = new AudioTrack(
          AudioManager.STREAM_MUSIC,
          sampleRate,
          AudioFormat.CHANNEL_OUT_MONO,
          AudioFormat.ENCODING_PCM_16BIT,
          buffer.length * 2,
          AudioTrack.MODE_STATIC);
      
      track.write(buffer, 0, buffer.length);
      track.play();
      
      try {
        Thread.sleep((long)(durationSec * 1000) + 30);
      } catch (InterruptedException e) {}
      track.stop();
      track.release();
    }
  }).start();
}



































