

// Ultra Small Touch Draw
void setup() {
  fullScreen();
  background(255);
  strokeWeight(5);
}

void draw() {
  if (mousePressed) {
    line(pmouseX, pmouseY, mouseX, mouseY);
  }
}

// Shake phone to clear (in Android mode) 
// or triple tap
int tapCount = 0;
int lastTapTime = 0;

void mousePressed() {
  if (millis() - lastTapTime < 300) {
    tapCount++;
    if (tapCount >= 3) {
      background(255);
      tapCount = 0;
    }
  } else {
    tapCount = 0;
  }
  lastTapTime = millis();
}





















