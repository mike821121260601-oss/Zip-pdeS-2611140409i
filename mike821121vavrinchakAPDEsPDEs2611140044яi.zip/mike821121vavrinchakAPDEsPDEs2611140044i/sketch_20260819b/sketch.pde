







/////SEE///OK/////errors//////errors//////

/*
  SMALL CHESS ENGINE v2
  APDE 0.5.3 / Processing Java

  Features:
  - Legal chess moves
  - Check
  - Checkmate
  - Stalemate
  - Castling
  - En-passant
  - Queen promotion
  - Alpha-beta engine
  - 10-position history
  - UCI-style commands
  - Touch board

  Human = WHITE
  Engine = BLACK

  UCI examples:

    uci
    isready
    ucinewgame
    position startpos
    position startpos moves e2e4 e7e5
    go depth 3
    stop
          */

int[] board = new int[64];

boolean whiteTurn;
boolean engineThinking = false;

int selected = -1;

int searchDepth = 3;

boolean castleWK;
boolean castleWQ;
boolean castleBK;
boolean castleBQ;

int enPassant = -1;

String lastMove = "";

// ------------------------------------------------------------
// HISTORY
// ------------------------------------------------------------

int[][] historyBoard = new int[10][64];

boolean[] historyTurn = new boolean[10];

boolean[] historyWK = new boolean[10];
boolean[] historyWQ = new boolean[10];
boolean[] historyBK = new boolean[10];
boolean[] historyBQ = new boolean[10];

int[] historyEP = new int[10];

int historyCount = 0;

// ------------------------------------------------------------
// MOVE OBJECT
// ------------------------------------------------------------

class Move {

  int from;
  int to;

  int promotion;

  boolean castle;
  boolean enPassant;

  Move(int f, int t) {
    from = f;
    to = t;
    promotion = 0;
    castle = false;
    enPassant = false;
  }
}

// ------------------------------------------------------------
// SETUP
// ------------------------------------------------------------

void setup() {

  fullScreen(P2D);

  textAlign(CENTER, CENTER);

  newGame();

  println("Small APDE Chess Engine v2");
  println("UCI ready");
}

// ------------------------------------------------------------
// DRAW
// ------------------------------------------------------------

void draw() {

  background(30);

  float s = min(width, height - 80) / 8.0;

  drawBoard(s);
  drawPieces(s);

  fill(255);
  textSize(24);

  if (engineThinking)
    text("ENGINE THINKING", width/2, height - 40);
  else if (inCheck(whiteTurn))
    text("CHECK", width/2, height - 40);
  else
    text(whiteTurn ? "WHITE" : "BLACK", width/2, height - 40);
}

// ------------------------------------------------------------
// BOARD
// ------------------------------------------------------------

void drawBoard(float s) {

  noStroke();

  for (int y = 0; y < 8; y++) {

    for (int x = 0; x < 8; x++) {

      if ((x+y)%2 == 0)
        fill(230,210,170);
      else
        fill(100,70,45);

      rect(x*s, y*s, s, s);

      int sq = y*8+x;

      if (sq == selected) {

        noFill();
        stroke(255,0,0);
        strokeWeight(5);

        rect(x*s+3,y*s+3,s-6,s-6);

        noStroke();
      }
    }
  }
}

// ------------------------------------------------------------
// PIECES
// ------------------------------------------------------------

void drawPieces(float s) {

  textSize(s*0.62);

  for (int sq=0; sq<64; sq++) {

    int p=board[sq];

    if (p==0)
      continue;

    int x=sq%8;
    int y=sq/8;

    if (p>0)
      fill(255);
    else
      fill(15);

    text(pieceChar(p),
         x*s+s/2,
         y*s+s/2);
  }
}

String pieceChar(int p) {

  if (p==1) return "P";
  if (p==2) return "N";
  if (p==3) return "B";
  if (p==4) return "R";
  if (p==5) return "Q";
  if (p==6) return "K";

  if (p==-1) return "p";
  if (p==-2) return "n";
  if (p==-3) return "b";
  if (p==-4) return "r";
  if (p==-5) return "q";
  if (p==-6) return "k";

  return "";
}

// ------------------------------------------------------------
// TOUCH
// ------------------------------------------------------------

void mousePressed() {

  float s=min(width,height-80)/8.0;

  if (mouseY >= s*8)
    return;

  int x=int(mouseX/s);
  int y=int(mouseY/s);

  int sq=y*8+x;

  if (engineThinking)
    return;

  if (!whiteTurn)
    return;

  if (selected==-1) {

    if (board[sq]>0)
      selected=sq;

    return;
  }

  if (sq==selected) {

    selected=-1;
    return;
  }

  ArrayList<Move> moves=generateLegalMoves(true);

  for (int i=0;i<moves.size();i++) {

    Move m=moves.get(i);

    if (m.from==selected &&
        m.to==sq) {

      makeMove(m);

      lastMove=
        squareName(m.from)+
        squareName(m.to);

      selected=-1;

      if (!whiteTurn)
        engineMove();

      return;
    }
  }

  selected=-1;
}

// ------------------------------------------------------------
// NEW GAME
// ------------------------------------------------------------

void newGame() {

  for (int i=0;i<64;i++)
    board[i]=0;

  // BLACK
  board[0]=-4;
  board[1]=-2;
  board[2]=-3;
  board[3]=-5;
  board[4]=-6;
  board[5]=-3;
  board[6]=-2;
  board[7]=-4;

  for (int i=8;i<16;i++)
    board[i]=-1;

  // WHITE
  board[56]=4;
  board[57]=2;
  board[58]=3;
  board[59]=5;
  board[60]=6;
  board[61]=3;
  board[62]=2;
  board[63]=4;

  for (int i=48;i<56;i++)
    board[i]=1;

  whiteTurn=true;

  castleWK=true;
  castleWQ=true;
  castleBK=true;
  castleBQ=true;

  enPassant=-1;

  selected=-1;

  historyCount=0;

  saveHistory();

  lastMove="";
}

// ------------------------------------------------------------
// GENERATE LEGAL MOVES
// ------------------------------------------------------------

ArrayList<Move> generateLegalMoves(boolean white) {

  ArrayList<Move> result=new ArrayList<Move>();

  for (int from=0;from<64;from++) {

    int p=board[from];

    if (p==0)
      continue;

    if (white && p<0)
      continue;

    if (!white && p>0)
      continue;

    ArrayList<Move> pseudo=generatePseudo(from);

    for (int i=0;i<pseudo.size();i++) {

      Move m=pseudo.get(i);

      makeMove(m);

      boolean legal=!inCheck(white);

      undoLastMove();

      if (legal)
        result.add(m);
    }
  }

  return result;
}

// ------------------------------------------------------------
// PSEUDO MOVES
// ------------------------------------------------------------

ArrayList<Move> generatePseudo(int from) {

  ArrayList<Move> list=new ArrayList<Move>();

  int p=board[from];

  int color=p>0 ? 1:-1;

  int type=abs(p);

  int x=from%8;
  int y=from/8;

  // PAWN
  if (type==1) {

    int dir=color==1 ? -1:1;

    int start=color==1 ? 6:1;

    int ny=y+dir;

    if (inside(x,ny)) {

      int to=ny*8+x;

      if (board[to]==0) {

        addPawnMove(list,from,to,color);

        if (y==start) {

          int to2=(y+2*dir)*8+x;

          if (board[to2]==0) {

            Move m=new Move(from,to2);
            list.add(m);
          }
        }
      }
    }

    for (int dx=-1;dx<=1;dx+=2) {

      int nx=x+dx;

      if (!inside(nx,ny))
        continue;

      int to=ny*8+nx;

      if (board[to]!=0 &&
          ((board[to]>0)!=(color>0))) {

        addPawnMove(list,from,to,color);
      }

      if (to==enPassant) {

        Move m=new Move(from,to);
        m.enPassant=true;
        list.add(m);
      }
    }

    return list;
  }

  // KNIGHT
  if (type==2) {

    int[][] d={
      {1,2},{2,1},
      {-1,2},{-2,1},
      {1,-2},{2,-1},
      {-1,-2},{-2,-1}
    };

    for (int i=0;i<8;i++)
      addNormal(list,from,x+d[i][0],y+d[i][1]);

    return list;
  }

  // BISHOP
  if (type==3) {

    slide(list,from,x,y,1,1);
    slide(list,from,x,y,1,-1);
    slide(list,from,x,y,-1,1);
    slide(list,from,x,y,-1,-1);

    return list;
  }

  // ROOK
  if (type==4) {

    slide(list,from,x,y,1,0);
    slide(list,from,x,y,-1,0);
    slide(list,from,x,y,0,1);
    slide(list,from,x,y,0,-1);

    return list;
  }

  // QUEEN
  if (type==5) {

    slide(list,from,x,y,1,0);
    slide(list,from,x,y,-1,0);
    slide(list,from,x,y,0,1);
    slide(list,from,x,y,0,-1);

    slide(list,from,x,y,1,1);
    slide(list,from,x,y,1,-1);
    slide(list,from,x,y,-1,1);
    slide(list,from,x,y,-1,-1);

    return list;
  }

  // KING
  if (type==6) {

    for (int dx=-1;dx<=1;dx++)
      for (int dy=-1;dy<=1;dy++)
        if (dx!=0 || dy!=0)
          addNormal(list,from,x+dx,y+dy);

    // CASTLING
    if (color>0) {

      if (castleWK &&
          board[61]==0 &&
          board[62]==0 &&
          !squareAttacked(60,false) &&
          !squareAttacked(61,false) &&
          !squareAttacked(62,false)) {

        Move m=new Move(60,62);
        m.castle=true;
        list.add(m);
      }

      if (castleWQ &&
          board[59]==0 &&
          board[58]==0 &&
          board[57]==0 &&
          !squareAttacked(60,false) &&
          !squareAttacked(59,false) &&
          !squareAttacked(58,false)) {

        Move m=new Move(60,58);
        m.castle=true;
        list.add(m);
      }

    } else {

      if (castleBK &&
          board[5]==0 &&
          board[6]==0 &&
          !squareAttacked(4,true) &&
          !squareAttacked(5,true) &&
          !squareAttacked(6,true)) {

        Move m=new Move(4,6);
        m.castle=true;
        list.add(m);
      }

      if (castleBQ &&
          board[3]==0 &&
          board[2]==0 &&
          board[1]==0 &&
          !squareAttacked(4,true) &&
          !squareAttacked(3,true) &&
          !squareAttacked(2,true)) {

        Move m=new Move(4,2);
        m.castle=true;
        list.add(m);
      }
    }

    return list;
  }

  return list;
}

// ------------------------------------------------------------
// PAWN PROMOTION
// ------------------------------------------------------------

void addPawnMove(ArrayList<Move> list,
                 int from,
                 int to,
                 int color) {

  Move m=new Move(from,to);

  int rank=to/8;

  if ((color>0 && rank==0) ||
      (color<0 && rank==7))
    m.promotion=5*color;

  list.add(m);
}

// ------------------------------------------------------------
// NORMAL MOVE
// ------------------------------------------------------------

void addNormal(ArrayList<Move> list,
               int from,
               int x,
               int y) {

  if (!inside(x,y))
    return;

  int to=y*8+x;

  int p=board[from];

  if (board[to]!=0 &&
      ((board[to]>0)==(p>0)))
    return;

  list.add(new Move(from,to));
}

// ------------------------------------------------------------
// SLIDING
// ------------------------------------------------------------

void slide(ArrayList<Move> list,
           int from,
           int x,
           int y,
           int dx,
           int dy) {

  int p=board[from];

  x+=dx;
  y+=dy;

  while (inside(x,y)) {

    int to=y*8+x;

    if (board[to]==0) {

      list.add(new Move(from,to));

    } else {

      if ((board[to]>0)!=(p>0))
        list.add(new Move(from,to));

      break;
    }

    x+=dx;
    y+=dy;
  }
}

// ------------------------------------------------------------
// MAKE MOVE
// ------------------------------------------------------------

void makeMove(Move m) {

  saveHistory();

  int p=board[m.from];

  board[m.to]=p;
  board[m.from]=0;

  // EN PASSANT CAPTURE
  if (m.enPassant) {

    if (p>0)
      board[m.to+8]=0;
    else
      board[m.to-8]=0;
  }

  // PROMOTION
  if (m.promotion!=0)
    board[m.to]=m.promotion;

  // CASTLING ROOK
  if (m.castle) {

    if (m.to==62) {
      board[61]=board[63];
      board[63]=0;
    }

    if (m.to==58) {
      board[59]=board[56];
      board[56]=0;
    }

    if (m.to==6) {
      board[5]=board[7];
      board[7]=0;
    }

    if (m.to==2) {
      board[3]=board[0];
      board[0]=0;
    }
  }

  // CASTLING RIGHTS
  if (p==6) {
    castleWK=false;
    castleWQ=false;
  }

  if (p==-6) {
    castleBK=false;
    castleBQ=false;
  }

  if (m.from==63 || m.to==63)
    castleWK=false;

  if (m.from==56 || m.to==56)
    castleWQ=false;

  if (m.from==7 || m.to==7)
    castleBK=false;

  if (m.from==0 || m.to==0)
    castleBQ=false;

  // EN PASSANT TARGET
  enPassant=-1;

  if (abs(p)==1 &&
      abs(m.to-m.from)==16)
    enPassant=(m.from+m.to)/2;

  whiteTurn=!whiteTurn;
}

// ------------------------------------------------------------
// UNDO
// ------------------------------------------------------------

void undoLastMove() {

  if (historyCount<=0)
    return;

  historyCount--;

  for (int i=0;i<64;i++)
    board[i]=historyBoard[historyCount][i];

  whiteTurn=historyTurn[historyCount];

  castleWK=historyWK[historyCount];
  castleWQ=historyWQ[historyCount];

  castleBK=historyBK[historyCount];
  castleBQ=historyBQ[historyCount];

  enPassant=historyEP[historyCount];
}

// ------------------------------------------------------------
// SAVE HISTORY
// ------------------------------------------------------------

void saveHistory() {

  if (historyCount>=10)
    historyCount=9;

  for (int i=0;i<64;i++)
    historyBoard[historyCount][i]=board[i];

  historyTurn[historyCount]=whiteTurn;

  historyWK[historyCount]=castleWK;
  historyWQ[historyCount]=castleWQ;

  historyBK[historyCount]=castleBK;
  historyBQ[historyCount]=castleBQ;

  historyEP[historyCount]=enPassant;

  historyCount++;
}

// ------------------------------------------------------------
// CHECK
// ------------------------------------------------------------

boolean inCheck(boolean white) {

  int king=white ? 6:-6;

  for (int i=0;i<64;i++) {

    if (board[i]==king)
      return squareAttacked(i,!white);
  }

  return true;
}

// ------------------------------------------------------------
// ATTACK TEST
// ------------------------------------------------------------

boolean squareAttacked(int sq,
                       boolean byWhite) {

  int x=sq%8;
  int y=sq/8;

  int pawn=byWhite ? 1:-1;

  int py=y+(byWhite ? 1:-1);

  if (inside(x-1,py) &&
      board[py*8+x-1]==pawn)
    return true;

  if (inside(x+1,py) &&
      board[py*8+x+1]==pawn)
    return true;

  int knight=byWhite ? 2:-2;

  int[][] nd={
    {1,2},{2,1},{-1,2},{-2,1},
    {1,-2},{2,-1},{-1,-2},{-2,-1}
  };

  for (int i=0;i<8;i++) {

    int nx=x+nd[i][0];
    int ny=y+nd[i][1];

    if (inside(nx,ny) &&
        board[ny*8+nx]==knight)
      return true;
  }

  int bishop=byWhite ? 3:-3;
  int queen=byWhite ? 5:-5;
  int rook=byWhite ? 4:-4;

  if (rayAttack(x,y,1,1,bishop,queen))
    return true;

  if (rayAttack(x,y,1,-1,bishop,queen))
    return true;

  if (rayAttack(x,y,-1,1,bishop,queen))
    return true;

  if (rayAttack(x,y,-1,-1,bishop,queen))
    return true;

  if (rayAttack(x,y,1,0,rook,queen))
    return true;

  if (rayAttack(x,y,-1,0,rook,queen))
    return true;

  if (rayAttack(x,y,0,1,rook,queen))
    return true;

  if (rayAttack(x,y,0,-1,rook,queen))
    return true;

  int king=byWhite ? 6:-6;

  for (int dx=-1;dx<=1;dx++)
    for (int dy=-1;dy<=1;dy++)
      if (dx!=0 || dy!=0) {

        int nx=x+dx;
        int ny=y+dy;

        if (inside(nx,ny) &&
            board[ny*8+nx]==king)
          return true;
      }

  return false;
}

// ------------------------------------------------------------
// RAY ATTACK
// ------------------------------------------------------------

boolean rayAttack(int x,int y,
                  int dx,int dy,
                  int piece,
                  int queen) {

  x+=dx;
  y+=dy;

  while (inside(x,y)) {

    int p=board[y*8+x];

    if (p!=0)
      return p==piece || p==queen;

    x+=dx;
    y+=dy;
  }

  return false;
}

// ------------------------------------------------------------
// ENGINE
// ------------------------------------------------------------

void engineMove() {

  engineThinking=true;

  ArrayList<Move> moves=
    generateLegalMoves(false);

  if (moves.size()==0) {

    engineThinking=false;

    if (inCheck(false))
      println("checkmate");
    else
      println("stalemate");

    return;
  }

  Move best=null;

  int bestScore=-10000000;

  for (int i=0;i<moves.size();i++) {

    Move m=moves.get(i);

    makeMove(m);

    int score=
      -negamax(searchDepth-1,
               -10000000,
               10000000);

    undoLastMove();

    if (score>bestScore) {

      bestScore=score;
      best=m;
    }
  }

  if (best!=null) {

    String uciMove=
      squareName(best.from)+
      squareName(best.to);

    makeMove(best);

    lastMove=uciMove;

    println("bestmove "+uciMove);
  }

  engineThinking=false;
}

// ------------------------------------------------------------
// NEGAMAX
// ------------------------------------------------------------

int negamax(int depth,
            int alpha,
            int beta) {

  ArrayList<Move> moves=
    generateLegalMoves(whiteTurn);

  if (moves.size()==0) {

    if (inCheck(whiteTurn))
      return -100000+depth;

    return 0;
  }

  if (depth<=0)
    return evaluateForSide();

  int best=-10000000;

  for (int i=0;i<moves.size();i++) {

    Move m=moves.get(i);

    makeMove(m);

    int score=
      -negamax(depth-1,
               -beta,
               -alpha);

    undoLastMove();

    if (score>best)
      best=score;

    if (score>alpha)
      alpha=score;

    if (alpha>=beta)
      break;
  }

  return best;
}

// ------------------------------------------------------------
// EVALUATION
// ------------------------------------------------------------

int evaluateForSide() {

  int score=0;

  for (int i=0;i<64;i++) {

    int p=board[i];

    if (p==0)
      continue;

    int value=0;

    if (abs(p)==1) value=100;
    if (abs(p)==2) value=320;
    if (abs(p)==3) value=330;
    if (abs(p)==4) value=500;
    if (abs(p)==5) value=900;
    if (abs(p)==6) value=20000;

    score += p>0 ? value:-value;
  }

  // mobility bonus
  int myMoves=
    generateLegalMoves(whiteTurn).size();

  score += whiteTurn ?
    myMoves*3 :
    -myMoves*3;

  return whiteTurn ? score:-score;
}

// ------------------------------------------------------------
// GAME STATUS
// ------------------------------------------------------------

void printStatus() {

  ArrayList<Move> moves=
    generateLegalMoves(whiteTurn);

  if (moves.size()==0) {

    if (inCheck(whiteTurn)) {

      if (whiteTurn)
        println("CHECKMATE BLACK WINS");
      else
        println("CHECKMATE WHITE WINS");

    } else {

      println("STALEMATE");
    }

  } else if (inCheck(whiteTurn)) {

    println("CHECK");
  }
}

// ------------------------------------------------------------
// UCI
// ------------------------------------------------------------

void uci(String command) {

  command=trim(command);

  println("> "+command);

  if (command.equals("uci")) {

    println("id name SmallAPDE-Chess-v2");
    println("id author APDE");
    println("option name Depth type spin default 3 min 1 max 5");
    println("uciok");

    return;
  }

  if (command.equals("isready")) {

    println("readyok");

    return;
  }

  if (command.equals("ucinewgame")) {

    newGame();

    return;
  }

  if (command.equals("stop")) {

    engineThinking=false;

    return;
  }

  if (command.equals("quit")) {

    println("quit");

    return;
  }

  if (command.startsWith("position startpos")) {

    newGame();

    int pos=command.indexOf("moves");

    if (pos>=0) {

      String rest=
        trim(command.substring(pos+5));

      if (rest.length()>0) {

        String[] moves=
          split(rest,' ');

        for (int i=0;i<moves.length;i++)
          applyUCIMove(moves[i]);
      }
    }

    return;
  }

  if (command.startsWith("go")) {

    int d=3;

    String[] a=split(command,' ');

    for (int i=0;i<a.length-1;i++) {

      if (a[i].equals("depth"))
        d=int(a[i+1]);
    }

    searchDepth=constrain(d,1,5);

    if (!whiteTurn)
      engineMove();

    return;
  }
}

// ------------------------------------------------------------
// APPLY UCI MOVE
// ------------------------------------------------------------

void applyUCIMove(String s) {

  if (s.length()<4)
    return;

  int from=
    parseSquare(s.substring(0,2));

  int to=
    parseSquare(s.substring(2,4));

  if (from<0 || to<0)
    return;

  ArrayList<Move> moves=
    generateLegalMoves(whiteTurn);

  for (int i=0;i<moves.size();i++) {

    Move m=moves.get(i);

    if (m.from==from &&
        m.to==to) {

      makeMove(m);

      lastMove=s;

      return;
    }
  }
}

// ------------------------------------------------------------
// SQUARE NAME
// ------------------------------------------------------------

String squareName(int sq) {

  int x=sq%8;
  int y=sq/8;

  return ""+
    char('a'+x)+
    char('8'-y);
}

int parseSquare(String s) {

  if (s.length()!=2)
    return -1;

  int x=s.charAt(0)-'a';
  int y='8'-s.charAt(1);

  if (!inside(x,y))
    return -1;

  return y*8+x;
}

// ------------------------------------------------------------
// INSIDE
// ------------------------------------------------------------

boolean inside(int x,int y) {

  return x>=0 &&
         x<8 &&
         y>=0 &&
         y<8;
}

// ------------------------------------------------------------
// KEYBOARD UCI TEST
// ------------------------------------------------------------

void keyPressed() {

  if (key=='1')
    uci("uci");

  if (key=='2')
    uci("isready");

  if (key=='3')
    uci("ucinewgame");

  if (key=='4')
    uci("position startpos");

  if (key=='5')
    uci("position startpos moves e2e4 e7e5");

  if (key=='6')
    uci("go depth 3");

  if (key=='7')
    printStatus();
}







/////SEE/////OK/////


























