


import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Build;
import android.view.View;
import android.widget.RemoteViews;

NotificationManager notificationManager;

String CHANNEL_ID = "my_picture_channel";
int NOTIFICATION_ID = 12345;

void setup() {
  size(displayWidth, displayHeight);

  // Create notification channel
  notificationManager =
    (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);

  if (Build.VERSION.SDK_INT >= 26) {

    NotificationChannel channel = new NotificationChannel(
      CHANNEL_ID,
      "My Picture Panel",
      NotificationManager.IMPORTANCE_HIGH
    );

    channel.setDescription("Picture and panel notification");
    channel.enableLights(true);
    channel.enableVibration(true);

    notificationManager.createNotificationChannel(channel);
  }

  // Create notification
  makeNotification();

  background(40);
  fill(255);
  textSize(30);
  textAlign(CENTER, CENTER);
  text("Notification created", width/2, height/2);
}


void draw() {
}


void makeNotification() {

  // ------------------------------------------------
  // CUSTOM NOTIFICATION PANEL
  // ------------------------------------------------

  RemoteViews panel = new RemoteViews(
    getPackageName(),
    R.layout.notification_panel
  );

  panel.setTextViewText(
    R.id.notification_title,
    "MY APDE APP"
  );

  panel.setTextViewText(
    R.id.notification_text,
    "Picture + custom panel"
  );


  // ------------------------------------------------
  // CREATE PICTURE
  // ------------------------------------------------

  Bitmap picture = Bitmap.createBitmap(
    300,
    180,
    Bitmap.Config.ARGB_8888
  );

  Canvas canvas = new Canvas(picture);

  Paint p = new Paint();
  p.setAntiAlias(true);

  // background
  p.setColor(Color.rgb(20, 20, 30));
  canvas.drawRect(0, 0, 300, 180, p);

  // big circle
  p.setColor(Color.rgb(0, 180, 255));
  canvas.drawCircle(150, 90, 55, p);

  // inner circle
  p.setColor(Color.WHITE);
  canvas.drawCircle(150, 90, 25, p);

  // lines
  p.setColor(Color.RED);
  p.setStrokeWidth(8);

  canvas.drawLine(20, 20, 280, 160, p);
  canvas.drawLine(280, 20, 20, 160, p);


  panel.setImageViewBitmap(
    R.id.notification_picture,
    picture
  );


  // ------------------------------------------------
  // LARGE ICON
  // ------------------------------------------------

  Bitmap icon = Bitmap.createBitmap(
    96,
    96,
    Bitmap.Config.ARGB_8888
  );

  Canvas ic = new Canvas(icon);

  Paint ip = new Paint();
  ip.setColor(Color.BLUE);
  ic.drawCircle(48, 48, 45, ip);

  ip.setColor(Color.WHITE);
  ic.drawCircle(48, 48, 20, ip);


  // ------------------------------------------------
  // OPEN APP WHEN NOTIFICATION IS TOUCHED
  // ------------------------------------------------

  Intent intent = new Intent(
    getActivity(),
    getActivity().getClass()
  );

  int flags = PendingIntent.FLAG_UPDATE_CURRENT;

  if (Build.VERSION.SDK_INT >= 23) {
    flags |= PendingIntent.FLAG_IMMUTABLE;
  }

  PendingIntent pendingIntent =
    PendingIntent.getActivity(
      getActivity(),
      0,
      intent,
      flags
    );


  // ------------------------------------------------
  // BUILD NOTIFICATION
  // ------------------------------------------------

  Notification.Builder builder;

  if (Build.VERSION.SDK_INT >= 26) {

    builder = new Notification.Builder(
      getActivity(),
      CHANNEL_ID
    );

  } else {

    builder = new Notification.Builder(
      getActivity()
    );
  }


  builder
    .setSmallIcon(android.R.drawable.ic_menu_gallery)
    .setLargeIcon(icon)
    .setContentTitle("MY APDE APP")
    .setContentText("Picture and panel")
    .setCustomContentView(panel)
    .setCustomBigContentView(panel)
    .setContentIntent(pendingIntent)
    .setAutoCancel(false)
    .setOngoing(true)
    .setShowWhen(true);


  Notification notification =
    builder.build();


  // ------------------------------------------------
  // SHOW NOTIFICATION
  // ------------------------------------------------

  notificationManager.notify(
    NOTIFICATION_ID,
    notification
  );
}
































