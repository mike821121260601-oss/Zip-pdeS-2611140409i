



import android. *;import java. *;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;

void settings() {
size(displayWidth, displayHeight, JAVA2D) ; } 
void setup() {
size(displayWidth, displayHeight, JAVA2D) ; } 


/*
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
*/


////// Canvas   canvas=new Canvas() ;


/////View.onDraw(Canvas  canvas);
          
 /*
  canvas.drawPoint()
   canvas.drawLine()
   canvas.drawRect()
   canvas.drawPath()

*/





Paint p = new Paint();
setStrokeWidth(4);

getContext(). Canvas.canvas.drawPoint(50, 50, p);
canvas.drawLine(50, 100, 300, 100, p);
canvas.drawRect(50, 150, 300, 300, p);

Path t = new Path();
t.moveTo(100, 400);
t.lineTo(300, 400);
t.lineTo(200, 250);
t.close();

canvas.drawPath(t, p);






import android.app.Activity;
import android.os.Bundle;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

public class MainActivity extends Activity {

    public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(new MyView());
    }

    class MyView extends View {

        Paint p = new Paint();
        Path t = new Path();

        MyView() {
            super(MainActivity.this);
            p.setStrokeWidth(5);
            p.setStyle(Paint.Style.STROKE);
        }

        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);

            // POINT
            canvas.drawPoint(100, 100, p);

            // LINE
            canvas.drawLine(100, 180, 400, 180, p);

            // RECTANGLE
            canvas.drawRect(100, 250, 400, 450, p);

            // TRIANGLE
            t.reset();
            t.moveTo(250, 550);
            t.lineTo(100, 750);
            t.lineTo(400, 750);
            t.close();

            canvas.drawPath(t, p);
        }
    }
}









































