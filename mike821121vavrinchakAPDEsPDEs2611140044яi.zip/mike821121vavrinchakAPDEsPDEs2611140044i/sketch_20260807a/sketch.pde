











/*

Yes. Here is a single APDE / Processing Java game example with:
3D mountains
Walking forward/back/left/right
On-screen touch keys
100 spheres in the sky
3D moving line
Line connecting nearby spheres
+1 when you reach a sphere
First-person camera
Works as a starting point for APDE
Save it as your main .pde file.

*/
// APDE 3D MOUNTAIN WALKING GAME
// Processing Android / APDE
// P3D + touch controls

int NUM_SPHERES = 100;

float playerX = 0;
float playerY = -80;
float playerZ = 500;

float angle = 0;
float walkSpeed = 8;

boolean upKey = false;
boolean downKey = false;
boolean leftKey = false;
boolean rightKey = false;

float[] sx = new float[NUM_SPHERES];
float[] sy = new float[NUM_SPHERES];
float[] sz = new float[NUM_SPHERES];

boolean[] taken = new boolean[NUM_SPHERES];

int score = 0;

void setup() {
  fullScreen(P3D);

  // Create 100 spheres in the sky
  for (int i = 0; i < NUM_SPHERES; i++) {
    sx[i] = random(-1800, 1800);
    sy[i] = random(-700, 100);
    sz[i] = random(-2200, 500);
  }
}

void draw() {
  background(30, 70, 120);

  // 3D camera
  float lookX = playerX + sin(angle) * 500;
  float lookZ = playerZ - cos(angle) * 500;

  camera(
    playerX, playerY, playerZ,
    lookX, playerY, lookZ,
    0, 1, 0
  );

  lights();

  drawSky();
  drawGround();
  drawMountains();

  updatePlayer();

  drawSpheres();
  drawMovingLines();

  checkSpheres();

  // 2D interface
  hint(DISABLE_DEPTH_TEST);
  camera();

  drawControls();
  drawScore();

  hint(ENABLE_DEPTH_TEST);
}

// --------------------------------------------------
// PLAYER
// --------------------------------------------------

void updatePlayer() {

  float dx = 0;
  float dz = 0;

  if (upKey) {
    dx += sin(angle) * walkSpeed;
    dz -= cos(angle) * walkSpeed;
  }

  if (downKey) {
    dx -= sin(angle) * walkSpeed;
    dz += cos(angle) * walkSpeed;
  }

  if (leftKey) {
    dx -= cos(angle) * walkSpeed;
    dz -= sin(angle) * walkSpeed;
  }

  if (rightKey) {
    dx += cos(angle) * walkSpeed;
    dz += sin(angle) * walkSpeed;
  }

  playerX += dx;
  playerZ += dz;
}

// --------------------------------------------------
// SKY
// --------------------------------------------------

void drawSky() {

  pushMatrix();

  noStroke();
  fill(80, 150, 220);

  translate(playerX, 400, playerZ);

  sphere(3000);

  popMatrix();
}

// --------------------------------------------------
// GROUND
// --------------------------------------------------

void drawGround() {

  pushMatrix();

  translate(0, 100, 0);

  rotateX(HALF_PI);

  noStroke();
  fill(50, 130, 60);

  plane(5000, 5000);

  popMatrix();
}

// --------------------------------------------------
// MOUNTAINS
// --------------------------------------------------

void drawMountains() {

  pushMatrix();

  translate(0, 0, -900);

  noStroke();

  // Back mountains
  for (int x = -2000; x < 2000; x += 250) {

    float h = 300 + noise(x * 0.01) * 600;

    fill(
      60 + (x % 100),
      70,
      80
    );

    beginShape(TRIANGLES);

    vertex(x, 100, 0);
    vertex(x + 250, 100, 0);
    vertex(x + 125, 100 - h, 0);

    endShape();
  }

  popMatrix();
}

// --------------------------------------------------
// 100 SPHERES
// --------------------------------------------------

void drawSpheres() {

  for (int i = 0; i < NUM_SPHERES; i++) {

    if (taken[i])
      continue;

    pushMatrix();

    translate(sx[i], sy[i], sz[i]);

    // Different colors
    if (i % 3 == 0)
      fill(255, 80, 80);
    else if (i % 3 == 1)
      fill(80, 255, 100);
    else
      fill(255, 230, 40);

    noStroke();

    sphere(25);

    popMatrix();
  }
}

// --------------------------------------------------
// MOVING 3D LINES
// --------------------------------------------------

void drawMovingLines() {

  strokeWeight(3);

  // Moving line from player toward the world
  stroke(255, 255, 255);

  line(
    playerX,
    playerY,
    playerZ,

    playerX + sin(frameCount * 0.03) * 400,
    playerY - 200,
    playerZ - 500
  );

  // Lines between nearby spheres
  for (int i = 0; i < NUM_SPHERES; i++) {

    if (taken[i])
      continue;

    for (int j = i + 1; j < NUM_SPHERES; j++) {

      if (taken[j])
        continue;

      float d = dist(
        sx[i], sy[i], sz[i],
        sx[j], sy[j], sz[j]
      );

      if (d < 300) {

        stroke(255, 200, 50, 100);

        line(
          sx[i], sy[i], sz[i],
          sx[j], sy[j], sz[j]
        );
      }
    }
  }
}

// --------------------------------------------------
// COLLECT SPHERES
// --------------------------------------------------

void checkSpheres() {

  for (int i = 0; i < NUM_SPHERES; i++) {

    if (taken[i])
      continue;

    float d = dist(
      playerX,
      playerY,
      playerZ,
      sx[i],
      sy[i],
      sz[i]
    );

    if (d < 70) {

      taken[i] = true;

      score++;

      // New sphere appears
      sx[i] = random(-1800, 1800);
      sy[i] = random(-700, 100);
      sz[i] = random(-2200, 500);

      taken[i] = false;
    }
  }
}

// --------------------------------------------------
// ON-SCREEN BUTTONS
// --------------------------------------------------

void drawControls() {

  noStroke();

  // UP
  fill(255, 255, 255, 100);
  ellipse(110, height - 190, 110, 110);

  // DOWN
  ellipse(110, height - 60, 110, 110);

  // LEFT
  ellipse(50, height - 125, 110, 110);

  // RIGHT
  ellipse(170, height - 125, 110, 110);

  fill(0);

  textAlign(CENTER, CENTER);
  textSize(40);

  text("▲", 110, height - 190);
  text("▼", 110, height - 60);
  text("◀", 50, height - 125);
  text("▶", 170, height - 125);
}

// --------------------------------------------------
// SCORE
// --------------------------------------------------

void drawScore() {

  fill(255);
  textAlign(LEFT, TOP);
  textSize(32);

  text("+ " + score, 30, 30);
}

// --------------------------------------------------
// TOUCH
// --------------------------------------------------

void mousePressed() {

  float x = mouseX;
  float y = mouseY;

  upKey = false;
  downKey = false;
  leftKey = false;
  rightKey = false;

  // UP
  if (dist(x, y, 110, height - 190) < 60)
    upKey = true;

  // DOWN
  if (dist(x, y, 110, height - 60) < 60)
    downKey = true;

  // LEFT
  if (dist(x, y, 50, height - 125) < 60)
    leftKey = true;

  // RIGHT
  if (dist(x, y, 170, height - 125) < 60)
    rightKey = true;
}

void mouseReleased() {

  upKey = false;
  downKey = false;
  leftKey = false;
  rightKey = false;
}



/*
Controls
▲ = walk forward
▼ = walk backward
◀ = walk left
▶ = walk right
The white 3D line moves continuously, and yellow lines connect spheres that are close together. Touching a sphere gives +1.
If you want, I can also make version 2 with a joystick, �⁠turning left/right by swiping the screen, �⁠trees, �⁠roads, �⁠houses, and �⁠much larger mountains.




*/









