
















import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.provider.Settings;

NotificationManager nm;

String CHANNEL_ID = "APDE_CHANNEL";

void setup() {
  size(displayWidth, displayHeight);

  nm = (NotificationManager)
    getActivity().getSystemService(Context.NOTIFICATION_SERVICE);

  createChannel();

  // Buttons on screen
  fill(40);
  rect(20, 30, width-40, 90);
  rect(20, 140, width-40, 90);
  rect(20, 250, width-40, 90);
  rect(20, 360, width-40, 90);

  fill(255);
  textSize(28);
  text("OPEN NOTIFICATION PANEL", 40, 85);
  text("SEND NOTIFICATION", 40, 195);
  text("SEND 3 NOTIFICATIONS", 40, 305);
  text("OPEN NOTIFICATION SETTINGS", 40, 415);
}


void createChannel() {

  if (Build.VERSION.SDK_INT >= 26) {

    NotificationChannel channel =
      new NotificationChannel(
      CHANNEL_ID,
      "APDE Notifications",
      NotificationManager.IMPORTANCE_DEFAULT
      );

    channel.setDescription("APDE notification channel");

    nm.createNotificationChannel(channel);
  }
}


void sendNotification(int id, String title, String message) {

  Intent intent = new Intent(getActivity(), getActivity().getClass());

  PendingIntent pi = PendingIntent.getActivity(
    getActivity(),
    id,
    intent,
    PendingIntent.FLAG_UPDATE_CURRENT |
    (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0)
    );

  Notification.Builder b;

  if (Build.VERSION.SDK_INT >= 26) {
    b = new Notification.Builder(
      getActivity(),
      CHANNEL_ID
      );
  } else {
    b = new Notification.Builder(getActivity());
  }

  b.setSmallIcon(android.R.drawable.ic_dialog_info)
   .setContentTitle(title)
   .setContentText(message)
   .setContentIntent(pi)
   .setAutoCancel(true)
   .setWhen(System.currentTimeMillis())
   .setShowWhen(true)
   .setPriority(Notification.PRIORITY_DEFAULT);

  nm.notify(id, b.build());
}


void openNotificationPanel() {

  try {

    Intent intent = new Intent(
      "android.settings.NOTIFICATION_SETTINGS"
      );

    startActivity(intent);

  } catch(Exception e) {

    println(e);
  }
}


void openNotificationSettings() {

  try {

    Intent intent = new Intent(
      Settings.ACTION_APP_NOTIFICATION_SETTINGS
      );

    intent.putExtra(
      Settings.EXTRA_APP_PACKAGE,
      getActivity().getPackageName()
      );

    startActivity(intent);

  } catch(Exception e) {

    println(e);
  }
}


void mousePressed() {

  if (mouseY > 30 && mouseY < 120) {

    openNotificationPanel();

  }

  if (mouseY > 140 && mouseY < 230) {

    sendNotification(
      1,
      "APDE notification",
      "Hello from your APDE application"
      );

  }

  if (mouseY > 250 && mouseY < 340) {

    sendNotification(
      10,
      "Notification 1",
      "First message"
      );

    sendNotification(
      11,
      "Notification 2",
      "Second message"
      );

    sendNotification(
      12,
      "Notification 3",
      "Third message"
      );

  }

  if (mouseY > 360 && mouseY < 450) {

    openNotificationSettings();

  }
}




































