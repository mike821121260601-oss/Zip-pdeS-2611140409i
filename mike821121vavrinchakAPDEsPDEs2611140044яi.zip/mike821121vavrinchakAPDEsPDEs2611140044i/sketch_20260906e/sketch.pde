






























////WORK//////WORK/////WORK/////////
// Android media APIs – без Processing Sound
import android.media.MediaRecorder;
import android.media.MediaPlayer;
import java.io.File;
import java.io.IOException;

final int COLS = 9;
final int ROWS = 14;
final int TOTAL = COLS * ROWS;

// Стани
final int IDLE = 0;
final int RECORDING = 1;
final int PLAYING_ALL = 2;
int state = IDLE;

// Запис
MediaRecorder recorder;
int recordingKey = -1;
long recordStart;

// Відтворення
MediaPlayer player;
int playIndex = 0;    // який трек зараз грає
boolean playNextPending = false;

// Файли зберігаються у внутрішній пам'яті (sketchPath)
String getFileName(int idx) {
  return "key_" + idx + ".3gp";
}

void setup() {
 ///  size(900, 700);   // зручний розмір для 9×14
    size(displayWidth, displayHeight, JAVA2D) ;

  // Дозвіл на мікрофон – має бути доданий у вкладці Android
}

void draw() {
  background(200);
  
  float cellW = width / (float) COLS;
  float cellH = height / (float) ROWS;
  
  // Малюємо сітку
  for (int i = 0; i < TOTAL; i++) {
    int col = i % COLS;
    int row = i / COLS;
    float x = col * cellW;
    float y = row * cellH;
    
    // Колір: перша кнопка особлива
    if (i == 0) {
      fill(200, 100, 100);
    } else {
      // Чи існує файл?
  File f = new File(sketchPath(getFileName(i)));
      if (f.exists()) fill(100, 200, 100);
      else fill(150);
    }
    rect(x, y, cellW, cellH);
    
    // Номер
    fill(0);
    textAlign(CENTER, CENTER);
    textSize(12);
    text(i, x + cellW/2, y + cellH/2);
  }
  
  // Статус
  fill(0);
  textAlign(LEFT, TOP);
  textSize(16);
  if (state == RECORDING) {
    int elapsed = (int)((millis() 
     - recordStart) / 1000);
    text("Запис кнопки " + recordingKey 
   + " ... " + elapsed + "/10с", 10, 10);
  } else if (state == PLAYING_ALL) {
    text("Грає��о всі треки... (" 
   + playIndex + "/" + TOTAL + ")", 10, 10);
  } else {
    text
("Торкніться кнопки (1–125) для запису 10с, або кнопки 0 для відтворення всіх", 10, 10);
  }
  
  // Якщо йде запис – перевіряємо таймаут
  if (state == RECORDING && (millis() 
    - recordStart >= 10000)) {
    finishRecording();
  }
  
  // Якщо граємо всі – перевіряємо завершення поточного треку
  if (state == PLAYING_ALL && playNextPending) {
    if (player != null && !player.isPlaying()) {
      // Поточний трек скінчився – запускаємо наступний
      playNextPending = false;
      playNext();
    }
  }
}

// Визначаємо, яку кнопку натиснули
int getKeyAt(float mx, float my) {
  float cellW = width / (float) COLS;
  float cellH = height / (float) ROWS;
  int col = (int)(mx / cellW);
  int row = (int)(my / cellH);
  if (col < 0 || col >= COLS 
    || row < 0 || row >= ROWS) return -1;
  return row * COLS + col;
}

void mousePressed() {
  if (state == RECORDING) return; 
  // зайнято записом
  
  int key = getKeyAt(mouseX, mouseY);
  if (key < 0 || key >= TOTAL) return;
  
  if (key == 0) {
    // Перша кнопка – граємо всі
    if (state == PLAYING_ALL) return; 
 // вже граємо
    startPlayAll();
  } else {
    // Інша кнопка – запис
    startRecording(key);
  }
}

// ----- ЗАПИС -----
void startRecording(int key) {
  // Видалити старий файл, якщо є
  File f = new File(sketchPath(getFileName(key)));
  if (f.exists()) f.delete();
  
  try {
    recorder = new MediaRecorder();
    recorder.setAudioSource
  (MediaRecorder.AudioSource.MIC);
    recorder.setOutputFormat
  (MediaRecorder.OutputFormat.THREE_GPP);
    recorder.setAudioEncoder
  (MediaRecorder.AudioEncoder.AMR_NB);
    recorder.setOutputFile
  (sketchPath(getFileName(key)));
    recorder.prepare();
    recorder.start();
    
    state = RECORDING;
    recordingKey = key;
    recordStart = millis();
  } catch (SecurityException e) {
    println
("⚠️ Немає дозволу на мікрофон – додайте його у вкладці Android!");
  } catch (Exception e) {
    e.printStackTrace();
  }
}

void finishRecording() {
  if (recorder != null) {
    recorder.stop();
    recorder.release();
    recorder = null;
  }
  state = IDLE;
  recordingKey = -1;
  println
("Запис кнопки " + recordingKey + " завершено.");
}

// ----- ВІДТВОРЕННЯ ВСІХ -----
void startPlayAll() {
  if (state == PLAYING_ALL) return;
  state = PLAYING_ALL;
  playIndex = 1; 
 // починаємо з першої кнопки (index=1)
  playNext();    
 // запускаємо перший існуючий трек
}

void playNext() {
  // Шукаємо наступний існуючий файл, починаючи з поточн����го playIndex
  while (playIndex < TOTAL) {
    File f = new File(sketchPath
   (getFileName(playIndex)));
    if (f.exists()) {
      // Знайшли – гра����мо
      try {
        player = new MediaPlayer();
        player.setDataSource(f.getAbsolutePath());
        player.prepare();
        // Встановлюємо слухач завершення
        player.setOnCompletionListener
  (new MediaPlayer.OnCompletionListener() {
     public void onCompletion(MediaPlayer mp) {
   // Поточний трек завершено – сигналізуємо про наступний
            playNextPending = true;
          }
        });
        player.start();
        playNextPending = false; 
    // чекаємо завершення
        println("Граємо трек " + playIndex);
        playIndex++;  // готуємо наступний індекс
        return;
      } catch (IOException e) {
        e.printStackTrace();
      }
    }
    playIndex++;
  }
  // ��к��о дійшли до кінця – всі треки зіграно
  finishPlayAll();
}

void finishPlayAll() {
  if (player != null) {
    player.release();
    player = null;
  }
  state = IDLE;
  playIndex = 0;
  println("Всі треки зіграно.");
}

// Звільнення ресурсів при закритті
void onDestroy() {
  if (recorder != null) recorder.release();
  if (player != null) player.release();
}////WIRK/////WORK///////



/*



// Android media APIs – без Processing Sound
import android.media.MediaRecorder;
import android.media.MediaPlayer;
import java.io.File;
import java.io.IOException;

final int COLS = 9;
final int ROWS = 14;
final int TOTAL = COLS * ROWS;

// Стани
final int IDLE = 0;
final int RECORDING = 1;
final int PLAYING_ALL = 2;
int state = IDLE;

// Запис
MediaRecorder recorder;
int recordingKey = -1;
long recordStart;

// Відтворення
MediaPlayer player;
int playIndex = 0;    // який трек зараз грає
boolean playNextPending = false;

// ��айли зберігаються у внутрішній пам'яті (sketchPath)
String getFileName(int idx) {
  return "key_" + idx + ".3gp";
}

void setup() {
  size(900, 700);   // зручний розмір для 9×14
  // Дозвіл на мікрофон – має бути доданий у вкладці Android
}

void draw() {
  background(200);
  
  float cellW = width / (float) COLS;
  float cellH = height / (float) ROWS;
  
  // Малюємо сітку
  for (int i = 0; i < TOTAL; i++) {
    int col = i % COLS;
    int row = i / COLS;
    float x = col * cellW;
    float y = row * cellH;
    
    // Колір: перша кнопка особлива
    if (i == 0) {
      fill(200, 100, 100);
    } else {
      // Чи існує файл?
      File f = new File(sketchPath(getFileName(i)));
      if (f.exists()) fill(100, 200, 100);
      else fill(150);
    }
    rect(x, y, cellW, cellH);
    
    // Номер
    fill(0);
    textAlign(CENTER, CENTER);
    textSize(12);
    text(i, x + cellW/2, y + cellH/2);
  }
  
  // Статус
  fill(0);
  textAlign(LEFT, TOP);
  textSize(16);
  if (state == RECORDING) {
    int elapsed = (int)((millis() - recordStart) / 1000);
    text("Запис кнопки " + recordingKey + " ... " + elapsed + "/10с", 10, 10);
  } else if (state == PLAYING_ALL) {
    text("Граємо всі треки... (" + playIndex + "/" + TOTAL + ")", 10, 10);
  } else {
    text("Торкніться кнопки (1–125) для запису 10с, або кнопки 0 для відтворення всіх", 10, 10);
  }
  
  // Якщо йде запис – перевіряємо таймаут
  if (state == RECORDING && (millis() - recordStart >= 10000)) {
    finishRecording();
  }
  
  // Якщо граємо всі – перевіряємо завершення поточного треку
  if (state == PLAYING_ALL && playNextPending) {
    if (player != null && !player.isPlaying()) {
      // Поточний тр��к скінчився – зап��скаємо наступний
      playNextPending = false;
      playNext();
    }
  }
}

// Визначаємо, яку кнопку натиснули
int getKeyAt(float mx, float my) {
  float cellW = width / (float) COLS;
  float cellH = height / (float) ROWS;
  int col = (int)(mx / cellW);
  int row = (int)(my / cellH);
  if (col < 0 || col >= COLS || row < 0 || row >= ROWS) return -1;
  return row * COLS + col;
}

void mousePressed() {
  if (state == RECORDING) return;   // зайнято записом
  
  int key = getKeyAt(mouseX, mouseY);
  if (key < 0 || key >= TOTAL) return;
  
  if (key == 0) {
    // Перша кнопка – граємо всі
    if (state == PLAYING_ALL) return;  // вже граємо
    startPlayAll();
  } else {
    // Інша кнопка – запис
    startRecording(key);
  }
}

// ----- ЗАПИС -----
void startRecording(int key) {
  // Видалити старий файл, якщо є
  File f = new File(sketchPath(getFileName(key)));
  if (f.exists()) f.delete();
  
  try {
    recorder = new MediaRecorder();
    recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
    recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
    recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
    recorder.setOutputFile(sketchPath(getFileName(key)));
    recorder.prepare();
    recorder.start();
    
    state = RECORDING;
    recordingKey = key;
    recordStart = millis();
  } catch (SecurityException e) {
    println("⚠️ Немає дозволу на мікрофон – додайте його у вкладці Android!");
  } catch (Exception e) {
    e.printStackTrace();
  }
}

void finishRecording() {
  if (recorder != null) {
    recorder.stop();
    recorder.release();
    recorder = null;
  }
  state = IDLE;
  recordingKey = -1;
  println("Запис кнопки " + recordingKey + " завершено.");
}

// ----- ВІДТВОРЕННЯ ВСІХ -----
void startPlayAll() {
  if (state == PLAYING_ALL) return;
  state = PLAYING_ALL;
  playIndex = 1;  // починаємо з першої кнопки (index=1)
  playNext();     // запускаємо перший існуючий трек
}

void playNext() {
  // Шукаємо наступний існуючий файл, починаючи з поточного playIndex
  while (playIndex < TOTAL) {
    File f = new File(sketchPath(getFileName(playIndex)));
    if (f.exists()) {
      // Знайшли – граємо
      try {
        player = new MediaPlayer();
        player.setDataSource(f.getAbsolutePath());
        player.prepare();
        // Встановлюємо слухач завершення
        player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
          public void onCompletion(MediaPlayer mp) {
            // Поточний трек завершено – сигналізуємо про наступний
            playNextPending = true;
          }
        });
        player.start();
        playNextPending = false;  // чек��ємо завершення
        println("Граємо трек " + playIndex);
        playIndex++;  // готуємо наступний індекс
        return;
      } catch (IOException e) {
        e.printStackTrace();
      }
    }
    playIndex++;
  }
  // Якщо дійшли до кінця – всі треки зіграно
  finishPlayAll();
}

void finishPlayAll() {
  if (player != null) {
    player.release();
    player = null;
  }
  state = IDLE;
  playIndex = 0;
  println("Всі треки зіграно.");
}

// Звільнення ресурсів при закритті
void onDestroy() {
  if (recorder != null) recorder.release();
  if (player != null) player.release();
}





// Android media APIs – без Processing Sound
import android.media.MediaRecorder;
import android.media.MediaPlayer;
import java.io.File;
import java.io.IOException;

final int COLS = 9;
final int ROWS = 14;
final int TOTAL = COLS * ROWS;

// Стани
final int IDLE = 0;
final int RECORDING = 1;
final int PLAYING_ALL = 2;
int state = IDLE;

// Запис
MediaRecorder recorder;
int recordingKey = -1;
long recordStart;

// Відтворення
MediaPlayer player;
int playIndex = 0;    // який трек зараз грає
boolean playNextPending = false;

// Файли зберігаються у внутрішній пам'яті (sketchPath)
String getFileName(int idx) {
  return "key_" + idx + ".3gp";
}

void setup() {
  size(900, 700);   // зручний розмір для 9×14
  // Дозвіл на мікрофон – має бути доданий у вкладці Android
}

void draw() {
  background(200);
  
  float cellW = width / (float) COLS;
  float cellH = height / (float) ROWS;
  
  // Малюємо сітку
  for (int i = 0; i < TOTAL; i++) {
    int col = i % COLS;
    int row = i / COLS;
    float x = col * cellW;
    float y = row * cellH;
    
    // Колір: перша кнопка особлива
    if (i == 0) {
      fill(200, 100, 100);
    } else {
      // ��и існує файл?
      File f = new File(sketchPath(getFileName(i)));
      if (f.exists()) fill(100, 200, 100);
      else fill(150);
    }
    rect(x, y, cellW, cellH);
    
    // Номер
    fill(0);
    textAlign(CENTER, CENTER);
    textSize(12);
    text(i, x + cellW/2, y + cellH/2);
  }
  
  // Статус
  fill(0);
  textAlign(LEFT, TOP);
  textSize(16);
  if (state == RECORDING) {
    int elapsed = (int)((millis() - recordStart) / 1000);
    text("Запис кнопки " + recordingKey + " ... " + elapsed + "/10с", 10, 10);
  } else if (state == PLAYING_ALL) {
    text("Граємо всі треки... (" + playIndex + "/" + TOTAL + ")", 10, 10);
  } else {
    text("Торкніться кнопки (1–125) для запису 10с, або кнопки 0 для відтворення всіх", 10, 10);
  }
  
  // Якщо йде запис – перевіряємо таймаут
  if (state == RECORDING && (millis() - recordStart >= 10000)) {
    finishRecording();
  }
  
  // Якщо граємо всі – перевіряємо завершення поточног������ треку
  if (state == PLAYING_ALL && playNextPending) {
    if (player != null && !player.isPlaying()) {
      // Поточний трек скінчився – запускаємо наступний
      playNextPending = false;
      playNext();
    }
  }
}

// Визначаємо, яку кнопку натиснули
int getKeyAt(float mx, float my) {
  float cellW = width / (float) COLS;
  float cellH = height / (float) ROWS;
  int col = (int)(mx / cellW);
  int row = (int)(my / cellH);
  if (col < 0 || col >= COLS || row < 0 || row >= ROWS) return -1;
  return row * COLS + col;
}

void mousePressed() {
  if (state == RECORDING) return;   // зайнято записом
  
  int key = getKeyAt(mouseX, mouseY);
  if (key < 0 || key >= TOTAL) return;
  
  if (key == 0) {
    // Перша кнопка – граємо всі
    if (state == PLAYING_ALL) return;  // вже граємо
    startPlayAll();
  } else {
    // Інша кнопка – запис
    startRecording(key);
  }
}

// ----- ЗАПИС -----
void startRecording(int key) {
  // Видалити старий файл, якщо є
  File f = new File(sketchPath(getFileName(key)));
  if (f.exists()) f.delete();
  
  try {
    recorder = new MediaRecorder();
    recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
    recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
    recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
    recorder.setOutputFile(sketchPath(getFileName(key)));
    recorder.prepare();
    recorder.start();
    
    state = RECORDING;
    recordingKey = key;
    recordStart = millis();
  } catch (SecurityException e) {
    println("⚠️ Немає дозволу на мікрофон – додайте його у вкладці Android!");
  } catch (Exception e) {
    e.printStackTrace();
  }
}

void finishRecording() {
  if (recorder != null) {
    recorder.stop();
    recorder.release();
    recorder = null;
  }
  state = IDLE;
  recordingKey = -1;
  println("Запис кн��п��и " + recordingKey + " завершено.");
}

// ----- ВІДТВОРЕННЯ ВСІХ -----
void startPlayAll() {
  if (state == PLAYING_ALL) return;
  state = PLAYING_ALL;
  playIndex = 1;  // починаємо з першої кнопки (index=1)
  playNext();     // запускаємо перший існуючий трек
}

void playNext() {
  // Шукаємо наступний існуючий файл, починаючи з поточного playIndex
  while (playIndex < TOTAL) {
    File f = new File(sketchPath(getFileName(playIndex)));
    if (f.exists()) {
      // Знайшли – граємо
      try {
        player = new MediaPlayer();
        player.setDataSource(f.getAbsolutePath());
        player.prepare();
        // Встановлюємо слухач завершення
        player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
          public void onCompletion(MediaPlayer mp) {
            // Поточний трек завершено – с��гналізуємо про наступний
            playNextPending = true;
          }
        });
        player.start();
        playNextPending = false;  // чекаємо завершення
        println("Граємо трек " + playIndex);
        playIndex++;  // готуємо наступний індекс
        return;
      } catch (IOException e) {
        e.printStackTrace();
      }
    }
    playIndex++;
  }
  // Якщо дійшли до кінця – всі треки зіграно
  finishPlayAll();
}

void finishPlayAll() {
  if (player != null) {
    player.release();
    player = null;
  }
  state = IDLE;
  playIndex = 0;
  println("Всі треки зіграно.");
}

// Звільнення ресурсів при закритті
void onDestroy() {
  if (recorder != null) recorder.release();
  if (player != null) player.release();
}




// Android media APIs – без Processing Sound
import android.media.MediaRecorder;
import android.media.MediaPlayer;
import java.io.File;
import java.io.IOException;

final int COLS = 9;
final int ROWS = 14;
final int TOTAL = COLS * ROWS;

// Стани
final int IDLE = 0;
final int RECORDING = 1;
final int PLAYING_ALL = 2;
int state = IDLE;

// Запис
MediaRecorder recorder;
int recordingKey = -1;
long recordStart;

// Відтворення
MediaPlayer player;
int playIndex = 0;    // який трек зараз грає
boolean playNextPending = false;

// Файли зберігаються у внутрішній пам'яті (sketchPath)
String getFileName(int idx) {
  return "key_" + idx + ".3gp";
}

void setup() {
  size(900, 700);   // зручний розмір для 9×14
  // Дозвіл на мікрофон – має бути доданий у вкладці Android
}

void draw() {
  background(200);
  
  float cellW = width / (float) COLS;
  float cellH = height / (float) ROWS;
  
  // Малюємо сітку
  for (int i = 0; i < TOTAL; i++) {
    int col = i % COLS;
    int row = i / COLS;
    float x = col * cellW;
    float y = row * cellH;
    
    // Колір: перша кнопка особлива
    if (i == 0) {
      fill(200, 100, 100);
    } else {
      // Чи існує файл?
      File f = new File(sketchPath(getFileName(i)));
      if (f.exists()) fill(100, 200, 100);
      else fill(150);
    }
    rect(x, y, cellW, cellH);
    
    // Номер
    fill(0);
    textAlign(CENTER, CENTER);
    textSize(12);
    text(i, x + cellW/2, y + cellH/2);
  }
  
  // Статус
  fill(0);
  textAlign(LEFT, TOP);
  textSize(16);
  if (state == RECORDING) {
    int elapsed = (int)((millis() - recordStart) / 1000);
    text("Запис кнопки " + recordingKey + " ... " + elapsed + "/10с", 10, 10);
  } else if (state == PLAYING_ALL) {
    text("Граємо всі треки... (" + playIndex + "/" + TOTAL + ")", 10, 10);
  } else {
    text("Торкніться ��нопки (1–125) для запису 10с, або кнопки 0 для відтворення всіх", 10, 10);
  }
  
  // Якщо йде запис – перевіряємо таймаут
  if (state == RECORDING && (millis() - recordStart >= 10000)) {
    finishRecording();
  }
  
  // Якщо граємо всі – перевіряємо завершення поточного треку
  if (state == PLAYING_ALL && playNextPending) {
    if (player != null && !player.isPlaying()) {
      // Поточний трек скінчився – запускаємо наступний
      playNextPending = false;
      playNext();
    }
  }
}

// Визначаємо, яку кнопку натиснули
int getKeyAt(float mx, float my) {
  float cellW = width / (float) COLS;
  float cellH = height / (float) ROWS;
  int col = (int)(mx / cellW);
  int row = (int)(my / cellH);
  if (col < 0 || col >= COLS || row < 0 || row >= ROWS) return -1;
  return row * COLS + col;
}

void mousePressed() {
  if (state == RECORDING) return;   // зайнято записом
  
  int key = getKeyAt(mouseX, mouseY);
  if (key < 0 || key >= TOTAL) return;
  
  if (key == 0) {
    // Перша кнопка – граємо всі
    if (state == PLAYING_ALL) return;  // вже граємо
    startPlayAll();
  } else {
    // Інша кнопка – запис
    startRecording(key);
  }
}

// ----- ЗАПИС -----
void startRecording(int key) {
  // Видалити старий файл, якщо є
  File f = new File(sketchPath(getFileName(key)));
  if (f.exists()) f.delete();
  
  try {
    recorder = new MediaRecorder();
    recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
    recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
    recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
    recorder.setOutputFile(sketchPath(getFileName(key)));
    recorder.prepare();
    recorder.start();
    
    state = RECORDING;
    recordingKey = key;
    recordStart = millis();
  } catch (SecurityException e) {
    println("⚠️ Немає дозволу на мікрофон – додайте й��го у в��ладці Android!");
  } catch (Exception e) {
    e.printStackTrace();
  }
}

void finishRecording() {
  if (recorder != null) {
    recorder.stop();
    recorder.release();
    recorder = null;
  }
  state = IDLE;
  recordingKey = -1;
  println("Запис кнопки " + recordingKey + " завершено.");
}

// ----- ВІДТВОРЕННЯ ВСІХ -----
void startPlayAll() {
  if (state == PLAYING_ALL) return;
  state = PLAYING_ALL;
  playIndex = 1;  // починаємо з першої кнопки (index=1)
  playNext();     // запускаємо перший існуючий трек
}

void playNext() {
  // Шукаємо наступний існуючий файл, починаючи з поточного playIndex
  while (playIndex < TOTAL) {
    File f = new File(sketchPath(getFileName(playIndex)));
    if (f.exists()) {
      // Знайшли – гр��ємо
      try {
        player = new MediaPlayer();
        player.setDataSource(f.getAbsolutePath());
        player.prepare();
        // Встановлюємо слухач завершення
        player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
          public void onCompletion(MediaPlayer mp) {
            // Поточний трек завершено – сигналізуємо про наступний
            playNextPending = true;
          }
        });
        player.start();
        playNextPending = false;  // чекаємо завершення
        println("Граємо трек " + playIndex);
        playIndex++;  // готуємо наступний індекс
        return;
      } catch (IOException e) {
        e.printStackTrace();
      }
    }
    playIndex++;
  }
  // Якщо дійшли до кінця – всі треки зіграно
  finishPlayAll();
}

void finishPlayAll() {
  if (player != null) {
    player.release();
    player = null;
  }
  state = IDLE;
  playIndex = 0;
  println("Всі треки зіграно.");
}

// Звільнення рес��рсів при закритті
void onDestroy() {
  if (recorder != null) recorder.release();
  if (player != null) player.release();
}





// Android media APIs – без Processing Sound
import android.media.MediaRecorder;
import android.media.MediaPlayer;
import java.io.File;
import java.io.IOException;

final int COLS = 9;
final int ROWS = 14;
final int TOTAL = COLS * ROWS;

// Стани
final int IDLE = 0;
final int RECORDING = 1;
final int PLAYING_ALL = 2;
int state = IDLE;

// Запис
MediaRecorder recorder;
int recordingKey = -1;
long recordStart;

// Відтворення
MediaPlayer player;
int playIndex = 0;    // який трек зараз грає
boolean playNextPending = false;

// Файли зберігаються у внутрішній пам'яті (sketchPath)
String getFileName(int idx) {
  return "key_" + idx + ".3gp";
}

void setup() {
  size(900, 700);   // зручний розмір для 9×14
  // Дозвіл на мікрофон ��� має бути доданий у вкладці Android
}

void draw() {
  background(200);
  
  float cellW = width / (float) COLS;
  float cellH = height / (float) ROWS;
  
  // Малюємо сітку
  for (int i = 0; i < TOTAL; i++) {
    int col = i % COLS;
    int row = i / COLS;
    float x = col * cellW;
    float y = row * cellH;
    
    // Колір: перша кнопка особлива
    if (i == 0) {
      fill(200, 100, 100);
    } else {
      // Чи існує файл?
      File f = new File(sketchPath(getFileName(i)));
      if (f.exists()) fill(100, 200, 100);
      else fill(150);
    }
    rect(x, y, cellW, cellH);
    
    // Номер
    fill(0);
    textAlign(CENTER, CENTER);
    textSize(12);
    text(i, x + cellW/2, y + cellH/2);
  }
  
  // Статус
  fill(0);
  textAlign(LEFT, TOP);
  textSize(16);
  if (state == RECORDING) {
    int elapsed = (int)((millis() - recordStart) / 1000);
    text("Запис кнопки " + recordingKey + " ... " + elapsed + "/10��", 10, 10);
  } else if (state == PLAYING_ALL) {
    text("Граємо всі треки... (" + playIndex + "/" + TOTAL + ")", 10, 10);
  } else {
    text("Торкніться кнопки (1–125) для запису 10с, або кнопки 0 для відтворення всіх", 10, 10);
  }
  
  // Якщо йде запис – перевіряємо таймаут
  if (state == RECORDING && (millis() - recordStart >= 10000)) {
    finishRecording();
  }
  
  // Якщо граємо всі – перевіряємо завершення поточного треку
  if (state == PLAYING_ALL && playNextPending) {
    if (player != null && !player.isPlaying()) {
      // Поточний трек скінчився – запускаємо наступний
      playNextPending = false;
      playNext();
    }
  }
}

// Виз��ача��мо, яку кнопку натиснули
int getKeyAt(float mx, float my) {
  float cellW = width / (float) COLS;
  float cellH = height / (float) ROWS;
  int col = (int)(mx / cellW);
  int row = (int)(my / cellH);
  if (col < 0 || col >= COLS || row < 0 || row >= ROWS) return -1;
  return row * COLS + col;
}

void mousePressed() {
  if (state == RECORDING) return;   // зайнято записом
  
  int key = getKeyAt(mouseX, mouseY);
  if (key < 0 || key >= TOTAL) return;
  
  if (key == 0) {
    // Перша кнопка – граємо всі
    if (state == PLAYING_ALL) return;  // вже граємо
    startPlayAll();
  } else {
    // Інша кнопка – запис
    startRecording(key);
  }
}

// ----- ЗАПИС -----
void startRecording(int key) {
  // Видалити старий файл, якщо є
  File f = new File(sketchPath(getFileName(key)));
  if (f.exists()) f.delete();
  
  try {
    recorder = new MediaRecorder();
    recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
    recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
    recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
    recorder.setOutputFile(sketchPath(getFileName(key)));
    recorder.prepare();
    recorder.start();
    
    state = RECORDING;
    recordingKey = key;
    recordStart = millis();
  } catch (SecurityException e) {
    println("⚠️ Немає дозволу на мікрофон – додайте його у вкладці Android!");
  } catch (Exception e) {
    e.printStackTrace();
  }
}

void finishRecording() {
  if (recorder != null) {
    recorder.stop();
    recorder.release();
    recorder = null;
  }
  state = IDLE;
  recordingKey = -1;
  println("Запис кнопки " + recordingKey + " завершено.");
}

// ----- ВІДТВОРЕННЯ ВСІХ -----
void startPlayAll() {
  if (state == PLAYING_ALL) return;
  state = PLAYING_ALL;
  playIndex = 1;  // починаємо з першої кнопки (index=1)
  playNext();     // запускаємо перший існуючий тр��к
}

void playNext() {
  // Шукаємо наступний існуючий файл, починаючи з поточн��го playIndex
  while (playIndex < TOTAL) {
    File f = new File(sketchPath(getFileName(playIndex)));
    if (f.exists()) {
      // Знайшли – граємо
      try {
        player = new MediaPlayer();
        player.setDataSource(f.getAbsolutePath());
        player.prepare();
        // Встановлюємо слухач завершення
        player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
          public void onCompletion(MediaPlayer mp) {
            // Поточний трек завершено – сигналізуємо про наступний
            playNextPending = true;
          }
        });
        player.start();
        playNextPending = false;  // чекаємо завершення
        println("Граємо трек " + playIndex);
        playIndex++;  // готуємо наступний індекс
        return;
      } catch (IOException e) {
        e.printStackTrace();
      }
    }
    playIndex++;
  }
  // Якщо д��йшли до кі��ця – всі треки зіграно
  finishPlayAll();
}

void finishPlayAll() {
  if (player != null) {
    player.release();
    player = null;
  }
  state = IDLE;
  playIndex = 0;
  println("Всі треки зіграно.");
}

// Звільнення ресурсів при закритті
void onDestroy() {
  if (recorder != null) recorder.release();
  if (player != null) player.release();
}



*/

















































/*
// ============================================================
//  Повний скетч: 9×14 кнопок, запис та міксування
//  Використовує тільки Android API (без бібліотеки Sound)
// ============================================================

import android.media.MediaRecorder;
import android.media.MediaExtractor;
import android.media.MediaCodec;
import android.media.MediaFormat;
import android.media.AudioTrack;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

// Константи сітки
final int COLS = 9;
final int ROWS = 14;
final int TOTAL = COLS * ROWS;

// Стани
final int IDLE = 0;
final int RECORDING = 1;
final int MIXING_PLAY = 2;
int state = IDLE;

// Запис
MediaRecorder recorder;
int recordingKey = -1;
long recordStart;

// Відтворення міксу
AudioTrack audioTrack;
Thread playThread;

// Імена файлів (зберігаються у внутрішній пам'яті)
String getFileName(int idx) {
  return "key_" + idx + ".3gp";
}

// ---------------------------------------------------------------------
//  Setup
// ---------------------------------------------------------------------
void setup() {
///  size(900, 700);
   size(displayWidth, displayHeight, JAVA2D) ;
  // Дозвіл RECORD_AUDIO має бути доданий у вкладці Android
}

// ---------------------------------------------------------------------
//  Малювання
// ---------------------------------------------------------------------
void draw() {
  background(200, 44,33);
  float cellW = width / (float) COLS;
  float cellH = height / (float) ROWS;
  
  for (int i = 0; i < TOTAL; i++) {
    int col = i % COLS;
    int row = i / COLS;
    float x = col * cellW;
    float y = row * cellH;
    
    // Колір кнопки
    if (i == 0) {
      fill(200, 100, 100);   
// че��вона – перша (мікс)
    } else {
      File f = new File(sketchPath(getFileName(i)));
      if (f.exists()) fill(100, 200, 100);  
// зелена – записано
      else fill(150, 111,122);                    
  // сіра – порожня
    }
    rect(x, y, cellW, cellH);
    fill(0);
    textAlign(CENTER, CENTER);
    textSize(12);
    text(i, x + cellW/2, y + cellH/2);
  }
  
  // Статусний рядок
  fill(0);
  textAlign(LEFT, TOP);
  textSize(16+15+2);
  if (state == RECORDING) {
    int elapsed = (int)((millis()
   - recordStart) / 1000);
    text("Запис кнопки " + recordingKey
  + " ... " + elapsed + "/10 с", 10, 10);
  } else if (state == MIXING_PLAY) {
    text("Граємо мікс всіх треків...", 10, 10);
   rect(width*2/3,0,width*2/3,height);
  } else {
    text
("Торкніться кнопки (1–125) для запису, або кнопки 0 для міксу", 10, 10);
  }
  
  // Перевірка зак��нчення запису
  if (state == RECORDING &&
  (millis() - recordStart >= 10000)) {
    finishRecording();
  }
}

// ---------------------------------------------------------------------
//  Обробка дотику
// ---------------------------------------------------------------------
int getKeyAt(float mx, float my) {
  float cellW = width / (float) COLS;
  float cellH = height / (float) ROWS;
  int col = (int)(mx / cellW);
  int row = (int)(my / cellH);
  if (col < 0 || col >= COLS
  || row < 0 || row >= ROWS) return -1;
  return row * COLS + col;
}

void mousePressed() {
  if (state == RECORDING) return;   // зайнято
  int key = getKeyAt(mouseX, mouseY);
  if (key < 0 || key >= TOTAL) return;
  
  if (key == 0) {
    if (state == MIXING_PLAY) return;
    startMixAndPlay();
  } else {
    startRecording(key);
  }
}

// ---------------------------------------------------------------------
//  Запис (MediaRecorder)
// ---------------------------------------------------------------------
void startRecording(int key) {
  // Видалити старий файл
  File f = new File(sketchPath(getFileName(key)));
  if (f.exists()) f.delete();
  
  try {
    recorder = new MediaRecorder();
    recorder.setAudioSource
 (MediaRecorder.AudioSource.MIC);
    recorder.setOutputFormat
 (MediaRecorder.OutputFormat.THREE_GPP);
    recorder.setAudioEncoder
 (MediaRecorder.AudioEncoder.AMR_NB);
    recorder.setOutputFile
 (sketchPath(getFileName(key)));
    recorder.prepare();
    recorder.start();
    
    state = RECORDING;
    recordingKey = key;
    recordStart = millis();
  } catch (SecurityException e) {
    println
("⚠️ Немає дозволу на мікрофон! Додайте його у вкладці Android.");
  } catch (Exception e) {
    e.printStackTrace();
  }
}

void finishRecording() {
  if (recorder != null) {
    recorder.stop();
    recorder.release();
    recorder = null;
  }
  state = IDLE;
  println
 ("Запис кнопки " + recordingKey + " завершено.");
  recordingKey = -1;
}

// ---------------------------------------------------------------------
//  Декодування .3gp у PCM (short[])
// ---------------------------------------------------------------------
short[] decodeToPCM(String filePath) 
   throws IOException {
  MediaExtractor extractor = new MediaExtractor();
  extractor.setDataSource(filePath);
  
  int trackIndex = -1;
  MediaFormat format = null;
  for (int i = 0; 
  i < extractor.getTrackCount(); i++) {
    format = extractor.getTrackFormat(i);
    String mime = format.getString
   (MediaFormat.KEY_MIME);
    if (mime.startsWith("audio/")) {
      trackIndex = i;
      break;
    }
  }
  if (trackIndex == -1) throw new 
  IOException("No audio track");
  
  extractor.selectTrack(trackIndex);
  MediaCodec codec
  = MediaCodec.createDecoderByType
  (format.getString(MediaFormat.KEY_MIME));
  codec.configure(format, null, null, 0);
  codec.start();
  
  java.util.ArrayList<Short> pcmList
  = new java.util.ArrayList<Short>();
  ByteBuffer[] inputBuffers
   = codec.getInputBuffers();
  ByteBuffer[] outputBuffers 
   = codec.getOutputBuffers();
  MediaCodec.BufferInfo info 
  = new MediaCodec.BufferInfo();
  boolean eos = false;
  
  while (!eos) {
    if (!eos) {
      int inIndex = codec.dequeueInputBuffer(10000);
      if (inIndex >= 0) {
        ByteBuffer buffer = inputBuffers[inIndex];
        int sampleSize = 
  extractor.readSampleData(buffer, 0);
        if (sampleSize < 0) {
          codec.queueInputBuffer
 (inIndex, 0, 0, 0, 
 MediaCodec.BUFFER_FLAG_END_OF_STREAM);
          eos = true;
        } else {
          long presentationTime
     = extractor.getSampleTime();
          codec.queueInputBuffer(inIndex, 0, sampleSize, presentationTime, 0);
          extractor.advance();
        }
      }
    }
    
    int outIndex = codec.dequeueOutputBuffer
   (info, 10000);
    if (outIndex >= 0) {
   ByteBuffer outBuffer = outputBuffers[outIndex];
      if 
((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) 
     != 0) {
        codec.releaseOutputBuffer(outIndex, false);
        continue;
      }
      if (info.size > 0) {
        outBuffer.position(info.offset);
        outBuffer.limit(info.offset + info.size);
        byte[] bytes = new byte[info.size];
        outBuffer.get(bytes);
      for (int i = 0; i < bytes.length / 2; i++) {
          short s = (short)
   ((bytes[i*2+1] << 8) | (bytes[i*2] & 0xFF));
          pcmList.add(s);
        }
      }
      codec.releaseOutputBuffer(outIndex, false);
      if ((info.flags & 
  MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break;
    }
  }
  
  codec.stop();
  codec.release();
  extractor.release();
  
  short[] pcm = new short[pcmList.size()];
  for (int i = 0; i < pcmList.size(); i++)
    pcm[i] = pcmList.get(i);
  return pcm;
}

// ---------------------------------------------------------------------
//  Міксування та програвання
// ---------------------------------------------------------------------
void startMixAndPlay() {
  // Збираємо всі існу��чі файли
  java.util.ArrayList<short[]> tracks
   = new java.util.ArrayList<short[]>();
  for (int i = 1; i < TOTAL; i++) {
    File f = new File(sketchPath(getFileName(i)));
    if (f.exists()) {
      try {
        short[] pcm = 
   decodeToPCM(f.getAbsolutePath());
        tracks.add(pcm);
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
  }
  
  if (tracks.size() == 0) {
    println("Немає записаних треків.");
    return;
  }
  
  // Визначаємо максимальну довжину (усі треки мають бути ~10 с при 8 кГц)
  int maxLen = 0;
  for (short[] t : tracks) if (t.length > maxLen)
   maxLen = t.length;
  
  // Сумуємо у float
  float[] mix = new float[maxLen];
  for (short[] t : tracks) {
  for (int i = 0; i < t.length && i < maxLen; i++){
      mix[i] += (float)t[i] / 32768.0f;
    }
  }
  
  // Нормалізація до 0.9 піку
  float peak = 0;
  for (float v : mix) if (Math.abs(v) > peak)
    peak = Math.abs(v);
  if (peak > 0.001) {
    float scale = 0.9f / peak;
    for (int i = 0; i < mix.length; i++) 
    mix[i] *= scale;
  }
  
  // Перетворен��я на short (PCM 16-bit)
  final short[] out = new short[mix.length];
  for (int i = 0; i < mix.length; i++) {
    out[i] = (short)(mix[i] * 32767);
  }
  
  // Параметри аудіо (AMR-NB -> 8 кГц, моно, 16-bit)
  int sampleRate = 8000;
  int channelConfig = AudioFormat.CHANNEL_OUT_MONO;
  int audioFormat = AudioFormat.ENCODING_PCM_16BIT;
  int bufferSize = out.length * 2;
  
  AudioAttributes attrs = 
  new AudioAttributes.Builder()
    .setUsage(AudioAttributes.USAGE_MEDIA)
    .setContentType
   (AudioAttributes.CONTENT_TYPE_MUSIC)
    .build();
  AudioFormat fmt = new AudioFormat.Builder()
    .setSampleRate(sampleRate)
    .setChannelMask(channelConfig)
    .setEncoding(audioFormat)
    .build();
  
  audioTrack = new AudioTrack
 (attrs, fmt, bufferSize, AudioTrack.MODE_STATIC, 0);
  if (audioTrack.getState() != 
   AudioTrack.STATE_INITIALIZED) {
    println("Помилка ініціалізації AudioTrack");
    return;
  }
  
  // Записуємо дані
  byte[] bytes = new byte[out.length * 2];
  ByteBuffer bb = ByteBuffer.wrap
   (bytes).order(ByteOrder.LITTLE_ENDIAN);
  for (short s : out) bb.putShort(s);
  int written = audioTrack.write(bytes, 
    0, bytes.length);
  if (written < bytes.length) {
    println("Не вдалося записати всі дані");
    audioTrack.release();
    audioTrack = null;
    return;
  }
  
  // Запускаємо відтворення у потоці
  if (playThread != null && playThread.isAlive()) {
    playThread.interrupt();
    try { playThread.join(100); } 
    catch (Exception e) {}
  }
  playThread = new Thread(new Runnable() {
    public void run() {
      audioTrack.play();
      state = MIXING_PLAY;
      // Чекаємо завершення
      while (audioTrack.getPlayState()
   == AudioTrack.PLAYSTATE_PLAYING) {
        try { Thread.sleep(50); } catch 
    (InterruptedException e) { break; }
      }
      audioTrack.stop();
      audioTrack.release();
      audioTrack = null;
      state = IDLE;
      println("Мікс завершено.");
    }
  });
  playThread.start();
}

// ---------------------------------------------------------------------
//  Звільнення ресурсі�� при з��критті
// ---------------------------------------------------------------------
void onDestroy() {
  if (recorder != null) recorder.release();
  if (audioTrack != null) audioTrack.release();
  if (playThread != null && playThread.isAlive()) {
    playThread.interrupt();
    try { playThread.join(200); } catch 
   (Exception e) {}
  }
}



*/


























/*

// Android media APIs – без Sound
import android.media.MediaRecorder;
import android.media.MediaExtractor;
import android.media.MediaCodec;
import android.media.MediaFormat;
import android.media.AudioTrack;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

final int COLS = 9;
final int ROWS = 14;
final int TOTAL = COLS * ROWS;

// Стани
final int IDLE = 0;
final int RECORDING = 1;
final int MIXING_PLAY = 2;
int state = IDLE;

// Запис
MediaRecorder recorder;
int recordingKey = -1;
long recordStart;

// Відтворення міксу
AudioTrack audioTrack;
Thread playThread;

// Файли
String getFileName(int idx) {
  return "key_" + idx + ".3gp";
}

void setup() {


 //// size(900, 700);

       size(displayWidth, displayHeight, JAVA2D) ;
  // Дозвіл на мікрофон – додати у вкладці Android
}

void draw() {
  background(200, 44,33);
  float cellW = width / (float) COLS;
  float cellH = height / (float) ROWS;
  
  for (int i = 0; i < TOTAL; i++) {
    int col = i % COLS;
    int row = i / COLS;
    float x = col * cellW;
    float y = row * cellH;
    
    if (i == 0) {
      fill(200, 100, 100);
    } else {
      File f = new File(sketchPath(getFileName(i)));
      if (f.exists()) fill(100, 200, 100);
      else fill(150);
    }
    rect(x, y, cellW, cellH);
    fill(0);
    textAlign(CENTER, CENTER);
    textSize(12);
    text(i, x + cellW/2, y + cellH/2);
  }
  
  fill(0);
  textAlign(LEFT, TOP);
  textSize(16);
  if (state == RECORDING) {
    int elapsed = (int)((millis() - recordStart) / 1000);
    text("Запис кнопки " + recordingKey + " ... " + elapsed + "/10с", 10, 10);
  } else if (state == MIXING_PLAY) {
    text("Граємо мікс всіх треків...", 10, 10);
  } else {
    text("Торкніться кнопки (1–125) для запису 10с, або кнопки 0 для міксу та програвання", 10, 10);
  }
  
  if (state == RECORDING && (millis() - recordStart >= 10000)) {
    finishRecording();
  }
}

int getKeyAt(float mx, float my) {
  float cellW = width / (float) COLS;
  float cellH = height / (float) ROWS;
  int col = (int)(mx / cellW);
  int row = (int)(my / cellH);
  if (col < 0 || col >= COLS || row < 0 || row >= ROWS) return -1;
  return row * COLS + col;
}

void mousePressed() {
  if (state == RECORDING) return;
  int key = getKeyAt(mouseX, mouseY);
  if (key < 0 || key >= TOTAL) return;
  
  if (key == 0) {
    // Перша кнопка – мікс і програвання
    if (state == MIXING_PLAY) return;
    startMixAndPlay();
  } else {
    startRecording(key);
  }
}

// ----- ЗАПИС (без змін) -----
void startRecording(int key) {
  File f = new File(sketchPath(getFileName(key)));
  if (f.exists()) f.delete();
  try {
    recorder = new MediaRecorder();
    recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
    recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
    recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
    recorder.setOutputFile(sketchPath(getFileName(key)));
    recorder.prepare();
    recorder.start();
    state = RECORDING;
    recordingKey = key;
    recordStart = millis();
  } catch (SecurityException e) {
    println("⚠️ Немає дозволу на мікрофон!");
  } catch (Exception e) {
    e.printStackTrace();
  }
}

void finishRecording() {
  if (recorder != null) {
    recorder.stop();
    recorder.release();
    recorder = null;
  }
  state = IDLE;
  recordingKey = -1;
  println("Запис кнопки " + recordingKey + " завершено.");
}

// ----- Декодування .3gp у PCM (short[]) -----
short[] decodeToPCM(String filePath) throws IOException {
  MediaExtractor extractor = new MediaExtractor();
  extractor.setDataSource(filePath);
  
  // Шукаємо аудіотрек
  int trackIndex = -1;
  MediaFormat format = null;
  for (int i = 0; i < extractor.getTrackCount(); i++) {
    format = extractor.getTrackFormat(i);
    String mime = format.getString(MediaFormat.KEY_MIME);
    if (mime.startsWith("audio/")) {
      trackIndex = i;
      break;
    }
  }
  if (trackIndex == -1) throw new IOException("No audio track");
  
  extractor.selectTrack(trackIndex);
  MediaCodec codec = MediaCodec.createDecoderByType(format.getString(MediaFormat.KEY_MIME));
  codec.configure(format, null, null, 0);
  codec.start();
  
  // Буфер для PCM (вихід��і дані)
  java.util.ArrayList<Short> pcmList = new java.util.ArrayList<Short>();
  ByteBuffer[] inputBuffers = codec.getInputBuffers();
  ByteBuffer[] outputBuffers = codec.getOutputBuffers();
  MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
  
  boolean eos = false;
  long startTimeNs = System.nanoTime();
  
  while (!eos) {
    if (!eos) {
      int inIndex = codec.dequeueInputBuffer(10000);
      if (inIndex >= 0) {
        ByteBuffer buffer = inputBuffers[inIndex];
        int sampleSize = extractor.readSampleData(buffer, 0);
        if (sampleSize < 0) {
          codec.queueInputBuffer(inIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
          eos = true;
        } else {
          long presentationTime = extractor.getSampleTime();
          codec.queueInputBuffer(inIndex, 0, sampleSize, presentationTime, 0);
          extractor.advance();
        }
      }
    }
    
    int outIndex = codec.dequeueOutputBuffer(info, 10000);
    if (outIndex >= 0) {
      ByteBuffer outBuffer = outputBuffers[outIndex];
      if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
        codec.releaseOutputBuffer(outIndex, false);
        continue;
      }
      if (info.size > 0) {
        outBuffer.position(info.offset);
        outBuffer.limit(info.offset + info.size);
        // Перетворюємо байти на short (PCM 16-bit little-endian)
        byte[] bytes = new byte[info.size];
        outBuffer.get(bytes);
        for (int i = 0; i < bytes.length / 2; i++) {
          short s = (short)((bytes[i*2+1] << 8) | (bytes[i*2] & 0xFF));
          pcmList.add(s);
        }
      }
      codec.releaseOutputBuffer(outIndex, false);
      if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
        break;
      }
    }
  }
  
  codec.stop();
  codec.release();
  extractor.release();
  
  // Перетворюємо ArrayList у short[]
  short[] pcm = new short[pcmList.size()];
  for (int i = 0; i < pcmList.size(); i++) pcm[i] = pcmList.get(i);
  return pcm;
}

// ----- МІКС ТА ПРОГРАВАННЯ -----
void startMixAndPlay() {
  // Збираємо всі існуючі файли
  java.util.ArrayList<short[]> tracks = new java.util.ArrayList<short[]>();
  for (int i = 1; i < TOTAL; i++) {
    File f = new File(sketchPath(getFileName(i)));
    if (f.exists()) {
      try {
        short[] pcm = decodeToPCM(f.getAbsolutePath());
        tracks.add(pcm);
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
  }
  
  if (tracks.size() == 0) {
    println("Немає записаних треків.");
    return;
  }
  
  // Визначаємо довжину міксу (максимальна довжина – 10 с @ 8 кГц ≈ 80000 семплів)
  int maxLen = 0;
  for (short[] t : tracks) if (t.length > maxLen) maxLen = t.length;
  
  // Міксуємо (сумуємо) у float
  float[] mix = new float[maxLen];
  for (short[] t : tracks) {
    for (int i = 0; i < t.length && i < maxLen; i++) {
      mix[i] += (float)t[i] / 32768.0f;   // нормалізуємо в [-1..1]
    }
  }
  
  // Норм��лізуємо до 0.9 піку
  float peak = 0;
  for (float v : mix) if (Math.abs(v) > peak) peak = Math.abs(v);
  if (peak > 0.001) {
    float scale = 0.9f / peak;
    for (int i = 0; i < mix.length; i++) mix[i] *= scale;
  }
  
  // Конвертуємо назад у short (16-bit PCM)
  short[] out = new short[mix.length];
  for (int i = 0; i < mix.length; i++) {
    out[i] = (short)(mix[i] * 32767);
  }
  
  // Запускаємо AudioTrack
  int sampleRate = 8000;   // AMR-NB завжди 8 кГц
  int channelConfig = AudioFormat.CHANNEL_OUT_MONO;
  int audioFormat = AudioFormat.ENCODING_PCM_16BIT;
  int bufferSize = AudioTrack.getMinBufferSize(sampleRate, channelConfig, audioFormat);
  if (bufferSize < out.length * 2) bufferSize = out.length * 2;
  
  AudioAttributes attrs = new AudioAttributes.Builder()
    .setUsage(AudioAttributes.USAGE_MEDIA)
    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
    .build();
  AudioFormat format = new AudioFormat.Builder()
    .setSampleRate(sampleRate)
    .setChannelMask(channelConfig)
    .setEncoding(audioFormat)
    .build();
  
  audioTrack = new AudioTrack(attrs, format, bufferSize, AudioTrack.MODE_STREAM, 0);
  audioTrack.play();
  
  // Відтворюємо у потоці, щоб не блокувати UI
  if (playThread != null && playThread.isAlive()) {
    playThread.interrupt();
  }
  playThread = new Thread(new Runnable() {
    public void run() {
      int written = 0;
      while (written < out.length) {
        int chunk = Math.min(out.length - written, 2048);
        short[] buffer = new short[chunk];
        System.arraycopy(out, written, buffer, 0, chunk);
        // Конвертуємо short[] у byte[] для запису
        byte[] bytes = new byte[chunk * 2];
        ByteBuffer bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
        for (short s : buffer) bb.putShort(s);
        audioTrack.write(bytes, 0, bytes.length);
        written += chunk;
      }
      // Чекаємо завершення відтв��рення, потім зупиняємо
      try {
        Thread.sleep(100);
      } catch (Exception e) {}
      audioTrack.stop();
      audioTrack.release();
      audioTrack = null;
      state = IDLE;
      println("Мікс завершено.");
    }
  });
  playThread.start();
  state = MIXING_PLAY;
}

// ----- Звільнення ресурсів -----
void onDestroy() {
  if (recorder != null) recorder.release();
  if (audioTrack != null) audioTrack.release();
  if (playThread != null && playThread.isAlive()) playThread.interrupt();
}




*/












