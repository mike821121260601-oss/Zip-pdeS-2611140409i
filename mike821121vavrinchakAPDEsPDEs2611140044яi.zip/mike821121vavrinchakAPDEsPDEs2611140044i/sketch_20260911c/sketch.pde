


// ANGry BIRDS / LINES
// APDE 0.5.3
// One file
// Touch only - NO keyboard

final int MAX_LINES = 999;

float[][] lines = new float[MAX_LINES][4];

// line: x1,y1,x2,y2
int lineCount = 0;

float birdX, birdY;
float birdVX = 0;
float birdVY = 0;

float birdSize = 34;

boolean birdFlying = false;
boolean birdAttached = false;

int selectedLine = -1;

float gravity = 0.0001f;
float flyPower = 0.0f;

long lastTime;

// --------------------------------------------------

void setup() {
  orientation(PORTRAIT);
  size(displayWidth, displayHeight, P2D);

  rectMode(CENTER);
  strokeCap(ROUND);

  makeLines();

  birdX = width * 0.15f;
  birdY = height * 0.75f;

  lastTime = millis();
}

// --------------------------------------------------

void draw() {

  background(245, 245, 240);

  float dt = millis() - lastTime;
  lastTime = millis();

  if (dt > 40) dt = 40;

  drawLines();

  if (birdFlying) {
    updateBird(dt);
  }

  drawBird();

  // small information
  fill(40);
  textSize(20);
  text("LINES: " + lineCount, 20, 30);

  if (selectedLine >= 0) {
    text("LINE " + selectedLine, 20, 55);
  }

  if (!birdFlying) {
    fill(30);
    text("TOUCH A LINE", 20, height - 30);
  }
}

// --------------------------------------------------
// CREATE MANY LINES
// --------------------------------------------------

void makeLines() {

  // Real visible game lines
  addLine(width*0.08f, height*0.82f,
          width*0.35f, height*0.72f);

  addLine(width*0.35f, height*0.72f,
          width*0.58f, height*0.63f);

  addLine(width*0.58f, height*0.63f,
          width*0.83f, height*0.70f);

  addLine(width*0.15f, height*0.55f,
          width*0.38f, height*0.48f);

  addLine(width*0.38f, height*0.48f,
          width*0.62f, height*0.53f);

  addLine(width*0.62f, height*0.53f,
          width*0.88f, height*0.40f);

  addLine(width*0.12f, height*0.35f,
          width*0.30f, height*0.28f);

  addLine(width*0.30f, height*0.28f,
          width*0.53f, height*0.34f);

  addLine(width*0.53f, height*0.34f,
          width*0.80f, height*0.25f);

  // Additional lines
  addLine(width*0.70f, height*0.82f,
          width*0.92f, height*0.75f);

  addLine(width*0.05f, height*0.65f,
          width*0.20f, height*0.60f);

  addLine(width*0.75f, height*0.55f,
          width*0.95f, height*0.50f);
}

// --------------------------------------------------

void addLine(float x1, float y1, float x2, float y2) {

  if (lineCount >= MAX_LINES) return;

  lines[lineCount][0] = x1;
  lines[lineCount][1] = y1;
  lines[lineCount][2] = x2;
  lines[lineCount][3] = y2;

  lineCount++;
}

// --------------------------------------------------

void drawLines() {

  strokeWeight(7);

  for (int i = 0; i < lineCount; i++) {

    if (i == selectedLine) {
      stroke(255, 80, 40);
      strokeWeight(11);
    } else {
      stroke(60, 80, 90);
      strokeWeight(7);
    }

    line(
      lines[i][0],
      lines[i][1],
      lines[i][2],
      lines[i][3]
    );
  }

  strokeWeight(1);
}

// --------------------------------------------------
// BIRD
// --------------------------------------------------

void drawBird() {

  noStroke();

  // shadow
  fill(0, 40);
  ellipse(birdX + 5, birdY + 7,
          birdSize + 5, birdSize + 5);

  // bird body
  fill(220, 40, 35);
  rect(birdX, birdY,
       birdSize, birdSize,
       8);

  // eye
  fill(255);
  ellipse(birdX - 7, birdY - 7, 10, 10);
  ellipse(birdX + 7, birdY - 7, 10, 10);

  fill(0);
  ellipse(birdX - 7, birdY - 7, 4, 4);
  ellipse(birdX + 7, birdY - 7, 4, 4);

  // beak
  fill(240, 170, 30);

  triangle(
    birdX + birdSize/2,
    birdY - 2,

    birdX + birdSize/2 + 18,
    birdY + 4,

    birdX + birdSize/2,
    birdY + 10
  );
}

// --------------------------------------------------
// BIRD PHYSICS
// --------------------------------------------------

void updateBird(float dt) {

  // Gravity gets larger while flying
  flyPower += gravity * dt;

  birdVY += flyPower * dt;

  birdX += birdVX * dt;
  birdY += birdVY * dt;

  // check every line
  for (int i = 0; i < lineCount; i++) {

    if (hitLine(i)) {

      selectedLine = i;

      // bounce from line
      float dx =
        lines[i][2] - lines[i][0];

      float dy =
        lines[i][3] - lines[i][1];

      float len = sqrt(dx*dx + dy*dy);

      if (len > 0) {

        dx /= len;
        dy /= len;

        // move along the line
        float speed =
          sqrt(birdVX*birdVX +
               birdVY*birdVY);

        if (speed < 1) speed = 1;

        birdVX = dx * speed * 0.72f;
        birdVY = dy * speed * 0.72f;

        // small upward bounce
        birdVY -= 2.0f;
      }

      // gravity becomes stronger
      flyPower += 0.0002f;

      break;
    }
  }

  // screen bottom
  if (birdY > height + birdSize) {

    birdFlying = false;

    birdVX = 0;
    birdVY = 0;

    flyPower = 0;

    birdY = height - 70;
  }

  // screen left/right
  if (birdX < -birdSize) {
    birdFlying = false;
  }

  if (birdX > width + birdSize) {
    birdFlying = false;
  }

  // top
  if (birdY < 0) {
    birdY = 0;
    birdVY *= -0.5f;
  }
}

// --------------------------------------------------
// LINE COLLISION
// --------------------------------------------------

boolean hitLine(int n) {

  float x1 = lines[n][0];
  float y1 = lines[n][1];

  float x2 = lines[n][2];
  float y2 = lines[n][3];

  float dx = x2 - x1;
  float dy = y2 - y1;

  float len2 = dx*dx + dy*dy;

  if (len2 < 1) return false;

  // nearest point on line
  float t =
    ((birdX-x1)*dx +
     (birdY-y1)*dy) / len2;

  if (t < 0) t = 0;
  if (t > 1) t = 1;

  float px = x1 + t*dx;
  float py = y1 + t*dy;

  float distance =
    dist(birdX, birdY, px, py);

  return distance < birdSize * 0.55f;
}

// --------------------------------------------------
// TOUCH
// --------------------------------------------------

void mousePressed() {

  // First: touch bird
  if (dist(mouseX, mouseY,
           birdX, birdY) < birdSize * 1.3f) {

    birdAttached = true;
    birdFlying = false;

    return;
  }

  // Otherwise touch a line
  int found = nearestLine(mouseX, mouseY);

  if (found >= 0) {

    selectedLine = found;

    // Put bird on the nearest point
    placeBirdOnLine(found,
                    mouseX,
                    mouseY);

    birdAttached = true;
    birdFlying = false;
  }
}

// --------------------------------------------------

void mouseDragged() {

  if (!birdAttached) return;

  // Move bird with finger
  birdX = mouseX;
  birdY = mouseY;
}

// --------------------------------------------------

void mouseReleased() {

  if (!birdAttached) return;

  birdAttached = false;

  // launch direction
  float dx = mouseX - birdX;
  float dy = mouseY - birdY;

  // If finger barely moved:
  // launch automatically along selected line
  if (abs(dx) < 5 && abs(dy) < 5) {

    if (selectedLine >= 0) {

      float x1 = lines[selectedLine][0];
      float y1 = lines[selectedLine][1];

      float x2 = lines[selectedLine][2];
      float y2 = lines[selectedLine][3];

      dx = x2 - x1;
      dy = y2 - y1;
    }
  }

  float len = sqrt(dx*dx + dy*dy);

  if (len < 1) len = 1;

  // launch
  birdVX = dx / len * 0.45f;
  birdVY = dy / len * 0.45f;

  // gravity starts at +0.0001
  flyPower = 0.0001f;

  birdFlying = true;
}

// --------------------------------------------------
// FIND NEAREST LINE
// --------------------------------------------------

int nearestLine(float px, float py) {

  int best = -1;
  float bestDistance = 55;

  for (int i = 0; i < lineCount; i++) {

    float d =
      pointLineDistance(
        px, py,
        lines[i][0],
        lines[i][1],
        lines[i][2],
        lines[i][3]
      );

    if (d < bestDistance) {

      bestDistance = d;
      best = i;
    }
  }

  return best;
}

// --------------------------------------------------

float pointLineDistance(
  float px, float py,
  float x1, float y1,
  float x2, float y2) {

  float dx = x2-x1;
  float dy = y2-y1;

  if (dx == 0 && dy == 0) {
    return dist(px,py,x1,y1);
  }

  float t =
    ((px-x1)*dx +
     (py-y1)*dy) /
    (dx*dx + dy*dy);

  if (t < 0) t = 0;
  if (t > 1) t = 1;

  float xx = x1 + t*dx;
  float yy = y1 + t*dy;

  return dist(px,py,xx,yy);
}

// --------------------------------------------------
// PUT BIRD ON LINE
// --------------------------------------------------

void placeBirdOnLine(
  int n,
  float px,
  float py) {

  float x1 = lines[n][0];
  float y1 = lines[n][1];

  float x2 = lines[n][2];
  float y2 = lines[n][3];

  float dx = x2-x1;
  float dy = y2-y1;

  float len2 = dx*dx + dy*dy;

  if (len2 < 1) return;

  float t =
    ((px-x1)*dx +
     (py-y1)*dy) / len2;

  if (t < 0) t = 0;
  if (t > 1) t = 1;

  birdX = x1 + t*dx;
  birdY = y1 + t*dy - birdSize*0.55f;
}









/*



// ANGry BIRDS / LINES
// APDE 0.5.3
// One file
// Touch only - NO keyboard

final int MAX_LINES = 999;

float[][] lines = new float[MAX_LINES][4];

// line: x1,y1,x2,y2
int lineCount = 0;

float birdX, birdY;
float birdVX = 0;
float birdVY = 0;

float birdSize = 34;

boolean birdFlying = false;
boolean birdAttached = false;

int selectedLine = -1;

float gravity = 0.0001f;
float flyPower = 0.0f;

long lastTime;

// --------------------------------------------------

void setup() {
  orientation(PORTRAIT);
  size(displayWidth, displayHeight, P2D);

  rectMode(CENTER);
  strokeCap(ROUND);

  makeLines();

  birdX = width * 0.15f;
  birdY = height * 0.75f;

  lastTime = millis();
}

// --------------------------------------------------

void draw() {

  background(245, 245, 240);

  float dt = millis() - lastTime;
  lastTime = millis();

  if (dt > 40) dt = 40;

  drawLines();

  if (birdFlying) {
    updateBird(dt);
  }

  drawBird();

  // small information
  fill(40);
  textSize(20);
  text("LINES: " + lineCount, 20, 30);

  if (selectedLine >= 0) {
    text("LINE " + selectedLine, 20, 55);
  }

  if (!birdFlying) {
    fill(30);
    text("TOUCH A LINE", 20, height - 30);
  }
}

// --------------------------------------------------
// CREATE MANY LINES
// --------------------------------------------------

void makeLines() {

  // Real visible game lines
  addLine(width*0.08f, height*0.82f,
          width*0.35f, height*0.72f);

  addLine(width*0.35f, height*0.72f,
          width*0.58f, height*0.63f);

  addLine(width*0.58f, height*0.63f,
          width*0.83f, height*0.70f);

  addLine(width*0.15f, height*0.55f,
          width*0.38f, height*0.48f);

  addLine(width*0.38f, height*0.48f,
          width*0.62f, height*0.53f);

  addLine(width*0.62f, height*0.53f,
          width*0.88f, height*0.40f);

  addLine(width*0.12f, height*0.35f,
          width*0.30f, height*0.28f);

  addLine(width*0.30f, height*0.28f,
          width*0.53f, height*0.34f);

  addLine(width*0.53f, height*0.34f,
          width*0.80f, height*0.25f);

  // Additional lines
  addLine(width*0.70f, height*0.82f,
          width*0.92f, height*0.75f);

  addLine(width*0.05f, height*0.65f,
          width*0.20f, height*0.60f);

  addLine(width*0.75f, height*0.55f,
          width*0.95f, height*0.50f);
}

// --------------------------------------------------

void addLine(float x1, float y1, float x2, float y2) {

  if (lineCount >= MAX_LINES) return;

  lines[lineCount][0] = x1;
  lines[lineCount][1] = y1;
  lines[lineCount][2] = x2;
  lines[lineCount][3] = y2;

  lineCount++;
}

// --------------------------------------------------

void drawLines() {

  strokeWeight(7);

  for (int i = 0; i < lineCount; i++) {

    if (i == selectedLine) {
      stroke(255, 80, 40);
      strokeWeight(11);
    } else {
      stroke(60, 80, 90);
      strokeWeight(7);
    }

    line(
      lines[i][0],
      lines[i][1],
      lines[i][2],
      lines[i][3]
    );
  }

  strokeWeight(1);
}

// --------------------------------------------------
// BIRD
// --------------------------------------------------

void drawBird() {

  noStroke();

  // shadow
  fill(0, 40);
  ellipse(birdX + 5, birdY + 7,
          birdSize + 5, birdSize + 5);

  // bird body
  fill(220, 40, 35);
  rect(birdX, birdY,
       birdSize, birdSize,
       8);

  // eye
  fill(255);
  ellipse(birdX - 7, birdY - 7, 10, 10);
  ellipse(birdX + 7, birdY - 7, 10, 10);

  fill(0);
  ellipse(birdX - 7, birdY - 7, 4, 4);
  ellipse(birdX + 7, birdY - 7, 4, 4);

  // beak
  fill(240, 170, 30);

  triangle(
    birdX + birdSize/2,
    birdY - 2,

    birdX + birdSize/2 + 18,
    birdY + 4,

    birdX + birdSize/2,
    birdY + 10
  );
}

// --------------------------------------------------
// BIRD PHYSICS
// --------------------------------------------------

void updateBird(float dt) {

  // Gravity gets larger while flying
  flyPower += gravity * dt;

  birdVY += flyPower * dt;

  birdX += birdVX * dt;
  birdY += birdVY * dt;

  // check every line
  for (int i = 0; i < lineCount; i++) {

    if (hitLine(i)) {

      selectedLine = i;

      // bounce from line
      float dx =
        lines[i][2] - lines[i][0];

      float dy =
        lines[i][3] - lines[i][1];

      float len = sqrt(dx*dx + dy*dy);

      if (len > 0) {

        dx /= len;
        dy /= len;

        // move along the line
        float speed =
          sqrt(birdVX*birdVX +
               birdVY*birdVY);

        if (speed < 1) speed = 1;

        birdVX = dx * speed * 0.72f;
        birdVY = dy * speed * 0.72f;

        // small upward bounce
        birdVY -= 2.0f;
      }

      // gravity becomes stronger
      flyPower += 0.0002f;

      break;
    }
  }

  // screen bottom
  if (birdY > height + birdSize) {

    birdFlying = false;

    birdVX = 0;
    birdVY = 0;

    flyPower = 0;

    birdY = height - 70;
  }

  // screen left/right
  if (birdX < -birdSize) {
    birdFlying = false;
  }

  if (birdX > width + birdSize) {
    birdFlying = false;
  }

  // top
  if (birdY < 0) {
    birdY = 0;
    birdVY *= -0.5f;
  }
}

// --------------------------------------------------
// LINE COLLISION
// --------------------------------------------------

boolean hitLine(int n) {

  float x1 = lines[n][0];
  float y1 = lines[n][1];

  float x2 = lines[n][2];
  float y2 = lines[n][3];

  float dx = x2 - x1;
  float dy = y2 - y1;

  float len2 = dx*dx + dy*dy;

  if (len2 < 1) return false;

  // nearest point on line
  float t =
    ((birdX-x1)*dx +
     (birdY-y1)*dy) / len2;

  if (t < 0) t = 0;
  if (t > 1) t = 1;

  float px = x1 + t*dx;
  float py = y1 + t*dy;

  float distance =
    dist(birdX, birdY, px, py);

  return distance < birdSize * 0.55f;
}

// --------------------------------------------------
// TOUCH
// --------------------------------------------------

void mousePressed() {

  // First: touch bird
  if (dist(mouseX, mouseY,
           birdX, birdY) < birdSize * 1.3f) {

    birdAttached = true;
    birdFlying = false;

    return;
  }

  // Otherwise touch a line
  int found = nearestLine(mouseX, mouseY);

  if (found >= 0) {

    selectedLine = found;

    // Put bird on the nearest point
    placeBirdOnLine(found,
                    mouseX,
                    mouseY);

    birdAttached = true;
    birdFlying = false;
  }
}

// --------------------------------------------------

void mouseDragged() {

  if (!birdAttached) return;

  // Move bird with finger
  birdX = mouseX;
  birdY = mouseY;
}

// --------------------------------------------------

void mouseReleased() {

  if (!birdAttached) return;

  birdAttached = false;

  // launch direction
  float dx = mouseX - birdX;
  float dy = mouseY - birdY;

  // If finger barely moved:
  // launch automatically along selected line
  if (abs(dx) < 5 && abs(dy) < 5) {

    if (selectedLine >= 0) {

      float x1 = lines[selectedLine][0];
      float y1 = lines[selectedLine][1];

      float x2 = lines[selectedLine][2];
      float y2 = lines[selectedLine][3];

      dx = x2 - x1;
      dy = y2 - y1;
    }
  }

  float len = sqrt(dx*dx + dy*dy);

  if (len < 1) len = 1;

  // launch
  birdVX = dx / len * 0.45f;
  birdVY = dy / len * 0.45f;

  // gravity starts at +0.0001
  flyPower = 0.0001f;

  birdFlying = true;
}

// --------------------------------------------------
// FIND NEAREST LINE
// --------------------------------------------------

int nearestLine(float px, float py) {

  int best = -1;
  float bestDistance = 55;

  for (int i = 0; i < lineCount; i++) {

    float d =
      pointLineDistance(
        px, py,
        lines[i][0],
        lines[i][1],
        lines[i][2],
        lines[i][3]
      );

    if (d < bestDistance) {

      bestDistance = d;
      best = i;
    }
  }

  return best;
}

// --------------------------------------------------

float pointLineDistance(
  float px, float py,
  float x1, float y1,
  float x2, float y2) {

  float dx = x2-x1;
  float dy = y2-y1;

  if (dx == 0 && dy == 0) {
    return dist(px,py,x1,y1);
  }

  float t =
    ((px-x1)*dx +
     (py-y1)*dy) /
    (dx*dx + dy*dy);

  if (t < 0) t = 0;
  if (t > 1) t = 1;

  float xx = x1 + t*dx;
  float yy = y1 + t*dy;

  return dist(px,py,xx,yy);
}

// --------------------------------------------------
// PUT BIRD ON LINE
// --------------------------------------------------

void placeBirdOnLine(
  int n,
  float px,
  float py) {

  float x1 = lines[n][0];
  float y1 = lines[n][1];

  float x2 = lines[n][2];
  float y2 = lines[n][3];

  float dx = x2-x1;
  float dy = y2-y1;

  float len2 = dx*dx + dy*dy;

  if (len2 < 1) return;

  float t =
    ((px-x1)*dx +
     (py-y1)*dy) / len2;

  if (t < 0) t = 0;
  if (t > 1) t = 1;

  birdX = x1 + t*dx;
  birdY = y1 + t*dy - birdSize*0.55f;
}




// ANGry BIRDS / LINES
// APDE 0.5.3
// One file
// Touch only - NO keyboard

final int MAX_LINES = 999;

float[][] lines = new float[MAX_LINES][4];

// line: x1,y1,x2,y2
int lineCount = 0;

float birdX, birdY;
float birdVX = 0;
float birdVY = 0;

float birdSize = 34;

boolean birdFlying = false;
boolean birdAttached = false;

int selectedLine = -1;

float gravity = 0.0001f;
float flyPower = 0.0f;

long lastTime;

// --------------------------------------------------

void setup() {
  orientation(PORTRAIT);
  size(displayWidth, displayHeight, P2D);

  rectMode(CENTER);
  strokeCap(ROUND);

  makeLines();

  birdX = width * 0.15f;
  birdY = height * 0.75f;

  lastTime = millis();
}

// --------------------------------------------------

void draw() {

  background(245, 245, 240);

  float dt = millis() - lastTime;
  lastTime = millis();

  if (dt > 40) dt = 40;

  drawLines();

  if (birdFlying) {
    updateBird(dt);
  }

  drawBird();

  // small information
  fill(40);
  textSize(20);
  text("LINES: " + lineCount, 20, 30);

  if (selectedLine >= 0) {
    text("LINE " + selectedLine, 20, 55);
  }

  if (!birdFlying) {
    fill(30);
    text("TOUCH A LINE", 20, height - 30);
  }
}

// --------------------------------------------------
// CREATE MANY LINES
// --------------------------------------------------

void makeLines() {

  // Real visible game lines
  addLine(width*0.08f, height*0.82f,
          width*0.35f, height*0.72f);

  addLine(width*0.35f, height*0.72f,
          width*0.58f, height*0.63f);

  addLine(width*0.58f, height*0.63f,
          width*0.83f, height*0.70f);

  addLine(width*0.15f, height*0.55f,
          width*0.38f, height*0.48f);

  addLine(width*0.38f, height*0.48f,
          width*0.62f, height*0.53f);

  addLine(width*0.62f, height*0.53f,
          width*0.88f, height*0.40f);

  addLine(width*0.12f, height*0.35f,
          width*0.30f, height*0.28f);

  addLine(width*0.30f, height*0.28f,
          width*0.53f, height*0.34f);

  addLine(width*0.53f, height*0.34f,
          width*0.80f, height*0.25f);

  // Additional lines
  addLine(width*0.70f, height*0.82f,
          width*0.92f, height*0.75f);

  addLine(width*0.05f, height*0.65f,
          width*0.20f, height*0.60f);

  addLine(width*0.75f, height*0.55f,
          width*0.95f, height*0.50f);
}

// --------------------------------------------------

void addLine(float x1, float y1, float x2, float y2) {

  if (lineCount >= MAX_LINES) return;

  lines[lineCount][0] = x1;
  lines[lineCount][1] = y1;
  lines[lineCount][2] = x2;
  lines[lineCount][3] = y2;

  lineCount++;
}

// --------------------------------------------------

void drawLines() {

  strokeWeight(7);

  for (int i = 0; i < lineCount; i++) {

    if (i == selectedLine) {
      stroke(255, 80, 40);
      strokeWeight(11);
    } else {
      stroke(60, 80, 90);
      strokeWeight(7);
    }

    line(
      lines[i][0],
      lines[i][1],
      lines[i][2],
      lines[i][3]
    );
  }

  strokeWeight(1);
}

// --------------------------------------------------
// BIRD
// --------------------------------------------------

void drawBird() {

  noStroke();

  // shadow
  fill(0, 40);
  ellipse(birdX + 5, birdY + 7,
          birdSize + 5, birdSize + 5);

  // bird body
  fill(220, 40, 35);
  rect(birdX, birdY,
       birdSize, birdSize,
       8);

  // eye
  fill(255);
  ellipse(birdX - 7, birdY - 7, 10, 10);
  ellipse(birdX + 7, birdY - 7, 10, 10);

  fill(0);
  ellipse(birdX - 7, birdY - 7, 4, 4);
  ellipse(birdX + 7, birdY - 7, 4, 4);

  // beak
  fill(240, 170, 30);

  triangle(
    birdX + birdSize/2,
    birdY - 2,

    birdX + birdSize/2 + 18,
    birdY + 4,

    birdX + birdSize/2,
    birdY + 10
  );
}

// --------------------------------------------------
// BIRD PHYSICS
// --------------------------------------------------

void updateBird(float dt) {

  // Gravity gets larger while flying
  flyPower += gravity * dt;

  birdVY += flyPower * dt;

  birdX += birdVX * dt;
  birdY += birdVY * dt;

  // check every line
  for (int i = 0; i < lineCount; i++) {

    if (hitLine(i)) {

      selectedLine = i;

      // bounce from line
      float dx =
        lines[i][2] - lines[i][0];

      float dy =
        lines[i][3] - lines[i][1];

      float len = sqrt(dx*dx + dy*dy);

      if (len > 0) {

        dx /= len;
        dy /= len;

        // move along the line
        float speed =
          sqrt(birdVX*birdVX +
               birdVY*birdVY);

        if (speed < 1) speed = 1;

        birdVX = dx * speed * 0.72f;
        birdVY = dy * speed * 0.72f;

        // small upward bounce
        birdVY -= 2.0f;
      }

      // gravity becomes stronger
      flyPower += 0.0002f;

      break;
    }
  }

  // screen bottom
  if (birdY > height + birdSize) {

    birdFlying = false;

    birdVX = 0;
    birdVY = 0;

    flyPower = 0;

    birdY = height - 70;
  }

  // screen left/right
  if (birdX < -birdSize) {
    birdFlying = false;
  }

  if (birdX > width + birdSize) {
    birdFlying = false;
  }

  // top
  if (birdY < 0) {
    birdY = 0;
    birdVY *= -0.5f;
  }
}

// --------------------------------------------------
// LINE COLLISION
// --------------------------------------------------

boolean hitLine(int n) {

  float x1 = lines[n][0];
  float y1 = lines[n][1];

  float x2 = lines[n][2];
  float y2 = lines[n][3];

  float dx = x2 - x1;
  float dy = y2 - y1;

  float len2 = dx*dx + dy*dy;

  if (len2 < 1) return false;

  // nearest point on line
  float t =
    ((birdX-x1)*dx +
     (birdY-y1)*dy) / len2;

  if (t < 0) t = 0;
  if (t > 1) t = 1;

  float px = x1 + t*dx;
  float py = y1 + t*dy;

  float distance =
    dist(birdX, birdY, px, py);

  return distance < birdSize * 0.55f;
}

// --------------------------------------------------
// TOUCH
// --------------------------------------------------

void mousePressed() {

  // First: touch bird
  if (dist(mouseX, mouseY,
           birdX, birdY) < birdSize * 1.3f) {

    birdAttached = true;
    birdFlying = false;

    return;
  }

  // Otherwise touch a line
  int found = nearestLine(mouseX, mouseY);

  if (found >= 0) {

    selectedLine = found;

    // Put bird on the nearest point
    placeBirdOnLine(found,
                    mouseX,
                    mouseY);

    birdAttached = true;
    birdFlying = false;
  }
}

// --------------------------------------------------

void mouseDragged() {

  if (!birdAttached) return;

  // Move bird with finger
  birdX = mouseX;
  birdY = mouseY;
}

// --------------------------------------------------

void mouseReleased() {

  if (!birdAttached) return;

  birdAttached = false;

  // launch direction
  float dx = mouseX - birdX;
  float dy = mouseY - birdY;

  // If finger barely moved:
  // launch automatically along selected line
  if (abs(dx) < 5 && abs(dy) < 5) {

    if (selectedLine >= 0) {

      float x1 = lines[selectedLine][0];
      float y1 = lines[selectedLine][1];

      float x2 = lines[selectedLine][2];
      float y2 = lines[selectedLine][3];

      dx = x2 - x1;
      dy = y2 - y1;
    }
  }

  float len = sqrt(dx*dx + dy*dy);

  if (len < 1) len = 1;

  // launch
  birdVX = dx / len * 0.45f;
  birdVY = dy / len * 0.45f;

  // gravity starts at +0.0001
  flyPower = 0.0001f;

  birdFlying = true;
}

// --------------------------------------------------
// FIND NEAREST LINE
// --------------------------------------------------

int nearestLine(float px, float py) {

  int best = -1;
  float bestDistance = 55;

  for (int i = 0; i < lineCount; i++) {

    float d =
      pointLineDistance(
        px, py,
        lines[i][0],
        lines[i][1],
        lines[i][2],
        lines[i][3]
      );

    if (d < bestDistance) {

      bestDistance = d;
      best = i;
    }
  }

  return best;
}

// --------------------------------------------------

float pointLineDistance(
  float px, float py,
  float x1, float y1,
  float x2, float y2) {

  float dx = x2-x1;
  float dy = y2-y1;

  if (dx == 0 && dy == 0) {
    return dist(px,py,x1,y1);
  }

  float t =
    ((px-x1)*dx +
     (py-y1)*dy) /
    (dx*dx + dy*dy);

  if (t < 0) t = 0;
  if (t > 1) t = 1;

  float xx = x1 + t*dx;
  float yy = y1 + t*dy;

  return dist(px,py,xx,yy);
}

// --------------------------------------------------
// PUT BIRD ON LINE
// --------------------------------------------------

void placeBirdOnLine(
  int n,
  float px,
  float py) {

  float x1 = lines[n][0];
  float y1 = lines[n][1];

  float x2 = lines[n][2];
  float y2 = lines[n][3];

  float dx = x2-x1;
  float dy = y2-y1;

  float len2 = dx*dx + dy*dy;

  if (len2 < 1) return;

  float t =
    ((px-x1)*dx +
     (py-y1)*dy) / len2;

  if (t < 0) t = 0;
  if (t > 1) t = 1;

  birdX = x1 + t*dx;
  birdY = y1 + t*dy - birdSize*0.55f;
}















*/






