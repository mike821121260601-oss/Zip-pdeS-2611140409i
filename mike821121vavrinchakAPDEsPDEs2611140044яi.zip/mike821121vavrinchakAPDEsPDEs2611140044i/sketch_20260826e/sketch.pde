














// APDE / Processing - Big Chess 13x13 (2 boards)
// Figures = rectangles only

int boardSize = 13;
int cell;
int offsetY = 40;
int boardGap = 30;

PVector[][] board1 = new PVector[boardSize][boardSize];
 // piece type
PVector[][] board2 = new PVector[boardSize][boardSize];

// Piece types:
// 0 = empty
// 1 = pawn
// 2 = knight
// 3 = bishop
// 4 = rook (castle)
// 5 = king

int selectedX = -1, selectedY = -1;
int activeBoard = 1; // 1 or 2

void setup() {
  fullScreen();
  orientation(PORTRAIT);
  cell = min((width - 40) / boardSize, (height - 180) 
     / (boardSize * 2 + 1));
  
  // Init empty
  for (int y = 0; y < boardSize; y++) {
    for (int x = 0; x < boardSize; x++) {
      board1[x][y] = new PVector(0, 0); 
    // type, color (0=white, 1=black)
      board2[x][y] = new PVector(0, 0);
    }
  }
  
  placeRandomPieces(board1);
  placeRandomPieces(board2);
}

void placeRandomPieces(PVector[][] b) {
  // Free 5 lines (rows 0-4 empty-ish, or clear middle)
  // Pawns randomly on rows 1-8 style, but scaled to 13
  
  // Place many random pawns
  for (int i = 0; i < 18; i++) {
    int x = (int)random(boardSize);
    int y = (int)random(2, 11);
    if (b[x][y].x == 0) {
      b[x][y] = new PVector(1, random(1) > 0.5 ? 1 : 0); 
   // pawn
    }
  }
  
  // One King
  int kx = (int)random(boardSize);
  int ky = (int)random(boardSize);
  b[kx][ky] = new PVector(5, 0); // white king
  
  // Knights, Bishops, Rooks randomly
  int[] types = {2, 2, 2, 3, 3, 4, 4, 2, 3}; 
     // knight bishop rook mix
  for (int t : types) {
    int tries = 0;
    while (tries < 50) {
      int x = (int)random(boardSize);
      int y = (int)random(boardSize);
      if (b[x][y].x == 0) {
      b[x][y] = new PVector(t, random(1) > 0.5 ? 1 : 0);
        break;
      }
      tries++;
    }
  }
  
  // Extra random on rows 9-12
  for (int y = 9; y < boardSize; y++) {
    for (int i = 0; i < 3; i++) {
      int x = (int)random(boardSize);
      if (b[x][y].x == 0) {
        int t = (int)random(2, 5); 
     // knight/bishop/rook
     b[x][y] = new PVector(t, random(1) > 0.5 ? 1 : 0);
      }
    }
  }
}

void draw() {
  background(30);
  
  // Title
  fill(255);
  textSize(28);
  textAlign(CENTER);
  text("BIG CHESS 13x13  |  Play with yourself", 
      width/2, 30);
  
  // Board 1
  drawBoard(board1, 20, offsetY, 1);
  
  // Board 2
  int board2Y = offsetY + boardSize * cell + boardGap;
  drawBoard(board2, 20, board2Y, 2);
  
  // Selected highlight
  if (selectedX >= 0) {
    stroke(255, 255, 0);
    strokeWeight(4);
    noFill();
    int by = 
(activeBoard == 1) ? offsetY : offsetY + boardSize 
       * cell + boardGap;
    rect(20 + selectedX * cell, by + selectedY * cell,
        cell, cell);
  }
  
  // Instructions
  fill(180);
  textSize(18);
  text("Tap piece  Tap empty square to move",
        width/2, height - 25);
}

void drawBoard(PVector[][] b, int ox, 
       int oy, int boardNum) {
  for (int y = 0; y < boardSize; y++) {
    for (int x = 0; x < boardSize; x++) {
      // Cell color
      if ((x + y) % 2 == 0) fill(240, 217, 181);
      else fill(181, 136, 99);
      
      noStroke();
      rect(ox + x * cell, oy + y * cell, cell, cell);
      
      // Draw piece as rectangle shapes
      int type = (int)b[x][y].x;
      int col = (int)b[x][y].y; // 0 white, 1 black
      
      if (type > 0) {
    drawPiece(ox + x * cell, oy + y * cell, type, col);
      }
    }
  }
  
  // Board label
  fill(200);
  textSize(16);
  textAlign(LEFT);
  text("Board " + boardNum, ox, oy - 8);
}

void drawPiece(float px, float py, 
     int type, int col) {
  float m = cell * 0.15; // margin
  float s = cell - m * 2;
  
  if (col == 0) fill(245);      // white
  else fill(40);                // black
  
  stroke(0);
  strokeWeight(1.5);
  
  switch(type) {
    case 1: // PAWN - small rectangle
      rect(px + m + s*0.25, py + m + s*0.35, 
         s*0.5, s*0.55, 4);
      break;
      
    case 2: // KNIGHT - L shape approx with 2 rects
      rect(px + m, py + m + s*0.2, s*0.55, s*0.7, 3);
      rect(px + m + s*0.35, py + m, s*0.5, s*0.4, 3);
      break;
      
    case 3: // BISHOP - tall pointed
      rect(px + m + s*0.3, py + m + s*0.15, 
            s*0.4, s*0.7, 3);
      triangle(px + m + s*0.5, py + m, 
               px + m + s*0.25, py + m + s*0.25, 
               px + m + s*0.75, py + m + s*0.25);
      break;
      
    case 4: // ROOK (Castle) - square with battlements
      rect(px + m + s*0.2, py + m + s*0.25,
       s*0.6, s*0.65, 2);
      // top notches
     rect(px + m + s*0.15, py + m + s*0.1, s*0.2, s*0.2);
     rect(px + m + s*0.4,  py + m + s*0.1, s*0.2, s*0.2);
     rect(px + m + s*0.65, py + m + s*0.1, s*0.2, s*0.2);
      break;
      
    case 5: // KING - cross on top
      rect(px + m + s*0.25, py + m + s*0.3, 
      s*0.5, s*0.55, 3);
      // cross
      rect(px + m + s*0.42, py + m + s*0.05,
      s*0.16, s*0.35);
      rect(px + m + s*0.28, py + m + s*0.12, 
        s*0.44, s*0.14);
      break;
  }
}

void mousePressed() {
  int mx = mouseX - 20;
  int my1 = mouseY - offsetY;
  int my2 = mouseY - (offsetY + 
    boardSize * cell + boardGap);
  
  // Check Board 1
  if (mx >= 0 && mx < boardSize * cell &&
    my1 >= 0 && my1 < boardSize * cell) {
    int x = mx / cell;
    int y = my1 / cell;
    handleClick(board1, x, y, 1);
  }
  // Check Board 2
  else if (mx >= 0 && mx < boardSize * 
  cell && my2 >= 0 && my2 < boardSize * cell) {
    int x = mx / cell;
    int y = my2 / cell;
    handleClick(board2, x, y, 2);
  }
}

void handleClick(PVector[][] b, int x, 
   int y, int boardNum) {
  if (selectedX == -1) {
    // Select piece
    if (b[x][y].x > 0) {
      selectedX = x;
      selectedY = y;
      activeBoard = boardNum;
    }
  } else {
    // Try move
    if (activeBoard == boardNum) {
      if (b[x][y].x == 0 || (b[x][y].y != 
     b[selectedX][selectedY].y)) {
        // Move or capture
        b[x][y] = b[selectedX][selectedY].copy();
     b[selectedX][selectedY] = new PVector(0, 0);
      }
    }
    selectedX = -1;
    selectedY = -1;
  }
}

// Double tap empty area to randomize again (optional)
void mouseDoubleClicked() {
  placeRandomPieces(board1);
  placeRandomPieces(board2);
  selectedX = -1;
}









/*


// APDE / Processing - Big Chess 13x13 (2 boards)
// Figures = rectangles only

int boardSize = 13;
int cell;
int offsetY = 40;
int boardGap = 30;

PVector[][] board1 = new PVector[boardSize][boardSize];
 // piece type
PVector[][] board2 = new PVector[boardSize][boardSize];

// Piece types:
// 0 = empty
// 1 = pawn
// 2 = knight
// 3 = bishop
// 4 = rook (castle)
// 5 = king

int selectedX = -1, selectedY = -1;
int activeBoard = 1; // 1 or 2

void setup() {
  fullScreen();
  orientation(PORTRAIT);
  cell = min((width - 40) / boardSize,
    (height - 180) / (boardSize * 2 + 1));
  
  // Init empty
  for (int y = 0; y < boardSize; y++) {
    for (int x = 0; x < boardSize; x++) {
      board1[x][y] = new PVector(0, 0); 
    // type, color (0=white, 1=black)
      board2[x][y] = new PVector(0, 0);
    }
  }
  
  placeRandomPieces(board1);
  placeRandomPieces(board2);
}

void placeRandomPieces(PVector[][] b) {
  // Free 5 lines (rows 0-4 empty-ish, or clear middle)
  // Pawns randomly on rows 1-8 style, but scaled to 13
  
  // Place many random pawns
  for (int i = 0; i < 18; i++) {
    int x = (int)random(boardSize);
    int y = (int)random(2, 11);
    if (b[x][y].x == 0) {
   b[x][y] = new PVector(1, random(1) > 0.5 ? 1 : 0);
    // pawn
    }
  }
  
  // One King
  int kx = (int)random(boardSize);
  int ky = (int)random(boardSize);
  b[kx][ky] = new PVector(5, 0); // white king
  
  // Knights, Bishops, Rooks randomly
  int[] types = {2, 2, 2, 3, 3, 4, 4, 2, 3};
    // knight bishop rook mix
  for (int t : types) {
    int tries = 0;
    while (tries < 50) {
      int x = (int)random(boardSize);
      int y = (int)random(boardSize);
      if (b[x][y].x == 0) {
   b[x][y] = new PVector(t, random(1) > 0.5 ? 1 : 0);
        break;
      }
      tries++;
    }
  }
  
  // Extra random on rows 9-12
  for (int y = 9; y < boardSize; y++) {
    for (int i = 0; i < 3; i++) {
      int x = (int)random(boardSize);
      if (b[x][y].x == 0) {
        int t = (int)random(2, 5); 
     // knight/bishop/rook
    b[x][y] = new PVector(t, random(1) > 0.5 ? 1 : 0);
      }
    }
  }
}

void draw() {
  background(30);
  
  // Title
  fill(255);
  textSize(28);
  textAlign(CENTER);
  text("BIG CHESS 13x13  |  Play with yourself", 
    width/2, 30);
  
  // Board 1
  drawBoard(board1, 20, offsetY, 1);
  
  // Board 2
  int board2Y = offsetY + boardSize * cell + boardGap;
  drawBoard(board2, 20, board2Y, 2);
  
  // Selected highlight
  if (selectedX >= 0) {
    stroke(255, 255, 0);
    strokeWeight(4);
    noFill();
    int by = (activeBoard == 1) ? offsetY : offsetY 
     + boardSize * cell + boardGap;
    rect(20 + selectedX * cell, by + selectedY 
      * cell, cell, cell);
  }
  
  // Instructions
  fill(180);
  textSize(18);
  text("Tap piece  Tap empty square to move", 
    width/2, height - 25);
}

void drawBoard(PVector[][] b, int ox, 
      int oy, int boardNum) {
  for (int y = 0; y < boardSize; y++) {
    for (int x = 0; x < boardSize; x++) {
      // Cell color
      if ((x + y) % 2 == 0) fill(240, 217, 181);
      else fill(181, 136, 99);
      
      noStroke();
      rect(ox + x * cell, oy + y * cell, cell, cell);
      
      // Draw piece as rectangle shapes
      int type = (int)b[x][y].x;
      int col = (int)b[x][y].y; // 0 white, 1 black
      
      if (type > 0) {
        drawPiece(ox + x * cell, oy + y * cell,
       type, col);
      }
    }
  }
  
  // Board label
  fill(200);
  textSize(16);
  textAlign(LEFT);
  text("Board " + boardNum, ox, oy - 8);
}

void drawPiece(float px, float py, i
      nt type, int col) {
  float m = cell * 0.15; // margin
  float s = cell - m * 2;
  
  if (col == 0) fill(245);      // white
  else fill(40);                // black
  
  stroke(0);
  strokeWeight(1.5);
  
  switch(type) {
    case 1: // PAWN - small rectangle
      rect(px + m + s*0.25, 
       py + m + s*0.35, s*0.5, s*0.55, 4);
      break;
      
    case 2: // KNIGHT - L shape approx with 2 rects
      rect(px + m, py + m + s*0.2, s*0.55, s*0.7, 3);
      rect(px + m + s*0.35, py + m, s*0.5, s*0.4, 3);
      break;
      
    case 3: // BISHOP - tall pointed
      rect(px + m + s*0.3, py + m + s*0.15, s*0.4, s*0.7, 3);
      triangle(px + m + s*0.5, py + m, 
               px + m + s*0.25, py + m + s*0.25, 
               px + m + s*0.75, py + m + s*0.25);
      break;
      
    case 4: // ROOK (Castle) - square with battlements
      rect(px + m + s*0.2, py + m + s*0.25, s*0.6, s*0.65, 2);
      // top notches
      rect(px + m + s*0.15, py + m + s*0.1, s*0.2, s*0.2);
      rect(px + m + s*0.4,  py + m + s*0.1, s*0.2, s*0.2);
      rect(px + m + s*0.65, py + m + s*0.1, s*0.2, s*0.2);
      break;
      
    case 5: // KING - cross on top
      rect(px + m + s*0.25, py + m + s*0.3, s*0.5, s*0.55, 3);
      // cross
      rect(px + m + s*0.42, py + m + s*0.05, s*0.16, s*0.35);
      rect(px + m + s*0.28, py + m + s*0.12, s*0.44, s*0.14);
      break;
  }
}

void mousePressed() {
  int mx = mouseX - 20;
  int my1 = mouseY - offsetY;
  int my2 = mouseY - (offsetY + boardSize * cell + boardGap);
  
  // Check Board 1
  if (mx >= 0 && mx < boardSize * cell && my1 >= 0 && my1 < boardSize * cell) {
    int x = mx / cell;
    int y = my1 / cell;
    handleClick(board1, x, y, 1);
  }
  // Check Board 2
  else if (mx >= 0 && mx < boardSize * cell && my2 >= 0 && my2 < boardSize * cell) {
    int x = mx / cell;
    int y = my2 / cell;
    handleClick(board2, x, y, 2);
  }
}

void handleClick(PVector[][] b, int x,
       int y, int boardNum) {
  if (selectedX == -1) {
    // Select piece
    if (b[x][y].x > 0) {
      selectedX = x;
      selectedY = y;
      activeBoard = boardNum;
    }
  } else {
    // Try move
    if (activeBoard == boardNum) {
      if (b[x][y].x == 0 || (b[x][y].y != 
       b[selectedX][selectedY].y)) {
        // Move or capture
        b[x][y] = b[selectedX][selectedY].copy();
        b[selectedX][selectedY] = new PVector(0, 0);
      }
    }
    selectedX = -1;
    selectedY = -1;
  }
}

// Double tap empty area to randomize again (optional)
void mouseDoubleClicked() {
  placeRandomPieces(board1);
  placeRandomPieces(board2);
  selectedX = -1;
}





*/








































