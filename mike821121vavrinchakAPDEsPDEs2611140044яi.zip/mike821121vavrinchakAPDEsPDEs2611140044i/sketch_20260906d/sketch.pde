












////WORK//////WORK/////WORK/////////
// Android media APIs – без Processing Sound
import android.media.MediaRecorder;
import android.media.MediaPlayer;
import java.io.File;
import java.io.IOException;

final int COLS = 9;
final int ROWS = 14;
final int TOTAL = COLS * ROWS;

// Стани
final int IDLE = 0;
final int RECORDING = 1;
final int PLAYING_ALL = 2;
int state = IDLE;

// Запис
MediaRecorder recorder;
int recordingKey = -1;
long recordStart;

// Відтворення
MediaPlayer player;
int playIndex = 0;    // який трек зараз грає
boolean playNextPending = false;

// Файли зберігаються у внутрішній пам'яті (sketchPath)
String getFileName(int idx) {
  return "key_" + idx + ".3gp";
}

void setup() {
 ///  size(900, 700);   // зручний розмір для 9×14
    size(displayWidth, displayHeight, JAVA2D) ;

  // Дозвіл на мікрофон – має бути доданий у вкладці Android
}

void draw() {
  background(200);
  
  float cellW = width / (float) COLS;
  float cellH = height / (float) ROWS;
  
  // Малюємо сітку
  for (int i = 0; i < TOTAL; i++) {
    int col = i % COLS;
    int row = i / COLS;
    float x = col * cellW;
    float y = row * cellH;
    
    // Колір: перша кнопка особлива
    if (i == 0) {
      fill(200, 100, 100);
    } else {
      // Чи існує файл?
  File f = new File(sketchPath(getFileName(i)));
      if (f.exists()) fill(100, 200, 100);
      else fill(150);
    }
    rect(x, y, cellW, cellH);
    
    // Номер
    fill(0);
    textAlign(CENTER, CENTER);
    textSize(12);
    text(i, x + cellW/2, y + cellH/2);
  }
  
  // Статус
  fill(0);
  textAlign(LEFT, TOP);
  textSize(16);
  if (state == RECORDING) {
    int elapsed = (int)((millis() 
     - recordStart) / 1000);
    text("Запис кнопки " + recordingKey 
   + " ... " + elapsed + "/10с", 10, 10);
  } else if (state == PLAYING_ALL) {
    text("Грає����о всі треки... (" 
   + playIndex + "/" + TOTAL + ")", 10, 10);
  } else {
    text
("Торкніться кнопки (1–125) для запису 10с, або кнопки 0 для відтворення всіх", 10, 10);
  }
  
  // Якщо йде запис – перевіряємо таймаут
  if (state == RECORDING && (millis() 
    - recordStart >= 10000)) {
    finishRecording();
  }
  
  // Якщо граємо всі – перевіряємо завершення поточного треку
  if (state == PLAYING_ALL && playNextPending) {
    if (player != null && !player.isPlaying()) {
      // Поточний трек скінчився – запускаємо наступний
      playNextPending = false;
      playNext();
    }
  }
}

// Визначаємо, яку кнопку натиснули
int getKeyAt(float mx, float my) {
  float cellW = width / (float) COLS;
  float cellH = height / (float) ROWS;
  int col = (int)(mx / cellW);
  int row = (int)(my / cellH);
  if (col < 0 || col >= COLS 
    || row < 0 || row >= ROWS) return -1;
  return row * COLS + col;
}

void mousePressed() {
  if (state == RECORDING) return; 
  // зайнято записом
  
  int key = getKeyAt(mouseX, mouseY);
  if (key < 0 || key >= TOTAL) return;
  
  if (key == 0) {
    // Перша кнопка – граємо всі
    if (state == PLAYING_ALL) return; 
 // вже граємо
    startPlayAll();
  } else {
    // Інша кнопка – запис
    startRecording(key);
  }
}

// ----- ЗАПИС -----
void startRecording(int key) {
  // Видалити старий файл, якщо є
  File f = new File(sketchPath(getFileName(key)));
  if (f.exists()) f.delete();
  
  try {
    recorder = new MediaRecorder();
    recorder.setAudioSource
  (MediaRecorder.AudioSource.MIC);
    recorder.setOutputFormat
  (MediaRecorder.OutputFormat.THREE_GPP);
    recorder.setAudioEncoder
  (MediaRecorder.AudioEncoder.AMR_NB);
    recorder.setOutputFile
  (sketchPath(getFileName(key)));
    recorder.prepare();
    recorder.start();
    
    state = RECORDING;
    recordingKey = key;
    recordStart = millis();
  } catch (SecurityException e) {
    println
("⚠️ Немає дозволу на мікрофон – додайте його у вкладці Android!");
  } catch (Exception e) {
    e.printStackTrace();
  }
}

void finishRecording() {
  if (recorder != null) {
    recorder.stop();
    recorder.release();
    recorder = null;
  }
  state = IDLE;
  recordingKey = -1;
  println
("Запис кнопки " + recordingKey + " завершено.");
}

// ----- ВІДТВОРЕННЯ ВСІХ -----
void startPlayAll() {
  if (state == PLAYING_ALL) return;
  state = PLAYING_ALL;
  playIndex = 1; 
 // починаємо з першої кнопки (index=1)
  playNext();    
 // запускаємо перший існуючий трек
}

void playNext() {
  // Шукаємо наступний існуючий файл, починаючи з поточного playIndex
  while (playIndex < TOTAL) {
    File f = new File(sketchPath
   (getFileName(playIndex)));
    if (f.exists()) {
      // Знайшли – гра����мо
      try {
        player = new MediaPlayer();
        player.setDataSource(f.getAbsolutePath());
        player.prepare();
        // Встановлюємо слухач завершення
        player.setOnCompletionListener
  (new MediaPlayer.OnCompletionListener() {
     public void onCompletion(MediaPlayer mp) {
   // Поточний трек завершено – сигналізуємо про наступний
            playNextPending = true;
          }
        });
        player.start();
        playNextPending = false; 
    // чекаємо завершення
        println("Граємо трек " + playIndex);
        playIndex++;  // готуємо наступний індекс
        return;
      } catch (IOException e) {
        e.printStackTrace();
      }
    }
    playIndex++;
  }
  // Якщо дійшли ��о кінця – всі треки зіграно
  finishPlayAll();
}

void finishPlayAll() {
  if (player != null) {
    player.release();
    player = null;
  }
  state = IDLE;
  playIndex = 0;
  println("Всі треки зіграно.");
}

// Звільнення ресурсів при закритті
void onDestroy() {
  if (recorder != null) recorder.release();
  if (player != null) player.release();
}////WIRK/////WORK///////



/*



// Android media APIs – без Processing Sound
import android.media.MediaRecorder;
import android.media.MediaPlayer;
import java.io.File;
import java.io.IOException;

final int COLS = 9;
final int ROWS = 14;
final int TOTAL = COLS * ROWS;

// Стани
final int IDLE = 0;
final int RECORDING = 1;
final int PLAYING_ALL = 2;
int state = IDLE;

// Запис
MediaRecorder recorder;
int recordingKey = -1;
long recordStart;

// Відтворення
MediaPlayer player;
int playIndex = 0;    // який трек зараз грає
boolean playNextPending = false;

// ��айли зберігаються у внутрішній пам'яті (sketchPath)
String getFileName(int idx) {
  return "key_" + idx + ".3gp";
}

void setup() {
  size(900, 700);   // зручний розмір для 9×14
  // Дозвіл на мікрофон – має бути доданий у вкладці Android
}

void draw() {
  background(200);
  
  float cellW = width / (float) COLS;
  float cellH = height / (float) ROWS;
  
  // Малюємо сітку
  for (int i = 0; i < TOTAL; i++) {
    int col = i % COLS;
    int row = i / COLS;
    float x = col * cellW;
    float y = row * cellH;
    
    // Колір: перша кнопка особлива
    if (i == 0) {
      fill(200, 100, 100);
    } else {
      // Чи існує файл?
      File f = new File(sketchPath(getFileName(i)));
      if (f.exists()) fill(100, 200, 100);
      else fill(150);
    }
    rect(x, y, cellW, cellH);
    
    // Номер
    fill(0);
    textAlign(CENTER, CENTER);
    textSize(12);
    text(i, x + cellW/2, y + cellH/2);
  }
  
  // Статус
  fill(0);
  textAlign(LEFT, TOP);
  textSize(16);
  if (state == RECORDING) {
    int elapsed = (int)((millis() - recordStart) / 1000);
    text("Запис кнопки " + recordingKey + " ... " + elapsed + "/10с", 10, 10);
  } else if (state == PLAYING_ALL) {
    text("Граємо всі треки... (" + playIndex + "/" + TOTAL + ")", 10, 10);
  } else {
    text("Торкніться кнопки (1–125) для запису 10с, або кнопки 0 для відтворення всіх", 10, 10);
  }
  
  // Якщо йде запис – перевіряємо таймаут
  if (state == RECORDING && (millis() - recordStart >= 10000)) {
    finishRecording();
  }
  
  // Якщо граємо всі – перевіряємо завершення поточного треку
  if (state == PLAYING_ALL && playNextPending) {
    if (player != null && !player.isPlaying()) {
      // Поточний трек скінчився – зап��скаємо наступний
      playNextPending = false;
      playNext();
    }
  }
}

// Визначаємо, яку кнопку натиснули
int getKeyAt(float mx, float my) {
  float cellW = width / (float) COLS;
  float cellH = height / (float) ROWS;
  int col = (int)(mx / cellW);
  int row = (int)(my / cellH);
  if (col < 0 || col >= COLS || row < 0 || row >= ROWS) return -1;
  return row * COLS + col;
}

void mousePressed() {
  if (state == RECORDING) return;   // зайнято записом
  
  int key = getKeyAt(mouseX, mouseY);
  if (key < 0 || key >= TOTAL) return;
  
  if (key == 0) {
    // Перша кнопка – граємо всі
    if (state == PLAYING_ALL) return;  // вже граємо
    startPlayAll();
  } else {
    // Інша кнопка – запис
    startRecording(key);
  }
}

// ----- ЗАПИС -----
void startRecording(int key) {
  // Видалити старий файл, якщо є
  File f = new File(sketchPath(getFileName(key)));
  if (f.exists()) f.delete();
  
  try {
    recorder = new MediaRecorder();
    recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
    recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
    recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
    recorder.setOutputFile(sketchPath(getFileName(key)));
    recorder.prepare();
    recorder.start();
    
    state = RECORDING;
    recordingKey = key;
    recordStart = millis();
  } catch (SecurityException e) {
    println("⚠️ Немає дозволу на мікрофон – додайте його у вкладці Android!");
  } catch (Exception e) {
    e.printStackTrace();
  }
}

void finishRecording() {
  if (recorder != null) {
    recorder.stop();
    recorder.release();
    recorder = null;
  }
  state = IDLE;
  recordingKey = -1;
  println("Запис кнопки " + recordingKey + " завершено.");
}

// ----- ВІДТВОРЕННЯ ВСІХ -----
void startPlayAll() {
  if (state == PLAYING_ALL) return;
  state = PLAYING_ALL;
  playIndex = 1;  // починаємо з першої кнопки (index=1)
  playNext();     // запускаємо перший існуючий трек
}

void playNext() {
  // Шукаємо наступний існуючий файл, починаючи з поточного playIndex
  while (playIndex < TOTAL) {
    File f = new File(sketchPath(getFileName(playIndex)));
    if (f.exists()) {
      // Знайшли – граємо
      try {
        player = new MediaPlayer();
        player.setDataSource(f.getAbsolutePath());
        player.prepare();
        // Встановлюємо слухач завершення
        player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
          public void onCompletion(MediaPlayer mp) {
            // Поточний трек завершено – сигналізуємо про наступний
            playNextPending = true;
          }
        });
        player.start();
        playNextPending = false;  // чек��ємо завершення
        println("Граємо трек " + playIndex);
        playIndex++;  // готуємо наступний індекс
        return;
      } catch (IOException e) {
        e.printStackTrace();
      }
    }
    playIndex++;
  }
  // Якщо дійшли до кінця – всі треки зіграно
  finishPlayAll();
}

void finishPlayAll() {
  if (player != null) {
    player.release();
    player = null;
  }
  state = IDLE;
  playIndex = 0;
  println("Всі треки зіграно.");
}

// Звільнення ресурсів при закритті
void onDestroy() {
  if (recorder != null) recorder.release();
  if (player != null) player.release();
}





// Android media APIs – без Processing Sound
import android.media.MediaRecorder;
import android.media.MediaPlayer;
import java.io.File;
import java.io.IOException;

final int COLS = 9;
final int ROWS = 14;
final int TOTAL = COLS * ROWS;

// Стани
final int IDLE = 0;
final int RECORDING = 1;
final int PLAYING_ALL = 2;
int state = IDLE;

// Запис
MediaRecorder recorder;
int recordingKey = -1;
long recordStart;

// Відтворення
MediaPlayer player;
int playIndex = 0;    // який трек зараз грає
boolean playNextPending = false;

// Файли зберігаються у внутрішній пам'яті (sketchPath)
String getFileName(int idx) {
  return "key_" + idx + ".3gp";
}

void setup() {
  size(900, 700);   // зручний розмір для 9×14
  // Дозвіл на мікрофон – має бути доданий у вкладці Android
}

void draw() {
  background(200);
  
  float cellW = width / (float) COLS;
  float cellH = height / (float) ROWS;
  
  // Малюємо сітку
  for (int i = 0; i < TOTAL; i++) {
    int col = i % COLS;
    int row = i / COLS;
    float x = col * cellW;
    float y = row * cellH;
    
    // Колір: перша кнопка особлива
    if (i == 0) {
      fill(200, 100, 100);
    } else {
      // ��и існує файл?
      File f = new File(sketchPath(getFileName(i)));
      if (f.exists()) fill(100, 200, 100);
      else fill(150);
    }
    rect(x, y, cellW, cellH);
    
    // Номер
    fill(0);
    textAlign(CENTER, CENTER);
    textSize(12);
    text(i, x + cellW/2, y + cellH/2);
  }
  
  // Статус
  fill(0);
  textAlign(LEFT, TOP);
  textSize(16);
  if (state == RECORDING) {
    int elapsed = (int)((millis() - recordStart) / 1000);
    text("Запис кнопки " + recordingKey + " ... " + elapsed + "/10с", 10, 10);
  } else if (state == PLAYING_ALL) {
    text("Граємо всі треки... (" + playIndex + "/" + TOTAL + ")", 10, 10);
  } else {
    text("Торкніться кнопки (1–125) для запису 10с, або кнопки 0 для відтворення всіх", 10, 10);
  }
  
  // Якщо йде запис – перевіряємо таймаут
  if (state == RECORDING && (millis() - recordStart >= 10000)) {
    finishRecording();
  }
  
  // Якщо граємо всі – перевіряємо завершення поточног������ треку
  if (state == PLAYING_ALL && playNextPending) {
    if (player != null && !player.isPlaying()) {
      // Поточний трек скінчився – запускаємо наступний
      playNextPending = false;
      playNext();
    }
  }
}

// Визначаємо, яку кнопку натиснули
int getKeyAt(float mx, float my) {
  float cellW = width / (float) COLS;
  float cellH = height / (float) ROWS;
  int col = (int)(mx / cellW);
  int row = (int)(my / cellH);
  if (col < 0 || col >= COLS || row < 0 || row >= ROWS) return -1;
  return row * COLS + col;
}

void mousePressed() {
  if (state == RECORDING) return;   // зайнято записом
  
  int key = getKeyAt(mouseX, mouseY);
  if (key < 0 || key >= TOTAL) return;
  
  if (key == 0) {
    // Перша кнопка – граємо всі
    if (state == PLAYING_ALL) return;  // вже граємо
    startPlayAll();
  } else {
    // Інша кнопка – запис
    startRecording(key);
  }
}

// ----- ЗАПИС -----
void startRecording(int key) {
  // Видалити старий файл, якщо є
  File f = new File(sketchPath(getFileName(key)));
  if (f.exists()) f.delete();
  
  try {
    recorder = new MediaRecorder();
    recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
    recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
    recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
    recorder.setOutputFile(sketchPath(getFileName(key)));
    recorder.prepare();
    recorder.start();
    
    state = RECORDING;
    recordingKey = key;
    recordStart = millis();
  } catch (SecurityException e) {
    println("⚠️ Немає дозволу на мікрофон – додайте його у вкладці Android!");
  } catch (Exception e) {
    e.printStackTrace();
  }
}

void finishRecording() {
  if (recorder != null) {
    recorder.stop();
    recorder.release();
    recorder = null;
  }
  state = IDLE;
  recordingKey = -1;
  println("Запис кн��п��и " + recordingKey + " завершено.");
}

// ----- ВІДТВОРЕННЯ ВСІХ -----
void startPlayAll() {
  if (state == PLAYING_ALL) return;
  state = PLAYING_ALL;
  playIndex = 1;  // починаємо з першої кнопки (index=1)
  playNext();     // запускаємо перший існуючий трек
}

void playNext() {
  // Шукаємо наступний існуючий файл, починаючи з поточного playIndex
  while (playIndex < TOTAL) {
    File f = new File(sketchPath(getFileName(playIndex)));
    if (f.exists()) {
      // Знайшли – граємо
      try {
        player = new MediaPlayer();
        player.setDataSource(f.getAbsolutePath());
        player.prepare();
        // Встановлюємо слухач завершення
        player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
          public void onCompletion(MediaPlayer mp) {
            // Поточний трек завершено – с��гналізуємо про наступний
            playNextPending = true;
          }
        });
        player.start();
        playNextPending = false;  // чекаємо завершення
        println("Граємо трек " + playIndex);
        playIndex++;  // готуємо наступний індекс
        return;
      } catch (IOException e) {
        e.printStackTrace();
      }
    }
    playIndex++;
  }
  // Якщо дійшли до кінця – всі треки зіграно
  finishPlayAll();
}

void finishPlayAll() {
  if (player != null) {
    player.release();
    player = null;
  }
  state = IDLE;
  playIndex = 0;
  println("Всі треки зіграно.");
}

// Звільнення ресурсів при закритті
void onDestroy() {
  if (recorder != null) recorder.release();
  if (player != null) player.release();
}




// Android media APIs – без Processing Sound
import android.media.MediaRecorder;
import android.media.MediaPlayer;
import java.io.File;
import java.io.IOException;

final int COLS = 9;
final int ROWS = 14;
final int TOTAL = COLS * ROWS;

// Стани
final int IDLE = 0;
final int RECORDING = 1;
final int PLAYING_ALL = 2;
int state = IDLE;

// Запис
MediaRecorder recorder;
int recordingKey = -1;
long recordStart;

// Відтворення
MediaPlayer player;
int playIndex = 0;    // який трек зараз грає
boolean playNextPending = false;

// Файли зберігаються у внутрішній пам'яті (sketchPath)
String getFileName(int idx) {
  return "key_" + idx + ".3gp";
}

void setup() {
  size(900, 700);   // зручний розмір для 9×14
  // Дозвіл на мікрофон – має бути доданий у вкладці Android
}

void draw() {
  background(200);
  
  float cellW = width / (float) COLS;
  float cellH = height / (float) ROWS;
  
  // Малюємо сітку
  for (int i = 0; i < TOTAL; i++) {
    int col = i % COLS;
    int row = i / COLS;
    float x = col * cellW;
    float y = row * cellH;
    
    // Колір: перша кнопка особлива
    if (i == 0) {
      fill(200, 100, 100);
    } else {
      // Чи існує файл?
      File f = new File(sketchPath(getFileName(i)));
      if (f.exists()) fill(100, 200, 100);
      else fill(150);
    }
    rect(x, y, cellW, cellH);
    
    // Номер
    fill(0);
    textAlign(CENTER, CENTER);
    textSize(12);
    text(i, x + cellW/2, y + cellH/2);
  }
  
  // Статус
  fill(0);
  textAlign(LEFT, TOP);
  textSize(16);
  if (state == RECORDING) {
    int elapsed = (int)((millis() - recordStart) / 1000);
    text("Запис кнопки " + recordingKey + " ... " + elapsed + "/10с", 10, 10);
  } else if (state == PLAYING_ALL) {
    text("Граємо всі треки... (" + playIndex + "/" + TOTAL + ")", 10, 10);
  } else {
    text("Торкніться ��нопки (1–125) для запису 10с, або кнопки 0 для відтворення всіх", 10, 10);
  }
  
  // Якщо йде запис – перевіряємо таймаут
  if (state == RECORDING && (millis() - recordStart >= 10000)) {
    finishRecording();
  }
  
  // Якщо граємо всі – перевіряємо завершення поточного треку
  if (state == PLAYING_ALL && playNextPending) {
    if (player != null && !player.isPlaying()) {
      // Поточний трек скінчився – запускаємо наступний
      playNextPending = false;
      playNext();
    }
  }
}

// Визначаємо, яку кнопку натиснули
int getKeyAt(float mx, float my) {
  float cellW = width / (float) COLS;
  float cellH = height / (float) ROWS;
  int col = (int)(mx / cellW);
  int row = (int)(my / cellH);
  if (col < 0 || col >= COLS || row < 0 || row >= ROWS) return -1;
  return row * COLS + col;
}

void mousePressed() {
  if (state == RECORDING) return;   // зайнято записом
  
  int key = getKeyAt(mouseX, mouseY);
  if (key < 0 || key >= TOTAL) return;
  
  if (key == 0) {
    // Перша кнопка – граємо всі
    if (state == PLAYING_ALL) return;  // вже граємо
    startPlayAll();
  } else {
    // Інша кнопка – запис
    startRecording(key);
  }
}

// ----- ЗАПИС -----
void startRecording(int key) {
  // Видалити старий файл, якщо є
  File f = new File(sketchPath(getFileName(key)));
  if (f.exists()) f.delete();
  
  try {
    recorder = new MediaRecorder();
    recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
    recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
    recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
    recorder.setOutputFile(sketchPath(getFileName(key)));
    recorder.prepare();
    recorder.start();
    
    state = RECORDING;
    recordingKey = key;
    recordStart = millis();
  } catch (SecurityException e) {
    println("⚠️ Немає дозволу на мікрофон – додайте й��го у в��ладці Android!");
  } catch (Exception e) {
    e.printStackTrace();
  }
}

void finishRecording() {
  if (recorder != null) {
    recorder.stop();
    recorder.release();
    recorder = null;
  }
  state = IDLE;
  recordingKey = -1;
  println("Запис кнопки " + recordingKey + " завершено.");
}

// ----- ВІДТВОРЕННЯ ВСІХ -----
void startPlayAll() {
  if (state == PLAYING_ALL) return;
  state = PLAYING_ALL;
  playIndex = 1;  // починаємо з першої кнопки (index=1)
  playNext();     // запускаємо перший існуючий трек
}

void playNext() {
  // Шукаємо наступний існуючий файл, починаючи з поточного playIndex
  while (playIndex < TOTAL) {
    File f = new File(sketchPath(getFileName(playIndex)));
    if (f.exists()) {
      // Знайшли – гр��ємо
      try {
        player = new MediaPlayer();
        player.setDataSource(f.getAbsolutePath());
        player.prepare();
        // Встановлюємо слухач завершення
        player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
          public void onCompletion(MediaPlayer mp) {
            // Поточний трек завершено – сигналізуємо про наступний
            playNextPending = true;
          }
        });
        player.start();
        playNextPending = false;  // чекаємо завершення
        println("Граємо трек " + playIndex);
        playIndex++;  // готуємо наступний індекс
        return;
      } catch (IOException e) {
        e.printStackTrace();
      }
    }
    playIndex++;
  }
  // Якщо дійшли до кінця – всі треки зіграно
  finishPlayAll();
}

void finishPlayAll() {
  if (player != null) {
    player.release();
    player = null;
  }
  state = IDLE;
  playIndex = 0;
  println("Всі треки зіграно.");
}

// Звільнення рес��рсів при закритті
void onDestroy() {
  if (recorder != null) recorder.release();
  if (player != null) player.release();
}





// Android media APIs – без Processing Sound
import android.media.MediaRecorder;
import android.media.MediaPlayer;
import java.io.File;
import java.io.IOException;

final int COLS = 9;
final int ROWS = 14;
final int TOTAL = COLS * ROWS;

// Стани
final int IDLE = 0;
final int RECORDING = 1;
final int PLAYING_ALL = 2;
int state = IDLE;

// Запис
MediaRecorder recorder;
int recordingKey = -1;
long recordStart;

// Відтворення
MediaPlayer player;
int playIndex = 0;    // який трек зараз грає
boolean playNextPending = false;

// Файли зберігаються у внутрішній пам'яті (sketchPath)
String getFileName(int idx) {
  return "key_" + idx + ".3gp";
}

void setup() {
  size(900, 700);   // зручний розмір для 9×14
  // Дозвіл на мікрофон ��� має бути доданий у вкладці Android
}

void draw() {
  background(200);
  
  float cellW = width / (float) COLS;
  float cellH = height / (float) ROWS;
  
  // Малюємо сітку
  for (int i = 0; i < TOTAL; i++) {
    int col = i % COLS;
    int row = i / COLS;
    float x = col * cellW;
    float y = row * cellH;
    
    // Колір: перша кнопка особлива
    if (i == 0) {
      fill(200, 100, 100);
    } else {
      // Чи існує файл?
      File f = new File(sketchPath(getFileName(i)));
      if (f.exists()) fill(100, 200, 100);
      else fill(150);
    }
    rect(x, y, cellW, cellH);
    
    // Номер
    fill(0);
    textAlign(CENTER, CENTER);
    textSize(12);
    text(i, x + cellW/2, y + cellH/2);
  }
  
  // Статус
  fill(0);
  textAlign(LEFT, TOP);
  textSize(16);
  if (state == RECORDING) {
    int elapsed = (int)((millis() - recordStart) / 1000);
    text("Запис кнопки " + recordingKey + " ... " + elapsed + "/10��", 10, 10);
  } else if (state == PLAYING_ALL) {
    text("Граємо всі треки... (" + playIndex + "/" + TOTAL + ")", 10, 10);
  } else {
    text("Торкніться кнопки (1–125) для запису 10с, або кнопки 0 для відтворення всіх", 10, 10);
  }
  
  // Якщо йде запис – перевіряємо таймаут
  if (state == RECORDING && (millis() - recordStart >= 10000)) {
    finishRecording();
  }
  
  // Якщо граємо всі – перевіряємо завершення поточного треку
  if (state == PLAYING_ALL && playNextPending) {
    if (player != null && !player.isPlaying()) {
      // Поточний трек скінчився – запускаємо наступний
      playNextPending = false;
      playNext();
    }
  }
}

// Визначаємо, яку кнопку натиснули
int getKeyAt(float mx, float my) {
  float cellW = width / (float) COLS;
  float cellH = height / (float) ROWS;
  int col = (int)(mx / cellW);
  int row = (int)(my / cellH);
  if (col < 0 || col >= COLS || row < 0 || row >= ROWS) return -1;
  return row * COLS + col;
}

void mousePressed() {
  if (state == RECORDING) return;   // зайнято записом
  
  int key = getKeyAt(mouseX, mouseY);
  if (key < 0 || key >= TOTAL) return;
  
  if (key == 0) {
    // Перша кнопка – граємо всі
    if (state == PLAYING_ALL) return;  // вже граємо
    startPlayAll();
  } else {
    // Інша кнопка – запис
    startRecording(key);
  }
}

// ----- ЗАПИС -----
void startRecording(int key) {
  // Видалити старий файл, якщо є
  File f = new File(sketchPath(getFileName(key)));
  if (f.exists()) f.delete();
  
  try {
    recorder = new MediaRecorder();
    recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
    recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
    recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
    recorder.setOutputFile(sketchPath(getFileName(key)));
    recorder.prepare();
    recorder.start();
    
    state = RECORDING;
    recordingKey = key;
    recordStart = millis();
  } catch (SecurityException e) {
    println("⚠️ Немає дозволу на мікрофон – додайте його у вкладці Android!");
  } catch (Exception e) {
    e.printStackTrace();
  }
}

void finishRecording() {
  if (recorder != null) {
    recorder.stop();
    recorder.release();
    recorder = null;
  }
  state = IDLE;
  recordingKey = -1;
  println("Запис кнопки " + recordingKey + " завершено.");
}

// ----- ВІДТВОРЕННЯ ВСІХ -----
void startPlayAll() {
  if (state == PLAYING_ALL) return;
  state = PLAYING_ALL;
  playIndex = 1;  // починаємо з першої кнопки (index=1)
  playNext();     // запускаємо пер��ий існуючий тр��к
}

void playNext() {
  // Шукаємо наступний існуючий файл, починаючи з поточн��го playIndex
  while (playIndex < TOTAL) {
    File f = new File(sketchPath(getFileName(playIndex)));
    if (f.exists()) {
      // Знайшли – граємо
      try {
        player = new MediaPlayer();
        player.setDataSource(f.getAbsolutePath());
        player.prepare();
        // Встановлюємо слухач завершення
        player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
          public void onCompletion(MediaPlayer mp) {
            // Поточний трек завершено – сигналізуємо про наступний
            playNextPending = true;
          }
        });
        player.start();
        playNextPending = false;  // чекаємо завершення
        println("Граємо трек " + playIndex);
        playIndex++;  // готуємо наступний індекс
        return;
      } catch (IOException e) {
        e.printStackTrace();
      }
    }
    playIndex++;
  }
  // Якщо д��йшли до кі��ця – всі треки зіграно
  finishPlayAll();
}

void finishPlayAll() {
  if (player != null) {
    player.release();
    player = null;
  }
  state = IDLE;
  playIndex = 0;
  println("Всі треки зіграно.");
}

// Звільнення ресурсів при закритті
void onDestroy() {
  if (recorder != null) recorder.release();
  if (player != null) player.release();
}



*/








































