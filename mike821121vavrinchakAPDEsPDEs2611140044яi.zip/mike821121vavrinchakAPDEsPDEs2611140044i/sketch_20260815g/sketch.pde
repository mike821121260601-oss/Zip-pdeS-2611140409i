




import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Window;
import android.view.WindowManager;

Activity act;

void setup() {
  fullScreen(P2D);

  act = getActivity();

  Window window = act.getWindow();

  // Transparent window
  window.setBackgroundDrawableResource(android.R.color.transparent);

  window.setDimAmount(0);

  window.setFlags(
    WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS,
    WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS
  );

  window.setFlags(
    WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION,
    WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION
  );

  background(0, 0);  // transparent Processing background

  noStroke();
}

void draw() {

  // DO NOT use background(255), background(0), etc.

  // Your drawing here:
  fill(255, 0, 0, 180);
  ellipse(width/2, height/2, 200, 200);
}













