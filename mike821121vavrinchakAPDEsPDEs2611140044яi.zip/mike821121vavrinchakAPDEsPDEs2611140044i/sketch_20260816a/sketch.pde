










// DOOM-STYLE FPS FOR APDE
// Processing / APDE
// Landscape Android

int cols = 16;
int rows = 16;
float cell = 80;

int[][] map = {
  {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,0,1,1,1,0,1,1,1,1,1,0,1,1,0,1},
  {1,0,1,0,0,0,0,0,0,0,1,0,0,1,0,1},
  {1,0,1,0,1,1,1,0,1,0,1,1,0,1,0,1},
  {1,0,0,0,1,0,0,0,1,0,0,0,0,1,0,1},
  {1,0,1,0,1,0,1,1,1,1,1,0,0,1,0,1},
  {1,0,1,0,0,0,1,0,0,0,1,0,0,0,0,1},
  {1,0,1,1,1,0,1,0,1,0,1,1,1,1,0,1},
  {1,0,0,0,1,0,0,0,1,0,0,0,0,1,0,1},
  {1,0,1,0,1,1,1,1,1,1,1,0,1,1,0,1},
  {1,0,1,0,0,0,0,0,0,0,0,0,0,1,0,1},
  {1,0,1,1,1,1,1,0,1,1,1,1,0,1,0,1},
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
};

float px = 120;
float py = 120;

float angle = 0;

float moveSpeed = 3.5;
float turnSpeed = 0.045;

int health = 100;
int ammo = 99;
int kills = 0;

boolean forward = false;
boolean back = false;
boolean left = false;
boolean right = false;
boolean fire = false;

float[] ex = {
  600, 1000, 1160, 520, 840
};

float[] ey = {
  280, 280, 600, 760, 1080
};

boolean[] alive = {
  true,true,true,true,true
};

void settings() {
  size(displayWidth, displayHeight, P3D);
}

void setup() {

///  orientation(LANDSCAPE);

  noStroke();

  perspective(
    PI/3.0,
    (float)width/(float)height,
    1,
    5000
  );
}

void draw() {

  background(25,25,25);

  updatePlayer();

  drawWorld();

  drawEnemies();

  drawWeapon();

  drawHUD();

  if (fire) shoot();
}


// ------------------------------------------------
// PLAYER
// ------------------------------------------------

void updatePlayer() {

  float nx = px;
  float ny = py;

  if (forward) {
    nx += cos(angle) * moveSpeed;
    ny += sin(angle) * moveSpeed;
  }

  if (back) {
    nx -= cos(angle) * moveSpeed;
    ny -= sin(angle) * moveSpeed;
  }

  if (left) {
    nx += sin(angle) * moveSpeed;
    ny -= cos(angle) * moveSpeed;
  }

  if (right) {
    nx -= sin(angle) * moveSpeed;
    ny += cos(angle) * moveSpeed;
  }

  if (!wall(nx,py)) px = nx;
  if (!wall(px,ny)) py = ny;
}


// ------------------------------------------------
// WALL TEST
// ------------------------------------------------

boolean wall(float x,float y) {

  int mx = int(x/cell);
  int my = int(y/cell);

  if (mx < 0 || my < 0 ||
      mx >= cols || my >= rows)
    return true;

  return map[my][mx] == 1;
}


// ------------------------------------------------
// 3D WORLD
// ------------------------------------------------

void drawWorld() {

  int rays = width/3;

  float FOV = PI/3.0;

  for (int i=0;i<rays;i++) {

    float ra =
      angle - FOV/2.0 +
      FOV*i/(float)rays;

    float rx = px;
    float ry = py;

    float step = 3;

    float dist = 0;

    while (dist < 2000) {

      rx += cos(ra)*step;
      ry += sin(ra)*step;

      dist += step;

      if (wall(rx,ry))
        break;
    }

    float corrected =
      dist*cos(ra-angle);

    float wallHeight =
      height*0.9/(corrected*0.012+1);

    float screenX =
      i*3;

    float top =
      height/2-wallHeight/2;

    float bottom =
      height/2+wallHeight/2;

    // floor
    fill(35);
    rect(screenX,bottom,3,height-bottom);

    // ceiling
    fill(20);
    rect(screenX,0,3,top);

    // wall
    float shade =
      constrain(255-dist/5,30,220);

    fill(shade*0.7,shade*0.35,shade*0.15);

    rect(
      screenX,
      top,
      3,
      wallHeight
    );
  }
}


// ------------------------------------------------
// ENEMIES
// ------------------------------------------------

void drawEnemies() {

  for (int i=0;i<ex.length;i++) {

    if (!alive[i]) continue;

    float dx = ex[i]-px;
    float dy = ey[i]-py;

    float distance =
      sqrt(dx*dx+dy*dy);

    float enemyAngle =
      atan2(dy,dx);

    float relative =
      atan2(
        sin(enemyAngle-angle),
        cos(enemyAngle-angle)
      );

    if (abs(relative) < PI/3.0) {

      float sx =
        width/2 +
        tan(relative)*width*0.75;

      float size =
        5000/distance;

      if (size > 10) {

        pushMatrix();

        translate(
          sx,
          height/2,
          0
        );

        fill(150,20,20);

        box(
          size*0.35,
          size*0.8,
          size*0.2
        );

        popMatrix();
      }
    }
  }
}


// ------------------------------------------------
// SHOOT
// ------------------------------------------------

void shoot() {

  if (ammo <= 0) return;

  ammo--;

  float best = 999999;
  int target = -1;

  for (int i=0;i<ex.length;i++) {

    if (!alive[i]) continue;

    float dx = ex[i]-px;
    float dy = ey[i]-py;

    float d =
      sqrt(dx*dx+dy*dy);

    float a =
      atan2(dy,dx);

    float diff =
      atan2(
        sin(a-angle),
        cos(a-angle)
      );

    if (abs(diff) < 0.08 && d < best) {

      if (!bulletWall(ex[i],ey[i])) {

        best = d;
        target = i;
      }
    }
  }

  if (target >= 0) {

    alive[target] = false;

    kills++;
  }

  fire = false;
}


// ------------------------------------------------
// BULLET LINE OF SIGHT
// ------------------------------------------------

boolean bulletWall(float x,float y) {

  float dx = x-px;
  float dy = y-py;

  float d =
    sqrt(dx*dx+dy*dy);

  int steps = int(d/5);

  for (int i=1;i<steps;i++) {

    float t =
      i/(float)steps;

    float xx =
      px+dx*t;

    float yy =
      py+dy*t;

    if (wall(xx,yy))
      return true;
  }

  return false;
}


// ------------------------------------------------
// WEAPON
// ------------------------------------------------

void drawWeapon() {

  pushMatrix();

  translate(
    width/2,
    height*0.83,
    0
  );

  fill(45);

  box(
    width*0.08,
    height*0.18,
    80
  );

  translate(0,-height*0.07,50);

  fill(20);

  box(
    width*0.025,
    height*0.12,
    100
  );

  popMatrix();
}


// ------------------------------------------------
// HUD
// ------------------------------------------------

void drawHUD() {

  camera();

  hint(DISABLE_DEPTH_TEST);

  fill(255);

  textSize(28);

  text(
    "HEALTH: "+health,
    20,
    35
  );

  text(
    "AMMO: "+ammo,
    20,
    70
  );

  text(
    "KILLS: "+kills,
    20,
    105
  );

  // crosshair

  stroke(255);

  line(
    width/2-15,
    height/2,
    width/2+15,
    height/2
  );

  line(
    width/2,
    height/2-15,
    width/2,
    height/2+15
  );

  noStroke();

  hint(ENABLE_DEPTH_TEST);
}


// ------------------------------------------------
// TOUCH CONTROLS
// ------------------------------------------------

void touchStarted() {

  if (
//touchX 
mouseX
< width*0.25 &&
     // touchY
mouseY
 > height*0.55) {

    left = true;
  }

  if (
//touchX 
mouseX
< width*0.25 &&
    //  touchY
mouseY
 < height*0.55) {

    forward = true;
  }

  if (
//touchX 
mouseX
> width*0.75 &&
      //touchY 
mouseY
> height*0.55) {

    right = true;
  }

  if (
//touchX 
mouseX
> width*0.70 &&
     // touchY 
mouseY
< height*0.45) {

    fire = true;
  }
}


void touchEnded() {

  forward = false;
  back = false;
  left = false;
  right = false;
}


// ------------------------------------------------
// KEYBOARD
// ------------------------------------------------

void keyPressed() {

  if (key == 'w' || keyCode == UP)
    forward = true;

  if (key == 's' || keyCode == DOWN)
    back = true;

  if (key == 'a' || keyCode == LEFT)
    left = true;

  if (key == 'd' || keyCode == RIGHT)
    right = true;

  if (key == ' ')
    fire = true;
}


void keyReleased() {

  if (key == 'w' || keyCode == UP)
    forward = false;

  if (key == 's' || keyCode == DOWN)
    back = false;

  if (key == 'a' || keyCode == LEFT)
    left = false;

  if (key == 'd' || keyCode == RIGHT)
    right = false;
}










