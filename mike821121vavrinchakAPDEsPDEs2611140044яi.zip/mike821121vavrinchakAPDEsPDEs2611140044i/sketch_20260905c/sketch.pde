

// Touch Draw with On-Screen Color Buttons
// Tap bottom corners to change color, top to clear

color[] colors = {#000000, #FF0000, #00FF00, #0000FF, #FFFFFF};
int colorIndex = 0;
boolean erased = false;

void setup() {
  fullScreen();
  background(255);
  strokeWeight(10);
  strokeCap(ROUND);
}

void draw() {
  // Draw line when touching in drawing area
  if (mousePressed && mouseY < height - 100) {
    stroke(colors[colorIndex]);
    line(pmouseX, pmouseY, mouseX, mouseY);
  }
  drawButtons();
}

void drawButtons() {
  // Bottom bar
  noStroke();
  fill(200);
  rect(0, height - 100, width, 100);

  // Color buttons
  int buttonSize = 60;
  int y = height - 80;

  // Black
  fill(0);
  ellipse(width/2 - 100, y + 30, buttonSize, buttonSize);

  // Red
  fill(255, 0, 0);
  ellipse(width/2 - 30, y + 30, buttonSize, buttonSize);

  // Blue
  fill(0, 0, 255);
  ellipse(width/2 + 40, y + 30, buttonSize, buttonSize);

  // Green
  fill(0, 255, 0);
  ellipse(width/2 + 110, y + 30, buttonSize, buttonSize);

  // Clear button
  fill(150);
  rect(width - 120, y, 100, 60);
  fill(0);
  textSize(20);
  textAlign(CENTER, CENTER);
  text("CLEAR", width - 70, y + 30);
}

void mousePressed() {
  int y = height - 80;

  // Check color buttons
  if (mouseY > height - 100) {
    if (dist(mouseX, mouseY, width/2 - 100, y + 30) < 30) {
      colors[colorIndex] = color(0); // Black
      colorIndex = 0;
    } else if (dist(mouseX, mouseY, width/2 - 30, y + 30) < 30) {
      colors[colorIndex] = color(255, 0, 0); // Red
      colorIndex = 1;
    } else if (dist(mouseX, mouseY, width/2 + 40, y + 30) < 30) {
      colors[colorIndex] = color(0, 0, 255); // Blue
      colorIndex = 2;
    } else if (dist(mouseX, mouseY, width/2 + 110, y + 30) < 30) {
      colors[colorIndex] = color(0, 255, 0); // Green
      colorIndex = 3;
    } else if (mouseX > width - 120 && mouseX < width - 20 && 
               mouseY > y && mouseY < y + 60) {
      background(255); // Clear
    }
  }
}

