
/////OOOOKKKK//GROK//MY IDEA//

// ============================================================
//  FIVE-IN-A-ROW  •  55×55  •  APDE / Processing for Android
//  Human (Black) vs Engine (White)
// ============================================================

final int BOARD_SIZE = 55;
final int WIN_LENGTH = 5;
final int EMPTY = 0;
final int HUMAN = 1;   // Black
final int AI    = 2;   // White

int[][] board = new int[BOARD_SIZE][BOARD_SIZE];
ArrayList<int[]> history = new ArrayList<int[]>();

int cellSize;
float offsetX, offsetY;
int lastY = -1, lastX = -1;
boolean humanTurn = true;
boolean gameOver = false;
String statusMsg = "Your turn (Black ●)";
int winner = 0;

// Touch / pan
float panX = 0, panY = 0;
float lastTouchX, lastTouchY;
boolean isDragging = false;

void setup() {
  fullScreen();
  orientation(PORTRAIT);
  
  // Calculate cell size so the board fits reasonably
  cellSize = min(width, height) / 18;   // show \~18 cells on screen
  offsetX = (width  - BOARD_SIZE * cellSize) / 2.0;
  offsetY = (height - BOARD_SIZE * cellSize) / 2.0 + 40;
  
  textAlign(CENTER, CENTER);
  textSize(28);
}

void draw() {
  background(30, 30, 40);
  
  // Title bar
  fill(20, 20, 30);
  rect(0, 0, width, 80);
  fill(255);
  textSize(32);
  text("Five-in-a-Row 55×55", width/2, 40);
  
  // Status
  fill(200);
  textSize(26);
  text(statusMsg, width/2, height - 50);
  
  // Draw board (with panning)
  pushMatrix();
  translate(panX, panY);
  
  // Grid background
  fill(210, 180, 140);
  noStroke();
  rect(offsetX - 10, offsetY - 10, 
       BOARD_SIZE * cellSize + 20, 
       BOARD_SIZE * cellSize + 20);
  
  // Grid lines
  stroke(80, 50, 20);
  strokeWeight(1);
  for (int i = 0; i <= BOARD_SIZE; i++) {
    line(offsetX, offsetY + i * cellSize,
         offsetX + BOARD_SIZE * cellSize, offsetY + i * cellSize);
    line(offsetX + i * cellSize, offsetY,
         offsetX + i * cellSize, offsetY + BOARD_SIZE * cellSize);
  }
  
  // Stones
  noStroke();
  for (int y = 0; y < BOARD_SIZE; y++) {
    for (int x = 0; x < BOARD_SIZE; x++) {
      float cx = offsetX + x * cellSize + cellSize/2;
      float cy = offsetY + y * cellSize + cellSize/2;
      
      if (board[y][x] == HUMAN) {
        fill(20);
        ellipse(cx, cy, cellSize * 0.85, cellSize * 0.85);
      } else if (board[y][x] == AI) {
        fill(245);
        ellipse(cx, cy, cellSize * 0.85, cellSize * 0.85);
        stroke(100);
        strokeWeight(1);
        noFill();
        ellipse(cx, cy, cellSize * 0.85, cellSize * 0.85);
        noStroke();
      }
      
      // Highlight last move
      if (y == lastY && x == lastX) {
        stroke(255, 50, 50);
        strokeWeight(3);
        noFill();
        ellipse(cx, cy, cellSize * 0.95, cellSize * 0.95);
        noStroke();
      }
    }
  }
  
  popMatrix();
  
  // Game over overlay
  if (gameOver) {
    fill(0, 180);
    rect(0, height/2 - 80, width, 160);
    fill(255);
    textSize(42);
    if (winner == HUMAN) text("YOU WIN!", width/2, height/2 - 20);
    else if (winner == AI) text("ENGINE WINS!", width/2, height/2 - 20);
    else text("DRAW", width/2, height/2 - 20);
    
    textSize(26);
    text("Tap anywhere to restart", width/2, height/2 + 40);
  }
}

// ===================== TOUCH =====================
void mousePressed() {
  if (gameOver) {
    restartGame();
    return;
  }
  
  lastTouchX = mouseX;
  lastTouchY = mouseY;
  isDragging = false;
}

void mouseDragged() {
  float dx = mouseX - lastTouchX;
  float dy = mouseY - lastTouchY;
  
  if (abs(dx) > 8 || abs(dy) > 8) {
    isDragging = true;
    panX += dx;
    panY += dy;
    lastTouchX = mouseX;
    lastTouchY = mouseY;
  }
}

void mouseReleased() {
  if (isDragging || !humanTurn || gameOver) return;
  
  // Convert screen → board coordinates
  float bx = (mouseX - panX - offsetX) / cellSize;
  float by = (mouseY - panY - offsetY) / cellSize;
  
  int x = floor(bx);
  int y = floor(by);
  
  if (x >= 0 && x < BOARD_SIZE && y >= 0 && y < BOARD_SIZE) {
    if (board[y][x] == EMPTY) {
      placeStone(y, x, HUMAN);
      lastY = y;
      lastX = x;
      
      if (checkWin(y, x, HUMAN)) {
        gameOver = true;
        winner = HUMAN;
        statusMsg = "You win!";
        return;
      }
      
      humanTurn = false;
      statusMsg = "Engine thinking...";
      
      // Run AI on next frame so UI stays responsive
      thread("engineThink");
    }
  }
}

// ===================== GAME LOGIC =====================
void placeStone(int y, int x, int player) {
  board[y][x] = player;
  history.add(new int[]{y, x, player});
}

boolean checkWin(int y, int x, int player) {
  int[][] dirs = {{0,1},{1,0},{1,1},{1,-1}};
  
  for (int[] d : dirs) {
    int count = 1;
    count += countDir(y, x, d[0], d[1], player);
    count += countDir(y, x, -d[0], -d[1], player);
    if (count >= WIN_LENGTH) return true;
  }
  return false;
}

int countDir(int y, int x, int dy, int dx, int player) {
  int c = 0;
  int ny = y + dy;
  int nx = x + dx;
  while (ny >= 0 && ny < BOARD_SIZE && nx >= 0 && nx < BOARD_SIZE 
         && board[ny][nx] == player) {
    c++;
    ny += dy;
    nx += dx;
  }
  return c;
}

// ===================== ENGINE =====================
void engineThink() {
  int[] move = findBestMove();
  int y = move[0];
  int x = move[1];
  
  placeStone(y, x, AI);
  lastY = y;
  lastX = x;
  
  if (checkWin(y, x, AI)) {
    gameOver = true;
    winner = AI;
    statusMsg = "Engine wins!";
  } else {
    humanTurn = true;
    statusMsg = "Your turn (Black ●)";
  }
}

int[] findBestMove() {
  ArrayList<int[]> candidates = getCandidates(2);
  
  if (candidates.isEmpty()) {
    int c = BOARD_SIZE / 2;
    return new int[]{c, c};
  }
  
  int bestScore = Integer.MIN_VALUE;
  ArrayList<int[]> bestMoves = new ArrayList<int[]>();
  
  for (int[] pos : candidates) {
    int y = pos[0];
    int x = pos[1];
    int score = evaluate(y, x, AI);
    
    // slight center preference
    int dist = abs(y - BOARD_SIZE/2) + abs(x - BOARD_SIZE/2);
    score -= dist / 8;
    
    if (score > bestScore) {
      bestScore = score;
      bestMoves.clear();
      bestMoves.add(pos);
    } else if (score == bestScore) {
      bestMoves.add(pos);
    }
  }
  
  return bestMoves.get((int)random(bestMoves.size()));
}

ArrayList<int[]> getCandidates(int radius) {
  ArrayList<int[]> list = new ArrayList<int[]>();
  boolean[][] seen = new boolean[BOARD_SIZE][BOARD_SIZE];
  
  if (history.isEmpty()) {
    int c = BOARD_SIZE / 2;
    for (int dy = -2; dy <= 2; dy++)
      for (int dx = -2; dx <= 2; dx++)
        list.add(new int[]{c+dy, c+dx});
    return list;
  }
  
  for (int[] m : history) {
    int y = m[0], x = m[1];
    for (int dy = -radius; dy <= radius; dy++) {
      for (int dx = -radius; dx <= radius; dx++) {
        int ny = y + dy;
        int nx = x + dx;
        if (ny >= 0 && ny < BOARD_SIZE && nx >= 0 && nx < BOARD_SIZE 
            && board[ny][nx] == EMPTY && !seen[ny][nx]) {
          seen[ny][nx] = true;
          list.add(new int[]{ny, nx});
        }
      }
    }
  }
  return list;
}

int evaluate(int y, int x, int player) {
  int score = 0;
  int opponent = (player == AI) ? HUMAN : AI;
  
  // Place temporarily
  board[y][x] = player;
  score += scoreThreats(y, x, player);
  
  // Block opponent
  board[y][x] = opponent;
  score += scoreThreats(y, x, opponent) * 0.9;   // slightly prefer own threats
  
  board[y][x] = EMPTY;
  return score;
}

int scoreThreats(int y, int x, int player) {
  int score = 0;
  int[][] dirs = {{0,1},{1,0},{1,1},{1,-1}};
  
  for (int[] d : dirs) {
    int forward = countDir(y, x, d[0], d[1], player);
    int backward = countDir(y, x, -d[0], -d[1], player);
    int total = forward + backward + 1;
    
    int openEnds = 0;
    int fy = y + (forward+1)*d[0];
    int fx = x + (forward+1)*d[1];
    if (fy>=0 && fy<BOARD_SIZE && fx>=0 && fx<BOARD_SIZE && board[fy][fx]==EMPTY)
      openEnds++;
      
    int by = y - (backward+1)*d[0];
    int bx = x - (backward+1)*d[1];
    if (by>=0 && by<BOARD_SIZE && bx>=0 && bx<BOARD_SIZE && board[by][bx]==EMPTY)
      openEnds++;
    
    if (total >= 5) score += 100000;
    else if (total == 4) {
      if (openEnds >= 1) score += 10000;
      else score += 400;
    }
    else if (total == 3) {
      if (openEnds == 2) score += 4500;
      else if (openEnds == 1) score += 250;
    }
    else if (total == 2) {
      if (openEnds == 2) score += 120;
      else if (openEnds == 1) score += 25;
    }
  }
  return score;
}

void restartGame() {
  for (int y = 0; y < BOARD_SIZE; y++)
    for (int x = 0; x < BOARD_SIZE; x++)
      board[y][x] = EMPTY;
      
  history.clear();
  lastY = lastX = -1;
  humanTurn = true;
  gameOver = false;
  winner = 0;
  statusMsg = "Your turn (Black ●)";
  panX = panY = 0;
}




















