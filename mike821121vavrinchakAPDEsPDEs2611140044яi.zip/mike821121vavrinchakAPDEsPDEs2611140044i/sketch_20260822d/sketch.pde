// APDE – 2 Random Polygons + Bouncing Circle
// Circle changes angle on screen edges AND on polygon sides

float playerX, playerY;
float playerR = 20;
float angle = random(TWO_PI);
float speed = 5.5;

// Two polygons
PShape poly1, poly2;
float rot1 = 0, rot2 = 0;
float rotSpeed1, rotSpeed2;
float poly1X, poly1Y, poly2X, poly2Y;
float polySize;

// Store the actual vertices of each polygon (for collision)
float[][] verts1, verts2;

void setup() {
  size(displayWidth, displayHeight);
  // size(900, 1600);

  float minSide = min(width, height);
  polySize = random(minSide * 0.20, minSide * 0.25);

  // Create polygons and keep their vertices
  int sides1 = int(random(3, 101));
  int sides2 = int(random(3, 101));
  
  verts1 = createRandomVerts(sides1, polySize);
  verts2 = createRandomVerts(sides2, polySize);
  
  poly1 = makeShape(verts1);
  poly2 = makeShape(verts2);

  rotSpeed1 = random(0.1, 0.2) * (random(1) > 0.5 ? 1 : -1);
  rotSpeed2 = random(0.1, 0.2) * (random(1) > 0.5 ? 1 : -1);

  poly1X = width * 0.30;
  poly1Y = height * 0.42;
  poly2X = width * 0.70;
  poly2Y = height * 0.58;

  // Start position
  playerX = width * 0.5;
  playerY = height * 0.12;
}

void draw() {
  background(12);

  // ---- Rotate polygons ----
  rot1 += rotSpeed1;
  rot2 += rotSpeed2;

  // ---- Draw polygons ----
  pushMatrix();
  translate(poly1X, poly1Y);
  rotate(radians(rot1));
  shape(poly1, 0, 0);
  popMatrix();

  pushMatrix();
  translate(poly2X, poly2Y);
  rotate(radians(rot2));
  shape(poly2, 0, 0);
  popMatrix();

  // ---- Move ball ----
  float nextX = playerX + cos(angle) * speed;
  float nextY = playerY + sin(angle) * speed;

  // 1. Bounce on screen edges
  if (nextX - playerR < 0 || nextX + playerR > width) {
    angle = PI - angle;                     // reflect horizontally
    nextX = constrain(nextX, playerR, width - playerR);
  }
  if (nextY - playerR < 0 || nextY + playerR > height) {
    angle = -angle;                         // reflect vertically
    nextY = constrain(nextY, playerR, height - playerR);
  }

  // 2. Bounce on polygon sides
  if (hitsPolygon(nextX, nextY, verts1, poly1X, poly1Y, rot1) ||
      hitsPolygon(nextX, nextY, verts2, poly2X, poly2Y, rot2)) {
    
    // Simple reflection: reverse direction + small random tweak
    angle += PI + random(-0.4, 0.4);
  }

  playerX = nextX;
  playerY = nextY;

  // Keep inside screen just in case
  playerX = constrain(playerX, playerR, width - playerR);
  playerY = constrain(playerY, playerR, height - playerR);

  // ---- Draw ball ----
  fill(255, 70, 70);
  noStroke();
  ellipse(playerX, playerY, playerR * 2, playerR * 2);

  // Direction line
  stroke(255);
  strokeWeight(2);
  line(playerX, playerY,
       playerX + cos(angle) * playerR * 1.6,
       playerY + sin(angle) * playerR * 1.6);
}

// ---------- Helpers ----------

float[][] createRandomVerts(int sides, float size) {
  float[][] v = new float[sides][2];
  float radius = size * 0.48;
  for (int i = 0; i < sides; i++) {
    float a = TWO_PI * i / sides + random(-0.22, 0.22);
    float r = radius * random(0.78, 1.05);
    v[i][0] = cos(a) * r;
    v[i][1] = sin(a) * r;
  }
  return v;
}

PShape makeShape(float[][] verts) {
  PShape s = createShape();
  s.beginShape();
  s.noFill();
  s.stroke(160, 220, 255);
  s.strokeWeight(2.5);
  for (int i = 0; i < verts.length; i++) {
    s.vertex(verts[i][0], verts[i][1]);
  }
  s.endShape(CLOSE);
  return s;
}

// Check if circle hits any side of a rotating polygon
boolean hitsPolygon(float cx, float cy, float[][] verts, float px, float py, float rotDeg) {
  float rot = radians(rotDeg);
  int n = verts.length;

  for (int i = 0; i < n; i++) {
    // Transform vertices to screen space
    float x1 = verts[i][0];
    float y1 = verts[i][1];
    float x2 = verts[(i + 1) % n][0];
    float y2 = verts[(i + 1) % n][1];

    // Rotate + translate
    float rx1 = px + x1 * cos(rot) - y1 * sin(rot);
    float ry1 = py + x1 * sin(rot) + y1 * cos(rot);
    float rx2 = px + x2 * cos(rot) - y2 * sin(rot);
    float ry2 = py + x2 * sin(rot) + y2 * cos(rot);

    // Distance from circle center to the line segment
    if (distToSegment(cx, cy, rx1, ry1, rx2, ry2) < playerR) {
      return true;
    }
  }
  return false;
}

// Distance from point to line segment
float distToSegment(float px, float py, float x1, float y1, float x2, float y2) {
  float dx = x2 - x1;
  float dy = y2 - y1;
  float len2 = dx * dx + dy * dy;
  if (len2 == 0) return dist(px, py, x1, y1);

  float t = constrain(((px - x1) * dx + (py - y1) * dy) / len2, 0, 1);
  float projX = x1 + t * dx;
  float projY = y1 + t * dy;
  return dist(px, py, projX, projY);
}

// Optional manual control
void keyPressed() {
  if (keyCode == LEFT)  angle -= 0.25;
  if (keyCode == RIGHT) angle += 0.25;
}

void mousePressed() {
  if (mouseX < width / 2) angle -= 0.35;
  else                    angle += 0.35;
}
































