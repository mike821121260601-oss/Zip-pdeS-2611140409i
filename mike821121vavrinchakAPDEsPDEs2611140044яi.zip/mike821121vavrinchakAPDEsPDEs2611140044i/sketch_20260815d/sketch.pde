











// APDE 3D SPHERE SHOOTER
// Random 10 x 10 3D mountains + many walls
// Red spheres = targets
// Touch = shoot / aim
// Buttons = move

int N = 10;
float cell = 180;

float[][] mountain = new float[N][N];

int WALLS = 45;
float[] wx = new float[WALLS];
float[] wz = new float[WALLS];
float[] ww = new float[WALLS];
float[] wh = new float[WALLS];
float[] wd = new float[WALLS];

int ENEMIES = 20;
float[] ex = new float[ENEMIES];
float[] ey = new float[ENEMIES];
float[] ez = new float[ENEMIES];
boolean[] alive = new boolean[ENEMIES];

float px = 0;
float py = 65;
float pz = 0;

float angle = 0;
float pitch = 0;

float speed = 7;

int score = 0;

boolean shooting = false;

void settings() {
  fullScreen(P3D);
}

void setup() {


///  orientation(LANDSCAPE);



  noStroke();

  // -------------------------
  // RANDOM MOUNTAINS
  // -------------------------
  for (int z=0; z<N; z++) {
    for (int x=0; x<N; x++) {

      mountain[x][z] = random(20,130);

    }
  }

  // -------------------------
  // RANDOM WALLS
  // -------------------------
  for (int i=0; i<WALLS; i++) {

    wx[i] = random(-N*cell/2, N*cell/2);
    wz[i] = random(-N*cell/2, N*cell/2);

    ww[i] = random(40,160);
    wd[i] = random(20,80);
    wh[i] = random(50,180);
  }

  // -------------------------
  // RANDOM ENEMIES
  // -------------------------
  for (int i=0; i<ENEMIES; i++) {
    newEnemy(i);
  }
}


// =====================================================
// CREATE ENEMY
// =====================================================

void newEnemy(int i) {

  ex[i] = random(-N*cell/2, N*cell/2);
  ez[i] = random(-N*cell/2, N*cell/2);

  ey[i] = random(40,130);

  alive[i] = true;
}


// =====================================================
// DRAW
// =====================================================

void draw() {

  background(100,150,210);

  lights();

  // camera direction
  float dx = cos(angle) * cos(pitch);
  float dy = sin(pitch);
  float dz = sin(angle) * cos(pitch);

  camera(
    px, py, pz,
    px+dx*500,
    py+dy*500,
    pz+dz*500,
    0,1,0
  );

  // -------------------------
  // SUN
  // -------------------------

  directionalLight(
    255,255,255,
    -0.5,-1,-0.3
  );

  // -------------------------
  // GROUND / MOUNTAINS
  // -------------------------

  drawMountains();

  // -------------------------
  // WALLS
  // -------------------------

  drawWalls();

  // -------------------------
  // ENEMIES
  // -------------------------

  drawEnemies();

  // -------------------------
  // CROSSHAIR
  // -------------------------

  drawCrosshair();

  // -------------------------
  // TOUCH BUTTONS
  // -------------------------

  drawControls();

  // -------------------------
  // TEXT
  // -------------------------

  fill(255);
  textSize(30);
  text("SCORE: "+score,30,45);
}


// =====================================================
// MOUNTAINS 10 x 10
// =====================================================

void drawMountains() {

  for (int z=0; z<N-1; z++) {

    for (int x=0; x<N-1; x++) {

      float x1 = x*cell-N*cell/2;
      float z1 = z*cell-N*cell/2;

      float x2 = (x+1)*cell-N*cell/2;
      float z2 = (z+1)*cell-N*cell/2;

      fill(
        50 + x*5,
        110 + z*4,
        50
      );

      beginShape(TRIANGLES);

      vertex(
        x1,
        mountain[x][z],
        z1
      );

      vertex(
        x2,
        mountain[x+1][z],
        z1
      );

      vertex(
        x1,
        mountain[x][z+1],
        z2
      );


      vertex(
        x2,
        mountain[x+1][z],
        z1
      );

      vertex(
        x2,
        mountain[x+1][z+1],
        z2
      );

      vertex(
        x1,
        mountain[x][z+1],
        z2
      );

      endShape();
    }
  }
}


// =====================================================
// WALLS
// =====================================================

void drawWalls() {

  for (int i=0; i<WALLS; i++) {

    pushMatrix();

    translate(
      wx[i],
      wh[i]/2,
      wz[i]
    );

    fill(
      100 + (i*17)%100,
      70,
      50
    );

    box(
      ww[i],
      wh[i],
      wd[i]
    );

    popMatrix();
  }
}


// =====================================================
// ENEMIES
// =====================================================

void drawEnemies() {

  for (int i=0; i<ENEMIES; i++) {

    if (!alive[i]) continue;

    pushMatrix();

    translate(
      ex[i],
      ey[i],
      ez[i]
    );

    fill(255,0,0);

    sphere(35);

    // small white eye
    pushMatrix();

    translate(
      10,
      -10,
      -30
    );

    fill(255);

    sphere(8);

    popMatrix();

    popMatrix();
  }
}


// =====================================================
// SHOOT
// =====================================================

void shoot() {

  float dx = cos(angle) * cos(pitch);
  float dy = sin(pitch);
  float dz = sin(angle) * cos(pitch);

  for (int i=0; i<ENEMIES; i++) {

    if (!alive[i]) continue;

    float vx = ex[i] - px;
    float vy = ey[i] - py;
    float vz = ez[i] - pz;

    float distance =
      sqrt(vx*vx + vy*vy + vz*vz);

    if (distance > 1500) continue;

    vx /= distance;
    vy /= distance;
    vz /= distance;

    float dot =
      dx*vx +
      dy*vy +
      dz*vz;

    // target is close to crosshair
    if (dot > 0.985) {

      alive[i] = false;

      score++;

      // immediately create another target
      newEnemy(i);

      break;
    }
  }
}


// =====================================================
// CROSSHAIR
// =====================================================

void drawCrosshair() {

  hint(DISABLE_DEPTH_TEST);

  camera();

  stroke(255);
  strokeWeight(4);

  float cx = width/2;
  float cy = height/2;

  line(cx-25,cy,cx-5,cy);
  line(cx+5,cy,cx+25,cy);

  line(cx,cy-25,cx,cy-5);
  line(cx,cy+5,cx,cy+25);

  noStroke();

  hint(ENABLE_DEPTH_TEST);
}


// =====================================================
// CONTROLS
// =====================================================

void drawControls() {

  hint(DISABLE_DEPTH_TEST);

  camera();

  fill(255,255,255,80);

  // LEFT
  ellipse(100,height-120,100,100);

  // RIGHT
  ellipse(300,height-120,100,100);

  // FORWARD
  ellipse(width-170,height-170,110,110);

  // SHOOT
  fill(255,0,0,130);

  ellipse(
    width-120,
    height-80,
    120,
    120
  );

  hint(ENABLE_DEPTH_TEST);
}


// =====================================================
// TOUCH
// =====================================================

void touchStarted() {

  if (mouseX > width-190 &&
      mouseY > height-140) {

    shoot();

    shooting = true;

    return;
  }

  if (mouseX < 180 &&
      mouseY > height-180) {

    angle -= 0.12;

    return;
  }

  if (mouseX < 360 &&
      mouseY > height-180) {

    angle += 0.12;

    return;
  }

  // aim
  angle +=
    (mouseX-width/2)*0.003;

  pitch +=
    (mouseY-height/2)*0.002;

  pitch = constrain(
    pitch,
    -1.2,
    1.2
  );
}


// =====================================================
// HOLD / MOVE
// =====================================================

void touchMoved() {

  float mx =
    (mouseX-width/2)*0.002;

  float my =
    (mouseY-height/2)*0.002;

  angle += mx;

  pitch += my;

  pitch = constrain(
    pitch,
    -1.2,
    1.2
  );
}


void touchEnded() {

  shooting = false;
}






















