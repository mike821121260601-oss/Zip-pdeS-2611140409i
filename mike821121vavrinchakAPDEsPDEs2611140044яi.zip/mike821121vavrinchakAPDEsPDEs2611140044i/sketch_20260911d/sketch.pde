


/**
 * Android Sound Example – 2 sounds in one sketch
 * Works with Processing Android Mode / APDE
 * Put sound1.mp3 and sound2.mp3 in the data folder
 */

import android.media.MediaPlayer;
import android.content.res.AssetFileDescriptor;
import android.content.Context;
import android.app.Activity;

MediaPlayer mp1, mp2;
Context context;
Activity act;
AssetFileDescriptor afd1, afd2;

// Button areas (bigger size as requested)
float btn1X, btn1Y, btn1W, btn1H;
float btn2X, btn2Y, btn2W, btn2H;

void setup() {
  fullScreen();
  orientation(PORTRAIT);   // or LANDSCAPE
  textAlign(CENTER, CENTER);
  textSize(48);

  // Make buttons bigger
  btn1W = width * 0.7;
  btn1H = height * 0.18;
  btn1X = (width - btn1W) / 2;
  btn1Y = height * 0.25;

  btn2W = width * 0.7;
  btn2H = height * 0.18;
  btn2X = (width - btn2W) / 2;
  btn2Y = height * 0.55;

  act = this.getActivity();
  context = act.getApplicationContext();

  try {
    // Sound 1
    mp1 = new MediaPlayer();
    afd1 = context.getAssets().openFd("sound1.mp3");
    mp1.setDataSource(afd1.getFileDescriptor(), afd1.getStartOffset(), afd1.getLength());
    mp1.prepare();

    // Sound 2
    mp2 = new MediaPlayer();
    afd2 = context.getAssets().openFd("sound2.mp3");
    mp2.setDataSource(afd2.getFileDescriptor(), afd2.getStartOffset(), afd2.getLength());
    mp2.prepare();

    println("Sounds loaded OK");
  } 
  catch (Exception e) {
    println("Error loading sounds: " + e);
  }
}

void draw() {
  background(30);

  // Button 1
  fill(0, 180, 80);
  rect(btn1X, btn1Y, btn1W, btn1H, 30);
  fill(255);
  text("PLAY SOUND 1", btn1X + btn1W/2, btn1Y + btn1H/2);

  // Button 2
  fill(0, 120, 220);
  rect(btn2X, btn2Y, btn2W, btn2H, 30);
  fill(255);
  text("PLAY SOUND 2", btn2X + btn2W/2, btn2Y + btn2H/2);

  fill(200);
  textSize(32);
  text("Tap a button", width/2, height * 0.12);
  textSize(48);
}

void mousePressed() {
  // Sound 1
  if (mouseX > btn1X && mouseX < btn1X + btn1W &&
      mouseY > btn1Y && mouseY < btn1Y + btn1H) {
    playSound(mp1);
  }

  // Sound 2
  if (mouseX > btn2X && mouseX < btn2X + btn2W &&
      mouseY > btn2Y && mouseY < btn2Y + btn2H) {
    playSound(mp2);
  }
}

void playSound(MediaPlayer mp) {
  if (mp == null) return;
  try {
    if (mp.isPlaying()) {
      mp.seekTo(0);          // restart from beginning
    } else {
      mp.start();
    }
  } 
  catch (Exception e) {
    println("Play error: " + e);
  }
}

// Clean up when the app pauses / stops
public void pause() {
  super.pause();
  releasePlayers();
}

public void stop() {
  super.stop();
  releasePlayers();
}

void releasePlayers() {
  if (mp1 != null) {
    mp1.release();
    mp1 = null;
  }
  if (mp2 != null) {
    mp2.release();
    mp2 = null;
  }
}







