



/*
 ============================================================
*/


/*
 ============================================================
 CHESS ANALYZER OVERLAY
 ONE FILE / APDE 0.5.3
 ============================================================

 Local chess engine:
   - legal chess moves
   - check detection
   - castling
   - en-passant
   - promotion
   - alpha-beta search
   - material + positional evaluation
   - BEST MOVE
   - FEN input

 Overlay:
   - transparent drawing
   - arrows/lines
   - erase
   - clear
   - hide
   - timer
   - depth controls

 IMPORTANT:
 SYSTEM_ALERT_WINDOW permission is required for a real
 Android overlay.
 ============================================================
*/

import android.app.Activity;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.ArrayList;

Activity act;
WindowManager wm;
ChessView view;

void setup() {
  fullScreen();
  orientation(LANDSCAPE);

  act = this.getActivity();

  act.getWindow().setBackgroundDrawable(
    new ColorDrawable(Color.TRANSPARENT)
  );

  act.getWindow().setFormat(
    android.graphics.PixelFormat.TRANSLUCENT
  );

  if (Build.VERSION.SDK_INT >= 23) {
    if (!Settings.canDrawOverlays(act)) {
      try {
        Intent i = new Intent(
          Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
          Uri.parse("package:" + act.getPackageName())
        );
        act.startActivity(i);
      }
      catch(Exception e) {
        act.startActivity(
          new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
        );
      }
      return;
    }
  }

  startOverlay();
}

void startOverlay() {

  wm = (WindowManager)
    act.getSystemService(Context.WINDOW_SERVICE);

  view = new ChessView(act);

  WindowManager.LayoutParams p =
    new WindowManager.LayoutParams();

  p.width =
    WindowManager.LayoutParams.MATCH_PARENT;

  p.height =
    WindowManager.LayoutParams.MATCH_PARENT;

  if (Build.VERSION.SDK_INT >= 26)
    p.type =
      WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
  else
    p.type =
      WindowManager.LayoutParams.TYPE_PHONE;

  p.flags =
      WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
    | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
    | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
    | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;

  p.format =
    android.graphics.PixelFormat.TRANSLUCENT;

  p.gravity =
    Gravity.TOP | Gravity.LEFT;

  try {
    wm.addView(view,p);
  }
  catch(Exception e) {
    Toast.makeText(
      act,
      "Overlay error: " + e,
      Toast.LENGTH_LONG
    ).show();
  }
}

void draw() {
  background(0,0);
}


// ============================================================
// CHESS VIEW
// ============================================================

class ChessView extends View {

  Paint p = new Paint();
  Paint text = new Paint();

  Board board = new Board();

  ArrayList<DrawLine> drawings =
    new ArrayList<DrawLine>();

  int sq = 70;
  int bx = 20;
  int by = 125;

  int selected = -1;

  int bestFrom = -1;
  int bestTo = -1;

  boolean showPanel = true;
  boolean eraseMode = false;
  boolean drawMode = false;

  int drawColor = Color.RED;

  float lastX,lastY;

  int depth = 3;

  long thinkingStart;

  String status = "READY";

  long timer = 300;
  long timerLast;

  ChessView(Context c) {
    super(c);

    p.setAntiAlias(true);

    text.setAntiAlias(true);
    text.setTypeface(
      Typeface.create(
        Typeface.DEFAULT,
        Typeface.BOLD
      )
    );

    timerLast =
      System.currentTimeMillis();
  }

  protected void onDraw(Canvas c) {

    c.drawColor(
      Color.TRANSPARENT,
      PorterDuff.Mode.CLEAR
    );

    drawBoard(c);

    drawArrows(c);

    if (showPanel)
      drawPanel(c);

    updateTimer();

    invalidate();
  }


  // ==========================================================
  // BOARD
  // ==========================================================

  void drawBoard(Canvas c) {

    int s = sq;

    for (int r=0;r<8;r++) {

      for (int f=0;f<8;f++) {

        int col;

        if ((r+f)%2==0)
          col = Color.rgb(238,238,210);
        else
          col = Color.rgb(118,150,86);

        p.setColor(col);

        c.drawRect(
          bx+f*s,
          by+r*s,
          bx+(f+1)*s,
          by+(r+1)*s,
          p
        );

        int pos =
          r*8+f;

        if (pos==selected) {
          p.setColor(
            Color.argb(130,255,220,0)
          );

          c.drawRect(
            bx+f*s,
            by+r*s,
            bx+(f+1)*s,
            by+(r+1)*s,
            p
          );
        }

        if (pos==bestFrom ||
            pos==bestTo) {

          p.setColor(
            Color.argb(120,0,180,255)
          );

          c.drawRect(
            bx+f*s,
            by+r*s,
            bx+(f+1)*s,
            by+(r+1)*s,
            p
          );
        }

        char pc =
          board.b[pos];

        if (pc!='.') {

          text.setTextSize(
            s*0.72f
          );

          text.setTextAlign(
            Paint.Align.CENTER
          );

          boolean white =
            Character.isUpperCase(pc);

          text.setColor(
            white ?
            Color.WHITE :
            Color.BLACK
          );

          String piece =
            pieceText(pc);

          // shadow
          text.setStyle(
            Paint.Style.FILL
          );

          if (white) {

            text.setShadowLayer(
              5,2,2,Color.BLACK
            );

          } else {

            text.setShadowLayer(
              3,1,1,Color.WHITE
            );
          }

          c.drawText(
            piece,
            bx+f*s+s/2,
            by+r*s+s*0.78f,
            text
          );

          text.clearShadowLayer();
        }
      }
    }
  }


  String pieceText(char pc) {

    switch(pc) {

    case 'K': return "♔";
    case 'Q': return "♕";
    case 'R': return "♖";
    case 'B': return "♗";
    case 'N': return "♘";
    case 'P': return "♙";

    case 'k': return "♚";
    case 'q': return "♛";
    case 'r': return "♜";
    case 'b': return "♝";
    case 'n': return "♞";
    case 'p': return "♟";
    }

    return "";
  }


  // ==========================================================
  // PANEL
  // ==========================================================

  void drawPanel(Canvas c) {

    int w=getWidth();

    p.setColor(
      Color.argb(205,20,20,20)
    );

    c.drawRoundRect(
      new RectF(
        5,5,w-5,110
      ),
      15,15,p
    );

    button(c,10,15,95,55,"BEST");

    button(c,100,15,170,55,"DEPTH-");

    button(c,175,15,245,55,"DEPTH+");

    button(c,250,15,325,55,"CLEAR");

    button(c,330,15,405,55,"ERASE");

    button(c,410,15,485,55,"HIDE");

    button(c,490,15,565,55,"BACK");

    button(c,570,15,645,55,"FEN");

    button(c,650,15,715,55,"NEW");

    text.setTextSize(18);
    text.setColor(Color.WHITE);
    text.setTextAlign(Paint.Align.LEFT);

    c.drawText(
      "DEPTH " + depth,
      10,90,text
    );

    c.drawText(
      status,
      130,90,text
    );

    c.drawText(
      formatTime(timer),
      600,90,text
    );
  }


  void button(
    Canvas c,
    float x1,float y1,
    float x2,float y2,
    String s
  ) {

    p.setColor(
      Color.argb(230,55,55,55)
    );

    c.drawRoundRect(
      new RectF(
        x1,y1,x2,y2
      ),
      8,8,p
    );

    text.setTextSize(13);
    text.setColor(Color.WHITE);
    text.setTextAlign(Paint.Align.CENTER);

    c.drawText(
      s,
      (x1+x2)/2,
      y1+26,
      text
    );

    text.setTextAlign(Paint.Align.LEFT);
  }


  // ==========================================================
  // TOUCH
  // ==========================================================

  public boolean onTouchEvent(MotionEvent e) {

    float x=e.getX();
    float y=e.getY();

    if (e.getAction()==MotionEvent.ACTION_DOWN) {

      lastX=x;
      lastY=y;

      // PANEL
      if (showPanel && y<70) {

        if (x<95) {
          findBest();
          return true;
        }

        if (x>=100 && x<170) {
          if (depth>1) depth--;
          status="DEPTH "+depth;
          return true;
        }

        if (x>=175 && x<245) {
          if (depth<6) depth++;
          status="DEPTH "+depth;
          return true;
        }

        if (x>=250 && x<325) {
          drawings.clear();
          return true;
        }

        if (x>=330 && x<405) {
          eraseMode=true;
          drawMode=true;
          return true;
        }

        if (x>=410 && x<485) {
          showPanel=false;
          return true;
        }

        if (x>=490 && x<565) {
          backToChess();
          return true;
        }

        if (x>=570 && x<645) {
          askFEN();
          return true;
        }

        if (x>=650 && x<715) {
          board.start();
          bestFrom=-1;
          bestTo=-1;
          status="NEW GAME";
          return true;
        }
      }


      // BOARD
      if (insideBoard(x,y)) {

        int pos =
          squareAt(x,y);

        if (selected<0) {

          if (board.b[pos]!='.') {
            selected=pos;
            status="SELECT";
          }

        } else {

          Move m =
            new Move(
              selected,
              pos,
              '\0'
            );

          if (board.isLegal(m)) {

            board.make(m);

            selected=-1;

            bestFrom=-1;
            bestTo=-1;

            status =
              board.white ?
              "WHITE MOVE" :
              "BLACK MOVE";

          } else {

            selected=-1;
            status="ILLEGAL";
          }
        }

        return true;
      }

      drawMode=true;
      eraseMode=false;

      return true;
    }


    if (e.getAction()==MotionEvent.ACTION_MOVE) {

      if (drawMode) {

        if (eraseMode) {

          erase(x,y);

        } else {

          drawings.add(
            new DrawLine(
              lastX,lastY,
              x,y,
              drawColor
            )
          );
        }

        lastX=x;
        lastY=y;
      }

      return true;
    }


    if (e.getAction()==MotionEvent.ACTION_UP) {

      drawMode=false;

      return true;
    }

    return true;
  }


  boolean insideBoard(
    float x,float y
  ) {

    return
      x>=bx &&
      x<bx+8*sq &&
      y>=by &&
      y<by+8*sq;
  }


  int squareAt(float x,float y) {

    int f =
      (int)((x-bx)/sq);

    int r =
      (int)((y-by)/sq);

    return r*8+f;
  }


  // ==========================================================
  // DRAWING
  // ==========================================================

  void drawArrows(Canvas c) {

    p.setStrokeWidth(6);
    p.setStrokeCap(Paint.Cap.ROUND);

    for (DrawLine l:
         drawings) {

      p.setColor(l.color);

      c.drawLine(
        l.x1,l.y1,
        l.x2,l.y2,
        p
      );
    }
  }


  void erase(float x,float y) {

    for (int i=drawings.size()-1;
         i>=0;i--) {

      DrawLine l=drawings.get(i);

      float d =
        pointLineDistance(
          x,y,
          l.x1,l.y1,
          l.x2,l.y2
        );

      if (d<35)
        drawings.remove(i);
    }
  }


  float pointLineDistance(
    float px,float py,
    float x1,float y1,
    float x2,float y2
  ) {

    float dx=x2-x1;
    float dy=y2-y1;

    if (dx==0 && dy==0)
      return dist(px,py,x1,y1);

    float t=
      ((px-x1)*dx+
       (py-y1)*dy)/
      (dx*dx+dy*dy);

    t=constrain(t,0,1);

    float xx=x1+t*dx;
    float yy=y1+t*dy;

    return dist(px,py,xx,yy);
  }


  // ==========================================================
  // BEST MOVE
  // ==========================================================

  void findBest() {

    status="THINKING";

    thinkingStart =
      System.currentTimeMillis();

    bestFrom=-1;
    bestTo=-1;

    MoveList ml =
      board.generateLegal();

    if (ml.moves.size()==0) {
      status="NO MOVES";
      return;
    }

    int bestScore =
      board.white ?
      -10000000 :
      10000000;

    Move best=null;

    for (Move m:
         ml.moves) {

      Board b =
        board.copy();

      b.make(m);

      int score =
        search(
          b,
          depth-1,
          -10000000,
          10000000
        );

      if (board.white) {

        if (score>bestScore) {
          bestScore=score;
          best=m;
        }

      } else {

        if (score<bestScore) {
          bestScore=score;
          best=m;
        }
      }
    }

    if (best!=null) {

      bestFrom=best.from;
      bestTo=best.to;

      status =
        "BEST " +
        squareName(best.from) +
        "-" +
        squareName(best.to) +
        "  "+bestScore;
    }
  }


  int search(
    Board b,
    int d,
    int alpha,
    int beta
  ) {

    if (d<=0)
      return b.evaluate();

    MoveList ml =
      b.generateLegal();

    if (ml.moves.size()==0) {

      if (b.inCheck(b.white)) {

        if (b.white)
          return -900000+d;

        return 900000-d;
      }

      return 0;
    }

    if (b.white) {

      int best=-10000000;

      for (Move m:
           ml.moves) {

        Board n=b.copy();

        n.make(m);

        int v =
          search(
            n,d-1,
            alpha,beta
          );

        if (v>best)
          best=v;

        if (v>alpha)
          alpha=v;

        if (beta<=alpha)
          break;
      }

      return best;

    } else {

      int best=10000000;

      for (Move m:
           ml.moves) {

        Board n=b.copy();

        n.make(m);

        int v =
          search(
            n,d-1,
            alpha,beta
          );

        if (v<best)
          best=v;

        if (v<beta)
          beta=v;

        if (beta<=alpha)
          break;
      }

      return best;
    }
  }


  String squareName(int p) {

    int f=p%8;
    int r=p/8;

    return
      ""+(char)('a'+f)+
      (8-r);
  }


  // ==========================================================
  // TIMER
  // ==========================================================

  void updateTimer() {

    long now=
      System.currentTimeMillis();

    if (now-timerLast>=1000) {

      timer--;

      if (timer<0)
        timer=0;

      timerLast=now;
    }
  }


  String formatTime(long s) {

    long m=s/60;
    long z=s%60;

    return
      m+":"+
      (z<10?"0":"")+
      z;
  }


  // ==========================================================
  // FEN
  // ==========================================================

  void askFEN() {

    final EditText input =
      new EditText(act);

    input.setSingleLine(false);

    input.setText(
      board.toFEN()
    );

    new AlertDialog.Builder(act)
      .setTitle("FEN")
      .setView(input)
      .setPositiveButton(
        "LOAD",
        new DialogInterface.OnClickListener() {

          public void onClick(
            DialogInterface d,
            int w
          ) {

            board.fromFEN(
              input.getText().toString()
            );

            selected=-1;
            bestFrom=-1;
            bestTo=-1;

            status="FEN LOADED";
          }
        }
      )
      .setNegativeButton(
        "CANCEL",
        null
      )
      .show();
  }


  // ==========================================================
  // BACK TO CHESS APP
  // ==========================================================

  void backToChess() {

    // ЗАМІНИ на package твоєї шахової програми.
    String chessPackage=
      "com.example.chess";

    try {

      Intent i=
        act.getPackageManager()
        .getLaunchIntentForPackage(
          chessPackage
        );

      if (i!=null) {

        i.addFlags(
          Intent.FLAG_ACTIVITY_NEW_TASK
        );

        act.startActivity(i);

      } else {

        Toast.makeText(
          act,
          "Chess app not found",
          Toast.LENGTH_SHORT
        ).show();
      }

    } catch(Exception e) {}
  }
}


// ============================================================
// DRAW LINE
// ============================================================

class DrawLine {

  float x1,y1,x2,y2;
  int color;

  DrawLine(
    float a,float b,
    float c,float d,
    int col
  ) {

    x1=a;
    y1=b;
    x2=c;
    y2=d;
    color=col;
  }
}


// ============================================================
// CHESS MOVE
// ============================================================

class Move {

  int from;
  int to;
  char promotion;

  Move(
    int a,int b,
    char c
  ) {

    from=a;
    to=b;
    promotion=c;
  }
}


// ============================================================
// MOVE LIST
// ============================================================

class MoveList {

  ArrayList<Move> moves=
    new ArrayList<Move>();
}


// ============================================================
// CHESS BOARD
// ============================================================

class Board {

  char[] b =
    new char[64];

  boolean white=true;

  boolean castleWK=true;
  boolean castleWQ=true;
  boolean castleBK=true;
  boolean castleBQ=true;

  int ep=-1;

  Board() {
    start();
  }


  void start() {

    String[] a = {

      "rnbqkbnr",
      "pppppppp",
      "........",
      "........",
      "........",
      "........",
      "PPPPPPPP",
      "RNBQKBNR"
    };

    for(int r=0;r<8;r++)
      for(int f=0;f<8;f++)
        b[r*8+f]=a[r].charAt(f);

    white=true;

    castleWK=true;
    castleWQ=true;
    castleBK=true;
    castleBQ=true;

    ep=-1;
  }


  Board copy() {

    Board n=new Board();

    for(int i=0;i<64;i++)
      n.b[i]=b[i];

    n.white=white;

    n.castleWK=castleWK;
    n.castleWQ=castleWQ;
    n.castleBK=castleBK;
    n.castleBQ=castleBQ;

    n.ep=ep;

    return n;
  }


  // ==========================================================
  // MAKE MOVE
  // ==========================================================

  void make(Move m) {

    char pc=b[m.from];

    b[m.from]='.';

    // en passant
    if ((pc=='P'||pc=='p') &&
        m.to==ep &&
        b[m.to]=='.') {

      if (pc=='P')
        b[m.to+8]='.';
      else
        b[m.to-8]='.';
    }

    b[m.to]=pc;

    // promotion
    if (pc=='P' && m.to/8==0)
      b[m.to]='Q';

    if (pc=='p' && m.to/8==7)
      b[m.to]='q';

    // castling
    if (pc=='K') {

      castleWK=false;
      castleWQ=false;

      if (m.from==60 &&
          m.to==62) {

        b[63]='.';
        b[61]='R';
      }

      if (m.from==60 &&
          m.to==58) {

        b[56]='.';
        b[59]='R';
      }
    }

    if (pc=='k') {

      castleBK=false;
      castleBQ=false;

      if (m.from==4 &&
          m.to==6) {

        b[7]='.';
        b[5]='r';
      }

      if (m.from==4 &&
          m.to==2) {

        b[0]='.';
        b[3]='r';
      }
    }

    if (m.from==63 ||
        m.to==63)
      castleWK=false;

    if (m.from==56 ||
        m.to==56)
      castleWQ=false;

    if (m.from==7 ||
        m.to==7)
      castleBK=false;

    if (m.from==0 ||
        m.to==0)
      castleBQ=false;

    ep=-1;

    if (pc=='P' &&
        m.from/8==6 &&
        m.to/8==4)
      ep=m.from-8;

    if (pc=='p' &&
        m.from/8==1 &&
        m.to/8==3)
      ep=m.from+8;

    white=!white;
  }


  // ==========================================================
  // LEGAL MOVES
  // ==========================================================

  MoveList generateLegal() {

    MoveList out=
      new MoveList();

    for(int i=0;i<64;i++) {

      char pc=b[i];

      if (pc=='.')
        continue;

      if (white !=
          Character.isUpperCase(pc))
        continue;

      generatePiece(
        i,pc,out
      );
    }

    MoveList legal=
      new MoveList();

    for(Move m:
        out.moves) {

      Board n=copy();

      n.make(m);

      if (!n.inCheck(!n.white))
        legal.moves.add(m);
    }

    return legal;
  }


  // ==========================================================
  // PIECES
  // ==========================================================

  void generatePiece(
    int pos,
    char pc,
    MoveList ml
  ) {

    int f=pos%8;
    int r=pos/8;

    boolean w=
      Character.isUpperCase(pc);

    if (pc=='P'||pc=='p') {

      int dr=w?-1:1;

      int rr=r+dr;

      if (rr>=0 && rr<8) {

        int to=rr*8+f;

        if (b[to]=='.') {

          ml.moves.add(
            new Move(pos,to,'\0')
          );

          if ((w&&r==6) ||
              (!w&&r==1)) {

            int to2=
              (r+2*dr)*8+f;

            if(b[to2]=='.')
              ml.moves.add(
                new Move(pos,to2,'\0')
              );
          }
        }

        for(int df=-1;
            df<=1;
            df+=2) {

          int ff=f+df;

          if(ff<0||ff>7)
            continue;

          int t=rr*8+ff;

          if(b[t]!='.' &&
             Character.isUpperCase(
               b[t])!=w) {

            ml.moves.add(
              new Move(pos,t,'\0')
            );
          }

          if(t==ep) {

            ml.moves.add(
              new Move(pos,t,'\0')
            );
          }
        }
      }

      return;
    }


    if (pc=='N'||pc=='n') {

      int[] df={
        1,2,2,1,
        -1,-2,-2,-1
      };

      int[] dr={
        -2,-1,1,2,
        2,1,-1,-2
      };

      for(int i=0;i<8;i++) {

        addStep(
          pos,
          f+df[i],
          r+dr[i],
          w,
          ml
        );
      }

      return;
    }


    if (pc=='K'||pc=='k') {

      for(int df=-1;df<=1;df++)
        for(int dr=-1;dr<=1;dr++)
          if(df!=0||dr!=0)
            addStep(
              pos,
              f+df,
              r+dr,
              w,
              ml
            );

      // castling
      if(w && pos==60) {

        if(castleWK &&
           b[61]=='.' &&
           b[62]=='.' &&
           !squareAttacked(60,false) &&
           !squareAttacked(61,false) &&
           !squareAttacked(62,false)) {

          ml.moves.add(
            new Move(60,62,'\0')
          );
        }

        if(castleWQ &&
           b[59]=='.' &&
           b[58]=='.' &&
           b[57]=='.' &&
           !squareAttacked(60,false) &&
           !squareAttacked(59,false) &&
           !squareAttacked(58,false)) {

          ml.moves.add(
            new Move(60,58,'\0')
          );
        }
      }

      if(!w && pos==4) {

        if(castleBK &&
           b[5]=='.' &&
           b[6]=='.' &&
           !squareAttacked(4,true) &&
           !squareAttacked(5,true) &&
           !squareAttacked(6,true)) {

          ml.moves.add(
            new Move(4,6,'\0')
          );
        }

        if(castleBQ &&
           b[3]=='.' &&
           b[2]=='.' &&
           b[1]=='.' &&
           !squareAttacked(4,true) &&
           !squareAttacked(3,true) &&
           !squareAttacked(2,true)) {

          ml.moves.add(
            new Move(4,2,'\0')
          );
        }
      }

      return;
    }


    if (pc=='B'||pc=='b') {

      slide(
        pos,w,ml,
        new int[]{
          1,1,
          1,-1,
          -1,1,
          -1,-1
        }
      );

      return;
    }


    if (pc=='R'||pc=='r') {

      slide(
        pos,w,ml,
        new int[]{
          1,0,
          -1,0,
          0,1,
          0,-1
        }
      );

      return;
    }


    if (pc=='Q'||pc=='q') {

      slide(
        pos,w,ml,
        new int[]{
          1,0,
          -1,0,
          0,1,
          0,-1,
          1,1,
          1,-1,
          -1,1,
          -1,-1
        }
      );
    }
  }


  void addStep(
    int pos,
    int f,
    int r,
    boolean w,
    MoveList ml
  ) {

    if(f<0||f>7||r<0||r>7)
      return;

    int t=r*8+f;

    if(b[t]=='.' ||
       Character.isUpperCase(b[t])!=w) {

      ml.moves.add(
        new Move(pos,t,'\0')
      );
    }
  }


  void slide(
    int pos,
    boolean w,
    MoveList ml,
    int[] dirs
  ) {

    int f=pos%8;
    int r=pos/8;

    for(int i=0;i<dirs.length;i+=2) {

      int df=dirs[i];
      int dr=dirs[i+1];

      int ff=f+df;
      int rr=r+dr;

      while(
        ff>=0&&ff<8&&
        rr>=0&&rr<8
      ) {

        int t=rr*8+ff;

        if(b[t]=='.') {

          ml.moves.add(
            new Move(pos,t,'\0')
          );

        } else {

          if(
            Character.isUpperCase(
              b[t]
            )!=w
          ) {

            ml.moves.add(
              new Move(pos,t,'\0')
            );
          }

          break;
        }

        ff+=df;
        rr+=dr;
      }
    }
  }


  // ==========================================================
  // CHECK
  // ==========================================================

  boolean inCheck(boolean sideWhite) {

    int king=-1;

    char k=
      sideWhite?'K':'k';

    for(int i=0;i<64;i++)
      if(b[i]==k)
        king=i;

    if(king<0)
      return true;

    return squareAttacked(
      king,
      !sideWhite
    );
  }


  boolean squareAttacked(
    int pos,
    boolean byWhite
  ) {

    int f=pos%8;
    int r=pos/8;

    // pawn
    int pr =
      byWhite ? r+1 : r-1;

    if(pr>=0&&pr<8) {

      for(int df=-1;df<=1;df+=2) {

        int ff=f+df;

        if(ff>=0&&ff<8) {

          char pc=
            b[pr*8+ff];

          if(pc==
             (byWhite?'P':'p'))
            return true;
        }
      }
    }


    // knight
    int[] nf={
      1,2,2,1,
      -1,-2,-2,-1
    };

    int[] nr={
      -2,-1,1,2,
      2,1,-1,-2
    };

    for(int i=0;i<8;i++) {

      int ff=f+nf[i];
      int rr=r+nr[i];

      if(ff>=0&&ff<8&&
         rr>=0&&rr<8) {

        if(b[rr*8+ff]==
           (byWhite?'N':'n'))
          return true;
      }
    }


    // king
    for(int df=-1;df<=1;df++)
      for(int dr=-1;dr<=1;dr++)
        if(df!=0||dr!=0) {

          int ff=f+df;
          int rr=r+dr;

          if(ff>=0&&ff<8&&
             rr>=0&&rr<8) {

            if(b[rr*8+ff]==
               (byWhite?'K':'k'))
              return true;
          }
        }


    // rook / queen
    if(rayAttack(
      f,r,byWhite,
      new int[]{
        1,0,-1,0,
        0,1,0,-1
      },
      "RQ"
    ))
      return true;


    // bishop / queen
    if(rayAttack(
      f,r,byWhite,
      new int[]{
        1,1,
        1,-1,
        -1,1,
        -1,-1
      },
      "BQ"
    ))
      return true;

    return false;
  }


  boolean rayAttack(
    int f,int r,
    boolean byWhite,
    int[] dirs,
    String pieces
  ) {

    char R=
      byWhite?'R':'r';

    char B=
      byWhite?'B':'b';

    char Q=
      byWhite?'Q':'q';

    for(int i=0;i<dirs.length;i+=2) {

      int ff=f+dirs[i];
      int rr=r+dirs[i+1];

      while(
        ff>=0&&ff<8&&
        rr>=0&&rr<8
      ) {

        char pc=b[rr*8+ff];

        if(pc!='.') {

          if(
            pc==Q ||
            (pieces.indexOf('R')>=0 &&
             pc==R) ||
            (pieces.indexOf('B')>=0 &&
             pc==B)
          )
            return true;

          break;
        }

        ff+=dirs[i];
        rr+=dirs[i+1];
      }
    }

    return false;
  }


  boolean isLegal(Move m) {

    MoveList ml=
      generateLegal();

    for(Move x:
        ml.moves) {

      if(x.from==m.from &&
         x.to==m.to)
        return true;
    }

    return false;
  }


  // ==========================================================
  // EVALUATION
  // ==========================================================

  int evaluate() {

    int score=0;

    for(int i=0;i<64;i++) {

      char pc=b[i];

      switch(pc) {

      case 'P':
        score+=100;
        score+=pawnBonus(i,true);
        break;

      case 'N':
        score+=320;
        score+=centerBonus(i);
        break;

      case 'B':
        score+=330;
        score+=centerBonus(i);
        break;

      case 'R':
        score+=500;
        break;

      case 'Q':
        score+=900;
        score+=centerBonus(i);
        break;

      case 'K':
        score+=kingBonus(i,true);
        break;


      case 'p':
        score-=100;
        score-=pawnBonus(i,false);
        break;

      case 'n':
        score-=320;
        score-=centerBonus(i);
        break;

      case 'b':
        score-=330;
        score-=centerBonus(i);
        break;

      case 'r':
        score-=500;
        break;

      case 'q':
        score-=900;
        score-=centerBonus(i);
        break;

      case 'k':
        score-=kingBonus(i,false);
        break;
      }
    }

    return score;
  }


  int centerBonus(int p) {

    int f=p%8;
    int r=p/8;

    int d=
      abs(f-3)+
      abs(r-3);

    return
      14-d*3;
  }


  int pawnBonus(
    int p,
    boolean w
  ) {

    int r=p/8;

    if(w)
      return (6-r)*5;

    return (r-1)*5;
  }


  int kingBonus(
    int p,
    boolean w
  ) {

    int f=p%8;
    int r=p/8;

    int d=
      abs(f-3)+
      abs(r-3);

    // king prefers safety early
    return 20-d*2;
  }


  // ==========================================================
  // FEN
  // ==========================================================

  String toFEN() {

    String s="";

    for(int r=0;r<8;r++) {

      int empty=0;

      for(int f=0;f<8;f++) {

        char pc=b[r*8+f];

        if(pc=='.') {

          empty++;

        } else {

          if(empty>0) {
            s+=empty;
            empty=0;
          }

          s+=pc;
        }
      }

      if(empty>0)
        s+=empty;

      if(r<7)
        s+="/";
    }

    s+=" ";
    s+=white?"w ":"b ";

    String c="";

    if(castleWK)c+="K";
    if(castleWQ)c+="Q";
    if(castleBK)c+="k";
    if(castleBQ)c+="q";

    if(c.length()==0)
      c="-";

    s+=c+" ";

    if(ep>=0)
      s+=squareName(ep);
    else
      s+="-";

    s+=" 0 1";

    return s;
  }


  void fromFEN(String fen) {

    try {

      String[] a=
        fen.trim().split("\\s+");

      String[] rows=
        a[0].split("/");

      for(int r=0;r<8;r++) {

        int f=0;

        for(int j=0;
            j<rows[r].length();
            j++) {

          char pc=
            rows[r].charAt(j);

          if(Character.isDigit(pc)) {

            int n=
              pc-'0';

            for(int k=0;k<n;k++)
              b[r*8+f++]='.';

          } else {

            b[r*8+f++]=pc;
          }
        }
      }

      white=
        a.length>1 ?
        a[1].equals("w") :
        true;

      castleWK=false;
      castleWQ=false;
      castleBK=false;
      castleBQ=false;

      if(a.length>2) {

        String c=a[2];

        castleWK=c.indexOf('K')>=0;
        castleWQ=c.indexOf('Q')>=0;
        castleBK=c.indexOf('k')>=0;
        castleBQ=c.indexOf('q')>=0;
      }

      ep=-1;

      if(a.length>3 &&
         !a[3].equals("-")) {

        ep=
          fenSquare(a[3]);
      }

    }
    catch(Exception e) {

      start();
    }
  }


  int fenSquare(String s) {

    if(s.length()<2)
      return -1;

    int f=
      s.charAt(0)-'a';

    int rank=
      s.charAt(1)-'0';

    if(f<0||f>7||
       rank<1||rank>8)
      return -1;

    return
      (8-rank)*8+f;
  }
}


// ============================================================
// GLOBAL BACK BUTTON
// ============================================================

@Override
public void onBackPressed() {

  if(view!=null) {

    view.showPanel=true;
    view.invalidate();

  } else {

    super.onBackPressed();
  }
}


// ============================================================
// CLEANUP
// ============================================================

@Override
public void onDestroy() {

  try {

    if(wm!=null &&
       view!=null) {

      wm.removeView(view);
      view=null;
    }

  } catch(Exception e) {}

  super.onDestroy();
}


























