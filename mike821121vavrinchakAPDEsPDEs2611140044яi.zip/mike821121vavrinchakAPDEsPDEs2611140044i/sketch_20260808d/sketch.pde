






/*


// APDE / Processing // 6 x 11 touch squares // Touch = record timing // Release = save signal // Next touch = replay the saved signal // Every square has its own parallel playback buffer. final int COLS = 6; final int ROWS = 11; Square[][] sq = new Square[COLS][ROWS]; void setup() { fullScreen(); frameRate(60); for (int x = 0; x < COLS; x++) { for (int y = 0; y < ROWS; y++) { sq[x][y] = new Square(x, y); } } } void draw() { background(20); for (int x = 0; x < COLS; x++) { for (int y = 0; y < ROWS; y++) { sq[x][y].update(); sq[x][y].draw(); } } } void touchStarted() { int x = (int)(mouseX / (width / (float)COLS)); int y = (int)(mouseY / (height / (float)ROWS)); if (x >= 0 && x < COLS && y >= 0 && y < ROWS) { sq[x][y].touchDown(); } } void touchEnded() { int x = (int)(mouseX / (width / (float)COLS)); int y = (int)(mouseY / (height / (float)ROWS)); if (x >= 0 && x < COLS && y >= 0 && y < ROWS) { sq[x][y].touchUp(); } } // -------------------------------------------------- // SQUARE // -------------------------------------------------- class Square { float x, y, w, h; int normalColor; int playColor; boolean recording = false; boolean playing = false; long touchStart; long playStart; // Independent timing buffer for this square int[] timeBuffer = new int[1000]; int timeCount = 0; int playIndex = 0; Square(int gx, int gy) { x = gx * width / (float)COLS; y = gy * height / (float)ROWS; w = width / (float)COLS; h = height / (float)ROWS; normalColor = color( random(40, 255), random(40, 255), random(40, 255) ); playColor = color(255); } void touchDown() { // If we already have a signal, // start playing it. if (timeCount > 0 && !recording) { playing = true; playStart = millis(); playIndex = 0; } else { // Start recording recording = true; timeCount = 0; touchStart = millis(); } } void touchUp() { if (recording) { int t = (int)(millis() - touchStart); if (timeCount < timeBuffer.length) { timeBuffer[timeCount++] = t; } recording = false; // Start playing immediately playing = true; playStart = millis(); playIndex = 0; } } void update() { // RECORDING if (recording) { int t = (int)(millis() - touchStart); if (timeCount < timeBuffer.length) { timeBuffer[timeCount++] = t; } } // PLAYBACK if (playing && timeCount > 0) { int elapsed = (int)(millis() - playStart); // Find which recorded time is currently playing while (playIndex < timeCount && elapsed >= timeBuffer[playIndex]) { playIndex++; } // End of signal if (playIndex >= timeCount) { playing = false; } } } void draw() { if (recording) { fill(255, 100, 0); } else if (playing) { fill(playColor); } else { fill(normalColor); } stroke(20); strokeWeight(3); rect(x + 2, y + 2, w - 4, h - 4, 8); // Small indicator if (recording) { fill(255); textAlign(CENTER, CENTER); textSize(18); text("REC", x + w/2, y + h/2); } if (playing) { noStroke(); fill(255, 80); ellipse(x + w/2, y + h/2, min(w,h)*0.25, min(w,h)*0.25); } } }

*/



// APDE / Processing
// 6 x 11 touch squares
// Touch = record timing
// Release = save signal
// Next touch = replay the saved signal
// Every square has its own parallel playback buffer.

final int COLS = 6;
final int ROWS = 11;

Square[][] sq = new Square[COLS][ROWS];

void setup() {
  fullScreen();
  frameRate(60);

  for (int x = 0; x < COLS; x++) {
    for (int y = 0; y < ROWS; y++) {
      sq[x][y] = new Square(x, y);
    }
  }
}

void draw() {
  background(20);

  for (int x = 0; x < COLS; x++) {
    for (int y = 0; y < ROWS; y++) {
      sq[x][y].update();
      sq[x][y].draw();
    }
  }
}

void touchStarted() {
  int x = (int)(mouseX / (width / (float)COLS));
  int y = (int)(mouseY / (height / (float)ROWS));

  if (x >= 0 && x < COLS && y >= 0 && y < ROWS) {
    sq[x][y].touchDown();
  }
}

void touchEnded() {
  int x = (int)(mouseX / (width / (float)COLS));
  int y = (int)(mouseY / (height / (float)ROWS));

  if (x >= 0 && x < COLS && y >= 0 && y < ROWS) {
    sq[x][y].touchUp();
  }
}


// --------------------------------------------------
// SQUARE
// --------------------------------------------------

class Square {

  float x, y, w, h;

  int normalColor;
  int playColor;

  boolean recording = false;
  boolean playing = false;

  long touchStart;
  long playStart;

  // Independent timing buffer for this square
  int[] timeBuffer = new int[1000];
  int timeCount = 0;

  int playIndex = 0;

  Square(int gx, int gy) {

    x = gx * width / (float)COLS;
    y = gy * height / (float)ROWS;

    w = width / (float)COLS;
    h = height / (float)ROWS;

    normalColor = color(
      random(40, 255),
      random(40, 255),
      random(40, 255)
    );

    playColor = color(255);
  }

  void touchDown() {

    // If we already have a signal,
    // start playing it.
    if (timeCount > 0 && !recording) {

      playing = true;
      playStart = millis();
      playIndex = 0;

    } else {

      // Start recording
      recording = true;
      timeCount = 0;
      touchStart = millis();
    }
  }

  void touchUp() {

    if (recording) {

      int t = (int)(millis() - touchStart);

      if (timeCount < timeBuffer.length) {
        timeBuffer[timeCount++] = t;
      }

      recording = false;

      // Start playing immediately
      playing = true;
      playStart = millis();
      playIndex = 0;
    }
  }

  void update() {

    // RECORDING
    if (recording) {

      int t = (int)(millis() - touchStart);

      if (timeCount < timeBuffer.length) {
        timeBuffer[timeCount++] = t;
      }
    }

    // PLAYBACK
    if (playing && timeCount > 0) {

      int elapsed = (int)(millis() - playStart);

      // Find which recorded time is currently playing
      while (playIndex < timeCount &&
             elapsed >= timeBuffer[playIndex]) {

        playIndex++;
      }

      // End of signal
      if (playIndex >= timeCount) {
        playing = false;
      }
    }
  }

  void draw() {

    if (recording) {

      fill(255, 100, 0);

    } else if (playing) {

      fill(playColor);

    } else {

      fill(normalColor);
    }

    stroke(20);
    strokeWeight(3);

    rect(x + 2, y + 2,
         w - 4, h - 4,
         8);

    // Small indicator
    if (recording) {
      fill(255);
      textAlign(CENTER, CENTER);
      textSize(18);
      text("REC", x + w/2, y + h/2);
    }

    if (playing) {
      noStroke();
      fill(255, 80);
      ellipse(x + w/2, y + h/2,
              min(w,h)*0.25,
              min(w,h)*0.25);
    }
  }
}












