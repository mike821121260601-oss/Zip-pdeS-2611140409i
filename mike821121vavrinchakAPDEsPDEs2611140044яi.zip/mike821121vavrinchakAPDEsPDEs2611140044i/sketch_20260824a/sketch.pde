




// RANDOM NES-STYLE MUSIC GENERATOR
// APDE / Processing Android
// Creates approximately 3 minutes of 8-bit music.
//
// Output:
// random_nes_3min.wav

import java.io.*;
import android.os.Environment;

int SAMPLE_RATE = 22050;
int BPM = 150;
int BEAT_SAMPLES;
int TOTAL_SECONDS = 180;

String outputFile;

void setup() {
  orientation(PORTRAIT);
  background(20);
  
  BEAT_SAMPLES = SAMPLE_RATE * 60 / BPM;

  outputFile =
    Environment.getExternalStorageDirectory().getAbsolutePath()
    + "/random_nes_3min.wav";

  println("Generating music...");
  println(outputFile);

  generateMusic();

  println("DONE!");
  println(outputFile);

  background(20);
  fill(255);
  textAlign(CENTER, CENTER);
  textSize(24);
  text("3 MIN 8-BIT MUSIC", width/2, height/2-30);
  textSize(16);
  text("WAV CREATED", width/2, height/2+10);
}

void draw() {
}


// ----------------------------------------------------
// MUSIC GENERATOR
// ----------------------------------------------------

void generateMusic() {

  int totalSamples = SAMPLE_RATE * TOTAL_SECONDS;

  RandomAccessFile file = null;

  try {

    file = new RandomAccessFile(outputFile, "rw");

    // Reserve WAV header
    for (int i = 0; i < 44; i++)
      file.write(0);

    int samplesWritten = 0;

    int bars = 112;

    for (int bar = 0; bar < bars; bar++) {

      // Random key
      int root = randomRoot();

      // 4 beats per bar
      for (int beat = 0; beat < 4; beat++) {

        int note;

        // Random melody
        if (random(1) < 0.75) {
          int[] scale = {
            0, 2, 3, 5, 7, 8, 10, 12
          };

          note = root + scale[(int)random(scale.length)];
        } else {
          note = root;
        }

        // Melody
        samplesWritten +=
          writeNote(
            file,
            note,
            BEAT_SAMPLES,
            0.32,
            0
          );

        // Bass
        int bassNote = root - 12;

        writeNote(
          file,
          bassNote,
          BEAT_SAMPLES,
          0.22,
          1
        );

        // Noise percussion
        writeDrums(
          file,
          BEAT_SAMPLES
        );

        // Keep correct length
        if (samplesWritten >= totalSamples)
          break;
      }

      if (samplesWritten >= totalSamples)
        break;
    }

    file.close();

    // Write WAV header
    writeWavHeader(outputFile, totalSamples);

  } 
  catch (Exception e) {

    println("ERROR:");
    println(e);

    try {
      if (file != null)
        file.close();
    } 
    catch(Exception x) {
    }
  }
}


// ----------------------------------------------------
// NOTE
// ----------------------------------------------------

int writeNote(
  RandomAccessFile f,
  int midi,
  int length,
  float volume,
  int type
) {

  try {

    double frequency =
      440.0 * pow(
        2.0,
        (midi - 69) / 12.0
      );

    int attack = length / 30;
    int release = length / 8;

    for (int i = 0; i < length; i++) {

      double t =
        (double)i / SAMPLE_RATE;

      double phase =
        (t * frequency) % 1.0;

      float s;

      if (type == 0) {

        // Square wave
        s = phase < 0.5 ? 1.0 : -1.0;

      } else {

        // Bass square wave
        s = phase < 0.5 ? 0.8 : -0.8;
      }

      // Envelope
      float env = 1.0;

      if (i < attack)
        env = (float)i / attack;

      if (i > length - release)
        env =
          (float)(length - i) / release;

      float value =
        s * volume * env;

      short sample =
        (short)(value * 32767);

      f.write(sample & 255);
      f.write((sample >> 8) & 255);
    }

  } 
  catch(Exception e) {

    println(e);
  }

  return length;
}


// ----------------------------------------------------
// DRUMS
// ----------------------------------------------------

void writeDrums(
  RandomAccessFile f,
  int length
) {

  try {

    int n = length / 2;

    for (int i = 0; i < n; i++) {

      float decay =
        1.0 - (float)i / n;

      float noise =
        random(-1, 1);

      float value =
        noise * decay * 0.18;

      short sample =
        (short)(value * 32767);

      f.write(sample & 255);
      f.write((sample >> 8) & 255);
    }

  } 
  catch(Exception e) {

    println(e);
  }
}


// ----------------------------------------------------
// RANDOM ROOT
// ----------------------------------------------------

int randomRoot() {

  int[] roots = {

    48, // C
    50, // D
    52, // E
    53, // F
    55, // G
    57, // A
    59  // B
  };

  return roots[
    (int)random(roots.length)
  ];
}


// ----------------------------------------------------
// WAV HEADER
// ----------------------------------------------------

void writeWavHeader(
  String filename,
  int samples
) {

  try {

    RandomAccessFile f =
      new RandomAccessFile(
        filename,
        "rw"
      );

    int dataSize =
      samples * 2;

    int fileSize =
      36 + dataSize;

    f.seek(0);

    // RIFF
    writeString(f, "RIFF");
    writeIntLE(f, fileSize);

    // WAVE
    writeString(f, "WAVE");

    // fmt
    writeString(f, "fmt ");
    writeIntLE(f, 16);

    // PCM
    writeShortLE(f, 1);

    // Mono
    writeShortLE(f, 1);

    // Sample rate
    writeIntLE(
      f,
      SAMPLE_RATE
    );

    // Byte rate
    writeIntLE(
      f,
      SAMPLE_RATE * 2
    );

    // Block align
    writeShortLE(f, 2);

    // Bits
    writeShortLE(f, 16);

    // data
    writeString(f, "data");

    writeIntLE(
      f,
      dataSize
    );

    f.close();

  } 
  catch(Exception e) {

    println(e);
  }
}


// ----------------------------------------------------
// LITTLE-ENDIAN HELPERS
// ----------------------------------------------------

void writeString(
  RandomAccessFile f,
  String s
) throws IOException {

  byte[] b =
    s.getBytes("US-ASCII");

  f.write(b);
}


void writeIntLE(
  RandomAccessFile f,
  int v
) throws IOException {

  f.write(v & 255);
  f.write((v >> 8) & 255);
  f.write((v >> 16) & 255);
  f.write((v >> 24) & 255);
}


void writeShortLE(
  RandomAccessFile f,
  int v
) throws IOException {

  f.write(v & 255);
  f.write((v >> 8) & 255);
}





























