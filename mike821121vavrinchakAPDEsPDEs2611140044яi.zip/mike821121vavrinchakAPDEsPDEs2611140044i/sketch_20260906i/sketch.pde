


// Chess line sketch – transparent background
// Does not touch any chess position or pieces

void setup() {
  size(800, 800);
  // Transparent background
  background(0, 0);          // alpha = 0
}

void draw() {
  // Clear with full transparency every frame
  background(0, 0);

  stroke(180, 140, 80);      // warm chess-wood color
  strokeWeight(2);
  noFill();

  // Draw the 8×8 grid lines only (no pieces, no fills)
  int cell = width / 8;
  for (int i = 0; i <= 8; i++) {
    // vertical lines
    line(i * cell, 0, i * cell, height);
    // horizontal lines
    line(0, i * cell, width, i * cell);
  }

  // Optional: thin outer frame
  stroke(120, 90, 50);
  strokeWeight(4);
  rect(0, 0, width-1, height-1);
}









