




// APDE / Processing 3 – 2D Fighter with 3D Spheres (P3D)
// Title: Sphere Fighter – based on your sketch

PFont font;

// Player
float px = 200, py = 400;
float pvx = 0, pvy = 0;
boolean onGround = true;
float gravity = 0.6;
float jumpForce = -14;
int facing = 1;          // 1 = right, -1 = left
int state = 0;           // 0=idle/walk, 1=jump, 2=punch, 3=kick, 4=special
int stateTimer = 0;
String comboBuffer = "";
int comboTimer = 0;

// Simple opponent (static for now)
float ox = 500, oy = 400;

void setup() {
  size(800, 600, P3D);
  font = createFont("SansSerif", 16);
  textFont(font);
  noStroke();
}

void draw() {
  background(30, 30, 50);
  
  // Floor
  pushMatrix();
  translate(width/2, 520, -100);
  fill(60, 60, 80);
  box(900, 20, 300);
  popMatrix();
  
  // Lights for nice spheres
  lights();
  ambientLight(80, 80, 100);
  directionalLight(255, 255, 255, -0.5, 1, -0.5);
  
  // Physics
  pvy += gravity;
  px += pvx;
  py += pvy;
  
  if (py > 400) {
    py = 400;
    pvy = 0;
    onGround = true;
  } else {
    onGround = false;
  }
  
  // Friction
  pvx *= 0.85;
  
  // Keep on screen
  px = constrain(px, 60, width-60);
  
  // State machine
  if (stateTimer > 0) stateTimer--;
  else state = 0;
  
  // Combo timeout
  if (comboTimer > 0) comboTimer--;
  else comboBuffer = "";
  
  // Draw player (sphere body)
  drawFighter(px, py, facing, state);
  
  // Draw opponent
  drawFighter(ox, oy, -1, 0);
  
  // HUD
  fill(255);
  text("A = Punch   B = Kick   C = Special   Arrows = Move   Space = Jump", 20, 30);
  text("Combo: " + comboBuffer, 20, 55);
  text("State: " + stateName(state), 20, 80);
}

void drawFighter(float x, float y, int face, int anim) {
  pushMatrix();
  translate(x, y, 0);
  scale(face, 1, 1);   // flip for direction
  
  // Body (torso)
  fill(200, 100, 80);
  sphereDetail(12);
  pushMatrix();
  translate(0, -40, 0);
  sphere(22);
  popMatrix();
  
  // Head
  fill(255, 220, 180);
  pushMatrix();
  translate(0, -75, 0);
  sphere(16);
  popMatrix();
  
  // Arms + Legs – simple pose system
  float armAngle = 0;
  float legAngle = 0;
  float kickAngle = 0;
  
  if (anim == 2) {          // punch
    armAngle = -1.2;
  } else if (anim == 3) {   // kick
    kickAngle = -1.4;
  } else if (anim == 1) {   // jump / aerial
    armAngle = -0.6;
    legAngle = 0.4;
  } else if (abs(pvx) > 0.5) { // walking bob
    armAngle = sin(frameCount * 0.25) * 0.5;
    legAngle = sin(frameCount * 0.25) * 0.6;
  }
  
  // Left arm
  drawLimb(0, -45, 0, armAngle, 0.0, 18, color(200,100,80));
  // Right arm
  drawLimb(0, -45, 0, -armAngle*0.7, 0.0, 18, color(200,100,80));
  
  // Left leg
  drawLimb(0, -20, 0, legAngle, 0.0, 22, color(80,80,180));
  // Right leg (kick overrides)
  drawLimb(0, -20, 0, kickAngle != 0 ? kickAngle : -legAngle, 0.0, 22, color(80,80,180));
  
  popMatrix();
}

void drawLimb(float ox, float oy, float oz, float angle, float twist, float len, color c) {
  pushMatrix();
  translate(ox, oy, oz);
  rotateZ(angle);
  rotateY(twist);
  
  fill(c);
  // upper
  translate(0, len*0.4, 0);
  sphere(10);
  // lower
  translate(0, len*0.55, 0);
  sphere(9);
  // tip
  translate(0, len*0.4, 0);
  sphere(7);
  popMatrix();
}

String stateName(int s) {
  if (s==1) return "JUMP";
  if (s==2) return "PUNCH";
  if (s==3) return "KICK";
  if (s==4) return "SPECIAL";
  return "IDLE";
}

void keyPressed() {
  if (keyCode == LEFT)  { pvx = -5; facing = -1; }
  if (keyCode == RIGHT) { pvx =  5; facing =  1; }
  if (key == ' ' && onGround) {
    pvy = jumpForce;
    state = 1;
    stateTimer = 20;
  }
  
  // Attack keys + combo buffer
  if (key == 'a' || key == 'A') {
    addCombo('A');
    state = 2;
    stateTimer = 12;
  }
  if (key == 'b' || key == 'B') {
    addCombo('B');
    state = 3;
    stateTimer = 15;
  }
  if (key == 'c' || key == 'C') {
    addCombo('C');
    // check for specials
    if (comboBuffer.endsWith("AABBABCC") || comboBuffer.endsWith("AAA") || comboBuffer.length() > 4) {
      state = 4;
      stateTimer = 30;
      // simple special effect – leap forward
      pvx = facing * 12;
      pvy = -8;
    } else {
      state = 2;
      stateTimer = 10;
    }
  }
}

void addCombo(char k) {
  comboBuffer += k;
  if (comboBuffer.length() > 10) comboBuffer = comboBuffer.substring(comboBuffer.length()-10);
  comboTimer = 40; // frames before combo resets
}























