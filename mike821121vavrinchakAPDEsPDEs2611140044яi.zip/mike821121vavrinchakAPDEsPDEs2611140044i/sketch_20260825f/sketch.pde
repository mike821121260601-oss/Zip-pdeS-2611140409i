










// ============================================================
// SINGLE-FILE CHESS
// APDE 0.5.3 / PROCESSING
//
// HUMAN vs ENGINE
//
// ENGINE WHITE / ENGINE BLACK
//
// WHITE VIEW:
//   UP
//   DOWN
//   LEFT
//   RIGHT
//
// PORTRAIT:
//   BOARD UP
//   BOARD DOWN
//
// SAFE SCREEN MARGIN
//
// No chess font
// No external library
// ============================================================


// ============================================================
// PIECES
// ============================================================

final int EMPTY = 0;

final int WP = 1;
final int WN = 2;
final int WB = 3;
final int WR = 4;
final int WQ = 5;
final int WK = 6;

final int BP = -1;
final int BN = -2;
final int BB = -3;
final int BR = -4;
final int BQ = -5;
final int BK = -6;


// ============================================================
// BOARD
// ============================================================

int[][] board = new int[8][8];


// ============================================================
// GAME
// ============================================================

boolean whiteTurn = true;

boolean engineWhite = false;
boolean engineBlack = true;

boolean engineThinking = false;
boolean gameOver = false;

int engineDepth = 3;


// ============================================================
// VIEW
//
// 0 = WHITE UP
// 1 = WHITE DOWN
// 2 = WHITE LEFT
// 3 = WHITE RIGHT
// ============================================================

int whiteSide = 1;

boolean portraitMode;


// ============================================================
// BOARD SCREEN POSITION
// ============================================================

float BS;

float boardLeft;
float boardTop;

float SAFE = 65;


// ============================================================
// SELECTED SQUARE
// ============================================================

int selectedX = -1;
int selectedY = -1;

ArrayList<Move> currentMoves =
  new ArrayList<Move>();


// ============================================================
// CHESS STATE
// ============================================================

int enPassantX = -1;
int enPassantY = -1;

boolean wCastleK;
boolean wCastleQ;
boolean bCastleK;
boolean bCastleQ;


// ============================================================
// ENGINE
// ============================================================

long nodes = 0;


// ============================================================
// MOVE CLASS
// ============================================================

class Move {

  int fx;
  int fy;

  int tx;
  int ty;

  int captured;

  int promotion;

  boolean castle;
  boolean enPassant;

  // STATE BEFORE MOVE
  int oldEPX;
  int oldEPY;

  boolean oldWCK;
  boolean oldWCQ;
  boolean oldBCK;
  boolean oldBCQ;


  Move(int a, int b, int c, int d) {

    fx = a;
    fy = b;

    tx = c;
    ty = d;

    captured = board[d][c];

    promotion = 0;

    castle = false;
    enPassant = false;

    oldEPX = enPassantX;
    oldEPY = enPassantY;

    oldWCK = wCastleK;
    oldWCQ = wCastleQ;

    oldBCK = bCastleK;
    oldBCQ = bCastleQ;
  }
}


// ============================================================
// SETUP
// ============================================================

void setup() {

  fullScreen(P2D);

  orientation(PORTRAIT);

  calculateLayout();

  newGame();
}


// ============================================================
// LAYOUT
// ============================================================

void calculateLayout() {

  portraitMode =
    height >= width;


  if (portraitMode) {

    // Portrait board.
    // Leave SAFE space at the physical top/bottom.

    BS =
      min(
        width - 10,
        height - SAFE * 2 - 150
      ) / 8.0;


    if (BS < 25) {
      BS = 25;
    }


    boardLeft =
      (width - BS * 8) / 2.0;


    if (whiteSide == 0) {

      // BOARD UP

      boardTop =
        SAFE + 10;

    } else {

      // BOARD DOWN

      boardTop =
        SAFE + 10;
    }

  } else {

    // LANDSCAPE

    BS =
      min(
        height - SAFE * 2,
        width - 150
      ) / 8.0;


    if (BS < 25) {
      BS = 25;
    }


    if (whiteSide == 2) {

      // WHITE LEFT

      boardLeft =
        SAFE + 10;

      boardTop =
        (height - BS * 8) / 2.0;

    }

    else if (whiteSide == 3) {

      // WHITE RIGHT

      boardLeft =
        width - SAFE - BS * 8 - 10;

      boardTop =
        (height - BS * 8) / 2.0;

    }

    else {

      boardLeft =
        (width - BS * 8) / 2.0;


      if (whiteSide == 0) {

        boardTop =
          SAFE;

      } else {

        boardTop =
          height - SAFE - BS * 8;
      }
    }
  }
}


// ============================================================
// NEW GAME
// ============================================================

void newGame() {

  for (int y = 0; y < 8; y++) {

    for (int x = 0; x < 8; x++) {

      board[y][x] = EMPTY;
    }
  }


  // BLACK

  board[0][0] = BR;
  board[0][1] = BN;
  board[0][2] = BB;
  board[0][3] = BQ;
  board[0][4] = BK;
  board[0][5] = BB;
  board[0][6] = BN;
  board[0][7] = BR;


  for (int x = 0; x < 8; x++) {

    board[1][x] = BP;
  }


  // WHITE

  board[7][0] = WR;
  board[7][1] = WN;
  board[7][2] = WB;
  board[7][3] = WQ;
  board[7][4] = WK;
  board[7][5] = WB;
  board[7][6] = WN;
  board[7][7] = WR;


  for (int x = 0; x < 8; x++) {

    board[6][x] = WP;
  }


  whiteTurn = true;

  engineThinking = false;

  gameOver = false;


  selectedX = -1;
  selectedY = -1;

  currentMoves.clear();


  enPassantX = -1;
  enPassantY = -1;


  wCastleK = true;
  wCastleQ = true;

  bCastleK = true;
  bCastleQ = true;


  // Engine White starts automatically.

  if (engineWhite) {

    startEngine();
  }
}


// ============================================================
// DRAW
// ============================================================

void draw() {

  background(28, 28, 28);

  calculateLayout();

  drawBoard();

  drawPieces();

  drawUI();
}


// ============================================================
// BOARD
// ============================================================

void drawBoard() {

  for (int sy = 0; sy < 8; sy++) {

    for (int sx = 0; sx < 8; sx++) {

      int bx =
        screenToBoardX(sx, sy);

      int by =
        screenToBoardY(sx, sy);


      if ((sx + sy) % 2 == 0) {

        fill(235, 210, 165);

      } else {

        fill(105, 70, 45);
      }


      noStroke();

      rect(
        boardLeft + sx * BS,
        boardTop + sy * BS,
        BS,
        BS
      );


      // selected

      if (bx == selectedX &&
          by == selectedY) {

        fill(255, 220, 0, 100);

        rect(
          boardLeft + sx * BS,
          boardTop + sy * BS,
          BS,
          BS
        );
      }
    }
  }


  // legal moves

  if (selectedX >= 0) {

    for (Move m : currentMoves) {

      if (m.fx == selectedX &&
          m.fy == selectedY) {

        int sx =
          boardToScreenX(m.tx, m.ty);

        int sy =
          boardToScreenY(m.tx, m.ty);


        fill(0, 220, 0, 120);

        ellipse(
          boardLeft +
          (sx + 0.5) * BS,

          boardTop +
          (sy + 0.5) * BS,

          BS * 0.30,
          BS * 0.30
        );
      }
    }
  }


  // check king

  if (isKingInCheck(whiteTurn)) {

    int king =
      whiteTurn ? WK : BK;


    for (int y = 0; y < 8; y++) {

      for (int x = 0; x < 8; x++) {

        if (board[y][x] == king) {

          int sx =
            boardToScreenX(x, y);

          int sy =
            boardToScreenY(x, y);


          fill(255, 0, 0, 120);

          rect(
            boardLeft + sx * BS,
            boardTop + sy * BS,
            BS,
            BS
          );
        }
      }
    }
  }
}


// ============================================================
// BOARD COORDINATE ROTATION
// ============================================================

int screenToBoardX(
  int sx,
  int sy) {

  if (whiteSide == 0) {

    return 7 - sx;

  } else if (whiteSide == 1) {

    return sx;

  } else if (whiteSide == 2) {

    return sy;

  } else {

    return 7 - sy;
  }
}


int screenToBoardY(
  int sx,
  int sy) {

  if (whiteSide == 0) {

    return 7 - sy;

  } else if (whiteSide == 1) {

    return sy;

  } else if (whiteSide == 2) {

    return 7 - sx;

  } else {

    return sx;
  }
}


int boardToScreenX(
  int bx,
  int by) {

  if (whiteSide == 0) {

    return 7 - bx;

  } else if (whiteSide == 1) {

    return bx;

  } else if (whiteSide == 2) {

    return 7 - by;

  } else {

    return by;
  }
}


int boardToScreenY(
  int bx,
  int by) {

  if (whiteSide == 0) {

    return 7 - by;

  } else if (whiteSide == 1) {

    return by;

  } else if (whiteSide == 2) {

    return bx;

  } else {

    return 7 - bx;
  }
}


// ============================================================
// PIECES
// ============================================================

void drawPieces() {

  for (int y = 0; y < 8; y++) {

    for (int x = 0; x < 8; x++) {

      int p = board[y][x];

      if (p == EMPTY) continue;


      int sx =
        boardToScreenX(x, y);

      int sy =
        boardToScreenY(x, y);


      drawPiece(
        p,

        boardLeft +
        (sx + 0.5) * BS,

        boardTop +
        (sy + 0.5) * BS,

        BS
      );
    }
  }
}


// ============================================================
// GEOMETRIC CHESS PIECES
// ============================================================

void drawPiece(
  int p,
  float cx,
  float cy,
  float s) {

  boolean white =
    p > 0;


  if (white) {

    fill(245);
    stroke(20);

  } else {

    fill(25);
    stroke(245);
  }


  strokeWeight(
    max(2, s * 0.035)
  );


  int t = abs(p);


  // PAWN

  if (t == 1) {

    ellipse(
      cx,
      cy - s * 0.12,
      s * 0.38,
      s * 0.38
    );


    rectMode(CENTER);

    rect(
      cx,
      cy + s * 0.18,
      s * 0.48,
      s * 0.35
    );

    rectMode(CORNER);
  }


  // KNIGHT

  else if (t == 2) {

    triangle(

      cx - s * 0.28,
      cy + s * 0.30,

      cx + s * 0.28,
      cy + s * 0.30,

      cx + s * 0.05,
      cy - s * 0.32
    );


    ellipse(
      cx - s * 0.03,
      cy - s * 0.22,
      s * 0.20,
      s * 0.20
    );
  }


  // BISHOP

  else if (t == 3) {

    ellipse(
      cx,
      cy - s * 0.18,
      s * 0.42,
      s * 0.55
    );


    line(
      cx - s * 0.12,
      cy - s * 0.35,

      cx + s * 0.12,
      cy + s * 0.05
    );


    rectMode(CENTER);

    rect(
      cx,
      cy + s * 0.25,
      s * 0.58,
      s * 0.18
    );

    rectMode(CORNER);
  }


  // ROOK

  else if (t == 4) {

    rectMode(CENTER);

    rect(
      cx,
      cy + s * 0.05,
      s * 0.52,
      s * 0.58
    );


    rect(
      cx,
      cy - s * 0.27,
      s * 0.62,
      s * 0.18
    );

    rectMode(CORNER);
  }


  // QUEEN

  else if (t == 5) {

    ellipse(
      cx,
      cy + s * 0.04,
      s * 0.58,
      s * 0.60
    );


    triangle(

      cx - s * 0.30,
      cy - s * 0.20,

      cx,
      cy - s * 0.42,

      cx + s * 0.30,
      cy - s * 0.20
    );
  }


  // KING

  else if (t == 6) {

    ellipse(
      cx,
      cy + s * 0.05,
      s * 0.58,
      s * 0.62
    );


    line(
      cx,
      cy - s * 0.42,

      cx,
      cy - s * 0.12
    );


    line(
      cx - s * 0.15,
      cy - s * 0.30,

      cx + s * 0.15,
      cy - s * 0.30
    );
  }


  noStroke();
}


// ============================================================
// UI
// ============================================================

void drawUI() {

  fill(255);

  textAlign(CENTER, CENTER);

  textSize(16);


  if (engineThinking) {

    text(
      "ENGINE THINKING",
      width / 2,
      20
    );

  } else if (gameOver) {

    if (isKingInCheck(whiteTurn)) {

      if (whiteTurn) {

        text(
          "CHECKMATE - BLACK WINS",
          width / 2,
          20
        );

      } else {

        text(
          "CHECKMATE - WHITE WINS",
          width / 2,
          20
        );
      }

    } else {

      text(
        "DRAW",
        width / 2,
        20
      );
    }

  } else {

    if (whiteTurn) {

      text(
        "WHITE MOVE",
        width / 2,
        20
      );

    } else {

      text(
        "BLACK MOVE",
        width / 2,
        20
      );
    }
  }


  // Controls

  if (portraitMode) {

    drawPortraitControls();

  } else {

    drawLandscapeControls();
  }
}


// ============================================================
// PORTRAIT CONTROLS
// ============================================================

void drawPortraitControls() {

  float y =
    boardTop + BS * 8 + 12;


  if (y + 130 > height) {

    y =
      boardTop - 130;
  }


  fill(65);

  rect(5, y, width - 10, 48);

  rect(5, y + 55, width - 10, 48);


  fill(255);

  textSize(15);


  text(
    "BOARD UP",
    width * 0.25,
    y + 24
  );


  text(
    "BOARD DOWN",
    width * 0.75,
    y + 24
  );


  text(
    "ENGINE WHITE",
    width * 0.25,
    y + 79
  );


  text(
    "ENGINE BLACK",
    width * 0.75,
    y + 79
  );
}


// ============================================================
// LANDSCAPE CONTROLS
// ============================================================

void drawLandscapeControls() {

  float y =
    height - 55;


  fill(65);


  rect(
    5,
    y,
    100,
    45
  );


  rect(
    110,
    y,
    100,
    45
  );


  rect(
    215,
    y,
    100,
    45
  );


  rect(
    320,
    y,
    100,
    45
  );


  fill(255);

  textSize(13);


  text(
    "WHITE UP",
    55,
    y + 22
  );


  text(
    "WHITE DOWN",
    160,
    y + 22
  );


  text(
    "WHITE LEFT",
    265,
    y + 22
  );


  text(
    "WHITE RIGHT",
    370,
    y + 22
  );


  // engine controls

  float x =
    width - 210;


  fill(65);

  rect(
    x,
    5,
    100,
    45
  );


  rect(
    x + 105,
    5,
    100,
    45
  );


  fill(255);

  text(
    "ENGINE WHITE",
    x + 50,
    27
  );


  text(
    "ENGINE BLACK",
    x + 155,
    27
  );
}


// ============================================================
// TOUCH
// ============================================================

void mousePressed() {

  // UI first

  if (handleUI()) {
    return;
  }


  if (gameOver) {
    return;
  }


  if (engineThinking) {
    return;
  }


  // Human cannot move engine side

  if (!humanCanMove()) {
    return;
  }


  int sx =
    floor(
      (mouseX - boardLeft) / BS
    );


  int sy =
    floor(
      (mouseY - boardTop) / BS
    );


  if (sx < 0 ||
      sx >= 8 ||
      sy < 0 ||
      sy >= 8) {

    return;
  }


  int x =
    screenToBoardX(sx, sy);


  int y =
    screenToBoardY(sx, sy);


  // no selected piece

  if (selectedX < 0) {

    if (isOwnPiece(x, y)) {

      selectedX = x;
      selectedY = y;

      currentMoves =
        generateLegalMoves(
          whiteTurn
        );
    }

    return;
  }


  // find move

  Move chosen = null;


  for (Move m : currentMoves) {

    if (m.fx == selectedX &&
        m.fy == selectedY &&
        m.tx == x &&
        m.ty == y) {

      chosen = m;

      break;
    }
  }


  if (chosen != null) {

    makeMove(chosen);


    selectedX = -1;
    selectedY = -1;

    currentMoves.clear();


    whiteTurn =
      !whiteTurn;


    checkGameEnd();


    if (!gameOver &&
        !humanCanMove()) {

      startEngine();
    }

  } else {

    if (isOwnPiece(x, y)) {

      selectedX = x;
      selectedY = y;

      currentMoves =
        generateLegalMoves(
          whiteTurn
        );

    } else {

      selectedX = -1;
      selectedY = -1;

      currentMoves.clear();
    }
  }
}


// ============================================================
// UI TOUCH
// ============================================================

boolean handleUI() {

  // PORTRAIT

  if (portraitMode) {

    float y =
      boardTop + BS * 8 + 12;


    if (y + 110 > height) {

      y =
        boardTop - 110;
    }


    if (mouseY >= y &&
        mouseY <= y + 48) {

      if (mouseX < width / 2) {

        // BOARD UP

        whiteSide = 0;

      } else {

        // BOARD DOWN

        whiteSide = 1;
      }

      calculateLayout();

      return true;
    }


    if (mouseY >= y + 55 &&
        mouseY <= y + 103) {

      if (mouseX < width / 2) {

        setEngineWhite();

      } else {

        setEngineBlack();
      }

      return true;
    }
  }


  // LANDSCAPE

  else {

    float y =
      height - 55;


    if (mouseY >= y &&
        mouseY <= y + 50) {

      if (mouseX < 105) {

        setWhiteSide(0);
        return true;
      }


      if (mouseX < 210) {

        setWhiteSide(1);
        return true;
      }


      if (mouseX < 315) {

        setWhiteSide(2);
        return true;
      }


      if (mouseX < 420) {

        setWhiteSide(3);
        return true;
      }
    }


    float ex =
      width - 210;


    if (mouseY >= 5 &&
        mouseY <= 55) {

      if (mouseX >= ex &&
          mouseX < ex + 100) {

        setEngineWhite();

        return true;
      }


      if (mouseX >= ex + 105 &&
          mouseX < ex + 210) {

        setEngineBlack();

        return true;
      }
    }
  }


  return false;
}


// ============================================================
// HUMAN / ENGINE
// ============================================================

boolean humanCanMove() {

  if (whiteTurn &&
      engineWhite) {

    return false;
  }


  if (!whiteTurn &&
      engineBlack) {

    return false;
  }


  return true;
}


// ============================================================
// ENGINE WHITE
// ============================================================

void setEngineWhite() {

  engineWhite = true;
  engineBlack = false;

  newGame();
}


// ============================================================
// ENGINE BLACK
// ============================================================

void setEngineBlack() {

  engineWhite = false;
  engineBlack = true;

  newGame();
}


// ============================================================
// WHITE SIDE
// ============================================================

void setWhiteSide(int side) {

  whiteSide = side;

  selectedX = -1;
  selectedY = -1;

  currentMoves.clear();

  calculateLayout();
}


// ============================================================
// ENGINE START
// ============================================================

void startEngine() {

  if (gameOver) {
    return;
  }


  if (engineThinking) {
    return;
  }


  engineThinking = true;

  thread("engineThread");
}


// ============================================================
// ENGINE THREAD
// ============================================================

void engineThread() {

  delay(80);


  nodes = 0;


  ArrayList<Move> moves =
    generateLegalMoves(
      whiteTurn
    );


  if (moves.size() == 0) {

    engineThinking = false;

    checkGameEnd();

    return;
  }


  Move best = null;

  int bestScore =
    -1000000000;


  // Simple move ordering:
  // captures first

  sortMoves(moves);


  for (Move m : moves) {

    makeMove(m);


    int score =
      -search(
        engineDepth - 1,
        -1000000000,
        1000000000,
        !whiteTurn
      );


    undoMove(m);


    if (best == null ||
        score > bestScore) {

      best = m;

      bestScore = score;
    }
  }


  if (best != null) {

    makeMove(best);
  }


  whiteTurn =
    !whiteTurn;


  engineThinking = false;


  checkGameEnd();
}


// ============================================================
// MOVE ORDERING
// ============================================================

void sortMoves(
  ArrayList<Move> moves) {

  for (int i = 0;
       i < moves.size();
       i++) {

    int best = i;

    int bestValue =
      moveValue(moves.get(i));


    for (int j = i + 1;
         j < moves.size();
         j++) {

      int v =
        moveValue(moves.get(j));


      if (v > bestValue) {

        best = j;

        bestValue = v;
      }
    }


    if (best != i) {

      Move tmp =
        moves.get(i);

      moves.set(
        i,
        moves.get(best)
      );

      moves.set(
        best,
        tmp
      );
    }
  }
}


// ============================================================
// MOVE VALUE
// ============================================================

int moveValue(Move m) {

  int v = 0;


  if (m.captured != EMPTY) {

    v +=
      pieceValue(
        abs(m.captured)
      ) * 10;
  }


  if (m.promotion != 0) {

    v += 900;
  }


  if (m.castle) {

    v += 50;
  }


  return v;
}


// ============================================================
// SEARCH
// ============================================================

int search(
  int depth,
  int alpha,
  int beta,
  boolean sideWhite) {

  nodes++;


  ArrayList<Move> moves =
    generateLegalMoves(
      sideWhite
    );


  if (moves.size() == 0) {

    if (isKingInCheck(sideWhite)) {

      return -900000 -
        depth;
    }


    return 0;
  }


  if (depth <= 0) {

    return evaluate();
  }


  sortMoves(moves);


  int best =
    -1000000000;


  for (Move m : moves) {

    makeMove(m);


    int score =
      -search(
        depth - 1,
        -beta,
        -alpha,
        !sideWhite
      );


    undoMove(m);


    if (score > best) {

      best = score;
    }


    if (score > alpha) {

      alpha = score;
    }


    if (alpha >= beta) {

      break;
    }
  }


  return best;
}


// ============================================================
// EVALUATION
// ============================================================

int evaluate() {

  int score = 0;


  for (int y = 0; y < 8; y++) {

    for (int x = 0; x < 8; x++) {

      int p =
        board[y][x];


      if (p == EMPTY) {
        continue;
      }


      int v =
        pieceValue(abs(p));


      if (p > 0) {

        score += v;

      } else {

        score -= v;
      }


      // pawn advancement

      if (p == WP) {

        score +=
          (6 - y) * 5;

      } else if (p == BP) {

        score -=
          (y - 1) * 5;
      }


      // center control

      if (abs(x - 3.5) < 2 &&
          abs(y - 3.5) < 2) {

        if (p > 0) {
          score += 3;
        } else {
          score -= 3;
        }
      }
    }
  }


  // Evaluation is White-positive.
  // Negamax requires side-to-move perspective.

  if (whiteTurn) {

    return score;

  } else {

    return -score;
  }
}


// ============================================================
// PIECE VALUE
// ============================================================

int pieceValue(int p) {

  if (p == 1) return 100;
  if (p == 2) return 320;
  if (p == 3) return 330;
  if (p == 4) return 500;
  if (p == 5) return 900;
  if (p == 6) return 20000;

  return 0;
}


// ============================================================
// LEGAL MOVES
// ============================================================

ArrayList<Move> generateLegalMoves(
  boolean white) {

  ArrayList<Move> pseudo =
    generatePseudoMoves(white);


  ArrayList<Move> legal =
    new ArrayList<Move>();


  for (Move m : pseudo) {

    makeMove(m);


    boolean check =
      isKingInCheck(white);


    undoMove(m);


    if (!check) {

      legal.add(m);
    }
  }


  return legal;
}


// ============================================================
// PSEUDO MOVES
// ============================================================

ArrayList<Move> generatePseudoMoves(
  boolean white) {

  ArrayList<Move> list =
    new ArrayList<Move>();


  for (int y = 0; y < 8; y++) {

    for (int x = 0; x < 8; x++) {

      int p =
        board[y][x];


      if (p == EMPTY) {
        continue;
      }


      if (white && p < 0) {
        continue;
      }


      if (!white && p > 0) {
        continue;
      }


      int type =
        abs(p);


      if (type == 1) {

        pawnMoves(
          x,y,white,list
        );

      } else if (type == 2) {

        knightMoves(
          x,y,white,list
        );

      } else if (type == 3) {

        bishopMoves(
          x,y,white,list
        );

      } else if (type == 4) {

        rookMoves(
          x,y,white,list
        );

      } else if (type == 5) {

        queenMoves(
          x,y,white,list
        );

      } else if (type == 6) {

        kingMoves(
          x,y,white,list
        );
      }
    }
  }


  return list;
}


// ============================================================
// PAWN
// ============================================================

void pawnMoves(
  int x,
  int y,
  boolean white,
  ArrayList<Move> list) {

  int dir =
    white ? -1 : 1;


  int start =
    white ? 6 : 1;


  int promo =
    white ? 0 : 7;


  int ny =
    y + dir;


  if (inside(x,ny) &&
      board[ny][x] == EMPTY) {

    addPawnMove(
      x,y,x,ny,
      white,promo,list
    );


    if (y == start &&
        board[y + 2*dir][x] ==
        EMPTY) {

      list.add(
        new Move(
          x,y,
          x,y + 2*dir
        )
      );
    }
  }


  for (int dx = -1;
       dx <= 1;
       dx += 2) {

    int nx =
      x + dx;


    if (!inside(nx,ny)) {
      continue;
    }


    int target =
      board[ny][nx];


    if (target != EMPTY &&
        ((white && target < 0) ||
         (!white && target > 0))) {

      addPawnMove(
        x,y,nx,ny,
        white,promo,list
      );
    }


    if (nx == enPassantX &&
        ny == enPassantY) {

      Move m =
        new Move(
          x,y,nx,ny
        );


      m.enPassant = true;

      list.add(m);
    }
  }
}


// ============================================================
// PAWN PROMOTION
// ============================================================

void addPawnMove(
  int fx,
  int fy,
  int tx,
  int ty,
  boolean white,
  int promotionY,
  ArrayList<Move> list) {

  Move m =
    new Move(
      fx,fy,tx,ty
    );


  if (ty == promotionY) {

    m.promotion =
      white ? WQ : BQ;
  }


  list.add(m);
}


// ============================================================
// KNIGHT
// ============================================================

void knightMoves(
  int x,
  int y,
  boolean white,
  ArrayList<Move> list) {

  int[][] d = {

    {1,2},
    {2,1},
    {2,-1},
    {1,-2},

    {-1,-2},
    {-2,-1},
    {-2,1},
    {-1,2}
  };


  for (int i = 0; i < 8; i++) {

    int nx =
      x + d[i][0];

    int ny =
      y + d[i][1];


    if (!inside(nx,ny)) {
      continue;
    }


    int p =
      board[ny][nx];


    if (p == EMPTY ||
        (white && p < 0) ||
        (!white && p > 0)) {

      list.add(
        new Move(
          x,y,nx,ny
        )
      );
    }
  }
}


// ============================================================
// BISHOP
// ============================================================

void bishopMoves(
  int x,
  int y,
  boolean white,
  ArrayList<Move> list) {

  slide(
    x,y,white,list,
    1,1
  );

  slide(
    x,y,white,list,
    1,-1
  );

  slide(
    x,y,white,list,
    -1,1
  );

  slide(
    x,y,white,list,
    -1,-1
  );
}


// ============================================================
// ROOK
// ============================================================

void rookMoves(
  int x,
  int y,
  boolean white,
  ArrayList<Move> list) {

  slide(
    x,y,white,list,
    1,0
  );

  slide(
    x,y,white,list,
    -1,0
  );

  slide(
    x,y,white,list,
    0,1
  );

  slide(
    x,y,white,list,
    0,-1
  );
}


// ============================================================
// QUEEN
// ============================================================

void queenMoves(
  int x,
  int y,
  boolean white,
  ArrayList<Move> list) {

  bishopMoves(
    x,y,white,list
  );

  rookMoves(
    x,y,white,list
  );
}


// ============================================================
// SLIDER
// ============================================================

void slide(
  int x,
  int y,
  boolean white,
  ArrayList<Move> list,
  int dx,
  int dy) {

  int nx =
    x + dx;

  int ny =
    y + dy;


  while (inside(nx,ny)) {

    int p =
      board[ny][nx];


    if (p == EMPTY) {

      list.add(
        new Move(
          x,y,nx,ny
        )
      );

    } else {

      if ((white && p < 0) ||
          (!white && p > 0)) {

        list.add(
          new Move(
            x,y,nx,ny
          )
        );
      }


      break;
    }


    nx += dx;
    ny += dy;
  }
}


// ============================================================
// KING
// ============================================================

void kingMoves(
  int x,
  int y,
  boolean white,
  ArrayList<Move> list) {

  for (int dx = -1;
       dx <= 1;
       dx++) {

    for (int dy = -1;
         dy <= 1;
         dy++) {

      if (dx == 0 &&
          dy == 0) {
        continue;
      }


      int nx =
        x + dx;

      int ny =
        y + dy;


      if (!inside(nx,ny)) {
        continue;
      }


      int p =
        board[ny][nx];


      if (p == EMPTY ||
          (white && p < 0) ||
          (!white && p > 0)) {

        list.add(
          new Move(
            x,y,nx,ny
          )
        );
      }
    }
  }


  // CASTLING


  if (white) {

    if (wCastleK &&
        board[7][5] == EMPTY &&
        board[7][6] == EMPTY &&

        !squareAttacked(
          4,7,false
        ) &&

        !squareAttacked(
          5,7,false
        ) &&

        !squareAttacked(
          6,7,false
        )) {

      Move m =
        new Move(
          4,7,6,7
        );

      m.castle = true;

      list.add(m);
    }


    if (wCastleQ &&
        board[7][1] == EMPTY &&
        board[7][2] == EMPTY &&
        board[7][3] == EMPTY &&

        !squareAttacked(
          4,7,false
        ) &&

        !squareAttacked(
          3,7,false
        ) &&

        !squareAttacked(
          2,7,false
        )) {

      Move m =
        new Move(
          4,7,2,7
        );

      m.castle = true;

      list.add(m);
    }

  } else {

    if (bCastleK &&
        board[0][5] == EMPTY &&
        board[0][6] == EMPTY &&

        !squareAttacked(
          4,0,true
        ) &&

        !squareAttacked(
          5,0,true
        ) &&

        !squareAttacked(
          6,0,true
        )) {

      Move m =
        new Move(
          4,0,6,0
        );

      m.castle = true;

      list.add(m);
    }


    if (bCastleQ &&
        board[0][1] == EMPTY &&
        board[0][2] == EMPTY &&
        board[0][3] == EMPTY &&

        !squareAttacked(
          4,0,true
        ) &&

        !squareAttacked(
          3,0,true
        ) &&

        !squareAttacked(
          2,0,true
        )) {

      Move m =
        new Move(
          4,0,2,0
        );

      m.castle = true;

      list.add(m);
    }
  }
}


// ============================================================
// MAKE MOVE
// ============================================================

void makeMove(Move m) {

  int p =
    board[m.fy][m.fx];


  board[m.fy][m.fx] =
    EMPTY;


  // en-passant capture

  if (m.enPassant) {

    if (p == WP) {

      board[m.ty + 1][m.tx] =
        EMPTY;

    } else {

      board[m.ty - 1][m.tx] =
        EMPTY;
    }
  }


  board[m.ty][m.tx] =
    p;


  // promotion

  if (m.promotion != 0) {

    board[m.ty][m.tx] =
      m.promotion;
  }


  // castle rook

  if (m.castle) {

    if (m.tx == 6) {

      board[m.ty][5] =
        board[m.ty][7];

      board[m.ty][7] =
        EMPTY;

    } else {

      board[m.ty][3] =
        board[m.ty][0];

      board[m.ty][0] =
        EMPTY;
    }
  }


  // castling rights

  if (p == WK) {

    wCastleK = false;
    wCastleQ = false;
  }


  if (p == BK) {

    bCastleK = false;
    bCastleQ = false;
  }


  if (m.fx == 0 &&
      m.fy == 7) {

    wCastleQ = false;
  }


  if (m.fx == 7 &&
      m.fy == 7) {

    wCastleK = false;
  }


  if (m.fx == 0 &&
      m.fy == 0) {

    bCastleQ = false;
  }


  if (m.fx == 7 &&
      m.fy == 0) {

    bCastleK = false;
  }


  // captured rook

  if (m.tx == 0 &&
      m.ty == 7) {

    wCastleQ = false;
  }


  if (m.tx == 7 &&
      m.ty == 7) {

    wCastleK = false;
  }


  if (m.tx == 0 &&
      m.ty == 0) {

    bCastleQ = false;
  }


  if (m.tx == 7 &&
      m.ty == 0) {

    bCastleK = false;
  }


  // en passant

  enPassantX = -1;
  enPassantY = -1;


  if (abs(p) == 1 &&
      abs(m.ty - m.fy) == 2) {

    enPassantX =
      m.fx;

    enPassantY =
      (m.fy + m.ty) / 2;
  }
}


// ============================================================
// UNDO
// ============================================================

void undoMove(Move m) {

  int p =
    board[m.ty][m.tx];


  if (m.promotion != 0) {

    p =
      p > 0 ? WP : BP;
  }


  board[m.fy][m.fx] =
    p;


  board[m.ty][m.tx] =
    m.captured;


  // en passant restore

  if (m.enPassant) {

    if (p == WP) {

      board[m.ty + 1][m.tx] =
        BP;

    } else {

      board[m.ty - 1][m.tx] =
        WP;
    }


    board[m.ty][m.tx] =
      EMPTY;
  }


  // castle rook restore

  if (m.castle) {

    if (m.tx == 6) {

      board[m.ty][7] =
        board[m.ty][5];

      board[m.ty][5] =
        EMPTY;

    } else {

      board[m.ty][0] =
        board[m.ty][3];

      board[m.ty][3] =
        EMPTY;
    }
  }


  // restore complete state

  enPassantX =
    m.oldEPX;

  enPassantY =
    m.oldEPY;


  wCastleK =
    m.oldWCK;

  wCastleQ =
    m.oldWCQ;

  bCastleK =
    m.oldBCK;

  bCastleQ =
    m.oldBCQ;
}


// ============================================================
// CHECK
// ============================================================

boolean isKingInCheck(
  boolean white) {

  int king =
    white ? WK : BK;


  int kx = -1;
  int ky = -1;


  for (int y = 0; y < 8; y++) {

    for (int x = 0; x < 8; x++) {

      if (board[y][x] == king) {

        kx = x;
        ky = y;
      }
    }
  }


  if (kx < 0) {
    return true;
  }


  return squareAttacked(
    kx,
    ky,
    !white
  );
}


// ============================================================
// ATTACK TEST
// ============================================================

boolean squareAttacked(
  int x,
  int y,
  boolean byWhite) {


  // PAWN

  int pawn =
    byWhite ? WP : BP;


  int py =
    y + (byWhite ? 1 : -1);


  for (int dx = -1;
       dx <= 1;
       dx += 2) {

    int px =
      x + dx;


    if (inside(px,py) &&
        board[py][px] == pawn) {

      return true;
    }
  }


  // KNIGHT

  int knight =
    byWhite ? WN : BN;


  int[][] nd = {

    {1,2},
    {2,1},
    {2,-1},
    {1,-2},

    {-1,-2},
    {-2,-1},
    {-2,1},
    {-1,2}
  };


  for (int i = 0; i < 8; i++) {

    int nx =
      x + nd[i][0];

    int ny =
      y + nd[i][1];


    if (inside(nx,ny) &&
        board[ny][nx] == knight) {

      return true;
    }
  }


  // BISHOP / QUEEN

  int bishop =
    byWhite ? WB : BB;

  int queen =
    byWhite ? WQ : BQ;


  int[][] diag = {

    {1,1},
    {1,-1},
    {-1,1},
    {-1,-1}
  };


  for (int d = 0; d < 4; d++) {

    int nx =
      x + diag[d][0];

    int ny =
      y + diag[d][1];


    while (inside(nx,ny)) {

      int p =
        board[ny][nx];


      if (p != EMPTY) {

        if (p == bishop ||
            p == queen) {

          return true;
        }


        break;
      }


      nx += diag[d][0];
      ny += diag[d][1];
    }
  }


  // ROOK / QUEEN

  int rook =
    byWhite ? WR : BR;


  int[][] line = {

    {1,0},
    {-1,0},
    {0,1},
    {0,-1}
  };


  for (int d = 0; d < 4; d++) {

    int nx =
      x + line[d][0];

    int ny =
      y + line[d][1];


    while (inside(nx,ny)) {

      int p =
        board[ny][nx];


      if (p != EMPTY) {

        if (p == rook ||
            p == queen) {

          return true;
        }


        break;
      }


      nx += line[d][0];
      ny += line[d][1];
    }
  }


  // KING

  int king =
    byWhite ? WK : BK;


  for (int dx = -1;
       dx <= 1;
       dx++) {

    for (int dy = -1;
         dy <= 1;
         dy++) {

      if (dx == 0 &&
          dy == 0) {

        continue;
      }


      int nx =
        x + dx;

      int ny =
        y + dy;


      if (inside(nx,ny) &&
          board[ny][nx] == king) {

        return true;
      }
    }
  }


  return false;
}


// ============================================================
// GAME END
// ============================================================

void checkGameEnd() {

  ArrayList<Move> moves =
    generateLegalMoves(
      whiteTurn
    );


  if (moves.size() == 0) {

    gameOver = true;
  }
}


// ============================================================
// OWN PIECE
// ============================================================

boolean isOwnPiece(
  int x,
  int y) {

  int p =
    board[y][x];


  if (whiteTurn) {

    return p > 0;

  } else {

    return p < 0;
  }
}


// ============================================================
// INSIDE
// ============================================================

boolean inside(
  int x,
  int y) {

  return
    x >= 0 &&
    x < 8 &&
    y >= 0 &&
    y < 8;
}





















































