



// ============================================================
// TURTLE NINJA 2D
// Single-file APDE 0.5.3 prototype
// Android / Processing
// ============================================================

boolean portraitMode;

float camX = 0;

Hero player;
ArrayList<Enemy> enemies = new ArrayList<Enemy>();
ArrayList<Block> blocks = new ArrayList<Block>();

int gameTime = 60;
int lastSecond;

boolean gameOver = false;
boolean win = false;

// Touch buttons
boolean leftDown = false;
boolean rightDown = false;
boolean jumpDown = false;
boolean attackDown = false;
boolean dashDown = false;

// ------------------------------------------------------------

void setup() {
  fullScreen(P2D);
  frameRate(60);
  smooth(0);

  portraitMode = height > width;

  resetGame();
}

// ------------------------------------------------------------

void resetGame() {
  camX = 0;
  gameOver = false;
  win = false;

  player = new Hero(180, height * 0.62);

  enemies.clear();
  blocks.clear();

  // Ground
  blocks.add(new Block(-500, height * 0.75, 4000, height * 0.30));

  // Platforms
  blocks.add(new Block(500, height * 0.58, 260, 35));
  blocks.add(new Block(950, height * 0.50, 250, 35));
  blocks.add(new Block(1400, height * 0.60, 300, 35));
  blocks.add(new Block(1950, height * 0.52, 280, 35));
  blocks.add(new Block(2450, height * 0.62, 300, 35));

  // Enemies
  enemies.add(new Enemy(650, height * 0.62));
  enemies.add(new Enemy(1050, height * 0.62));
  enemies.add(new Enemy(1500, height * 0.62));
  enemies.add(new Enemy(2100, height * 0.62));
  enemies.add(new Enemy(2600, height * 0.62));
  enemies.add(new Enemy(3100, height * 0.62));

  lastSecond = millis();
}

// ------------------------------------------------------------

void draw() {
  background(8, 3, 20);

  drawCity();

  if (!gameOver && !win) {
    updateGame();
  }

  pushMatrix();
  translate(-camX, 0);

  for (Block b : blocks) b.drawBlock();

  for (Enemy e : enemies) {
    e.drawEnemy();
  }

  player.drawHero();

  popMatrix();

  drawHUD();
  drawControls();

  if (gameOver) drawGameOver();
  if (win) drawWin();
}

// ============================================================
// GAME
// ============================================================

void updateGame() {

  // Timer
  if (millis() - lastSecond >= 1000) {
    gameTime--;
    lastSecond = millis();

    if (gameTime <= 0) {
      gameTime = 0;
      gameOver = true;
    }
  }

  player.updateHero();

  for (Enemy e : enemies) {
    e.updateEnemy();

    if (!e.dead && hitTest(player.x, player.y, 45, 70,
                           e.x, e.y, 40, 65)) {

      if (player.attackTimer <= 0) {
        player.health -= 0.15;
      }
    }
  }

  // Remove defeated enemies
  boolean allDead = true;

  for (Enemy e : enemies) {
    if (!e.dead) allDead = false;
  }

  if (allDead) win = true;

  // Camera
  camX = player.x - width * 0.38;

  if (camX < 0) camX = 0;
}

// ============================================================
// CITY BACKGROUND
// ============================================================

void drawCity() {

  // Purple sky
  noStroke();
  fill(50, 0, 100);
  rect(0, 0, width, height);

  fill(85, 0, 150);
  rect(0, height * 0.28, width, height * 0.47);

  // Moon
  fill(150, 70, 255);
  ellipse(width * 0.82, height * 0.23, 90, 90);

  // Buildings
  float scaleX = width / 720.0;

  for (int i = -2; i < 18; i++) {

    float bx = i * 65 * scaleX;
    float bh = 80 + ((i * 37) % 130);

    if (bh < 50) bh += 100;

    fill(8, 5, 18);
    rect(bx,
         height * 0.57 - bh,
         55 * scaleX,
         bh);

    fill(130, 40, 220);

    for (int yy = 0; yy < bh - 15; yy += 25) {
      for (int xx = 8; xx < 45; xx += 18) {
        rect(bx + xx * scaleX,
             height * 0.57 - bh + yy,
             7 * scaleX,
             9);
      }
    }
  }

  // Bridge / street
  fill(15, 20, 35);
  rect(0, height * 0.68, width, height * 0.15);

  stroke(20, 130, 210);
  strokeWeight(5);

  for (int y = 0; y < 4; y++) {
    line(0,
         height * 0.70 + y * 22,
         width,
         height * 0.70 + y * 22);
  }

  noStroke();

  // Street lights
  for (int x = 30; x < width; x += 120) {
    fill(20);
    rect(x, height * 0.48, 6, height * 0.25);

    fill(150, 255, 100);
    ellipse(x + 3, height * 0.48, 12, 12);
  }
}

// ============================================================
// HERO
// ============================================================

class Hero {

  float x, y;
  float vx, vy;

  float health = 100;

  boolean grounded = false;

  int attackTimer = 0;
  int dashTimer = 0;

  Hero(float xx, float yy) {
    x = xx;
    y = yy;
  }

  void updateHero() {

    float speed = 5.0;

    if (leftDown) {
      vx = -speed;
    } else if (rightDown) {
      vx = speed;
    } else {
      vx *= 0.75;
    }

    if (dashDown && dashTimer <= 0) {
      if (rightDown) vx = 13;
      if (leftDown) vx = -13;

      dashTimer = 30;
    }

    if (jumpDown && grounded) {
      vy = -12;
      grounded = false;
    }

    if (attackDown && attackTimer <= 0) {
      attackTimer = 20;
    }

    if (attackTimer > 0) {
      attackTimer--;

      // Attack hit
      if (attackTimer == 12) {
        for (Enemy e : enemies) {
          if (!e.dead &&
              abs(e.x - x) < 85 &&
              abs(e.y - y) < 70) {

            e.health -= 35;
            e.vx = (e.x > x) ? 7 : -7;

            if (e.health <= 0) {
              e.dead = true;
            }
          }
        }
      }
    }

    if (dashTimer > 0) dashTimer--;

    // Gravity
    vy += 0.55;

    x += vx;
    y += vy;

    grounded = false;

    // Collision with blocks
    for (Block b : blocks) {

      if (x + 22 > b.x &&
          x - 22 < b.x + b.w &&
          y + 65 > b.y &&
          y + 65 < b.y + b.h + 25 &&
          vy >= 0) {

        y = b.y - 65;
        vy = 0;
        grounded = true;
      }
    }

    if (x < 30) x = 30;

    if (health <= 0) {
      health = 0;
      gameOver = true;
    }
  }

  void drawHero() {

    pushMatrix();
    translate(x, y);

    // shadow
    noStroke();
    fill(0, 0, 0, 100);
    ellipse(0, 67, 55, 12);

    // legs
    fill(20, 120, 45);
    rect(-18, 35, 14, 28);
    rect(5, 35, 14, 28);

    // feet
    fill(30, 180, 55);
    rect(-25, 58, 22, 9);
    rect(3, 58, 22, 9);

    // shell
    fill(20, 105, 45);
    ellipse(0, 5, 58, 68);

    // shell lines
    stroke(10, 50, 25);
    strokeWeight(3);
    line(-20, -5, 20, 18);
    line(20, -5, -20, 18);
    noStroke();

    // body
    fill(40, 180, 65);
    ellipse(0, 5, 42, 55);

    // head
    fill(45, 190, 70);
    ellipse(0, -38, 43, 40);

    // mask
    fill(220, 40, 55);
    rect(-23, -45, 46, 12);

    // eyes
    fill(255);
    ellipse(-10, -39, 8, 8);
    ellipse(10, -39, 8, 8);

    // arms
    stroke(40, 180, 65);
    strokeWeight(11);

    if (attackTimer > 0) {
      line(12, -5, 65, -18);

      // weapon
      stroke(220);
      strokeWeight(4);
      line(52, -30, 78, -30);
    } else {
      line(18, 0, 35, 20);
    }

    line(-18, 0, -32, 18);

    noStroke();

    // belt
    fill(210, 170, 40);
    rect(-21, 19, 42, 8);

    popMatrix();
  }
}

// ============================================================
// ENEMY
// ============================================================

class Enemy {

  float x, y;
  float vx = 0;

  float health = 100;
  boolean dead = false;

  Enemy(float xx, float yy) {
    x = xx;
    y = yy;
  }

  void updateEnemy() {

    if (dead) return;

    float distance = player.x - x;

    if (abs(distance) < 450) {

      if (distance > 55) vx = 1.5;
      else if (distance < -55) vx = -1.5;
      else vx = 0;
    }

    x += vx;

    // gravity
    y += 0;

    // Enemy attack
    if (abs(distance) < 65 &&
        frameCount % 45 == 0) {
      player.health -= 4;
    }
  }

  void drawEnemy() {

    if (dead) {

      // fallen body
      pushMatrix();
      translate(x, y + 50);

      fill(20, 80, 30);
      ellipse(0, 0, 65, 25);

      popMatrix();

      return;
    }

    pushMatrix();
    translate(x, y);

    // shadow
    fill(0, 0, 0, 100);
    ellipse(0, 67, 55, 12);

    // legs
    fill(120, 30, 30);
    rect(-16, 35, 12, 28);
    rect(5, 35, 12, 28);

    // body
    fill(100, 35, 40);
    ellipse(0, 8, 48, 60);

    // head
    fill(145, 45, 45);
    ellipse(0, -35, 42, 40);

    // black mask
    fill(20);
    rect(-22, -42, 44, 12);

    // eyes
    fill(255, 230, 80);
    ellipse(-9, -37, 7, 7);
    ellipse(9, -37, 7, 7);

    // arms
    stroke(150, 45, 45);
    strokeWeight(10);
    line(-18, 0, -35, 20);
    line(18, 0, 35, 20);
    noStroke();

    popMatrix();

    // health
    fill(40);
    rect(x - 25, y - 70, 50, 6);

    fill(230, 30, 30);
    rect(x - 25, y - 70, 50 * health / 100.0, 6);
  }
}

// ============================================================
// BLOCKS
// ============================================================

class Block {

  float x, y, w, h;

  Block(float xx, float yy, float ww, float hh) {
    x = xx;
    y = yy;
    w = ww;
    h = hh;
  }

  void drawBlock() {

    fill(25, 35, 45);
    rect(x, y, w, h);

    fill(35, 100, 140);
    rect(x, y, w, 7);

    stroke(15, 20, 25);
    strokeWeight(3);

    for (int xx = int(x); xx < x + w; xx += 45) {
      line(xx, y + 8, xx + 20, y + h);
    }

    noStroke();
  }
}

// ============================================================
// HUD
// ============================================================

void drawHUD() {

  // Health
  fill(255);
  textAlign(LEFT, CENTER);
  textSize(22);
  text("NINJA", 25, 25);

  fill(30);
  rect(25, 42, width * 0.35, 20);

  fill(30, 220, 50);
  rect(25, 42,
       width * 0.35 * player.health / 100.0,
       20);

  // Timer
  textAlign(CENTER, CENTER);
  fill(255);
  textSize(30);
  text(gameTime, width / 2, 45);

  // enemy count
  int alive = 0;

  for (Enemy e : enemies) {
    if (!e.dead) alive++;
  }

  textSize(16);
  text("ENEMIES " + alive,
       width - 75,
       45);
}

// ============================================================
// TOUCH CONTROLS
// ============================================================

void drawControls() {

  float s = min(width, height);

  float r = s * 0.075;

  // Left
  drawButton(r * 1.25,
             height - r * 2.0,
             r,
             "◀");

  // Right
  drawButton(r * 3.0,
             height - r * 2.0,
             r,
             "▶");

  // Jump
  drawButton(width - r * 3.0,
             height - r * 2.8,
             r,
             "▲");

  // A
  drawButton(width - r * 1.6,
             height - r * 2.0,
             r,
             "A");

  // B
  drawButton(width - r * 3.0,
             height - r * 1.0,
             r,
             "B");

  // START
  drawButton(width - 65,
             55,
             35,
             "START");
}

void drawButton(float x, float y,
                float r, String label) {

  fill(20, 20, 20, 90);
  stroke(210, 210, 210, 120);
  strokeWeight(2);

  ellipse(x, y, r * 2, r * 2);

  noStroke();

  fill(255, 255, 255, 180);

  textAlign(CENTER, CENTER);
  textSize(r * 0.42);
  text(label, x, y);
}

// ============================================================
// TOUCH
// ============================================================

void mousePressed() {

  float s = min(width, height);
  float r = s * 0.075;

  float x = mouseX;
  float y = mouseY;

  leftDown =
    dist(x, y,
         r * 1.25,
         height - r * 2.0) < r;

  rightDown =
    dist(x, y,
         r * 3.0,
         height - r * 2.0) < r;

  jumpDown =
    dist(x, y,
         width - r * 3.0,
         height - r * 2.8) < r;

  attackDown =
    dist(x, y,
         width - r * 1.6,
         height - r * 2.0) < r;

  dashDown =
    dist(x, y,
         width - r * 3.0,
         height - r * 1.0) < r;

  // START
  if (dist(x, y, width - 65, 55) < 45) {
    resetGame();
  }
}

void mouseDragged() {
  mousePressed();
}

void mouseReleased() {
  leftDown = false;
  rightDown = false;
  jumpDown = false;
  attackDown = false;
  dashDown = false;
}

// ============================================================
// COLLISION
// ============================================================

boolean hitTest(float x1, float y1,
                float w1, float h1,
                float x2, float y2,
                float w2, float h2) {

  return abs(x1 - x2) < (w1 + w2) * 0.5 &&
         abs(y1 - y2) < (h1 + h2) * 0.5;
}

// ============================================================
// END SCREENS
// ============================================================

void drawGameOver() {

  fill(0, 0, 0, 190);
  rect(0, 0, width, height);

  fill(255, 50, 50);
  textAlign(CENTER, CENTER);
  textSize(45);
  text("GAME OVER", width / 2, height / 2 - 30);

  fill(255);
  textSize(20);
  text("PRESS START",
       width / 2,
       height / 2 + 35);
}

void drawWin() {

  fill(0, 0, 0, 180);
  rect(0, 0, width, height);

  fill(60, 255, 100);
  textAlign(CENTER, CENTER);
  textSize(45);
  text("STAGE CLEAR",
       width / 2,
       height / 2 - 30);

  fill(255);
  textSize(20);
  text("PRESS START",
       width / 2,
       height / 2 + 35);
}






























