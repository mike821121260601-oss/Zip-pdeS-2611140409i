






import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.graphics.PixelFormat;
import android.graphics.Color;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.os.Build;

WindowManager wm;
DrawView drawView;
LinearLayout controls;

boolean drawing = true;
boolean erasing = false;

void setup() {
  size(1, 1);

  // Request "Display over other apps"
  if (Build.VERSION.SDK_INT >= 23) {
    if (!Settings.canDrawOverlays(getActivity())) {

      Intent intent = new Intent(
        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
        Uri.parse("package:" + getActivity().getPackageName())
      );

      getActivity().startActivity(intent);
    }
  }

  delay(1000);

  createOverlay();
}

void draw() {
  // Nothing is drawn by the Processing surface.
  // The real transparent drawing is the Android overlay.
}

void createOverlay() {

  wm = (WindowManager)getActivity()
    .getSystemService(getActivity().WINDOW_SERVICE);

  // -----------------------------
  // TRANSPARENT DRAWING VIEW
  // -----------------------------

  drawView = new DrawView();

  WindowManager.LayoutParams lp =
    new WindowManager.LayoutParams();

  lp.width = WindowManager.LayoutParams.MATCH_PARENT;
  lp.height = WindowManager.LayoutParams.MATCH_PARENT;

  lp.gravity = Gravity.TOP | Gravity.LEFT;

  lp.format = PixelFormat.TRANSLUCENT;

  lp.flags =
    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;

  if (Build.VERSION.SDK_INT >= 26) {
    lp.type =
      WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
  }

  wm.addView(drawView, lp);

  // -----------------------------
  // CONTROL BUTTONS
  // -----------------------------

  controls = new LinearLayout(getActivity());

  controls.setOrientation(LinearLayout.HORIZONTAL);

  controls.setBackgroundColor(
    Color.argb(160, 30, 30, 30)
  );

  Button drawButton =
    new Button(getActivity());

  drawButton.setText("DRAW");

  drawButton.setOnClickListener(
    new View.OnClickListener() {
      public void onClick(View v) {
        drawing = true;
        erasing = false;
      }
    }
  );

  Button eraseButton =
    new Button(getActivity());

  eraseButton.setText("ERASE");

  eraseButton.setOnClickListener(
    new View.OnClickListener() {
      public void onClick(View v) {
        drawing = false;
        erasing = true;
      }
    }
  );

  Button clearButton =
    new Button(getActivity());

  clearButton.setText("CLEAR");

  clearButton.setOnClickListener(
    new View.OnClickListener() {
      public void onClick(View v) {
        drawView.clearDrawing();
      }
    }
  );

  Button closeButton =
    new Button(getActivity());

  closeButton.setText("X");

  closeButton.setOnClickListener(
    new View.OnClickListener() {
      public void onClick(View v) {
        removeOverlay();
      }
    }
  );

  controls.addView(drawButton);
  controls.addView(eraseButton);
  controls.addView(clearButton);
  controls.addView(closeButton);

  WindowManager.LayoutParams cp =
    new WindowManager.LayoutParams();

  cp.width =
    WindowManager.LayoutParams.WRAP_CONTENT;

  cp.height =
    WindowManager.LayoutParams.WRAP_CONTENT;

  cp.gravity =
    Gravity.TOP | Gravity.CENTER_HORIZONTAL;

  cp.format = PixelFormat.TRANSLUCENT;

  cp.flags =
    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;

  if (Build.VERSION.SDK_INT >= 26) {
    cp.type =
      WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
  }

  wm.addView(controls, cp);
}


// ======================================
// REMOVE OVERLAY
// ======================================

void removeOverlay() {

  try {

    if (drawView != null) {
      wm.removeView(drawView);
      drawView = null;
    }

    if (controls != null) {
      wm.removeView(controls);
      controls = null;
    }

  } catch (Exception e) {
    println(e);
  }
}


// ======================================
// DRAW VIEW
// ======================================

class DrawView extends View {

  android.graphics.Bitmap bitmap;

  android.graphics.Canvas canvas;

  android.graphics.Paint paint;

  float oldX;
  float oldY;

  boolean firstTouch = true;

  DrawView() {

    super(getActivity());

    setBackgroundColor(Color.TRANSPARENT);

    paint = new android.graphics.Paint();

    paint.setAntiAlias(true);

    paint.setStrokeWidth(8);

    paint.setStrokeCap(
      android.graphics.Paint.Cap.ROUND
    );

    paint.setStyle(
      android.graphics.Paint.Style.STROKE
    );

    paint.setColor(Color.RED);
  }


  protected void onSizeChanged(
    int w,
    int h,
    int oldw,
    int oldh
  ) {

    bitmap =
      android.graphics.Bitmap.createBitmap(
        w,
        h,
        android.graphics.Bitmap.Config.ARGB_8888
      );

    canvas =
      new android.graphics.Canvas(bitmap);
  }


  protected void onDraw(
    android.graphics.Canvas c
  ) {

    super.onDraw(c);

    // Draw only our pixels.
    // Everything else stays transparent.

    if (bitmap != null) {
      c.drawBitmap(bitmap, 0, 0, null);
    }
  }


  public boolean onTouchEvent(MotionEvent event) {

    float x = event.getX();
    float y = event.getY();

    if (event.getAction() ==
        MotionEvent.ACTION_DOWN) {

      oldX = x;
      oldY = y;

      firstTouch = false;

      return true;
    }


    if (event.getAction() ==
        MotionEvent.ACTION_MOVE) {

      if (drawing) {

        paint.setColor(Color.RED);

        paint.setStrokeWidth(8);

        canvas.drawLine(
          oldX,
          oldY,
          x,
          y,
          paint
        );

      }


      if (erasing) {

        paint.setColor(Color.TRANSPARENT);

        paint.setStrokeWidth(40);

        paint.setXfermode(
          new android.graphics.PorterDuffXfermode(
            android.graphics.PorterDuff.Mode.CLEAR
          )
        );

        canvas.drawLine(
          oldX,
          oldY,
          x,
          y,
          paint
        );

        paint.setXfermode(null);
      }


      oldX = x;
      oldY = y;

      invalidate();

      return true;
    }


    if (event.getAction() ==
        MotionEvent.ACTION_UP) {

      return true;
    }

    return true;
  }


  void clearDrawing() {

    if (canvas != null) {

      canvas.drawColor(
        Color.TRANSPARENT,
        android.graphics.PorterDuff.Mode.CLEAR
      );

      invalidate();
    }
  }
}












/*

//permissions

import android.view.Window;
import android.view.WindowManager;
import android.graphics.Color;
import android.os.Build;
import android.provider.Settings;
import android.content.Intent;
import android.net.Uri;
import android.graphics.PixelFormat;

ArrayList<PVector> lines = new ArrayList<PVector>();

void setup() {
  fullScreen(P2D);

  // Transparent Processing surface
 ///// surface.setTitle("Transparent Draw");

  Window w = getActivity().getWindow();

  w.setFormat(PixelFormat.TRANSLUCENT);







 //// w.clearFlags(WindowManager.LayoutParams.FLAG_OPAQUE);


w.clearFlags(


/////
WindowManager.LayoutParams.FLAG_OPAQUE


);




  w.addFlags(
    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
  );

  // Transparent window
  w.setBackgroundDrawableResource(
    android.R.color.transparent
  );

  // Ask Android for overlay permission
  if (Build.VERSION.SDK_INT >= 23) {
    if (!Settings.canDrawOverlays(getActivity())) {
      Intent i = new Intent(
        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
        Uri.parse
  ("package:" + getActivity().getPackageName())
      );
      getActivity().startActivity(i);
    }
  }

  strokeWeight(5);
  stroke(255, 0, 0);
  noFill();
}

void draw() {
  // IMPORTANT:
  // Do NOT use background().
  // The previous app remains visible.

  // Draw stored lines
  for (int i = 0; i < lines.size(); i += 2) {
    PVector a = lines.get(i);
    PVector b = lines.get(i + 1);

    line(a.x, a.y, b.x, b.y);
  }

  // Current drawing
  if (mousePressed) {
    stroke(255, 0, 0);
    strokeWeight(5);

    line(pmouseX, pmouseY, mouseX, mouseY);

    lines.add(new PVector(pmouseX, pmouseY));
    lines.add(new PVector(mouseX, mouseY));
  }
}

void touchStarted() {
  // Start drawing
}

void touchMoved() {
  // Drawing is handled in draw()
}

void touchEnded() {
}

// ERASE EVERYTHING DRAWN BY THIS APP
void eraseAll() {
  lines.clear();
}


*/

















