


//GPT//
// ============================================================
// APDE CHESS - ENGINE VS ENGINE
// Pieces are drawn geometrically - NO chess text characters
// ============================================================

int[][] b = new int[8][8];

int WHITE = 1;
int BLACK = -1;

int turn = WHITE;

long thinkStart = 0;
long moveWaitStart = 0;

boolean thinking = false;
boolean waiting = false;

int THINK_TIME = 4000;
int FREE_TIME = 14000;

Move bestMove = null;

int selectedX = -1;
int selectedY = -1;

int lastFromX = -1;
int lastFromY = -1;
int lastToX = -1;
int lastToY = -1;

boolean whiteCastleK = true;
boolean whiteCastleQ = true;
boolean blackCastleK = true;
boolean blackCastleQ = true;

int epX = -1;
int epY = -1;

int moveNumber = 1;


// ============================================================
// SETUP
// ============================================================

void settings() {
  size(displayWidth, displayHeight, P2D);
}

void setup() {
  orientation(PORTRAIT);
  rectMode(CENTER);
  ellipseMode(CENTER);
  noStroke();

  newGame();
}


// ============================================================
// NEW GAME
// ============================================================

void newGame() {

  for (int y = 0; y < 8; y++)
    for (int x = 0; x < 8; x++)
      b[y][x] = 0;

  // BLACK
  b[0][0] = -4;
  b[0][1] = -2;
  b[0][2] = -3;
  b[0][3] = -5;
  b[0][4] = -6;
  b[0][5] = -3;
  b[0][6] = -2;
  b[0][7] = -4;

  for (int x = 0; x < 8; x++)
    b[1][x] = -1;

  // WHITE
  for (int x = 0; x < 8; x++)
    b[6][x] = 1;

  b[7][0] = 4;
  b[7][1] = 2;
  b[7][2] = 3;
  b[7][3] = 5;
  b[7][4] = 6;
  b[7][5] = 3;
  b[7][6] = 2;
  b[7][7] = 4;

  turn = WHITE;

  whiteCastleK = true;
  whiteCastleQ = true;
  blackCastleK = true;
  blackCastleQ = true;

  epX = -1;
  epY = -1;

  moveNumber = 1;

  thinking = false;
  waiting = false;

  bestMove = null;
}


// ============================================================
// DRAW
// ============================================================

void draw() {

  background(20);

  drawBoard();
  drawPieces();

  // ENGINE CONTROL
  if (!thinking && !waiting) {

    thinking = true;
    thinkStart = millis();

    bestMove = null;
  }

  if (thinking) {

    // Search during the 4 second thinking period
    if (millis() - thinkStart < THINK_TIME) {

      bestMove = findEngineMove(turn);

    } else {

      thinking = false;

      if (bestMove != null) {
        makeMove(bestMove);
      }

      waiting = true;
      moveWaitStart = millis();
    }
  }

  if (waiting) {

    if (millis() - moveWaitStart >= FREE_TIME) {
      waiting = false;
    }
  }

  drawInformation();
}


// ============================================================
// BOARD
// ============================================================

void drawBoard() {

  float s = min(displayWidth, displayHeight) * 0.92;
  float bx = (displayWidth - s) / 2;
  float by = displayHeight * 0.08;

  for (int y = 0; y < 8; y++) {

    for (int x = 0; x < 8; x++) {

      if ((x + y) % 2 == 0)
        fill(230, 220, 180);
      else
        fill(90, 120, 150);

      rect(
        bx + (x + 0.5) * s / 8,
        by + (y + 0.5) * s / 8,
        s / 8 + 1,
        s / 8 + 1
      );
    }
  }

  // LAST MOVE
  if (lastFromX >= 0) {

    fill(255, 255, 0, 90);

    rect(
      bx + (lastFromX + 0.5) * s / 8,
      by + (lastFromY + 0.5) * s / 8,
      s / 8,
      s / 8
    );

    rect(
      bx + (lastToX + 0.5) * s / 8,
      by + (lastToY + 0.5) * s / 8,
      s / 8,
      s / 8
    );
  }
}


// ============================================================
// PIECES
// ============================================================

void drawPieces() {

  float s = min(displayWidth, displayHeight) * 0.92;
  float bx = (displayWidth - s) / 2;
  float by = displayHeight * 0.08;

  for (int y = 0; y < 8; y++) {

    for (int x = 0; x < 8; x++) {

      int p = b[y][x];

      if (p != 0) {

        float px = bx + (x + 0.5) * s / 8;
        float py = by + (y + 0.5) * s / 8;

        drawPiece(px, py, s / 8 * 0.82, p);
      }
    }
  }
}


// ============================================================
// GEOMETRIC CHESS PIECES
// ============================================================

void drawPiece(float x, float y, float z, int p) {

  boolean white = p > 0;

  if (white)
    fill(220, 30, 30);
  else
    fill(20, 40, 220);

  int type = abs(p);

  // PAWN
  if (type == 1) {

    ellipse(x, y - z * 0.20,
            z * 0.30, z * 0.30);

    rect(x, y + z * 0.10,
         z * 0.50, z * 0.40);

    rect(x, y + z * 0.35,
         z * 0.68, z * 0.18);
  }

  // KNIGHT
  if (type == 2) {

    triangle(
      x - z * .30, y + z * .32,
      x + z * .30, y + z * .32,
      x + z * .10, y - z * .35
    );

    rect(x, y + z * .34,
         z * .70, z * .16);

    ellipse(x + z * .05,
            y - z * .25,
            z * .22,
            z * .22);
  }

  // BISHOP
  if (type == 3) {

    ellipse(x, y - z * .20,
            z * .35, z * .35);

    triangle(
      x,
      y - z * .43,
      x - z * .30,
      y + z * .25,
      x + z * .30,
      y + z * .25
    );

    rect(x, y + z * .35,
         z * .70, z * .18);
  }

  // ROOK
  if (type == 4) {

    rect(x, y,
         z * .48, z * .65);

    rect(x, y - z * .34,
         z * .65, z * .20);

    rect(x - z * .22, y - z * .45,
         z * .16, z * .20);

    rect(x, y - z * .45,
         z * .16, z * .20);

    rect(x + z * .22, y - z * .45,
         z * .16, z * .20);

    rect(x, y + z * .37,
         z * .75, z * .18);
  }

  // QUEEN
  if (type == 5) {

    ellipse(x, y - z * .30,
            z * .18, z * .18);

    ellipse(x - z * .23,
            y - z * .25,
            z * .16, z * .16);

    ellipse(x + z * .23,
            y - z * .25,
            z * .16, z * .16);

    triangle(
      x,
      y - z * .40,
      x - z * .34,
      y + z * .20,
      x + z * .34,
      y + z * .20
    );

    rect(x, y + z * .34,
         z * .75, z * .18);
  }

  // KING
  if (type == 6) {

    rect(x, y,
         z * .48, z * .60);

    rect(x, y - z * .38,
         z * .70, z * .18);

    rect(x, y - z * .15,
         z * .65, z * .18);

    // CROSS MADE FROM RECTANGLES
    rect(x, y - z * .55,
         z * .16, z * .35);

    rect(x, y - z * .55,
         z * .35, z * .14);

    rect(x, y + z * .35,
         z * .75, z * .18);
  }
}


// ============================================================
// MOVE STRUCTURE
// ============================================================

class Move {

  int fx, fy;
  int tx, ty;

  int promotion;

  Move(int a, int c, int d, int e) {

    fx = a;
    fy = c;
    tx = d;
    ty = e;

    promotion = 0;
  }
}


// ============================================================
// ENGINE
// ============================================================

Move findEngineMove(int side) {

  ArrayList<Move> moves = generateLegalMoves(side);

  if (moves.size() == 0)
    return null;

  Move best = moves.get(0);

  int bestScore = -999999999;

  // Lightweight search
  for (int i = 0; i < moves.size(); i++) {

    Move m = moves.get(i);

    int old = b[m.ty][m.tx];

    b[m.ty][m.tx] = b[m.fy][m.fx];
    b[m.fy][m.fx] = 0;

    int score =
      evaluateBoard() * side
      + (old != 0 ? 100 : 0)
      + int(random(30));

    b[m.fy][m.fx] = b[m.ty][m.tx];
    b[m.ty][m.tx] = old;

    if (score > bestScore) {

      bestScore = score;
      best = m;
    }
  }

  return best;
}


// ============================================================
// BOARD EVALUATION
// ============================================================

int evaluateBoard() {

  int score = 0;

  for (int y = 0; y < 8; y++) {

    for (int x = 0; x < 8; x++) {

      int p = b[y][x];

      if (p == 0)
        continue;

      int v = 0;

      switch(abs(p)) {

        case 1:
          v = 100;
          break;

        case 2:
          v = 320;
          break;

        case 3:
          v = 330;
          break;

        case 4:
          v = 500;
          break;

        case 5:
          v = 900;
          break;

        case 6:
          v = 20000;
          break;
      }

      score += p > 0 ? v : -v;
    }
  }

  return score;
}


// ============================================================
// GENERATE LEGAL MOVES
// ============================================================

ArrayList<Move> generateLegalMoves(int side) {

  ArrayList<Move> result = new ArrayList<Move>();

  for (int y = 0; y < 8; y++) {

    for (int x = 0; x < 8; x++) {

      int p = b[y][x];

      if (p == 0)
        continue;

      if ((p > 0 ? 1 : -1) != side)
        continue;

      generatePieceMoves(x, y, p, result);
    }
  }

  return result;
}


// ============================================================
// PIECE MOVE GENERATION
// ============================================================

void generatePieceMoves(
  int x,
  int y,
  int p,
  ArrayList<Move> list) {

  int side = p > 0 ? 1 : -1;
  int type = abs(p);

  if (type == 1)
    pawnMoves(x, y, side, list);

  if (type == 2)
    knightMoves(x, y, side, list);

  if (type == 3)
    bishopMoves(x, y, side, list);

  if (type == 4)
    rookMoves(x, y, side, list);

  if (type == 5) {
    bishopMoves(x, y, side, list);
    rookMoves(x, y, side, list);
  }

  if (type == 6)
    kingMoves(x, y, side, list);
}


// ============================================================
// PAWN
// ============================================================

void pawnMoves(
  int x, int y,
  int side,
  ArrayList<Move> list) {

  int dy = side == WHITE ? -1 : 1;

  int ny = y + dy;

  if (inside(x, ny) && b[ny][x] == 0) {

    list.add(new Move(x, y, x, ny));

    if ((side == WHITE && y == 6) ||
        (side == BLACK && y == 1)) {

      int ny2 = y + dy * 2;

      if (b[ny2][x] == 0)
        list.add(new Move(x, y, x, ny2));
    }
  }

  for (int dx = -1; dx <= 1; dx += 2) {

    int nx = x + dx;

    if (!inside(nx, ny))
      continue;

    if (b[ny][nx] != 0 &&
        b[ny][nx] * side < 0) {

      list.add(new Move(x, y, nx, ny));
    }
  }
}


// ============================================================
// KNIGHT
// ============================================================

void knightMoves(
  int x, int y,
  int side,
  ArrayList<Move> list) {

  int[] dx = {
    1, 2, 2, 1,
    -1, -2, -2, -1
  };

  int[] dy = {
    -2, -1, 1, 2,
    2, 1, -1, -2
  };

  for (int i = 0; i < 8; i++) {

    int nx = x + dx[i];
    int ny = y + dy[i];

    if (!inside(nx, ny))
      continue;

    if (b[ny][nx] == 0 ||
        b[ny][nx] * side < 0) {

      list.add(new Move(x, y, nx, ny));
    }
  }
}


// ============================================================
// BISHOP
// ============================================================

void bishopMoves(
  int x, int y,
  int side,
  ArrayList<Move> list) {

  slide(x, y, 1, 1, side, list);
  slide(x, y, 1, -1, side, list);
  slide(x, y, -1, 1, side, list);
  slide(x, y, -1, -1, side, list);
}


// ============================================================
// ROOK
// ============================================================

void rookMoves(
  int x, int y,
  int side,
  ArrayList<Move> list) {

  slide(x, y, 1, 0, side, list);
  slide(x, y, -1, 0, side, list);
  slide(x, y, 0, 1, side, list);
  slide(x, y, 0, -1, side, list);
}


// ============================================================
// SLIDING PIECES
// ============================================================

void slide(
  int x, int y,
  int dx, int dy,
  int side,
  ArrayList<Move> list) {

  int nx = x + dx;
  int ny = y + dy;

  while (inside(nx, ny)) {

    if (b[ny][nx] == 0) {

      list.add(new Move(x, y, nx, ny));

    } else {

      if (b[ny][nx] * side < 0)
        list.add(new Move(x, y, nx, ny));

      break;
    }

    nx += dx;
    ny += dy;
  }
}


// ============================================================
// KING
// ============================================================

void kingMoves(
  int x, int y,
  int side,
  ArrayList<Move> list) {

  for (int dx = -1; dx <= 1; dx++) {

    for (int dy = -1; dy <= 1; dy++) {

      if (dx == 0 && dy == 0)
        continue;

      int nx = x + dx;
      int ny = y + dy;

      if (!inside(nx, ny))
        continue;

      if (b[ny][nx] == 0 ||
          b[ny][nx] * side < 0) {

        list.add(new Move(x, y, nx, ny));
      }
    }
  }
}


// ============================================================
// MAKE MOVE
// ============================================================

void makeMove(Move m) {

  int p = b[m.fy][m.fx];

  lastFromX = m.fx;
  lastFromY = m.fy;

  lastToX = m.tx;
  lastToY = m.ty;

  b[m.ty][m.tx] = p;
  b[m.fy][m.fx] = 0;

  // PROMOTION
  if (p == WHITE && m.ty == 0)
    b[m.ty][m.tx] = WHITE * 5;

  if (p == BLACK && m.ty == 7)
    b[m.ty][m.tx] = BLACK * 5;

  turn = -turn;

  if (turn == WHITE)
    moveNumber++;
}


// ============================================================
// SCREEN INFORMATION
// ============================================================

void drawInformation() {

  fill(255);

  textAlign(CENTER, CENTER);
  textSize(displayWidth / 22);

  String s;

  if (thinking) {

    int left =
      max(0, THINK_TIME -
      int(millis() - thinkStart));

    s =
      (turn == WHITE ? "RED ENGINE" : "BLUE ENGINE")
      + " THINKING "
      + (left / 1000.0);
  }

  else if (waiting) {

    int left =
      max(0, FREE_TIME -
      int(millis() - moveWaitStart));

    s =
      "FREE TIME "
      + (left / 1000.0);
  }

  else {

    s = "CHESS";
  }

  text(
    s,
    displayWidth / 2,
    displayHeight * .96
  );
}


// ============================================================
// INSIDE BOARD
// ============================================================

boolean inside(int x, int y) {

  return x >= 0 &&
         x < 8 &&
         y >= 0 &&
         y < 8;
}
















