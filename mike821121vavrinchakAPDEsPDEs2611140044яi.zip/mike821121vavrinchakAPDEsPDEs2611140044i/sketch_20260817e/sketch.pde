

// ============================================================
// APDE 2D FIGHTING GAME
// ORIGINAL CHARACTERS
// HUMAN vs AI
// ============================================================

float playerX, playerY;
float enemyX, enemyY;

float playerVX = 0;
float playerVY = 0;

float enemyVX = 0;
float enemyVY = 0;

float playerHealth = 100;
float enemyHealth = 100;

boolean playerJump = false;
boolean enemyJump = false;

boolean playerBlock = false;
boolean enemyBlock = false;

boolean playerPunch = false;
boolean playerKick = false;

boolean enemyPunch = false;
boolean enemyKick = false;

int playerAttackTimer = 0;
int enemyAttackTimer = 0;

int playerAttackType = 0;
int enemyAttackType = 0;

int aiTimer = 0;
int aiDecision = 0;

int winner = 0;

float groundY;

int W;
int H;

// Touch buttons
boolean leftPressed = false;
boolean rightPressed = false;
boolean jumpPressed = false;
boolean punchPressed = false;
boolean kickPressed = false;
boolean blockPressed = false;

// Button rectangles
float bLeftX, bLeftY, bSize;
float bRightX, bRightY;
float bJumpX, bJumpY;
float bPunchX, bPunchY;
float bKickX, bKickY;
float bBlockX, bBlockY;


// ============================================================
// SETUP
// ============================================================

void setup() {

  orientation(LANDSCAPE);


 ///    orientation(PORTRAIT);





  size(displayWidth, displayHeight, P2D);

  W = width;
  H = height;

  groundY = H * 0.78;

  playerX = W * 0.25;
  enemyX  = W * 0.75;

  playerY = groundY;
  enemyY = groundY;

  setupButtons();

  textAlign(CENTER, CENTER);

}


// ============================================================
// BUTTONS
// ============================================================

void setupButtons() {

  bSize = H * 0.12;

  bLeftX = W * 0.08;
  bLeftY = H * 0.82;

  bRightX = W * 0.18;
  bRightY = H * 0.82;

  bJumpX = W * 0.30;
  bJumpY = H * 0.82;

  bPunchX = W * 0.70;
  bPunchY = H * 0.82;

  bKickX = W * 0.82;
  bKickY = H * 0.82;

  bBlockX = W * 0.92;
  bBlockY = H * 0.82;
}


// ============================================================
// DRAW
// ============================================================

void draw() {

  background(25, 30, 45);

  drawArena();

  if (winner == 0) {

    playerControl();

    physicsPlayer();

    aiEngine();

  ///  physicsEnemy();

    checkAttacks();

    keepPlayersInside();

  }

  drawFighter(
    playerX,
    playerY,
    true,
    playerBlock,
    playerAttackType,
    playerAttackTimer
  );

  drawFighter(
    enemyX,
    enemyY,
    false,
    enemyBlock,
    enemyAttackType,
    enemyAttackTimer
  );

  drawHealthBars();

  drawControls();

  drawStatus();

}


// ============================================================
// ARENA
// ============================================================

void drawArena() {

  // sky

  fill(70, 100, 150);
  rect(0, 0, W, groundY);

  // background buildings

  fill(45, 50, 65);

  for (int i = 0; i < 12; i++) {

    float bx = i * W / 12.0;
    float bh = 60 + (i * 37) % 180;

    rect(
      bx,
      groundY - bh,
      W / 13.0,
      bh
    );

  }

  // windows

  fill(120, 150, 180);

  for (int i = 0; i < 12; i++) {

    float bx = i * W / 12.0;

    for (int j = 0; j < 4; j++) {

      rect(
        bx + 10,
        groundY - 40 - j * 35,
        10,
        12
      );

    }

  }

  // floor

  fill(70, 65, 55);
  rect(0, groundY, W, H - groundY);

  // floor lines

  stroke(110, 100, 85);

  for (int i = 0; i < 20; i++) {

    line(
      i * W / 20.0,
      groundY,
      i * W / 20.0 + 50,
      H
    );

  }

  noStroke();

}


// ============================================================
// PLAYER CONTROL
// ============================================================

void playerControl() {

  playerBlock = blockPressed;

  if (leftPressed) {

    playerVX = -6;

  } else if (rightPressed) {

    playerVX = 6;

  } else {

    playerVX *= 0.75;

  }


  // Jump

  if (jumpPressed && playerY >= groundY - 1) {

    playerVY = -18;

  }


  // Punch

  if (punchPressed && playerAttackTimer <= 0) {

    playerAttackType = 1;
    playerAttackTimer = 18;

  }


  // Kick

  if (kickPressed && playerAttackTimer <= 0) {

    playerAttackType = 2;
    playerAttackTimer = 25;

  }

}


// ============================================================
// PLAYER PHYSICS
// ============================================================

void physicsPlayer() {

  playerX += playerVX;

  playerY += playerVY;

  playerVY += 0.8;

  if (playerY > groundY) {

    playerY = groundY;
    playerVY = 0;

  }

  if (playerAttackTimer > 0) {

    playerAttackTimer--;

  } else {

    playerAttackType = 0;

  }

}


// ============================================================
// AI ENGINE
// ============================================================

void aiEngine() {

  aiTimer--;

  float distance = abs(playerX - enemyX);

  // ----------------------------------------------------------
  // AI THINKING
  // ----------------------------------------------------------

  if (aiTimer <= 0) {

    aiTimer = int(random(8, 25));

    // AI evaluates situation

    if (enemyHealth < 20) {

      aiDecision = int(random(0, 5));

    }

    else if (playerHealth < 20) {

      aiDecision = int(random(1, 7));

    }

    else if (distance > W * 0.35) {

      aiDecision = 1;

    }

    else if (distance < W * 0.18) {

      aiDecision = int(random(2, 8));

    }

    else {

      aiDecision = int(random(0, 7));

    }

  }


  // ----------------------------------------------------------
  // AI ACTIONS
  // ----------------------------------------------------------

  enemyBlock = false;

  // move toward player

  if (aiDecision == 1) {

    if (enemyX < playerX) {

      enemyVX = 4;

    } else {

      enemyVX = -4;

    }

  }

  // move away

  else if (aiDecision == 2) {

    if (enemyX < playerX) {

      enemyVX = -4;

    } else {

      enemyVX = 4;

    }

  }

  // block

  else if (aiDecision == 3) {

    enemyVX *= 0.5;

    enemyBlock = true;

  }

  // punch

  else if (aiDecision == 4) {

    enemyVX *= 0.5;

    if (enemyAttackTimer <= 0) {

      enemyAttackType = 1;
      enemyAttackTimer = 18;

    }

  }

  // kick

  else if (aiDecision == 5) {

    enemyVX *= 0.5;

    if (enemyAttackTimer <= 0) {

      enemyAttackType = 2;
      enemyAttackTimer = 25;

    }

  }

  // jump

  else if (aiDecision == 6) {

    if (enemyY >= groundY - 1) {

      enemyVY = -18;

    }

  }

  // jump toward player

  else if (aiDecision == 7) {

    if (enemyX < playerX) {

      enemyVX = 5;

    } else {

      enemyVX = -5;

    }

    if (enemyY >= groundY - 1) {

      enemyVY = -17;

    }

  }


  enemyX += enemyVX;

  enemyY += enemyVY;

  enemyVY += 0.8;

  enemyVX *= 0.85;


  if (enemyY > groundY) {

    enemyY = groundY;
    enemyVY = 0;

  }


  if (enemyAttackTimer > 0) {

    enemyAttackTimer--;

  } else {

    enemyAttackType = 0;

  }

}


// ============================================================
// ATTACK COLLISION
// ============================================================

void checkAttacks() {

  float distance = abs(playerX - enemyX);


  // Player attack

  if (playerAttackTimer > 5 &&
      playerAttackTimer < 15 &&
      playerAttackType != 0) {

    if (distance < W * 0.16) {

      if (!enemyBlock) {

        if (playerAttackType == 1) {

          enemyHealth -= 1.5;

        } else {

          enemyHealth -= 2.5;

        }

        enemyX += (enemyX > playerX ? 12 : -12);

      }

    }

  }


  // Enemy attack

  if (enemyAttackTimer > 5 &&
      enemyAttackTimer < 15 &&
      enemyAttackType != 0) {

    if (distance < W * 0.16) {

      if (!playerBlock) {

        if (enemyAttackType == 1) {

          playerHealth -= 1.5;

        } else {

          playerHealth -= 2.5;

        }

        playerX += (playerX > enemyX ? 12 : -12);

      }

    }

  }


  playerHealth = constrain(playerHealth, 0, 100);
  enemyHealth = constrain(enemyHealth, 0, 100);


  if (playerHealth <= 0) {

    winner = 2;

  }

  if (enemyHealth <= 0) {

    winner = 1;

  }

}


// ============================================================
// KEEP PLAYERS INSIDE
// ============================================================

void keepPlayersInside() {

  playerX = constrain(playerX, 40, W - 40);
  enemyX = constrain(enemyX, 40, W - 40);

}


// ============================================================
// DRAW FIGHTER
// ============================================================

void drawFighter(
  float x,
  float y,
  boolean player,
  boolean blocking,
  int attack,
  int attackTimer
) {

  pushMatrix();

  translate(x, y);

  boolean facingRight;

  if (player) {

    facingRight = true;

  } else {

    facingRight = false;

  }


  if (!facingRight) {

    scale(-1, 1);

  }


  // Shadow

  fill(0, 0, 0, 70);
  ellipse(0, 5, 80, 20);


  // Body

  if (player) {

    fill(40, 130, 230);

  } else {

    fill(220, 70, 70);

  }

  rectMode(CENTER);

  rect(0, -70, 48, 80, 8);


  // Belt

  fill(40);

  rect(0, -45, 52, 10);


  // Head

  fill(220, 170, 130);

  ellipse(0, -125, 45, 45);


  // Hair

  fill(25);

  arc(
    0,
    -132,
    46,
    40,
    PI,
    TWO_PI
  );


  // Legs

  fill(40);

  rect(-16, -12, 15, 55);
  rect(16, -12, 15, 55);


  // Feet

  rect(-20, 15, 28, 12);
  rect(20, 15, 28, 12);


  // Arms

  if (blocking) {

    fill(220, 170, 130);

    rect(25, -75, 15, 60);
    rect(5, -78, 15, 60);

  }

  else if (attack == 1) {

    // Punch

    fill(220, 170, 130);

    rect(43, -82, 65, 15);

    ellipse(78, -82, 20, 20);

    // other arm

    rect(-25, -70, 35, 13);

  }

  else if (attack == 2) {

    // Kick

    fill(220, 170, 130);

    rect(38, -65, 45, 15);

    ellipse(70, -65, 20, 20);

    // arms

    rect(25, -80, 15, 50);
    rect(-25, -80, 15, 50);

  }

  else {

    fill(220, 170, 130);

    rect(30, -70, 35, 14);
    rect(-30, -70, 35, 14);

    ellipse(47, -70, 20, 20);
    ellipse(-47, -70, 20, 20);

  }


  popMatrix();

  rectMode(CORNER);

}


// ============================================================
// HEALTH BARS
// ============================================================

void drawHealthBars() {

  float barW = W * 0.35;
  float barH = 25;

  // Player background

  fill(30);

  rect(
    W * 0.05,
    30,
    barW,
    barH
  );

  fill(30, 180, 255);

  rect(
    W * 0.05,
    30,
    barW * playerHealth / 100.0,
    barH
  );


  // Enemy background

  fill(30);

  rect(
    W * 0.60,
    30,
    barW,
    barH
  );

  fill(255, 70, 70);

  rect(
    W * 0.60,
    30,
    barW * enemyHealth / 100.0,
    barH
  );


  fill(255);

  textSize(18);

  text(
    "PLAYER",
    W * 0.05 + barW / 2,
    70
  );

  text(
    "AI",
    W * 0.60 + barW / 2,
    70
  );

}


// ============================================================
// TOUCH CONTROLS
// ============================================================

void drawControls() {

  drawButton(bLeftX, bLeftY, "LEFT");
  drawButton(bRightX, bRightY, "RIGHT");

  drawButton(bJumpX, bJumpY, "JUMP");

  drawButton(bPunchX, bPunchY, "PUNCH");
  drawButton(bKickX, bKickY, "KICK");

  drawButton(bBlockX, bBlockY, "BLOCK");

}


// ============================================================
// DRAW BUTTON
// ============================================================

void drawButton(float x, float y, String label) {

  fill(0, 0, 0, 110);

  ellipse(
    x,
    y,
    bSize,
    bSize
  );

  fill(255);

  textSize(bSize * 0.18);

  text(
    label,
    x,
    y
  );

}


// ============================================================
// STATUS
// ============================================================

void drawStatus() {

  fill(255);

  textSize(18);

  if (winner == 1) {

    text(
      "PLAYER WINS!",
      W / 2,
      H * 0.15
    );

  }

  else if (winner == 2) {

    text(
      "AI WINS!",
      W / 2,
      H * 0.15
    );

  }

}


// ============================================================
// TOUCH START
// ============================================================

void touchStarted() {

  ///checkTouch(touchX, touchY, true);

}


// ============================================================
// TOUCH MOVE
// ============================================================

void touchMoved() {

  ////checkTouch(touchX, touchY, true);

}


// ============================================================
// TOUCH END
// ============================================================

void touchEnded() {

  leftPressed = false;
  rightPressed = false;
  jumpPressed = false;
  punchPressed = false;
  kickPressed = false;
  blockPressed = false;

}


// ============================================================
// TOUCH CHECK
// ============================================================

void checkTouch(float tx, float ty, boolean state) {

  if (insideButton(tx, ty, bLeftX, bLeftY)) {

    leftPressed = state;

  }

  if (insideButton(tx, ty, bRightX, bRightY)) {

    rightPressed = state;

  }

  if (insideButton(tx, ty, bJumpX, bJumpY)) {

    jumpPressed = state;

  }

  if (insideButton(tx, ty, bPunchX, bPunchY)) {

    punchPressed = state;

  }

  if (insideButton(tx, ty, bKickX, bKickY)) {

    kickPressed = state;

  }

  if (insideButton(tx, ty, bBlockX, bBlockY)) {

    blockPressed = state;

  }

}


// ============================================================
// BUTTON COLLISION
// ============================================================

boolean insideButton(
  float tx,
  float ty,
  float bx,
  float by
) {

  return dist(tx, ty, bx, by) < bSize * 0.55;

}


// ============================================================
// RESTART
// ============================================================

void mousePressed() {

  // Useful for APDE testing

  if (winner != 0) {

    playerHealth = 100;
    enemyHealth = 100;

    playerX = W * 0.25;
    enemyX = W * 0.75;

    playerY = groundY;
    enemyY = groundY;

    playerVY = 0;
    enemyVY = 0;

    winner = 0;

  }

}





























