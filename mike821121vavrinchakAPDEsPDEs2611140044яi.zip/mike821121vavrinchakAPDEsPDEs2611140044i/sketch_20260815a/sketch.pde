


// APDE - NOTIFICATION 9 KEYS
// Android 9
// Real Android status bar stays visible

import android.view.Window;
import android.view.WindowManager;
import android.graphics.Color;

String[] keyName = {
  "KEY 1", "KEY 2", "KEY 3",
  "KEY 4", "KEY 5", "KEY 6",
  "KEY 7", "KEY 8", "KEY 9"
};

boolean[] keyDown = new boolean[9];

void setup() {

  size(displayWidth, displayHeight, P2D);

  orientation(PORTRAIT);



/*

  // KEEP ANDROID STATUS BAR
  Window window = getActivity().getWindow();

  window.clearFlags(
    WindowManager.LayoutParams.FLAG_FULLSCREEN
  );

  // STATUS BAR COLOR
  window.setStatusBarColor(
    Color.rgb(0, 0, 0)
  );



*/



  textAlign(CENTER, CENTER);

  noStroke();
}

void draw() {

  background(25);

  // Because Android status bar is NOT fullscreen,
  // this drawing starts below the system status bar.

  fill(255);
  textSize(30);

  text(
    "NOTIFICATION",
    width / 2,
    height * 0.08
  );

  float marginX = width * 0.05;
  float top = height * 0.16;

  float gapX = width * 0.025;
  float gapY = height * 0.025;

  float keyW =
    (width - marginX * 2 - gapX * 2) / 3.0;

  float keyH =
    height * 0.18;

  for (int i = 0; i < 9; i++) {

    int col = i % 3;
    int row = i / 3;

    float x =
      marginX + col * (keyW + gapX);

    float y =
      top + row * (keyH + gapY);

    if (keyDown[i]) {
      fill(0, 220, 80);
    } else {
      fill(65, 65, 75);
    }

    rect(
      x,
      y,
      keyW,
      keyH,
      20
    );

    fill(255);
    textSize(24);

    text(
      keyName[i],
      x + keyW / 2,
      y + keyH / 2
    );
  }
}

void mousePressed() {

  float marginX = width * 0.05;
  float top = height * 0.16;

  float gapX = width * 0.025;
  float gapY = height * 0.025;

  float keyW =
    (width - marginX * 2 - gapX * 2) / 3.0;

  float keyH =
    height * 0.18;

  for (int i = 0; i < 9; i++) {

    int col = i % 3;
    int row = i / 3;

    float x =
      marginX + col * (keyW + gapX);

    float y =
      top + row * (keyH + gapY);

    if (mouseX >= x &&
        mouseX <= x + keyW &&
        mouseY >= y &&
        mouseY <= y + keyH) {

      keyDown[i] = true;

      println(
        "NOTIFICATION KEY: " + (i + 1)
      );
    }
  }
}

void mouseReleased() {

  for (int i = 0; i < 9; i++) {
    keyDown[i] = false;
  }
}





















