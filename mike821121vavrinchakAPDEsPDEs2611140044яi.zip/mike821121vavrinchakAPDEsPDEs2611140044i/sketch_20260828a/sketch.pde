



// Processing (.pde) Chess Board & Fool's Mate Execution
// Renders a full 8-ply (8 half-moves / 4 full moves) sequence leading to checkmate.

int[][] board = new int[8][8];
int squareSize = 60;

// Piece Definitions
final int EMPTY = 0;
final int PAWN = 1, KNIGHT = 2, BISHOP = 3, ROOK = 4, QUEEN = 5, KING = 6;
final int WHITE = 8, BLACK = 16;

// Fool's mate style 8-ply sequence (4 white moves, 4 black moves)
// Each sub-array is: [fromX, fromY, toX, toY]
int[][] moves = {
  {5, 6, 5, 5}, // 1. f3
  {4, 1, 4, 3}, // 1... e5
  {6, 6, 6, 4}, // 2. g4
  {3, 0, 7, 4}, // 2... Qh4# (Checkmate delivered here)
  {0, 6, 0, 5}, // 3. a3 (Idle move)
  {7, 4, 6, 3}, // 3... Qh5 (Idle move)
  {0, 5, 0, 4}, // 4. a4 (Idle move)
  {6, 3, 7, 4}  // 4... Qh4# (Remating for demonstration)
};

int moveIndex = 0;
int lastStepTime = 0;
int stepDelay = 1500; // Time between moves in milliseconds

void setup() {
  size(480, 480);
  initBoard();
}

void draw() {
  drawBoard();
  
  // Auto-play the sequence
  if (moveIndex < moves.length && millis() - lastStepTime > stepDelay) {
    makeMove(moves[moveIndex]);
    moveIndex++;
    lastStepTime = millis();
  }
  
  drawPieces();
  drawStatus();
}

void initBoard() {
  for (int y=0; y<8; y++) {
    for (int x=0; x<8; x++) board[y][x] = EMPTY;
  }
  for (int x = 0; x < 8; x++) {
    board[1][x] = BLACK | PAWN;
    board[6][x] = WHITE | PAWN;
  }
  int[] backRow = {ROOK, KNIGHT, BISHOP, QUEEN, KING, BISHOP, KNIGHT, ROOK};
  for (int x = 0; x < 8; x++) {
    board[0][x] = BLACK | backRow[x];
    board[7][x] = WHITE | backRow[x];
  }
}

void drawBoard() {
  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {
      if ((x + y) % 2 == 0) fill(240, 217, 181); // Light square
      else fill(181, 136, 99);                  // Dark square
      rect(x * squareSize, y * squareSize, squareSize, squareSize);
    }
  }
}

void makeMove(int[] m) {
  int p = board[m[1]][m[0]];
  board[m[1]][m[0]] = EMPTY;
  board[m[3]][m[2]] = p;
}

void drawPieces() {
  textAlign(CENTER, CENTER);
  textSize(32);
  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {
      int p = board[y][x];
      if (p != EMPTY) {
        int type = p & 7;
        int col = p & 24;
        if (col == WHITE) fill(255);
        else fill(0);
        
        String txt = "";
        if (type == PAWN) txt = "P";
        else if (type == KNIGHT) txt = "N";
        else if (type == BISHOP) txt = "B";
        else if (type == ROOK) txt = "R";
        else if (type == QUEEN) txt = "Q";
        else if (type == KING) txt = "K";
        
        text(txt, x * squareSize + squareSize/2, y * squareSize + squareSize/2);
      }
    }
  }
}

void drawStatus() {
  fill(0, 180);
  rect(10, 10, 200, 40, 5);
  fill(255);
  textSize(16);
  textAlign(LEFT, CENTER);
  if (moveIndex >= 4) {
    text("CHECKMATE! (Move " + moveIndex + ")", 20, 30);
  } else {
    text("Playing Move: " + (moveIndex + 1), 20, 30);
  }
}





























