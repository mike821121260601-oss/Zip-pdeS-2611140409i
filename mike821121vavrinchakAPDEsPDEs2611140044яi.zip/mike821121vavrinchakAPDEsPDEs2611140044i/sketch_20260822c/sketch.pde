


// APDE – 2 Random Polygons (≤100 sides) + Moving Circle
// Polygons rotate randomly 0.1° – 0.2° per frame
// No collisions (screen or polygons)

float playerX, playerY;
float playerR = 22;
float angle = 0;
float speed = 4.5;

// Two polygons
PShape poly1, poly2;
float rot1 = 0, rot2 = 0;
float rotSpeed1, rotSpeed2;
float poly1X, poly1Y, poly2X, poly2Y;
float polySize;               // actual size used for both

void setup() {
  size(displayWidth, displayHeight);
  // size(900, 1600);   // optional fixed size for testing

  // Size rule: between 20% and 25% of the smaller screen side
  float minSide = min(width, height);
  polySize = random(minSide * 0.20, minSide * 0.25);

  // Create two random polygons (3–100 sides)
  poly1 = createRandomPolygon(int(random(3, 101)), polySize);
  poly2 = createRandomPolygon(int(random(3, 101)), polySize);

  // Random rotation speeds (0.1° – 0.2° per frame)
  rotSpeed1 = random(0.1, 0.2) * (random(1) > 0.5 ? 1 : -1);
  rotSpeed2 = random(0.1, 0.2) * (random(1) > 0.5 ? 1 : -1);

  // Place polygons
  poly1X = width * 0.30;
  poly1Y = height * 0.40;
  poly2X = width * 0.70;
  poly2Y = height * 0.60;

  // Start circle in open space
  playerX = width / 2;
  playerY = height * 0.15;
}

void draw() {
  background(12);

  // ---- Update polygon rotations ----
  rot1 += rotSpeed1;
  rot2 += rotSpeed2;

  // ---- Draw polygons ----
  pushMatrix();
  translate(poly1X, poly1Y);
  rotate(radians(rot1));
  shape(poly1, 0, 0);
  popMatrix();

  pushMatrix();
  translate(poly2X, poly2Y);
  rotate(radians(rot2));
  shape(poly2, 0, 0);
  popMatrix();

  // ---- Move circle (no collision) ----
  playerX += cos(angle) * speed;
  playerY += sin(angle) * speed;

  // Soft wrap around screen edges (no hard collision)
  if (playerX < -playerR) playerX = width + playerR;
  if (playerX > width + playerR) playerX = -playerR;
  if (playerY < -playerR) playerY = height + playerR;
  if (playerY > height + playerR) playerY = -playerR;

  // ---- Draw circle ----
  fill(255, 70, 70);
  noStroke();
  ellipse(playerX, playerY, playerR * 2, playerR * 2);

  // Direction line
  stroke(255);
  strokeWeight(2);
  line(playerX, playerY,
       playerX + cos(angle) * playerR * 1.7,
       playerY + sin(angle) * playerR * 1.7);
}

// Create a random polygon with n sides, roughly fitting inside a square of side "size"
PShape createRandomPolygon(int sides, float size) {
  PShape s = createShape();
  s.beginShape();
  s.noFill();
  s.stroke(160, 220, 255);
  s.strokeWeight(2.5);

  float radius = size * 0.48;   // keep it inside the target square

  for (int i = 0; i < sides; i++) {
    float a = TWO_PI * i / sides + random(-0.25, 0.25); // slight irregularity
    float r = radius * random(0.75, 1.05);
    float x = cos(a) * r;
    float y = sin(a) * r;
    s.vertex(x, y);
  }
  s.endShape(CLOSE);
  return s;
}

// ---- Controls ----
void keyPressed() {
  if (keyCode == LEFT)  angle -= 0.18;
  if (keyCode == RIGHT) angle += 0.18;
}

void mouseDragged() {
  angle += (mouseX - pmouseX) * 0.014;
}

void mousePressed() {
  if (mouseX < width / 2) angle -= 0.28;
  else                    angle += 0.28;
}























