


// ============================================================
// APDE 2D TANK BATTLE
// Player vs Computer
// Touch controls
// ============================================================

float px, py;
float pAngle = 0;
float pTurret = 0;
int playerHP = 100;

float ex, ey;
float eAngle = 0;
float eTurret = 0;
int enemyHP = 100;

ArrayList<Bullet> bullets = new ArrayList<Bullet>();
ArrayList<Explosion> explosions = new ArrayList<Explosion>();

ArrayList<Wall> walls = new ArrayList<Wall>();

boolean gameOver = false;
boolean playerWin = false;

int score = 0;

float tankSize = 42;
float moveSpeed = 3.0;

boolean leftTouch = false;
boolean rightTouch = false;
boolean upTouch = false;
boolean downTouch = false;
boolean fireTouch = false;

long lastPlayerShot = 0;
long lastEnemyShot = 0;

void setup() {
  fullScreen(P2D);





  orientation(LANDSCAPE);


    ////      orientation(PORTRAIT);








  rectMode(CENTER);
  ellipseMode(CENTER);

  px = width * 0.18;
  py = height * 0.50;

  ex = width * 0.82;
  ey = height * 0.50;

  makeWalls();
}

void draw() {

  background(35, 90, 35);

  if (!gameOver) {
    updatePlayer();
    updateEnemy();
    updateBullets();
    updateExplosions();
  }

  drawBattlefield();
  drawTank(px, py, pAngle, pTurret, 0);
  drawTank(ex, ey, eAngle, eTurret, 1);

  drawBullets();
  drawExplosions();

  drawControls();
  drawHUD();

  if (gameOver) {
    drawGameOver();
  }
}


// ============================================================
// BATTLEFIELD
// ============================================================

void drawBattlefield() {

  // grass grid
  stroke(45, 110, 45);

  for (int x = 0; x < width; x += 40) {
    line(x, 0, x, height);
  }

  for (int y = 0; y < height; y += 40) {
    line(0, y, width, y);
  }

  noStroke();

  // walls
  for (Wall w : walls) {
    w.draw();
  }
}


// ============================================================
// TANK
// ============================================================

void drawTank(float x, float y,
              float bodyAngle,
              float turretAngle,
              int team) {

  pushMatrix();
  translate(x, y);

  // tank tracks
  rotate(bodyAngle);

  if (team == 0) {
    fill(30, 150, 40);
  } else {
    fill(180, 40, 40);
  }

  rect(0, -16, 52, 12);
  rect(0, 16, 52, 12);

  // body
  if (team == 0) {
    fill(40, 190, 50);
  } else {
    fill(220, 50, 50);
  }

  rect(0, 0, 44, 32);

  popMatrix();


  // turret
  pushMatrix();
  translate(x, y);
  rotate(turretAngle);

  if (team == 0) {
    fill(50, 210, 60);
  } else {
    fill(240, 60, 60);
  }

  ellipse(0, 0, 28, 28);

  rect(18, 0, 40, 9);

  popMatrix();
}


// ============================================================
// PLAYER
// ============================================================

void updatePlayer() {

  if (leftTouch) {
    pAngle -= 0.055;
  }

  if (rightTouch) {
    pAngle += 0.055;
  }

  if (upTouch) {
    px += cos(pAngle) * moveSpeed;
    py += sin(pAngle) * moveSpeed;
  }

  if (downTouch) {
    px -= cos(pAngle) * moveSpeed;
    py -= sin(pAngle) * moveSpeed;
  }

  keepTankInside(true);

  if (fireTouch) {
    playerShoot();
  }

  // turret follows tank direction
  pTurret = pAngle;
}


void playerShoot() {

  if (millis() - lastPlayerShot < 350) {
    return;
  }

  lastPlayerShot = millis();

  float bx = px + cos(pTurret) * 35;
  float by = py + sin(pTurret) * 35;

  bullets.add(
    new Bullet(
      bx,
      by,
      pTurret,
      true
    )
  );
}


// ============================================================
// ENEMY AI
// ============================================================

void updateEnemy() {

  float dx = px - ex;
  float dy = py - ey;

  float targetAngle = atan2(dy, dx);

  // rotate toward player
  float difference =
    angleDifference(targetAngle, eAngle);

  if (difference > 0) {
    eAngle += 0.018;
  } else {
    eAngle -= 0.018;
  }

  eTurret = targetAngle;

  float distance = dist(px, py, ex, ey);

  // move toward player
  if (distance > 300) {

    ex += cos(eAngle) * 1.2;
    ey += sin(eAngle) * 1.2;
  }

  // move away if too close
  if (distance < 180) {

    ex -= cos(eAngle) * 1.2;
    ey -= sin(eAngle) * 1.2;
  }

  keepTankInside(false);

  // enemy shoots
  if (distance < 700) {

    if (millis() - lastEnemyShot > 850) {

      lastEnemyShot = millis();

      float bx =
        ex + cos(eTurret) * 35;

      float by =
        ey + sin(eTurret) * 35;

      bullets.add(
        new Bullet(
          bx,
          by,
          eTurret,
          false
        )
      );
    }
  }
}


// ============================================================
// ANGLE
// ============================================================

float angleDifference(float a, float b) {

  float d = a - b;

  while (d > PI) {
    d -= TWO_PI;
  }

  while (d < -PI) {
    d += TWO_PI;
  }

  return d;
}


// ============================================================
// KEEP TANK ON SCREEN
// ============================================================

void keepTankInside(boolean player) {

  float x;
  float y;

  if (player) {
    x = px;
    y = py;
  } else {
    x = ex;
    y = ey;
  }

  x = constrain(x, 30, width - 30);
  y = constrain(y, 30, height - 30);

  if (player) {
    px = x;
    py = y;
  } else {
    ex = x;
    ey = y;
  }
}


// ============================================================
// BULLETS
// ============================================================

class Bullet {

  float x;
  float y;
  float a;

  boolean fromPlayer;

  float speed = 9;

  Bullet(float xx, float yy,
         float aa, boolean pp) {

    x = xx;
    y = yy;
    a = aa;
    fromPlayer = pp;
  }

  void update() {

    x += cos(a) * speed;
    y += sin(a) * speed;
  }

  void draw() {

    if (fromPlayer) {
      fill(255, 240, 50);
    } else {
      fill(255, 120, 30);
    }

    ellipse(x, y, 9, 9);
  }
}


void updateBullets() {

  for (int i = bullets.size() - 1; i >= 0; i--) {

    Bullet b = bullets.get(i);

    b.update();

    boolean remove = false;

    // screen boundary
    if (b.x < 0 ||
        b.x > width ||
        b.y < 0 ||
        b.y > height) {

      remove = true;
    }

    // wall collision
    for (Wall w : walls) {

      if (w.hit(b.x, b.y)) {

        explosions.add(
          new Explosion(b.x, b.y)
        );

        remove = true;
        break;
      }
    }

    // player hit
    if (!remove && !b.fromPlayer) {

      if (dist(b.x, b.y, px, py) < 25) {

        playerHP -= 10;

        explosions.add(
          new Explosion(px, py)
        );

        remove = true;

        if (playerHP <= 0) {

          playerHP = 0;

          gameOver = true;
          playerWin = false;
        }
      }
    }

    // enemy hit
    if (!remove && b.fromPlayer) {

      if (dist(b.x, b.y, ex, ey) < 25) {

        enemyHP -= 10;

        explosions.add(
          new Explosion(ex, ey)
        );

        remove = true;

        if (enemyHP <= 0) {

          enemyHP = 0;

          score += 100;

          gameOver = true;
          playerWin = true;
        }
      }
    }

    if (remove) {
      bullets.remove(i);
    }
  }
}


void drawBullets() {

  for (Bullet b : bullets) {
    b.draw();
  }
}


// ============================================================
// EXPLOSIONS
// ============================================================

class Explosion {

  float x;
  float y;

  float r = 5;
  int life = 30;

  Explosion(float xx, float yy) {

    x = xx;
    y = yy;
  }

  void update() {

    r += 3;
    life--;
  }

  void draw() {

    noFill();
    stroke(255, 180, 30);
    strokeWeight(4);

    ellipse(x, y, r, r);

    noStroke();
  }
}


void updateExplosions() {

  for (int i = explosions.size() - 1;
       i >= 0;
       i--) {

    Explosion e = explosions.get(i);

    e.update();

    if (e.life <= 0) {
      explosions.remove(i);
    }
  }
}


void drawExplosions() {

  for (Explosion e : explosions) {
    e.draw();
  }
}


// ============================================================
// WALLS
// ============================================================

class Wall {

  float x;
  float y;
  float w;
  float h;

  Wall(float xx, float yy,
       float ww, float hh) {

    x = xx;
    y = yy;
    w = ww;
    h = hh;
  }

  void draw() {

    fill(100, 80, 55);
    rect(x, y, w, h);

    fill(130, 105, 70);
    rect(x, y - 4, w - 8, h - 8);
  }

  boolean hit(float px, float py) {

    return
      px > x - w / 2 &&
      px < x + w / 2 &&
      py > y - h / 2 &&
      py < y + h / 2;
  }
}


void makeWalls() {

  walls.clear();

  walls.add(
    new Wall(
      width * 0.50,
      height * 0.25,
      width * 0.20,
      30
    )
  );

  walls.add(
    new Wall(
      width * 0.50,
      height * 0.75,
      width * 0.20,
      30
    )
  );

  walls.add(
    new Wall(
      width * 0.50,
      height * 0.50,
      30,
      height * 0.25
    )
  );

  walls.add(
    new Wall(
      width * 0.25,
      height * 0.50,
      100,
      30
    )
  );

  walls.add(
    new Wall(
      width * 0.75,
      height * 0.50,
      100,
      30
    )
  );
}


// ============================================================
// TOUCH CONTROLS
// ============================================================

void drawControls() {

  noStroke();

  // LEFT
  fill(0, 0, 0, 110);
  ellipse(80, height - 90, 100, 100);

  // RIGHT
  ellipse(200, height - 90, 100, 100);

  // UP
  ellipse(140, height - 150, 100, 100);

  // DOWN
  ellipse(140, height - 30, 80, 60);

  // FIRE
  fill(180, 30, 30, 180);
  ellipse(width - 100, height - 100, 130, 130);

  fill(255);

  textAlign(CENTER, CENTER);
  textSize(28);

  text("←", 80, height - 90);
  text("→", 200, height - 90);
  text("↑", 140, height - 150);
  text("↓", 140, height - 30);

  textSize(24);
  text("FIRE", width - 100, height - 100);
}


// ============================================================
// TOUCH
// ============================================================

void touchStarted() {

  updateTouch(mouseX, mouseY, true);
}


void touchMoved() {

  updateTouch(mouseX, mouseY, true);
}


void touchEnded() {

  leftTouch = false;
  rightTouch = false;
  upTouch = false;
  downTouch = false;
  fireTouch = false;
}


void updateTouch(float x, float y, boolean down) {

  leftTouch = false;
  rightTouch = false;
  upTouch = false;
  downTouch = false;
  fireTouch = false;

  if (gameOver) {

    if (x > width * 0.35 &&
        x < width * 0.65 &&
        y > height * 0.55 &&
        y < height * 0.80) {

      restartGame();
    }

    return;
  }

  if (x < 140 &&
      y > height - 150) {

    leftTouch = true;
  }

  if (x >= 140 &&
      x < 270 &&
      y > height - 150) {

    rightTouch = true;
  }

  if (x >= 80 &&
      x < 200 &&
      y > height - 210 &&
      y < height - 90) {

    upTouch = true;
  }

  if (x >= 100 &&
      x < 180 &&
      y > height - 70) {

    downTouch = true;
  }

  if (x > width - 190 &&
      y > height - 190) {

    fireTouch = true;
  }
}


// ============================================================
// HUD
// ============================================================

void drawHUD() {

  textAlign(LEFT, TOP);
  textSize(24);

  fill(255);
  text("PLAYER", 20, 15);

  // player health
  fill(50);
  rect(130, 28, 150, 18);

  fill(40, 220, 50);
  rect(
    130 - (150 - playerHP * 1.5) / 2,
    28,
    playerHP * 1.5,
    18
  );

  text("ENEMY", width - 190, 15);

  fill(50);
  rect(width - 90, 28, 150, 18);

  fill(220, 40, 40);

  rect(
    width - 90 -
    (150 - enemyHP * 1.5) / 2,
    28,
    enemyHP * 1.5,
    18
  );

  fill(255);
  text("SCORE " + score, width / 2 - 70, 15);
}


// ============================================================
// GAME OVER
// ============================================================

void drawGameOver() {

  fill(0, 0, 0, 190);
  rect(width / 2, height / 2,
       width, height);

  fill(255);
  textAlign(CENTER, CENTER);

  textSize(55);

  if (playerWin) {
    text("YOU WIN!", width / 2, height / 2 - 70);
  } else {
    text("YOU LOSE!", width / 2, height / 2 - 70);
  }

  textSize(28);
  text("SCORE: " + score,
       width / 2,
       height / 2);

  fill(50, 180, 70);
  rect(width / 2,
       height / 2 + 90,
       220,
       70);

  fill(255);
  text("RESTART",
       width / 2,
       height / 2 + 90);
}


// ============================================================
// RESTART
// ============================================================

void restartGame() {

  px = width * 0.18;
  py = height * 0.50;

  ex = width * 0.82;
  ey = height * 0.50;

  pAngle = 0;
  eAngle = PI;

  playerHP = 100;
  enemyHP = 100;

  bullets.clear();
  explosions.clear();

  score = 0;

  gameOver = false;
  playerWin = false;
}


























