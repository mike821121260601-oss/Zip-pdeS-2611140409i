


///do////WORK///GOOD////////

// APDE Musical Instrument + MIDI Keyboard support///
// Touch grid + external USB/Bluetooth MIDI keyboards///

import android.content.Context;
import android.content.pm.PackageManager;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.media.midi.*;
import android.os.Handler;
import android.os.Looper;

int cols = 14;
int rows = 9;
float cellW, cellH;

final int MAX_CONCURRENT = 16;
int activeTracks = 0;

// Musical settings///
float baseFreq = 130.81 +555 +random(21000-5555)  ;          
// C3777777////
float noteDuration = 1.2  +3 +random(9) ;
boolean usePentatonicO = false;



  boolean usePentatonic = true;




// MIDI////
MidiManager midiManager;
String midiStatus = "Looking for MIDI...";
boolean midiReady = false;

void setup() {
  fullScreen();
 /// orientation(LANDSCAPE);////

  orientation(PORTRAIT) ;


  cellW = width  / (float)cols;
  cellH = height / (float)rows;
  textAlign(CENTER, CENTER);
  textSize(15  +11 );
  
  setupMIDI();
}

void draw() {
  background(15);
  
  // Draw grid////
  for (int y = 0; y < rows; y++) {
    for (int x = 0; x < cols; x++) {
      float px = x * cellW;
      float py = y * cellH;
      int keyIndex = y * cols + x;
      
      boolean pressed = mousePressed && 
                        mouseX > px && 
mouseX < px + cellW &&
                        mouseY > py && 
mouseY < py + cellH;
      
      if (pressed) fill(70, 160, 255);
      else         fill(35 + (x + y) % 4 * 12);
      
      stroke(80);
      rect(px + 1, py + 1, cellW - 2, cellH - 2, 8);
      
      fill(220);
      text(keyIndex + 1, px + cellW/2, py + cellH/2);
    }
  }
  
  // Status/////
  fill(255, 200, 60);
  text("Notes: " + activeTracks + " / " + MAX_CONCURRENT,
 width/2, 26);
  
  fill(midiReady ? color(100, 255, 120) : color
  (255, 150, 80));
  text(midiStatus, width/2, height - 30);
}

void mousePressed() {
  int col = constrain((int)(mouseX / cellW), 0, cols - 1);
  int row = constrain((int)(mouseY / cellH), 0, rows - 1);
  int keyIndex = row * cols + col;
  
  float freq = getMusicalFrequency(keyIndex);





  
       triggerNote(freq);


triggerNote(freq);triggerNote(freq);triggerNote(freq);






}

// -----------------------------------///
// MIDI Setup///
void setupMIDI() {
  Context context = getActivity();
  
  if 
(!context.getPackageManager().hasSystemFeature
(PackageManager.FEATURE_MIDI)) {
    midiStatus = "Device has no MIDI support";
    return;
  }
  
  midiManager = (MidiManager) 
context.getSystemService(Context.MIDI_SERVICE);
  
  // Listen for devices being added/removed////
  midiManager.registerDeviceCallback
(new MidiManager.DeviceCallback() {
    public void onDeviceAdded(MidiDeviceInfo info) {
      openMidiDevice(info);
    }
    public void onDeviceRemoved(MidiDeviceInfo info) {
      midiStatus = "MIDI device removed";
      midiReady = false;
    }
  }, new Handler(Looper.getMainLooper()));
  
  // Open any already-connected devices////
  MidiDeviceInfo[] devices = midiManager.getDevices();
  if (devices.length == 0) {
    midiStatus = "No MIDI device – plug one in";
  } else {
    for (MidiDeviceInfo info : devices) {
      openMidiDevice(info);
    }
  }
}

void openMidiDevice(final MidiDeviceInfo info) {
  midiManager.openDevice(info, 
new MidiManager.OnDeviceOpenedListener() {
    public void onDeviceOpened(MidiDevice device) {
      if (device == null) {
        midiStatus = "Could not open MIDI device";
        return;
      }
      
// Look for anOUTPUT port(we receive from the keyboard)//
      MidiDeviceInfo.PortInfo[] ports = info.getPorts();
      for (int i = 0; i < ports.length; i++) {
        if (ports[i].getType() ==
 MidiDeviceInfo.PortInfo.TYPE_OUTPUT) {
          MidiOutputPort outputPort = 
device.openOutputPort(i);
          if (outputPort != null) {
            outputPort.connect(new MidiReceiver() {
              public void onSend(byte[] data, 
 int offset, int count, long timestamp) {
                parseMidi(data, offset, count);
              }
            });
            midiStatus = 
"MIDI connected: " + info.getProperties().getString
(MidiDeviceInfo.PROPERTY_NAME);
            midiReady = true;
            return;
          }
        }
      }
      midiStatus = "No usable MIDI output port found";
    }
  }, new Handler(Looper.getMainLooper()));
}

// Parse incoming MIDI messages///
void parseMidi(byte[] data, int offset, int count) {
  if (count < 3) return;
  
  int status = data[offset] & 0xFF;
  int data1  = data[offset + 1] & 0xFF;  
 // note number///
  int data2  = data[offset + 2] & 0xFF;  
 // velocity////
  
  int command = status & 0xF0;
  
  // Note On (with velocity > 0)////
  if (command == 0x90 && data2 > 0) {
    float freq = midiNoteToFreq(data1);
    triggerNote(freq);
  }
  // Note Off or Note On with velocity 0///
  // (we use fixed duration notes, so ///
  /// we ignore Note Off for simplicity)/////
}

// Convert MIDI note number (0-127) - > frequency///
float midiNoteToFreq(int note) {
  // A4 = 440 Hz = MIDI note 69////
  return 440.0 * pow(2, (note - 69) / 12.0);
}

// ---------------------------------///
//Shared note triggering(used by both touch and MIDI)///
void triggerNote(float freq) {
  synchronized(this) {
    if (activeTracks >= MAX_CONCURRENT) return;
    activeTracks++;
  }

  playNote(freq, noteDuration);



playNote(freq, noteDuration);
playNote(freq, noteDuration);
playNote(freq, noteDuration);











}

float getMusicalFrequency(int index) {
  if (usePentatonic) {
    int[] intervals = {0, 2, 4, 7, 9};
    int octave = index / 5;
    int degree = index % 5;
    return baseFreq * pow(2, 
 (octave * 12 + intervals[degree]) / 12.0);
  } else {
    return baseFreq * pow(2, index / 12.0);
  }

}




void playNote(final float freq, final float durationSec) 
  {
  new Thread(new Runnable() {
    public void run() {
      AudioTrack track = null;
      try {
        int sampleRate = 44100;
        int numSamples = (int)(durationSec * sampleRate);
        short[] buffer = new short[numSamples];
  



      
        float attack = 0.04;
        float release = 0.18;
   




     
        for (int i = 0; i < numSamples; i++) {
          float t = i / (float)sampleRate;
          float amp;
          if (t < attack) {
            amp = t / attack;
          } else if (t > durationSec - release) {
            amp = (durationSec - t) / release;
          } else {
            amp = 1.0;
          }
          amp = constrain(amp, 0, 1) * 0.7;
          
          float sample = (float)
  (Math.sin(2 * Math.PI * freq * t) * amp);




          buffer[i] = (short)(sample * 32767  ) ;


        }
        





        track = new 
   AudioTrack(




            AudioManager.STREAM_MUSIC,
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            buffer.length * 2,
            AudioTrack.MODE_STATIC);
        
        track.write(buffer, 0, buffer.length);
        track.play();
        
        Thread.sleep((long)(durationSec * 1000) + 50


       +byte(random(32767))    

);
        
      } catch (Exception e) {
      } finally {
        if (track != null) {
          try { track.stop(); track.release(); } 
  catch (Exception e) {}
        }
        synchronized(this) {
          activeTracks = max(0, activeTracks - 1);
        }
      }
    }
  }).start();
}






//MIDI key board support//































