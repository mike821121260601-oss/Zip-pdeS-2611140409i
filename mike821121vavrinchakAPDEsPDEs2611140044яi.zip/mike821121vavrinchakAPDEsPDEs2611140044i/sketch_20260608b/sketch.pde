









byte tetris=0;int t=0;

int [] [] [] m=new int [55] [55] [999] ;







void setup() {
size(displayWidth, displayHeight, P2D) ;
orientation(PORTRAIT) ;  } 
void draw() {noStroke();
rectMode(CENTER);ellipseMode(CENTER);













if( (mouseX != pmouseX) 
||(mouseY != pmouseY) ) 
{t=2;

fill(int(random(255)),
int(random(255)),
int(random(255))) ;
ellipse(mouseX, mouseY, 22,22) ;



for(int f=1;f<=3;f++){
for(int ff=1;ff<=3;ff++){


if(m[f] [ff] [0] ==1){
fill(222,11,222);
ellipse(mouseX-(f*displayWidth /55),
mouseY-(ff*displayHeight /55),
displayWidth /155,displayHeight /155);
}

if(m[f] [ff] [0] ==0){
fill(22,222,222);
ellipse(mouseX-(f*displayWidth /55),
mouseY-(ff*displayHeight /55),
displayWidth /155,displayHeight /155);
}




} } 



}









if(t==0){t=1; 














float rndm=random(99);
if((rndm>-1)&&(rndm<6)){
m[1][1][0]=1;
m[2][2][0]=1;
m[3][3][0]=1;
m[2][1][0]=0;
m[3][1][0]=0;
m[1][2][0]=0;
m[1][3][0]=0;
m[3][2][0]=0;
m[2][3][0]=0;
}

if((rndm>5)&&(rndm<11)){
m[1][1][0]=1;
m[2][2][0]=0;
m[3][3][0]=0;
m[2][1][0]=1;
m[3][1][0]=1;
m[1][2][0]=0;
m[1][3][0]=0;
m[3][2][0]=1;
m[2][3][0]=0;
}










fill(11,11,11);
rect(displayWidth /2,
displayHeight /2,
displayWidth, displayHeight) ;




for(int f=0;f<55;f++){
for(int ff=0;ff<55;ff++){

if(m[f] [ff] [1]==0){
fill(77,77,77);
rect(
displayWidth /55*(1+f)
+displayWidth /111,
displayHeight /55*(1+ff) /2
-displayHeight /333,
displayWidth /99,
displayHeight /99 /2
) ;    }


if(m[f] [ff] [1]==1){
fill(177,77,77);
rect(
displayWidth /55*(1+f)
+displayWidth /111,
displayHeight /55*(1+ff) /2
-displayHeight /333,
displayWidth /99,
displayHeight /99 /2
) ;    }










} } 








for(int f=1;f<=3;f++){
for(int ff=1;ff<=3;ff++){


if(m[f] [ff] [0] ==1){
fill(222,11,222);
ellipse(mouseX-(f*displayWidth /55),
mouseY-(ff*displayHeight /55),
displayWidth /155,displayHeight /155);
}

if(m[f] [ff] [0] ==0){
fill(22,222,222);
ellipse(mouseX-(f*displayWidth /55),
mouseY-(ff*displayHeight /55),
displayWidth /155,displayHeight /155);
}




} } 





}


























if(int(random(55))==9){t=0;}


} 




























