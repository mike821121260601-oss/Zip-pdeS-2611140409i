



// ================================================================
// CAVE - APDE 0.5.3
// Single-file Processing / Android game
//
// Controls:
//   TOUCH / MOUSE   = fly up
//   SPACE           = fly up
//
// Game:
//   Fly through the cave.
//   Avoid red, green, blue and large monsters.
//   Health decreases on collision.
//   Game restarts by touching after GAME OVER.
// ================================================================

import android.app.Activity;
import android.content.Context;
import android.os.Vibrator;

// ------------------------------------------------
// GLOBALS
// ------------------------------------------------

Tunnel tunnel;
Player player;
MonsterManager monsterManager;

int startGameFrame = 0;
int framesElapsed = 0;
int score = 0;

boolean firstGame = true;
boolean gameOver = false;

boolean playButtonPressed = false;
boolean inputLocked = false;

int bgAlpha = 80;

boolean androidDevice = true;
Activity act;

String lastMessage = "";

String[] gameOverQuotes = {
  "retry",
  "try again",
  "just do it",
  "yes you can",
  "thanks for playing",
  "hello world",
  "you died",
  "game over"
};

// ------------------------------------------------
// SETTINGS
// ------------------------------------------------

void settings() {
  fullScreen();
}

// ------------------------------------------------
// SETUP
// ------------------------------------------------

void setup() {

  if (androidDevice) {
    act = this.getActivity();
    orientation(LANDSCAPE);
  }

  frameRate(30);
  noSmooth();

  restartGame();
}

// ------------------------------------------------
// RESTART
// ------------------------------------------------

void restartGame() {

  tunnel = new Tunnel();
  player = new Player();
  monsterManager = new MonsterManager();

  gameOver = false;
  inputLocked = false;

  score = 0;
  framesElapsed = 0;

  startGameFrame = frameCount;

  background(0);

  lastMessage = "";
}

// ------------------------------------------------
// DRAW
// ------------------------------------------------

void draw() {

  updateInput();

  updateTutorial();

  redrawBackground();

  if (gameOver) {

    drawGameover();

    if (!inputLocked && playButtonPressed) {
      restartGame();
    }

  } else {

    updateGameState();

    drawFramesElapsed();
    drawHealth();

    if (player.isDead()) {

      gameOver = true;

      score = framesElapsed;

      lastMessage = getRandomGameoverMessage();

      lockInput();
    }
  }

  tryUnlockInput();
}

// ------------------------------------------------
// INPUT
// ------------------------------------------------

void updateInput() {

  playButtonPressed = false;

  if (mousePressed) {
    playButtonPressed = true;
  }

  if (keyPressed) {

    if (key == ' ' ||
        keyCode == 32 ||
        key == 'w' ||
        key == 'W' ||
        key == '8') {

      playButtonPressed = true;
    }
  }

  if (player != null) {
    player.input();
  }
}

// ------------------------------------------------
// GAME UPDATE
// ------------------------------------------------

void updateGameState() {

  honorScript();

  player.update();

  tunnel.update();

  collCheckPlayerAgainstWalls();

  tunnel.draw();

  player.draw();

  monsterManager.update();

  framesElapsed = frameCount - startGameFrame;
}

// ------------------------------------------------
// TUTORIAL
// ------------------------------------------------

void updateTutorial() {

  int tutorialDuration = 200;

  if (framesElapsed < tutorialDuration && firstGame) {
    drawTutorial();
  }

  if (framesElapsed > tutorialDuration ||
      playButtonPressed) {

    firstGame = false;
  }
}

// ------------------------------------------------
// OBSTACLE
// ------------------------------------------------

enum Obstacle {
  FLOOR,
  CEILING
}

// ------------------------------------------------
// INPUT LOCK
// ------------------------------------------------

void lockInput() {
  inputLocked = true;
}

void tryUnlockInput() {

  if (!playButtonPressed) {
    inputLocked = false;
  }
}

// ------------------------------------------------
// GAME OVER MESSAGE
// ------------------------------------------------

String getRandomGameoverMessage() {

  int n = (int)random(gameOverQuotes.length);

  return gameOverQuotes[n];
}

// ------------------------------------------------
// BACKGROUND
// ------------------------------------------------

void redrawBackground() {

  noStroke();

  fill(0, bgAlpha);

  rectMode(CORNER);

  rect(0, 0, width, height);

  stroke(0);
}

// ------------------------------------------------
// SCORE
// ------------------------------------------------

void drawFramesElapsed() {

  noStroke();

  fill(0);

  rectMode(CORNER);

  rect(0, 0, 160, 80);

  textSize(40);

  textAlign(LEFT, TOP);

  fill(255);

  text(framesElapsed, 20, 15);
}

// ------------------------------------------------
// FPS
// ------------------------------------------------

void drawFramerate() {

  textSize(10);

  textAlign(LEFT, TOP);

  fill(150);

  text("FPS " + nf(frameRate, 1, 1),
       5,
       height - 20);
}

// ------------------------------------------------
// MONSTER COUNT
// ------------------------------------------------

void drawMonsterCount() {

  textSize(10);

  textAlign(LEFT, TOP);

  fill(150);

  text(
    "MONSTERS " + monsterManager.monsters.size(),
    5,
    height - 35
    );
}

// ------------------------------------------------
// TUTORIAL
// ------------------------------------------------

void drawTutorial() {

  noStroke();

  fill(100, 180);

  rectMode(CORNER);

  rect(
    0,
    height / 3,
    width,
    height / 3
    );

  textAlign(CENTER, CENTER);

  fill(255);

  textSize(50);

  text(
    "TOUCH TO FLY",
    width / 2,
    height / 2 - 30
    );

  textSize(28);

  text(
    "EVADE EVERYTHING",
    width / 2,
    height / 2 + 30
    );
}

// ------------------------------------------------
// GAME OVER
// ------------------------------------------------

void drawGameover() {

  rectMode(CORNER);

  noStroke();

  fill(20, 220);

  rect(
    0,
    0,
    width,
    height
    );

  textAlign(CENTER, CENTER);

  textSize(60);

  fill(255);

  text(
    lastMessage,
    width / 2,
    height / 3
    );

  textSize(35);

  fill(255);

  text(
    "SCORE",
    width / 2,
    height / 2
    );

  textSize(65);

  text(
    score,
    width / 2,
    height / 2 + 70
    );

  textSize(25);

  text(
    "TOUCH TO PLAY AGAIN",
    width / 2,
    height - 70
    );
}

// ------------------------------------------------
// HEALTH
// ------------------------------------------------

void drawHealth() {

  if (player.health <= 0) {
    return;
  }

  float healthWidth =
    (float)width / player.maxHealth;

  noFill();

  strokeWeight(10);

  if (player.health <
      player.maxHealth * 0.25f) {

    stroke(255, 0, 0);

  } else if (player.health <
             player.maxHealth * 0.50f) {

    stroke(255, 255, 0);

  } else {

    stroke(0, 255, 0);
  }

  line(
    5,
    5,
    5 + healthWidth * player.health,
    5
    );

  strokeWeight(1);

  stroke(0);
}

// ------------------------------------------------
// MONSTER SCRIPT
// ------------------------------------------------

void honorScript() {

  if (timeCheck(
    0,
    500,
    50,
    8,
    "a"
    )) {

    monsterManager.addMonster(
      new SquareMonster()
      );
  }

  if (timeCheck(
    500,
    1000,
    22,
    6,
    "b"
    )) {

    monsterManager.addMonster(
      new SinMonster()
      );
  }

  if (timeCheck(
    1000,
    99999,
    17,
    8,
    "b"
    )) {

    monsterManager.addMonster(
      new SinMonster()
      );
  }

  if (timeCheck(
    1500,
    99999,
    35,
    5,
    "c"
    )) {

    monsterManager.addMonster(
      new SeekerMonster()
      );
  }

  if (timeCheck(
    2000,
    99999,
    27,
    5,
    "d"
    )) {

    monsterManager.addMonster(
      new HugeMonster()
      );
  }

  if (timeCheck(
    2470,
    99999,
    18,
    10,
    "b"
    )) {

    monsterManager.addMonster(
      new SinMonster()
      );
  }
}

// ------------------------------------------------
// SCRIPT TIME CHECK
// ------------------------------------------------

boolean timeCheck(
  int start,
  int stop,
  int every,
  int maxOnScreenAtATime,
  String type) {

  if (framesElapsed < start) {
    return false;
  }

  if (framesElapsed >= stop) {
    return false;
  }

  if ((framesElapsed - start) % every != 0) {
    return false;
  }

  if (isMaxMonsters(
    type,
    maxOnScreenAtATime)) {

    return false;
  }

  return true;
}

// ------------------------------------------------
// COUNT MONSTERS
// ------------------------------------------------

boolean isMaxMonsters(
  String type,
  int maxOnScreenAtATime) {

  int count = 0;

  for (Monster m : monsterManager.monsters) {

    if (type.equals(m.toString())) {
      count++;
    }
  }

  return count >= maxOnScreenAtATime;
}

// ------------------------------------------------
// PLAYER / MONSTER COLLISION
// ------------------------------------------------

boolean collCheckMonsterAgainstPlayer(
  PVector playerPos,
  float playerSize,
  PVector monsterPos,
  float monsterSize) {

  float playerLeft =
    playerPos.x - playerSize / 2;

  float playerRight =
    playerPos.x + playerSize / 2;

  float playerTop =
    playerPos.y - playerSize / 2;

  float playerBottom =
    playerPos.y + playerSize / 2;

  float monsterLeft =
    monsterPos.x;

  float monsterRight =
    monsterPos.x + monsterSize;

  float monsterTop =
    monsterPos.y;

  float monsterBottom =
    monsterPos.y + monsterSize;

  boolean xHit =
    playerRight > monsterLeft &&
    playerLeft < monsterRight;

  boolean yHit =
    playerBottom > monsterTop &&
    playerTop < monsterBottom;

  return xHit && yHit;
}

// ------------------------------------------------
// PLAYER / WALL COLLISION
// ------------------------------------------------

void collCheckPlayerAgainstWalls() {

  if (tunnel.isCollision(
    player.pos,
    player.size,
    Obstacle.CEILING)) {

    player.applyForce(0, 10);

    player.applyDamage(10);
  }

  if (tunnel.isCollision(
    player.pos,
    player.size,
    Obstacle.FLOOR)) {

    player.applyForce(0, -10);

    player.applyDamage(10);
  }

  int damage =
    monsterManager.checkCollisions(player);

  if (damage > 0) {
    player.applyDamage(damage);
  }
}

// ================================================================
// TUNNEL
// ================================================================

class Tunnel {

  float TunnelHeight =
    height - height / 2.0f;

  int modelXScale = 10;

  float drawXScale = 10;

  int yscl = 20;

  float flatness = 0.5f;

  int wallColor;

  PVector[] ceiling;

  PShape ceilingShape;
  PShape floorShape;

  Tunnel() {

    int count =
      max(2, width / modelXScale);

    ceiling =
      new PVector[count];

    ceiling[0] =
      generate(0, true);

    for (int x = 1;
         x < ceiling.length;
         x++) {

      ceiling[x] =
        generate(x, false);
    }
  }

  void update() {

    moveTunnel();

    wallColor = color(255);
  }

  void draw() {

    strokeWeight(1);

    PShape t =
      getTunnelShape();

    shape(t, 0, 0);
  }

  // ------------------------------------------------
  // MOVE TUNNEL
  // ------------------------------------------------

  void moveTunnel() {

    for (int x = 0;
         x < ceiling.length - 1;
         x++) {

      ceiling[x].y =
        ceiling[x + 1].y;
    }

    ceiling[ceiling.length - 1] =
      generate(
        ceiling.length - 1,
        false
        );
  }

  // ------------------------------------------------
  // CREATE TUNNEL
  // ------------------------------------------------

  PShape getTunnelShape() {

    PShape group =
      createShape(GROUP);

    ceilingShape =
      getWall(true);

    floorShape =
      getWall(false);

    group.addChild(ceilingShape);
    group.addChild(floorShape);

    return group;
  }

  // ------------------------------------------------
  // COLLISION WITH WALL
  // ------------------------------------------------

  boolean isCollision(
    PVector pos,
    float size,
    Obstacle obstacle) {

    if (ceiling == null) {
      return false;
    }

    int i =
      floor(
        map(
          pos.x,
          0,
          width,
          0,
          ceiling.length - 1
          )
        );

    i =
      constrain(
        i,
        0,
        ceiling.length - 1
        );

    int nextI =
      min(
        ceiling.length - 1,
        i + 1
        );

    float y0 =
      ceiling[i].y;

    float y1 =
      ceiling[nextI].y;

    float topY =
      min(y0, y1);

    float bottomY =
      max(y0, y1) + TunnelHeight;

    if (obstacle == Obstacle.CEILING) {

      if (pos.y - size / 2 <= topY) {
        return true;
      }
    }

    if (obstacle == Obstacle.FLOOR) {

      if (pos.y + size / 2 >= bottomY) {
        return true;
      }
    }

    return false;
  }

  // ------------------------------------------------
  // DRAW WALL
  // ------------------------------------------------

  PShape getWall(boolean top) {

    PShape wall =
      createShape();

    wall.beginShape();

    wall.noFill();

    wall.stroke(wallColor);

    if (top) {

      for (int i = 0;
           i < ceiling.length;
           i++) {

        PVector p =
          ceiling[i];

        wall.vertex(
          p.x * drawXScale,
          p.y
          );
      }

      wall.vertex(
        width + 20,
        ceiling[ceiling.length - 1].y
        );

      wall.vertex(
        width + 20,
        -20
        );

      wall.vertex(
        -20,
        -20
        );

      wall.vertex(
        -20,
        ceiling[0].y
        );

    } else {

      for (int i = 0;
           i < ceiling.length;
           i++) {

        PVector p =
          ceiling[i];

        wall.vertex(
          p.x * drawXScale,
          p.y + TunnelHeight
          );
      }

      wall.vertex(
        width + 20,
        ceiling[ceiling.length - 1].y
        + TunnelHeight
        );

      wall.vertex(
        width + 20,
        height + 20
        );

      wall.vertex(
        -20,
        height + 20
        );

      wall.vertex(
        -20,
        ceiling[0].y
        + TunnelHeight
        );
    }

    wall.endShape();

    return wall;
  }

  // ------------------------------------------------
  // GENERATE CAVE
  // ------------------------------------------------

  PVector generate(
    int x,
    boolean init) {

    PVector c =
      new PVector(x, 100);

    if (init) {

      c.y = 100;

    } else {

      float previous =
        ceiling[x - 1].y;

      if (random(1) > 0.5f) {

        c.y =
          previous + yscl;

      } else {

        c.y =
          previous - yscl;
      }

      if (random(1) > flatness) {

        c.y = previous;
      }
    }

    c.y =
      constrain(
        c.y,
        20,
        height - TunnelHeight - 20
        );

    return c;
  }

  // ------------------------------------------------
  // CAVE TOP
  // ------------------------------------------------

  int getTunnelTop(int x) {

    int i =
      round(
        map(
          x,
          0,
          width,
          0,
          ceiling.length - 1
          )
        );

    i =
      constrain(
        i,
        0,
        ceiling.length - 1
        );

    return (int)ceiling[i].y;
  }

  // ------------------------------------------------
  // CAVE MIDDLE
  // ------------------------------------------------

  int getTunnelMiddle(int x) {

    return (int)(
      getTunnelTop(x)
      + TunnelHeight / 2
      );
  }

  float getTunnelHeight() {

    return TunnelHeight;
  }
}

// ================================================================
// ABSTRACT GAME OBJECT
// ================================================================

abstract class GameObject {

  PVector pos;
  PVector spd;
  PVector acc;

  float maxSpeed;
  float size;
  float grav;

  GameObject() {

    pos =
      new PVector(0, 0);

    spd =
      new PVector(0, 0);

    acc =
      new PVector(0, 0);

    maxSpeed = 10;
    size = 10;
    grav = 0.5f;

    setup();

    update();
  }

  void applyForce(
    float x,
    float y) {

    acc.x += x;
    acc.y += y;
  }

  void applyGravity() {

    applyForce(0, grav);
  }

  void update() {

    applyGravity();

    spd.add(acc);

    spd.limit(maxSpeed);

    pos.add(spd);

    acc.mult(0);
  }

  abstract void setup();
}

// ================================================================
// PLAYER
// ================================================================

class Player extends GameObject {

  float maxHealth = 38;

  float health = maxHealth;

  boolean invulnerability = false;

  int invulnerabilityStartFrame = 0;

  int invulnerabilityDuration = 30;

  // ------------------------------------------------

  void setup() {

    int x =
      width / 6;

    pos =
      new PVector(
        x,
        tunnel.getTunnelMiddle(x)
        );

    maxSpeed = 7;

    size = 35;

    grav = 0.5f;
  }

  // ------------------------------------------------

  void update() {

    super.update();

    updateInvulnerability();

    // prevent extreme speed
    spd.y =
      constrain(
        spd.y,
        -maxSpeed,
        maxSpeed
        );
  }

  // ------------------------------------------------

  void draw() {

    if (invulnerability) {

      strokeWeight(2);

      int dangerRed =
        color(
          155 + 100 *
          sin(framesElapsed * 0.2f),
          0,
          0
          );

      stroke(dangerRed);

      if (playButtonPressed) {
        fill(dangerRed);
      } else {
        fill(0);
      }

    } else {

      if (playButtonPressed) {

        strokeWeight(5);

        stroke(255);

        fill(255);

      } else {

        strokeWeight(3);

        stroke(255);

        fill(0);
      }
    }

    beginShape();

    vertex(
      pos.x,
      pos.y
      );

    vertex(
      pos.x - size / 2,
      pos.y + size / 2
      );

    vertex(
      pos.x - size / 2,
      pos.y - size / 2
      );

    endShape(CLOSE);

    strokeWeight(1);
  }

  // ------------------------------------------------
  // DAMAGE
  // ------------------------------------------------

  void applyDamage(int damage) {

    if (damage <= 0) {
      return;
    }

    if (invulnerability) {
      return;
    }

    invulnerabilityDuration =
      damage * 3;

    invulnerability = true;

    invulnerabilityStartFrame =
      frameCount;

    health -= damage;

    health =
      max(0, health);

    vibrate(damage * 5);
  }

  // ------------------------------------------------
  // VIBRATION
  // ------------------------------------------------

  void vibrate(int milliseconds) {

    if (!androidDevice) {
      return;
    }

    if (act == null) {
      return;
    }

    try {

      Vibrator vibrator =
        (Vibrator)act.getSystemService(
        Context.VIBRATOR_SERVICE
        );

      if (vibrator != null) {

        vibrator.vibrate(
          milliseconds
          );
      }

    } catch(Exception e) {
      // ignore vibration failure
    }
  }

  // ------------------------------------------------
  // INVULNERABILITY
  // ------------------------------------------------

  void updateInvulnerability() {

    if (frameCount >
        invulnerabilityStartFrame
        + invulnerabilityDuration) {

      invulnerability = false;
    }
  }

  // ------------------------------------------------
  // INPUT
  // ------------------------------------------------

  void input() {

    if (!playButtonPressed) {
      return;
    }

    if (spd.y > 0) {
      spd.y = 0;
    }

    applyForce(
      0,
      -1.5f
      );
  }

  // ------------------------------------------------
  // DEAD
  // ------------------------------------------------

  boolean isDead() {

    return health < 1;
  }
}

// ================================================================
// MONSTER MANAGER
// ================================================================

class MonsterManager {

  ArrayList<Monster> monsters =
    new ArrayList<Monster>();

  // ------------------------------------------------

  void update() {

    for (int i = monsters.size() - 1;
         i >= 0;
         i--) {

      Monster m =
        monsters.get(i);

      m.update();

      if (m.isTrespassing() ||
          m.isDead()) {

        monsters.remove(i);
      }
    }
  }

  // ------------------------------------------------

  void addMonster(Monster m) {

    if (m != null) {
      monsters.add(m);
    }
  }

  // ------------------------------------------------

  int checkCollisions(
    Player player) {

    for (Monster m : monsters) {

      if (collCheckMonsterAgainstPlayer(
        player.pos,
        player.size,
        m.pos,
        m.size)) {

        int damage =
          m.getCollisionDamageToPlayer();

        m.onCollision();

        return damage;
      }

      if (tunnel.isCollision(
        m.pos,
        m.size,
        Obstacle.CEILING)) {

        m.onCollision();
      }

      if (tunnel.isCollision(
        m.pos,
        m.size,
        Obstacle.FLOOR)) {

        m.onCollision();
      }
    }

    return 0;
  }
}

// ================================================================
// MONSTER BASE
// ================================================================

abstract class Monster extends GameObject {

  boolean dead = false;

  // ------------------------------------------------

  abstract int getCollisionDamageToPlayer();

  abstract void onCollision();

  // ------------------------------------------------

  boolean isTrespassing() {

    return pos.x < -size * 2;
  }

  // ------------------------------------------------

  boolean isDead() {

    return dead;
  }
}

// ================================================================
// RED SQUARE MONSTER
// ================================================================

class SquareMonster extends Monster {

  void setup() {

    float randomValue =
      noise(
        framesElapsed / 100.0f
        + random(1) / 10.0f
        );

    float tunnelTop =
      tunnel.getTunnelTop(width);

    float tunnelBottom =
      tunnelTop
      + tunnel.TunnelHeight;

    float safeY =
      map(
        randomValue,
        0,
        1,
        tunnelTop + size,
        tunnelBottom - size
        );

    pos =
      new PVector(
        width + size,
        safeY
        );

    spd.x = -4;
  }

  // ------------------------------------------------

  void update() {

    applyForce(
      -10,
      -grav
      );

    super.update();

    drawMonster();
  }

  // ------------------------------------------------

  void drawMonster() {

    noStroke();

    fill(
      255,
      0,
      0
      );

    rectMode(CORNER);

    rect(
      pos.x,
      pos.y,
      size,
      size
      );
  }

  // ------------------------------------------------

  int getCollisionDamageToPlayer() {

    return 5;
  }

  // ------------------------------------------------

  void onCollision() {

    dead = true;
  }

  // ------------------------------------------------

  public String toString() {

    return "a";
  }
}

// ================================================================
// SIN MONSTER
// ================================================================

class SinMonster extends SquareMonster {

  void update() {

    applyForce(
      0,
      map(
        sin(
          radians(frameCount * 2)
          ),
        -1,
        1,
        -1.0f,
        1.0f
        )
      );

    super.update();

    drawSinMonster();
  }

  // ------------------------------------------------

  void drawSinMonster() {

    noStroke();

    fill(
      150,
      255,
      150
      );

    rectMode(CORNER);

    rect(
      pos.x,
      pos.y,
      size,
      size
      );
  }

  // ------------------------------------------------

  public String toString() {

    return "b";
  }
}

// ================================================================
// SEEKER MONSTER
// ================================================================

class SeekerMonster extends SquareMonster {

  void setup() {

    super.setup();

    pos.y =
      tunnel.getTunnelMiddle(width);
  }

  // ------------------------------------------------

  void update() {

    PVector towardsPlayer =
      PVector.sub(
        player.pos,
        pos
        );

    towardsPlayer.mult(0.1f);

    towardsPlayer.x = 0;

    applyForce(
      towardsPlayer.x,
      towardsPlayer.y
      );

    super.update();

    drawSeeker();
  }

  // ------------------------------------------------

  void drawSeeker() {

    noStroke();

    fill(
      202,
      209,
      250
      );

    rectMode(CORNER);

    rect(
      pos.x,
      pos.y,
      size,
      size
      );
  }

  // ------------------------------------------------

  public String toString() {

    return "c";
  }
}

// ================================================================
// HUGE MONSTER
// ================================================================

class HugeMonster extends SquareMonster {

  void setup() {

    super.setup();

    size *= 2;

    maxSpeed = 10;
  }

  // ------------------------------------------------

  void drawMonster() {

    noStroke();

    fill(
      255,
      80,
      0
      );

    rectMode(CORNER);

    rect(
      pos.x,
      pos.y,
      size,
      size
      );
  }

  // ------------------------------------------------

  int getCollisionDamageToPlayer() {

    return 10;
  }

  // ------------------------------------------------

  public String toString() {

    return "d";
  }
}















/*



// ================================================================
// CAVE - APDE 0.5.3
// Single-file Processing / Android game
//
// Controls:
//   TOUCH / MOUSE   = fly up
//   SPACE           = fly up
//
// Game:
//   Fly through the cave.
//   Avoid red, green, blue and large monsters.
//   Health decreases on collision.
//   Game restarts by touching after GAME OVER.
// ================================================================

import android.app.Activity;
import android.content.Context;
import android.os.Vibrator;

// ------------------------------------------------
// GLOBALS
// ------------------------------------------------

Tunnel tunnel;
Player player;
MonsterManager monsterManager;

int startGameFrame = 0;
int framesElapsed = 0;
int score = 0;

boolean firstGame = true;
boolean gameOver = false;

boolean playButtonPressed = false;
boolean inputLocked = false;

int bgAlpha = 80;

boolean androidDevice = true;
Activity act;

String lastMessage = "";

String[] gameOverQuotes = {
  "retry",
  "try again",
  "just do it",
  "yes you can",
  "thanks for playing",
  "hello world",
  "you died",
  "game over"
};

// ------------------------------------------------
// SETTINGS
// ------------------------------------------------

void settings() {
  fullScreen();
}

// ------------------------------------------------
// SETUP
// ------------------------------------------------

void setup() {

  if (androidDevice) {
    act = this.getActivity();
    orientation(LANDSCAPE);
  }

  frameRate(30);
  noSmooth();

  restartGame();
}

// ------------------------------------------------
// RESTART
// ------------------------------------------------

void restartGame() {

  tunnel = new Tunnel();
  player = new Player();
  monsterManager = new MonsterManager();

  gameOver = false;
  inputLocked = false;

  score = 0;
  framesElapsed = 0;

  startGameFrame = frameCount;

  background(0);

  lastMessage = "";
}

// ------------------------------------------------
// DRAW
// ------------------------------------------------

void draw() {

  updateInput();

  updateTutorial();

  redrawBackground();

  if (gameOver) {

    drawGameover();

    if (!inputLocked && playButtonPressed) {
      restartGame();
    }

  } else {

    updateGameState();

    drawFramesElapsed();
    drawHealth();

    if (player.isDead()) {

      gameOver = true;

      score = framesElapsed;

      lastMessage = getRandomGameoverMessage();

      lockInput();
    }
  }

  tryUnlockInput();
}

// ------------------------------------------------
// INPUT
// ------------------------------------------------

void updateInput() {

  playButtonPressed = false;

  if (mousePressed) {
    playButtonPressed = true;
  }

  if (keyPressed) {

    if (key == ' ' ||
        keyCode == 32 ||
        key == 'w' ||
        key == 'W' ||
        key == '8') {

      playButtonPressed = true;
    }
  }

  if (player != null) {
    player.input();
  }
}

// ------------------------------------------------
// GAME UPDATE
// ------------------------------------------------

void updateGameState() {

  honorScript();

  player.update();

  tunnel.update();

  collCheckPlayerAgainstWalls();

  tunnel.draw();

  player.draw();

  monsterManager.update();

  framesElapsed = frameCount - startGameFrame;
}

// ------------------------------------------------
// TUTORIAL
// ------------------------------------------------

void updateTutorial() {

  int tutorialDuration = 200;

  if (framesElapsed < tutorialDuration && firstGame) {
    drawTutorial();
  }

  if (framesElapsed > tutorialDuration ||
      playButtonPressed) {

    firstGame = false;
  }
}

// ------------------------------------------------
// OBSTACLE
// ------------------------------------------------

enum Obstacle {
  FLOOR,
  CEILING
}

// ------------------------------------------------
// INPUT LOCK
// ------------------------------------------------

void lockInput() {
  inputLocked = true;
}

void tryUnlockInput() {

  if (!playButtonPressed) {
    inputLocked = false;
  }
}

// ------------------------------------------------
// GAME OVER MESSAGE
// ------------------------------------------------

String getRandomGameoverMessage() {

  int n = (int)random(gameOverQuotes.length);

  return gameOverQuotes[n];
}

// ------------------------------------------------
// BACKGROUND
// ------------------------------------------------

void redrawBackground() {

  noStroke();

  fill(0, bgAlpha);

  rectMode(CORNER);

  rect(0, 0, width, height);

  stroke(0);
}

// ------------------------------------------------
// SCORE
// ------------------------------------------------

void drawFramesElapsed() {

  noStroke();

  fill(0);

  rectMode(CORNER);

  rect(0, 0, 160, 80);

  textSize(40);

  textAlign(LEFT, TOP);

  fill(255);

  text(framesElapsed, 20, 15);
}

// ------------------------------------------------
// FPS
// ------------------------------------------------

void drawFramerate() {

  textSize(10);

  textAlign(LEFT, TOP);

  fill(150);

  text("FPS " + nf(frameRate, 1, 1),
       5,
       height - 20);
}

// ------------------------------------------------
// MONSTER COUNT
// ------------------------------------------------

void drawMonsterCount() {

  textSize(10);

  textAlign(LEFT, TOP);

  fill(150);

  text(
    "MONSTERS " + monsterManager.monsters.size(),
    5,
    height - 35
    );
}

// ------------------------------------------------
// TUTORIAL
// ------------------------------------------------

void drawTutorial() {

  noStroke();

  fill(100, 180);

  rectMode(CORNER);

  rect(
    0,
    height / 3,
    width,
    height / 3
    );

  textAlign(CENTER, CENTER);

  fill(255);

  textSize(50);

  text(
    "TOUCH TO FLY",
    width / 2,
    height / 2 - 30
    );

  textSize(28);

  text(
    "EVADE EVERYTHING",
    width / 2,
    height / 2 + 30
    );
}

// ------------------------------------------------
// GAME OVER
// ------------------------------------------------

void drawGameover() {

  rectMode(CORNER);

  noStroke();

  fill(20, 220);

  rect(
    0,
    0,
    width,
    height
    );

  textAlign(CENTER, CENTER);

  textSize(60);

  fill(255);

  text(
    lastMessage,
    width / 2,
    height / 3
    );

  textSize(35);

  fill(255);

  text(
    "SCORE",
    width / 2,
    height / 2
    );

  textSize(65);

  text(
    score,
    width / 2,
    height / 2 + 70
    );

  textSize(25);

  text(
    "TOUCH TO PLAY AGAIN",
    width / 2,
    height - 70
    );
}

// ------------------------------------------------
// HEALTH
// ------------------------------------------------

void drawHealth() {

  if (player.health <= 0) {
    return;
  }

  float healthWidth =
    (float)width / player.maxHealth;

  noFill();

  strokeWeight(10);

  if (player.health <
      player.maxHealth * 0.25f) {

    stroke(255, 0, 0);

  } else if (player.health <
             player.maxHealth * 0.50f) {

    stroke(255, 255, 0);

  } else {

    stroke(0, 255, 0);
  }

  line(
    5,
    5,
    5 + healthWidth * player.health,
    5
    );

  strokeWeight(1);

  stroke(0);
}

// ------------------------------------------------
// MONSTER SCRIPT
// ------------------------------------------------

void honorScript() {

  if (timeCheck(
    0,
    500,
    50,
    8,
    "a"
    )) {

    monsterManager.addMonster(
      new SquareMonster()
      );
  }

  if (timeCheck(
    500,
    1000,
    22,
    6,
    "b"
    )) {

    monsterManager.addMonster(
      new SinMonster()
      );
  }

  if (timeCheck(
    1000,
    99999,
    17,
    8,
    "b"
    )) {

    monsterManager.addMonster(
      new SinMonster()
      );
  }

  if (timeCheck(
    1500,
    99999,
    35,
    5,
    "c"
    )) {

    monsterManager.addMonster(
      new SeekerMonster()
      );
  }

  if (timeCheck(
    2000,
    99999,
    27,
    5,
    "d"
    )) {

    monsterManager.addMonster(
      new HugeMonster()
      );
  }

  if (timeCheck(
    2470,
    99999,
    18,
    10,
    "b"
    )) {

    monsterManager.addMonster(
      new SinMonster()
      );
  }
}

// ------------------------------------------------
// SCRIPT TIME CHECK
// ------------------------------------------------

boolean timeCheck(
  int start,
  int stop,
  int every,
  int maxOnScreenAtATime,
  String type) {

  if (framesElapsed < start) {
    return false;
  }

  if (framesElapsed >= stop) {
    return false;
  }

  if ((framesElapsed - start) % every != 0) {
    return false;
  }

  if (isMaxMonsters(
    type,
    maxOnScreenAtATime)) {

    return false;
  }

  return true;
}

// ------------------------------------------------
// COUNT MONSTERS
// ------------------------------------------------

boolean isMaxMonsters(
  String type,
  int maxOnScreenAtATime) {

  int count = 0;

  for (Monster m : monsterManager.monsters) {

    if (type.equals(m.toString())) {
      count++;
    }
  }

  return count >= maxOnScreenAtATime;
}

// ------------------------------------------------
// PLAYER / MONSTER COLLISION
// ------------------------------------------------

boolean collCheckMonsterAgainstPlayer(
  PVector playerPos,
  float playerSize,
  PVector monsterPos,
  float monsterSize) {

  float playerLeft =
    playerPos.x - playerSize / 2;

  float playerRight =
    playerPos.x + playerSize / 2;

  float playerTop =
    playerPos.y - playerSize / 2;

  float playerBottom =
    playerPos.y + playerSize / 2;

  float monsterLeft =
    monsterPos.x;

  float monsterRight =
    monsterPos.x + monsterSize;

  float monsterTop =
    monsterPos.y;

  float monsterBottom =
    monsterPos.y + monsterSize;

  boolean xHit =
    playerRight > monsterLeft &&
    playerLeft < monsterRight;

  boolean yHit =
    playerBottom > monsterTop &&
    playerTop < monsterBottom;

  return xHit && yHit;
}

// ------------------------------------------------
// PLAYER / WALL COLLISION
// ------------------------------------------------

void collCheckPlayerAgainstWalls() {

  if (tunnel.isCollision(
    player.pos,
    player.size,
    Obstacle.CEILING)) {

    player.applyForce(0, 10);

    player.applyDamage(10);
  }

  if (tunnel.isCollision(
    player.pos,
    player.size,
    Obstacle.FLOOR)) {

    player.applyForce(0, -10);

    player.applyDamage(10);
  }

  int damage =
    monsterManager.checkCollisions(player);

  if (damage > 0) {
    player.applyDamage(damage);
  }
}

// ================================================================
// TUNNEL
// ================================================================

class Tunnel {

  float TunnelHeight =
    height - height / 2.0f;

  int modelXScale = 10;

  float drawXScale = 10;

  int yscl = 20;

  float flatness = 0.5f;

  int wallColor;

  PVector[] ceiling;

  PShape ceilingShape;
  PShape floorShape;

  Tunnel() {

    int count =
      max(2, width / modelXScale);

    ceiling =
      new PVector[count];

    ceiling[0] =
      generate(0, true);

    for (int x = 1;
         x < ceiling.length;
         x++) {

      ceiling[x] =
        generate(x, false);
    }
  }

  void update() {

    moveTunnel();

    wallColor = color(255);
  }

  void draw() {

    strokeWeight(1);

    PShape t =
      getTunnelShape();

    shape(t, 0, 0);
  }

  // ------------------------------------------------
  // MOVE TUNNEL
  // ------------------------------------------------

  void moveTunnel() {

    for (int x = 0;
         x < ceiling.length - 1;
         x++) {

      ceiling[x].y =
        ceiling[x + 1].y;
    }

    ceiling[ceiling.length - 1] =
      generate(
        ceiling.length - 1,
        false
        );
  }

  // ------------------------------------------------
  // CREATE TUNNEL
  // ------------------------------------------------

  PShape getTunnelShape() {

    PShape group =
      createShape(GROUP);

    ceilingShape =
      getWall(true);

    floorShape =
      getWall(false);

    group.addChild(ceilingShape);
    group.addChild(floorShape);

    return group;
  }

  // ------------------------------------------------
  // COLLISION WITH WALL
  // ------------------------------------------------

  boolean isCollision(
    PVector pos,
    float size,
    Obstacle obstacle) {

    if (ceiling == null) {
      return false;
    }

    int i =
      floor(
        map(
          pos.x,
          0,
          width,
          0,
          ceiling.length - 1
          )
        );

    i =
      constrain(
        i,
        0,
        ceiling.length - 1
        );

    int nextI =
      min(
        ceiling.length - 1,
        i + 1
        );

    float y0 =
      ceiling[i].y;

    float y1 =
      ceiling[nextI].y;

    float topY =
      min(y0, y1);

    float bottomY =
      max(y0, y1) + TunnelHeight;

    if (obstacle == Obstacle.CEILING) {

      if (pos.y - size / 2 <= topY) {
        return true;
      }
    }

    if (obstacle == Obstacle.FLOOR) {

      if (pos.y + size / 2 >= bottomY) {
        return true;
      }
    }

    return false;
  }

  // ------------------------------------------------
  // DRAW WALL
  // ------------------------------------------------

  PShape getWall(boolean top) {

    PShape wall =
      createShape();

    wall.beginShape();

    wall.noFill();

    wall.stroke(wallColor);

    if (top) {

      for (int i = 0;
           i < ceiling.length;
           i++) {

        PVector p =
          ceiling[i];

        wall.vertex(
          p.x * drawXScale,
          p.y
          );
      }

      wall.vertex(
        width + 20,
        ceiling[ceiling.length - 1].y
        );

      wall.vertex(
        width + 20,
        -20
        );

      wall.vertex(
        -20,
        -20
        );

      wall.vertex(
        -20,
        ceiling[0].y
        );

    } else {

      for (int i = 0;
           i < ceiling.length;
           i++) {

        PVector p =
          ceiling[i];

        wall.vertex(
          p.x * drawXScale,
          p.y + TunnelHeight
          );
      }

      wall.vertex(
        width + 20,
        ceiling[ceiling.length - 1].y
        + TunnelHeight
        );

      wall.vertex(
        width + 20,
        height + 20
        );

      wall.vertex(
        -20,
        height + 20
        );

      wall.vertex(
        -20,
        ceiling[0].y
        + TunnelHeight
        );
    }

    wall.endShape();

    return wall;
  }

  // ------------------------------------------------
  // GENERATE CAVE
  // ------------------------------------------------

  PVector generate(
    int x,
    boolean init) {

    PVector c =
      new PVector(x, 100);

    if (init) {

      c.y = 100;

    } else {

      float previous =
        ceiling[x - 1].y;

      if (random(1) > 0.5f) {

        c.y =
          previous + yscl;

      } else {

        c.y =
          previous - yscl;
      }

      if (random(1) > flatness) {

        c.y = previous;
      }
    }

    c.y =
      constrain(
        c.y,
        20,
        height - TunnelHeight - 20
        );

    return c;
  }

  // ------------------------------------------------
  // CAVE TOP
  // ------------------------------------------------

  int getTunnelTop(int x) {

    int i =
      round(
        map(
          x,
          0,
          width,
          0,
          ceiling.length - 1
          )
        );

    i =
      constrain(
        i,
        0,
        ceiling.length - 1
        );

    return (int)ceiling[i].y;
  }

  // ------------------------------------------------
  // CAVE MIDDLE
  // ------------------------------------------------

  int getTunnelMiddle(int x) {

    return (int)(
      getTunnelTop(x)
      + TunnelHeight / 2
      );
  }

  float getTunnelHeight() {

    return TunnelHeight;
  }
}

// ================================================================
// ABSTRACT GAME OBJECT
// ================================================================

abstract class GameObject {

  PVector pos;
  PVector spd;
  PVector acc;

  float maxSpeed;
  float size;
  float grav;

  GameObject() {

    pos =
      new PVector(0, 0);

    spd =
      new PVector(0, 0);

    acc =
      new PVector(0, 0);

    maxSpeed = 10;
    size = 10;
    grav = 0.5f;

    setup();

    update();
  }

  void applyForce(
    float x,
    float y) {

    acc.x += x;
    acc.y += y;
  }

  void applyGravity() {

    applyForce(0, grav);
  }

  void update() {

    applyGravity();

    spd.add(acc);

    spd.limit(maxSpeed);

    pos.add(spd);

    acc.mult(0);
  }

  abstract void setup();
}

// ================================================================
// PLAYER
// ================================================================

class Player extends GameObject {

  float maxHealth = 38;

  float health = maxHealth;

  boolean invulnerability = false;

  int invulnerabilityStartFrame = 0;

  int invulnerabilityDuration = 30;

  // ------------------------------------------------

  void setup() {

    int x =
      width / 6;

    pos =
      new PVector(
        x,
        tunnel.getTunnelMiddle(x)
        );

    maxSpeed = 7;

    size = 35;

    grav = 0.5f;
  }

  // ------------------------------------------------

  void update() {

    super.update();

    updateInvulnerability();

    // prevent extreme speed
    spd.y =
      constrain(
        spd.y,
        -maxSpeed,
        maxSpeed
        );
  }

  // ------------------------------------------------

  void draw() {

    if (invulnerability) {

      strokeWeight(2);

      int dangerRed =
        color(
          155 + 100 *
          sin(framesElapsed * 0.2f),
          0,
          0
          );

      stroke(dangerRed);

      if (playButtonPressed) {
        fill(dangerRed);
      } else {
        fill(0);
      }

    } else {

      if (playButtonPressed) {

        strokeWeight(5);

        stroke(255);

        fill(255);

      } else {

        strokeWeight(3);

        stroke(255);

        fill(0);
      }
    }

    beginShape();

    vertex(
      pos.x,
      pos.y
      );

    vertex(
      pos.x - size / 2,
      pos.y + size / 2
      );

    vertex(
      pos.x - size / 2,
      pos.y - size / 2
      );

    endShape(CLOSE);

    strokeWeight(1);
  }

  // ------------------------------------------------
  // DAMAGE
  // ------------------------------------------------

  void applyDamage(int damage) {

    if (damage <= 0) {
      return;
    }

    if (invulnerability) {
      return;
    }

    invulnerabilityDuration =
      damage * 3;

    invulnerability = true;

    invulnerabilityStartFrame =
      frameCount;

    health -= damage;

    health =
      max(0, health);

    vibrate(damage * 5);
  }

  // ------------------------------------------------
  // VIBRATION
  // ------------------------------------------------

  void vibrate(int milliseconds) {

    if (!androidDevice) {
      return;
    }

    if (act == null) {
      return;
    }

    try {

      Vibrator vibrator =
        (Vibrator)act.getSystemService(
        Context.VIBRATOR_SERVICE
        );

      if (vibrator != null) {

        vibrator.vibrate(
          milliseconds
          );
      }

    } catch(Exception e) {
      // ignore vibration failure
    }
  }

  // ------------------------------------------------
  // INVULNERABILITY
  // ------------------------------------------------

  void updateInvulnerability() {

    if (frameCount >
        invulnerabilityStartFrame
        + invulnerabilityDuration) {

      invulnerability = false;
    }
  }

  // ------------------------------------------------
  // INPUT
  // ------------------------------------------------

  void input() {

    if (!playButtonPressed) {
      return;
    }

    if (spd.y > 0) {
      spd.y = 0;
    }

    applyForce(
      0,
      -1.5f
      );
  }

  // ------------------------------------------------
  // DEAD
  // ------------------------------------------------

  boolean isDead() {

    return health < 1;
  }
}

// ================================================================
// MONSTER MANAGER
// ================================================================

class MonsterManager {

  ArrayList<Monster> monsters =
    new ArrayList<Monster>();

  // ------------------------------------------------

  void update() {

    for (int i = monsters.size() - 1;
         i >= 0;
         i--) {

      Monster m =
        monsters.get(i);

      m.update();

      if (m.isTrespassing() ||
          m.isDead()) {

        monsters.remove(i);
      }
    }
  }

  // ------------------------------------------------

  void addMonster(Monster m) {

    if (m != null) {
      monsters.add(m);
    }
  }

  // ------------------------------------------------

  int checkCollisions(
    Player player) {

    for (Monster m : monsters) {

      if (collCheckMonsterAgainstPlayer(
        player.pos,
        player.size,
        m.pos,
        m.size)) {

        int damage =
          m.getCollisionDamageToPlayer();

        m.onCollision();

        return damage;
      }

      if (tunnel.isCollision(
        m.pos,
        m.size,
        Obstacle.CEILING)) {

        m.onCollision();
      }

      if (tunnel.isCollision(
        m.pos,
        m.size,
        Obstacle.FLOOR)) {

        m.onCollision();
      }
    }

    return 0;
  }
}

// ================================================================
// MONSTER BASE
// ================================================================

abstract class Monster extends GameObject {

  boolean dead = false;

  // ------------------------------------------------

  abstract int getCollisionDamageToPlayer();

  abstract void onCollision();

  // ------------------------------------------------

  boolean isTrespassing() {

    return pos.x < -size * 2;
  }

  // ------------------------------------------------

  boolean isDead() {

    return dead;
  }
}

// ================================================================
// RED SQUARE MONSTER
// ================================================================

class SquareMonster extends Monster {

  void setup() {

    float randomValue =
      noise(
        framesElapsed / 100.0f
        + random(1) / 10.0f
        );

    float tunnelTop =
      tunnel.getTunnelTop(width);

    float tunnelBottom =
      tunnelTop
      + tunnel.TunnelHeight;

    float safeY =
      map(
        randomValue,
        0,
        1,
        tunnelTop + size,
        tunnelBottom - size
        );

    pos =
      new PVector(
        width + size,
        safeY
        );

    spd.x = -4;
  }

  // ------------------------------------------------

  void update() {

    applyForce(
      -10,
      -grav
      );

    super.update();

    drawMonster();
  }

  // ------------------------------------------------

  void drawMonster() {

    noStroke();

    fill(
      255,
      0,
      0
      );

    rectMode(CORNER);

    rect(
      pos.x,
      pos.y,
      size,
      size
      );
  }

  // ------------------------------------------------

  int getCollisionDamageToPlayer() {

    return 5;
  }

  // ------------------------------------------------

  void onCollision() {

    dead = true;
  }

  // ------------------------------------------------

  public String toString() {

    return "a";
  }
}

// ================================================================
// SIN MONSTER
// ================================================================

class SinMonster extends SquareMonster {

  void update() {

    applyForce(
      0,
      map(
        sin(
          radians(frameCount * 2)
          ),
        -1,
        1,
        -1.0f,
        1.0f
        )
      );

    super.update();

    drawSinMonster();
  }

  // ------------------------------------------------

  void drawSinMonster() {

    noStroke();

    fill(
      150,
      255,
      150
      );

    rectMode(CORNER);

    rect(
      pos.x,
      pos.y,
      size,
      size
      );
  }

  // ------------------------------------------------

  public String toString() {

    return "b";
  }
}

// ================================================================
// SEEKER MONSTER
// ================================================================

class SeekerMonster extends SquareMonster {

  void setup() {

    super.setup();

    pos.y =
      tunnel.getTunnelMiddle(width);
  }

  // ------------------------------------------------

  void update() {

    PVector towardsPlayer =
      PVector.sub(
        player.pos,
        pos
        );

    towardsPlayer.mult(0.1f);

    towardsPlayer.x = 0;

    applyForce(
      towardsPlayer.x,
      towardsPlayer.y
      );

    super.update();

    drawSeeker();
  }

  // ------------------------------------------------

  void drawSeeker() {

    noStroke();

    fill(
      202,
      209,
      250
      );

    rectMode(CORNER);

    rect(
      pos.x,
      pos.y,
      size,
      size
      );
  }

  // ------------------------------------------------

  public String toString() {

    return "c";
  }
}

// ================================================================
// HUGE MONSTER
// ================================================================

class HugeMonster extends SquareMonster {

  void setup() {

    super.setup();

    size *= 2;

    maxSpeed = 10;
  }

  // ------------------------------------------------

  void drawMonster() {

    noStroke();

    fill(
      255,
      80,
      0
      );

    rectMode(CORNER);

    rect(
      pos.x,
      pos.y,
      size,
      size
      );
  }

  // ------------------------------------------------

  int getCollisionDamageToPlayer() {

    return 10;
  }

  // ------------------------------------------------

  public String toString() {

    return "d";
  }
}


















// ================================================================
// CAVE - APDE 0.5.3
// Single-file Processing / Android game
//
// Controls:
//   TOUCH / MOUSE   = fly up
//   SPACE           = fly up
//
// Game:
//   Fly through the cave.
//   Avoid red, green, blue and large monsters.
//   Health decreases on collision.
//   Game restarts by touching after GAME OVER.
// ================================================================

import android.app.Activity;
import android.content.Context;
import android.os.Vibrator;

// ------------------------------------------------
// GLOBALS
// ------------------------------------------------

Tunnel tunnel;
Player player;
MonsterManager monsterManager;

int startGameFrame = 0;
int framesElapsed = 0;
int score = 0;

boolean firstGame = true;
boolean gameOver = false;

boolean playButtonPressed = false;
boolean inputLocked = false;

int bgAlpha = 80;

boolean androidDevice = true;
Activity act;

String lastMessage = "";

String[] gameOverQuotes = {
  "retry",
  "try again",
  "just do it",
  "yes you can",
  "thanks for playing",
  "hello world",
  "you died",
  "game over"
};

// ------------------------------------------------
// SETTINGS
// ------------------------------------------------

void settings() {
  fullScreen();
}

// ------------------------------------------------
// SETUP
// ------------------------------------------------

void setup() {

  if (androidDevice) {
    act = this.getActivity();
    orientation(LANDSCAPE);
  }

  frameRate(30);
  noSmooth();

  restartGame();
}

// ------------------------------------------------
// RESTART
// ------------------------------------------------

void restartGame() {

  tunnel = new Tunnel();
  player = new Player();
  monsterManager = new MonsterManager();

  gameOver = false;
  inputLocked = false;

  score = 0;
  framesElapsed = 0;

  startGameFrame = frameCount;

  background(0);

  lastMessage = "";
}

// ------------------------------------------------
// DRAW
// ------------------------------------------------

void draw() {

  updateInput();

  updateTutorial();

  redrawBackground();

  if (gameOver) {

    drawGameover();

    if (!inputLocked && playButtonPressed) {
      restartGame();
    }

  } else {

    updateGameState();

    drawFramesElapsed();
    drawHealth();

    if (player.isDead()) {

      gameOver = true;

      score = framesElapsed;

      lastMessage = getRandomGameoverMessage();

      lockInput();
    }
  }

  tryUnlockInput();
}

// ------------------------------------------------
// INPUT
// ------------------------------------------------

void updateInput() {

  playButtonPressed = false;

  if (mousePressed) {
    playButtonPressed = true;
  }

  if (keyPressed) {

    if (key == ' ' ||
        keyCode == 32 ||
        key == 'w' ||
        key == 'W' ||
        key == '8') {

      playButtonPressed = true;
    }
  }

  if (player != null) {
    player.input();
  }
}

// ------------------------------------------------
// GAME UPDATE
// ------------------------------------------------

void updateGameState() {

  honorScript();

  player.update();

  tunnel.update();

  collCheckPlayerAgainstWalls();

  tunnel.draw();

  player.draw();

  monsterManager.update();

  framesElapsed = frameCount - startGameFrame;
}

// ------------------------------------------------
// TUTORIAL
// ------------------------------------------------

void updateTutorial() {

  int tutorialDuration = 200;

  if (framesElapsed < tutorialDuration && firstGame) {
    drawTutorial();
  }

  if (framesElapsed > tutorialDuration ||
      playButtonPressed) {

    firstGame = false;
  }
}

// ------------------------------------------------
// OBSTACLE
// ------------------------------------------------

enum Obstacle {
  FLOOR,
  CEILING
}

// ------------------------------------------------
// INPUT LOCK
// ------------------------------------------------

void lockInput() {
  inputLocked = true;
}

void tryUnlockInput() {

  if (!playButtonPressed) {
    inputLocked = false;
  }
}

// ------------------------------------------------
// GAME OVER MESSAGE
// ------------------------------------------------

String getRandomGameoverMessage() {

  int n = (int)random(gameOverQuotes.length);

  return gameOverQuotes[n];
}

// ------------------------------------------------
// BACKGROUND
// ------------------------------------------------

void redrawBackground() {

  noStroke();

  fill(0, bgAlpha);

  rectMode(CORNER);

  rect(0, 0, width, height);

  stroke(0);
}

// ------------------------------------------------
// SCORE
// ------------------------------------------------

void drawFramesElapsed() {

  noStroke();

  fill(0);

  rectMode(CORNER);

  rect(0, 0, 160, 80);

  textSize(40);

  textAlign(LEFT, TOP);

  fill(255);

  text(framesElapsed, 20, 15);
}

// ------------------------------------------------
// FPS
// ------------------------------------------------

void drawFramerate() {

  textSize(10);

  textAlign(LEFT, TOP);

  fill(150);

  text("FPS " + nf(frameRate, 1, 1),
       5,
       height - 20);
}

// ------------------------------------------------
// MONSTER COUNT
// ------------------------------------------------

void drawMonsterCount() {

  textSize(10);

  textAlign(LEFT, TOP);

  fill(150);

  text(
    "MONSTERS " + monsterManager.monsters.size(),
    5,
    height - 35
    );
}

// ------------------------------------------------
// TUTORIAL
// ------------------------------------------------

void drawTutorial() {

  noStroke();

  fill(100, 180);

  rectMode(CORNER);

  rect(
    0,
    height / 3,
    width,
    height / 3
    );

  textAlign(CENTER, CENTER);

  fill(255);

  textSize(50);

  text(
    "TOUCH TO FLY",
    width / 2,
    height / 2 - 30
    );

  textSize(28);

  text(
    "EVADE EVERYTHING",
    width / 2,
    height / 2 + 30
    );
}

// ------------------------------------------------
// GAME OVER
// ------------------------------------------------

void drawGameover() {

  rectMode(CORNER);

  noStroke();

  fill(20, 220);

  rect(
    0,
    0,
    width,
    height
    );

  textAlign(CENTER, CENTER);

  textSize(60);

  fill(255);

  text(
    lastMessage,
    width / 2,
    height / 3
    );

  textSize(35);

  fill(255);

  text(
    "SCORE",
    width / 2,
    height / 2
    );

  textSize(65);

  text(
    score,
    width / 2,
    height / 2 + 70
    );

  textSize(25);

  text(
    "TOUCH TO PLAY AGAIN",
    width / 2,
    height - 70
    );
}

// ------------------------------------------------
// HEALTH
// ------------------------------------------------

void drawHealth() {

  if (player.health <= 0) {
    return;
  }

  float healthWidth =
    (float)width / player.maxHealth;

  noFill();

  strokeWeight(10);

  if (player.health <
      player.maxHealth * 0.25f) {

    stroke(255, 0, 0);

  } else if (player.health <
             player.maxHealth * 0.50f) {

    stroke(255, 255, 0);

  } else {

    stroke(0, 255, 0);
  }

  line(
    5,
    5,
    5 + healthWidth * player.health,
    5
    );

  strokeWeight(1);

  stroke(0);
}

// ------------------------------------------------
// MONSTER SCRIPT
// ------------------------------------------------

void honorScript() {

  if (timeCheck(
    0,
    500,
    50,
    8,
    "a"
    )) {

    monsterManager.addMonster(
      new SquareMonster()
      );
  }

  if (timeCheck(
    500,
    1000,
    22,
    6,
    "b"
    )) {

    monsterManager.addMonster(
      new SinMonster()
      );
  }

  if (timeCheck(
    1000,
    99999,
    17,
    8,
    "b"
    )) {

    monsterManager.addMonster(
      new SinMonster()
      );
  }

  if (timeCheck(
    1500,
    99999,
    35,
    5,
    "c"
    )) {

    monsterManager.addMonster(
      new SeekerMonster()
      );
  }

  if (timeCheck(
    2000,
    99999,
    27,
    5,
    "d"
    )) {

    monsterManager.addMonster(
      new HugeMonster()
      );
  }

  if (timeCheck(
    2470,
    99999,
    18,
    10,
    "b"
    )) {

    monsterManager.addMonster(
      new SinMonster()
      );
  }
}

// ------------------------------------------------
// SCRIPT TIME CHECK
// ------------------------------------------------

boolean timeCheck(
  int start,
  int stop,
  int every,
  int maxOnScreenAtATime,
  String type) {

  if (framesElapsed < start) {
    return false;
  }

  if (framesElapsed >= stop) {
    return false;
  }

  if ((framesElapsed - start) % every != 0) {
    return false;
  }

  if (isMaxMonsters(
    type,
    maxOnScreenAtATime)) {

    return false;
  }

  return true;
}

// ------------------------------------------------
// COUNT MONSTERS
// ------------------------------------------------

boolean isMaxMonsters(
  String type,
  int maxOnScreenAtATime) {

  int count = 0;

  for (Monster m : monsterManager.monsters) {

    if (type.equals(m.toString())) {
      count++;
    }
  }

  return count >= maxOnScreenAtATime;
}

// ------------------------------------------------
// PLAYER / MONSTER COLLISION
// ------------------------------------------------

boolean collCheckMonsterAgainstPlayer(
  PVector playerPos,
  float playerSize,
  PVector monsterPos,
  float monsterSize) {

  float playerLeft =
    playerPos.x - playerSize / 2;

  float playerRight =
    playerPos.x + playerSize / 2;

  float playerTop =
    playerPos.y - playerSize / 2;

  float playerBottom =
    playerPos.y + playerSize / 2;

  float monsterLeft =
    monsterPos.x;

  float monsterRight =
    monsterPos.x + monsterSize;

  float monsterTop =
    monsterPos.y;

  float monsterBottom =
    monsterPos.y + monsterSize;

  boolean xHit =
    playerRight > monsterLeft &&
    playerLeft < monsterRight;

  boolean yHit =
    playerBottom > monsterTop &&
    playerTop < monsterBottom;

  return xHit && yHit;
}

// ------------------------------------------------
// PLAYER / WALL COLLISION
// ------------------------------------------------

void collCheckPlayerAgainstWalls() {

  if (tunnel.isCollision(
    player.pos,
    player.size,
    Obstacle.CEILING)) {

    player.applyForce(0, 10);

    player.applyDamage(10);
  }

  if (tunnel.isCollision(
    player.pos,
    player.size,
    Obstacle.FLOOR)) {

    player.applyForce(0, -10);

    player.applyDamage(10);
  }

  int damage =
    monsterManager.checkCollisions(player);

  if (damage > 0) {
    player.applyDamage(damage);
  }
}

// ================================================================
// TUNNEL
// ================================================================

class Tunnel {

  float TunnelHeight =
    height - height / 2.0f;

  int modelXScale = 10;

  float drawXScale = 10;

  int yscl = 20;

  float flatness = 0.5f;

  int wallColor;

  PVector[] ceiling;

  PShape ceilingShape;
  PShape floorShape;

  Tunnel() {

    int count =
      max(2, width / modelXScale);

    ceiling =
      new PVector[count];

    ceiling[0] =
      generate(0, true);

    for (int x = 1;
         x < ceiling.length;
         x++) {

      ceiling[x] =
        generate(x, false);
    }
  }

  void update() {

    moveTunnel();

    wallColor = color(255);
  }

  void draw() {

    strokeWeight(1);

    PShape t =
      getTunnelShape();

    shape(t, 0, 0);
  }

  // ------------------------------------------------
  // MOVE TUNNEL
  // ------------------------------------------------

  void moveTunnel() {

    for (int x = 0;
         x < ceiling.length - 1;
         x++) {

      ceiling[x].y =
        ceiling[x + 1].y;
    }

    ceiling[ceiling.length - 1] =
      generate(
        ceiling.length - 1,
        false
        );
  }

  // ------------------------------------------------
  // CREATE TUNNEL
  // ------------------------------------------------

  PShape getTunnelShape() {

    PShape group =
      createShape(GROUP);

    ceilingShape =
      getWall(true);

    floorShape =
      getWall(false);

    group.addChild(ceilingShape);
    group.addChild(floorShape);

    return group;
  }

  // ------------------------------------------------
  // COLLISION WITH WALL
  // ------------------------------------------------

  boolean isCollision(
    PVector pos,
    float size,
    Obstacle obstacle) {

    if (ceiling == null) {
      return false;
    }

    int i =
      floor(
        map(
          pos.x,
          0,
          width,
          0,
          ceiling.length - 1
          )
        );

    i =
      constrain(
        i,
        0,
        ceiling.length - 1
        );

    int nextI =
      min(
        ceiling.length - 1,
        i + 1
        );

    float y0 =
      ceiling[i].y;

    float y1 =
      ceiling[nextI].y;

    float topY =
      min(y0, y1);

    float bottomY =
      max(y0, y1) + TunnelHeight;

    if (obstacle == Obstacle.CEILING) {

      if (pos.y - size / 2 <= topY) {
        return true;
      }
    }

    if (obstacle == Obstacle.FLOOR) {

      if (pos.y + size / 2 >= bottomY) {
        return true;
      }
    }

    return false;
  }

  // ------------------------------------------------
  // DRAW WALL
  // ------------------------------------------------

  PShape getWall(boolean top) {

    PShape wall =
      createShape();

    wall.beginShape();

    wall.noFill();

    wall.stroke(wallColor);

    if (top) {

      for (int i = 0;
           i < ceiling.length;
           i++) {

        PVector p =
          ceiling[i];

        wall.vertex(
          p.x * drawXScale,
          p.y
          );
      }

      wall.vertex(
        width + 20,
        ceiling[ceiling.length - 1].y
        );

      wall.vertex(
        width + 20,
        -20
        );

      wall.vertex(
        -20,
        -20
        );

      wall.vertex(
        -20,
        ceiling[0].y
        );

    } else {

      for (int i = 0;
           i < ceiling.length;
           i++) {

        PVector p =
          ceiling[i];

        wall.vertex(
          p.x * drawXScale,
          p.y + TunnelHeight
          );
      }

      wall.vertex(
        width + 20,
        ceiling[ceiling.length - 1].y
        + TunnelHeight
        );

      wall.vertex(
        width + 20,
        height + 20
        );

      wall.vertex(
        -20,
        height + 20
        );

      wall.vertex(
        -20,
        ceiling[0].y
        + TunnelHeight
        );
    }

    wall.endShape();

    return wall;
  }

  // ------------------------------------------------
  // GENERATE CAVE
  // ------------------------------------------------

  PVector generate(
    int x,
    boolean init) {

    PVector c =
      new PVector(x, 100);

    if (init) {

      c.y = 100;

    } else {

      float previous =
        ceiling[x - 1].y;

      if (random(1) > 0.5f) {

        c.y =
          previous + yscl;

      } else {

        c.y =
          previous - yscl;
      }

      if (random(1) > flatness) {

        c.y = previous;
      }
    }

    c.y =
      constrain(
        c.y,
        20,
        height - TunnelHeight - 20
        );

    return c;
  }

  // ------------------------------------------------
  // CAVE TOP
  // ------------------------------------------------

  int getTunnelTop(int x) {

    int i =
      round(
        map(
          x,
          0,
          width,
          0,
          ceiling.length - 1
          )
        );

    i =
      constrain(
        i,
        0,
        ceiling.length - 1
        );

    return (int)ceiling[i].y;
  }

  // ------------------------------------------------
  // CAVE MIDDLE
  // ------------------------------------------------

  int getTunnelMiddle(int x) {

    return (int)(
      getTunnelTop(x)
      + TunnelHeight / 2
      );
  }

  float getTunnelHeight() {

    return TunnelHeight;
  }
}

// ================================================================
// ABSTRACT GAME OBJECT
// ================================================================

abstract class GameObject {

  PVector pos;
  PVector spd;
  PVector acc;

  float maxSpeed;
  float size;
  float grav;

  GameObject() {

    pos =
      new PVector(0, 0);

    spd =
      new PVector(0, 0);

    acc =
      new PVector(0, 0);

    maxSpeed = 10;
    size = 10;
    grav = 0.5f;

    setup();

    update();
  }

  void applyForce(
    float x,
    float y) {

    acc.x += x;
    acc.y += y;
  }

  void applyGravity() {

    applyForce(0, grav);
  }

  void update() {

    applyGravity();

    spd.add(acc);

    spd.limit(maxSpeed);

    pos.add(spd);

    acc.mult(0);
  }

  abstract void setup();
}

// ================================================================
// PLAYER
// ================================================================

class Player extends GameObject {

  float maxHealth = 38;

  float health = maxHealth;

  boolean invulnerability = false;

  int invulnerabilityStartFrame = 0;

  int invulnerabilityDuration = 30;

  // ------------------------------------------------

  void setup() {

    int x =
      width / 6;

    pos =
      new PVector(
        x,
        tunnel.getTunnelMiddle(x)
        );

    maxSpeed = 7;

    size = 35;

    grav = 0.5f;
  }

  // ------------------------------------------------

  void update() {

    super.update();

    updateInvulnerability();

    // prevent extreme speed
    spd.y =
      constrain(
        spd.y,
        -maxSpeed,
        maxSpeed
        );
  }

  // ------------------------------------------------

  void draw() {

    if (invulnerability) {

      strokeWeight(2);

      int dangerRed =
        color(
          155 + 100 *
          sin(framesElapsed * 0.2f),
          0,
          0
          );

      stroke(dangerRed);

      if (playButtonPressed) {
        fill(dangerRed);
      } else {
        fill(0);
      }

    } else {

      if (playButtonPressed) {

        strokeWeight(5);

        stroke(255);

        fill(255);

      } else {

        strokeWeight(3);

        stroke(255);

        fill(0);
      }
    }

    beginShape();

    vertex(
      pos.x,
      pos.y
      );

    vertex(
      pos.x - size / 2,
      pos.y + size / 2
      );

    vertex(
      pos.x - size / 2,
      pos.y - size / 2
      );

    endShape(CLOSE);

    strokeWeight(1);
  }

  // ------------------------------------------------
  // DAMAGE
  // ------------------------------------------------

  void applyDamage(int damage) {

    if (damage <= 0) {
      return;
    }

    if (invulnerability) {
      return;
    }

    invulnerabilityDuration =
      damage * 3;

    invulnerability = true;

    invulnerabilityStartFrame =
      frameCount;

    health -= damage;

    health =
      max(0, health);

    vibrate(damage * 5);
  }

  // ------------------------------------------------
  // VIBRATION
  // ------------------------------------------------

  void vibrate(int milliseconds) {

    if (!androidDevice) {
      return;
    }

    if (act == null) {
      return;
    }

    try {

      Vibrator vibrator =
        (Vibrator)act.getSystemService(
        Context.VIBRATOR_SERVICE
        );

      if (vibrator != null) {

        vibrator.vibrate(
          milliseconds
          );
      }

    } catch(Exception e) {
      // ignore vibration failure
    }
  }

  // ------------------------------------------------
  // INVULNERABILITY
  // ------------------------------------------------

  void updateInvulnerability() {

    if (frameCount >
        invulnerabilityStartFrame
        + invulnerabilityDuration) {

      invulnerability = false;
    }
  }

  // ------------------------------------------------
  // INPUT
  // ------------------------------------------------

  void input() {

    if (!playButtonPressed) {
      return;
    }

    if (spd.y > 0) {
      spd.y = 0;
    }

    applyForce(
      0,
      -1.5f
      );
  }

  // ------------------------------------------------
  // DEAD
  // ------------------------------------------------

  boolean isDead() {

    return health < 1;
  }
}

// ================================================================
// MONSTER MANAGER
// ================================================================

class MonsterManager {

  ArrayList<Monster> monsters =
    new ArrayList<Monster>();

  // ------------------------------------------------

  void update() {

    for (int i = monsters.size() - 1;
         i >= 0;
         i--) {

      Monster m =
        monsters.get(i);

      m.update();

      if (m.isTrespassing() ||
          m.isDead()) {

        monsters.remove(i);
      }
    }
  }

  // ------------------------------------------------

  void addMonster(Monster m) {

    if (m != null) {
      monsters.add(m);
    }
  }

  // ------------------------------------------------

  int checkCollisions(
    Player player) {

    for (Monster m : monsters) {

      if (collCheckMonsterAgainstPlayer(
        player.pos,
        player.size,
        m.pos,
        m.size)) {

        int damage =
          m.getCollisionDamageToPlayer();

        m.onCollision();

        return damage;
      }

      if (tunnel.isCollision(
        m.pos,
        m.size,
        Obstacle.CEILING)) {

        m.onCollision();
      }

      if (tunnel.isCollision(
        m.pos,
        m.size,
        Obstacle.FLOOR)) {

        m.onCollision();
      }
    }

    return 0;
  }
}

// ================================================================
// MONSTER BASE
// ================================================================

abstract class Monster extends GameObject {

  boolean dead = false;

  // ------------------------------------------------

  abstract int getCollisionDamageToPlayer();

  abstract void onCollision();

  // ------------------------------------------------

  boolean isTrespassing() {

    return pos.x < -size * 2;
  }

  // ------------------------------------------------

  boolean isDead() {

    return dead;
  }
}

// ================================================================
// RED SQUARE MONSTER
// ================================================================

class SquareMonster extends Monster {

  void setup() {

    float randomValue =
      noise(
        framesElapsed / 100.0f
        + random(1) / 10.0f
        );

    float tunnelTop =
      tunnel.getTunnelTop(width);

    float tunnelBottom =
      tunnelTop
      + tunnel.TunnelHeight;

    float safeY =
      map(
        randomValue,
        0,
        1,
        tunnelTop + size,
        tunnelBottom - size
        );

    pos =
      new PVector(
        width + size,
        safeY
        );

    spd.x = -4;
  }

  // ------------------------------------------------

  void update() {

    applyForce(
      -10,
      -grav
      );

    super.update();

    drawMonster();
  }

  // ------------------------------------------------

  void drawMonster() {

    noStroke();

    fill(
      255,
      0,
      0
      );

    rectMode(CORNER);

    rect(
      pos.x,
      pos.y,
      size,
      size
      );
  }

  // ------------------------------------------------

  int getCollisionDamageToPlayer() {

    return 5;
  }

  // ------------------------------------------------

  void onCollision() {

    dead = true;
  }

  // ------------------------------------------------

  public String toString() {

    return "a";
  }
}

// ================================================================
// SIN MONSTER
// ================================================================

class SinMonster extends SquareMonster {

  void update() {

    applyForce(
      0,
      map(
        sin(
          radians(frameCount * 2)
          ),
        -1,
        1,
        -1.0f,
        1.0f
        )
      );

    super.update();

    drawSinMonster();
  }

  // ------------------------------------------------

  void drawSinMonster() {

    noStroke();

    fill(
      150,
      255,
      150
      );

    rectMode(CORNER);

    rect(
      pos.x,
      pos.y,
      size,
      size
      );
  }

  // ------------------------------------------------

  public String toString() {

    return "b";
  }
}

// ================================================================
// SEEKER MONSTER
// ================================================================

class SeekerMonster extends SquareMonster {

  void setup() {

    super.setup();

    pos.y =
      tunnel.getTunnelMiddle(width);
  }

  // ------------------------------------------------

  void update() {

    PVector towardsPlayer =
      PVector.sub(
        player.pos,
        pos
        );

    towardsPlayer.mult(0.1f);

    towardsPlayer.x = 0;

    applyForce(
      towardsPlayer.x,
      towardsPlayer.y
      );

    super.update();

    drawSeeker();
  }

  // ------------------------------------------------

  void drawSeeker() {

    noStroke();

    fill(
      202,
      209,
      250
      );

    rectMode(CORNER);

    rect(
      pos.x,
      pos.y,
      size,
      size
      );
  }

  // ------------------------------------------------

  public String toString() {

    return "c";
  }
}

// ================================================================
// HUGE MONSTER
// ================================================================

class HugeMonster extends SquareMonster {

  void setup() {

    super.setup();

    size *= 2;

    maxSpeed = 10;
  }

  // ------------------------------------------------

  void drawMonster() {

    noStroke();

    fill(
      255,
      80,
      0
      );

    rectMode(CORNER);

    rect(
      pos.x,
      pos.y,
      size,
      size
      );
  }

  // ------------------------------------------------

  int getCollisionDamageToPlayer() {

    return 10;
  }

  // ------------------------------------------------

  public String toString() {

    return "d";
  }
}











// ================================================================
// CAVE - APDE 0.5.3
// Single-file Processing / Android game
//
// Controls:
//   TOUCH / MOUSE   = fly up
//   SPACE           = fly up
//
// Game:
//   Fly through the cave.
//   Avoid red, green, blue and large monsters.
//   Health decreases on collision.
//   Game restarts by touching after GAME OVER.
// ================================================================

import android.app.Activity;
import android.content.Context;
import android.os.Vibrator;

// ------------------------------------------------
// GLOBALS
// ------------------------------------------------

Tunnel tunnel;
Player player;
MonsterManager monsterManager;

int startGameFrame = 0;
int framesElapsed = 0;
int score = 0;

boolean firstGame = true;
boolean gameOver = false;

boolean playButtonPressed = false;
boolean inputLocked = false;

int bgAlpha = 80;

boolean androidDevice = true;
Activity act;

String lastMessage = "";

String[] gameOverQuotes = {
  "retry",
  "try again",
  "just do it",
  "yes you can",
  "thanks for playing",
  "hello world",
  "you died",
  "game over"
};

// ------------------------------------------------
// SETTINGS
// ------------------------------------------------

void settings() {
  fullScreen();
}

// ------------------------------------------------
// SETUP
// ------------------------------------------------

void setup() {

  if (androidDevice) {
    act = this.getActivity();
    orientation(LANDSCAPE);
  }

  frameRate(30);
  noSmooth();

  restartGame();
}

// ------------------------------------------------
// RESTART
// ------------------------------------------------

void restartGame() {

  tunnel = new Tunnel();
  player = new Player();
  monsterManager = new MonsterManager();

  gameOver = false;
  inputLocked = false;

  score = 0;
  framesElapsed = 0;

  startGameFrame = frameCount;

  background(0);

  lastMessage = "";
}

// ------------------------------------------------
// DRAW
// ------------------------------------------------

void draw() {

  updateInput();

  updateTutorial();

  redrawBackground();

  if (gameOver) {

    drawGameover();

    if (!inputLocked && playButtonPressed) {
      restartGame();
    }

  } else {

    updateGameState();

    drawFramesElapsed();
    drawHealth();

    if (player.isDead()) {

      gameOver = true;

      score = framesElapsed;

      lastMessage = getRandomGameoverMessage();

      lockInput();
    }
  }

  tryUnlockInput();
}

// ------------------------------------------------
// INPUT
// ------------------------------------------------

void updateInput() {

  playButtonPressed = false;

  if (mousePressed) {
    playButtonPressed = true;
  }

  if (keyPressed) {

    if (key == ' ' ||
        keyCode == 32 ||
        key == 'w' ||
        key == 'W' ||
        key == '8') {

      playButtonPressed = true;
    }
  }

  if (player != null) {
    player.input();
  }
}

// ------------------------------------------------
// GAME UPDATE
// ------------------------------------------------

void updateGameState() {

  honorScript();

  player.update();

  tunnel.update();

  collCheckPlayerAgainstWalls();

  tunnel.draw();

  player.draw();

  monsterManager.update();

  framesElapsed = frameCount - startGameFrame;
}

// ------------------------------------------------
// TUTORIAL
// ------------------------------------------------

void updateTutorial() {

  int tutorialDuration = 200;

  if (framesElapsed < tutorialDuration && firstGame) {
    drawTutorial();
  }

  if (framesElapsed > tutorialDuration ||
      playButtonPressed) {

    firstGame = false;
  }
}

// ------------------------------------------------
// OBSTACLE
// ------------------------------------------------

enum Obstacle {
  FLOOR,
  CEILING
}

// ------------------------------------------------
// INPUT LOCK
// ------------------------------------------------

void lockInput() {
  inputLocked = true;
}

void tryUnlockInput() {

  if (!playButtonPressed) {
    inputLocked = false;
  }
}

// ------------------------------------------------
// GAME OVER MESSAGE
// ------------------------------------------------

String getRandomGameoverMessage() {

  int n = (int)random(gameOverQuotes.length);

  return gameOverQuotes[n];
}

// ------------------------------------------------
// BACKGROUND
// ------------------------------------------------

void redrawBackground() {

  noStroke();

  fill(0, bgAlpha);

  rectMode(CORNER);

  rect(0, 0, width, height);

  stroke(0);
}

// ------------------------------------------------
// SCORE
// ------------------------------------------------

void drawFramesElapsed() {

  noStroke();

  fill(0);

  rectMode(CORNER);

  rect(0, 0, 160, 80);

  textSize(40);

  textAlign(LEFT, TOP);

  fill(255);

  text(framesElapsed, 20, 15);
}

// ------------------------------------------------
// FPS
// ------------------------------------------------

void drawFramerate() {

  textSize(10);

  textAlign(LEFT, TOP);

  fill(150);

  text("FPS " + nf(frameRate, 1, 1),
       5,
       height - 20);
}

// ------------------------------------------------
// MONSTER COUNT
// ------------------------------------------------

void drawMonsterCount() {

  textSize(10);

  textAlign(LEFT, TOP);

  fill(150);

  text(
    "MONSTERS " + monsterManager.monsters.size(),
    5,
    height - 35
    );
}

// ------------------------------------------------
// TUTORIAL
// ------------------------------------------------

void drawTutorial() {

  noStroke();

  fill(100, 180);

  rectMode(CORNER);

  rect(
    0,
    height / 3,
    width,
    height / 3
    );

  textAlign(CENTER, CENTER);

  fill(255);

  textSize(50);

  text(
    "TOUCH TO FLY",
    width / 2,
    height / 2 - 30
    );

  textSize(28);

  text(
    "EVADE EVERYTHING",
    width / 2,
    height / 2 + 30
    );
}

// ------------------------------------------------
// GAME OVER
// ------------------------------------------------

void drawGameover() {

  rectMode(CORNER);

  noStroke();

  fill(20, 220);

  rect(
    0,
    0,
    width,
    height
    );

  textAlign(CENTER, CENTER);

  textSize(60);

  fill(255);

  text(
    lastMessage,
    width / 2,
    height / 3
    );

  textSize(35);

  fill(255);

  text(
    "SCORE",
    width / 2,
    height / 2
    );

  textSize(65);

  text(
    score,
    width / 2,
    height / 2 + 70
    );

  textSize(25);

  text(
    "TOUCH TO PLAY AGAIN",
    width / 2,
    height - 70
    );
}

// ------------------------------------------------
// HEALTH
// ------------------------------------------------

void drawHealth() {

  if (player.health <= 0) {
    return;
  }

  float healthWidth =
    (float)width / player.maxHealth;

  noFill();

  strokeWeight(10);

  if (player.health <
      player.maxHealth * 0.25f) {

    stroke(255, 0, 0);

  } else if (player.health <
             player.maxHealth * 0.50f) {

    stroke(255, 255, 0);

  } else {

    stroke(0, 255, 0);
  }

  line(
    5,
    5,
    5 + healthWidth * player.health,
    5
    );

  strokeWeight(1);

  stroke(0);
}

// ------------------------------------------------
// MONSTER SCRIPT
// ------------------------------------------------

void honorScript() {

  if (timeCheck(
    0,
    500,
    50,
    8,
    "a"
    )) {

    monsterManager.addMonster(
      new SquareMonster()
      );
  }

  if (timeCheck(
    500,
    1000,
    22,
    6,
    "b"
    )) {

    monsterManager.addMonster(
      new SinMonster()
      );
  }

  if (timeCheck(
    1000,
    99999,
    17,
    8,
    "b"
    )) {

    monsterManager.addMonster(
      new SinMonster()
      );
  }

  if (timeCheck(
    1500,
    99999,
    35,
    5,
    "c"
    )) {

    monsterManager.addMonster(
      new SeekerMonster()
      );
  }

  if (timeCheck(
    2000,
    99999,
    27,
    5,
    "d"
    )) {

    monsterManager.addMonster(
      new HugeMonster()
      );
  }

  if (timeCheck(
    2470,
    99999,
    18,
    10,
    "b"
    )) {

    monsterManager.addMonster(
      new SinMonster()
      );
  }
}

// ------------------------------------------------
// SCRIPT TIME CHECK
// ------------------------------------------------

boolean timeCheck(
  int start,
  int stop,
  int every,
  int maxOnScreenAtATime,
  String type) {

  if (framesElapsed < start) {
    return false;
  }

  if (framesElapsed >= stop) {
    return false;
  }

  if ((framesElapsed - start) % every != 0) {
    return false;
  }

  if (isMaxMonsters(
    type,
    maxOnScreenAtATime)) {

    return false;
  }

  return true;
}

// ------------------------------------------------
// COUNT MONSTERS
// ------------------------------------------------

boolean isMaxMonsters(
  String type,
  int maxOnScreenAtATime) {

  int count = 0;

  for (Monster m : monsterManager.monsters) {

    if (type.equals(m.toString())) {
      count++;
    }
  }

  return count >= maxOnScreenAtATime;
}

// ------------------------------------------------
// PLAYER / MONSTER COLLISION
// ------------------------------------------------

boolean collCheckMonsterAgainstPlayer(
  PVector playerPos,
  float playerSize,
  PVector monsterPos,
  float monsterSize) {

  float playerLeft =
    playerPos.x - playerSize / 2;

  float playerRight =
    playerPos.x + playerSize / 2;

  float playerTop =
    playerPos.y - playerSize / 2;

  float playerBottom =
    playerPos.y + playerSize / 2;

  float monsterLeft =
    monsterPos.x;

  float monsterRight =
    monsterPos.x + monsterSize;

  float monsterTop =
    monsterPos.y;

  float monsterBottom =
    monsterPos.y + monsterSize;

  boolean xHit =
    playerRight > monsterLeft &&
    playerLeft < monsterRight;

  boolean yHit =
    playerBottom > monsterTop &&
    playerTop < monsterBottom;

  return xHit && yHit;
}

// ------------------------------------------------
// PLAYER / WALL COLLISION
// ------------------------------------------------

void collCheckPlayerAgainstWalls() {

  if (tunnel.isCollision(
    player.pos,
    player.size,
    Obstacle.CEILING)) {

    player.applyForce(0, 10);

    player.applyDamage(10);
  }

  if (tunnel.isCollision(
    player.pos,
    player.size,
    Obstacle.FLOOR)) {

    player.applyForce(0, -10);

    player.applyDamage(10);
  }

  int damage =
    monsterManager.checkCollisions(player);

  if (damage > 0) {
    player.applyDamage(damage);
  }
}

// ================================================================
// TUNNEL
// ================================================================

class Tunnel {

  float TunnelHeight =
    height - height / 2.0f;

  int modelXScale = 10;

  float drawXScale = 10;

  int yscl = 20;

  float flatness = 0.5f;

  int wallColor;

  PVector[] ceiling;

  PShape ceilingShape;
  PShape floorShape;

  Tunnel() {

    int count =
      max(2, width / modelXScale);

    ceiling =
      new PVector[count];

    ceiling[0] =
      generate(0, true);

    for (int x = 1;
         x < ceiling.length;
         x++) {

      ceiling[x] =
        generate(x, false);
    }
  }

  void update() {

    moveTunnel();

    wallColor = color(255);
  }

  void draw() {

    strokeWeight(1);

    PShape t =
      getTunnelShape();

    shape(t, 0, 0);
  }

  // ------------------------------------------------
  // MOVE TUNNEL
  // ------------------------------------------------

  void moveTunnel() {

    for (int x = 0;
         x < ceiling.length - 1;
         x++) {

      ceiling[x].y =
        ceiling[x + 1].y;
    }

    ceiling[ceiling.length - 1] =
      generate(
        ceiling.length - 1,
        false
        );
  }

  // ------------------------------------------------
  // CREATE TUNNEL
  // ------------------------------------------------

  PShape getTunnelShape() {

    PShape group =
      createShape(GROUP);

    ceilingShape =
      getWall(true);

    floorShape =
      getWall(false);

    group.addChild(ceilingShape);
    group.addChild(floorShape);

    return group;
  }

  // ------------------------------------------------
  // COLLISION WITH WALL
  // ------------------------------------------------

  boolean isCollision(
    PVector pos,
    float size,
    Obstacle obstacle) {

    if (ceiling == null) {
      return false;
    }

    int i =
      floor(
        map(
          pos.x,
          0,
          width,
          0,
          ceiling.length - 1
          )
        );

    i =
      constrain(
        i,
        0,
        ceiling.length - 1
        );

    int nextI =
      min(
        ceiling.length - 1,
        i + 1
        );

    float y0 =
      ceiling[i].y;

    float y1 =
      ceiling[nextI].y;

    float topY =
      min(y0, y1);

    float bottomY =
      max(y0, y1) + TunnelHeight;

    if (obstacle == Obstacle.CEILING) {

      if (pos.y - size / 2 <= topY) {
        return true;
      }
    }

    if (obstacle == Obstacle.FLOOR) {

      if (pos.y + size / 2 >= bottomY) {
        return true;
      }
    }

    return false;
  }

  // ------------------------------------------------
  // DRAW WALL
  // ------------------------------------------------

  PShape getWall(boolean top) {

    PShape wall =
      createShape();

    wall.beginShape();

    wall.noFill();

    wall.stroke(wallColor);

    if (top) {

      for (int i = 0;
           i < ceiling.length;
           i++) {

        PVector p =
          ceiling[i];

        wall.vertex(
          p.x * drawXScale,
          p.y
          );
      }

      wall.vertex(
        width + 20,
        ceiling[ceiling.length - 1].y
        );

      wall.vertex(
        width + 20,
        -20
        );

      wall.vertex(
        -20,
        -20
        );

      wall.vertex(
        -20,
        ceiling[0].y
        );

    } else {

      for (int i = 0;
           i < ceiling.length;
           i++) {

        PVector p =
          ceiling[i];

        wall.vertex(
          p.x * drawXScale,
          p.y + TunnelHeight
          );
      }

      wall.vertex(
        width + 20,
        ceiling[ceiling.length - 1].y
        + TunnelHeight
        );

      wall.vertex(
        width + 20,
        height + 20
        );

      wall.vertex(
        -20,
        height + 20
        );

      wall.vertex(
        -20,
        ceiling[0].y
        + TunnelHeight
        );
    }

    wall.endShape();

    return wall;
  }

  // ------------------------------------------------
  // GENERATE CAVE
  // ------------------------------------------------

  PVector generate(
    int x,
    boolean init) {

    PVector c =
      new PVector(x, 100);

    if (init) {

      c.y = 100;

    } else {

      float previous =
        ceiling[x - 1].y;

      if (random(1) > 0.5f) {

        c.y =
          previous + yscl;

      } else {

        c.y =
          previous - yscl;
      }

      if (random(1) > flatness) {

        c.y = previous;
      }
    }

    c.y =
      constrain(
        c.y,
        20,
        height - TunnelHeight - 20
        );

    return c;
  }

  // ------------------------------------------------
  // CAVE TOP
  // ------------------------------------------------

  int getTunnelTop(int x) {

    int i =
      round(
        map(
          x,
          0,
          width,
          0,
          ceiling.length - 1
          )
        );

    i =
      constrain(
        i,
        0,
        ceiling.length - 1
        );

    return (int)ceiling[i].y;
  }

  // ------------------------------------------------
  // CAVE MIDDLE
  // ------------------------------------------------

  int getTunnelMiddle(int x) {

    return (int)(
      getTunnelTop(x)
      + TunnelHeight / 2
      );
  }

  float getTunnelHeight() {

    return TunnelHeight;
  }
}

// ================================================================
// ABSTRACT GAME OBJECT
// ================================================================

abstract class GameObject {

  PVector pos;
  PVector spd;
  PVector acc;

  float maxSpeed;
  float size;
  float grav;

  GameObject() {

    pos =
      new PVector(0, 0);

    spd =
      new PVector(0, 0);

    acc =
      new PVector(0, 0);

    maxSpeed = 10;
    size = 10;
    grav = 0.5f;

    setup();

    update();
  }

  void applyForce(
    float x,
    float y) {

    acc.x += x;
    acc.y += y;
  }

  void applyGravity() {

    applyForce(0, grav);
  }

  void update() {

    applyGravity();

    spd.add(acc);

    spd.limit(maxSpeed);

    pos.add(spd);

    acc.mult(0);
  }

  abstract void setup();
}

// ================================================================
// PLAYER
// ================================================================

class Player extends GameObject {

  float maxHealth = 38;

  float health = maxHealth;

  boolean invulnerability = false;

  int invulnerabilityStartFrame = 0;

  int invulnerabilityDuration = 30;

  // ------------------------------------------------

  void setup() {

    int x =
      width / 6;

    pos =
      new PVector(
        x,
        tunnel.getTunnelMiddle(x)
        );

    maxSpeed = 7;

    size = 35;

    grav = 0.5f;
  }

  // ------------------------------------------------

  void update() {

    super.update();

    updateInvulnerability();

    // prevent extreme speed
    spd.y =
      constrain(
        spd.y,
        -maxSpeed,
        maxSpeed
        );
  }

  // ------------------------------------------------

  void draw() {

    if (invulnerability) {

      strokeWeight(2);

      int dangerRed =
        color(
          155 + 100 *
          sin(framesElapsed * 0.2f),
          0,
          0
          );

      stroke(dangerRed);

      if (playButtonPressed) {
        fill(dangerRed);
      } else {
        fill(0);
      }

    } else {

      if (playButtonPressed) {

        strokeWeight(5);

        stroke(255);

        fill(255);

      } else {

        strokeWeight(3);

        stroke(255);

        fill(0);
      }
    }

    beginShape();

    vertex(
      pos.x,
      pos.y
      );

    vertex(
      pos.x - size / 2,
      pos.y + size / 2
      );

    vertex(
      pos.x - size / 2,
      pos.y - size / 2
      );

    endShape(CLOSE);

    strokeWeight(1);
  }

  // ------------------------------------------------
  // DAMAGE
  // ------------------------------------------------

  void applyDamage(int damage) {

    if (damage <= 0) {
      return;
    }

    if (invulnerability) {
      return;
    }

    invulnerabilityDuration =
      damage * 3;

    invulnerability = true;

    invulnerabilityStartFrame =
      frameCount;

    health -= damage;

    health =
      max(0, health);

    vibrate(damage * 5);
  }

  // ------------------------------------------------
  // VIBRATION
  // ------------------------------------------------

  void vibrate(int milliseconds) {

    if (!androidDevice) {
      return;
    }

    if (act == null) {
      return;
    }

    try {

      Vibrator vibrator =
        (Vibrator)act.getSystemService(
        Context.VIBRATOR_SERVICE
        );

      if (vibrator != null) {

        vibrator.vibrate(
          milliseconds
          );
      }

    } catch(Exception e) {
      // ignore vibration failure
    }
  }

  // ------------------------------------------------
  // INVULNERABILITY
  // ------------------------------------------------

  void updateInvulnerability() {

    if (frameCount >
        invulnerabilityStartFrame
        + invulnerabilityDuration) {

      invulnerability = false;
    }
  }

  // ------------------------------------------------
  // INPUT
  // ------------------------------------------------

  void input() {

    if (!playButtonPressed) {
      return;
    }

    if (spd.y > 0) {
      spd.y = 0;
    }

    applyForce(
      0,
      -1.5f
      );
  }

  // ------------------------------------------------
  // DEAD
  // ------------------------------------------------

  boolean isDead() {

    return health < 1;
  }
}

// ================================================================
// MONSTER MANAGER
// ================================================================

class MonsterManager {

  ArrayList<Monster> monsters =
    new ArrayList<Monster>();

  // ------------------------------------------------

  void update() {

    for (int i = monsters.size() - 1;
         i >= 0;
         i--) {

      Monster m =
        monsters.get(i);

      m.update();

      if (m.isTrespassing() ||
          m.isDead()) {

        monsters.remove(i);
      }
    }
  }

  // ------------------------------------------------

  void addMonster(Monster m) {

    if (m != null) {
      monsters.add(m);
    }
  }

  // ------------------------------------------------

  int checkCollisions(
    Player player) {

    for (Monster m : monsters) {

      if (collCheckMonsterAgainstPlayer(
        player.pos,
        player.size,
        m.pos,
        m.size)) {

        int damage =
          m.getCollisionDamageToPlayer();

        m.onCollision();

        return damage;
      }

      if (tunnel.isCollision(
        m.pos,
        m.size,
        Obstacle.CEILING)) {

        m.onCollision();
      }

      if (tunnel.isCollision(
        m.pos,
        m.size,
        Obstacle.FLOOR)) {

        m.onCollision();
      }
    }

    return 0;
  }
}

// ================================================================
// MONSTER BASE
// ================================================================

abstract class Monster extends GameObject {

  boolean dead = false;

  // ------------------------------------------------

  abstract int getCollisionDamageToPlayer();

  abstract void onCollision();

  // ------------------------------------------------

  boolean isTrespassing() {

    return pos.x < -size * 2;
  }

  // ------------------------------------------------

  boolean isDead() {

    return dead;
  }
}

// ================================================================
// RED SQUARE MONSTER
// ================================================================

class SquareMonster extends Monster {

  void setup() {

    float randomValue =
      noise(
        framesElapsed / 100.0f
        + random(1) / 10.0f
        );

    float tunnelTop =
      tunnel.getTunnelTop(width);

    float tunnelBottom =
      tunnelTop
      + tunnel.TunnelHeight;

    float safeY =
      map(
        randomValue,
        0,
        1,
        tunnelTop + size,
        tunnelBottom - size
        );

    pos =
      new PVector(
        width + size,
        safeY
        );

    spd.x = -4;
  }

  // ------------------------------------------------

  void update() {

    applyForce(
      -10,
      -grav
      );

    super.update();

    drawMonster();
  }

  // ------------------------------------------------

  void drawMonster() {

    noStroke();

    fill(
      255,
      0,
      0
      );

    rectMode(CORNER);

    rect(
      pos.x,
      pos.y,
      size,
      size
      );
  }

  // ------------------------------------------------

  int getCollisionDamageToPlayer() {

    return 5;
  }

  // ------------------------------------------------

  void onCollision() {

    dead = true;
  }

  // ------------------------------------------------

  public String toString() {

    return "a";
  }
}

// ================================================================
// SIN MONSTER
// ================================================================

class SinMonster extends SquareMonster {

  void update() {

    applyForce(
      0,
      map(
        sin(
          radians(frameCount * 2)
          ),
        -1,
        1,
        -1.0f,
        1.0f
        )
      );

    super.update();

    drawSinMonster();
  }

  // ------------------------------------------------

  void drawSinMonster() {

    noStroke();

    fill(
      150,
      255,
      150
      );

    rectMode(CORNER);

    rect(
      pos.x,
      pos.y,
      size,
      size
      );
  }

  // ------------------------------------------------

  public String toString() {

    return "b";
  }
}

// ================================================================
// SEEKER MONSTER
// ================================================================

class SeekerMonster extends SquareMonster {

  void setup() {

    super.setup();

    pos.y =
      tunnel.getTunnelMiddle(width);
  }

  // ------------------------------------------------

  void update() {

    PVector towardsPlayer =
      PVector.sub(
        player.pos,
        pos
        );

    towardsPlayer.mult(0.1f);

    towardsPlayer.x = 0;

    applyForce(
      towardsPlayer.x,
      towardsPlayer.y
      );

    super.update();

    drawSeeker();
  }

  // ------------------------------------------------

  void drawSeeker() {

    noStroke();

    fill(
      202,
      209,
      250
      );

    rectMode(CORNER);

    rect(
      pos.x,
      pos.y,
      size,
      size
      );
  }

  // ------------------------------------------------

  public String toString() {

    return "c";
  }
}

// ================================================================
// HUGE MONSTER
// ================================================================

class HugeMonster extends SquareMonster {

  void setup() {

    super.setup();

    size *= 2;

    maxSpeed = 10;
  }

  // ------------------------------------------------

  void drawMonster() {

    noStroke();

    fill(
      255,
      80,
      0
      );

    rectMode(CORNER);

    rect(
      pos.x,
      pos.y,
      size,
      size
      );
  }

  // ------------------------------------------------

  int getCollisionDamageToPlayer() {

    return 10;
  }

  // ------------------------------------------------

  public String toString() {

    return "d";
  }
}









// ================================================================
// CAVE - APDE 0.5.3
// Single-file Processing / Android game
//
// Controls:
//   TOUCH / MOUSE   = fly up
//   SPACE           = fly up
//
// Game:
//   Fly through the cave.
//   Avoid red, green, blue and large monsters.
//   Health decreases on collision.
//   Game restarts by touching after GAME OVER.
// ================================================================

import android.app.Activity;
import android.content.Context;
import android.os.Vibrator;

// ------------------------------------------------
// GLOBALS
// ------------------------------------------------

Tunnel tunnel;
Player player;
MonsterManager monsterManager;

int startGameFrame = 0;
int framesElapsed = 0;
int score = 0;

boolean firstGame = true;
boolean gameOver = false;

boolean playButtonPressed = false;
boolean inputLocked = false;

int bgAlpha = 80;

boolean androidDevice = true;
Activity act;

String lastMessage = "";

String[] gameOverQuotes = {
  "retry",
  "try again",
  "just do it",
  "yes you can",
  "thanks for playing",
  "hello world",
  "you died",
  "game over"
};

// ------------------------------------------------
// SETTINGS
// ------------------------------------------------

void settings() {
  fullScreen();
}

// ------------------------------------------------
// SETUP
// ------------------------------------------------

void setup() {

  if (androidDevice) {
    act = this.getActivity();
    orientation(LANDSCAPE);
  }

  frameRate(30);
  noSmooth();

  restartGame();
}

// ------------------------------------------------
// RESTART
// ------------------------------------------------

void restartGame() {

  tunnel = new Tunnel();
  player = new Player();
  monsterManager = new MonsterManager();

  gameOver = false;
  inputLocked = false;

  score = 0;
  framesElapsed = 0;

  startGameFrame = frameCount;

  background(0);

  lastMessage = "";
}

// ------------------------------------------------
// DRAW
// ------------------------------------------------

void draw() {

  updateInput();

  updateTutorial();

  redrawBackground();

  if (gameOver) {

    drawGameover();

    if (!inputLocked && playButtonPressed) {
      restartGame();
    }

  } else {

    updateGameState();

    drawFramesElapsed();
    drawHealth();

    if (player.isDead()) {

      gameOver = true;

      score = framesElapsed;

      lastMessage = getRandomGameoverMessage();

      lockInput();
    }
  }

  tryUnlockInput();
}

// ------------------------------------------------
// INPUT
// ------------------------------------------------

void updateInput() {

  playButtonPressed = false;

  if (mousePressed) {
    playButtonPressed = true;
  }

  if (keyPressed) {

    if (key == ' ' ||
        keyCode == 32 ||
        key == 'w' ||
        key == 'W' ||
        key == '8') {

      playButtonPressed = true;
    }
  }

  if (player != null) {
    player.input();
  }
}

// ------------------------------------------------
// GAME UPDATE
// ------------------------------------------------

void updateGameState() {

  honorScript();

  player.update();

  tunnel.update();

  collCheckPlayerAgainstWalls();

  tunnel.draw();

  player.draw();

  monsterManager.update();

  framesElapsed = frameCount - startGameFrame;
}

// ------------------------------------------------
// TUTORIAL
// ------------------------------------------------

void updateTutorial() {

  int tutorialDuration = 200;

  if (framesElapsed < tutorialDuration && firstGame) {
    drawTutorial();
  }

  if (framesElapsed > tutorialDuration ||
      playButtonPressed) {

    firstGame = false;
  }
}

// ------------------------------------------------
// OBSTACLE
// ------------------------------------------------

enum Obstacle {
  FLOOR,
  CEILING
}

// ------------------------------------------------
// INPUT LOCK
// ------------------------------------------------

void lockInput() {
  inputLocked = true;
}

void tryUnlockInput() {

  if (!playButtonPressed) {
    inputLocked = false;
  }
}

// ------------------------------------------------
// GAME OVER MESSAGE
// ------------------------------------------------

String getRandomGameoverMessage() {

  int n = (int)random(gameOverQuotes.length);

  return gameOverQuotes[n];
}

// ------------------------------------------------
// BACKGROUND
// ------------------------------------------------

void redrawBackground() {

  noStroke();

  fill(0, bgAlpha);

  rectMode(CORNER);

  rect(0, 0, width, height);

  stroke(0);
}

// ------------------------------------------------
// SCORE
// ------------------------------------------------

void drawFramesElapsed() {

  noStroke();

  fill(0);

  rectMode(CORNER);

  rect(0, 0, 160, 80);

  textSize(40);

  textAlign(LEFT, TOP);

  fill(255);

  text(framesElapsed, 20, 15);
}

// ------------------------------------------------
// FPS
// ------------------------------------------------

void drawFramerate() {

  textSize(10);

  textAlign(LEFT, TOP);

  fill(150);

  text("FPS " + nf(frameRate, 1, 1),
       5,
       height - 20);
}

// ------------------------------------------------
// MONSTER COUNT
// ------------------------------------------------

void drawMonsterCount() {

  textSize(10);

  textAlign(LEFT, TOP);

  fill(150);

  text(
    "MONSTERS " + monsterManager.monsters.size(),
    5,
    height - 35
    );
}

// ------------------------------------------------
// TUTORIAL
// ------------------------------------------------

void drawTutorial() {

  noStroke();

  fill(100, 180);

  rectMode(CORNER);

  rect(
    0,
    height / 3,
    width,
    height / 3
    );

  textAlign(CENTER, CENTER);

  fill(255);

  textSize(50);

  text(
    "TOUCH TO FLY",
    width / 2,
    height / 2 - 30
    );

  textSize(28);

  text(
    "EVADE EVERYTHING",
    width / 2,
    height / 2 + 30
    );
}

// ------------------------------------------------
// GAME OVER
// ------------------------------------------------

void drawGameover() {

  rectMode(CORNER);

  noStroke();

  fill(20, 220);

  rect(
    0,
    0,
    width,
    height
    );

  textAlign(CENTER, CENTER);

  textSize(60);

  fill(255);

  text(
    lastMessage,
    width / 2,
    height / 3
    );

  textSize(35);

  fill(255);

  text(
    "SCORE",
    width / 2,
    height / 2
    );

  textSize(65);

  text(
    score,
    width / 2,
    height / 2 + 70
    );

  textSize(25);

  text(
    "TOUCH TO PLAY AGAIN",
    width / 2,
    height - 70
    );
}

// ------------------------------------------------
// HEALTH
// ------------------------------------------------

void drawHealth() {

  if (player.health <= 0) {
    return;
  }

  float healthWidth =
    (float)width / player.maxHealth;

  noFill();

  strokeWeight(10);

  if (player.health <
      player.maxHealth * 0.25f) {

    stroke(255, 0, 0);

  } else if (player.health <
             player.maxHealth * 0.50f) {

    stroke(255, 255, 0);

  } else {

    stroke(0, 255, 0);
  }

  line(
    5,
    5,
    5 + healthWidth * player.health,
    5
    );

  strokeWeight(1);

  stroke(0);
}

// ------------------------------------------------
// MONSTER SCRIPT
// ------------------------------------------------

void honorScript() {

  if (timeCheck(
    0,
    500,
    50,
    8,
    "a"
    )) {

    monsterManager.addMonster(
      new SquareMonster()
      );
  }

  if (timeCheck(
    500,
    1000,
    22,
    6,
    "b"
    )) {

    monsterManager.addMonster(
      new SinMonster()
      );
  }

  if (timeCheck(
    1000,
    99999,
    17,
    8,
    "b"
    )) {

    monsterManager.addMonster(
      new SinMonster()
      );
  }

  if (timeCheck(
    1500,
    99999,
    35,
    5,
    "c"
    )) {

    monsterManager.addMonster(
      new SeekerMonster()
      );
  }

  if (timeCheck(
    2000,
    99999,
    27,
    5,
    "d"
    )) {

    monsterManager.addMonster(
      new HugeMonster()
      );
  }

  if (timeCheck(
    2470,
    99999,
    18,
    10,
    "b"
    )) {

    monsterManager.addMonster(
      new SinMonster()
      );
  }
}

// ------------------------------------------------
// SCRIPT TIME CHECK
// ------------------------------------------------

boolean timeCheck(
  int start,
  int stop,
  int every,
  int maxOnScreenAtATime,
  String type) {

  if (framesElapsed < start) {
    return false;
  }

  if (framesElapsed >= stop) {
    return false;
  }

  if ((framesElapsed - start) % every != 0) {
    return false;
  }

  if (isMaxMonsters(
    type,
    maxOnScreenAtATime)) {

    return false;
  }

  return true;
}

// ------------------------------------------------
// COUNT MONSTERS
// ------------------------------------------------

boolean isMaxMonsters(
  String type,
  int maxOnScreenAtATime) {

  int count = 0;

  for (Monster m : monsterManager.monsters) {

    if (type.equals(m.toString())) {
      count++;
    }
  }

  return count >= maxOnScreenAtATime;
}

// ------------------------------------------------
// PLAYER / MONSTER COLLISION
// ------------------------------------------------

boolean collCheckMonsterAgainstPlayer(
  PVector playerPos,
  float playerSize,
  PVector monsterPos,
  float monsterSize) {

  float playerLeft =
    playerPos.x - playerSize / 2;

  float playerRight =
    playerPos.x + playerSize / 2;

  float playerTop =
    playerPos.y - playerSize / 2;

  float playerBottom =
    playerPos.y + playerSize / 2;

  float monsterLeft =
    monsterPos.x;

  float monsterRight =
    monsterPos.x + monsterSize;

  float monsterTop =
    monsterPos.y;

  float monsterBottom =
    monsterPos.y + monsterSize;

  boolean xHit =
    playerRight > monsterLeft &&
    playerLeft < monsterRight;

  boolean yHit =
    playerBottom > monsterTop &&
    playerTop < monsterBottom;

  return xHit && yHit;
}

// ------------------------------------------------
// PLAYER / WALL COLLISION
// ------------------------------------------------

void collCheckPlayerAgainstWalls() {

  if (tunnel.isCollision(
    player.pos,
    player.size,
    Obstacle.CEILING)) {

    player.applyForce(0, 10);

    player.applyDamage(10);
  }

  if (tunnel.isCollision(
    player.pos,
    player.size,
    Obstacle.FLOOR)) {

    player.applyForce(0, -10);

    player.applyDamage(10);
  }

  int damage =
    monsterManager.checkCollisions(player);

  if (damage > 0) {
    player.applyDamage(damage);
  }
}

// ================================================================
// TUNNEL
// ================================================================

class Tunnel {

  float TunnelHeight =
    height - height / 2.0f;

  int modelXScale = 10;

  float drawXScale = 10;

  int yscl = 20;

  float flatness = 0.5f;

  int wallColor;

  PVector[] ceiling;

  PShape ceilingShape;
  PShape floorShape;

  Tunnel() {

    int count =
      max(2, width / modelXScale);

    ceiling =
      new PVector[count];

    ceiling[0] =
      generate(0, true);

    for (int x = 1;
         x < ceiling.length;
         x++) {

      ceiling[x] =
        generate(x, false);
    }
  }

  void update() {

    moveTunnel();

    wallColor = color(255);
  }

  void draw() {

    strokeWeight(1);

    PShape t =
      getTunnelShape();

    shape(t, 0, 0);
  }

  // ------------------------------------------------
  // MOVE TUNNEL
  // ------------------------------------------------

  void moveTunnel() {

    for (int x = 0;
         x < ceiling.length - 1;
         x++) {

      ceiling[x].y =
        ceiling[x + 1].y;
    }

    ceiling[ceiling.length - 1] =
      generate(
        ceiling.length - 1,
        false
        );
  }

  // ------------------------------------------------
  // CREATE TUNNEL
  // ------------------------------------------------

  PShape getTunnelShape() {

    PShape group =
      createShape(GROUP);

    ceilingShape =
      getWall(true);

    floorShape =
      getWall(false);

    group.addChild(ceilingShape);
    group.addChild(floorShape);

    return group;
  }

  // ------------------------------------------------
  // COLLISION WITH WALL
  // ------------------------------------------------

  boolean isCollision(
    PVector pos,
    float size,
    Obstacle obstacle) {

    if (ceiling == null) {
      return false;
    }

    int i =
      floor(
        map(
          pos.x,
          0,
          width,
          0,
          ceiling.length - 1
          )
        );

    i =
      constrain(
        i,
        0,
        ceiling.length - 1
        );

    int nextI =
      min(
        ceiling.length - 1,
        i + 1
        );

    float y0 =
      ceiling[i].y;

    float y1 =
      ceiling[nextI].y;

    float topY =
      min(y0, y1);

    float bottomY =
      max(y0, y1) + TunnelHeight;

    if (obstacle == Obstacle.CEILING) {

      if (pos.y - size / 2 <= topY) {
        return true;
      }
    }

    if (obstacle == Obstacle.FLOOR) {

      if (pos.y + size / 2 >= bottomY) {
        return true;
      }
    }

    return false;
  }

  // ------------------------------------------------
  // DRAW WALL
  // ------------------------------------------------

  PShape getWall(boolean top) {

    PShape wall =
      createShape();

    wall.beginShape();

    wall.noFill();

    wall.stroke(wallColor);

    if (top) {

      for (int i = 0;
           i < ceiling.length;
           i++) {

        PVector p =
          ceiling[i];

        wall.vertex(
          p.x * drawXScale,
          p.y
          );
      }

      wall.vertex(
        width + 20,
        ceiling[ceiling.length - 1].y
        );

      wall.vertex(
        width + 20,
        -20
        );

      wall.vertex(
        -20,
        -20
        );

      wall.vertex(
        -20,
        ceiling[0].y
        );

    } else {

      for (int i = 0;
           i < ceiling.length;
           i++) {

        PVector p =
          ceiling[i];

        wall.vertex(
          p.x * drawXScale,
          p.y + TunnelHeight
          );
      }

      wall.vertex(
        width + 20,
        ceiling[ceiling.length - 1].y
        + TunnelHeight
        );

      wall.vertex(
        width + 20,
        height + 20
        );

      wall.vertex(
        -20,
        height + 20
        );

      wall.vertex(
        -20,
        ceiling[0].y
        + TunnelHeight
        );
    }

    wall.endShape();

    return wall;
  }

  // ------------------------------------------------
  // GENERATE CAVE
  // ------------------------------------------------

  PVector generate(
    int x,
    boolean init) {

    PVector c =
      new PVector(x, 100);

    if (init) {

      c.y = 100;

    } else {

      float previous =
        ceiling[x - 1].y;

      if (random(1) > 0.5f) {

        c.y =
          previous + yscl;

      } else {

        c.y =
          previous - yscl;
      }

      if (random(1) > flatness) {

        c.y = previous;
      }
    }

    c.y =
      constrain(
        c.y,
        20,
        height - TunnelHeight - 20
        );

    return c;
  }

  // ------------------------------------------------
  // CAVE TOP
  // ------------------------------------------------

  int getTunnelTop(int x) {

    int i =
      round(
        map(
          x,
          0,
          width,
          0,
          ceiling.length - 1
          )
        );

    i =
      constrain(
        i,
        0,
        ceiling.length - 1
        );

    return (int)ceiling[i].y;
  }

  // ------------------------------------------------
  // CAVE MIDDLE
  // ------------------------------------------------

  int getTunnelMiddle(int x) {

    return (int)(
      getTunnelTop(x)
      + TunnelHeight / 2
      );
  }

  float getTunnelHeight() {

    return TunnelHeight;
  }
}

// ================================================================
// ABSTRACT GAME OBJECT
// ================================================================

abstract class GameObject {

  PVector pos;
  PVector spd;
  PVector acc;

  float maxSpeed;
  float size;
  float grav;

  GameObject() {

    pos =
      new PVector(0, 0);

    spd =
      new PVector(0, 0);

    acc =
      new PVector(0, 0);

    maxSpeed = 10;
    size = 10;
    grav = 0.5f;

    setup();

    update();
  }

  void applyForce(
    float x,
    float y) {

    acc.x += x;
    acc.y += y;
  }

  void applyGravity() {

    applyForce(0, grav);
  }

  void update() {

    applyGravity();

    spd.add(acc);

    spd.limit(maxSpeed);

    pos.add(spd);

    acc.mult(0);
  }

  abstract void setup();
}

// ================================================================
// PLAYER
// ================================================================

class Player extends GameObject {

  float maxHealth = 38;

  float health = maxHealth;

  boolean invulnerability = false;

  int invulnerabilityStartFrame = 0;

  int invulnerabilityDuration = 30;

  // ------------------------------------------------

  void setup() {

    int x =
      width / 6;

    pos =
      new PVector(
        x,
        tunnel.getTunnelMiddle(x)
        );

    maxSpeed = 7;

    size = 35;

    grav = 0.5f;
  }

  // ------------------------------------------------

  void update() {

    super.update();

    updateInvulnerability();

    // prevent extreme speed
    spd.y =
      constrain(
        spd.y,
        -maxSpeed,
        maxSpeed
        );
  }

  // ------------------------------------------------

  void draw() {

    if (invulnerability) {

      strokeWeight(2);

      int dangerRed =
        color(
          155 + 100 *
          sin(framesElapsed * 0.2f),
          0,
          0
          );

      stroke(dangerRed);

      if (playButtonPressed) {
        fill(dangerRed);
      } else {
        fill(0);
      }

    } else {

      if (playButtonPressed) {

        strokeWeight(5);

        stroke(255);

        fill(255);

      } else {

        strokeWeight(3);

        stroke(255);

        fill(0);
      }
    }

    beginShape();

    vertex(
      pos.x,
      pos.y
      );

    vertex(
      pos.x - size / 2,
      pos.y + size / 2
      );

    vertex(
      pos.x - size / 2,
      pos.y - size / 2
      );

    endShape(CLOSE);

    strokeWeight(1);
  }

  // ------------------------------------------------
  // DAMAGE
  // ------------------------------------------------

  void applyDamage(int damage) {

    if (damage <= 0) {
      return;
    }

    if (invulnerability) {
      return;
    }

    invulnerabilityDuration =
      damage * 3;

    invulnerability = true;

    invulnerabilityStartFrame =
      frameCount;

    health -= damage;

    health =
      max(0, health);

    vibrate(damage * 5);
  }

  // ------------------------------------------------
  // VIBRATION
  // ------------------------------------------------

  void vibrate(int milliseconds) {

    if (!androidDevice) {
      return;
    }

    if (act == null) {
      return;
    }

    try {

      Vibrator vibrator =
        (Vibrator)act.getSystemService(
        Context.VIBRATOR_SERVICE
        );

      if (vibrator != null) {

        vibrator.vibrate(
          milliseconds
          );
      }

    } catch(Exception e) {
      // ignore vibration failure
    }
  }

  // ------------------------------------------------
  // INVULNERABILITY
  // ------------------------------------------------

  void updateInvulnerability() {

    if (frameCount >
        invulnerabilityStartFrame
        + invulnerabilityDuration) {

      invulnerability = false;
    }
  }

  // ------------------------------------------------
  // INPUT
  // ------------------------------------------------

  void input() {

    if (!playButtonPressed) {
      return;
    }

    if (spd.y > 0) {
      spd.y = 0;
    }

    applyForce(
      0,
      -1.5f
      );
  }

  // ------------------------------------------------
  // DEAD
  // ------------------------------------------------

  boolean isDead() {

    return health < 1;
  }
}

// ================================================================
// MONSTER MANAGER
// ================================================================

class MonsterManager {

  ArrayList<Monster> monsters =
    new ArrayList<Monster>();

  // ------------------------------------------------

  void update() {

    for (int i = monsters.size() - 1;
         i >= 0;
         i--) {

      Monster m =
        monsters.get(i);

      m.update();

      if (m.isTrespassing() ||
          m.isDead()) {

        monsters.remove(i);
      }
    }
  }

  // ------------------------------------------------

  void addMonster(Monster m) {

    if (m != null) {
      monsters.add(m);
    }
  }

  // ------------------------------------------------

  int checkCollisions(
    Player player) {

    for (Monster m : monsters) {

      if (collCheckMonsterAgainstPlayer(
        player.pos,
        player.size,
        m.pos,
        m.size)) {

        int damage =
          m.getCollisionDamageToPlayer();

        m.onCollision();

        return damage;
      }

      if (tunnel.isCollision(
        m.pos,
        m.size,
        Obstacle.CEILING)) {

        m.onCollision();
      }

      if (tunnel.isCollision(
        m.pos,
        m.size,
        Obstacle.FLOOR)) {

        m.onCollision();
      }
    }

    return 0;
  }
}

// ================================================================
// MONSTER BASE
// ================================================================

abstract class Monster extends GameObject {

  boolean dead = false;

  // ------------------------------------------------

  abstract int getCollisionDamageToPlayer();

  abstract void onCollision();

  // ------------------------------------------------

  boolean isTrespassing() {

    return pos.x < -size * 2;
  }

  // ------------------------------------------------

  boolean isDead() {

    return dead;
  }
}

// ================================================================
// RED SQUARE MONSTER
// ================================================================

class SquareMonster extends Monster {

  void setup() {

    float randomValue =
      noise(
        framesElapsed / 100.0f
        + random(1) / 10.0f
        );

    float tunnelTop =
      tunnel.getTunnelTop(width);

    float tunnelBottom =
      tunnelTop
      + tunnel.TunnelHeight;

    float safeY =
      map(
        randomValue,
        0,
        1,
        tunnelTop + size,
        tunnelBottom - size
        );

    pos =
      new PVector(
        width + size,
        safeY
        );

    spd.x = -4;
  }

  // ------------------------------------------------

  void update() {

    applyForce(
      -10,
      -grav
      );

    super.update();

    drawMonster();
  }

  // ------------------------------------------------

  void drawMonster() {

    noStroke();

    fill(
      255,
      0,
      0
      );

    rectMode(CORNER);

    rect(
      pos.x,
      pos.y,
      size,
      size
      );
  }

  // ------------------------------------------------

  int getCollisionDamageToPlayer() {

    return 5;
  }

  // ------------------------------------------------

  void onCollision() {

    dead = true;
  }

  // ------------------------------------------------

  public String toString() {

    return "a";
  }
}

// ================================================================
// SIN MONSTER
// ================================================================

class SinMonster extends SquareMonster {

  void update() {

    applyForce(
      0,
      map(
        sin(
          radians(frameCount * 2)
          ),
        -1,
        1,
        -1.0f,
        1.0f
        )
      );

    super.update();

    drawSinMonster();
  }

  // ------------------------------------------------

  void drawSinMonster() {

    noStroke();

    fill(
      150,
      255,
      150
      );

    rectMode(CORNER);

    rect(
      pos.x,
      pos.y,
      size,
      size
      );
  }

  // ------------------------------------------------

  public String toString() {

    return "b";
  }
}

// ================================================================
// SEEKER MONSTER
// ================================================================

class SeekerMonster extends SquareMonster {

  void setup() {

    super.setup();

    pos.y =
      tunnel.getTunnelMiddle(width);
  }

  // ------------------------------------------------

  void update() {

    PVector towardsPlayer =
      PVector.sub(
        player.pos,
        pos
        );

    towardsPlayer.mult(0.1f);

    towardsPlayer.x = 0;

    applyForce(
      towardsPlayer.x,
      towardsPlayer.y
      );

    super.update();

    drawSeeker();
  }

  // ------------------------------------------------

  void drawSeeker() {

    noStroke();

    fill(
      202,
      209,
      250
      );

    rectMode(CORNER);

    rect(
      pos.x,
      pos.y,
      size,
      size
      );
  }

  // ------------------------------------------------

  public String toString() {

    return "c";
  }
}

// ================================================================
// HUGE MONSTER
// ================================================================

class HugeMonster extends SquareMonster {

  void setup() {

    super.setup();

    size *= 2;

    maxSpeed = 10;
  }

  // ------------------------------------------------

  void drawMonster() {

    noStroke();

    fill(
      255,
      80,
      0
      );

    rectMode(CORNER);

    rect(
      pos.x,
      pos.y,
      size,
      size
      );
  }

  // ------------------------------------------------

  int getCollisionDamageToPlayer() {

    return 10;
  }

  // ------------------------------------------------

  public String toString() {

    return "d";
  }
}








*/



























































