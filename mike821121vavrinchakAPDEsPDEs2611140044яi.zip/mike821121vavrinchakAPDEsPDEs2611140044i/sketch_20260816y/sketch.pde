////7do some////

// APDE / Processing sketch
// Face as 3D point cloud (\~20000 points)
// No circles – only point()

float[][] points;   // [x, y, z]
int TOTAL_POINTS = 20000;

void setup() {
  size(800, 800, P3D);
  smooth(8);
  generateFacePoints();
}

void draw() {
  background(255);
  lights();
  translate(width/2, height/2 + 40, 0);
  
  // gentle rotation
  rotateY(frameCount * 0.008);
  rotateX(sin(frameCount * 0.005) * 0.15);
  
  stroke(20);
  strokeWeight(1.4);
  noFill();
  
  for (int i = 0; i < TOTAL_POINTS; i++) {
    point(points[i][0], points[i][1], points[i][2]);
  }
}

void generateFacePoints() {
  points = new float[TOTAL_POINTS][3];
  int idx = 0;
  
  // Head + face base (ellipsoid)
  while (idx < TOTAL_POINTS * 0.55) {
    float u = random(TWO_PI);
    float v = random(PI);
    float r = 1.0 + random(-0.04, 0.04);
    
    float x = r * 95 * cos(u) * sin(v);
    float y = r * 120 * cos(v) - 20;
    float z = r * 85 * sin(u) * sin(v);
    
    // flatten a bit for face
    if (z > 30) z *= 0.7;
    
    points[idx][0] = x;
    points[idx][1] = y;
    points[idx][2] = z;
    idx++;
  }
  
  // Forehead
  while (idx < TOTAL_POINTS * 0.62) {
    float x = random(-70, 70);
    float y = random(-140, -70);
    float z = 40 + random(-25, 15) - abs(x)*0.15;
    points[idx][0] = x;
    points[idx][1] = y;
    points[idx][2] = z;
    idx++;
  }
  
  // Eyes region
  while (idx < TOTAL_POINTS * 0.70) {
    float side = random(1) < 0.5 ? -1 : 1;
    float x = side * (28 + random(-12, 12));
    float y = -25 + random(-18, 12);
    float z = 55 + random(-8, 12);
    points[idx][0] = x;
    points[idx][1] = y;
    points[idx][2] = z;
    idx++;
  }
  
  // Nose
  while (idx < TOTAL_POINTS * 0.76) {
    float t = random(1);
    float x = random(-12, 12) * (1-t);
    float y = -5 + t * 55;
    float z = 60 + t * 25 + random(-6, 6);
    points[idx][0] = x;
    points[idx][1] = y;
    points[idx][2] = z;
    idx++;
  }
  
  // Mouth / lips
  while (idx < TOTAL_POINTS * 0.82) {
    float x = random(-35, 35);
    float y = 45 + random(-8, 14);
    float z = 50 + random(-10, 15) - abs(x)*0.2;
    points[idx][0] = x;
    points[idx][1] = y;
    points[idx][2] = z;
    idx++;
  }
  
  // Beard / jaw
  while (idx < TOTAL_POINTS * 0.92) {
    float x = random(-75, 75);
    float y = 40 + random(0, 90);
    float z = 20 + random(-30, 40) - abs(x)*0.25;
    if (y > 80) z -= (y-80)*0.4;
    points[idx][0] = x;
    points[idx][1] = y;
    points[idx][2] = z;
    idx++;
  }
  
  // Hair volume
  while (idx < TOTAL_POINTS) {
    float u = random(TWO_PI);
    float v = random(0.3, 1.2);
    float r = 90 + random(10, 55);
    
    float x = r * cos(u) * sin(v);
    float y = -90 - r * cos(v) * 0.9 + random(-20, 10);
    float z = r * sin(u) * sin(v) * 0.7 - 20;
    
    points[idx][0] = x;
    points[idx][1] = y;
    points[idx][2] = z;
    idx++;
  }
}





























