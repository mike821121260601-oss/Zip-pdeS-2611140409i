
/////do//////
// APDE / Processing (Android) sketch
// 6 independent chess boards on screen
// Touch to select + move pieces
// Long-press any board to undo last move on that board
// No text, no labels, no algebraic notation
// Pieces drawn only with rectangles

int COLS = 2;
int ROWS = 3;
int MARGIN = 8;
float SQ;                 // square size
Board[] boards = new Board[6];
float[] bx = new float[6];
float[] by = new float[6];

int selBoard = -1;
int selR = -1, selC = -1;
boolean pieceSelected = false;

long pressStart = 0;
int pressBoard = -1;
final int LONG_PRESS_MS = 450;

void setup() {
  fullScreen();
  orientation(PORTRAIT);
  frameRate(30);
  
  // Calculate square size so 6 boards fit
  float usableW = width  - MARGIN * (COLS + 1);
  float usableH = height - MARGIN * (ROWS + 1);
  SQ = min(usableW / (COLS * 8), usableH / (ROWS * 8));
  
  // Center the whole grid
  float totalW = COLS * 8 * SQ + (COLS - 1) * MARGIN;
  float totalH = ROWS * 8 * SQ + (ROWS - 1) * MARGIN;
  float startX = (width  - totalW) / 2;
  float startY = (height - totalH) / 2;
  
  for (int i = 0; i < 6; i++) {
    int col = i % COLS;
    int row = i / COLS;
    bx[i] = startX + col * (8 * SQ + MARGIN);
    by[i] = startY + row * (8 * SQ + MARGIN);
    boards[i] = new Board();
  }
}

void draw() {
  background(30);
  
  for (int i = 0; i < 6; i++) {
    boards[i].draw(bx[i], by[i]);
  }
  
  // Highlight selected square
  if (pieceSelected && selBoard >= 0) {
    stroke(255, 220, 0);
    strokeWeight(3);
    noFill();
    rect(bx[selBoard] + selC * SQ, 
by[selBoard] + selR * SQ, SQ, SQ);
    noStroke();
  }
}

void mousePressed() {
  pressStart = millis();
  pressBoard = findBoard(mouseX, mouseY);
  
  if (pressBoard < 0) {
    pieceSelected = false;
    return;
  }
  
  int c = int((mouseX - bx[pressBoard]) / SQ);
  int r = int((mouseY - by[pressBoard]) / SQ);
  if (r < 0 || r > 7 || c < 0 || c > 7) return;
  
  if (!pieceSelected) {
    // Select a piece
    if (boards[pressBoard].pieces[r][c] != 0) {
      selBoard = pressBoard;
      selR = r;
      selC = c;
      pieceSelected = true;
    }
  } else {
    // Try to move
    if (pressBoard == selBoard) {
      boards[selBoard].tryMove(selR, selC, r, c);
    }
    pieceSelected = false;
    selBoard = -1;
  }
}

void mouseReleased() {
  if (pressBoard >= 0 &&
 millis() - pressStart >= LONG_PRESS_MS) {
    // Long press = undo last move on that board
    boards[pressBoard].undo();
    pieceSelected = false;
    selBoard = -1;
  }
  pressBoard = -1;
}

int findBoard(float mx, float my) {
  for (int i = 0; i < 6; i++) {
    if (mx >= bx[i] && mx < bx[i] + 8 * SQ &&
        my >= by[i] && my < by[i] + 8 * SQ) {
      return i;
    }
  }
  return -1;
}

// -------------------------------------------------
class Board {
  int[][] pieces = new int[8][8];   // 0=empty
  // 1-6 white: P R N B Q K
  // 7-12 black: p r n b q k
  ArrayList<int[]> history = new ArrayList<int[]>();
  
  Board() {
    reset();
  }
  
  void reset() {
    // Clear
    for (int r = 0; r < 8; r++)
      for (int c = 0; c < 8; c++)
        pieces[r][c] = 0;
    
    // White
    pieces[7][0] = 2; pieces[7][1] = 3; pieces[7][2] = 4;
    pieces[7][3] = 5; pieces[7][4] = 6; pieces[7][5] = 4;
    pieces[7][6] = 3; pieces[7][7] = 2;
    for (int c = 0; c < 8; c++) pieces[6][c] = 1;
    
    // Black
    pieces[0][0] = 8; pieces[0][1] = 9; pieces[0][2] = 10;
    pieces[0][3] = 11; pieces[0][4] = 12;
 pieces[0][5] = 10;
    pieces[0][6] = 9; pieces[0][7] = 8;
    for (int c = 0; c < 8; c++) pieces[1][c] = 7;
    
    history.clear();
  }
  
  void tryMove(int fr, int fc, int tr, int tc) {
    if (fr == tr && fc == tc) return;
    int from = pieces[fr][fc];
    if (from == 0) return;
    
    // Save for undo
    int[] rec = {fr, fc, tr, tc, pieces[tr][tc]};
    history.add(rec);
    
    pieces[tr][tc] = from;
    pieces[fr][fc] = 0;
  }
  
  void undo() {
    if (history.isEmpty()) return;
    int[] rec = history.remove(history.size() - 1);
    pieces[rec[0]][rec[1]] = pieces[rec[2]][rec[3]];
    pieces[rec[2]][rec[3]] = rec[4];
  }
  
  void draw(float ox, float oy) {
    noStroke();
    for (int r = 0; r < 8; r++) {
      for (int c = 0; c < 8; c++) {
        // Board squares
        if ((r + c) % 2 == 0) fill(222, 184, 135);
        else                  fill(139, 90, 43);
        rect(ox + c * SQ, oy + r * SQ, SQ, SQ);
        
        // Piece
        drawPiece(pieces[r][c], ox + c * SQ, oy + r * SQ);
      }
    }
  }
  
  // Pure rectangle pieces – no text, no images
  void drawPiece(int p, float x, float y) {
    if (p == 0) return;
    
    boolean white = (p <= 6);
    float s = SQ;
    float cx = x + s * 0.5;
    float cy = y + s * 0.5;
    
    if (white) fill(245, 245, 240);
    else       fill(25, 25, 30);
    
    int type = (p - 1) % 6;   
// 0=P 1=R 2=N 3=B 4=Q 5=K
    
    switch (type) {
      case 0: // Pawn – small rectangle
        rect(cx - s*0.18, cy - s*0.12, s*0.36, s*0.38, 2);
        break;
        
      case 1: // Rook – tall block + battlements
        rect(cx - s*0.22, cy - s*0.18, s*0.44, s*0.48, 1);
        // battlements
        rect(cx - s*0.22, cy - s*0.28, s*0.12, s*0.12);
        rect(cx - s*0.05, cy - s*0.28, s*0.10, s*0.12);
        rect(cx + s*0.10, cy - s*0.28, s*0.12, s*0.12);
        break;
        
      case 2: // Knight – L shape from rectangles
        rect(cx - s*0.20, cy - s*0.22, s*0.40, s*0.52, 2);
        rect(cx + s*0.02, cy - s*0.30, s*0.28, s*0.22, 2);
        break;
        
      case 3: // Bishop – pointed rectangle stack
        rect(cx - s*0.16, cy - s*0.05, s*0.32, s*0.38, 1);
        rect(cx - s*0.12, cy - s*0.22, s*0.24, s*0.22, 1);
        rect(cx - s*0.07, cy - s*0.32, s*0.14, s*0.14, 1);
        break;
        
      case 4: // Queen – wide base + three top rects
        rect(cx - s*0.24, cy - s*0.10, s*0.48, s*0.42, 2);
        rect(cx - s*0.22, cy - s*0.28, s*0.12, s*0.20);
        rect(cx - s*0.05, cy - s*0.32, s*0.10, s*0.24);
        rect(cx + s*0.10, cy - s*0.28, s*0.12, s*0.20);
        break;
        
      case 5: // King – cross made of rectangles
        rect(cx - s*0.18, cy - s*0.08, s*0.36, s*0.40, 2);
        // cross
        rect(cx - s*0.06, cy - s*0.32, s*0.12, s*0.28);
        rect(cx - s*0.16, cy - s*0.22, s*0.32, s*0.12);
        break;
    }
  }
}



/////do////grok////

































