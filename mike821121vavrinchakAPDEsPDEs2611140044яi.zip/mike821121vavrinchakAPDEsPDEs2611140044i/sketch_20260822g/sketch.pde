


// APDE / Processing – Simple Pool Game
// Touch/drag to aim and shoot the cue ball

int BALL_COUNT = 16;          // 1 cue + 15 object
float BALL_R = 12;
float TABLE_MARGIN = 40;
float POCKET_R = 22;

Ball[] balls = new Ball[BALL_COUNT];
PVector[] pockets = new PVector[6];

boolean aiming = false;
PVector aimStart, aimEnd;
boolean ballsMoving = false;

void setup() {
  size(displayWidth, displayHeight);   // full screen on Android
  orientation(LANDSCAPE);
  frameRate(60);
  
  // pockets (4 corners + 2 middle)
  float w = width - 2*TABLE_MARGIN;
  float h = height - 2*TABLE_MARGIN;
  pockets[0] = new PVector(TABLE_MARGIN, TABLE_MARGIN);
  pockets[1] = new PVector(width/2, TABLE_MARGIN);
  pockets[2] = new PVector(width - TABLE_MARGIN, TABLE_MARGIN);
  pockets[3] = new PVector(TABLE_MARGIN, height - TABLE_MARGIN);
  pockets[4] = new PVector(width/2, height - TABLE_MARGIN);
  pockets[5] = new PVector(width - TABLE_MARGIN, height - TABLE_MARGIN);
  
  resetGame();
}

void resetGame() {
  // cue ball
  balls[0] = new Ball(width*0.25, height/2, color(255), true);
  
  // triangle rack on the right
  float startX = width * 0.65;
  float startY = height/2;
  float d = BALL_R * 2.05;
  int idx = 1;
  for (int row = 0; row < 5; row++) {
    for (int col = 0; col <= row; col++) {
      if (idx >= BALL_COUNT) break;
      float x = startX + row * d * 0.866;
      float y = startY - row * d/2 + col * d;
      color c = color(random(80,255), random(40,200), random(40,180));
      balls[idx] = new Ball(x, y, c, false);
      idx++;
    }
  }
  ballsMoving = false;
}

void draw() {
  background(20, 60, 30);
  
  // table
  fill(20, 110, 40);
  noStroke();
  rect(TABLE_MARGIN, TABLE_MARGIN, 
       width - 2*TABLE_MARGIN, height - 2*TABLE_MARGIN, 8);
  
  // cushions outline
  stroke(80, 40, 10);
  strokeWeight(8);
  noFill();
  rect(TABLE_MARGIN, TABLE_MARGIN, 
       width - 2*TABLE_MARGIN, height - 2*TABLE_MARGIN, 8);
  
  // pockets
  fill(0);
  noStroke();
  for (PVector p : pockets) {
    ellipse(p.x, p.y, POCKET_R*2, POCKET_R*2);
  }
  
  // physics
  ballsMoving = false;
  for (Ball b : balls) {
    if (b == null || b.pocketed) continue;
    b.update();
    if (b.vel.mag() > 0.15) ballsMoving = true;
  }
  
  // collisions
  for (int i = 0; i < BALL_COUNT; i++) {
    if (balls[i] == null || balls[i].pocketed) continue;
    for (int j = i+1; j < BALL_COUNT; j++) {
      if (balls[j] == null || balls[j].pocketed) continue;
      balls[i].collide(balls[j]);
    }
  }
  
  // draw balls
  for (Ball b : balls) {
    if (b != null && !b.pocketed) b.display();
  }
  
  // aiming line
  if (aiming && !ballsMoving) {
    stroke(255, 200);
    strokeWeight(2);
    line(aimStart.x, aimStart.y, aimEnd.x, aimEnd.y);
    
    // power indicator
    float power = constrain(PVector.dist(aimStart, aimEnd) / 8, 0, 18);
    fill(255, 180, 0);
    noStroke();
    rect(20, 20, power * 10, 12);
  }
  
  // instructions
  fill(255);
  textSize(18);
  if (!ballsMoving) {
    text("Drag from cue ball to aim & shoot", 20, height - 20);
  } else {
    text("Balls moving…", 20, height - 20);
  }
}

void mousePressed() {
  if (ballsMoving) return;
  
  // check if near cue ball
  Ball cue = balls[0];
  if (cue != null && !cue.pocketed && dist(mouseX, mouseY, cue.pos.x, cue.pos.y) < BALL_R*3) {
    aiming = true;
    aimStart = new PVector(cue.pos.x, cue.pos.y);
    aimEnd = new PVector(mouseX, mouseY);
  }
}

void mouseDragged() {
  if (aiming) {
    aimEnd = new PVector(mouseX, mouseY);
  }
}

void mouseReleased() {
  if (aiming && !ballsMoving) {
    Ball cue = balls[0];
    if (cue != null && !cue.pocketed) {
      PVector dir = PVector.sub(aimStart, aimEnd);  // opposite of drag
      float power = constrain(dir.mag() / 12, 0, 16);
      dir.normalize();
      dir.mult(power);
      cue.vel.add(dir);
    }
  }
  aiming = false;
}

// simple restart on double-tap or when nothing is moving + screen tap
void mouseClicked() {
  if (!ballsMoving) {
    // optional: restart after a while
  }
}

void keyPressed() {
  if (key == 'r' || key == 'R') resetGame();
}

// ---------- Ball class ----------
class Ball {
  PVector pos, vel;
  color col;
  boolean isCue;
  boolean pocketed = false;
  
  Ball(float x, float y, color c, boolean cue) {
    pos = new PVector(x, y);
    vel = new PVector(0, 0);
    col = c;
    isCue = cue;
  }
  
  void update() {
    if (pocketed) return;
    
    pos.add(vel);
    vel.mult(0.988);          // friction
    
    // cushions
    float left = TABLE_MARGIN + BALL_R;
    float right = width - TABLE_MARGIN - BALL_R;
    float top = TABLE_MARGIN + BALL_R;
    float bottom = height - TABLE_MARGIN - BALL_R;
    
    if (pos.x < left)  { pos.x = left;  vel.x *= -0.9; }
    if (pos.x > right) { pos.x = right; vel.x *= -0.9; }
    if (pos.y < top)   { pos.y = top;   vel.y *= -0.9; }
    if (pos.y > bottom){ pos.y = bottom;vel.y *= -0.9; }
    
    // pockets
    for (PVector p : pockets) {
      if (dist(pos.x, pos.y, p.x, p.y) < POCKET_R - 4) {
        pocketed = true;
        vel.set(0, 0);
        break;
      }
    }
  }
  
  void collide(Ball other) {
    float d = dist(pos.x, pos.y, other.pos.x, other.pos.y);
    if (d < BALL_R * 2 && d > 0.01) {
      // separate
      PVector n = PVector.sub(other.pos, pos);
      n.normalize();
      float overlap = BALL_R * 2 - d;
      pos.sub(PVector.mult(n, overlap * 0.5));
      other.pos.add(PVector.mult(n, overlap * 0.5));
      
      // elastic-ish collision
      PVector v1 = vel.copy();
      PVector v2 = other.vel.copy();
      float p = 2 * (v1.dot(n) - v2.dot(n)) / 2;
      vel.sub(PVector.mult(n, p));
      other.vel.add(PVector.mult(n, p));
      
      // small energy loss
      vel.mult(0.98);
      other.vel.mult(0.98);
    }
  }
  
  void display() {
    noStroke();
    fill(col);
    ellipse(pos.x, pos.y, BALL_R*2, BALL_R*2);
    
    if (isCue) {
      fill(0);
      ellipse(pos.x, pos.y, 4, 4);  // cue mark
    }
  }
}



























