


// APDE 0.5.3 - Show last 6 apps in RAM + Grab Screenshot
// Note: On modern Android, full recent apps list is restricted

import android.app.ActivityManager;
import android.content.Context;
import android.os.Environment;
import java.io.File;
import java.util.List;

String[] appNames = new String[6];
String status = "Loading...";
boolean shotTaken = false;

void setup() {
  fullScreen();
  orientation(PORTRAIT);
  textAlign(CENTER, CENTER);
  textSize(28);
  
  // Try to get running / recent apps
  getLastApps();
}

void draw() {
  background(30);
  
  fill(255);
  text("Last 6 Apps in RAM (from end)", width/2, 60);
  
  // Draw the list
  for (int i = 0; i < 6; i++) {
    float y = 140 + i * 70;
    fill(60);
    rect(40, y - 30, width - 80, 55, 12);
    
    fill(255);
    String name = (appNames[i] != null) ? appNames[i] : "--- empty ---";
    text((i+1) + ". " + name, width/2, y);
  }
  
  // Screenshot button
  fill(0, 150, 80);
  rect(width/2 - 150, height - 160, 300, 70, 15);
  fill(255);
  text("GRAB SCREENSHOT", width/2, height - 125);
  
  // Status
  fill(200);
  textSize(22);
  text(status, width/2, height - 50);
  textSize(28);
}

void mousePressed() {
  // Button area
  if (mouseY > height - 160 && mouseY < height - 90) {
    takeScreenshot();
  }
}

void getLastApps() {
  try {
    ActivityManager am = (ActivityManager) getContext().getSystemService(Context.ACTIVITY_SERVICE);
    
    // Try running processes (more available than recent tasks)
    List<ActivityManager.RunningAppProcessInfo> processes = am.getRunningAppProcesses();
    
    if (processes != null && processes.size() > 0) {
      int start = max(0, processes.size() - 6);  // from the end
      int count = 0;
      
      for (int i = processes.size() - 1; i >= start && count < 6; i--) {
        ActivityManager.RunningAppProcessInfo info = processes.get(i);
        appNames[count] = info.processName;
        // Clean package name a bit
        if (appNames[count].contains(":")) {
          appNames[count] = appNames[count].split(":")[0];
        }
        count++;
      }
      status = "Found " + count + " processes";
    } else {
      status = "No process list available";
    }
  } catch (Exception e) {
    status = "Permission / API limited";
    appNames[0] = "System restricted";
    appNames[1] = "Need Usage Access";
  }
}

void takeScreenshot() {
  try {
    // Capture current screen
    PImage shot = get();
    
    // Save path
    String path = Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_PICTURES).getAbsolutePath();
    File dir = new File(path + "/APDE_Shots");
    if (!dir.exists()) dir.mkdirs();
    
    String filename = path + "/APDE_Shots/shot_" + year() + nf(month(),2) + nf(day(),2) + 
                      "_" + nf(hour(),2) + nf(minute(),2) + nf(second(),2) + ".png";
    
    shot.save(filename);
    status = "Saved: " + filename;
    shotTaken = true;
  } catch (Exception e) {
    status = "Screenshot failed: " + e.getMessage();
  }
}





















