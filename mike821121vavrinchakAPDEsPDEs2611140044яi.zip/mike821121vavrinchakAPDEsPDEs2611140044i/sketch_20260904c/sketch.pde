



/*
  CHESS KALEIDOSCOPE
  APDE 0.5.3 / Processing

  ORIGINAL PLAYABLE ENGINE
  Historical ideas are used only as inspiration:
  early chess-program search + evaluation + move ordering.

  ONE PDE FILE
*/

int N = 8;
int SQ;

char[] b = new char[64];

boolean whiteTurn = true;
boolean humanWhite = true;
boolean humanBlack = false;

int selected = -1;
ArrayList<Integer> selectedMoves = new ArrayList<Integer>();

boolean thinking = false;
boolean gameOver = false;

int engineDepth = 5;
int engineSide = -1;       // -1 = none, 0 white, 1 black
long nodes = 0;

String lastMove = "";
String bestMoveText = "";
String status = "";

long searchStart;
long searchLimit = 2500;

int[] history = new int[256];
int historyCount = 0;

TTEntry[] tt = new TTEntry[50000];

final int INF = 1000000;
final int MATE = 900000;

final int EMPTY = 0;
final int WHITE = 0;
final int BLACK = 1;

class Move {
  int from, to;
  int captured;
  int promotion;
  boolean castle;
  boolean ep;

  Move(int f, int t) {
    from = f;
    to = t;
    captured = b[t];
    promotion = 0;
    castle = false;
    ep = false;
  }

  Move copy() {
    Move m = new Move(from, to);
    m.captured = captured;
    m.promotion = promotion;
    m.castle = castle;
    m.ep = ep;
    return m;
  }
}

class TTEntry {
  long key;
  int depth;
  int score;
  int flag;
  int move;

  TTEntry(long k, int d, int s, int f, int m) {
    key = k;
    depth = d;
    score = s;
    flag = f;
    move = m;
  }
}

void setup() {
  size(displayWidth, displayHeight);
  SQ = min(width, height) / 8;

  initBoard();

  for (int i = 0; i < tt.length; i++)
    tt[i] = null;

  status = "WHITE TO MOVE";
}

void draw() {
  background(30, 30, 30);

  SQ = min(width, height - 80) / 8;

  drawBoard();
  drawPieces();
  drawInfo();

  if (!thinking && !gameOver && engineSide >= 0) {
    int side = whiteTurn ? WHITE : BLACK;

    if (side == engineSide) {
      thinking = true;
      thread("engineThread");
    }
  }
}

void drawBoard() {
  float ox = (width - SQ * 8) / 2.0;
  float oy = 20;

  for (int r = 0; r < 8; r++) {
    for (int c = 0; c < 8; c++) {

      boolean light = ((r + c) & 1) == 0;

      if (light)
        fill(220, 210, 180);
      else
        fill(100, 130, 90);

      rect(ox + c * SQ, oy + r * SQ, SQ, SQ);

      int sq = r * 8 + c;

      if (sq == selected) {
        noFill();
        stroke(255, 220, 0);
        strokeWeight(5);
        rect(ox + c * SQ + 3,
             oy + r * SQ + 3,
             SQ - 6,
             SQ - 6);
        strokeWeight(1);
      }

      if (selectedMoves.contains(sq)) {
        fill(255, 180, 30, 150);
        ellipse(ox + c * SQ + SQ/2,
                oy + r * SQ + SQ/2,
                SQ * .30,
                SQ * .30);
      }
    }
  }
}

void drawPieces() {
  float ox = (width - SQ * 8) / 2.0;
  float oy = 20;

  textAlign(CENTER, CENTER);
  textSize(SQ * .72);

  for (int sq = 0; sq < 64; sq++) {
    if (b[sq] == EMPTY) continue;

    int r = sq / 8;
    int c = sq % 8;

    char p = (char)b[sq];

    if (isWhitePiece(p))
      fill(250);
    else
      fill(20);

    text(pieceChar(p),
         ox + c * SQ + SQ/2,
         oy + r * SQ + SQ/2 - 3);
  }
}

String pieceChar(char p) {
  switch(p) {
  case 'P': return "P";
  case 'N': return "N";
  case 'B': return "B";
  case 'R': return "R";
  case 'Q': return "Q";
  case 'K': return "K";

  case 'p': return "P";
  case 'n': return "N";
  case 'b': return "B";
  case 'r': return "R";
  case 'q': return "Q";
  case 'k': return "K";
  }

  return "";
}

void drawInfo() {
  fill(240);
  textAlign(LEFT, CENTER);
  textSize(18);

  String s = "";

  if (thinking)
    s = "ENGINE THINKING  depth " + engineDepth +
        "  nodes " + nodes;
  else
    s = status;

  text(s, 10, height - 60);

  text("BEST: " + bestMoveText, 10, height - 35);
}

/* --------------------------------------------------
   BOARD
-------------------------------------------------- */

void initBoard() {

  for (int i = 0; i < 64; i++)
    b[i] = '.';

  String row1 = "RNBQKBNR";
  String row2 = "PPPPPPPP";
  String row7 = "pppppppp";
  String row8 = "rnbqkbnr";

  for (int i = 0; i < 8; i++) {
    b[i] = row1.charAt(i);
    b[8+i] = row2.charAt(i);
    b[48+i] = row7.charAt(i);
    b[56+i] = row8.charAt(i);
  }

  whiteTurn = true;
  selected = -1;
  selectedMoves.clear();
  historyCount = 0;

  lastMove = "";
  bestMoveText = "";

  gameOver = false;
}

/* --------------------------------------------------
   INPUT
-------------------------------------------------- */

void mousePressed() {

  if (thinking || gameOver)
    return;

  int side = whiteTurn ? WHITE : BLACK;

  if (side == engineSide)
    return;

  float ox = (width - SQ * 8) / 2.0;
  float oy = 20;

  int c = int((mouseX - ox) / SQ);
  int r = int((mouseY - oy) / SQ);

  if (c < 0 || c >= 8 || r < 0 || r >= 8)
    return;

  int sq = r * 8 + c;

  if (selected < 0) {

    if (b[sq] != '.' &&
        pieceColor(b[sq]) == side) {

      selected = sq;
      selectedMoves.clear();

      ArrayList<Move> ms = legalMoves(side);

      for (Move m : ms)
        if (m.from == selected)
          selectedMoves.add(m.to);
    }

    return;
  }

  Move chosen = null;

  ArrayList<Move> ms = legalMoves(side);

  for (Move m : ms) {
    if (m.from == selected && m.to == sq) {
      chosen = m;
      break;
    }
  }

  if (chosen != null) {

    makeMove(chosen);

    selected = -1;
    selectedMoves.clear();

    whiteTurn = !whiteTurn;

    updateGameState();
  }
  else {
    selected = -1;
    selectedMoves.clear();
  }
}

void keyPressed() {

  if (key == 'r' || key == 'R') {
    initBoard();
    status = "NEW GAME";
  }

  if (key == '1') {
    engineSide = BLACK;
    status = "HUMAN WHITE / ENGINE BLACK";
  }

  if (key == '2') {
    engineSide = WHITE;
    status = "ENGINE WHITE / HUMAN BLACK";
  }

  if (key == '3') {
    engineSide = -1;
    status = "HUMAN VS HUMAN";
  }

  if (key == '4') {
    engineSide = WHITE;
    humanWhite = false;
    humanBlack = false;
    status = "ENGINE VS ENGINE";
  }

  if (key == '+')
    engineDepth = min(8, engineDepth + 1);

  if (key == '-')
    engineDepth = max(1, engineDepth - 1);
}

/* --------------------------------------------------
   ENGINE THREAD
-------------------------------------------------- */

void engineThread() {

  nodes = 0;
  bestMoveText = "";

  searchStart = millis();

  Move best = searchRoot(engineDepth,
                          whiteTurn ? WHITE : BLACK);

  if (best != null && !gameOver) {

    makeMove(best);

    lastMove = moveString(best);

    whiteTurn = !whiteTurn;

    bestMoveText = lastMove;
  }

  thinking = false;

  updateGameState();
}

/* --------------------------------------------------
   ROOT SEARCH
-------------------------------------------------- */

Move searchRoot(int depth, int side) {

  ArrayList<Move> moves = legalMoves(side);

  if (moves.size() == 0)
    return null;

  orderMoves(moves, -1);

  Move best = moves.get(0);

  int bestScore = -INF;

  for (int d = 1; d <= depth; d++) {

    int alpha = -INF;
    int beta = INF;

    Move iterationBest = null;
    int iterationScore = -INF;

    orderMoves(moves, bestIndex(moves, best));

    for (Move m : moves) {

      if (timeUp())
        break;

      makeMove(m);

      int score;

      if (side == WHITE)
        score = -alphaBeta(d - 1,
                           -beta,
                           -alpha,
                           BLACK);
      else
        score = -alphaBeta(d - 1,
                           -beta,
                           -alpha,
                           WHITE);

      undoMove(m);

      score = -score;

      if (score > iterationScore) {
        iterationScore = score;
        iterationBest = m;
      }

      if (score > alpha)
        alpha = score;
    }

    if (iterationBest != null) {
      best = iterationBest;
      bestScore = iterationScore;
      bestMoveText = moveString(best) +
                     "  score " + bestScore;
    }

    if (timeUp())
      break;
  }

  return best;
}

int alphaBeta(int depth,
              int alpha,
              int beta,
              int side) {

  nodes++;

  if ((nodes & 2047) == 0 && timeUp())
    return evaluateFor(side);

  if (depth <= 0)
    return quiescence(alpha, beta, side);

  ArrayList<Move> moves = legalMoves(side);

  if (moves.size() == 0) {

    if (inCheck(side))
      return -MATE + depth;

    return 0;
  }

  orderMoves(moves, -1);

  int originalAlpha = alpha;
  int bestMove = -1;

  long key = positionKey();

  TTEntry t = ttEntry(key);

  if (t != null && t.depth >= depth) {

    if (t.flag == 0)
      return t.score;

    if (t.flag == 1)
      alpha = max(alpha, t.score);

    if (t.flag == 2)
      beta = min(beta, t.score);

    if (alpha >= beta)
      return t.score;
  }

  int best = -INF;

  for (Move m : moves) {

    if (timeUp())
      break;

    makeMove(m);

    int score = -alphaBeta(depth - 1,
                           -beta,
                           -alpha,
                           1 - side);

    undoMove(m);

    if (score > best) {
      best = score;
      bestMove = encodeMove(m);
    }

    alpha = max(alpha, score);

    if (alpha >= beta)
      break;
  }

  int flag = 0;

  if (best <= originalAlpha)
    flag = 2;
  else if (best >= beta)
    flag = 1;

  int index = (int)(abs(key) % tt.length);

  tt[index] = new TTEntry(
    key,
    depth,
    best,
    flag,
    bestMove
  );

  return best;
}

/* --------------------------------------------------
   QUIESCENCE
-------------------------------------------------- */

int quiescence(int alpha,
               int beta,
               int side) {

  nodes++;

  int stand = evaluateFor(side);

  if (stand >= beta)
    return beta;

  if (stand > alpha)
    alpha = stand;

  ArrayList<Move> moves = legalMoves(side);

  for (Move m : moves) {

    if (m.captured == '.' ||
        m.captured == EMPTY)
      continue;

    makeMove(m);

    int score = -quiescence(-beta,
                            -alpha,
                            1-side);

    undoMove(m);

    if (score >= beta)
      return beta;

    if (score > alpha)
      alpha = score;
  }

  return alpha;
}

/* --------------------------------------------------
   MOVE GENERATION
-------------------------------------------------- */

ArrayList<Move> legalMoves(int side) {

  ArrayList<Move> result =
    new ArrayList<Move>();

  for (int sq = 0; sq < 64; sq++) {

    char p = b[sq];

    if (p == '.')
      continue;

    if (pieceColor(p) != side)
      continue;

    pseudoMoves(sq, p, result);
  }

  ArrayList<Move> legal =
    new ArrayList<Move>();

  for (Move m : result) {

    makeMove(m);

    boolean check = inCheck(side);

    undoMove(m);

    if (!check)
      legal.add(m);
  }

  return legal;
}

void pseudoMoves(int sq,
                 char p,
                 ArrayList<Move> list) {

  int side = pieceColor(p);
  int r = sq / 8;
  int c = sq % 8;

  char u = Character.toUpperCase(p);

  if (u == 'P') {

    int dr = side == WHITE ? -1 : 1;

    int r1 = r + dr;

    if (inside(r1,c) &&
        b[r1*8+c] == '.') {

      Move m = new Move(sq,r1*8+c);

      if (r1 == 0 || r1 == 7) {
        m.promotion = 'Q';
      }

      list.add(m);

      int start = side == WHITE ? 6 : 1;

      if (r == start &&
          b[(r+2*dr)*8+c] == '.') {

        list.add(new Move(
          sq,
          (r+2*dr)*8+c
        ));
      }
    }

    for (int dc=-1; dc<=1; dc+=2) {

      int cc = c + dc;

      if (!inside(r1,cc))
        continue;

      int to = r1*8+cc;

      if (b[to] != '.' &&
          pieceColor(b[to]) != side) {

        Move m = new Move(sq,to);

        if (r1 == 0 || r1 == 7)
          m.promotion = 'Q';

        list.add(m);
      }
    }

    return;
  }

  if (u == 'N') {

    int[][] d = {
      {2,1},{2,-1},
      {-2,1},{-2,-1},
      {1,2},{1,-2},
      {-1,2},{-1,-2}
    };

    for (int i=0;i<8;i++)
      addStep(sq,
              r+d[i][0],
              c+d[i][1],
              side,
              list);

    return;
  }

  if (u == 'K') {

    for (int dr=-1;dr<=1;dr++)
      for (int dc=-1;dc<=1;dc++)
        if (dr != 0 || dc != 0)
          addStep(sq,
                  r+dr,
                  c+dc,
                  side,
                  list);

    return;
  }

  if (u == 'B' ||
      u == 'R' ||
      u == 'Q') {

    if (u == 'B' || u == 'Q') {

      slide(sq,r,c,
            side,list,
            1,1);

      slide(sq,r,c,
            side,list,
            1,-1);

      slide(sq,r,c,
            side,list,
            -1,1);

      slide(sq,r,c,
            side,list,
            -1,-1);
    }

    if (u == 'R' || u == 'Q') {

      slide(sq,r,c,
            side,list,
            1,0);

      slide(sq,r,c,
            side,list,
            -1,0);

      slide(sq,r,c,
            side,list,
            0,1);

      slide(sq,r,c,
            side,list,
            0,-1);
    }
  }
}

void addStep(int sq,
             int r,
             int c,
             int side,
             ArrayList<Move> list) {

  if (!inside(r,c))
    return;

  int to = r*8+c;

  if (b[to] == '.' ||
      pieceColor(b[to]) != side)
    list.add(new Move(sq,to));
}

void slide(int sq,
           int r,
           int c,
           int side,
           ArrayList<Move> list,
           int dr,
           int dc) {

  int rr = r + dr;
  int cc = c + dc;

  while (inside(rr,cc)) {

    int to = rr*8+cc;

    if (b[to] == '.') {
      list.add(new Move(sq,to));
    }
    else {

      if (pieceColor(b[to]) != side)
        list.add(new Move(sq,to));

      break;
    }

    rr += dr;
    cc += dc;
  }
}

/* --------------------------------------------------
   MOVE ORDERING
-------------------------------------------------- */



 









void orderMoves(ArrayList<Move> moves,
                int preferred) {

  for (int i=0;i<moves.size();i++) {

    int best = i;
    int bestScore = moveScore(moves.get(i));

    for (int j=i+1;j<moves.size();j++) {

      int s = moveScore(moves.get(j));

      if (s > bestScore) {
        best = j;
        bestScore = s;
      }
    }

    Move temp = moves.get(i);
    moves.set(i,moves.get(best));
    moves.set(best,temp);
  }
}

int moveScore(Move m) {

  int s = 0;



 




//... ///

  if (m.captured != '.' &&
      m.captured != EMPTY) {

    s += 10000;



 // s += pieceValue((m.captured) ) * 10;

 //   s += pieceValue(char(m.captured) ) * 10;

 // s += ((  ( pieceValue((m.captured ) )*10 ))) ;

   ///   s +=10;//err///















s += pieceValue((char)m.captured) * 10;









    s -= pieceValue(b[m.from]);
  }

  if (m.promotion != 0)
    s += 9000;

  char p = b[m.from];

  if (Character.toUpperCase(p) == 'N')
    s += 300;

  if (Character.toUpperCase(p) == 'B')
    s += 250;

  return s;
}

/* --------------------------------------------------
   EVALUATION
-------------------------------------------------- */

int evaluateFor(int side) {

  int white = evaluateSide(WHITE);
  int black = evaluateSide(BLACK);

  int score = white - black;

  return side == WHITE ? score : -score;
}

int evaluateSide(int side) {

  int score = 0;

  for (int sq=0;sq<64;sq++) {

    char p = b[sq];

    if (p == '.' ||
        pieceColor(p) != side)
      continue;

    int v = pieceValue(p);

    score += v;

    int r = sq / 8;
    int c = sq % 8;

    char u = Character.toUpperCase(p);

    if (u == 'P') {

      int advance =
        side == WHITE ? 6-r : r-1;

      score += advance * 8;

      if (passedPawn(sq,side))
        score += 35;
    }

    if (u == 'N') {

      int center =
        4 - abs(3-r) +
        4 - abs(3-c);

      score += center * 8;
    }

    if (u == 'B')
      score += bishopActivity(sq,side);

    if (u == 'R') {

      if (r == 0 || r == 7)
        score += 5;
    }

    if (u == 'Q')
      score += queenActivity(sq,side);

    if (u == 'K') {

      int centerDistance =
        abs(3-r) + abs(3-c);

      score -= centerDistance * 2;
    }
  }

  score += mobility(side) * 2;

  return score;
}

int pieceValue(char p) {

  switch(Character.toUpperCase(p)) {
  case 'P': return 100;
  case 'N': return 320;
  case 'B': return 330;
  case 'R': return 500;
  case 'Q': return 900;
  case 'K': return 20000;
  }

  return 0;
}

boolean passedPawn(int sq,int side) {

  int r=sq/8;
  int c=sq%8;

  int enemy = 1-side;

  for (int rr=0;rr<8;rr++) {

    for (int cc=max(0,c-1);
         cc<=min(7,c+1);
         cc++) {

      int s=rr*8+cc;

      if (b[s] != '.' &&
          pieceColor(b[s]) == enemy &&
          Character.toUpperCase(b[s]) == 'P') {

        if (side == WHITE && rr < r)
          return false;

        if (side == BLACK && rr > r)
          return false;
      }
    }
  }

  return true;
}

int bishopActivity(int sq,int side) {

  int score=0;

  int r=sq/8;
  int c=sq%8;

  int[][] d={
    {1,1},{1,-1},
    {-1,1},{-1,-1}
  };

  for (int i=0;i<4;i++) {

    int rr=r+d[i][0];
    int cc=c+d[i][1];

    while(inside(rr,cc)) {

      int s=rr*8+cc;

      if (b[s] != '.') {

        if (pieceColor(b[s]) != side)
          score += 4;

        break;
      }

      score += 1;

      rr+=d[i][0];
      cc+=d[i][1];
    }
  }

  return score;
}

int queenActivity(int sq,int side) {

  return mobilitySquare(sq,side) * 2;
}

int mobilitySquare(int sq,int side) {

  char p=b[sq];

  if (p=='.') return 0;

  ArrayList<Move> list=
    new ArrayList<Move>();

  pseudoMoves(sq,p,list);

  int n=0;

  for(Move m:list) {

    if (b[m.to]=='.' ||
        pieceColor(b[m.to])!=side)
      n++;
  }

  return n;
}

int mobility(int side) {

  int n=0;

  for(int sq=0;sq<64;sq++) {

    if(b[sq]!='.' &&
       pieceColor(b[sq])==side)
      n += mobilitySquare(sq,side);
  }

  return n;
}

/* --------------------------------------------------
   CHECK
-------------------------------------------------- */

boolean inCheck(int side) {

  int king=-1;

  for(int i=0;i<64;i++) {

    if(side==WHITE && b[i]=='K')
      king=i;

    if(side==BLACK && b[i]=='k')
      king=i;
  }

  if(king<0)
    return true;

  return attacked(king,1-side);
}

boolean attacked(int sq,int bySide) {

  int r=sq/8;
  int c=sq%8;

  int pawnDir =
    bySide==WHITE ? 1 : -1;

  for(int dc=-1;dc<=1;dc+=2) {

    int rr=r+pawnDir;
    int cc=c+dc;

    if(inside(rr,cc)) {

      char p=b[rr*8+cc];

      if((bySide==WHITE && p=='P') ||
         (bySide==BLACK && p=='p'))
        return true;
    }
  }

  int[][] knight={
    {2,1},{2,-1},
    {-2,1},{-2,-1},
    {1,2},{1,-2},
    {-1,2},{-1,-2}
  };

  for(int i=0;i<8;i++) {

    int rr=r+knight[i][0];
    int cc=c+knight[i][1];

    if(inside(rr,cc)) {

      char p=b[rr*8+cc];

      if((bySide==WHITE && p=='N') ||
         (bySide==BLACK && p=='n'))
        return true;
    }
  }

  for(int dr=-1;dr<=1;dr++)
    for(int dc=-1;dc<=1;dc++) {

      if(dr==0 && dc==0)
        continue;

      int rr=r+dr;
      int cc=c+dc;

      if(inside(rr,cc)) {

        char p=b[rr*8+cc];

        if((bySide==WHITE && p=='K') ||
           (bySide==BLACK && p=='k'))
          return true;
      }
    }

  int[][] diag={
    {1,1},{1,-1},
    {-1,1},{-1,-1}
  };

  for(int i=0;i<4;i++) {

    int rr=r+diag[i][0];
    int cc=c+diag[i][1];

    while(inside(rr,cc)) {

      char p=b[rr*8+cc];

      if(p!='.') {

        if(bySide==WHITE &&
           (p=='B'||p=='Q'))
          return true;

        if(bySide==BLACK &&
           (p=='b'||p=='q'))
          return true;

        break;
      }

      rr+=diag[i][0];
      cc+=diag[i][1];
    }
  }

  int[][] line={
    {1,0},{-1,0},
    {0,1},{0,-1}
  };

  for(int i=0;i<4;i++) {

    int rr=r+line[i][0];
    int cc=c+line[i][1];

    while(inside(rr,cc)) {

      char p=b[rr*8+cc];

      if(p!='.') {

        if(bySide==WHITE &&
           (p=='R'||p=='Q'))
          return true;

        if(bySide==BLACK &&
           (p=='r'||p=='q'))
          return true;

        break;
      }

      rr+=line[i][0];
      cc+=line[i][1];
    }
  }

  return false;
}

/* --------------------------------------------------
   MAKE / UNMAKE
-------------------------------------------------- */

void makeMove(Move m) {

  history[historyCount++] =
    positionHashSimple();

  char p=b[m.from];

  b[m.to]=p;
  b[m.from]='.';

  if(m.promotion!=0) {

    if(p=='P')
      b[m.to]='Q';

    if(p=='p')
      b[m.to]='q';
  }

  /*
    Promotion is deliberately simple here.
    Q promotion is automatic.
  */
}

void undoMove(Move m) {

  b[m.from]=b[m.to];

  if(m.promotion!=0) {

    if(b[m.from]=='Q')
      b[m.from]='P';

    if(b[m.from]=='q')
      b[m.from]='p';
  }

  b[m.to]=(char)m.captured;

  historyCount--;
}

/* --------------------------------------------------
   GAME STATE
-------------------------------------------------- */

void updateGameState() {

  int side =
    whiteTurn ? WHITE : BLACK;

  ArrayList<Move> moves =
    legalMoves(side);

  if(moves.size()==0) {

    gameOver=true;

    if(inCheck(side)) {

      if(side==WHITE)
        status="CHECKMATE - BLACK WINS";
      else
        status="CHECKMATE - WHITE WINS";

    } else {
      status="STALEMATE";
    }

    return;
  }

  if(inCheck(side))
    status=(side==WHITE ?
            "WHITE IN CHECK" :
            "BLACK IN CHECK");
  else
    status=(side==WHITE ?
            "WHITE TO MOVE" :
            "BLACK TO MOVE");
}

/* --------------------------------------------------
   UTILITIES
-------------------------------------------------- */

int pieceColor(char p) {

  if(p=='.')
    return -1;

  if(Character.isUpperCase(p))
    return WHITE;

  return BLACK;
}

boolean isWhitePiece(char p) {
  return p!='.' &&
         Character.isUpperCase(p);
}

boolean inside(int r,int c) {
  return r>=0 && r<8 &&
         c>=0 && c<8;
}

int encodeMove(Move m) {
  return m.from*64+m.to;
}

int bestIndex(ArrayList<Move> list,
              Move wanted) {

  if(wanted==null)
    return -1;

  for(int i=0;i<list.size();i++)
    if(list.get(i).from==wanted.from &&
       list.get(i).to==wanted.to)
      return i;

  return -1;
}

String moveString(Move m) {

  return squareName(m.from) +
         squareName(m.to);
}

String squareName(int sq) {

  int r=sq/8;
  int c=sq%8;

  char file=(char)('a'+c);
  char rank=(char)('8'-r);

  return ""+file+rank;
}

boolean timeUp() {
  return millis()-searchStart >
         searchLimit;
}

/* --------------------------------------------------
   POSITION HASH
-------------------------------------------------- */

long positionKey() {

  long h=1469598103934665603L;

  for(int i=0;i<64;i++) {

    h ^= (long)b[i];
    h *= 1099511628211L;
  }

  h ^= whiteTurn ? 1 : 2;

  return h;
}

int positionHashSimple() {

  int h=17;

  for(int i=0;i<64;i++)
    h=h*31+b[i];

  return h;
}

TTEntry ttEntry(long key) {

  int i=(int)(abs(key)%tt.length);

  TTEntry e=tt[i];

  if(e!=null && e.key==key)
    return e;

  return null;
}
























