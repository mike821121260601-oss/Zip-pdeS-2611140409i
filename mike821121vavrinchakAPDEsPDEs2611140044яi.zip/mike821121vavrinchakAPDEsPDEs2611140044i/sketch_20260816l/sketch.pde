


////DO///////OK///////
import android.media.AudioTrack;
import android.media.AudioFormat;
import android.media.AudioManager;

AudioTrack audio;
int sampleRate = 44100;

float[] notes = {
  261.63, 277.18, 293.66, 311.13, 329.63,
  349.23, 369.99, 392.00, 415.30, 440.00,
  466.16, 493.88, 523.25, 554.37, 587.33,
  622.25, 659.25, 698.46, 739.99, 783.99,
  830.61, 880.00, 932.33, 987.77, 1046.50
};

void setup() {
  size(displayWidth, displayHeight);
  orientation(PORTRAIT);
  
  audio = new AudioTrack(
    AudioManager.STREAM_MUSIC,
    sampleRate,
    AudioFormat.CHANNEL_OUT_MONO,
    AudioFormat.ENCODING_PCM_16BIT,
    sampleRate / 2,
    AudioTrack.MODE_STREAM
  );
  
  audio.play();
}

void draw() {
  background(20);
  
  float w = width / 5.0;
  float h = height / 5.0;
  
  for (int i = 0; i < 25; i++) {
    int col = i % 5;
    int row = i / 5;
    
    float x = col * w;
    float y = row * h;
    
    fill(40 + i * 7, 100, 220);
    stroke(255);
    strokeWeight(2);
    
    rect(x + 3, y + 3, w - 6, h - 6);
    
    fill(255);
    textAlign(CENTER, CENTER);
    textSize(min(w, h) * 0.25);
    text("" + (i + 1), x + w/2, y + h/2);
  }
}

void mousePressed() {
  float w = width / 5.0;
  float h = height / 5.0;
  
  int col = int(mouseX / w);
  int row = int(mouseY / h);
  
  if (col >= 0 && col < 5 && row >= 0 && row < 5) {
    int key = row * 5 + col;
    playNote(notes[key], 300);
  }
}

void playNote(float frequency, int duration) {
  int samples = sampleRate * duration / 1000;
  short[] buffer = new short[samples];
  
  for (int i = 0; i < samples; i++) {
    float t = (float)i / sampleRate;
    
    // Smooth attack/release
    float envelope = 1.0;
    
    if (i < samples * 0.05)
      envelope = i / (samples * 0.05);
      
    if (i > samples * 0.85)
      envelope = (samples - i) / (samples * 0.15);
    
    buffer[i] = (short)(
      Math.sin(2.0 * Math.PI * frequency * t)
      * 16000
      * envelope
    );
  }
  
  audio.write(buffer, 0, buffer.length);
}

void onPause() {
  super.onPause();
  if (audio != null) audio.pause();
}

void onResume() {
  super.onResume();
  if (audio != null) audio.play();
}







////do/////
































