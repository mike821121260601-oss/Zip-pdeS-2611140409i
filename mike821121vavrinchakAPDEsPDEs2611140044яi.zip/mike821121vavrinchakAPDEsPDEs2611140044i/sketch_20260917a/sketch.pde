
// ============================================================
//  P4wn Chess – Processing / APDE 0.5.3 port
//  Based on the original public-domain p4wn engine
//  by Douglas Bagnall
// ============================================================

int SQUARE = 60;               // size of one square
int BOARD_X = 20;              // top-left of the board
int BOARD_Y = 40;

// Piece encoding (same as original p4wn)
final int EMPTY = 0;
final int WPAWN = 2, BPAWN = 3;
final int WROOK = 4, BROOK = 5;
final int WKNIGHT = 6, BKNIGHT = 7;
final int WBISHOP = 8, BBISHOP = 9;
final int WKING = 10, BKING = 11;
final int WQUEEN = 12, BQUEEN = 13;
final int EDGE = 16;

int[] board = new int[120];    // 10x12 mailbox
int toPlay = 0;                // 0 = white, 1 = black
int selected = -1;             // currently selected square (0-119)
int computerLevel = 2;         // 1-4 (higher = stronger / slower)
boolean gameOver = false;
String statusMsg = "White to move";

// Simple piece values (scaled like original)
int[] values = {0,0, 20,20, 100,100, 60,60, 61,61, 8000,8000, 180,180};

// ------------------------------------------------------------
void setup() {
  size(520, 640);
  textAlign(CENTER, CENTER);
  textSize(18);
  initBoard();
  statusMsg = "White to move – tap a piece";
}

void draw() {
  background(40);
  drawBoard();
  drawPieces();
  drawUI();
}

// ------------------------------------------------------------
//  Board initialisation (FEN-style start position)
// ------------------------------------------------------------
void initBoard() {
  // clear
  for (int i = 0; i < 120; i++) board[i] = EDGE;
  for (int y = 2; y <= 9; y++)
    for (int x = 1; x <= 8; x++)
      board[y*10 + x] = EMPTY;

  // black pieces
  int[] back = {BROOK, BKNIGHT, BBISHOP, BQUEEN, BKING, BBISHOP, BKNIGHT, BROOK};
  for (int i = 0; i < 8; i++) {
    board[20 + 1 + i] = back[i];
    board[30 + 1 + i] = BPAWN;
  }
  // white pieces
  int[] wback = {WROOK, WKNIGHT, WBISHOP, WQUEEN, WKING, WBISHOP, WKNIGHT, WROOK};
  for (int i = 0; i < 8; i++) {
    board[90 + 1 + i] = wback[i];
    board[80 + 1 + i] = WPAWN;
  }
  toPlay = 0;
  selected = -1;
  gameOver = false;
}

// ------------------------------------------------------------
//  Drawing
// ------------------------------------------------------------
void drawBoard() {
  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {
      int sq = (9-y)*10 + (x+1);          // mailbox coordinate
      boolean light = ((x + y) % 2 == 0);
      fill(light ? 220 : 120);
      if (sq == selected) fill(180, 220, 100);
      rect(BOARD_X + x*SQUARE, BOARD_Y + y*SQUARE, SQUARE, SQUARE);
    }
  }
}

void drawPieces() {
  textSize(36);
  for (int y = 2; y <= 9; y++) {
    for (int x = 1; x <= 8; x++) {
      int p = board[y*10 + x];
      if (p == EMPTY || p == EDGE) continue;
      int screenY = BOARD_Y + (9-y)*SQUARE + SQUARE/2;
      int screenX = BOARD_X + (x-1)*SQUARE + SQUARE/2;
      fill( (p & 1) == 0 ? 255 : 30 );
      text(pieceChar(p), screenX, screenY);
    }
  }
  textSize(18);
}

String pieceChar(int p) {
  switch (p) {
    case WPAWN: return "♙"; case BPAWN: return "♟";
    case WROOK: return "♖"; case BROOK: return "♜";
    case WKNIGHT: return "♘"; case BKNIGHT: return "♞";
    case WBISHOP: return "♗"; case BBISHOP: return "♝";
    case WQUEEN: return "♕"; case BQUEEN: return "♛";
    case WKING: return "♔"; case BKING: return "♚";
  }
  return "";
}

void drawUI() {
  fill(255);
  text(statusMsg, width/2, 20);
  text("Level: " + computerLevel + "   (tap to change)", width/2, height - 50);
  text("New Game", width/2, height - 20);
}

// ------------------------------------------------------------
//  Input (works with mouse and touch in APDE)
// ------------------------------------------------------------
void mousePressed() {
  // level button
  if (mouseY > height - 70 && mouseY < height - 40) {
    computerLevel = (computerLevel % 4) + 1;
    return;
  }
  // new game
  if (mouseY > height - 30) {
    initBoard();
    statusMsg = "White to move";
    return;
  }

  if (gameOver) return;

  int bx = (mouseX - BOARD_X) / SQUARE;
  int by = (mouseY - BOARD_Y) / SQUARE;
  if (bx < 0 || bx > 7 || by < 0 || by > 7) return;

  int sq = (9 - by)*10 + (bx + 1);

  if (selected == -1) {
    // select own piece
    int p = board[sq];
    if (p != EMPTY && (p & 1) == toPlay) {
      selected = sq;
    }
  } else {
    // try move
    if (tryMove(selected, sq)) {
      selected = -1;
      toPlay = 1 - toPlay;
      statusMsg = (toPlay == 0 ? "White" : "Black") + " to move";
      // computer move
      if (!gameOver && toPlay == 1) {
        delay(200);
        computerMove();
      }
    } else {
      // re-select
      int p = board[sq];
      if (p != EMPTY && (p & 1) == toPlay) selected = sq;
      else selected = -1;
    }
  }
}

// ------------------------------------------------------------
//  Very simplified move validation + make move
//  (full p4wn legality is much longer; this is a working subset)
// ------------------------------------------------------------
boolean tryMove(int from, int to) {
  int piece = board[from];
  if (piece == EMPTY) return false;
  if ((piece & 1) != toPlay) return false;

  // extremely simplified – only basic sliding / pawn / king moves
  // for a full port you would copy the whole p4_parse() logic
  int dx = (to % 10) - (from % 10);
  int dy = (to / 10) - (from / 10);
  int adx = abs(dx), ady = abs(dy);

  boolean legal = false;
  int type = piece & 14;

  if (type == 2) { // pawn
    int dir = (toPlay == 0) ? -10 : 10;
    if (dx == 0 && board[to] == EMPTY) {
      if (to == from + dir) legal = true;
      if (to == from + 2*dir && board[from+dir] == EMPTY &&
         ((toPlay==0 && from/10==8) || (toPlay==1 && from/10==3))) legal = true;
    }
    if (adx == 1 && to == from + dir && board[to] != EMPTY && (board[to]&1) != toPlay)
      legal = true;
  }
  else if (type == 6) { // knight
    if ((adx==1 && ady==2) || (adx==2 && ady==1)) legal = true;
  }
  else if (type == 10) { // king
    if (adx <= 1 && ady <= 1) legal = true;
  }
  else { // rook / bishop / queen – rough ray test
    if (type == 4 || type == 12) { // rook or queen
      if (dx == 0 || dy == 0) legal = clearRay(from, to);
    }
    if (type == 8 || type == 12) { // bishop or queen
      if (adx == ady) legal = clearRay(from, to);
    }
  }

  if (!legal) return false;
  if (board[to] != EMPTY && (board[to] & 1) == toPlay) return false;

  // make the move
  board[to] = piece;
  board[from] = EMPTY;

  // promotion
  if ((piece & 14) == 2 && (to/10 == 2 || to/10 == 9))
    board[to] = (toPlay == 0) ? WQUEEN : BQUEEN;

  return true;
}

boolean clearRay(int from, int to) {
  int dx = (to%10) - (from%10);
  int dy = (to/10) - (from/10);
  int sx = (dx == 0) ? 0 : dx / abs(dx);
  int sy = (dy == 0) ? 0 : dy / abs(dy);
  int n = max(abs(dx), abs(dy));
  for (int i = 1; i < n; i++) {
    int sq = from + i*(sy*10 + sx);
    if (board[sq] != EMPTY) return false;
  }
  return true;
}

// ------------------------------------------------------------
//  Computer move – simple 1-ply material greedy (extendable)
// ------------------------------------------------------------
void computerMove() {
  int bestFrom = -1, bestTo = -1;
  int bestScore = -99999;

  for (int f = 21; f <= 98; f++) {
    if (board[f] == EMPTY || board[f] == EDGE) continue;
    if ((board[f] & 1) != 1) continue; // black only

    for (int t = 21; t <= 98; t++) {
      if (board[t] == EDGE) continue;
      // try the move
      int savedFrom = board[f];
      int savedTo   = board[t];
      if (tryMove(f, t)) {
        int sc = evaluate();
        if (sc > bestScore) {
          bestScore = sc;
          bestFrom = f;
          bestTo = t;
        }
        // undo
        board[f] = savedFrom;
        board[t] = savedTo;
      }
    }
  }

  if (bestFrom != -1) {
    tryMove(bestFrom, bestTo);
    toPlay = 0;
    statusMsg = "White to move";
  } else {
    statusMsg = "Black has no moves";
    gameOver = true;
  }
}

int evaluate() {
  int score = 0;
  for (int i = 21; i <= 98; i++) {
    int p = board[i];
    if (p == EMPTY || p == EDGE) continue;
    int v = values[p];
    if ((p & 1) == 1) score += v;   // black positive
    else score -= v;
  }
  return score;
}


