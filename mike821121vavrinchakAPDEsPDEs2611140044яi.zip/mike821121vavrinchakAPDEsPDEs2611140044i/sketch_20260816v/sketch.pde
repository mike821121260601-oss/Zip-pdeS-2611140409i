




// APDE Musical Instrument – 9×14 grid
// Clean tones, musical scale, soft envelope

import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;

int cols = 14;
int rows = 9;
float cellW, cellH;

final int MAX_CONCURRENT = 16;   // safe polyphony
int activeTracks = 0;

// --- Musical settings (easy to change) ---
float baseFreq = 130.81;         // C3  (change this to shift the whole instrument)
float noteDuration = 1.2;        // seconds
boolean usePentatonic = false;   // true = more "always pleasant" scale

void setup() {
  fullScreen();
  orientation(LANDSCAPE);
  cellW = width  / (float)cols;
  cellH = height / (float)rows;
  textAlign(CENTER, CENTER);
  textSize(15);
}

void draw() {
  background(15);
  
  for (int y = 0; y < rows; y++) {
    for (int x = 0; x < cols; x++) {
      float px = x * cellW;
      float py = y * cellH;
      int keyIndex = y * cols + x;
      
      boolean pressed = mousePressed && 
                        mouseX > px && mouseX < px + cellW &&
                        mouseY > py && mouseY < py + cellH;
      
      if (pressed) fill(70, 160, 255);
      else         fill(35 + (x + y) % 4 * 12);
      
      stroke(80);
      rect(px + 1, py + 1, cellW - 2, cellH - 2, 8);
      
      // show note name roughly
      fill(220);
      text(keyIndex + 1, px + cellW/2, py + cellH/2);
    }
  }
  
  fill(255, 200, 60);
  text("Notes: " + activeTracks + " / " + MAX_CONCURRENT, width/2, 26);
}

void mousePressed() {
  int col = constrain((int)(mouseX / cellW), 0, cols - 1);
  int row = constrain((int)(mouseY / cellH), 0, rows - 1);
  int keyIndex = row * cols + col;
  
  float freq = getMusicalFrequency(keyIndex);
  
  synchronized(this) {
    if (activeTracks >= MAX_CONCURRENT) return;
    activeTracks++;
  }
  
  playNote(freq, noteDuration);
}

// Convert key index → musical frequency
float getMusicalFrequency(int index) {
  if (usePentatonic) {
    // Pentatonic (very pleasant for improvisation)
    int[] intervals = {0, 2, 4, 7, 9};           // major pentatonic
    int octave = index / 5;
    int degree = index % 5;
    return baseFreq * pow(2, (octave * 12 + intervals[degree]) / 12.0);
  } else {
    // Chromatic scale (every semitone)
    return baseFreq * pow(2, index / 12.0);
  }
}

void playNote(final float freq, final float durationSec) {
  new Thread(new Runnable() {
    public void run() {
      AudioTrack track = null;
      try {
        int sampleRate = 44100;
        int numSamples = (int)(durationSec * sampleRate);
        short[] buffer = new short[numSamples];
        
        // Soft attack + release (no clicks)
        float attack = 0.04;   // 40 ms
        float release = 0.18;  // 180 ms
        
        for (int i = 0; i < numSamples; i++) {
          float t = i / (float)sampleRate;
          
          // amplitude envelope
          float amp;
          if (t < attack) {
            amp = t / attack;                          // attack
          } else if (t > durationSec - release) {
            amp = (durationSec - t) / release;         // release
          } else {
            amp = 1.0;                                 // sustain
          }
          amp = constrain(amp, 0, 1) * 0.7;            // overall volume
          
          float sample = (float)(Math.sin(2 * Math.PI * freq * t) * amp);
          buffer[i] = (short)(sample * 32767);
        }
        
        track = new AudioTrack(
            AudioManager.STREAM_MUSIC,
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            buffer.length * 2,
            AudioTrack.MODE_STATIC);
        
        track.write(buffer, 0, buffer.length);
        track.play();
        
        Thread.sleep((long)(durationSec * 1000) + 50);
        
      } catch (Exception e) {
      } finally {
        if (track != null) {
          try { track.stop(); track.release(); } catch (Exception e) {}
        }
        synchronized(this) {
          activeTracks = max(0, activeTracks - 1);
        }
      }
    }
  }).start();
}






























