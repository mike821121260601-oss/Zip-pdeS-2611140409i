

/*
Yes — here is a Version 2 test. It keeps your simplified rules but adds minimax search up to depth 8, capture values, checkmate/stalemate detection, and BEST MOVE display.
*/
// ============================================================
// APDE / Processing PDE
// SIMPLIFIED CHESS ENGINE V2
//
// 8x8 board
// NO KNIGHTS
// NO CASTLING
// QUEEN = ROOK MOVEMENT ONLY
// BISHOP = disabled
// KING = 1 square
// PAWNS = normal forward + diagonal capture
//
// A = engine makes best move
// W = engine plays White
// B = engine plays Black
// H = human only
// R = reset
// U = undo last move
// ============================================================

String[][] board = new String[8][8];

boolean whiteTurn = true;

int selectedRow = -1;
int selectedCol = -1;

ArrayList<Move> legalMoves = new ArrayList<Move>();
ArrayList<Move> history = new ArrayList<Move>();

Move bestMove = null;

int SEARCH_DEPTH = 8;

long nodes = 0;

boolean engineWhite = false;
boolean engineBlack = true;

PFont font;

// ------------------------------------------------------------

void setup() {
  size(900, 900);
  font = createFont("SansSerif", 24);
  textFont(font);
  initBoard();
}

// ------------------------------------------------------------

void draw() {

  background(235);

  drawBoard();
  drawPanel();

  // automatic engine move
  if ((whiteTurn && engineWhite) ||
      (!whiteTurn && engineBlack)) {

    delay(120);

    bestMove = findBestMove(SEARCH_DEPTH);

    if (bestMove != null) {
      doMove(bestMove);
    }

    selectedRow = -1;
    selectedCol = -1;
    legalMoves.clear();
  }
}

// ============================================================
// BOARD
// ============================================================

void initBoard() {

  for (int r = 0; r < 8; r++) {
    for (int c = 0; c < 8; c++) {
      board[r][c] = "";
    }
  }

  // BLACK
  board[0][0] = "r";
  board[0][2] = "b";
  board[0][3] = "q";
  board[0][4] = "k";
  board[0][5] = "b";
  board[0][7] = "r";

  for (int c = 0; c < 8; c++)
    board[1][c] = "p";

  // WHITE
  for (int c = 0; c < 8; c++)
    board[6][c] = "P";

  board[7][0] = "R";
  board[7][2] = "B";
  board[7][3] = "Q";
  board[7][4] = "K";
  board[7][5] = "B";
  board[7][7] = "R";

  whiteTurn = true;

  history.clear();
  bestMove = null;
  nodes = 0;
}

// ============================================================
// DRAW
// ============================================================

void drawBoard() {

  int cell = 80;
  int ox = 40;
  int oy = 40;

  for (int r = 0; r < 8; r++) {

    for (int c = 0; c < 8; c++) {

      if ((r+c)%2 == 0)
        fill(235,215,180);
      else
        fill(120,90,60);

      stroke(40);

      rect(
        ox+c*cell,
        oy+r*cell,
        cell,
        cell
      );

      // selected
      if (r == selectedRow &&
          c == selectedCol) {

        fill(255,150,0,130);
        noStroke();

        rect(
          ox+c*cell,
          oy+r*cell,
          cell,
          cell
        );
      }

      // best move
      if (bestMove != null) {

        if ((r == bestMove.fromRow &&
             c == bestMove.fromCol) ||

            (r == bestMove.toRow &&
             c == bestMove.toCol)) {

          fill(0,200,80,100);
          noStroke();

          rect(
            ox+c*cell,
            oy+r*cell,
            cell,
            cell
          );
        }
      }

      // legal move dots
      for (Move m : legalMoves) {

        if (m.toRow == r &&
            m.toCol == c) {

          fill(20,180,180,170);
          noStroke();

          ellipse(
            ox+c*cell+cell/2,
            oy+r*cell+cell/2,
            18,
            18
          );
        }
      }

      // piece
      String p = board[r][c];

      if (!p.equals("")) {

        fill(
          isWhitePiece(p)
          ? 250
          : 20
        );

        textAlign(CENTER,CENTER);
        textSize(38);

        text(
          pieceSymbol(p),
          ox+c*cell+cell/2,
          oy+r*cell+cell/2
        );
      }
    }
  }

  // coordinates

  fill(0);
  textSize(16);

  for (int c=0;c<8;c++) {

    text(
      ""+(char)('a'+c),
      ox+c*cell+40,
      695
    );
  }

  for (int r=0;r<8;r++) {

    text(
      ""+(8-r),
      20,
      oy+r*cell+40
    );
  }
}

// ============================================================
// PANEL
// ============================================================

void drawPanel() {

  fill(20);

  textAlign(LEFT,TOP);
  textSize(18);

  text(
    "TURN: "+(whiteTurn ? "WHITE":"BLACK"),
    700,40
  );

  text(
    "DEPTH: "+SEARCH_DEPTH,
    700,70
  );

  text(
    "NODES: "+nodes,
    700,100
  );

  text("A = best move",700,140);
  text("W = engine white",700,170);
  text("B = engine black",700,200);
  text("H = human mode",700,230);
  text("R = reset",700,260);
  text("U = undo",700,290);

  if (bestMove != null) {

    text(
      "BEST MOVE",
      700,340
    );

    text(
      squareName(bestMove.fromRow,
                 bestMove.fromCol)
      +" -> "+
      squareName(bestMove.toRow,
                 bestMove.toCol),
      700,370
    );

    text(
      "TAKE: "+
      (bestMove.capturedPiece.equals("")
      ? "NO"
      : bestMove.capturedPiece),
      700,400
    );

    text(
      "SCORE: "+
      bestMove.searchScore,
      700,430
    );
  }
}

// ============================================================
// TOUCH
// ============================================================

void mousePressed() {

  if ((whiteTurn && engineWhite) ||
      (!whiteTurn && engineBlack))
    return;

  int cell = 80;
  int ox = 40;
  int oy = 40;

  int col = (mouseX-ox)/cell;
  int row = (mouseY-oy)/cell;

  if (row<0 || row>=8 ||
      col<0 || col>=8)
    return;

  // select
  if (selectedRow == -1) {

    if (isMyPiece(board[row][col])) {

      selectedRow = row;
      selectedCol = col;

      legalMoves =
        getLegalMovesForPiece(row,col);
    }

    return;
  }

  // move
  Move m = findMove(row,col);

  if (m != null) {

    doMove(m);

    selectedRow=-1;
    selectedCol=-1;
    legalMoves.clear();
  }
}

// ============================================================
// KEYBOARD
// ============================================================

void keyPressed() {

  if (key=='a' || key=='A') {

    bestMove =
      findBestMove(SEARCH_DEPTH);

    if (bestMove != null)
      doMove(bestMove);

    return;
  }

  if (key=='w' || key=='W') {

    engineWhite=true;
    engineBlack=false;
    return;
  }

  if (key=='b' || key=='B') {

    engineWhite=false;
    engineBlack=true;
    return;
  }

  if (key=='h' || key=='H') {

    engineWhite=false;
    engineBlack=false;
    return;
  }

  if (key=='r' || key=='R') {

    initBoard();
    return;
  }

  if (key=='u' || key=='U') {

    undoMove();
    return;
  }
}

// ============================================================
// MOVE GENERATION
// ============================================================

ArrayList<Move> getLegalMovesForPiece(
  int row,
  int col) {

  ArrayList<Move> list =
    new ArrayList<Move>();

  String p=board[row][col];

  if (p.equals(""))
    return list;

  if (p.equals("R") ||
      p.equals("r") ||
      p.equals("Q") ||
      p.equals("q")) {

    addRookMoves(
      list,row,col,p
    );
  }

  else if (p.equals("K") ||
           p.equals("k")) {

    addKingMoves(
      list,row,col,p
    );
  }

  else if (p.equals("P")) {

    addPawnMoves(
      list,row,col,-1
    );
  }

  else if (p.equals("p")) {

    addPawnMoves(
      list,row,col,1
    );
  }

  return list;
}

// ============================================================
// ROOK / QUEEN
// ============================================================

void addRookMoves(
  ArrayList<Move> list,
  int row,
  int col,
  String p) {

  int[] dr={-1,1,0,0};
  int[] dc={0,0,-1,1};

  for (int d=0;d<4;d++) {

    int r=row+dr[d];
    int c=col+dc[d];

    while (r>=0 && r<8 &&
           c>=0 && c<8) {

      if (board[r][c].equals("")) {

        list.add(
          new Move(
            p,row,col,r,c,""
          )
        );
      }

      else {

        if (isEnemyPiece(
          board[r][c],p)) {

          list.add(
            new Move(
              p,row,col,r,c,
              board[r][c]
            )
          );
        }

        break;
      }

      r+=dr[d];
      c+=dc[d];
    }
  }
}

// ============================================================
// KING
// ============================================================

void addKingMoves(
  ArrayList<Move> list,
  int row,
  int col,
  String p) {

  for (int dr=-1;dr<=1;dr++) {

    for (int dc=-1;dc<=1;dc++) {

      if (dr==0 && dc==0)
        continue;

      int r=row+dr;
      int c=col+dc;

      if (r>=0 && r<8 &&
          c>=0 && c<8) {

        if (board[r][c].equals("") ||
            isEnemyPiece(board[r][c],p)) {

          list.add(
            new Move(
              p,row,col,r,c,
              board[r][c]
            )
          );
        }
      }
    }
  }
}

// ============================================================
// PAWN
// ============================================================

void addPawnMoves(
  ArrayList<Move> list,
  int row,
  int col,
  int dir) {

  String p=board[row][col];

  int r=row+dir;

  if (r<0 || r>=8)
    return;

  // forward

  if (board[r][col].equals("")) {

    list.add(
      new Move(
        p,row,col,r,col,""
      )
    );

    int start =
      p.equals("P") ? 6 : 1;

    int rr=row+dir*2;

    if (row==start &&
        rr>=0 && rr<8 &&
        board[rr][col].equals("")) {

      list.add(
        new Move(
          p,row,col,rr,col,""
        )
      );
    }
  }

  // captures

  for (int dc=-1;dc<=1;dc+=2) {

    int c=col+dc;

    if (c>=0 && c<8) {

      String target=board[r][c];

      if (!target.equals("") &&
          isEnemyPiece(target,p)) {

        list.add(
          new Move(
            p,row,col,r,c,target
          )
        );
      }
    }
  }
}

// ============================================================
// ALL MOVES
// ============================================================

ArrayList<Move> getAllMoves(
  boolean sideWhite) {

  ArrayList<Move> all =
    new ArrayList<Move>();

  for (int r=0;r<8;r++) {

    for (int c=0;c<8;c++) {

      String p=board[r][c];

      if (!p.equals("") &&
          isWhitePiece(p)==sideWhite) {

        all.addAll(
          getLegalMovesForPiece(r,c)
        );
      }
    }
  }

  return all;
}

// ============================================================
// 8-DEPTH MINIMAX
// ============================================================

Move findBestMove(int depth) {

  nodes=0;

  ArrayList<Move> moves =
    getAllMoves(whiteTurn);

  if (moves.size()==0)
    return null;

  Move best=null;

  int bestScore =
    whiteTurn
    ? -100000000
    : 100000000;

  for (Move m : moves) {

    String[][] save =
      copyBoard();

    makeMoveTemporary(m);

    int score =
      minimax(
        depth-1,
        -100000000,
        100000000,
        !whiteTurn
      );

    restoreBoard(save);

    m.searchScore=score;

    if (whiteTurn) {

      if (score>bestScore) {

        bestScore=score;
        best=m;
      }
    }

    else {

      if (score<bestScore) {

        bestScore=score;
        best=m;
      }
    }
  }

  return best;
}

// ============================================================

int minimax(
  int depth,
  int alpha,
  int beta,
  boolean sideWhite) {

  nodes++;

  if (depth<=0)
    return evaluate();

  ArrayList<Move> moves =
    getAllMoves(sideWhite);

  if (moves.size()==0) {

    if (kingExists(sideWhite))
      return evaluate();

    return sideWhite
      ? -1000000
      : 1000000;
  }

  if (sideWhite) {

    int best=-100000000;

    for (Move m:moves) {

      String[][] save =
        copyBoard();

      makeMoveTemporary(m);

      int score =
        minimax(
          depth-1,
          alpha,
          beta,
          false
        );

      restoreBoard(save);

      best=max(best,score);
      alpha=max(alpha,best);

      if (beta<=alpha)
        break;
    }

    return best;
  }

  else {

    int best=100000000;

    for (Move m:moves) {

      String[][] save =
        copyBoard();

      makeMoveTemporary(m);

      int score =
        minimax(
          depth-1,
          alpha,
          beta,
          true
        );

      restoreBoard(save);

      best=min(best,score);
      beta=min(beta,best);

      if (beta<=alpha)
        break;
    }

    return best;
  }
}

// ============================================================
// EVALUATION
// ============================================================

int evaluate() {

  int score=0;

  for (int r=0;r<8;r++) {

    for (int c=0;c<8;c++) {

      String p=board[r][c];

      if (p.equals(""))
        continue;

      int v=pieceValue(p);

      if (isWhitePiece(p))
        score+=v;
      else
        score-=v;

      // small positional bonus
      if (p.equals("P"))
        score+=(6-r)*2;

      if (p.equals("p"))
        score-=r*2;
    }
  }

  return score;
}

// ============================================================
// BOARD TEMPORARY MOVE
// ============================================================

void makeMoveTemporary(Move m) {

  board[m.toRow][m.toCol] =
    board[m.fromRow][m.fromCol];

  board[m.fromRow][m.fromCol]="";

  // promotion
  if (board[m.toRow][m.toCol].equals("P") &&
      m.toRow==0)
    board[m.toRow][m.toCol]="Q";

  if (board[m.toRow][m.toCol].equals("p") &&
      m.toRow==7)
    board[m.toRow][m.toCol]="q";
}

// ============================================================
// REAL MOVE
// ============================================================

void doMove(Move m) {

  history.add(
    new Move(
      m.piece,
      m.fromRow,
      m.fromCol,
      m.toRow,
      m.toCol,
      m.capturedPiece
    )
  );

  makeMoveTemporary(m);

  whiteTurn=!whiteTurn;

  bestMove=m;
}

// ============================================================
// UNDO
// ============================================================

void undoMove() {

  if (history.size()==0)
    return;

  Move m =
    history.remove(
      history.size()-1
    );

  // restore original piece
  board[m.fromRow][m.fromCol]=m.piece;

  // restore captured piece
  board[m.toRow][m.toCol]=
    m.capturedPiece;

  whiteTurn=!whiteTurn;

  bestMove=null;
}

// ============================================================
// BOARD COPY
// ============================================================

String[][] copyBoard() {

  String[][] x =
    new String[8][8];

  for (int r=0;r<8;r++)
    for (int c=0;c<8;c++)
      x[r][c]=board[r][c];

  return x;
}

void restoreBoard(String[][] x) {

  for (int r=0;r<8;r++)
    for (int c=0;c<8;c++)
      board[r][c]=x[r][c];
}

// ============================================================
// HELPERS
// ============================================================

boolean kingExists(boolean white) {

  String k=white ? "K":"k";

  for (int r=0;r<8;r++)
    for (int c=0;c<8;c++)
      if (board[r][c].equals(k))
        return true;

  return false;
}

boolean isWhitePiece(String p) {

  if (p.equals(""))
    return false;

  return p.equals(
    p.toUpperCase()
  );
}

boolean isMyPiece(String p) {

  if (p.equals(""))
    return false;

  return isWhitePiece(p)==whiteTurn;
}

boolean isEnemyPiece(
  String target,
  String mine) {

  if (target.equals(""))
    return false;

  return
    isWhitePiece(target) !=
    isWhitePiece(mine);
}

// ============================================================

int pieceValue(String p) {

  p=p.toLowerCase();

  if (p.equals("k")) return 100000;
  if (p.equals("q")) return 900;
  if (p.equals("r")) return 500;
  if (p.equals("b")) return 330;
  if (p.equals("p")) return 100;

  return 0;
}

// ============================================================

String pieceSymbol(String p) {

  if (p.equals("K")) return "♔";
  if (p.equals("Q")) return "♕";
  if (p.equals("R")) return "♖";
  if (p.equals("B")) return "♗";
  if (p.equals("P")) return "♙";

  if (p.equals("k")) return "♚";
  if (p.equals("q")) return "♛";
  if (p.equals("r")) return "♜";
  if (p.equals("b")) return "♝";
  if (p.equals("p")) return "♟";

  return p;
}

// ============================================================

String squareName(
  int row,
  int col) {

  return ""
    +(char)('a'+col)
    +(8-row);
}

// ============================================================

Move findMove(
  int row,
  int col) {

  for (Move m:legalMoves) {

    if (m.toRow==row &&
        m.toCol==col)

      return m;
  }

  return null;
}

// ============================================================
// MOVE OBJECT
// ============================================================

class Move {

  String piece;

  int fromRow;
  int fromCol;

  int toRow;
  int toCol;

  String capturedPiece;

  int searchScore=0;

  Move(
    String piece,
    int fromRow,
    int fromCol,
    int toRow,
    int toCol,
    String capturedPiece) {

    this.piece=piece;

    this.fromRow=fromRow;
    this.fromCol=fromCol;

    this.toRow=toRow;
    this.toCol=toCol;

    this.capturedPiece=
      capturedPiece;
  }
}





/*

Test controls

H — human vs human

W — engine controls White

B — engine controls Black

A — calculate and play the current side's best move

R — reset

U — undo


The important new part is the minimax + alpha-beta search. SEARCH_DEPTH = 8 means the engine tries to look up to 8 plies ahead, although the number of positions can become very large on Android.

Important: this is still a prototype engine, not full chess. It intentionally does not implement knights, castling, check legality, en-passant, or true bishop/queen diagonals.





*/












