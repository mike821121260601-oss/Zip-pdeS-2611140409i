

PGraphics canvas;

int brushSize = 12;
int brushColor = color(0);

void setup() {
  fullScreen();
  
  canvas = createGraphics(width, height);
  canvas.beginDraw();
  canvas.background(255);
  canvas.endDraw();
  
  strokeCap(ROUND);
}

void draw() {
  image(canvas, 0, 0);
  
  // Small buttons
  fill(220);
  stroke(0);
  rect(10, 10, 100, 60);
  rect(120, 10, 100, 60);
  rect(230, 10, 100, 60);
  
  fill(0);
  textSize(22);
  text("CLEAR", 25, 48);
  text("+", 160, 50);
  text("-", 270, 50);
  
  if (mousePressed && mouseY > 80) {
    canvas.beginDraw();
    canvas.stroke(brushColor);
    canvas.strokeWeight(brushSize);
    canvas.line(pmouseX, pmouseY, mouseX, mouseY);
    canvas.endDraw();
  }
}

void mousePressed() {
  if (mouseY < 80) {
    
    if (mouseX < 110) {
      canvas.beginDraw();
      canvas.background(255);
      canvas.endDraw();
    }
    
    if (mouseX > 120 && mouseX < 220) {
      brushSize += 2;
      if (brushSize > 80) brushSize = 80;
    }
    
    if (mouseX > 230 && mouseX < 340) {
      brushSize -= 2;
      if (brushSize < 2) brushSize = 2;
    }
  }
}
























