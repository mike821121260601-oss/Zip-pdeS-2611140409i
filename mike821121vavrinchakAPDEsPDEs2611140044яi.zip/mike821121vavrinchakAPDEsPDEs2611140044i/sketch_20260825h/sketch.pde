





/*
Добре! Ось простий прототип шахової дошки з базовою можливістю розставляти і переміщати фігури мишею в Processing (Java). Тут немає логіки гри або ходів комп’ютера, але це база, на якій можна будувати:

```java
*/







int tileSize = 80;
int cols = 8;
int rows = 8;

PImage[][] pieces = new PImage[2][6]; // 2 кольори, 6 типів фігур
Piece[][] board = new Piece[8][8];

Piece selectedPiece = null;
int offsetX, offsetY;

void setup() {

 // size(tileSize * cols, tileSize * rows);

 //  fullscreen(P2D) ;

size(displayWidth, displayHeight, P2D) ;


  loadPieces();
  setupBoard();
}

void draw() {
  background(255);
  drawBoard();
  drawPieces();
  if (selectedPiece != null) {
    image(selectedPiece.img, mouseX - offsetX, mouseY - offsetY);
  }
}

void loadPieces() {
  // Завантажуємо картинки фігур (файли мають бути в папці "data")
  // Порядок: король, ферзь, тура, слон, кінь, пішак
  pieces[0][0] = loadImage("white_king.png");
  pieces[0][1] = loadImage("white_queen.png");
  pieces[0][2] = loadImage("white_rook.png");
  pieces[0][3] = loadImage("white_bishop.png");
  pieces[0][4] = loadImage("white_knight.png");
  pieces[0][5] = loadImage("white_pawn.png");
  
  pieces[1][0] = loadImage("black_king.png");
  pieces[1][1] = loadImage("black_queen.png");
  pieces[1][2] = loadImage("black_rook.png");
  pieces[1][3] = loadImage("black_bishop.png");
  pieces[1][4] = loadImage("black_knight.png");
  pieces[1][5] = loadImage("black_pawn.png");
}

void setupBoard() {
  // Встановлюємо початкові позиції фігур
  // Білий – індекс 0, чорний – 1
  // Пішаки
  for (int i = 0; i < 8; i++  ) {
    board[1][i] = new Piece(pieces[1][5], 1, "pawn", 1, i);
    board[6][i] = new Piece(pieces[0][5], 0, "pawn", 6, i);
  }
  // Тури
  board[0][0] = new Piece(pieces[1][2], 1, "rook", 0, 0);
  board[0][7] = new Piece(pieces[1][2], 1, "rook", 0, 7);
  board[7][0] = new Piece(pieces[0][2], 0, "rook", 7, 0);
  board[7][7] = new Piece(pieces[0][2], 0, "rook", 7, 7);
  // Коні
  board[0][1] = new Piece(pieces[1][4], 1, "knight", 0, 1);
  board[0][6] = new Piece(pieces[1][4], 1, "knight", 0, 6);
  board[7][1] = new Piece(pieces[0][4], 0, "knight", 7, 1);
  board[7][6] = new Piece(pieces[0][4], 0, "knight", 7, 6);
  // Слони
  board[0][2] = new Piece(pieces[1][3], 1, "bishop", 0, 2);
  board[0][5] = new Piece(pieces[1][3], 1, "bishop", 0, 5);
  board[7][2] = new Piece(pieces[0][3], 0, "bishop", 7, 2);
  board[7][5] = new Piece(pieces[0][3], 0, "bishop", 7, 5);
  // Ферзі
  board[0][3] = new Piece(pieces[1][1], 1, "queen", 0, 3);
  board[7][3] = new Piece(pieces[0][1], 0, "queen", 7, 3);
  // Королі
  board[0][4] = new Piece(pieces[1][0], 1, "king", 0, 4);
  board[7][4] = new Piece(pieces[0][0], 0, "king", 7, 4);
}

void drawBoard() {
  for (int i = 0; i < cols; i ++ ) {
    for (int j = 0; j < rows; j ++ ) {
      if ((i  +  j) % 2 == 0) fill(240);
      else fill(90);
      rect(i * tileSize, j * tileSize, tileSize, tileSize);
    }
  }
}

void drawPieces() {
  for (int i = 0; i < rows; i  ++) {
    for (int j = 0; j < cols; j  ++) {
      Piece p = board[i][j];
      if (p != null && p != selectedPiece) {
        image(p.img, j * tileSize, i * tileSize, tileSize, tileSize);
      }
    }
  }
}

void mousePressed() {
  int i = mouseY / tileSize;
  int j = mouseX / tileSize;
  if (i >= 0 && i < rows && j >= 0 && j < cols) {
    Piece p = board[i][j];
    if (p != null) {
      selectedPiece = p;
      offsetX = mouseX - j * tileSize;
      offsetY = mouseY - i * tileSize;
      board[i][j] = null; // Забираємо з дошки до переміщення
    }
  }
}

void mouseReleased() {
  if (selectedPiece != null) {
    int i = mouseY / tileSize;
    int j = mouseX / tileSize;
    if (i >= 0 && i < rows && j >= 0 && j < cols) {
      // Проста логіка - ставимо фігуру на клітинку
      selectedPiece.row = i;
      selectedPiece.col = j;
      board[i][j] = selectedPiece;
    } else {
      // Повертаємо фігуру на початкове місце, якщо поза дошкою
      board[selectedPiece.row][selectedPiece.col] = selectedPiece;
    }
    selectedPiece = null;
  }
}

// Клас для шахової фігури
class Piece {
  PImage img;
  int color; // 0 - білий, 1 - чорний
  String type;
  int row, col;
  
  Piece(PImage img, int color, String type, int row, int col) {
    this.img = img;
    this.color = color;
    this.type = type;
    this.row = row;
    this.col = col;
  }
}



/*






```

**Що потрібно для запуску:**  
- Потрібно мати в папці `data` картинки фігур з назвами:  
  `white_king.png`  
  `white_queen.png`  
  `white_rook.png`  
  `white_bishop.png`  
  `white_knight.png`  
  `white_pawn.png`  
  `black_king.png`  
  `black_queen.png`  
  `black_rook.png`  
  `black_bishop.png`  
  `black_knight.png`  
  `black_pawn.png`


*/



/*
Ви можете знайти відкриті набори іконок фігур у інтернеті, наприклад на сайтах із безкоштовними іконками.

---

Цей код — це простий старт. Наступні кроки — реалізувати правила ходів, перевірку шаху, ходи комп’ютера (можна підключити Stockfish через API або локально), підрахунок переможця.

Якщо потрібно, допоможу з наступними етапами!
*/
























