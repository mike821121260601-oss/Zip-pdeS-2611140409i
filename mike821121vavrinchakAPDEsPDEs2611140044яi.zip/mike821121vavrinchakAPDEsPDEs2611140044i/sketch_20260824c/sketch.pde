
// ============================================================
// APDE 0.5.3
// BIOLOGICAL HUMAN SKELETON - P3D
// Single PDE file
//
// Units:
// 1.0 = 1 meter
//
// Human height approximately 1.78 m
//
// BODY:
// transparent surface = 20%
// point cloud = configurable
//
// SKELETON:
// dynamic joints and bones
//
// CONTROLS:
// LEFT / RIGHT
// UP / DOWN
// FRONT / BACK
// START BONES
// END BONES
//
// Small control size is calculated from physical millimeters.
// ============================================================


// -------------------------------
// SETTINGS
// -------------------------------

float HUMAN_HEIGHT = 1.78;

int POINT_COUNT = 700000-650000;
// Increase toward 1000000-2000000 if the Android device is fast.
// Several million dynamic points can be too slow on Android 9.

float POINT_SIZE = 2.0;

float BODY_ALPHA = 51 +111;       // 20% of 255

boolean bonesRunning = false;


// -------------------------------
// CAMERA
// -------------------------------

float camX = 0;
float camY = 1.05;
float camZ = 4.0;

float yaw = 0;
float pitch = 0;

float moveSpeed = 0.025;


// -------------------------------
// JOINTS
// -------------------------------

final int HEAD = 0;

final int NECK = 1;

final int SHOULDER_L = 2;
final int ELBOW_L = 3;
final int WRIST_L = 4;
final int HAND_L = 5;

final int SHOULDER_R = 6;
final int ELBOW_R = 7;
final int WRIST_R = 8;
final int HAND_R = 9;

final int SPINE1 = 10;
final int SPINE2 = 11;
final int PELVIS = 12;

final int HIP_L = 13;
final int KNEE_L = 14;
final int ANKLE_L = 15;
final int FOOT_L = 16;

final int HIP_R = 17;
final int KNEE_R = 18;
final int ANKLE_R = 19;
final int FOOT_R = 20;

final int JOINTS = 21;

PVector[] J = new PVector[JOINTS];


// -------------------------------
// BODY POINT CLOUD
// -------------------------------

PShape bodyPoints;


// -------------------------------
// BODY DIMENSIONS
// -------------------------------

float shoulderWidth = 0.43;
float pelvisWidth = 0.30;

float headRadius = 0.115;

float chestWidth = 0.28;
float chestDepth = 0.18;

float waistWidth = 0.22;

float upperArm = 0.29;
float foreArm = 0.25;

float upperLeg = 0.43;
float lowerLeg = 0.42;

float footLength = 0.25;


// -------------------------------
// TOUCH STATES
// -------------------------------

boolean keyUp = false;
boolean keyDown = false;
boolean keyLeft = false;
boolean keyRight = false;
boolean keyFront = false;
boolean keyBack = false;

boolean keyStart = false;
boolean keyEnd = false;


// -------------------------------
// 3 MM CONTROL
// -------------------------------

float mmToPixels(float mm) {

  // Android physical pixel density
  // Processing density is used as approximation.

  return mm * displayDensity * 160.0 / 25.4;
}


// ============================================================
// SETUP
// ============================================================

void setup() {

  fullScreen(P3D);

  smooth(2);

  frameRate(30);

  for (int i = 0; i < JOINTS; i++) {
    J[i] = new PVector();
  }

  makeSkeleton();

  generateBodyPoints();

  textAlign(CENTER, CENTER);
}


// ============================================================
// DRAW
// ============================================================

void draw() {

  background(8, 12, 18);

  updateControls();

  if (bonesRunning) {
    animateSkeleton();
  }

  setupCamera();

  lights();

  drawBody();

  drawSkeleton();

  hint(DISABLE_DEPTH_TEST);

  camera();

  drawControls();

  hint(ENABLE_DEPTH_TEST);
}


// ============================================================
// CAMERA
// ============================================================

void setupCamera() {

  float dx = sin(yaw);
  float dz = cos(yaw);

  float lx = camX + dx;
  float ly = camY + sin(pitch);
  float lz = camZ + dz;

  camera(
    camX,
    camY,
    camZ,
    lx,
    ly,
    lz,
    0,
    1,
    0
  );
}


// ============================================================
// SKELETON INITIAL POSITION
// ============================================================

void makeSkeleton() {

  // Feet
  J[FOOT_L].set(-0.09, 0.05, 0.04);
  J[FOOT_R].set( 0.09, 0.05, 0.04);

  // Ankles
  J[ANKLE_L].set(-0.09, 0.11, 0);
  J[ANKLE_R].set( 0.09, 0.11, 0);

  // Knees
  J[KNEE_L].set(-0.095, 0.53, 0);
  J[KNEE_R].set( 0.095, 0.53, 0);

  // Hips
  J[HIP_L].set(-0.14, 0.94, 0);
  J[HIP_R].set( 0.14, 0.94, 0);

  // Pelvis
  J[PELVIS].set(0, 1.00, 0);

  // Spine
  J[SPINE1].set(0, 1.16, 0);
  J[SPINE2].set(0, 1.32, 0);

  // Neck
  J[NECK].set(0, 1.55, 0);

  // Head
  J[HEAD].set(0, 1.67, 0);

  // Shoulders
  J[SHOULDER_L].set(-0.215, 1.43, 0);
  J[SHOULDER_R].set( 0.215, 1.43, 0);

  // Arms
  J[ELBOW_L].set(-0.48, 1.18, 0);
  J[WRIST_L].set(-0.55, 0.92, 0);
  J[HAND_L].set(-0.56, 0.82, 0);

  J[ELBOW_R].set(0.48, 1.18, 0);
  J[WRIST_R].set(0.55, 0.92, 0);
  J[HAND_R].set(0.56, 0.82, 0);
}


// ============================================================
// ANIMATION
// ============================================================

void animateSkeleton() {

  float t = millis() * 0.002;

  float swing = sin(t) * 0.20;

  // Left leg
  J[KNEE_L].z = swing * 0.35;
  J[ANKLE_L].z = swing * 0.65;
  J[FOOT_L].z = swing * 0.75;

  // Right leg opposite
  J[KNEE_R].z = -swing * 0.35;
  J[ANKLE_R].z = -swing * 0.65;
  J[FOOT_R].z = -swing * 0.75;

  // Arms
  J[ELBOW_L].z = -swing * 0.65;
  J[WRIST_L].z = -swing * 0.85;
  J[HAND_L].z = -swing;

  J[ELBOW_R].z = swing * 0.65;
  J[WRIST_R].z = swing * 0.85;
  J[HAND_R].z = swing;
}


// ============================================================
// BODY POINT CLOUD
// ============================================================

void generateBodyPoints() {

  bodyPoints = createShape();

  bodyPoints.beginShape(POINTS);

  bodyPoints.strokeWeight(POINT_SIZE);

  randomSeed(92831);

  for (int i = 0; i < POINT_COUNT; i++) {

    float x;
    float y;
    float z;

    float r = random(1);

    // HEAD
    if (r < 0.12) {

      float a = random(TWO_PI);
      float b = random(-HALF_PI, HALF_PI);

      x = cos(b) * cos(a) * headRadius;
      y = 1.67 + sin(b) * headRadius;
      z = cos(b) * sin(a) * headRadius;
    }

    // CHEST
    else if (r < 0.42) {

      y = random(1.20, 1.50);

      float scale =
        1.0 - abs(y - 1.35) * 1.5;

      x = randomGaussian() * chestWidth * 0.42 * scale;
      z = randomGaussian() * chestDepth * 0.42;
    }

    // WAIST
    else if (r < 0.53) {

      y = random(1.00, 1.22);

      x = randomGaussian() * waistWidth * 0.38;
      z = randomGaussian() * 0.09;
    }

    // PELVIS
    else if (r < 0.65) {

      y = random(0.87, 1.05);

      x = randomGaussian() * pelvisWidth * 0.43;
      z = randomGaussian() * 0.12;
    }

    // LEFT LEG
    else if (r < 0.77) {

      y = random(0.10, 0.92);

      float q = map(y, 0.10, 0.92, 0, 1);

      x = -0.09 - 0.04 * q;

      x += randomGaussian() * 0.055;

      z = randomGaussian() * 0.055;
    }

    // RIGHT LEG
    else if (r < 0.89) {

      y = random(0.10, 0.92);

      float q = map(y, 0.10, 0.92, 0, 1);

      x = 0.09 + 0.04 * q;

      x += randomGaussian() * 0.055;

      z = randomGaussian() * 0.055;
    }

    // ARMS
    else {

      boolean left = random(1) < 0.5;

      y = random(0.80, 1.44);

      float q = map(y, 0.80, 1.44, 0, 1);

      if (left)
        x = -0.22 - 0.30 * (1.0 - q);
      else
        x =  0.22 + 0.30 * (1.0 - q);

      x += randomGaussian() * 0.04;

      z = randomGaussian() * 0.045;
    }

    bodyPoints.vertex(x, -y, z);
  }

  bodyPoints.endShape();
}


// ============================================================
// BODY RENDER
// ============================================================

void drawBody() {

  pushMatrix();

  // Body point cloud
  shape(bodyPoints);

  // Transparent body volumes
  noStroke();

  fill(210, 120, 100, BODY_ALPHA);

  // Head
  pushMatrix();
  translate(0, -J[HEAD].y, 0);
  sphere(headRadius);
  popMatrix();

  // Chest
  pushMatrix();
  translate(0, -1.34, 0);
  scale(0.27, 0.31, 0.16);
  sphere(1);
  popMatrix();

  // Pelvis
  pushMatrix();
  translate(0, -0.98, 0);
  scale(0.22, 0.16, 0.14);
  sphere(1);
  popMatrix();

  // Upper legs
  transparentLimb(J[HIP_L], J[KNEE_L], 0.075);
  transparentLimb(J[HIP_R], J[KNEE_R], 0.075);

  // Lower legs
  transparentLimb(J[KNEE_L], J[ANKLE_L], 0.055);
  transparentLimb(J[KNEE_R], J[ANKLE_R], 0.055);

  // Arms
  transparentLimb(J[SHOULDER_L], J[ELBOW_L], 0.055);
  transparentLimb(J[ELBOW_L], J[WRIST_L], 0.045);

  transparentLimb(J[SHOULDER_R], J[ELBOW_R], 0.055);
  transparentLimb(J[ELBOW_R], J[WRIST_R], 0.045);

  popMatrix();
}


// ============================================================
// TRANSPARENT LIMB
// ============================================================

void transparentLimb(
  PVector a,
  PVector b,
  float radius
) {

  PVector mid = PVector.add(a, b);
  mid.mult(0.5);

  float len = PVector.dist(a, b);

  pushMatrix();

  translate(mid.x, -mid.y, mid.z);

  // approximate transparent cylinder
  int sides = 6;

  beginShape(QUAD_STRIP);

  for (int i = 0; i <= sides; i++) {

    float ang = TWO_PI * i / sides;

    float x = cos(ang) * radius;
    float z = sin(ang) * radius;

    vertex(
      x,
      -len * 0.5,
      z
    );

    vertex(
      x,
      len * 0.5,
      z
    );
  }

  endShape();

  popMatrix();
}


// ============================================================
// SKELETON
// ============================================================

void drawSkeleton() {

  stroke(240, 240, 220, 230);
  strokeWeight(3);

  // spine
  bone(SPINE2, NECK);
  bone(SPINE1, SPINE2);
  bone(PELVIS, SPINE1);

  // neck/head
  bone(NECK, HEAD);

  // shoulders
  bone(SHOULDER_L, SHOULDER_R);
  bone(NECK, SHOULDER_L);
  bone(NECK, SHOULDER_R);

  // left arm
  bone(SHOULDER_L, ELBOW_L);
  bone(ELBOW_L, WRIST_L);
  bone(WRIST_L, HAND_L);

  // right arm
  bone(SHOULDER_R, ELBOW_R);
  bone(ELBOW_R, WRIST_R);
  bone(WRIST_R, HAND_R);

  // pelvis
  bone(HIP_L, HIP_R);
  bone(PELVIS, HIP_L);
  bone(PELVIS, HIP_R);

  // left leg
  bone(HIP_L, KNEE_L);
  bone(KNEE_L, ANKLE_L);
  bone(ANKLE_L, FOOT_L);

  // right leg
  bone(HIP_R, KNEE_R);
  bone(KNEE_R, ANKLE_R);
  bone(ANKLE_R, FOOT_R);

  // joints
  noStroke();
  fill(255, 210, 80);

  for (int i = 0; i < JOINTS; i++) {

    pushMatrix();

    translate(
      J[i].x,
      -J[i].y,
      J[i].z
    );

    sphere(0.018);

    popMatrix();
  }
}


// ============================================================
// BONE LINE
// ============================================================

void bone(int a, int b) {

  line(
    J[a].x,
    -J[a].y,
    J[a].z,

    J[b].x,
    -J[b].y,
    J[b].z
  );
}


// ============================================================
// MOVEMENT
// ============================================================

void updateControls() {

  if (keyLeft)
    yaw -= 0.035;

  if (keyRight)
    yaw += 0.035;

  float dx = sin(yaw) * moveSpeed;
  float dz = cos(yaw) * moveSpeed;

  if (keyUp) {
    camX += dx;
    camZ += dz;
  }

  if (keyDown) {
    camX -= dx;
    camZ -= dz;
  }

  if (keyFront) {
    camY -= moveSpeed;
  }

  if (keyBack) {
    camY += moveSpeed;
  }

  camY = constrain(camY, 0.1, 4.0);
}


// ============================================================
// TOUCH CONTROLS
// ============================================================

void drawControls() {

  float s = mmToPixels(3.0);

  // Android may produce very small physical controls.
  // Minimum is used so they remain touchable.
  float touchSize = max(s, 55);

  float gap = 10;

  float bottom = height - touchSize - 15;

  drawButton(
    15,
    bottom,
    touchSize,
    touchSize,
    "L"
  );

  drawButton(
    15 + touchSize + gap,
    bottom,
    touchSize,
    touchSize,
    "R"
  );

  drawButton(
    15 + touchSize * 0.5,
    bottom - touchSize - gap,
    touchSize,
    touchSize,
    "UP"
  );

  drawButton(
    15 + touchSize * 0.5,
    bottom + touchSize + gap,
    touchSize,
    touchSize,
    "DOWN"
  );

  float right = width - touchSize - 15;

  drawButton(
    right,
    bottom,
    touchSize,
    touchSize,
    "FRONT"
  );

  drawButton(
    right,
    bottom - touchSize - gap,
    touchSize,
    touchSize,
    "BACK"
  );

  drawButton(
    width/2 - touchSize - gap,
    20,
    touchSize,
    touchSize,
    "START\nBONES"
  );

  drawButton(
    width/2 + gap,
    20,
    touchSize,
    touchSize,
    "END\nBONES"
  );
}


// ============================================================
// BUTTON DRAW
// ============================================================

void drawButton(
  float x,
  float y,
  float w,
  float h,
  String label
) {

  fill(20, 20, 25, 190);
  stroke(220, 220, 220, 180);
  strokeWeight(1);

  rect(
    x,
    y,
    w,
    h,
    5
  );

  fill(255);

  textSize(
    max(8, min(18, w * 0.20))
  );

  text(
    label,
    x + w/2,
    y + h/2
  );
}


// ============================================================
// TOUCH
// ============================================================

void touchStarted() {

  processTouch(mouseX, mouseY);
}

void touchMoved() {

  processTouch(mouseX, mouseY);
}

void touchEnded() {

  clearKeys();
}


// ============================================================
// TOUCH PROCESSING
// ============================================================

void processTouch(
  float x,
  float y
) {

  clearKeys();

  float s = max(mmToPixels(3.0), 55);
  float gap = 10;

  float bottom = height - s - 15;

  // LEFT
  if (inside(
    x, y,
    15,
    bottom,
    s,
    s
    )) {

    keyLeft = true;
  }

  // RIGHT
  if (inside(
    x, y,
    15 + s + gap,
    bottom,
    s,
    s
    )) {

    keyRight = true;
  }

  // UP
  if (inside(
    x, y,
    15 + s * 0.5,
    bottom - s - gap,
    s,
    s
    )) {

    keyUp = true;
  }

  // DOWN
  if (inside(
    x, y,
    15 + s * 0.5,
    bottom + s + gap,
    s,
    s
    )) {

    keyDown = true;
  }

  // FRONT
  if (inside(
    x, y,
    width - s - 15,
    bottom,
    s,
    s
    )) {

    keyFront = true;
  }

  // BACK
  if (inside(
    x, y,
    width - s - 15,
    bottom - s - gap,
    s,
    s
    )) {

    keyBack = true;
  }

  // START BONES
  if (inside(
    x, y,
    width/2 - s - gap,
    20,
    s,
    s
    )) {

    bonesRunning = true;
  }

  // END BONES
  if (inside(
    x, y,
    width/2 + gap,
    20,
    s,
    s
    )) {

    bonesRunning = false;
  }
}


// ============================================================
// CLEAR TOUCH STATES
// ============================================================

void clearKeys() {

  keyUp = false;
  keyDown = false;
  keyLeft = false;
  keyRight = false;

  keyFront = false;
  keyBack = false;
}


// ============================================================
// HIT TEST
// ============================================================

boolean inside(
  float px,
  float py,
  float x,
  float y,
  float w,
  float h
) {

  return
    px >= x &&
    px <= x + w &&
    py >= y &&
    py <= y + h;
}




























