
























/*















Yes. Here is a complete APDE / Processing Java 3D game example:
🏔️ 3D mountain terrain
🚶 WASD / arrow-key walking
☁️ 100 spheres in the sky
✨ spheres move along a line
🎥 first-person camera
🌄 fog-like sky background
Paste this into an APDE sketch:
// APDE 3D MOUNTAIN GAME
// Processing / Java mode
// Controls: W A S D or ARROW KEYS
*/








float px = 0;
float pz = 250;
float py = 35;

float angle = 0;
float speed = 4;

boolean forward, back, left, right;

int N = 100;

float[] sx = new float[N];
float[] sy = new float[N];
float[] sz = new float[N];

void setup() {
  fullScreen(P3D);

  // Create 100 sky spheres
  for (int i = 0; i < N; i++) {
    sx[i] = random(-900, 900);
    sy[i] = random(-250, 100);
    sz[i] = random(-1000, 500);
  }
}

void draw() {
  background(90, 170, 230);

  // Camera direction
  float dx = sin(angle);
  float dz = -cos(angle);

  // WALK
  if (forward) {
    px += dx * speed;
    pz += dz * speed;
  }

  if (back) {
    px -= dx * speed;
    pz -= dz * speed;
  }

  if (left) {
    px += cos(angle) * speed;
    pz += sin(angle) * speed;
  }

  if (right) {
    px -= cos(angle) * speed;
    pz -= sin(angle) * speed;
  }

  // Camera
  camera(
    px, py, pz,
    px + dx * 300, py - 20, pz + dz * 300,
    0, 1, 0
  );

  // LIGHT
  ambientLight(100, 100, 100);
  directionalLight(255, 255, 255, -0.5, -1, -0.5);

  // SUN
  pushMatrix();
  translate(px + 500, -400, pz - 800);
  noStroke();
  fill(255, 240, 100);
  sphere(80);
  popMatrix();

  // MOUNTAINS
  drawMountains();

  // GROUND
  pushMatrix();
  translate(0, 60, 0);
  rotateX(HALF_PI);

  noStroke();
  fill(40, 130, 55);
  rectMode(CENTER);
  rect(0, 0, 4000, 4000);

  popMatrix();

  // 100 SKY SPHERES
  drawSpheres();

  // MOVING LINE
  drawMovingLine();

  // Crosshair
  drawCrosshair();

  // HUD
  drawHUD();
}


// --------------------------------------------------
// MOUNTAINS
// --------------------------------------------------

void drawMountains() {

  int rows = 18;
  int cols = 18;

  float size = 250;

  for (int z = -rows; z < rows; z++) {

    beginShape(TRIANGLE_STRIP);

    for (int x = -cols; x <= cols; x++) {

      float wx = x * size;
      float wz = z * size;

      float h =
        30 +
        90 * noise(x * 0.12, z * 0.12) +
        70 * noise(x * 0.04, z * 0.04);

      // Far mountains become larger
      if (z < -5) {
        h += 150;
      }

      // Left side
      fill(
        35 + h * 0.1,
        80 + h * 0.2,
        40
      );

      vertex(
        wx,
        60 - h,
        wz
      );

      // Second vertex
      float h2 =
        30 +
        90 * noise((x + 1) * 0.12, z * 0.12) +
        70 * noise((x + 1) * 0.04, z * 0.04);

      if (z < -5)
        h2 += 150;

      vertex(
        wx + size,
        60 - h2,
        wz
      );
    }

    endShape();
  }
}


// --------------------------------------------------
// 100 MOVING SPHERES
// --------------------------------------------------

void drawSpheres() {

  for (int i = 0; i < N; i++) {

    // Move spheres along a line
    sx[i] += 1.5;

    // Reset when they reach the end
    if (sx[i] > 1200) {
      sx[i] = -1200;
    }

    pushMatrix();

    translate(
      sx[i],
      sy[i],
      sz[i]
    );

    noStroke();

    // Different colors
    if (i % 3 == 0)
      fill(255, 80, 80);
    else if (i % 3 == 1)
      fill(80, 255, 120);
    else
      fill(100, 160, 255);

    sphere(8);

    popMatrix();
  }
}


// --------------------------------------------------
// MOVING LINE THROUGH THE SPHERES
// --------------------------------------------------

void drawMovingLine() {

  pushMatrix();

  stroke(255, 230, 50);
  strokeWeight(3);

  // Long horizontal line
  line(
    -1200, -50, -300,
     1200, -50, -300
  );

  // A second diagonal moving line
  float t = (frameCount * 2) % 2400 - 1200;

  stroke(255, 255, 255);

  line(
    t, -200, -500,
    t + 300, 100, -500
  );

  popMatrix();
}


// --------------------------------------------------
// CROSSHAIR
// --------------------------------------------------

void drawCrosshair() {

  camera();

  stroke(255);
  strokeWeight(2);

  line(
    width/2 - 10,
    height/2,
    width/2 + 10,
    height/2
  );

  line(
    width/2,
    height/2 - 10,
    width/2,
    height/2 + 10
  );
}


// --------------------------------------------------
// HUD
// --------------------------------------------------

void drawHUD() {

  camera();

  fill(255);
  textSize(22);

  text("3D MOUNTAIN GAME", 20, 30);
  text("WASD / ARROWS = WALK", 20, 58);

  text(
    "X: " + int(px) +
    "  Z: " + int(pz),
    20, 86
  );
}


// --------------------------------------------------
// KEYBOARD
// --------------------------------------------------

void keyPressed() {

  if (key == 'w' || key == 'W' || keyCode == UP)
    forward = true;

  if (key == 's' || key == 'S' || keyCode == DOWN)
    back = true;

  if (key == 'a' || key == 'A' || keyCode == LEFT)
    left = true;

  if (key == 'd' || key == 'D' || keyCode == RIGHT)
    right = true;
}


void keyReleased() {

  if (key == 'w' || key == 'W' || keyCode == UP)
    forward = false;

  if (key == 's' || key == 'S' || keyCode == DOWN)
    back = false;

  if (key == 'a' || key == 'A' || keyCode == LEFT)
    left = false;

  if (key == 'd' || key == 'D' || keyCode == RIGHT)
    right = false;
}


/*
Controls: W = forward, S = backward, A/D = left/right. Arrow keys also work.
If you want, I can �⁠make the **next version with
 mouse/touch camera rotation, shooting the 100
 spheres, collision with mountains, and a player gun**.
*/






























