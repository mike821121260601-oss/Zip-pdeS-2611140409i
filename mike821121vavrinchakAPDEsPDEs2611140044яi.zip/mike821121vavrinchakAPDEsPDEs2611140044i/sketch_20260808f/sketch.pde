






















/*


Here is a simple APDE/Processing sketch. It draws 1×1 pixel random colors in the main area (20–90% horizontal, 10–90% vertical). The left 5–15% strip is a color palette; touching a pixel in the drawing area paints it with the selected color.
// APDE / Processing

*/




int selectedColor = color(255, 0, 0);

void setup() {
  fullScreen();
  noStroke();
  background(0);
  
  drawRandomPixels();
  drawPalette();
}

void draw() {
  // Nothing needed here












}

void drawRandomPixels() {
  int x1 = (int)(width * 0.20);
  int x2 = (int)(width * 0.90);
  int y1 = (int)(height * 0.10);
  int y2 = (int)(height * 0.90);

  loadPixels();

  for (int y = y1; y < y2; y++) {
    for (int x = x1; x < x2; x++) {
      pixels[y * width + x] =
        color(random(255), random(255), random(255));
    }
  }

  updatePixels();
}

void drawPalette() {
  int x1 = (int)(width * 0.05);
  int x2 = (int)(width * 0.15);
  int y1 = (int)(height * 0.05);
  int y2 = (int)(height * 0.95);

  noStroke();

  // Random-color palette pixels
  for (int y = y1; y < y2; y++) {
    for (int x = x1; x < x2; x++) {
      fill(
        random(255),
        random(255),
        random(255)
      );
      rect(x, y, 1, 1);
    }
  }
}

void touchStarted() {
  paintPixel(mouseX, mouseY);
}

void touchMoved() {
  paintPixel(mouseX, mouseY);
}

void paintPixel(int x, int y) {

  // Palette area: choose the touched color
  if (x >= width * 0.05 &&
      x <  width * 0.15 &&
      y >= height * 0.05 &&
      y <  height * 0.95) {

    selectedColor = get(x, y);
    return;
  }



  // Drawing area
  if (x >= width * 0.20 &&
      x <  width * 0.90 &&
      y >= height * 0.10 &&
      y <  height * 0.90) {

    set(x, y, selectedColor);
  }
}



/*
Areas:
🎨 Palette: X = 5–15%, Y = 5–95%
🖼️ Drawing: X = 20–90%, Y = 10–90%
Each drawing element is exactly 1 pixel
Touch palette → select that pixel's color
Touch/drag drawing → paint pixels with selected color

*/








